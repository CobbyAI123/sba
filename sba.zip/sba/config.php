<?php
// config.php - Main Configuration File
// Prevent double loading
if (defined('CONFIG_LOADED')) {
    return;
}
define('CONFIG_LOADED', true);

// Start session with secure settings
if (session_status() === PHP_SESSION_NONE) {
    // Set session parameters before starting
    ini_set('session.use_cookies', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_httponly', 1);
    
    // Start session
    session_start();
}

// Base Path
if (!defined('BASE_PATH')) {
    define('BASE_PATH', __DIR__);
}

if (!function_exists('env')) {
    function env($key, $default = null) {
        $value = getenv($key);
        if ($value === false || $value === '') {
            return $default;
        }
        return $value;
    }
}

$envPath = BASE_PATH . '/.env';
if (is_file($envPath) && is_readable($envPath)) {
    $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (is_array($lines)) {
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '#') === 0) {
                continue;
            }
            if (strpos($line, '=') === false) {
                continue;
            }
            $parts = explode('=', $line, 2);
            $name = trim($parts[0]);
            $value = trim($parts[1]);
            $value = trim($value, "\"'");

            if ($name !== '' && getenv($name) === false) {
                putenv($name . '=' . $value);
                $_ENV[$name] = $value;
                $_SERVER[$name] = $value;
            }
        }
    }
}

// Environment Configuration
if (!defined('APP_ENV')) {
    // Auto-detect environment: if 'localhost' or '127.0.0.1' = development, else = production
    $isLocal = (isset($_SERVER['HTTP_HOST']) && 
                (strpos($_SERVER['HTTP_HOST'], 'localhost') !== false || 
                 strpos($_SERVER['HTTP_HOST'], '127.0.0.1') !== false));
    define('APP_ENV', env('APP_ENV', $isLocal ? 'development' : 'production'));
}

// Error Reporting
if (APP_ENV === 'production') {
    $logDir = BASE_PATH . '/logs';
    if (!is_dir($logDir)) {
        @mkdir($logDir, 0755, true);
    }
    error_reporting(0); // Hide all errors in production
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', BASE_PATH . '/logs/error.log');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}

// Database Configuration (use environment variables in production)
if (!defined('DB_HOST')) {
    if (APP_ENV === 'production') {
        define('DB_HOST', env('DB_HOST', 'localhost'));
        define('DB_USER', env('DB_USER', ''));
        define('DB_PASS', env('DB_PASS', ''));
        define('DB_NAME', env('DB_NAME', ''));
    } else {
        // LOCAL DEVELOPMENT
        define('DB_HOST', env('DB_HOST', 'localhost'));
        define('DB_USER', env('DB_USER', 'root'));
        define('DB_PASS', env('DB_PASS', ''));
        define('DB_NAME', env('DB_NAME', 'sba'));
    }
}

if (APP_ENV === 'production' && (DB_USER === '' || DB_NAME === '')) {
    error_log('Application configuration error: missing DB_USER/DB_NAME in environment');
    http_response_code(500);
    die('Application is not configured.');
}

// Application URL
if (!defined('APP_URL')) {
    if (APP_ENV === 'production') {
        $envUrl = env('APP_URL');
        if (!empty($envUrl)) {
            define('APP_URL', rtrim($envUrl, '/'));
        } else {
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $host = $_SERVER['HTTP_HOST'] ?? 'sba.uniquehavenangelschool.com';
            define('APP_URL', $protocol . '://' . $host);
        }
    } else {
        define('APP_URL', env('APP_URL', 'http://localhost/sba'));
    }
}

// Upload Directories
if (!defined('UPLOAD_PATH')) {
    define('UPLOAD_PATH', BASE_PATH . '/uploads/');
}
if (!defined('AVATAR_PATH')) {
    define('AVATAR_PATH', UPLOAD_PATH . 'avatars/');
}
if (!defined('STUDENT_PHOTO_PATH')) {
    define('STUDENT_PHOTO_PATH', UPLOAD_PATH . 'students/');
}
if (!defined('SCHOOL_LOGO_PATH')) {
    define('SCHOOL_LOGO_PATH', UPLOAD_PATH . 'logos/');
}

// Currency Configuration
if (!defined('CURRENCY_CODE')) {
    define('CURRENCY_CODE', 'GHS');
}
if (!defined('CURRENCY_SYMBOL')) {
    define('CURRENCY_SYMBOL', '₵');
}

// Paystack Configuration (use environment variables in production)
if (!defined('PAYSTACK_PUBLIC_KEY')) {
    if (APP_ENV === 'production') {
        define('PAYSTACK_PUBLIC_KEY', env('PAYSTACK_PUBLIC_KEY', ''));
    } else {
        define('PAYSTACK_PUBLIC_KEY', env('PAYSTACK_PUBLIC_KEY', 'pk_test_xxxxxxxxxxxxx'));
    }
}
if (!defined('PAYSTACK_SECRET_KEY')) {
    if (APP_ENV === 'production') {
        define('PAYSTACK_SECRET_KEY', env('PAYSTACK_SECRET_KEY', ''));
    } else {
        define('PAYSTACK_SECRET_KEY', env('PAYSTACK_SECRET_KEY', 'sk_test_xxxxxxxxxxxxx'));
    }
}
if (!defined('PAYSTACK_CALLBACK_URL')) {
    define('PAYSTACK_CALLBACK_URL', APP_URL . '/payment/callback.php');
}

// Security Configuration
if (!defined('MAX_LOGIN_ATTEMPTS')) {
    define('MAX_LOGIN_ATTEMPTS', 5);
}
if (!defined('LOGIN_LOCKOUT_TIME')) {
    define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes in seconds
}
if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 3600); // 1 hour in seconds
}
if (!defined('DEFAULT_STUDENT_PASSWORD')) {
    define('DEFAULT_STUDENT_PASSWORD', 'Student@123');
}
if (!defined('DEFAULT_TEACHER_PASSWORD')) {
    define('DEFAULT_TEACHER_PASSWORD', 'Teacher@123');
}
if (!defined('PASSWORD_MIN_LENGTH')) {
    define('PASSWORD_MIN_LENGTH', 8);
}

// Timezone
date_default_timezone_set('Africa/Lagos');

// Load Helper Functions
require_once BASE_PATH . '/includes/helper-functions.php';

// Database Connection Class
class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        try {
            $this->connection = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                array(
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"
                )
            );
        } catch(PDOException $e) {
            error_log('Database connection failed: ' . $e->getMessage());
            http_response_code(500);
            if (APP_ENV === 'production') {
                die('Database connection failed.');
            }
            die('Database connection failed: ' . $e->getMessage());
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
}

// Security Functions
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

// CSRF Protection
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

function csrf_field() {
    $token = generate_csrf_token();
    return '<input type="hidden" name="csrf_token" value="' . $token . '">';
}

// Session Security
function init_secure_session() {
    // Start session if not already started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Prevent session fixation
    if (!isset($_SESSION['initiated'])) {
        session_regenerate_id(true);
        $_SESSION['initiated'] = true;
    }
    
    // Check session timeout
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
        session_unset();
        session_destroy();
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        return false;
    }
    $_SESSION['last_activity'] = time();
    
    // Validate session fingerprint
    $fingerprint = md5($_SERVER['HTTP_USER_AGENT'] ?? '');
    if (!isset($_SESSION['fingerprint'])) {
        $_SESSION['fingerprint'] = $fingerprint;
    } elseif ($_SESSION['fingerprint'] !== $fingerprint) {
        session_unset();
        session_destroy();
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        return false;
    }
    
    return true;
}

// Rate Limiting for Login
function check_login_attempts($username) {
    $db = Database::getInstance()->getConnection();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    
    try {
        $db->query("SELECT 1 FROM login_attempts LIMIT 1");
    } catch (PDOException $e) {
        return true;
    }
    
    // Clean old attempts
    $stmt = $db->prepare("DELETE FROM login_attempts WHERE attempt_time < DATE_SUB(NOW(), INTERVAL ? SECOND)");
    $stmt->execute([LOGIN_LOCKOUT_TIME]);
    
    // Check current attempts
    $stmt = $db->prepare("SELECT COUNT(*) as attempts FROM login_attempts WHERE (username = ? OR ip_address = ?) AND attempt_time > DATE_SUB(NOW(), INTERVAL ? SECOND)");
    $stmt->execute([$username, $ip, LOGIN_LOCKOUT_TIME]);
    $result = $stmt->fetch();
    
    return $result['attempts'] < MAX_LOGIN_ATTEMPTS;
}

function log_login_attempt($username, $success = false) {
    $db = Database::getInstance()->getConnection();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    
    try {
        $db->query("SELECT 1 FROM login_attempts LIMIT 1");
    } catch (PDOException $e) {
        return;
    }
    
    if (!$success) {
        $stmt = $db->prepare("INSERT INTO login_attempts (username, ip_address, attempt_time) VALUES (?, ?, NOW())");
        $stmt->execute([$username, $ip]);
    } else {
        // Clear attempts on successful login
        $stmt = $db->prepare("DELETE FROM login_attempts WHERE username = ? OR ip_address = ?");
        $stmt->execute([$username, $ip]);
    }
}

// Password Policy Validation
function validate_password($password) {
    $errors = [];
    
    if (strlen($password) < PASSWORD_MIN_LENGTH) {
        $errors[] = "Password must be at least " . PASSWORD_MIN_LENGTH . " characters long";
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = "Password must contain at least one uppercase letter";
    }
    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = "Password must contain at least one lowercase letter";
    }
    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must contain at least one number";
    }
    if (!preg_match('/[^A-Za-z0-9]/', $password)) {
        $errors[] = "Password must contain at least one special character";
    }
    
    return $errors;
}

function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function get_logged_in_user() {
    if (!is_logged_in()) {
        return null;
    }
    
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

function check_permission($allowed_roles = []) {
    if (!is_logged_in()) {
        redirect(APP_URL . '/login.php');
        exit;
    }
    
    $user = get_logged_in_user();
    
    // Convert single role string to array
    if (is_string($allowed_roles)) {
        $allowed_roles = [$allowed_roles];
    }
    
    if (!empty($allowed_roles) && !in_array($user['role'], $allowed_roles)) {
        $_SESSION['error'] = 'You do not have permission to access this page';
        redirect(APP_URL . '/dashboard.php');
        exit;
    }
    
    return $user;
}

function redirect($url) {
    // Ensure no output has been sent
    if (headers_sent($file, $line)) {
        echo "<script>window.location.href='$url';</script>";
        echo "<noscript><meta http-equiv='refresh' content='0;url=$url'></noscript>";
        exit;
    }
    
    header("Location: " . $url);
    exit;
}

function set_message($type, $message) {
    $_SESSION[$type] = $message;
}

function get_message($type) {
    if (isset($_SESSION[$type])) {
        $message = $_SESSION[$type];
        unset($_SESSION[$type]);
        return $message;
    }
    return null;
}

// Activity Logging
function log_activity($user_id, $action, $table_name = null, $record_id = null) {
    $db = Database::getInstance()->getConnection();
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    
    $stmt = $db->prepare("INSERT INTO activity_logs (user_id, action, table_name, record_id, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $action, $table_name, $record_id, $ip, $user_agent]);
}

// Notification Function
function create_notification($user_id, $title, $message, $type = 'info', $link = null) {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("INSERT INTO notifications (user_id, title, message, type, link) VALUES (?, ?, ?, ?, ?)");
    return $stmt->execute([$user_id, $title, $message, $type, $link]);
}

// Email Notification System
function send_email($to, $subject, $message, $from_name = 'School Management System') {
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: " . $from_name . " <noreply@schoolsystem.com>" . "\r\n";
    
    // Wrap message in HTML template
    $html_message = "
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #2D5BFF, #6C5CE7); color: white; padding: 20px; text-align: center; }
            .content { background: #f8f9fa; padding: 20px; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>" . $from_name . "</h2>
            </div>
            <div class='content'>
                " . $message . "
            </div>
            <div class='footer'>
                <p>This is an automated message. Please do not reply.</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    return mail($to, $subject, $html_message, $headers);
}

function send_welcome_email($user) {
    $subject = "Welcome to School Management System";
    $message = "
        <h3>Welcome, " . htmlspecialchars($user['first_name']) . "!</h3>
        <p>Your account has been created successfully.</p>
        <p><strong>Username:</strong> " . htmlspecialchars($user['username']) . "</p>
        <p><strong>Role:</strong> " . ucfirst(str_replace('_', ' ', $user['role'])) . "</p>
        <p>Please login and change your password immediately.</p>
        <p><a href='" . APP_URL . "' style='background: #2D5BFF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;'>Login Now</a></p>
    ";
    
    return send_email($user['email'], $subject, $message);
}

function send_password_reset_email($user, $reset_token) {
    $subject = "Password Reset Request";
    $reset_link = APP_URL . "/reset-password.php?token=" . $reset_token;
    $message = "
        <h3>Password Reset Request</h3>
        <p>Hello " . htmlspecialchars($user['first_name']) . ",</p>
        <p>We received a request to reset your password. Click the button below to reset it:</p>
        <p><a href='" . $reset_link . "' style='background: #2D5BFF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;'>Reset Password</a></p>
        <p>This link will expire in 1 hour.</p>
        <p>If you didn't request this, please ignore this email.</p>
    ";
    
    return send_email($user['email'], $subject, $message);
}

function send_payment_confirmation_email($user, $payment_details) {
    $subject = "Payment Confirmation";
    $message = "
        <h3>Payment Received</h3>
        <p>Dear " . htmlspecialchars($user['first_name']) . ",</p>
        <p>Your payment has been received successfully.</p>
        <p><strong>Amount:</strong> " . format_currency($payment_details['amount']) . "</p>
        <p><strong>Reference:</strong> " . htmlspecialchars($payment_details['reference']) . "</p>
        <p><strong>Date:</strong> " . date('F j, Y', strtotime($payment_details['date'])) . "</p>
        <p>Thank you for your payment.</p>
    ";
    
    return send_email($user['email'], $subject, $message);
}

// File Upload Handler with Enhanced Security
function upload_file($file, $destination_path, $allowed_types = ['jpg', 'jpeg', 'png', 'gif']) {
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'No file uploaded or upload error'];
    }
    
    // Check file size (max 5MB)
    $max_size = 5 * 1024 * 1024;
    if ($file['size'] > $max_size) {
        return ['success' => false, 'message' => 'File size exceeds 5MB limit'];
    }
    
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    // Validate extension
    if (!in_array($file_extension, $allowed_types)) {
        return ['success' => false, 'message' => 'Invalid file type'];
    }
    
    // Validate MIME type
    $allowed_mimes = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'pdf' => 'application/pdf',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (isset($allowed_mimes[$file_extension]) && $mime_type !== $allowed_mimes[$file_extension]) {
        return ['success' => false, 'message' => 'File content does not match extension'];
    }
    
    $new_filename = uniqid() . '_' . time() . '.' . $file_extension;
    $upload_path = $destination_path . $new_filename;
    
    if (!is_dir($destination_path)) {
        mkdir($destination_path, 0755, true);
    }
    
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        // Set proper permissions
        chmod($upload_path, 0644);
        return ['success' => true, 'filename' => $new_filename];
    }
    
    return ['success' => false, 'message' => 'Failed to move uploaded file'];
}

// Get School Settings
function get_school_setting($school_id, $key) {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("SELECT setting_value FROM settings WHERE school_id = ? AND setting_key = ?");
    $stmt->execute([$school_id, $key]);
    $result = $stmt->fetch();
    return $result ? $result['setting_value'] : null;
}

// Format Currency
function format_currency($amount, $currency = 'GHS') {
    $symbols = [
        'GHS' => '₵',
        'NGN' => '₦',
        'USD' => '$',
        'GBP' => '£',
        'EUR' => '€'
    ];
    
    $symbol = $symbols[$currency] ?? $currency;
    return $symbol . number_format($amount, 2);
}

// Calculate Grade
function calculate_grade($score) {
    if ($score >= 90) return 'A+';
    if ($score >= 80) return 'A';
    if ($score >= 70) return 'B';
    if ($score >= 60) return 'C';
    if ($score >= 50) return 'D';
    if ($score >= 40) return 'E';
    return 'F';
}

// Calculate Total Score: [(CA + Mid-Term) × 0.5] + [Exam × 0.5]
function calculate_total_score($ca_score = 0, $midterm_score = 0, $exam_score = 0) {
    $ca_score = floatval($ca_score) ?? 0;
    $midterm_score = floatval($midterm_score) ?? 0;
    $exam_score = floatval($exam_score) ?? 0;
    
    // Formula: [(CA + Midterm) * 0.5] + [Exam * 0.5]
    $total = (($ca_score + $midterm_score) * 0.5) + ($exam_score * 0.5);
    
    // Ensure it doesn't exceed 100
    return min(round($total, 2), 100);
}

// Calculate Grade and Remark (New System)
function calculate_grade_new($total_score) {
    $total_score = floatval($total_score) ?? 0;
    
    $grades = [
        ['min' => 90, 'grade' => 'A+', 'remark' => 'Excellent'],
        ['min' => 80, 'grade' => 'A', 'remark' => 'Excellent'],
        ['min' => 75, 'grade' => 'B+', 'remark' => 'Very Good'],
        ['min' => 70, 'grade' => 'B', 'remark' => 'Very Good'],
        ['min' => 65, 'grade' => 'C+', 'remark' => 'Good'],
        ['min' => 60, 'grade' => 'C', 'remark' => 'Good'],
        ['min' => 50, 'grade' => 'D', 'remark' => 'Fair'],
        ['min' => 0, 'grade' => 'F', 'remark' => 'Fail']
    ];
    
    foreach ($grades as $grade_info) {
        if ($total_score >= $grade_info['min']) {
            return [
                'grade' => $grade_info['grade'],
                'remark' => $grade_info['remark']
            ];
        }
    }
    
    return ['grade' => 'F', 'remark' => 'Fail'];
}

// Get Dashboard URL by Role
function get_dashboard_url($role) {
    $dashboards = [
        'super_admin' => APP_URL . '/super-admin/dashboard.php',
        'proprietor' => APP_URL . '/proprietor/dashboard.php',
        'admin' => APP_URL . '/admin/dashboard.php',
        'accountant' => APP_URL . '/accountant/dashboard.php',
        'librarian' => APP_URL . '/librarian/dashboard.php',
        'bookstore' => APP_URL . '/bookstore/dashboard.php',
        'teacher' => APP_URL . '/teacher/dashboard.php',
        'student' => APP_URL . '/student/dashboard.php',
        'parent' => APP_URL . '/parent/dashboard.php'
    ];
    
    return $dashboards[$role] ?? APP_URL . '/login.php';
}

// Generate unique admission number
function generate_admission_number($school_id) {
    $db = Database::getInstance()->getConnection();
    
    // Get school code
    $stmt = $db->prepare("SELECT school_code FROM schools WHERE school_id = ?");
    $stmt->execute([$school_id]);
    $school = $stmt->fetch();
    $school_code = $school['school_code'] ?? 'SCH';
    
    // Get current year
    $year = date('Y');
    
    // Get last admission number for this school and year
    $stmt = $db->prepare("
        SELECT admission_number 
        FROM students 
        WHERE school_id = ? AND admission_number LIKE ?
        ORDER BY admission_number DESC 
        LIMIT 1
    ");
    $pattern = strtoupper($school_code) . '/' . $year . '/%';
    $stmt->execute([$school_id, $pattern]);
    $last_student = $stmt->fetch();
    
    if ($last_student && $last_student['admission_number']) {
        // Extract the number part and increment
        preg_match('/(\d+)$/', $last_student['admission_number'], $matches);
        $next_number = isset($matches[1]) ? intval($matches[1]) + 1 : 1;
    } else {
        $next_number = 1;
    }
    
    // Generate admission number
    $admission_number = strtoupper($school_code) . '/' . $year . '/' . str_pad($next_number, 4, '0', STR_PAD_LEFT);
    
    // Double-check uniqueness (in case of race condition)
    $check_stmt = $db->prepare("SELECT COUNT(*) FROM students WHERE admission_number = ?");
    $check_stmt->execute([$admission_number]);
    
    // If exists, try next number
    while ($check_stmt->fetchColumn() > 0) {
        $next_number++;
        $admission_number = strtoupper($school_code) . '/' . $year . '/' . str_pad($next_number, 4, '0', STR_PAD_LEFT);
        $check_stmt->execute([$admission_number]);
    }
    
    return $admission_number;
}

// Pagination Helper
function paginate($query, $page = 1, $per_page = 20) {
    $db = Database::getInstance()->getConnection();
    
    // Get total count
    $count_query = preg_replace('/SELECT .+ FROM/i', 'SELECT COUNT(*) as total FROM', $query, 1);
    $count_query = preg_replace('/ORDER BY .+$/i', '', $count_query);
    $stmt = $db->query($count_query);
    $total = $stmt->fetch()['total'];
    
    // Calculate pagination
    $total_pages = ceil($total / $per_page);
    $page = max(1, min($page, $total_pages));
    $offset = ($page - 1) * $per_page;
    
    // Get paginated results
    $paginated_query = $query . " LIMIT $per_page OFFSET $offset";
    $stmt = $db->query($paginated_query);
    $results = $stmt->fetchAll();
    
    return [
        'data' => $results,
        'current_page' => $page,
        'per_page' => $per_page,
        'total' => $total,
        'total_pages' => $total_pages,
        'has_prev' => $page > 1,
        'has_next' => $page < $total_pages
    ];
}

function render_pagination($pagination, $base_url) {
    if ($pagination['total_pages'] <= 1) return '';
    
    $html = '<div class="pagination">';
    
    // Previous button
    if ($pagination['has_prev']) {
        $prev_page = $pagination['current_page'] - 1;
        $html .= "<a href=\"{$base_url}?page={$prev_page}\" class=\"page-link\"><i class=\"fas fa-chevron-left\"></i></a>";
    }
    
    // Page numbers
    $start = max(1, $pagination['current_page'] - 2);
    $end = min($pagination['total_pages'], $pagination['current_page'] + 2);
    
    if ($start > 1) {
        $html .= "<a href=\"{$base_url}?page=1\" class=\"page-link\">1</a>";
        if ($start > 2) $html .= "<span class=\"page-dots\">...</span>";
    }
    
    for ($i = $start; $i <= $end; $i++) {
        $active = $i == $pagination['current_page'] ? 'active' : '';
        $html .= "<a href=\"{$base_url}?page={$i}\" class=\"page-link {$active}\">{$i}</a>";
    }
    
    if ($end < $pagination['total_pages']) {
        if ($end < $pagination['total_pages'] - 1) $html .= "<span class=\"page-dots\">...</span>";
        $html .= "<a href=\"{$base_url}?page={$pagination['total_pages']}\" class=\"page-link\">{$pagination['total_pages']}</a>";
    }
    
    // Next button
    if ($pagination['has_next']) {
        $next_page = $pagination['current_page'] + 1;
        $html .= "<a href=\"{$base_url}?page={$next_page}\" class=\"page-link\"><i class=\"fas fa-chevron-right\"></i></a>";
    }
    
    $html .= '</div>';
    
    // Add info
    $showing_from = (($pagination['current_page'] - 1) * $pagination['per_page']) + 1;
    $showing_to = min($pagination['current_page'] * $pagination['per_page'], $pagination['total']);
    $html .= "<div class=\"pagination-info\">Showing {$showing_from} to {$showing_to} of {$pagination['total']} entries</div>";
    
    return $html;
}

// Create necessary directories if they don't exist
$directories = [
    UPLOAD_PATH,
    AVATAR_PATH,
    STUDENT_PHOTO_PATH,
    SCHOOL_LOGO_PATH,
    BASE_PATH . '/logs'
];

foreach ($directories as $dir) {
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Initialize secure session for all pages
init_secure_session();

// ============================================================================
// CREDENTIAL EMAIL FUNCTIONS
// ============================================================================

/**
 * Send teacher credentials email with login link
 */
function send_teacher_credentials_email($user_data, $password) {
    try {
        $login_link = APP_URL . '/login.php';
        $subject = "Your School Account Has Been Created";
        $message = "
            <h3>Welcome to School Management System!</h3>
            <p>Dear " . htmlspecialchars($user_data['first_name']) . ",</p>
            <p>Your school account has been successfully created. You can now access the system using the credentials below.</p>
            <hr style='margin: 20px 0;'>
            <p><strong>Login Details:</strong></p>
            <p><strong>Username:</strong> <code>" . htmlspecialchars($user_data['username']) . "</code></p>
            <p><strong>Password:</strong> <code>" . htmlspecialchars($password) . "</code></p>
            <p><strong>Role:</strong> " . ucfirst(str_replace('_', ' ', $user_data['role'])) . "</p>
            <hr style='margin: 20px 0;'>
            <p><a href='" . $login_link . "' style='background: #2D5BFF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;'>Login Now</a></p>
            <p style='color: #999; font-size: 12px; margin-top: 20px;'>Please change your password immediately after your first login. Keep these credentials secure.</p>
        ";
        
        return send_email($user_data['email'], $subject, $message, 'School Administration');
    } catch (Exception $e) {
        error_log('Failed to send teacher credentials email: ' . $e->getMessage());
        return false;
    }
}

/**
 * Send accountant credentials email with login link
 */
function send_accountant_credentials_email($user_data, $password) {
    try {
        $login_link = APP_URL . '/login.php';
        $subject = "Your School Account Has Been Created";
        $message = "
            <h3>Welcome to School Management System!</h3>
            <p>Dear " . htmlspecialchars($user_data['first_name']) . ",</p>
            <p>Your school account has been successfully created. You can now access the system using the credentials below.</p>
            <hr style='margin: 20px 0;'>
            <p><strong>Login Details:</strong></p>
            <p><strong>Username:</strong> <code>" . htmlspecialchars($user_data['username']) . "</code></p>
            <p><strong>Password:</strong> <code>" . htmlspecialchars($password) . "</code></p>
            <p><strong>Role:</strong> Accountant</p>
            <hr style='margin: 20px 0;'>
            <p><a href='" . $login_link . "' style='background: #2D5BFF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;'>Login Now</a></p>
            <p style='color: #999; font-size: 12px; margin-top: 20px;'>Please change your password immediately after your first login. Keep these credentials secure.</p>
        ";
        
        return send_email($user_data['email'], $subject, $message, 'School Administration');
    } catch (Exception $e) {
        error_log('Failed to send accountant credentials email: ' . $e->getMessage());
        return false;
    }
}

/**
 * Send parent credentials email with login link
 */
function send_parent_credentials_email($user_data, $password) {
    try {
        $login_link = APP_URL . '/login.php';
        $subject = "Your School Account Has Been Created";
        $message = "
            <h3>Welcome to School Management System!</h3>
            <p>Dear " . htmlspecialchars($user_data['first_name']) . ",</p>
            <p>Your school account has been successfully created. You can now access the system to view your child's academic progress and other information.</p>
            <hr style='margin: 20px 0;'>
            <p><strong>Login Details:</strong></p>
            <p><strong>Username:</strong> <code>" . htmlspecialchars($user_data['username']) . "</code></p>
            <p><strong>Password:</strong> <code>" . htmlspecialchars($password) . "</code></p>
            <hr style='margin: 20px 0;'>
            <p><a href='" . $login_link . "' style='background: #2D5BFF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;'>Login Now</a></p>
            <p style='color: #999; font-size: 12px; margin-top: 20px;'>Please change your password immediately after your first login. Keep these credentials secure.</p>
        ";
        
        return send_email($user_data['email'], $subject, $message, 'School Administration');
    } catch (Exception $e) {
        error_log('Failed to send parent credentials email: ' . $e->getMessage());
        return false;
    }
}

// ============================================================================
// LOAD ENHANCEMENT CLASSES FOR PHASE 1 & 2
// ============================================================================

// SMS Gateway - for attendance and fee reminders
require_once BASE_PATH . '/includes/SMSGateway.php';

// Audit Logger - for tracking all user actions
require_once BASE_PATH . '/includes/AuditLogger.php';

// Two-Factor Authentication
require_once BASE_PATH . '/includes/TwoFactorAuth.php';

// Payment Plans - for installment payments
require_once BASE_PATH . '/includes/PaymentPlans.php';

// Student Discipline Management
require_once BASE_PATH . '/includes/DisciplineManager.php';

// Communication Manager - for announcements and messaging
require_once BASE_PATH . '/includes/CommunicationManager.php';
// INITIALIZE ENHANCEMENT FEATURES
// ============================================================================

// Initialize Audit Logger for current request
if (isset($_SESSION['user']['school_id']) && isset($_SESSION['user']['user_id'])) {
    $GLOBALS['audit_logger'] = new AuditLogger(
        Database::getInstance()->getConnection(),
        $_SESSION['user']['school_id'],
        $_SESSION['user']['user_id']
    );
}

// Log page visit if audit logging enabled
if (isset($GLOBALS['audit_logger']) && $_SERVER['REQUEST_METHOD'] !== 'OPTIONS') {
    $page = $_SERVER['REQUEST_URI'] ?? 'unknown';
    // Only log actual page requests, not static assets
    if (!preg_match('/\.(js|css|jpg|jpeg|png|gif|ico|svg|woff|woff2|ttf|eot)$/i', $page)) {
        $GLOBALS['audit_logger']->log(
            "Accessed page: {$page}",
            'page_views',
            null,
            null,
            ['url' => $page, 'method' => $_SERVER['REQUEST_METHOD']],
            true
        );
    }
}
