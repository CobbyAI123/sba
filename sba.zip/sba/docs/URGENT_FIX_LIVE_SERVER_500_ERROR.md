# 🚨 URGENT: Live Server 500 Error Fix
## SBA School System - Immediate Action Required

**Issue:** ModSecurity blocking requests + 500 Internal Server Error on login.php

**Time to Fix:** 10-15 minutes

---

## 🔍 STEP 1: DIAGNOSE THE PROBLEM (5 minutes)

### Upload Diagnostic Script:
1. Go to cPanel → **File Manager**
2. Upload: `diagnose_500_error.php` to your root directory
3. Visit: **https://sba.uniquehavenangelschool.com/diagnose_500_error.php**
4. Read the diagnostic report
5. **DELETE the file after viewing**

This will show you:
- ✓ PHP version and extensions
- ✓ Database connection status
- ✓ File permissions
- ✓ Error logs
- ✓ What's actually causing the 500 error

---

## 🔧 STEP 2: FIX MODSECURITY ISSUE (5 minutes)

### Replace .htaccess with Enhanced Version:

1. **Backup current .htaccess:**
   - Download current `.htaccess` from cPanel
   - Save as `.htaccess.backup`

2. **Upload new .htaccess:**
   - Upload: `LIVE_SERVER_MODSECURITY_FIX.htaccess`
   - Rename it to: `.htaccess`
   - Replace existing file

### What This Fixes:
- ✓ ModSecurity rule 920274 (Chrome headers)
- ✓ ModSecurity rule 950100 (500 status code warning)
- ✓ Whitelists all Chrome security headers (sec-ch-ua-*)
- ✓ Enables HTTPS redirect
- ✓ Optimized security settings

---

## 💾 STEP 3: CHECK DATABASE (3 minutes)

### Verify Database Setup:

1. **Login to phpMyAdmin**
2. **Select your database:** `uniqueha_msmsdb`
3. **Check tables exist:** Should see 40+ tables
4. **If no tables:**
   - Click **Import**
   - Upload: `database/LIVE_SERVER_COMPLETE_SCHEMA.sql`
   - Click **Go**

---

## ⚙️ STEP 4: VERIFY .ENV CONFIGURATION (2 minutes)

### Check .env file exists and has correct values:

```env
# CRITICAL SETTINGS
APP_ENV=production
APP_URL=https://sba.uniquehavenangelschool.com

# DATABASE (must match your cPanel database)
DB_HOST=localhost
DB_USER=uniqueha_msms
DB_PASS=[your_actual_password]
DB_NAME=uniqueha_msmsdb

# PAYSTACK (use LIVE keys)
PAYSTACK_PUBLIC_KEY=pk_live_xxxxxxxxxxxxx
PAYSTACK_SECRET_KEY=sk_live_xxxxxxxxxxxxx

# ERROR SETTINGS (for production)
DEBUG=false
DISPLAY_ERRORS=false
LOG_ERRORS=true
```

---

## 🔐 STEP 5: CHECK FILE PERMISSIONS (2 minutes)

### Set correct permissions in File Manager:

```
uploads/         → 755
uploads/avatars/ → 755
uploads/students/→ 755
uploads/logos/   → 755
logs/            → 755
cache/           → 755
.env             → 644
.htaccess        → 644
config.php       → 644
```

**How to set permissions:**
1. Right-click folder/file
2. Select **Change Permissions**
3. Enter the number (755 or 644)
4. Click **Change Permissions**

---

## 🧪 STEP 6: TEST THE FIXES

### After applying fixes:

1. **Clear browser cache:** Ctrl+Shift+Delete
2. **Visit:** https://sba.uniquehavenangelschool.com
3. **Should redirect to:** https://sba.uniquehavenangelschool.com/login.php
4. **Login with:** superadmin / password
5. **Should load:** Dashboard without errors

---

## 📊 COMMON 500 ERROR CAUSES & SOLUTIONS

### Cause 1: Database Not Connected
**Symptoms:** Can't connect to database
**Solution:** 
- Check .env has correct DB_USER, DB_PASS, DB_NAME
- Verify database exists in phpMyAdmin
- Ensure user has ALL PRIVILEGES

### Cause 2: Missing Database Tables
**Symptoms:** Table doesn't exist errors
**Solution:**
- Import database/LIVE_SERVER_COMPLETE_SCHEMA.sql

### Cause 3: Syntax Error in PHP Files
**Symptoms:** Parse error or syntax error
**Solution:**
- Check logs/error.log for details
- Re-upload files if corrupted

### Cause 4: Memory Limit Exceeded
**Symptoms:** Out of memory error
**Solution:**
- Create php.ini with: memory_limit = 256M
- Or use .user.ini: memory_limit = 256M

### Cause 5: Wrong PHP Version
**Symptoms:** Function not found errors
**Solution:**
- Change PHP version in cPanel to 7.4 or 8.0+
- MultiPHP Manager → Select domain → PHP 7.4+

### Cause 6: .htaccess Syntax Error
**Symptoms:** 500 error on all pages
**Solution:**
- Temporarily rename .htaccess to .htaccess.old
- If site works, fix .htaccess syntax
- Use LIVE_SERVER_MODSECURITY_FIX.htaccess

---

## 🔍 HOW TO READ ERROR LOGS

### Via cPanel:
1. File Manager → `logs/error.log`
2. Right-click → View
3. Look for recent errors (today's date)

### Via SSH (if available):
```bash
tail -f logs/error.log
```

### Common Error Messages:

**"Call to undefined function"**
→ Missing PHP extension, enable in cPanel MultiPHP

**"No such file or directory"**
→ File path wrong, check config.php paths

**"Access denied for user"**
→ Database credentials wrong in .env

**"Table doesn't exist"**
→ Database not imported, use phpMyAdmin

---

## 🆘 IF STILL NOT WORKING

### Check These in Order:

1. **ModSecurity Still Blocking?**
   - Contact hosting support
   - Ask them to disable ModSecurity for your domain
   - Or whitelist your application

2. **PHP Version Wrong?**
   - cPanel → MultiPHP Manager
   - Select PHP 7.4 or 8.0+

3. **Wrong Document Root?**
   - Files should be in: public_html/
   - Or: public_html/sba/
   - Update ErrorDocument paths in .htaccess

4. **Hosting Restrictions?**
   - Some hosts block exec(), shell_exec()
   - Check with hosting support

---

## 📞 CONTACT HOSTING SUPPORT

### Information to Provide:

```
Subject: 500 Error and ModSecurity False Positives

Body:
I'm getting 500 errors on my domain: sba.uniquehavenangelschool.com

Issues:
1. ModSecurity rule 920274 blocking Chrome security headers
2. 500 Internal Server Error on login.php

Request:
- Disable ModSecurity for my domain, OR
- Whitelist these headers: sec-ch-ua-mobile, sec-ch-ua, sec-ch-ua-platform
- Check error logs: /home/username/logs/error_log

Error details:
[Paste the error from Apache error log]

Thank you!
```

---

## ✅ QUICK CHECKLIST

After fixing, verify:

```
□ Diagnostic script shows all green checkmarks
□ Database connected (40+ tables visible)
□ .htaccess uploaded (enhanced version)
□ .env configured with production settings
□ Permissions set correctly (755/644)
□ Can access login page without 500 error
□ Can login successfully
□ Dashboard loads
□ No ModSecurity warnings in Apache logs
□ HTTPS redirect working
```

---

## 🎯 SUCCESS INDICATORS

You'll know it's fixed when:

✓ Login page loads instantly (no 500 error)
✓ No ModSecurity warnings in Apache error log
✓ Can login and see dashboard
✓ All CSS/JS files loading
✓ HTTPS redirect working
✓ Browser console (F12) shows no errors

---

## 📁 FILES YOU NEED

All files are in: `c:\xampp\htdocs\sba\`

1. **diagnose_500_error.php** - Upload this first to diagnose
2. **LIVE_SERVER_MODSECURITY_FIX.htaccess** - Replace .htaccess with this
3. **database/LIVE_SERVER_COMPLETE_SCHEMA.sql** - Import if tables missing

---

## 🚀 EXPECTED RESULT

After fixes:
- ✅ Site loads at: https://sba.uniquehavenangelschool.com
- ✅ Redirects to login page
- ✅ Login works without errors
- ✅ Dashboard displays correctly
- ✅ No 500 errors in logs
- ✅ No ModSecurity warnings

---

**Time Required:** 10-15 minutes
**Difficulty:** Easy (follow steps)

**START WITH:** Upload diagnose_500_error.php and check what's actually wrong!

---

*Created: January 8, 2026*
*For: sba.uniquehavenangelschool.com*
*Issue: ModSecurity + 500 Error on Live Server*
