# 🔧 Fix Terms Table Error

## ⚠️ Error: Unknown column 'school_id' in 'field list'

The `terms` table was created without the `school_id` column. Here's how to fix it:

---

## ✅ **SOLUTION (Run This SQL):**

### **Option 1: Add Missing Column (Recommended)**

Copy and paste this in phpMyAdmin SQL tab:

```sql
-- Add school_id column to terms table
ALTER TABLE `terms` 
ADD COLUMN `school_id` int(11) NOT NULL AFTER `term_id`;

-- Add index for better performance
ALTER TABLE `terms` 
ADD INDEX `school_id` (`school_id`);

-- Now insert sample terms
INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) VALUES
(1, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1),
(1, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0),
(1, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0);
```

---

### **Option 2: Drop and Recreate Table (If Option 1 Fails)**

If the above doesn't work, drop and recreate the table:

```sql
-- Drop existing terms table
DROP TABLE IF EXISTS `terms`;

-- Create terms table with all columns
CREATE TABLE `terms` (
  `term_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `term_name` varchar(100) NOT NULL,
  `session_year` varchar(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`term_id`),
  KEY `school_id` (`school_id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample terms
INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) VALUES
(1, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1),
(1, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0),
(1, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0);
```

---

## 🎯 **Step-by-Step:**

### **Step 1: Open phpMyAdmin**
- Go to: `http://localhost/phpmyadmin`
- Select database: `school_management_system`

### **Step 2: Click SQL Tab**
- Click the **SQL** tab at the top

### **Step 3: Copy & Paste**
- Copy **Option 1** SQL above
- Paste in the SQL box
- Click **Go**

### **Step 4: Check for Success**
- Should see: "3 rows inserted" ✅
- No errors!

---

## 🔍 **Why This Happened:**

The `terms` table was created from an old SQL script that didn't include the `school_id` column. The fix adds this column so the table matches what the code expects.

---

## ✅ **After Running Fix:**

### **Verify Terms Table:**
```sql
DESCRIBE terms;
```

Should show these columns:
- ✅ term_id
- ✅ school_id ← Should be here now!
- ✅ term_name
- ✅ session_year
- ✅ start_date
- ✅ end_date
- ✅ is_active
- ✅ created_at
- ✅ updated_at

### **Check Sample Data:**
```sql
SELECT * FROM terms;
```

Should show 3 terms:
- ✅ First Term (2024/2025) - Active
- ✅ Second Term (2024/2025)
- ✅ Third Term (2024/2025)

---

## 🧪 **Test Pages:**

After fixing, test these pages:

1. **Academic Terms:**
   - Go to: `http://localhost/msms/admin/terms.php`
   - Should show 3 terms ✅

2. **Report Cards:**
   - Go to: `http://localhost/msms/admin/report-cards.php`
   - Term dropdown should work ✅

3. **Marks:**
   - Go to: `http://localhost/msms/admin/marks.php`
   - Should work ✅

---

## 🚨 **If Still Getting Errors:**

### **Check MySQL Version:**
If `ADD COLUMN IF NOT EXISTS` doesn't work, your MySQL version might be old.

Use **Option 2** instead (Drop and Recreate).

### **Check Permissions:**
Make sure your MySQL user has ALTER TABLE permissions.

### **Check Database Selected:**
Make sure `school_management_system` is selected in phpMyAdmin.

---

## 📋 **Complete Fix (All Tables):**

If you want to ensure ALL tables are correct, run this complete script:

```sql
-- Parent-Student table
CREATE TABLE IF NOT EXISTS `parent_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `relationship` varchar(50) DEFAULT 'Parent',
  `is_primary` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Drop and recreate terms table
DROP TABLE IF EXISTS `terms`;
CREATE TABLE `terms` (
  `term_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `term_name` varchar(100) NOT NULL,
  `session_year` varchar(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`term_id`),
  KEY `school_id` (`school_id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample terms
INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) VALUES
(1, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1),
(1, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0),
(1, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0);

-- Notifications table
CREATE TABLE IF NOT EXISTS `notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','error') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notification_id`),
  KEY `user_id` (`user_id`),
  KEY `is_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Transport routes table
CREATE TABLE IF NOT EXISTS `transport_routes` (
  `route_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `route_name` varchar(100) NOT NULL,
  `vehicle_number` varchar(50) DEFAULT NULL,
  `driver_name` varchar(100) DEFAULT NULL,
  `driver_phone` varchar(20) DEFAULT NULL,
  `fare` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`route_id`),
  KEY `school_id` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

---

## ✅ **Summary:**

**Problem:** Terms table missing `school_id` column  
**Solution:** Add the column using ALTER TABLE  
**Alternative:** Drop and recreate the table  
**Result:** All pages work! ✅  

---

**Run Option 1 or Option 2 above and the error will be fixed!** 🎉
