# Bug Fix: Constant Already Defined Warning

**Date:** December 26, 2025  
**Status:** ✅ FIXED

---

## Issue: PHP Warning on Production Server ❌

### **Error Message:**
```
Warning: Constant CURRENCY_SYMBOL already defined in 
/home/uniqueha/msms.uniquehavenangelschool.com/config.php on line 41
```

### **Location:**
- `config.php` - Lines 10, 22-25, 29-36, 39-41, 44-46, 49-54

### **Root Cause:**
The `config.php` file is being included multiple times in some pages, causing constants to be redefined. PHP throws a warning when you try to define a constant that already exists.

**Why This Happens:**
1. Some pages include `config.php` directly
2. Other files they include also include `config.php`
3. Result: `config.php` loads twice → Constants defined twice → Warning

**Example Scenario:**
```
page.php includes config.php
    ↓
page.php includes header.php
    ↓
header.php includes config.php
    ↓
ERROR: Constants already defined!
```

---

## Solution: Add Constant Checks ✅

### **The Fix:**
Wrapped ALL `define()` statements with `if (!defined())` checks to prevent redefinition.

**Before (CAUSES WARNING):**
```php
define('CURRENCY_SYMBOL', '₵');
define('APP_URL', 'http://localhost/sba');
define('DB_HOST', 'localhost');
```

**After (SAFE):**
```php
if (!defined('CURRENCY_SYMBOL')) {
    define('CURRENCY_SYMBOL', '₵');
}
if (!defined('APP_URL')) {
    define('APP_URL', 'http://localhost/sba');
}
if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost');
}
```

### **What This Does:**
1. ✅ Checks if constant already exists before defining
2. ✅ If exists → Skip definition (no error)
3. ✅ If doesn't exist → Define it normally
4. ✅ Safe to include `config.php` multiple times

---

## Constants Protected:

### **1. Environment Configuration**
```php
if (!defined('APP_ENV')) {
    define('APP_ENV', getenv('APP_ENV') ?: 'development');
}
```

### **2. Database Configuration**
```php
if (!defined('DB_HOST')) {
    define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
}
if (!defined('DB_USER')) {
    define('DB_USER', getenv('DB_USER') ?: 'root');
}
if (!defined('DB_PASS')) {
    define('DB_PASS', getenv('DB_PASS') ?: '');
}
if (!defined('DB_NAME')) {
    define('DB_NAME', getenv('DB_NAME') ?: 'sba');
}
```

### **3. Application URL**
```php
if (!defined('APP_URL')) {
    define('APP_URL', 'http://localhost/sba');
}
```

### **4. Upload Directories**
```php
if (!defined('UPLOAD_PATH')) {
    define('UPLOAD_PATH', BASE_PATH . '/uploads/');
}
if (!defined('AVATAR_PATH')) {
    define('AVATAR_PATH', UPLOAD_PATH . 'avatars/');
}
if (!defined('STUDENT_PHOTO_PATH')) {
    define('STUDENT_PHOTO_PATH', UPLOAD_PATH . 'students/');
}
if (!defined('SCHOOL_LOGO_PATH')) {
    define('SCHOOL_LOGO_PATH', UPLOAD_PATH . 'logos/');
}
```

### **5. Currency Configuration** ⭐ (The Main Issue)
```php
if (!defined('CURRENCY_CODE')) {
    define('CURRENCY_CODE', 'GHS');
}
if (!defined('CURRENCY_SYMBOL')) {
    define('CURRENCY_SYMBOL', '₵');
}
```

### **6. Paystack Configuration**
```php
if (!defined('PAYSTACK_PUBLIC_KEY')) {
    define('PAYSTACK_PUBLIC_KEY', getenv('PAYSTACK_PUBLIC_KEY') ?: 'pk_test_xxxxxxxxxxxxx');
}
if (!defined('PAYSTACK_SECRET_KEY')) {
    define('PAYSTACK_SECRET_KEY', getenv('PAYSTACK_SECRET_KEY') ?: 'sk_test_xxxxxxxxxxxxx');
}
if (!defined('PAYSTACK_CALLBACK_URL')) {
    define('PAYSTACK_CALLBACK_URL', APP_URL . '/payment/callback.php');
}
```

### **7. Security Configuration**
```php
if (!defined('MAX_LOGIN_ATTEMPTS')) {
    define('MAX_LOGIN_ATTEMPTS', 5);
}
if (!defined('LOGIN_LOCKOUT_TIME')) {
    define('LOGIN_LOCKOUT_TIME', 900);
}
if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 3600);
}
if (!defined('DEFAULT_STUDENT_PASSWORD')) {
    define('DEFAULT_STUDENT_PASSWORD', 'Student@123');
}
if (!defined('DEFAULT_TEACHER_PASSWORD')) {
    define('DEFAULT_TEACHER_PASSWORD', 'Teacher@123');
}
if (!defined('PASSWORD_MIN_LENGTH')) {
    define('PASSWORD_MIN_LENGTH', 8);
}
```

---

## Files Modified:

| File | Lines Changed | Fix Applied |
|------|---------------|-------------|
| `config.php` | 10-54 | Added `if (!defined())` checks to all constants |

**Total Changes:**
- ✅ +63 lines added (protective checks)
- ✅ -21 lines removed (direct defines)
- ✅ **Net: +42 lines**

---

## Benefits of This Fix:

1. ✅ **No More Warnings**: Eliminates "Constant already defined" warnings
2. ✅ **Production Ready**: Safe for production servers with strict error reporting
3. ✅ **Multiple Includes**: `config.php` can be safely included multiple times
4. ✅ **Best Practice**: Follows PHP best practices for constant definition
5. ✅ **Future Proof**: Prevents similar issues with new constants
6. ✅ **Clean Logs**: No more warning messages cluttering error logs

---

## Testing Instructions:

### **1. Test Locally:**
```
1. Clear all cache
2. Navigate to any page in the system
3. Check for warnings in error logs
4. Expected: No "Constant already defined" warnings
```

### **2. Test on Production:**
```
1. Upload fixed config.php to server
2. Replace existing file
3. Clear server cache/restart PHP-FPM if needed
4. Visit the website
5. Check error logs: /home/uniqueha/msms.uniquehavenangelschool.com/logs/
6. Expected: Warning should be gone
```

### **3. Verify Constants Work:**
```php
// Test in any page
echo CURRENCY_SYMBOL; // Should output: ₵
echo CURRENCY_CODE;   // Should output: GHS
echo APP_URL;         // Should output: your site URL
```

---

## Production Deployment Steps:

### **Step 1: Backup Current File**
```bash
cd /home/uniqueha/msms.uniquehavenangelschool.com/
cp config.php config.php.backup
```

### **Step 2: Upload Fixed File**
Use FTP/SFTP or file manager to upload the new `config.php`

### **Step 3: Verify Permissions**
```bash
chmod 644 config.php
chown uniqueha:uniqueha config.php
```

### **Step 4: Clear PHP Cache** (if using OpCache)
```bash
# Option 1: Restart PHP-FPM
sudo systemctl restart php-fpm

# Option 2: Or just reload
sudo systemctl reload php-fpm

# Option 3: Or via cPanel, restart PHP
```

### **Step 5: Test**
```
Visit: https://msms.uniquehavenangelschool.com
Check: No warnings displayed
Verify: All pages load correctly
```

---

## Error Log Verification:

**Before Fix:**
```
[26-Dec-2025 10:30:45 UTC] PHP Warning: Constant CURRENCY_SYMBOL already defined in 
/home/uniqueha/msms.uniquehavenangelschool.com/config.php on line 41

[26-Dec-2025 10:30:45 UTC] PHP Warning: Constant APP_URL already defined in 
/home/uniqueha/msms.uniquehavenangelschool.com/config.php on line 29

[Multiple similar warnings...]
```

**After Fix:**
```
[No warnings related to constants]
✅ Clean error log
```

---

## Additional Recommendations:

### **1. Configure Production APP_URL**
Update line 29-31 in `config.php` after upload:
```php
if (!defined('APP_URL')) {
    define('APP_URL', 'https://msms.uniquehavenangelschool.com');
}
```

### **2. Set Environment to Production**
Update line 10-12:
```php
if (!defined('APP_ENV')) {
    define('APP_ENV', 'production'); // Change from 'development'
}
```

### **3. Configure Database Credentials**
Update lines 22-31 with your production database:
```php
if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost'); // Your DB host
}
if (!defined('DB_USER')) {
    define('DB_USER', 'uniqueha_msms_user'); // Your DB user
}
if (!defined('DB_PASS')) {
    define('DB_PASS', 'your_secure_password'); // Your DB password
}
if (!defined('DB_NAME')) {
    define('DB_NAME', 'uniqueha_msms_db'); // Your DB name
}
```

### **4. Hide Errors in Production**
The config already has this, but verify lines 12-18:
```php
if (APP_ENV === 'production') {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);  // Don't show errors to users
    ini_set('log_errors', 1);       // Log errors instead
    ini_set('error_log', BASE_PATH . '/logs/error.log');
}
```

### **5. Set Proper Timezone**
Update line 58 if needed:
```php
date_default_timezone_set('Africa/Accra'); // Ghana timezone
```

---

## Common Issues & Solutions:

### **Issue 1: Warning Still Appears**

**Solution:**
```bash
# Clear PHP OpCache
php -r "if (function_exists('opcache_reset')) opcache_reset();"

# Or restart PHP
sudo systemctl restart php-fpm

# Or via cPanel: Software > Select PHP Version > Restart
```

### **Issue 2: Constants Not Working**

**Solution:**
```php
// Check if constants are defined
var_dump(defined('CURRENCY_SYMBOL')); // Should be true
echo CURRENCY_SYMBOL; // Should output ₵
```

### **Issue 3: Permission Denied**

**Solution:**
```bash
# Fix file permissions
chmod 644 config.php

# Fix ownership
chown uniqueha:uniqueha config.php
```

---

## Technical Details:

### **How `defined()` Works:**
```php
// defined() checks if a constant exists
if (!defined('MY_CONSTANT')) {
    // If it doesn't exist, define it
    define('MY_CONSTANT', 'value');
}
// If it already exists, skip (no error)
```

### **Why This is Better:**
```php
// OLD WAY (causes warnings):
define('CURRENCY_SYMBOL', '₵');
define('CURRENCY_SYMBOL', '₵'); // WARNING!

// NEW WAY (safe):
if (!defined('CURRENCY_SYMBOL')) {
    define('CURRENCY_SYMBOL', '₵');
}
if (!defined('CURRENCY_SYMBOL')) {
    define('CURRENCY_SYMBOL', '₵'); // Skipped, no warning
}
```

---

## Summary:

✅ **Fixed:** All constant definitions now check for existence first  
✅ **Safe:** `config.php` can be included multiple times without errors  
✅ **Production Ready:** No more warnings on production server  
✅ **Best Practice:** Follows PHP coding standards  
✅ **Future Proof:** New constants should follow same pattern  

---

**Upload the fixed `config.php` to your production server and the warning will disappear! ✅**
