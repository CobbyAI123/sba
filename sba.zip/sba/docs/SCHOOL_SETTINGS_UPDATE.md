# 🏫 School Settings Management

## Overview
Added comprehensive school settings page for admins to modify school details and upload school logos.

---

## ✨ Features Added

### **1. School Settings Page** ✅ NEW!
**File:** `admin/school-settings.php`

**Features:**
- ✅ Update school name
- ✅ Update school code
- ✅ Update contact information (phone, email, website)
- ✅ Update address
- ✅ Update school motto
- ✅ Update established date
- ✅ Add/update principal name
- ✅ **Upload/change school logo** 🎨
- ✅ Logo preview before upload
- ✅ Current logo display
- ✅ Professional UI with info cards
- ✅ Activity logging

---

## 🎨 Logo Upload Features

### **Upload Capabilities:**
- ✅ Upload new logo
- ✅ Replace existing logo
- ✅ Preview before saving
- ✅ Automatic old logo deletion
- ✅ File validation (JPG, PNG, GIF)
- ✅ Size limit (5MB max)
- ✅ Secure file naming

### **Supported Formats:**
- JPG/JPEG
- PNG
- GIF

### **Logo Storage:**
- Location: `uploads/logos/`
- Naming: `school_[id]_[timestamp].[ext]`
- Example: `school_1_1699012345.png`

---

## 📊 School Information Managed

### **Basic Information:**
- School Name
- School Code
- Phone Number
- Email Address
- Website URL
- Established Date

### **Additional Details:**
- Full Address
- School Motto
- Principal/Headmaster Name

### **Branding:**
- School Logo (image upload)

---

## 🗄️ Database Updates

### **New Columns Added:**
**File:** `database/update_schools_table.sql`

```sql
-- Add website column
ALTER TABLE schools 
ADD COLUMN IF NOT EXISTS website VARCHAR(255);

-- Add principal_name column
ALTER TABLE schools 
ADD COLUMN IF NOT EXISTS principal_name VARCHAR(200);
```

---

## 🎯 How to Use

### **Access School Settings:**
1. Login as Admin
2. Go to navigation menu
3. Click "School Settings"
4. Update information
5. Upload logo (optional)
6. Click "Save Changes"
7. ✅ Settings updated!

---

### **Upload School Logo:**
1. Go to School Settings
2. Scroll to "School Logo" section
3. Click upload area
4. Select image file
5. Preview appears
6. Click "Save Changes"
7. ✅ Logo uploaded!

---

## 📱 UI Features

### **Info Cards:**
```
┌──────────┬──────────┬──────────┐
│ ABC123   │   2020   │  Active  │
│School Code│Established│ Status  │
└──────────┴──────────┴──────────┘
```

### **Logo Upload Area:**
```
┌─────────────────────────────────┐
│         📤                      │
│  Click to upload new logo       │
│  JPG, PNG or GIF (Max 5MB)     │
└─────────────────────────────────┘
```

### **Current Logo Display:**
```
┌─────────────────────────────────┐
│      Current Logo:              │
│   [School Logo Image]           │
└─────────────────────────────────┘
```

---

## 🔐 Security Features

### **File Upload Security:**
- ✅ File type validation
- ✅ File size limit (5MB)
- ✅ Secure file naming
- ✅ Old file cleanup
- ✅ Directory permissions check

### **Data Validation:**
- ✅ Required field validation
- ✅ Email format validation
- ✅ URL format validation
- ✅ SQL injection prevention
- ✅ XSS protection

---

## 🧪 Testing Guide

### **Test 1: Update School Info**
1. Login as admin
2. Go to "School Settings"
3. Update school name
4. Update phone and email
5. Add motto
6. Click "Save Changes"
7. **Expected:** Success message, data updated

---

### **Test 2: Upload Logo**
1. Go to "School Settings"
2. Click upload area
3. Select image file (PNG/JPG)
4. See preview
5. Click "Save Changes"
6. **Expected:** Logo uploaded and displayed

---

### **Test 3: Replace Logo**
1. Go to "School Settings"
2. See current logo
3. Upload new logo
4. Click "Save Changes"
5. **Expected:** Old logo replaced, new logo shown

---

### **Test 4: Validation**
1. Try uploading 10MB file
2. **Expected:** Error - file too large
3. Try uploading .exe file
4. **Expected:** Error - invalid format

---

## 📁 Files Created

1. ✅ `admin/school-settings.php` - 400+ lines
2. ✅ `database/update_schools_table.sql` - Schema update

---

## 🎨 UI Components

### **Page Sections:**
1. **Header Banner** - Gradient with title
2. **Info Cards** - Quick stats (code, established, status)
3. **Logo Section** - Current logo + upload area
4. **Basic Information** - Name, code, contact
5. **Additional Details** - Address, motto, principal
6. **Save Button** - Submit changes

### **Design Features:**
- Professional gradient header
- Color-coded info cards
- Drag-and-drop upload area
- Live logo preview
- Responsive grid layout
- Clean form design

---

## 💡 Key Benefits

### **For Admins:**
- ✅ Easy school info updates
- ✅ Simple logo management
- ✅ No technical knowledge needed
- ✅ Visual feedback
- ✅ All settings in one place

### **For Schools:**
- ✅ Professional branding
- ✅ Up-to-date information
- ✅ Custom logo display
- ✅ Complete school profile

---

## 🔄 Logo Usage

### **Where Logo Appears:**
- Login page
- Dashboard header
- Reports and documents
- Student ID cards
- Certificates
- Email templates
- Public pages

---

## 📊 Database Schema

### **schools Table (Updated):**
```sql
CREATE TABLE schools (
    school_id INT PRIMARY KEY AUTO_INCREMENT,
    school_name VARCHAR(200) NOT NULL,
    school_code VARCHAR(50) UNIQUE NOT NULL,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    website VARCHAR(255),           -- NEW
    logo VARCHAR(255),
    motto VARCHAR(255),
    principal_name VARCHAR(200),    -- NEW
    established_date DATE,
    status ENUM('active', 'inactive'),
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);
```

---

## 🚀 Setup Instructions

### **Step 1: Update Database**
1. Open phpMyAdmin
2. Select database
3. Import `database/update_schools_table.sql`
4. ✅ Columns added!

### **Step 2: Access Settings**
1. Login as admin
2. Navigate to "School Settings"
3. Update information
4. Upload logo
5. Save changes

### **Step 3: Verify**
1. Check logo displays on dashboard
2. Verify all fields saved
3. Test logo upload/replace
4. ✅ All working!

---

## 📝 Configuration

### **Upload Settings:**
```php
// In config.php
define('SCHOOL_LOGO_PATH', UPLOAD_PATH . 'logos/');

// Max file size: 5MB
// Allowed formats: JPG, PNG, GIF
```

### **Create Upload Directory:**
```bash
mkdir uploads/logos
chmod 755 uploads/logos
```

---

## 🆘 Troubleshooting

### **Problem: Can't upload logo**
**Solution:**
- Check `uploads/logos/` folder exists
- Verify folder permissions (755)
- Check file size < 5MB
- Ensure valid format (JPG/PNG/GIF)

### **Problem: Logo not displaying**
**Solution:**
- Check file uploaded successfully
- Verify path in database
- Check APP_URL in config.php
- Clear browser cache

### **Problem: Old logo not deleted**
**Solution:**
- Check file permissions
- Verify old logo path correct
- Manual deletion if needed

---

## ✅ Summary

**Features Added:** 1 major page
**Files Created:** 2
**Database Updates:** 2 columns
**Lines of Code:** 400+

**Capabilities:**
- ✅ Complete school info management
- ✅ Logo upload and replacement
- ✅ Live preview
- ✅ Secure file handling
- ✅ Professional UI

---

## 🎯 Additional Notes

### **Room Number:**
- Already exists in timetable table ✅
- Column: `room_number VARCHAR(50)`
- Can be used when creating timetables
- No changes needed

### **Timetable Table:**
```sql
CREATE TABLE timetable (
    ...
    room_number VARCHAR(50),  -- Already exists!
    ...
);
```

---

**Status:** ✅ Complete and Working!  
**Version:** 2.0.0  
**Priority:** High  
**Impact:** All Admins  

---

**Admins can now fully manage school settings and upload logos!** 🏫✨

**Room number field already exists in timetable table!** 📅✅
