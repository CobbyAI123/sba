# 🔧 Fix Terms Table - Add Missing Columns

## ⚠️ Error: Unknown column 'session_year' in 'field list'

The `terms` table is missing some columns. Let's add them.

---

## ✅ **COMPLETE FIX (Run This):**

Copy and paste this ENTIRE script in phpMyAdmin SQL tab:

```sql
-- Add missing columns to terms table
ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `term_name` varchar(100) NOT NULL AFTER `school_id`;

ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `session_year` varchar(20) NOT NULL AFTER `term_name`;

ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `start_date` date NOT NULL AFTER `session_year`;

ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `end_date` date NOT NULL AFTER `start_date`;

ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `is_active` tinyint(1) DEFAULT 0 AFTER `end_date`;

ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `is_active`;

ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`;

-- Now insert sample terms
INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) VALUES
(1, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1),
(1, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0),
(1, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0);
```

---

## 🔄 **If "IF NOT EXISTS" Doesn't Work (Older MySQL):**

Use this version instead:

```sql
-- Check and describe current table structure
DESCRIBE terms;
```

Then manually add missing columns based on what you see. Or use this safer approach:

```sql
-- Disable foreign key checks
SET FOREIGN_KEY_CHECKS = 0;

-- Backup: Rename old table
RENAME TABLE `terms` TO `terms_backup`;

-- Create new table with correct structure
CREATE TABLE `terms` (
  `term_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `term_name` varchar(100) NOT NULL,
  `session_year` varchar(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`term_id`),
  KEY `school_id` (`school_id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Copy data from backup if any exists
INSERT INTO `terms` (`term_id`, `school_id`)
SELECT `term_id`, `school_id` FROM `terms_backup`
WHERE EXISTS (SELECT 1 FROM `terms_backup`);

-- Insert sample terms
INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) VALUES
(1, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1),
(1, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0),
(1, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0)
ON DUPLICATE KEY UPDATE term_name=VALUES(term_name);

-- Drop backup table
DROP TABLE IF EXISTS `terms_backup`;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;
```

---

## 📋 **What This Does:**

1. **Renames old table** to `terms_backup` (keeps your data safe)
2. **Creates new table** with all correct columns
3. **Copies old data** if any exists
4. **Inserts sample terms**
5. **Drops backup** after success
6. **Restores foreign keys**

---

## ✅ **Expected Table Structure:**

After running the fix, your `terms` table should have:

```
term_id         - int(11) PRIMARY KEY AUTO_INCREMENT
school_id       - int(11) NOT NULL
term_name       - varchar(100) NOT NULL
session_year    - varchar(20) NOT NULL
start_date      - date NOT NULL
end_date        - date NOT NULL
is_active       - tinyint(1) DEFAULT 0
created_at      - timestamp DEFAULT CURRENT_TIMESTAMP
updated_at      - timestamp ON UPDATE CURRENT_TIMESTAMP
```

---

## 🧪 **Verify After Fix:**

### **Check Table Structure:**
```sql
DESCRIBE terms;
```

Should show all 9 columns listed above ✅

### **Check Data:**
```sql
SELECT * FROM terms;
```

Should show 3 terms for 2024/2025 session ✅

---

## 🎯 **Recommended Approach:**

**Use the second script (Rename & Recreate)** - It's the most reliable and keeps a backup of your old data.

---

## ✅ **After Running:**

Test these pages:
1. `http://localhost/msms/admin/terms.php` - Should show terms ✅
2. `http://localhost/msms/admin/parents.php` - Should work ✅
3. `http://localhost/msms/admin/report-cards.php` - Should work ✅

---

**Use the second script - it's the safest and most complete fix!** 🎉
