# 🔴 URGENT: Fix Database Connection Error

**Error:** `Access denied for user 'root'@'localhost' (using password: NO)`

**Cause:** Live server is using local development database credentials instead of cPanel credentials.

---

## ⚡ **QUICK FIX (Choose ONE method)**

---

### **METHOD 1: Create .env File** ⭐ RECOMMENDED (Most Secure)

#### Step 1: Get Your cPanel Database Info

From your cPanel MySQL® Databases section:
```
Database Name:  cpaneluser___________ (example: myaccount_schoolsystem)
Username:       cpaneluser___________ (example: myaccount_admin)
Password:       [the password YOU created]
Host:           localhost
```

**Don't remember?** Check cPanel → MySQL® Databases to see database names and users.

#### Step 2: Create .env File on Live Server

1. **Login to cPanel**
2. **File Manager** → `public_html`
3. **Click "File"** → **"Create New File"**
4. **Name it:** `.env`
5. **Right-click** `.env` → **Edit**
6. **Paste this** (replace with YOUR actual credentials):

```env
# Production Environment Configuration

APP_ENV=production

# Database Credentials - UPDATE WITH YOUR CPANEL INFO
DB_HOST=localhost
DB_USER=cpaneluser_schooladmin
DB_PASS=YourActualDatabasePassword
DB_NAME=cpaneluser_schoolsystem

# Application URL
APP_URL=https://msms.uniquehavenangelschool.com

# Paystack Keys (optional - update later)
PAYSTACK_PUBLIC_KEY=pk_test_xxxxxxxxxxxxx
PAYSTACK_SECRET_KEY=sk_test_xxxxxxxxxxxxx

# Email Configuration (optional - update later)
MAIL_HOST=mail.uniquehavenangelschool.com
MAIL_PORT=465
MAIL_USERNAME=noreply@uniquehavenangelschool.com
MAIL_PASSWORD=your_email_password
MAIL_FROM_ADDRESS=noreply@uniquehavenangelschool.com
MAIL_ENCRYPTION=ssl
```

7. **Save**
8. **Set permissions:** Right-click → Permissions → **644**
9. **Test:** Refresh your site

---

### **METHOD 2: Edit config.php Directly** (Quick but less secure)

#### Option A: Via cPanel File Manager

1. **cPanel** → **File Manager** → `public_html`
2. **Right-click** `config.php` → **Edit**
3. **Find lines 27-36** (the database configuration section)
4. **Change from:**

```php
if (!defined('DB_HOST')) {
    define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
}
if (!defined('DB_USER')) {
    define('DB_USER', getenv('DB_USER') ?: 'root');
}
if (!defined('DB_PASS')) {
    define('DB_PASS', getenv('DB_PASS') ?: '');
}
if (!defined('DB_NAME')) {
    define('DB_NAME', getenv('DB_NAME') ?: 'sba');
}
```

5. **Change to:** (replace with YOUR actual credentials)

```php
if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost');
}
if (!defined('DB_USER')) {
    define('DB_USER', 'cpaneluser_schooladmin'); // YOUR DATABASE USERNAME
}
if (!defined('DB_PASS')) {
    define('DB_PASS', 'YourActualPassword'); // YOUR DATABASE PASSWORD
}
if (!defined('DB_NAME')) {
    define('DB_NAME', 'cpaneluser_schoolsystem'); // YOUR DATABASE NAME
}
```

6. **Also update APP_URL** (around line 40):

```php
if (!defined('APP_URL')) {
    define('APP_URL', 'https://msms.uniquehavenangelschool.com');
}
```

7. **Save**
8. **Test:** Refresh your site

---

## 🔍 **How to Find Your Database Credentials**

### In cPanel:

1. **Login to cPanel**
2. **Databases** section → **MySQL® Databases**

#### Database Name:
- Look under "Current Databases"
- Usually: `cpanelusername_databasename`
- Example: `myhost_schoolsystem`

#### Database User:
- Look under "Current Users"
- Usually: `cpanelusername_username`
- Example: `myhost_admin`

#### Password:
- You set this when you created the user
- **Forgot it?** Change it:
  1. Find user in "Current Users"
  2. Click "Change Password"
  3. Set new password
  4. Copy the new password
  5. Use in .env or config.php

---

## ✅ **Verification**

After fixing, your site should:
1. ✅ Load without database error
2. ✅ Show login page
3. ✅ Allow login with: superadmin / password
4. ✅ Display dashboard

---

## 🆘 **Still Not Working?**

### Check These:

#### 1. Database User Has Privileges
```
cPanel → MySQL® Databases
→ Current Databases section
→ Under your database, verify user has "ALL PRIVILEGES"
```

#### 2. Database Exists
```
cPanel → phpMyAdmin
→ Left sidebar should show your database
→ Click it, should see 40+ tables
```

#### 3. Credentials Typed Correctly
```
- No extra spaces
- Correct capitalization
- Full database name with prefix
```

#### 4. Config File Saved
```
- File Manager shows updated timestamp
- No syntax errors (missing quotes, semicolons)
```

---

## 📝 **Example Real Credentials**

Here's what they typically look like:

```
If cPanel username is: johnschool

Database Name:  johnschool_msms
Username:       johnschool_admin  
Password:       Xy9#mK2$pL6@nQ
Host:           localhost
```

**YOUR credentials will be different!** Check your cPanel.

---

## 🔐 **Security Note**

### Method 1 (.env file) is BETTER because:
- ✅ Credentials separate from code
- ✅ .htaccess protects .env from web access
- ✅ Easier to update without editing code

### Method 2 (config.php) works but:
- ⚠️ Credentials in code file
- ⚠️ Less secure
- ⚠️ Harder to manage

**Recommended:** Use Method 1 (.env file)

---

## ⏱️ **Time Estimate**

- **Method 1:** 5 minutes
- **Method 2:** 3 minutes
- **Finding credentials:** 2 minutes

**Total:** ~10 minutes to fix completely

---

## 🎯 **After This Fix**

Your site will:
1. Connect to database successfully
2. Load login page
3. Allow user authentication
4. Display dashboards
5. Work completely!

Then you can:
- ✅ Login and test
- ✅ Change default password
- ✅ Setup school profile
- ✅ Add users and data

---

## 📞 **Need Help Finding Credentials?**

**Take a screenshot of:**
1. cPanel → MySQL® Databases → Current Databases
2. cPanel → MySQL® Databases → Current Users

And show me (blur/hide passwords if sharing publicly).

---

**Priority:** 🔴 **CRITICAL - Fix this first before anything else!**

Without correct database credentials, the site cannot function.

Once fixed, everything else will work! 🚀
