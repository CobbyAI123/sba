# 🟡 Fix "Constant Already Defined" Warning

**Warning:** `Constant CURRENCY_SYMBOL already defined in config.php on line 41`

**Good News:** ✅ This is just a WARNING, not an error. Your site is working!

**Cause:** config.php is being included/required multiple times in some page

---

## ⚡ **QUICK FIX**

### **Method 1: Turn Off Warnings in Production** ⭐ RECOMMENDED

This is the best approach for a live site - hide warnings from users.

#### Edit config.php on your LIVE server:

1. **cPanel** → **File Manager** → `public_html/config.php`
2. **Find line ~18** (in the error reporting section)
3. **Change from:**

```php
// Error Reporting
if (APP_ENV === 'production') {
    error_reporting(E_ALL);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', BASE_PATH . '/logs/error.log');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}
```

4. **Change to:**

```php
// Error Reporting
if (APP_ENV === 'production') {
    error_reporting(E_ERROR | E_PARSE); // Only show critical errors
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', BASE_PATH . '/logs/error.log');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}
```

5. **Save**
6. **Refresh site** - warning should be gone (logged instead)

---

### **Method 2: Find Where config.php is Included Twice**

The warning happens because some page is including config.php more than once.

#### Common culprits:

**Check these files for duplicate includes:**

1. **index.php** - Should have ONE `require_once 'config.php';`
2. **login.php** - Should have ONE `require_once 'config.php';`
3. **Any page showing the warning** - Check the URL where you saw it

#### How to Fix:

1. **Open the page** that showed the warning
2. **Search for:** `require` or `include` and `config.php`
3. **Ensure only ONE line** like:
   ```php
   require_once 'config.php';
   ```
4. **Remove any duplicates**

---

### **Method 3: Make config.php Self-Protecting**

Add a guard at the top of config.php to prevent double-loading:

#### Edit config.php line 2 (top of file):

**Change from:**
```php
<?php
// config.php - Main Configuration File
session_start();
```

**Change to:**
```php
<?php
// config.php - Main Configuration File
if (defined('CONFIG_LOADED')) {
    return;
}
define('CONFIG_LOADED', true);

session_start();
```

This prevents config.php from running twice.

---

## ✅ **Which Method to Use?**

### **For Production (Live Site):**
→ **Method 1** - Hide warnings from users ⭐ BEST

**Why?**
- Warnings don't affect functionality
- Users shouldn't see PHP warnings
- Errors still get logged for debugging

### **For Development (Local):**
→ **Method 2 or 3** - Fix the root cause

**Why?**
- Shows you what's wrong
- Helps debug issues
- Teaches better coding practices

---

## 🎯 **RECOMMENDED ACTION NOW**

**For your live site, do Method 1:**

1. Edit config.php on server
2. Change `E_ALL` to `E_ERROR | E_PARSE` in production section
3. Save
4. Refresh site

**Warning gone!** ✅

---

## 📊 **Current Status**

✅ **Database connected** - You got past the login error!  
✅ **Site loading** - Pages are working  
⚠️ **Warning showing** - Just cosmetic, fix with Method 1  

**You're 95% done with deployment!** 🎉

---

## 🚀 **Next Steps After Fixing Warning**

1. **Test login:**
   - Username: `superadmin`
   - Password: `password`

2. **Change default password** (critical!)

3. **Setup school profile**

4. **Add your first users**

---

## 🔍 **Understanding Error Levels**

| Level | What It Means | Show in Production? |
|-------|---------------|---------------------|
| **E_ERROR** | Fatal errors | ❌ No (but log it) |
| **E_WARNING** | Warnings (non-fatal) | ❌ No (but log it) |
| **E_NOTICE** | Notices | ❌ Never show |
| **E_PARSE** | Syntax errors | ❌ No (but log it) |
| **E_ALL** | Everything | ❌ ONLY for development |

**Production best practice:** Only log errors, don't display them.

---

## 🆘 **Still Seeing Warnings?**

If Method 1 doesn't work:

1. **Clear browser cache** (Ctrl + Shift + Delete)
2. **Try incognito/private mode**
3. **Check if .env has APP_ENV=production**
4. **Verify config.php saved correctly**

---

**Status:** 🟡 **Minor cosmetic issue - easy fix!**

Your site is functional, this is just a display preference. Use Method 1 to hide it from users! 🚀
