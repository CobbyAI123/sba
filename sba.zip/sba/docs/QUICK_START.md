# ⚡ Quick Start Guide

## 🚀 Get Started in 5 Minutes!

### **Step 1: Import Database** (2 minutes)

1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Create database: `school_management_system`
3. Import these files in order:
   - `database/schema.sql`
   - `database/library_tables.sql`
   - `database/terms_table.sql`
   - `database/add_indexes_corrected.sql` (optional)

---

### **Step 2: Configure** (1 minute)

1. Open `config.php`
2. Update if needed:
```php
define('APP_URL', 'http://localhost/msms');
```
3. Save

---

### **Step 3: Login** (30 seconds)

1. Go to: `http://localhost/msms`
2. Login as Super Admin:
   - Username: `superadmin`
   - Password: `SuperAdmin@123`

---

### **Step 4: Create School** (1 minute)

1. Click "Schools" → "Add School"
2. Fill details:
   - School Name
   - School Code
   - Contact Info
3. Upload logo (optional)
4. Submit
5. ✅ Admin account auto-created!

---

### **Step 5: Setup School** (30 seconds)

1. Logout
2. Login as School Admin:
   - Username: `[school_code]_admin`
   - Password: `Admin@123`
3. Change password

---

## 🎓 First Steps as Admin

### **1. Set Academic Term**
- Go to "Academic Terms"
- Add: First Term, 2024/2025
- Set dates: Sep 1 - Dec 20
- Mark as active

### **2. Create Classes**
- Go to "Classes"
- Add: Grade 1, Grade 2, etc.

### **3. Add Subjects**
- Go to "Subjects"
- Add: Math, English, Science, etc.

### **4. Add Teachers**
- Go to "Teachers"
- Add teacher details
- Assign subjects

### **5. Add Students**
- Go to "Students"
- Add student details
- Admission number auto-generated

---

## 📱 User Access

### **Teacher Login:**
- Username: [assigned username]
- Password: [assigned password]
- Can: Mark attendance, enter marks

### **Student Login:**
- Username: [assigned username]
- Password: [assigned password]
- Can: View results, attendance, fees

### **Accountant Login:**
- Username: [assigned username]
- Password: [assigned password]
- Can: Track finances, payments

### **Librarian Login:**
- Username: [assigned username]
- Password: [assigned password]
- Can: Manage books, track loans

---

## 💡 Quick Tips

### **Currency:**
- System uses Ghana Cedis (₵)
- Change in `config.php` if needed

### **Passwords:**
- Change all default passwords
- Use strong passwords (8+ characters)

### **Uploads:**
- Avatars: `uploads/avatars/`
- Logos: `uploads/logos/`
- Photos: `uploads/students/`

### **Backups:**
- Backup database regularly
- Export from phpMyAdmin

---

## 🆘 Common Issues

**Can't login?**
- Check database imported
- Verify credentials
- Clear browser cache

**Upload errors?**
- Create upload folders
- Set permissions (755)

**Blank page?**
- Enable error display in config.php
- Check PHP error log

---

## 📚 Documentation

- `INSTALLATION_GUIDE.md` - Detailed setup
- `SYSTEM_OVERVIEW.md` - Complete features
- `USER_MANAGEMENT_SYSTEM.md` - User guide
- `TERM_CURRENCY_UPDATE.md` - Terms & currency

---

## ✅ Checklist

- [ ] Database imported
- [ ] Config updated
- [ ] Super admin login works
- [ ] School created
- [ ] Admin login works
- [ ] Academic term set
- [ ] Classes created
- [ ] Subjects added
- [ ] Teachers added
- [ ] Students added

---

**You're all set! Start managing your school! 🎓✨**

**Need help? Check the documentation files!** 📚
