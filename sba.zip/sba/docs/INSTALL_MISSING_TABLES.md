# 🔧 Fix Missing Database Tables

## ⚠️ Error: Table 'parent_student' doesn't exist

This error occurs because some database tables are missing. Follow these steps to fix it:

---

## 🎯 **QUICK FIX (3 Steps)**

### **Step 1: Open phpMyAdmin**
1. Go to `http://localhost/phpmyadmin`
2. Login (usually no password for localhost)
3. Click on your database: `school_management_system`

### **Step 2: Run SQL Script**
1. Click on the **SQL** tab at the top
2. Copy and paste the SQL below
3. Click **Go** button

### **Step 3: Refresh Your Page**
1. Go back to your admin dashboard
2. Click on **Parents** menu
3. Should work now! ✅

---

## 📋 **SQL SCRIPT TO RUN:**

```sql
-- Create parent_student relationship table
CREATE TABLE IF NOT EXISTS `parent_student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `relationship` varchar(50) DEFAULT 'Parent',
  `is_primary` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create terms table (for academic years)
CREATE TABLE IF NOT EXISTS `terms` (
  `term_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `term_name` varchar(100) NOT NULL,
  `session_year` varchar(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`term_id`),
  KEY `school_id` (`school_id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create notifications table
CREATE TABLE IF NOT EXISTS `notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','error') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notification_id`),
  KEY `user_id` (`user_id`),
  KEY `is_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create transport routes table
CREATE TABLE IF NOT EXISTS `transport_routes` (
  `route_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `route_name` varchar(100) NOT NULL,
  `vehicle_number` varchar(50) DEFAULT NULL,
  `driver_name` varchar(100) DEFAULT NULL,
  `driver_phone` varchar(20) DEFAULT NULL,
  `fare` decimal(10,2) DEFAULT 0.00,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`route_id`),
  KEY `school_id` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add sample academic terms
INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) VALUES
(1, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1),
(1, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0),
(1, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0)
ON DUPLICATE KEY UPDATE term_name=term_name;
```

---

## ✅ **What This Does:**

### **Creates 4 Missing Tables:**

1. **`parent_student`** - Links parents to their children
   - Stores parent-student relationships
   - Tracks primary guardian
   - Used by Parents page

2. **`terms`** - Academic terms/sessions
   - First Term, Second Term, Third Term
   - Session years (2024/2025, etc.)
   - Active term tracking
   - Used by Report Cards, Marks, etc.

3. **`notifications`** - System notifications
   - Send messages to users
   - Track read/unread status
   - Different notification types

4. **`transport_routes`** - School transport
   - Bus routes
   - Driver information
   - Transport fees

### **Adds Sample Data:**
- ✅ 3 academic terms for 2024/2025 session
- ✅ First Term set as active

---

## 🎯 **Alternative Method (Command Line)**

If you prefer using command line:

```bash
# Navigate to xampp/mysql/bin
cd C:\xampp\mysql\bin

# Run mysql
mysql -u root -p

# Select database
USE school_management_system;

# Copy and paste the SQL script above
# Then type:
exit;
```

---

## 📊 **Verify Installation:**

After running the SQL, verify tables exist:

```sql
SHOW TABLES LIKE 'parent_student';
SHOW TABLES LIKE 'terms';
SHOW TABLES LIKE 'notifications';
SHOW TABLES LIKE 'transport_routes';
```

Should return 4 tables! ✅

---

## 🧪 **Test After Installation:**

1. **Parents Page:**
   - Go to: `http://localhost/msms/admin/parents.php`
   - Should load without errors ✅

2. **Academic Terms:**
   - Go to: `http://localhost/msms/admin/terms.php`
   - Should show 3 sample terms ✅

3. **Notifications:**
   - Go to: `http://localhost/msms/admin/notifications.php`
   - Should work ✅

4. **Report Cards:**
   - Go to: `http://localhost/msms/admin/report-cards.php`
   - Should show term dropdown ✅

---

## 🔍 **If Still Getting Errors:**

### **Check Database Name:**
Make sure your database is named: `school_management_system`

If different, update in `config.php`:
```php
define('DB_NAME', 'your_database_name');
```

### **Check Tables Created:**
In phpMyAdmin, check if tables appear in left sidebar:
- ✅ parent_student
- ✅ terms
- ✅ notifications
- ✅ transport_routes

### **Check for SQL Errors:**
When running SQL in phpMyAdmin, check for error messages at the bottom.

---

## 📁 **SQL File Location:**

The SQL script is also saved in:
```
c:\xampp\htdocs\msms\database\add_missing_tables.sql
```

You can import this file directly in phpMyAdmin:
1. Click **Import** tab
2. Choose file: `add_missing_tables.sql`
3. Click **Go**

---

## ✅ **Summary:**

**Problem:** Missing database tables  
**Solution:** Run the SQL script above  
**Time:** 2 minutes  
**Result:** All pages work! ✅  

---

**Run the SQL script now and your Parents page will work!** 🎉
