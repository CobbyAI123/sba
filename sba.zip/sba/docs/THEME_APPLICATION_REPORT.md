# Theme Application Report

Generated: 2025-12-17 04:17:34

## Summary
- Total files scanned: 252
- Files needing fixes: 8

## Files by Role

### ADMIN (6)
- [ ] analytics-dashboard.php
- [ ] dashboard_v2.php
- [ ] database-backup.php
- [ ] email-settings.php
- [ ] financial-reports.php
- [ ] generate-transcript.php

### ACCOUNTANT (1)
- [ ] teacher-daily-collections.php

### PARENT (1)
- [ ] receipt.php

