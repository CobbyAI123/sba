# 🚀 QUICK DEPLOYMENT REFERENCE
# SBA School System - Fast Track to Live Server

## ⏱️ 30-Minute Deployment Guide

This is a condensed version for experienced users. For detailed instructions, see `CPANEL_DEPLOYMENT_GUIDE.md`.

---

## 📋 PREREQUISITES (5 minutes)

Gather these before starting:

```
✓ cPanel login URL: https://yourdomain.com/cpanel
✓ cPanel username: ______________
✓ cPanel password: ______________
✓ Domain name: msms.uniquehavenangelschool.com
✓ Paystack live keys (pk_live_..., sk_live_...)
✓ Email password for noreply@yourdomain.com
```

---

## 🗄️ DATABASE SETUP (5 minutes)

### Quick Steps:
```bash
1. cPanel → MySQL® Databases
2. Create Database: uniqueha_msmsdb
3. Create User: uniqueha_msms (generate strong password)
4. Add User to Database → ALL PRIVILEGES
5. phpMyAdmin → Import → database/LIVE_SERVER_COMPLETE_SCHEMA.sql
```

**Save these credentials:**
```
DB_HOST=localhost
DB_USER=uniqueha_msms  
DB_PASS=[generated_password]
DB_NAME=uniqueha_msmsdb
```

---

## 📁 FILE UPLOAD (10 minutes)

### Option A: Direct Upload (Faster)
```bash
1. File Manager → public_html
2. Upload deployment package ZIP
3. Right-click → Extract
4. Delete ZIP file
```

### Option B: FTP Upload
```bash
Host: ftp.yourdomain.com
User: [cPanel username]
Password: [cPanel password]
Upload to: /public_html/
```

### Files to Include:
```
✓ admin/, teacher/, student/, parent/, accountant/
✓ assets/, includes/, ajax/, payment/
✓ config.php, login.php, index.php
✓ .htaccess, .env.example
✓ error-404.php, error-403.php, error-500.php
```

### Files to EXCLUDE:
```
✗ All .md files (documentation)
✗ database/ folder (already imported)
✗ XAMPP files (start_xampp.bat, etc.)
✗ .git folder
```

---

## ⚙️ CONFIGURATION (5 minutes)

### 1. Create .env file:
```bash
# In File Manager
1. Copy .env.example → .env
2. Edit .env
```

### 2. Update .env values:
```env
APP_ENV=production
APP_URL=https://msms.uniquehavenangelschool.com

# Database (from step 1)
DB_HOST=localhost
DB_USER=uniqueha_msms
DB_PASS=[your_database_password]
DB_NAME=uniqueha_msmsdb

# Paystack LIVE Keys
PAYSTACK_PUBLIC_KEY=pk_live_xxxxxxxxxxxxx
PAYSTACK_SECRET_KEY=sk_live_xxxxxxxxxxxxx
PAYSTACK_CURRENCY=GHS

# Email
MAIL_HOST=mail.uniquehavenangelschool.com
MAIL_PORT=465
MAIL_USERNAME=noreply@uniquehavenangelschool.com
MAIL_PASSWORD=[your_email_password]
MAIL_ENCRYPTION=ssl
MAIL_FROM_ADDRESS=noreply@uniquehavenangelschool.com

# Security
DEBUG=false
DISPLAY_ERRORS=false
LOG_ERRORS=true
```

### 3. Enable HTTPS in .htaccess:
```apache
# Uncomment these lines (remove #):
<IfModule mod_rewrite.c>
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
</IfModule>
```

### 4. Set Permissions:
```bash
uploads/ → 755
logs/ → 755
.env → 644
.htaccess → 644
```

---

## ✅ TESTING (5 minutes)

### 1. Test Database Connection:
Visit: `https://yourdomain.com`
Should load login page.

### 2. Login:
```
Username: superadmin
Password: password
```

### 3. Immediate Actions:
```bash
✓ Change superadmin password
✓ Create school profile
✓ Set up academic year
✓ Test email (send test notification)
✓ Test payment gateway (test mode first)
```

---

## 🚨 QUICK TROUBLESHOOTING

### Database Connection Failed
```bash
→ Check .env credentials match phpMyAdmin
→ Verify user has ALL PRIVILEGES
→ Test with: mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
```

### 500 Error
```bash
→ Check logs/error.log
→ Verify .htaccess syntax
→ Set permissions: folders 755, files 644
```

### CSS Not Loading
```bash
→ Check APP_URL in .env matches domain
→ Clear browser cache (Ctrl+Shift+Delete)
→ Check assets/ folder uploaded
```

### Email Not Working
```bash
→ Verify email exists in cPanel
→ Test SMTP with external client
→ Check spam folder
→ Contact hosting support
```

---

## 🔒 SECURITY CHECKLIST

```bash
✓ Change all default passwords
✓ Enable HTTPS redirect
✓ Verify .env protected (.htaccess)
✓ Delete test files (test-*.php)
✓ Set correct permissions
✓ Enable error logging
✓ Schedule backups
```

---

## 💳 PAYSTACK SETUP (2 minutes)

```bash
1. Login to paystack.com
2. Settings → API Keys & Webhooks
3. Copy Live keys to .env
4. Set webhook: https://yourdomain.com/payment/webhook.php
5. Test with test keys first
6. Switch to live keys when ready
```

---

## 📧 EMAIL SETUP (3 minutes)

```bash
1. cPanel → Email Accounts
2. Create: noreply@yourdomain.com
3. Note SMTP settings:
   - Server: mail.yourdomain.com
   - Port: 465 (SSL)
   - Username: noreply@yourdomain.com
4. Update .env
5. Test: Send password reset email
```

---

## 💾 BACKUP SETUP (2 minutes)

```bash
# Database (Weekly)
phpMyAdmin → Export → SQL

# Full Backup (Monthly)
cPanel → Backup → Full Account Backup

# Automated (Recommended)
cPanel → Backup Wizard → Schedule
```

---

## 📊 DEFAULT ACCOUNTS

### After Fresh Install:
```
Super Admin:
  Username: superadmin
  Password: password
  
*** CHANGE IMMEDIATELY! ***
```

---

## 🎯 POST-DEPLOYMENT TASKS

### Hour 1:
```
□ Change admin password
□ Create school profile
□ Configure settings
□ Test all features
```

### Day 1:
```
□ Add classes & subjects
□ Register teachers
□ Set up fee structures
□ Configure academic year
```

### Week 1:
```
□ Import students
□ Assign teachers to classes
□ Configure attendance
□ Train staff
```

---

## 📱 ACCESS URLS

```
Main Site: https://msms.uniquehavenangelschool.com
Login: https://msms.uniquehavenangelschool.com/login.php
Admin: https://msms.uniquehavenangelschool.com/admin/
Teacher: https://msms.uniquehavenangelschool.com/teacher/
Student: https://msms.uniquehavenangelschool.com/student/
Parent: https://msms.uniquehavenangelschool.com/parent/
```

---

## 🔧 PHP SETTINGS

Create `php.ini` or `.user.ini`:
```ini
upload_max_filesize = 10M
post_max_size = 10M
max_execution_time = 300
memory_limit = 256M
display_errors = Off
log_errors = On
error_log = logs/php_errors.log
```

---

## 📞 NEED HELP?

### Check These First:
1. `logs/error.log` - PHP errors
2. Browser Console (F12) - JavaScript errors
3. phpMyAdmin - Database issues
4. cPanel Error Log - Server errors

### Documentation:
- `CPANEL_DEPLOYMENT_GUIDE.md` - Detailed guide
- `DEPLOYMENT_READY.md` - System overview
- `TROUBLESHOOTING_GUIDE.txt` - Common issues

---

## ✨ FEATURES ENABLED

```
✓ Multi-school management
✓ Student enrollment & tracking
✓ Teacher management
✓ Fee collection & billing
✓ Online payments (Paystack)
✓ Attendance tracking
✓ Examination & grading
✓ Report cards
✓ Parent portal
✓ Email notifications
✓ SMS notifications (Hubtel)
✓ Analytics dashboard
✓ Timetable management
✓ Library system
✓ Bookstore system
```

---

## 🎉 DEPLOYMENT COMPLETE!

Your system is now live at: **https://msms.uniquehavenangelschool.com**

### Next Steps:
1. Login and explore
2. Create your school
3. Configure settings
4. Add users
5. Start using!

---

**Deployment Date:** _______________
**Deployed By:** _______________
**Server:** _______________
**Status:** ⬜ Testing ⬜ Live

---

*For detailed instructions, see: CPANEL_DEPLOYMENT_GUIDE.md*
*Version: 1.0 | Last Updated: January 2026*
