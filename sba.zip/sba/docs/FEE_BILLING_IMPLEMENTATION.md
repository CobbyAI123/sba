# Automatic Fee Billing System Implementation

**Date:** December 21, 2025  
**Feature:** Automatic student billing when fees are created  
**Status:** ✅ IMPLEMENTED  

---

## Overview

This feature ensures that when administrators create or modify fee structures, students are automatically billed and the fees immediately reflect on both student and parent portals.

---

## How It Works

### 1. **When Fee Structure is Created**
When an admin adds a new fee structure:
1. Fee structure is saved to `fee_structure` table
2. System automatically fetches all active students in that class
3. A `fee_payment` record is created for each student
4. Fees immediately appear on student and parent portals
5. Audit log records the billing action

**Example:**
```
Admin creates: "Tuition Fee - JSS1 - ₦50,000"
↓
System automatically creates fee_payment records for all 45 JSS1 students
↓
Fees appear on portal for all 45 students and their parents
↓
Each student's outstanding balance increases by ₦50,000
```

### 2. **When Fee Structure is Updated**
When an admin modifies fee amount:
1. Fee structure is updated with new amount
2. All pending/partially-paid student bills are updated
3. Fees on portals automatically update
4. Audit log records the change

**Example:**
```
Admin updates fee from ₦50,000 → ₦55,000
↓
System updates all student bills with new amount
↓
All outstanding balances automatically adjust
↓
Students and parents see updated amounts on portal
```

### 3. **When Fee Structure is Deleted**
When an admin removes a fee structure:
1. Fee structure is deleted
2. All pending (unpaid) student bills for that fee are removed
3. Paid records are kept for history
4. Audit log records the deletion

**Example:**
```
Admin deletes: "Lab Fee - JSS1"
↓
System removes pending lab fee from all students
↓
Outstanding balances for those students decrease
↓
Fees no longer show on portal
```

---

## Database Tables

### fee_payments Table
New table that tracks individual student fees:

```sql
CREATE TABLE fee_payments (
    fee_payment_id INT PRIMARY KEY AUTO_INCREMENT,
    school_id INT,
    student_id INT,
    term_id INT,
    fee_type VARCHAR(100),      -- 'tuition', 'exam', 'lab', etc.
    amount DECIMAL(10, 2),      -- Amount due
    status ENUM(...),           -- pending, partially_paid, paid, cancelled, waived
    due_date DATE,              -- When payment is due
    paid_date DATE,             -- When payment was made
    paid_amount DECIMAL(10, 2), -- Amount already paid
    payment_method VARCHAR(50),
    payment_reference VARCHAR(100),
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)
```

### fee_structure Table Enhancements
Added columns to track lifecycle:
- `status` - active/inactive
- `created_at` - when created
- `updated_at` - when modified

---

## Portal Reflection

### Parent Portal (`parent/fees.php`)
Shows for each child:
- ✅ Total fees (sum of all pending fee_payments)
- ✅ Amount paid (from payments/transactions tables)
- ✅ Outstanding balance (total - paid)
- ✅ Individual fee breakdown by type
- ✅ Due dates for each fee

### Student Portal (`student/fees.php`)
Shows the same information as parent portal

### Child Fees Detail (`parent/child-fees.php`)
Shows detailed breakdown:
- ✅ All fees for this student
- ✅ Payment history
- ✅ Outstanding amounts
- ✅ Due dates

---

## Installation Steps

### Step 1: Create Database Table
```bash
# Run SQL migration
mysql -u root -p sba < database/create_fee_payments_table.sql

# Or use phpMyAdmin:
# 1. Go to SQL tab
# 2. Copy-paste the SQL file contents
# 3. Execute
```

### Step 2: Test the Feature
1. Go to Admin > Fee Structure
2. Click "Add Fee Structure"
3. Fill in:
   - Class: JSS1
   - Term: First Term 2025
   - Fee Type: Tuition Fee
   - Amount: 50000
   - Description: Annual tuition
4. Click "Save Fee"

**Expected Result:**
- Success message: "Fee structure added successfully! Billed X students."
- All JSS1 students now have outstanding fees
- Parents can see fees on their portal

### Step 3: Verify on Portals
1. **Parent Portal:**
   - Go to `parent/fees.php`
   - Scroll to child details
   - Should see "Total Fees: ₦50,000"
   - Should see "Outstanding: ₦50,000"

2. **Student Portal:**
   - Go to `student/fees.php` (if available)
   - Should see same information

### Step 4: Test Fee Update
1. Go to Admin > Fee Structure
2. Click Edit on the fee you just created
3. Change amount from 50,000 to 55,000
4. Click Save

**Expected Result:**
- Success message: "Updated X student bills"
- All student portals show new amount
- Outstanding balance automatically increases

### Step 5: Test Fee Deletion
1. Go to Admin > Fee Structure
2. Click Delete on a fee
3. Confirm deletion

**Expected Result:**
- Fee is removed
- Pending bills are cancelled
- Fees no longer show on student/parent portals

---

## Query Examples

### View All Pending Fees for a Student
```php
$stmt = $db->prepare("
    SELECT * FROM fee_payments
    WHERE student_id = ? AND status = 'pending'
    ORDER BY due_date
");
$stmt->execute([$student_id]);
$fees = $stmt->fetchAll();

// Calculate total outstanding
$total = array_sum(array_map(function($f) {
    return $f['amount'] - $f['paid_amount'];
}, $fees));
```

### View Fee Collection Status by Class
```php
$stmt = $db->prepare("
    SELECT 
        c.class_name,
        fp.fee_type,
        COUNT(DISTINCT fp.student_id) as students_billed,
        SUM(fp.amount) as total_expected,
        SUM(fp.paid_amount) as total_collected,
        COUNT(CASE WHEN fp.status = 'paid' THEN 1 END) as fully_paid_count,
        ROUND(SUM(fp.paid_amount) / SUM(fp.amount) * 100, 2) as collection_percentage
    FROM fee_payments fp
    INNER JOIN students s ON fp.student_id = s.student_id
    INNER JOIN classes c ON s.class_id = c.class_id
    WHERE c.class_id = ?
    GROUP BY c.class_name, fp.fee_type
");
$stmt->execute([$class_id]);
```

### Update Student Fee When Payment Received
```php
$stmt = $db->prepare("
    UPDATE fee_payments
    SET status = 'paid',
        paid_amount = amount,
        paid_date = NOW(),
        payment_method = ?,
        payment_reference = ?
    WHERE fee_payment_id = ?
");
$stmt->execute([$payment_method, $reference, $fee_payment_id]);
```

---

## Integration with Payment Systems

When a payment is received:

### Old System (Transactions Table)
```php
// After transaction is marked completed:
$stmt = $db->prepare("
    UPDATE fee_payments
    SET status = 'paid',
        paid_amount = amount,
        paid_date = NOW(),
        payment_method = ?,
        payment_reference = ?
    WHERE student_id = ? AND fee_type = ? AND term_id = ?
");
```

### New System (Payments Table)
```php
// After payment is marked completed:
$stmt = $db->prepare("
    UPDATE fee_payments
    SET status = 'paid',
        paid_amount = amount,
        paid_date = NOW(),
        payment_method = ?,
        payment_reference = ?
    WHERE student_id = ? AND fee_type = ? AND term_id = ?
");
```

---

## Portal Queries Updated

### parent/fees.php Query
Now uses `fee_payments` table:
```php
$stmt = $db->prepare("
    SELECT SUM(amount) as total_fees
    FROM fee_payments
    WHERE student_id = ? 
    AND term_id = ? 
    AND status IN ('pending', 'partially_paid')
");
$stmt->execute([$student_id, $term_id]);
```

### Automatic Outstanding Calculation
```php
$total_fees = 50000;  // From fee_payments
$paid = 20000;        // From payments table
$outstanding = $total_fees - $paid;  // = 30,000
```

---

## Features

✅ **Automatic Billing**
- Students automatically billed when fees created
- No manual intervention needed

✅ **Instant Portal Updates**
- Fees appear immediately on student/parent portals
- No page refresh needed (after reload)

✅ **Audit Trail**
- All fee creation/modification logged
- Shows how many students billed
- Tracks changes with before/after values

✅ **Flexible Management**
- Update fees anytime (updates all student bills)
- Delete unused fees (removes pending bills)
- Organize by class and term

✅ **Payment Tracking**
- Individual student fee records
- Payment history per fee
- Due date management
- Payment status tracking

✅ **Collection Reports**
- See which students have paid
- See how much has been collected
- Collection percentage by class/fee

---

## Best Practices

1. **Create Fees Early**
   - Create all fees for a term before classes start
   - Students see their complete fee obligations

2. **Set Reasonable Due Dates**
   - Use 7-30 days after billing
   - Gives parents time to arrange payment

3. **Regular Updates**
   - Check fee structure matches curriculum
   - Remove outdated fees
   - Update amounts annually

4. **Parent Communication**
   - Notify parents when fees are created
   - Remind of due dates
   - Send payment receipts

5. **Fee Organization**
   - Group related fees (e.g., "Development Fund", "Facility Fund")
   - Use clear descriptions
   - Consistent naming across classes/terms

---

## Troubleshooting

### Students Not Being Billed
**Issue:** Created fee structure but students don't have pending bills

**Solution:**
1. Check student status is 'active'
2. Verify term_id is correct
3. Run SQL to create missing records:
```sql
INSERT INTO fee_payments (school_id, student_id, term_id, fee_type, amount, status, due_date)
SELECT ?, s.student_id, ?, ?, ?, 'pending', DATE_ADD(NOW(), INTERVAL 7 DAY)
FROM students s
WHERE s.class_id = ? AND s.school_id = ? AND s.status = 'active';
```

### Fees Not Showing on Portal
**Issue:** Created fees but portals still show old amounts

**Solution:**
1. Clear browser cache (Ctrl+F5)
2. Check database query includes fee_payments table
3. Verify term_id matches active term

### Outstanding Fees Not Updating
**Issue:** Fees don't change when payments received

**Solution:**
1. Verify payment updates fee_payments table
2. Check payment has term_id that matches fee
3. Ensure payment_method and reference are recorded

---

## Audit Trail Records

When fee operations are performed, audit logs show:

```
Action: Added fee structure: Tuition Fee (Billed 45 students)
Table: fee_structure
Record ID: 234
Changes: {
    "fee_type": "tuition",
    "amount": 50000,
    "students_billed": 45
}
Timestamp: 2025-12-21 14:30:00
```

---

## Performance Considerations

- `fee_payments` table indexed on student_id and term_id
- Unique constraint prevents duplicate fees per student per term
- Queries optimized for portal display
- Audit logging is optional (can be disabled)

---

## Future Enhancements

Potential additions:
- Bulk fee creation for multiple classes
- Fee waiver/exemption system
- Recurring fee templates
- Automated payment reminders (SMS/Email)
- Fee adjustment for individual students
- Discount/reduction management

---

## Summary

✅ **Feature Complete**
- Fees automatically bill students when created
- Changes instantly reflect on portals
- Full audit trail of all operations
- Easy management and updates

**Status: PRODUCTION READY**

Test thoroughly in your environment before deploying to live system.
