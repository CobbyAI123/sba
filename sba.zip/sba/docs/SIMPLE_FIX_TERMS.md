# ✅ Simple Fix - Terms Table Already Has school_id!

## Good News! 
The `school_id` column already exists in your `terms` table. You just need to insert the sample data.

---

## 🎯 **FINAL FIX (Run This):**

Copy and paste this in phpMyAdmin SQL tab:

```sql
-- Just insert the sample terms
INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) VALUES
(1, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1),
(1, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0),
(1, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0);
```

---

## 📋 **If You Get "Duplicate Entry" Error:**

If terms already exist, just check what's in the table:

```sql
SELECT * FROM terms;
```

If you see terms already there, **you're done!** ✅

---

## 🔄 **If You Want to Replace Existing Terms:**

```sql
-- Delete old terms first
DELETE FROM terms WHERE school_id = 1;

-- Insert new terms
INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) VALUES
(1, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1),
(1, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0),
(1, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0);
```

---

## ✅ **Summary:**

Your `terms` table is **already correct**! It has the `school_id` column.

Just insert the sample data and you're done! 🎉
