# ============================================================================
# DEPLOYMENT CHECKLIST
# School Management System - cPanel Live Server
# ============================================================================
# Use this checklist to track your deployment progress
# Check off each item as you complete it
# ============================================================================

## PRE-DEPLOYMENT PREPARATION

### Local Preparation
- [ ] All features tested locally and working
- [ ] Database backup created
- [ ] All bugs fixed and verified
- [ ] Latest code committed (if using version control)
- [ ] Deployment package created using prepare_deployment.bat
- [ ] .env.example file reviewed and understood

### Account Setup
- [ ] cPanel hosting account ready
- [ ] Domain name configured
- [ ] DNS pointing to hosting server
- [ ] cPanel login credentials saved securely
- [ ] FTP credentials obtained (if needed)

### Third-Party Services
- [ ] Paystack account created (paystack.com)
- [ ] Paystack LIVE API keys obtained
- [ ] Email account password ready
- [ ] SSL certificate available or Let's Encrypt setup planned

---

## DATABASE SETUP

### Database Creation
- [ ] Logged into cPanel
- [ ] Navigated to MySQL® Databases
- [ ] Created new database
- [ ] Full database name noted (e.g., cpaneluser_schoolsystem)

### Database User
- [ ] Created database user
- [ ] Strong password generated and saved
- [ ] Full username noted (e.g., cpaneluser_schooladmin)
- [ ] User assigned to database
- [ ] ALL PRIVILEGES granted

### Database Import
- [ ] Logged into phpMyAdmin
- [ ] Database selected
- [ ] Import tab opened
- [ ] LIVE_SERVER_COMPLETE_SCHEMA.sql uploaded
- [ ] Import completed successfully
- [ ] Tables verified (40+ tables should exist)
- [ ] Sample data checked (schools, users tables)

---

## FILE UPLOAD

### Upload Method Selected
- [ ] Method 1: cPanel File Manager (recommended)
- [ ] Method 2: FTP/SFTP client
- [ ] Method 3: SSH/Terminal (advanced)

### Files Uploaded
- [ ] Deployment ZIP uploaded to public_html
- [ ] ZIP file extracted successfully
- [ ] Extracted files moved to correct location
- [ ] ZIP file deleted after extraction
- [ ] All folders present (admin, student, teacher, etc.)
- [ ] All root files present (config.php, login.php, etc.)

### Directory Structure Verified
- [ ] /admin folder exists
- [ ] /accountant folder exists
- [ ] /assets folder exists
- [ ] /includes folder exists
- [ ] /parent folder exists
- [ ] /student folder exists
- [ ] /teacher folder exists
- [ ] /librarian folder exists
- [ ] /bookstore folder exists
- [ ] /proprietor folder exists
- [ ] /super-admin folder exists
- [ ] /payment folder exists
- [ ] /ajax folder exists
- [ ] /cache folder exists
- [ ] /database folder exists (with SQL file)

---

## CONFIGURATION

### Environment File (.env)
- [ ] .env.example copied to .env
- [ ] APP_ENV set to "production"
- [ ] DB_HOST configured (usually "localhost")
- [ ] DB_USER configured with full username
- [ ] DB_PASS configured with correct password
- [ ] DB_NAME configured with full database name
- [ ] APP_URL updated with your domain (https://yourdomain.com)
- [ ] PAYSTACK_PUBLIC_KEY updated with live key
- [ ] PAYSTACK_SECRET_KEY updated with live key
- [ ] MAIL_HOST configured
- [ ] MAIL_PORT configured (465 for SSL)
- [ ] MAIL_USERNAME configured
- [ ] MAIL_PASSWORD configured
- [ ] MAIL_FROM_ADDRESS configured
- [ ] TIMEZONE set correctly (Africa/Accra for Ghana)

### Config.php Updates
- [ ] Opened config.php in editor
- [ ] Verified database constants match .env
- [ ] APP_URL updated if not using .env
- [ ] Error reporting set to production mode
- [ ] All paths verified

### .htaccess Configuration
- [ ] Opened .htaccess in editor
- [ ] HTTPS redirect uncommented (lines 88-91)
- [ ] Error document paths updated if in subdirectory
- [ ] Security headers verified
- [ ] File protection rules verified

---

## DIRECTORY CREATION

### Required Folders
- [ ] /uploads folder created (755 permissions)
- [ ] /uploads/avatars folder created (755)
- [ ] /uploads/students folder created (755)
- [ ] /uploads/logos folder created (755)
- [ ] /logs folder created (755 permissions)
- [ ] All folders writable by web server

---

## FILE PERMISSIONS

### Security Permissions Set
- [ ] .env file set to 644
- [ ] config.php set to 644
- [ ] .htaccess set to 644
- [ ] uploads/ folder set to 755
- [ ] logs/ folder set to 755
- [ ] All PHP files set to 644
- [ ] All folders set to 755

---

## SECURITY HARDENING

### Default Credentials
- [ ] Logged into phpMyAdmin
- [ ] Located superadmin user in users table
- [ ] Generated new password hash
- [ ] Updated password_hash field
- [ ] Verified new password works
- [ ] Documented new credentials securely

### File Protection
- [ ] .env file protected (not accessible via browser)
- [ ] config.php protected
- [ ] database/ folder protected
- [ ] logs/ folder protected
- [ ] Test files deleted

### SSL/HTTPS
- [ ] SSL certificate installed
- [ ] HTTPS redirect working
- [ ] Site accessible via https://
- [ ] Mixed content warnings resolved
- [ ] Security padlock showing in browser

---

## EMAIL CONFIGURATION

### Email Account
- [ ] Email account created in cPanel
- [ ] Strong password set
- [ ] SMTP settings obtained
- [ ] Settings updated in .env
- [ ] Test email sent successfully
- [ ] Test file deleted after testing

---

## PAYMENT GATEWAY

### Paystack Integration
- [ ] Paystack live account verified
- [ ] Business verification completed (if required)
- [ ] Live public key copied to .env
- [ ] Live secret key copied to .env
- [ ] Webhook URL configured in Paystack dashboard
- [ ] Test transaction completed (small amount)
- [ ] Payment confirmation received

---

## PHP CONFIGURATION

### PHP Settings
- [ ] php.ini or .user.ini created
- [ ] upload_max_filesize set to 10M
- [ ] post_max_size set to 10M
- [ ] max_execution_time set to 300
- [ ] memory_limit set to 256M
- [ ] date.timezone set correctly
- [ ] display_errors set to Off
- [ ] log_errors set to On

---

## TESTING & VERIFICATION

### Basic Functionality
- [ ] Homepage loads (https://yourdomain.com)
- [ ] Redirects to login page
- [ ] Login page displays correctly
- [ ] CSS and JavaScript loading
- [ ] Images displaying correctly

### Authentication
- [ ] Admin login works
- [ ] Dashboard loads after login
- [ ] Session management working
- [ ] Logout works correctly
- [ ] Login attempts limiting working

### Database Operations
- [ ] Can view existing data
- [ ] Can create new records
- [ ] Can update records
- [ ] Can delete records
- [ ] Queries executing properly

### File Uploads
- [ ] Student photo upload works
- [ ] School logo upload works
- [ ] Avatar upload works
- [ ] Files saving to correct directory
- [ ] File permissions correct

### Email System
- [ ] Welcome emails sending
- [ ] Password reset emails working
- [ ] Payment confirmation emails working
- [ ] Email templates displaying correctly

### Payment Processing
- [ ] Payment form displays
- [ ] Paystack modal opens
- [ ] Test payment completes
- [ ] Payment recorded in database
- [ ] Receipt generated

### Reports & PDFs
- [ ] Reports generate successfully
- [ ] PDFs download correctly
- [ ] Charts rendering properly
- [ ] Data accurate

---

## PERFORMANCE CHECK

### Speed & Optimization
- [ ] Page load time < 3 seconds
- [ ] Database queries optimized
- [ ] Images optimized
- [ ] Browser caching working
- [ ] GZIP compression enabled

### Cross-Browser Testing
- [ ] Tested on Chrome
- [ ] Tested on Firefox
- [ ] Tested on Safari
- [ ] Tested on Edge
- [ ] Mobile responsive verified

### Mobile Testing
- [ ] Tested on iPhone
- [ ] Tested on Android
- [ ] Touch interactions work
- [ ] Forms usable on mobile
- [ ] Navigation works on mobile

---

## BACKUP SETUP

### Backup Strategy
- [ ] Backup schedule planned
- [ ] Database backup tested
- [ ] File backup tested
- [ ] Backup storage location decided
- [ ] Restore procedure tested
- [ ] Backup automation configured (if available)

---

## MONITORING SETUP

### Error Monitoring
- [ ] Error logging enabled
- [ ] logs/error.log accessible
- [ ] PHP error log location identified
- [ ] Error notification method decided

### Uptime Monitoring
- [ ] Uptime monitor service registered
- [ ] URL added to monitoring
- [ ] Alert email configured
- [ ] Monitoring frequency set

---

## DOCUMENTATION

### Internal Documentation
- [ ] Deployment date recorded
- [ ] Server details documented
- [ ] Credentials saved securely (password manager)
- [ ] Backup locations documented
- [ ] Support contacts saved

### User Documentation
- [ ] Admin manual ready
- [ ] User guides prepared
- [ ] Training materials available
- [ ] FAQ document created

---

## POST-DEPLOYMENT

### Initial Setup
- [ ] Created first school profile
- [ ] Added academic year/term
- [ ] Created sample classes
- [ ] Added some subjects
- [ ] Created fee structures
- [ ] Configured school settings

### User Accounts
- [ ] Created admin accounts
- [ ] Created teacher accounts
- [ ] Created accountant account
- [ ] Tested different role logins
- [ ] Verified permissions for each role

### Training
- [ ] Admin trained
- [ ] Teachers trained
- [ ] Accountant trained
- [ ] Support staff trained
- [ ] Documentation provided

---

## FINAL VERIFICATION

### Security Audit
- [ ] All default passwords changed
- [ ] Test files deleted
- [ ] Debug mode disabled
- [ ] Error display disabled
- [ ] Database credentials secure
- [ ] API keys secure
- [ ] File permissions correct

### Performance Audit
- [ ] Site loads quickly
- [ ] No console errors
- [ ] No broken links
- [ ] All images load
- [ ] Forms submit properly

### Functionality Audit
- [ ] All modules accessible
- [ ] All features working
- [ ] Reports generating
- [ ] Emails sending
- [ ] Payments processing

---

## GO-LIVE

### Final Steps
- [ ] All checklist items completed
- [ ] Stakeholders notified
- [ ] Go-live date announced
- [ ] Support team ready
- [ ] Emergency contacts available

### Launch Day
- [ ] Monitor error logs closely
- [ ] Watch for user issues
- [ ] Be available for support
- [ ] Document any issues
- [ ] Collect user feedback

---

## POST-LAUNCH (First Week)

### Daily Checks
- [ ] Day 1: Check error logs
- [ ] Day 2: Check error logs
- [ ] Day 3: Check error logs
- [ ] Day 4: Check error logs
- [ ] Day 5: Check error logs
- [ ] Day 6: Check error logs
- [ ] Day 7: Check error logs

### Weekly Tasks
- [ ] Database backup completed
- [ ] Performance review done
- [ ] User feedback collected
- [ ] Issues documented
- [ ] Fixes planned

---

## CONTACT INFORMATION

**Hosting Provider Support:**
- Company: _____________________
- Phone: _____________________
- Email: _____________________
- Account #: _____________________

**Domain Registrar:**
- Company: _____________________
- Phone: _____________________
- Email: _____________________

**Paystack Support:**
- Email: support@paystack.com
- Phone: +234 01 277 7715

**Emergency Contacts:**
- Developer: _____________________
- System Admin: _____________________
- IT Support: _____________________

---

## NOTES & ISSUES

Use this section to document any issues or special configurations:

_______________________________________________
_______________________________________________
_______________________________________________
_______________________________________________
_______________________________________________

---

## COMPLETION

**Deployment Completed:** ☐ YES ☐ NO

**Deployment Date:** _____________________

**Deployed By:** _____________________

**Sign Off:** _____________________

---

**CONGRATULATIONS!** 🎉

Your School Management System is now live and ready to use!

Remember to:
- Monitor regularly for the first few weeks
- Keep backups current
- Update credentials periodically
- Review security settings monthly
- Collect user feedback for improvements

For support, refer to:
- CPANEL_DEPLOYMENT_GUIDE.md (detailed instructions)
- README.md (system overview)
- logs/error.log (error debugging)
