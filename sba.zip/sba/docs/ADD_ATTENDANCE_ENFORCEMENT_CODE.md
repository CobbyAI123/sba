# ✅ ATTENDANCE ENFORCEMENT - EXACT CODE TO ADD

## 📦 Files Ready:
1. ✅ `includes/attendance-check.php` - Already uploaded (contains helper functions)

---

## 🔧 STEP 1: Edit `accountant/collect-canteen-fees-teachers.php`

### A. Add at Line 5 (after `require_once BASE_PATH . '/config.php';`):
```php
require_once BASE_PATH . '/includes/attendance-check.php';
```

### B. Add at Line 21 (inside payment submission, after `$notes = ...`):
```php
    // ✅ ATTENDANCE ENFORCEMENT: Check if teacher marked attendance today
    if (!enforceAttendanceBeforeFeeCollection($db, $user_id, 'canteen fee')) {
        redirect(APP_URL . '/accountant/collect-canteen-fees-teachers.php');
        exit;
    }
```

### C. Add after Line 88 (after `$staff = $stmt->fetchAll();`):
```php
// ✅ Check attendance status for all staff
$attendance_status = checkStaffAttendanceStatus($db, $staff);
```

### D. Add after Line 175 (after the header card closes `</div>`):
```php
    
    <?php echo displayAttendanceEnforcementNotice(); ?>
```

### E. Change Line 245 - Update table header grid:
**FROM:**
```php
<div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr auto; gap: 15px;
```

**TO:**
```php
<div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr 120px auto; gap: 15px;
```

### F. Add new column header after "Paid This Week" (around Line 250):
```php
                <div>Attendance</div>
```

### G. Update staff row grid (around Line 257):
**FROM:**
```php
<div class="staff-item" style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr auto; gap: 15px;
```

**TO:**
```php
<?php 
    $hasAttendance = $attendance_status[$person['user_id']] ?? false;
?>
<div class="staff-item" style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr 120px auto; gap: 15px;
```

### H. Add attendance badge column (after "Paid This Week" column, before Action button):
```php
                        <div>
                            <?php echo getAttendanceStatusBadge($hasAttendance); ?>
                        </div>
```

### I. Replace the collect button logic (around Line 285):
**FROM:**
```php
                        <div>
                            <button onclick="openPaymentModal(...)" class="btn btn-primary btn-sm">
                                <i class="fas fa-plus"></i> Collect
                            </button>
                        </div>
```

**TO:**
```php
                        <div>
                            <?php if ($hasAttendance): ?>
                                <button onclick="openPaymentModal(<?php echo htmlspecialchars(json_encode($person)); ?>, '<?php echo $period; ?>')" 
                                        class="btn btn-primary btn-sm">
                                    <i class="fas fa-plus"></i> Collect
                                </button>
                            <?php else: ?>
                                <button class="btn btn-secondary btn-sm" disabled title="Teacher must mark attendance first">
                                    <i class="fas fa-lock"></i> Locked
                                </button>
                            <?php endif; ?>
                        </div>
```

---

## 🔧 STEP 2: Edit `accountant/collect-transport-fees-teachers.php`

**Follow the EXACT same steps as above**, just change:
- "canteen fee" → "transport fee"
- Keep everything else the same

---

## 📤 UPLOAD TO SERVER:

1. Upload `includes/attendance-check.php`
2. Upload modified `accountant/collect-canteen-fees-teachers.php`
3. Upload modified `accountant/collect-transport-fees-teachers.php`

---

## 🧪 TEST:

1. Login as teacher who hasn't marked attendance
2. Try to view collection page
3. Should see:
   - ⚠️ Orange notice banner at top
   - 🔴 Red "Not Yet" badge in Attendance column
   - 🔒 "Locked" button (disabled)
4. Mark attendance
5. Refresh page
6. Should now see:
   - 🟢 Green "Marked" badge
   - ✅ "Collect" button enabled

---

## ✅ DONE!

Your system now enforces attendance before fee collection! 🎉
