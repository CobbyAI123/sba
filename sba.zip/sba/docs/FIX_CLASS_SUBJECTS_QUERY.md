# ✅ Fix class_subjects Insert Query

## ⚠️ Error: Column 'class_id' in field list is ambiguous

The query needs to specify which table the `class_id` comes from.

---

## ✅ **CORRECTED SQL:**

Use this instead:

```sql
-- Link all subjects to all classes
INSERT INTO `class_subjects` (`class_id`, `subject_id`, `teacher_id`)
SELECT c.class_id, s.subject_id, NULL
FROM classes c
CROSS JOIN subjects s
WHERE c.school_id = 1 AND s.school_id = 1
ON DUPLICATE KEY UPDATE id=id;
```

**OR** if you want to link subjects to specific classes:

```sql
-- First, check your classes and subjects
SELECT class_id, class_name FROM classes WHERE school_id = 1;
SELECT subject_id, subject_name FROM subjects WHERE school_id = 1;

-- Then link subjects to Class 1
INSERT INTO `class_subjects` (`class_id`, `subject_id`, `teacher_id`)
SELECT 1, subject_id, NULL
FROM subjects
WHERE school_id = 1
ON DUPLICATE KEY UPDATE id=id;

-- Link subjects to Class 2
INSERT INTO `class_subjects` (`class_id`, `subject_id`, `teacher_id`)
SELECT 2, subject_id, NULL
FROM subjects
WHERE school_id = 1
ON DUPLICATE KEY UPDATE id=id;

-- Link subjects to Class 3
INSERT INTO `class_subjects` (`class_id`, `subject_id`, `teacher_id`)
SELECT 3, subject_id, NULL
FROM subjects
WHERE school_id = 1
ON DUPLICATE KEY UPDATE id=id;

-- Repeat for all your classes...
```

---

## 🎯 **Recommended Approach:**

### **Option 1: Link ALL subjects to ALL classes** (Quick)
```sql
INSERT INTO `class_subjects` (`class_id`, `subject_id`, `teacher_id`)
SELECT c.class_id, s.subject_id, NULL
FROM classes c
CROSS JOIN subjects s
WHERE c.school_id = 1 AND s.school_id = 1
ON DUPLICATE KEY UPDATE id=id;
```

### **Option 2: Link subjects to specific classes** (Better)
```sql
-- Check what you have first
SELECT class_id, class_name FROM classes WHERE school_id = 1;
SELECT subject_id, subject_name FROM subjects WHERE school_id = 1;

-- Then manually link based on your needs
-- Example: Link Math, English, Science to Class 1
INSERT INTO `class_subjects` (`class_id`, `subject_id`) VALUES
(1, 1),  -- Class 1, Math
(1, 2),  -- Class 1, English
(1, 3)   -- Class 1, Science
ON DUPLICATE KEY UPDATE id=id;
```

---

## ✅ **What Changed:**

**Before (Error):**
```sql
ON DUPLICATE KEY UPDATE class_id=class_id;
```

**After (Fixed):**
```sql
ON DUPLICATE KEY UPDATE id=id;
```

**Why:** The `ON DUPLICATE KEY UPDATE` clause was also ambiguous. Changed to update the `id` field instead.

---

## 🧪 **Verify After Running:**

```sql
-- Check what was linked
SELECT 
    cs.id,
    c.class_name,
    s.subject_name,
    CONCAT(u.first_name, ' ', u.last_name) as teacher_name
FROM class_subjects cs
JOIN classes c ON cs.class_id = c.class_id
JOIN subjects s ON cs.subject_id = s.subject_id
LEFT JOIN users u ON cs.teacher_id = u.user_id
WHERE c.school_id = 1
ORDER BY c.class_name, s.subject_name;
```

Should show all class-subject links ✅

---

## ✅ **Summary:**

**Error:** Ambiguous column reference  
**Fix:** Changed `ON DUPLICATE KEY UPDATE` clause  
**Result:** Query works! ✅  

---

**Use Option 1 (quick) or Option 2 (better control)!** 🎉
