# 🚀 CPANEL DEPLOYMENT GUIDE
# School Management System - Live Server Deployment Instructions

## 📋 PRE-DEPLOYMENT CHECKLIST

### Before You Start
- [ ] cPanel hosting account with PHP 7.4+ and MySQL 5.7+
- [ ] Domain name configured and pointing to your hosting
- [ ] SSL certificate installed (Let's Encrypt or purchased)
- [ ] Database backup from development (if migrating data)
- [ ] Paystack live API keys (from paystack.com)
- [ ] Email account created in cPanel for notifications

---

## 🗄️ STEP 1: DATABASE SETUP IN CPANEL

### 1.1 Create Database
1. Login to **cPanel**
2. Navigate to **MySQL® Databases**
3. Under "Create New Database":
   - Database Name: `schoolsystem` (or your preferred name)
   - Click **Create Database**
4. **Note down the full database name** (usually: `cpaneluser_schoolsystem`)

### 1.2 Create Database User
1. Scroll to "MySQL Users" section
2. Under "Add New User":
   - Username: `schooladmin` (or your preferred name)
   - **Generate strong password** (use password generator)
   - Click **Create User**
3. **IMPORTANT:** Copy and save these credentials securely:
   ```
   Database Name: cpaneluser_schoolsystem
   Username: cpaneluser_schooladmin
   Password: [generated_password]
   Host: localhost
   ```

### 1.3 Assign User to Database
1. Scroll to "Add User To Database"
2. Select the user and database you just created
3. Click **Add**
4. On privileges page, check **ALL PRIVILEGES**
5. Click **Make Changes**

### 1.4 Import Database Schema
1. Navigate to **phpMyAdmin** in cPanel
2. Select your database from left sidebar
3. Click **Import** tab
4. Click **Choose File** and select: `database/LIVE_SERVER_COMPLETE_SCHEMA.sql`
5. Ensure format is set to **SQL**
6. Click **Go**
7. Wait for success message
8. Verify tables are created (should see 40+ tables)

---

## 📁 STEP 2: FILE UPLOAD TO CPANEL

### 2.1 Prepare Files Locally
1. **Create deployment package** - zip only these folders/files:
   ```
   - admin/
   - accountant/
   - assets/
   - includes/
   - parent/
   - student/
   - teacher/
   - librarian/
   - bookstore/
   - proprietor/
   - super-admin/
   - payment/
   - ajax/
   - cache/
   - config.php
   - login.php
   - logout.php
   - index.php
   - .htaccess
   - .env.example
   - error-404.php
   - error-403.php
   - error-500.php
   ```

2. **DO NOT INCLUDE:**
   - ❌ All .md documentation files
   - ❌ database/ folder
   - ❌ backups/ folder
   - ❌ XAMPP-specific files
   - ❌ .git folder (if exists)

### 2.2 Upload via cPanel File Manager
1. Login to **cPanel**
2. Navigate to **File Manager**
3. Go to **public_html** folder (or subdirectory if installing in subfolder)
4. Click **Upload** button
5. Upload your zip file
6. Once uploaded, right-click the zip file
7. Click **Extract**
8. After extraction, delete the zip file

### 2.3 Alternative: Upload via FTP
```
Host: ftp.yourdomain.com
Username: [your cPanel username]
Password: [your cPanel password]
Port: 21
```
Upload all files to `public_html/` directory

---

## ⚙️ STEP 3: CONFIGURATION

### 3.1 Configure Environment File
1. In File Manager, navigate to your site root
2. Locate `.env.example` file
3. Right-click → **Copy**
4. Name it `.env`
5. Right-click `.env` → **Edit**
6. Update with your actual values:

```env
# CRITICAL: Set to production
APP_ENV=production

# Database credentials from Step 1
DB_HOST=localhost
DB_USER=cpaneluser_schooladmin
DB_PASS=[your_database_password]
DB_NAME=cpaneluser_schoolsystem

# Your domain
APP_URL=https://yourdomain.com

# Paystack LIVE keys
PAYSTACK_PUBLIC_KEY=pk_live_xxxxxxxxxxxxx
PAYSTACK_SECRET_KEY=sk_live_xxxxxxxxxxxxx

# Email settings
MAIL_HOST=mail.yourdomain.com
MAIL_PORT=465
MAIL_USERNAME=noreply@yourdomain.com
MAIL_PASSWORD=[your_email_password]
MAIL_FROM_ADDRESS=noreply@yourdomain.com
MAIL_ENCRYPTION=ssl
```

7. Click **Save Changes**

### 3.2 Update config.php
1. Open `config.php` in File Manager editor
2. Verify these settings point to environment variables:
   ```php
   define('APP_ENV', getenv('APP_ENV') ?: 'production');
   define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
   define('DB_USER', getenv('DB_USER') ?: 'root');
   define('DB_PASS', getenv('DB_PASS') ?: '');
   define('DB_NAME', getenv('DB_NAME') ?: 'sba');
   define('APP_URL', getenv('APP_URL') ?: 'http://localhost/sba');
   ```
3. If not using environment variables, directly update:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'cpaneluser_schooladmin');
   define('DB_PASS', 'your_password_here');
   define('DB_NAME', 'cpaneluser_schoolsystem');
   define('APP_URL', 'https://yourdomain.com');
   ```

### 3.3 Update .htaccess for Production
1. Open `.htaccess` in editor
2. **Uncomment HTTPS redirect** (around line 88):
   ```apache
   # Remove the # symbols from these lines:
   <IfModule mod_rewrite.c>
       RewriteCond %{HTTPS} off
       RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
   </IfModule>
   ```

3. **Update error document paths** if NOT in root:
   ```apache
   # If installing in subdirectory, update these paths:
   ErrorDocument 404 /error-404.php
   ErrorDocument 403 /error-403.php
   ErrorDocument 500 /error-500.php
   ```

---

## 🔐 STEP 4: SECURITY SETUP

### 4.1 Set File Permissions
In File Manager, select these and set permissions:

1. **Folders** (755):
   - uploads/ (if doesn't exist, create it)
   - logs/ (if doesn't exist, create it)
   - cache/
   
2. **Sensitive Files** (644):
   - .htaccess
   - .env
   - config.php

3. **Create Required Folders**:
   ```
   Create: uploads/avatars/
   Create: uploads/students/
   Create: uploads/logos/
   Create: logs/
   Set all to 755 permissions
   ```

### 4.2 Protect Sensitive Files
`.htaccess` already includes:
```apache
<FilesMatch "^(config\.php|\.env)$">
    Order allow,deny
    Deny from all
</FilesMatch>
```

Verify this is present in your `.htaccess`

### 4.3 Change Default Admin Password
**CRITICAL SECURITY STEP:**

1. Login to phpMyAdmin in cPanel
2. Select your database
3. Find `users` table
4. Locate superadmin user
5. Generate new password hash:
   ```php
   # Use PHP to generate hash
   <?php echo password_hash('YourNewStrongPassword123!', PASSWORD_DEFAULT); ?>
   ```
6. Update the password_hash field with new hash
7. **Delete the PHP file used to generate hash**

---

## 📧 STEP 5: EMAIL CONFIGURATION

### 5.1 Create Email Account in cPanel
1. Navigate to **Email Accounts**
2. Click **Create**
3. Email: `noreply@yourdomain.com`
4. Set strong password
5. Click **Create Account**

### 5.2 Get SMTP Settings
From Email Accounts page, note:
```
Incoming Server: mail.yourdomain.com
Outgoing Server: mail.yourdomain.com
Port (SSL): 465
Port (TLS): 587
Username: noreply@yourdomain.com
```

### 5.3 Update .env with Email Settings
Already done in Step 3.1 above

### 5.4 Test Email (Optional)
Create `test-email.php` in root:
```php
<?php
require_once 'config.php';
$result = send_email('your-email@example.com', 'Test', 'Test message');
echo $result ? 'Email sent successfully!' : 'Email failed!';
// DELETE THIS FILE AFTER TESTING
?>
```
Visit: https://yourdomain.com/test-email.php
**DELETE AFTER TESTING**

---

## 💳 STEP 6: PAYSTACK SETUP

### 6.1 Get Live API Keys
1. Login to [paystack.com](https://paystack.com)
2. Navigate to **Settings** → **API Keys & Webhooks**
3. Copy your **Live Public Key** (starts with `pk_live_`)
4. Copy your **Live Secret Key** (starts with `sk_live_`)
5. Update in `.env` file (done in Step 3.1)

### 6.2 Configure Webhook (Important!)
1. In Paystack dashboard, go to **Settings** → **API Keys & Webhooks**
2. Under Webhook URL, enter:
   ```
   https://yourdomain.com/payment/webhook.php
   ```
3. Click **Save**
4. This enables automatic payment verification

---

## 🔧 STEP 7: PHP CONFIGURATION

### 7.1 Create or Edit php.ini
1. In cPanel File Manager, go to root directory
2. Check if `php.ini` exists, if not create it
3. Add these settings:
   ```ini
   upload_max_filesize = 10M
   post_max_size = 10M
   max_execution_time = 300
   max_input_time = 300
   memory_limit = 256M
   date.timezone = Africa/Accra
   
   # For production
   display_errors = Off
   log_errors = On
   error_log = logs/php_errors.log
   ```

### 7.2 Alternative: Use .user.ini
If php.ini doesn't work, create `.user.ini`:
```ini
upload_max_filesize = 10M
post_max_size = 10M
max_execution_time = 300
```

---

## ✅ STEP 8: VERIFICATION & TESTING

### 8.1 Test Database Connection
Create `test-connection.php` in root:
```php
<?php
require_once 'config.php';
try {
    $db = Database::getInstance()->getConnection();
    echo "✅ Database connected successfully!<br>";
    echo "Server: " . DB_HOST . "<br>";
    echo "Database: " . DB_NAME . "<br>";
} catch (Exception $e) {
    echo "❌ Connection failed: " . $e->getMessage();
}
// DELETE THIS FILE AFTER TESTING
?>
```
Visit: https://yourdomain.com/test-connection.php
**DELETE AFTER TESTING**

### 8.2 Test Application
1. Visit: https://yourdomain.com
2. Should redirect to login page
3. Try logging in with default credentials:
   ```
   Username: superadmin
   Password: password
   ```
4. **IMMEDIATELY CHANGE PASSWORD** after first login

### 8.3 Test Key Features
- [ ] Login/Logout works
- [ ] Dashboard loads correctly
- [ ] Database queries work
- [ ] File uploads work (try uploading a student photo)
- [ ] Email notifications work
- [ ] HTTPS is enforced
- [ ] Payment gateway is configured

### 8.4 Check Error Logs
In File Manager, check `logs/error.log` for any errors

---

## 🚨 TROUBLESHOOTING

### Issue: Database Connection Failed
**Solution:**
1. Verify credentials in `.env` match Step 1.2
2. Check database user has ALL PRIVILEGES
3. Ensure database host is `localhost`
4. Check phpMyAdmin - can you access database?

### Issue: 500 Internal Server Error
**Solution:**
1. Check `.htaccess` syntax
2. View `logs/error.log` for details
3. Verify file permissions (folders: 755, files: 644)
4. Check PHP version (must be 7.4+)

### Issue: Page Not Found (404)
**Solution:**
1. Verify all files uploaded correctly
2. Check file paths in config.php
3. Ensure .htaccess is uploaded
4. Clear browser cache

### Issue: CSS/JS Not Loading
**Solution:**
1. Check APP_URL in config.php matches your domain
2. View page source, check asset paths
3. Ensure assets/ folder uploaded
4. Clear browser cache

### Issue: Email Not Sending
**Solution:**
1. Verify email account created in cPanel
2. Check SMTP settings in .env
3. Test with external SMTP tester
4. Check spam folder
5. Contact hosting support for mail server status

### Issue: File Upload Fails
**Solution:**
1. Create uploads/ folder with 755 permissions
2. Check php.ini settings for upload limits
3. Verify web server can write to uploads/
4. Check PHP error logs

### Issue: Session Timeout Too Fast
**Solution:**
Edit config.php:
```php
define('SESSION_TIMEOUT', 7200); // 2 hours
```

---

## 🔒 POST-DEPLOYMENT SECURITY

### Immediate Actions
1. ✅ Change default admin password
2. ✅ Delete all test files (test-*.php)
3. ✅ Verify .env file is protected
4. ✅ Enable HTTPS redirect
5. ✅ Set correct file permissions
6. ✅ Create first backup

### Regular Maintenance
1. **Daily**: Check error logs
2. **Weekly**: Database backup
3. **Monthly**: Security updates, clear old logs
4. **Quarterly**: Review user accounts, audit activity logs

---

## 💾 BACKUP STRATEGY

### Database Backup (Weekly)
1. In cPanel, navigate to **Backup Wizard**
2. Click **Backup**
3. Select **Download a MySQL Database Backup**
4. Select your database
5. Download and store securely
6. Keep last 4 weeks of backups

### Full Backup (Monthly)
1. In cPanel, navigate to **Backup**
2. Click **Download a Full Account Backup**
3. Enter email address for notification
4. Wait for backup completion email
5. Download and store offsite

### Alternative: Automated Backups
Many cPanel hosts offer automatic daily backups.
Check with your hosting provider.

---

## 📊 MONITORING

### Setup Uptime Monitoring
Use free services:
- UptimeRobot.com
- Pingdom.com
- StatusCake.com

Monitor: https://yourdomain.com/login.php

### Performance Monitoring
1. Enable error logging (already configured)
2. Monitor logs/error.log weekly
3. Track page load times
4. Monitor database size

---

## 🎯 GOING LIVE CHECKLIST

Before announcing to users:

- [ ] Database imported successfully
- [ ] All files uploaded
- [ ] .env configured with production values
- [ ] HTTPS enabled and working
- [ ] SSL certificate valid
- [ ] Default admin password changed
- [ ] Email system tested
- [ ] Payment gateway tested (test mode first)
- [ ] File uploads working
- [ ] Error logging enabled
- [ ] Backups scheduled
- [ ] Uptime monitoring setup
- [ ] All test files deleted
- [ ] 404/403/500 error pages working
- [ ] Mobile responsive verified
- [ ] Cross-browser tested (Chrome, Firefox, Safari)
- [ ] Performance acceptable (<3s page load)

---

## 📞 SUPPORT CONTACTS

### Hosting Issues
Contact your cPanel hosting support with:
- Server error logs
- Screenshot of issue
- Steps to reproduce

### Application Issues
Check:
1. logs/error.log
2. Browser console (F12)
3. Database for data integrity

---

## 🎉 SUCCESS!

Your School Management System is now live!

**Next Steps:**
1. Create your first school profile
2. Add classes and subjects
3. Register teachers and students
4. Configure fee structures
5. Set up academic terms
6. Train your staff

**Access URLs:**
- Main Site: https://yourdomain.com
- Admin Login: https://yourdomain.com/login.php
- phpMyAdmin: https://yourdomain.com/cpanel (via cPanel)

---

## 📱 MOBILE ACCESS

The system is fully responsive and works on:
- iOS (iPhone/iPad)
- Android phones/tablets
- Desktop browsers
- Tablets

Users can access from any device with internet connection.

---

**Deployment Date:** _______________
**Deployed By:** _______________
**Server:** _______________
**Domain:** _______________

---

*For technical support or customization, refer to the main README.md file.*

**Version:** 1.0.0
**Last Updated:** January 2026
