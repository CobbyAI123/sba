# 🚀 School Management System - Installation Guide

## System Requirements

### **Server Requirements:**
- PHP 7.4 or higher
- MySQL 5.7 or higher / MariaDB 10.3+
- Apache/Nginx web server
- 512MB RAM minimum (1GB recommended)
- 500MB disk space

### **PHP Extensions Required:**
- PDO
- PDO_MySQL
- mbstring
- openssl
- fileinfo
- GD (for image processing)
- JSON

---

## 📥 Installation Steps

### **Step 1: Download & Extract**

1. Download the system files
2. Extract to your web server directory:
   - **XAMPP:** `C:\xampp\htdocs\msms`
   - **WAMP:** `C:\wamp\www\msms`
   - **Linux:** `/var/www/html/msms`

---

### **Step 2: Create Database**

1. Open phpMyAdmin (`http://localhost/phpmyadmin`)
2. Click "New" to create database
3. Database name: `school_management_system`
4. Collation: `utf8mb4_general_ci`
5. Click "Create"

---

### **Step 3: Import Database Schema**

**Import in this order:**

1. **Main Schema:**
   - File: `database/schema.sql`
   - Contains: All core tables
   - Click "Import" → Choose file → "Go"

2. **Library Tables:**
   - File: `database/library_tables.sql`
   - Contains: Library management tables
   - Import same way

3. **Terms Table:**
   - File: `database/terms_table.sql`
   - Contains: Academic terms table
   - Import same way

4. **Indexes (Optional but Recommended):**
   - File: `database/add_indexes_corrected.sql`
   - Contains: Performance indexes
   - Import same way

**Expected Result:** 25+ tables created successfully

---

### **Step 4: Configure Application**

1. Open `config.php` in text editor
2. Update database settings:

```php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Your MySQL password
define('DB_NAME', 'school_management_system');

// Application URL
define('APP_URL', 'http://localhost/msms'); // Update if different
```

3. Save file

---

### **Step 5: Set Folder Permissions**

**Create upload directories:**

```bash
mkdir uploads
mkdir uploads/avatars
mkdir uploads/students
mkdir uploads/logos
```

**Set permissions (Linux/Mac):**

```bash
chmod 755 uploads
chmod 755 uploads/avatars
chmod 755 uploads/students
chmod 755/logos
```

**Windows:** Right-click folders → Properties → Security → Allow write access

---

### **Step 6: Access the System**

1. Open browser
2. Go to: `http://localhost/msms`
3. You should see the login page

---

### **Step 7: Default Login Credentials**

**Super Admin (System Administrator):**
- Username: `superadmin`
- Password: `SuperAdmin@123`

**⚠️ IMPORTANT:** Change this password immediately after first login!

---

## 🎓 Initial Setup

### **After First Login:**

#### **1. Create Your School**
1. Login as Super Admin
2. Go to "Schools"
3. Click "Add School"
4. Fill details:
   - School name
   - School code
   - Contact info
   - Upload logo
5. Submit
6. ✅ Admin account auto-created!

#### **2. Login as School Admin**
- Username: `[school_code]_admin`
- Password: `Admin@123`
- Change password after login

#### **3. Set Up Academic Term**
1. Go to "Academic Terms"
2. Click "Add New"
3. Create First Term:
   - Term: First Term
   - Session: 2024/2025
   - Dates: Sep 1 - Dec 20
   - Set as active
4. Submit

#### **4. Create Classes**
1. Go to "Classes"
2. Add classes (e.g., Grade 1, Grade 2, etc.)
3. Set capacity and details

#### **5. Add Subjects**
1. Go to "Subjects"
2. Add subjects (Math, English, Science, etc.)
3. Assign to classes

#### **6. Add Teachers**
1. Go to "Teachers"
2. Click "Add Teacher"
3. Fill details
4. Assign subjects

#### **7. Add Students**
1. Go to "Students"
2. Click "Add Student"
3. Fill details
4. Admission number auto-generated

#### **8. Add Other Staff**
1. Go to "Accountants" - Add accountant
2. Go to "Librarians" - Add librarian
3. Set up parents (optional)

---

## 🔐 Security Setup

### **1. Change Default Passwords**

**Super Admin:**
1. Login as superadmin
2. Go to Profile
3. Change password
4. Use strong password (min 8 characters)

**School Admin:**
1. Login with auto-generated credentials
2. Go to Profile
3. Change password immediately

### **2. Secure config.php**

**Production Settings:**

```php
// Set to production
define('APP_ENV', 'production');

// Disable error display
ini_set('display_errors', 0);
ini_set('log_errors', 1);
```

### **3. Database Security**

1. Create dedicated MySQL user:

```sql
CREATE USER 'sms_user'@'localhost' IDENTIFIED BY 'strong_password';
GRANT ALL PRIVILEGES ON school_management_system.* TO 'sms_user'@'localhost';
FLUSH PRIVILEGES;
```

2. Update config.php:

```php
define('DB_USER', 'sms_user');
define('DB_PASS', 'strong_password');
```

### **4. File Permissions**

**Secure sensitive files:**

```bash
chmod 600 config.php
chmod 644 *.php
chmod 755 uploads
```

---

## 🧪 Testing Installation

### **Test 1: Super Admin Access**
1. Login as superadmin
2. Create a test school
3. ✅ Should work without errors

### **Test 2: School Admin Access**
1. Login as school admin
2. View dashboard
3. ✅ Statistics should display

### **Test 3: Create Users**
1. Add a teacher
2. Add a student
3. ✅ Both should be created

### **Test 4: Upload Files**
1. Upload school logo
2. Upload student photo
3. ✅ Files should save

### **Test 5: Database Operations**
1. Mark attendance
2. Enter exam marks
3. ✅ Data should save

---

## 🐛 Troubleshooting

### **Problem: Cannot connect to database**

**Solution:**
1. Check MySQL is running
2. Verify database credentials in config.php
3. Ensure database exists
4. Check user permissions

### **Problem: Blank page / White screen**

**Solution:**
1. Enable error display:
```php
ini_set('display_errors', 1);
error_reporting(E_ALL);
```
2. Check PHP error log
3. Verify all files uploaded correctly

### **Problem: Upload folder errors**

**Solution:**
1. Create upload directories
2. Set correct permissions
3. Check PHP upload settings:
```php
upload_max_filesize = 10M
post_max_size = 10M
```

### **Problem: Session errors**

**Solution:**
1. Check session directory writable
2. Verify session settings in php.ini
3. Clear browser cookies

### **Problem: Login not working**

**Solution:**
1. Verify database imported correctly
2. Check users table has data
3. Ensure passwords are hashed
4. Clear browser cache

### **Problem: Images not displaying**

**Solution:**
1. Check APP_URL in config.php
2. Verify file paths correct
3. Check file permissions
4. Ensure GD extension enabled

---

## 📊 Database Verification

### **Check Tables Created:**

```sql
SHOW TABLES;
```

**Expected tables (25+):**
- schools
- users
- students
- teachers
- classes
- subjects
- class_subjects
- attendance
- exams
- exam_results
- payments
- fee_structure
- timetable
- terms
- library_books
- library_transactions
- library_categories
- activity_logs
- notifications
- sessions
- settings

### **Check Sample Data:**

```sql
-- Check super admin exists
SELECT * FROM users WHERE role = 'super_admin';

-- Check schools
SELECT * FROM schools;

-- Check terms
SELECT * FROM terms;
```

---

## ⚙️ Configuration Options

### **Currency Settings:**

Change in `config.php`:

```php
define('CURRENCY_CODE', 'GHS'); // Ghana Cedis
define('CURRENCY_SYMBOL', '₵');

// Other options:
// 'USD' => '$'
// 'NGN' => '₦'
// 'GBP' => '£'
// 'EUR' => '€'
```

### **Application URL:**

```php
// Development
define('APP_URL', 'http://localhost/msms');

// Production
define('APP_URL', 'https://yourdomain.com');
```

### **Session Timeout:**

```php
define('SESSION_TIMEOUT', 3600); // 1 hour (in seconds)
```

### **Password Requirements:**

```php
define('PASSWORD_MIN_LENGTH', 8);
```

---

## 🚀 Production Deployment

### **1. Prepare for Production**

**Update config.php:**

```php
define('APP_ENV', 'production');
define('APP_URL', 'https://yourdomain.com');
```

**Disable debugging:**

```php
ini_set('display_errors', 0);
ini_set('log_errors', 1);
```

### **2. Security Checklist**

- [ ] Change all default passwords
- [ ] Use strong database password
- [ ] Enable HTTPS/SSL
- [ ] Set proper file permissions
- [ ] Disable directory listing
- [ ] Enable firewall
- [ ] Regular backups configured
- [ ] Update PHP to latest version
- [ ] Remove phpMyAdmin from production

### **3. Performance Optimization**

**Enable caching:**

```php
// Add to .htaccess
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

**Enable compression:**

```php
// Add to .htaccess
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
</IfModule>
```

### **4. Backup Strategy**

**Database backup:**

```bash
mysqldump -u username -p school_management_system > backup_$(date +%Y%m%d).sql
```

**File backup:**

```bash
tar -czf sms_backup_$(date +%Y%m%d).tar.gz /path/to/msms
```

**Automated backups (cron):**

```bash
# Daily at 2 AM
0 2 * * * /path/to/backup_script.sh
```

---

## 📱 Mobile Access

The system is responsive and works on:
- ✅ Desktop computers
- ✅ Tablets
- ✅ Smartphones
- ✅ All modern browsers

**Recommended browsers:**
- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)

---

## 🆘 Support & Help

### **Common Issues:**

**Issue:** "Access denied for user"
- Check database credentials
- Verify user has permissions

**Issue:** "Table doesn't exist"
- Import all SQL files
- Check database name correct

**Issue:** "Cannot upload files"
- Create upload directories
- Set correct permissions

**Issue:** "Session expired"
- Increase session timeout
- Check server time

---

## 📚 Additional Resources

### **Documentation Files:**
- `README.md` - Overview
- `SYSTEM_OVERVIEW.md` - Complete features
- `USER_MANAGEMENT_SYSTEM.md` - User guide
- `EXAM_MARKS_SYSTEM.md` - Exam system
- `FEES_TIMETABLE_SYSTEM.md` - Fees & timetable
- `TERM_CURRENCY_UPDATE.md` - Terms & currency

### **Database Files:**
- `database/schema.sql` - Main schema
- `database/library_tables.sql` - Library tables
- `database/terms_table.sql` - Terms table
- `database/add_indexes_corrected.sql` - Performance indexes

---

## ✅ Installation Checklist

- [ ] PHP 7.4+ installed
- [ ] MySQL/MariaDB installed
- [ ] Web server running
- [ ] Files extracted to web directory
- [ ] Database created
- [ ] All SQL files imported
- [ ] config.php configured
- [ ] Upload folders created
- [ ] Permissions set
- [ ] Super admin login works
- [ ] School created
- [ ] Admin login works
- [ ] Academic term set
- [ ] Test users created
- [ ] File uploads working
- [ ] All features tested

---

## 🎉 Installation Complete!

**Your School Management System is now ready to use!**

**Next Steps:**
1. Login as Super Admin
2. Create your school
3. Set up academic term
4. Add classes and subjects
5. Add teachers and students
6. Start managing your school!

---

**Version:** 1.9.0  
**Status:** Production Ready ✅  
**Support:** Check documentation files  
**Updates:** Regular updates available  

---

**Happy School Management! 🎓✨**
