# Camera Permission Guide - QR Code Scanner

**Issue:** Camera permission denied when trying to use QR Code Scanner  
**Status:** ✅ RESOLVED with Enhanced Instructions  

---

## Quick Fix

### The Problem
When you click "Start Camera" on the QR Code Scanner page, you may see:
```
❌ Camera Permission Denied
To enable camera...
```

This means your browser hasn't been given permission to access your camera.

### The Solution (Quick Steps)

**For Chrome/Edge:**
1. Click the camera icon 📷 in the address bar (right side)
2. Click "Reset permissions for this site" 
3. Select "Allow"
4. Refresh the page (Ctrl+R)

**For Firefox:**
1. Click the lock icon 🔒 in the address bar
2. Click the dropdown next to "Camera"
3. Select "Allow"
4. Refresh the page

**For Safari:**
1. Go to Safari menu → Settings/Preferences
2. Click "Websites" tab
3. Click "Camera" in the left sidebar
4. Find your school domain → Select "Allow"
5. Refresh the page

---

## Browser-Specific Instructions

### Google Chrome

#### Step 1: Open QR Scanner
- Go to Teacher → QR Code Scanner
- Click "Start Camera"
- You should see a permission prompt

#### Step 2: Grant Permission
If you see a popup asking "Do you want yourdomain.com to access your camera?":
- Click "Allow" button
- Camera should start immediately

#### Step 3: If No Popup Appears
- Look for the camera icon 📷 in the address bar (right side, next to the search icon)
- Click it
- Click the dropdown arrow
- Select "Always allow on this site"
- Refresh the page (Ctrl+R or F5)

#### Step 4: If Still Denied
- Click the camera icon 📷 in the address bar
- Click "Reset permissions for this site"
- Refresh the page (F5)
- Try "Start Camera" again
- Click "Allow" when prompted

---

### Mozilla Firefox

#### Step 1: Open QR Scanner
- Go to Teacher → QR Code Scanner
- Click "Start Camera"
- Look for a permission bar (usually at the top or bottom)

#### Step 2: Grant Permission
If you see a permission notification:
- Click "Allow" or "Remember this decision"
- Camera should start

#### Step 3: If No Notification Appears
- Look for the lock icon 🔒 in the address bar (left side)
- Click it
- You should see a dropdown menu with permissions
- Find "Camera" and click the dropdown
- Select "Allow"
- Refresh the page (Ctrl+R or F5)

#### Step 4: If Still Denied
- Click the lock icon 🔒
- Look for "Permissions" section
- Find "Camera" - if it shows a blocked icon, click "x" to reset
- Refresh the page
- Try "Start Camera" again

---

### Apple Safari

#### Step 1: Camera Permission Settings
Safari handles permissions differently than other browsers.

**On macOS:**
1. Click "Safari" menu at the top left
2. Click "Settings..." or "Preferences..."
3. Click the "Websites" tab
4. Click "Camera" in the left sidebar
5. Find your school domain (e.g., schoolname.edu)
6. Change the dropdown from "Deny" to "Allow"
7. Close settings

**On iPad/iPhone:**
1. Go to Settings app
2. Scroll down and find "Safari"
3. Tap "Safari"
4. Scroll down to "Camera Access"
5. Make sure it's turned ON (green toggle)
6. Or check: Settings → Privacy → Camera → Make sure Safari is allowed

#### Step 2: Refresh and Try Again
- Go back to QR Code Scanner
- Refresh the page (Cmd+R)
- Click "Start Camera"
- Camera should now work

---

### Microsoft Edge

#### Step 1: Grant Permission
- Go to Teacher → QR Code Scanner
- Click "Start Camera"
- You should see a permission popup

#### Step 2: Allow Permission
- Click "Allow" button in the popup
- Camera should start immediately

#### Step 3: If No Popup
- Click the camera icon 📷 in the address bar (right side)
- Click the dropdown arrow
- Select "Allow for this site"
- Refresh the page

#### Step 4: If Still Denied
- Click the camera icon 📷
- Click "Reset permissions for this site"
- Refresh the page (F5)
- Try again

---

## What If None of These Work?

### Check Your Camera Hardware
1. **Windows:**
   - Open Camera app from Start menu
   - Make sure camera opens and shows video
   - If camera app doesn't work, your camera might be disabled or broken

2. **Mac:**
   - Open Photo Booth app (Applications → Utilities)
   - Check if camera appears
   - If not, camera might be disabled

3. **Check if Another App is Using Camera:**
   - Close Zoom, Google Meet, Discord, OBS, or any other video conferencing apps
   - These apps lock the camera so other programs can't use it

### Check Browser Settings

**Chrome/Edge:**
- Click 3 dots (menu) → Settings → Privacy and security → Site settings → Camera
- Look for your school domain
- If it's set to "Block", click it and change to "Allow"

**Firefox:**
- Type `about:preferences#privacy` in address bar
- Scroll to "Permissions" section
- Click "Settings..." next to "Camera"
- Look for your school domain
- If it's blocked, remove it from the list

**Safari:**
- Safari Menu → Settings → Websites → Camera
- Find your school domain and set to "Allow"

### Clear Browser Cache and Cookies

1. **Chrome/Edge:**
   - Press Ctrl+Shift+Delete
   - Select "All time" for time range
   - Check "Cookies and other site data"
   - Click "Clear data"
   - Refresh the page

2. **Firefox:**
   - Press Ctrl+Shift+Delete
   - Click "Clear Now"
   - Refresh the page

3. **Safari:**
   - Safari Menu → Settings → Privacy
   - Click "Manage Website Data..."
   - Find your school domain
   - Click "Remove"
   - Refresh the page

---

## Alternative: Use Bulk Attendance Instead

If you can't get the camera working, use **Bulk Attendance** instead:

1. Go to Teacher menu
2. Click "Bulk Attendance"
3. No camera needed - just type attendance manually
4. Select date and class
5. Mark students present/absent/late
6. Click save

**Advantages of Bulk Attendance:**
- ✅ No camera permission needed
- ✅ Works on any device
- ✅ No internet required
- ✅ Can edit multiple students at once
- ✅ Works if your device has no camera

---

## Tips & Troubleshooting

| Problem | Solution |
|---------|----------|
| Camera starts but no video | Check if device camera is physically working (try Camera app first) |
| "Camera already in use" error | Close Zoom/Meet/Discord/other video apps first |
| Permission keeps getting denied | Try using an incognito/private browser window |
| Works in incognito but not normal | Clear browser cache and cookies |
| Still doesn't work after all steps | Use Bulk Attendance instead (no camera needed) |
| Camera works but QR code not scanning | Make sure QR code is clearly visible and well-lit |
| QR code scans but nothing happens | Check your internet connection |

---

## Browser Compatibility

| Browser | QR Scanner Support | Notes |
|---------|-------------------|-------|
| Chrome | ✅ Full Support | Best performance, easy permissions |
| Firefox | ✅ Full Support | Reliable, similar to Chrome |
| Safari | ✅ Full Support | Requires settings change first |
| Edge | ✅ Full Support | Similar to Chrome |
| Opera | ✅ Full Support | Chromium-based |
| Mobile Chrome | ✅ Full Support | Works on Android phones |
| Mobile Safari | ✅ Full Support | Works on iPhones/iPads |

---

## Security Note

Camera access is a privacy feature:
- Your browser asks permission specifically for QR Scanner
- You control what permission you give
- Permissions apply only to this school domain
- You can revoke permission anytime by changing browser settings
- No recordings are made - only real-time camera feed for QR scanning

---

## Still Having Issues?

**Contact your IT Support with:**
1. Your browser name and version
2. Operating system (Windows/Mac/Android/iOS)
3. The exact error message you see
4. What steps you've already tried
5. Whether other camera apps work on your device

---

## Summary

**TL;DR:**
1. Look for camera icon 📷 or lock 🔒 in your address bar
2. Click it and set camera to "Allow"
3. Refresh page
4. Try again
5. If still doesn't work, use Bulk Attendance instead (no camera needed)

---

**Status:** ✅ Enhanced Instructions Added to QR Scanner Page

The page now:
- Detects which browser you're using
- Shows browser-specific instructions automatically
- Provides a "Reload Page" button for easy refresh
- Links to Bulk Attendance as fallback
- Checks camera permission on page load

