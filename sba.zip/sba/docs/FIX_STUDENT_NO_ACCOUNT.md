# Fix: Students Without User Accounts

**Problem:** Student shows "⚠️ No user account linked"  
**Result:** Student cannot log in  
**Solution:** Use automated fix tool

---

## What This Means

**Student Record Exists:**
```
✅ Admission Number: AMSS/2025/0002
✅ Name: John Doe
✅ Class: Primary 1
```

**User Account Missing:**
```
❌ No user_id linked
❌ Cannot log in
❌ No username/password
```

---

## Quick Fix (Automated)

### **Step 1: Run Fix Tool**

Open in your browser:
```
http://localhost/sba/fix-missing-student-accounts.php
```

### **Step 2: Review Students**

The tool will show:
- List of all students without accounts
- Their admission numbers
- Their names and classes

### **Step 3: Click "Create Accounts"**

The tool will:
- ✅ Create user accounts automatically
- ✅ Generate usernames (admission number)
- ✅ Set password to: `student123`
- ✅ Link accounts to students
- ✅ Display all credentials

### **Step 4: Save Credentials**

Print or copy the credentials:
```
Username: amss/2025/0002
Password: student123
```

Give these to the student!

---

## Manual Fix (If Needed)

If you prefer to fix manually:

### **Option 1: Edit Student in Admin Panel**

1. Go to: **Admin > Students**
2. Find student: **AMSS/2025/0002**
3. Click **Edit** button
4. Fill in all required fields
5. Click **Save**
6. System will auto-create user account

### **Option 2: Add Student Fresh**

1. Go to: **Admin > Students**
2. Click **Add Student**
3. Enter all details:
   - First Name
   - Last Name
   - Class
   - Email (required for user account)
4. Save
5. User account created automatically

---

## Why This Happens

**Common Causes:**

1. **Old Database Import**
   - Student data imported from old system
   - User accounts not created during import

2. **Manual Database Entry**
   - Someone added student directly in database
   - Skipped user account creation

3. **Failed Account Creation**
   - Error occurred during student registration
   - Student record saved, user account didn't

4. **Deleted User Account**
   - User account was deleted
   - Student record remains

---

## How User Accounts Work

**Students Table:**
```sql
students
├── student_id (Primary Key)
├── admission_number (AMSS/2025/0002)
├── first_name
├── last_name
├── class_id
├── user_id (Link to users table) ← THIS IS MISSING!
```

**Users Table:**
```sql
users
├── user_id (Primary Key)
├── username (for login)
├── password_hash (encrypted)
├── role (student)
├── email
```

**The Link:**
```
students.user_id → users.user_id
If user_id is NULL → No account → Can't login
```

---

## Default Credentials Generated

**Username Format:**
```
Admission Number (lowercase)
Example: amss/2025/0002
```

**Password:**
```
student123 (for all students)
```

**First Login:**
- Students should change password immediately
- Prompt them to update their profile

---

## Verification

### **After Creating Account:**

1. **Check Student List**
   - Go to: Admin > Students
   - Find: AMSS/2025/0002
   - Should show: Username instead of "No account"

2. **Test Login**
   ```
   1. Open: http://localhost/sba/login.php
   2. Username: amss/2025/0002
   3. Password: student123
   4. Should login successfully
   ```

3. **Check Database**
   ```sql
   SELECT s.admission_number, s.user_id, u.username, u.role
   FROM students s
   LEFT JOIN users u ON s.user_id = u.user_id
   WHERE s.admission_number = 'AMSS/2025/0002';
   
   -- Should show:
   -- admission_number | user_id | username        | role
   -- AMSS/2025/0002  | 123     | amss/2025/0002 | student
   ```

---

## Prevention

**To Prevent This Issue:**

### **1. Always Use Admin Panel**
```
✅ Add students through: Admin > Students > Add Student
❌ Don't add directly to database
```

### **2. Require Email**
```
Email is required for user account creation
Make sure every student has a unique email
```

### **3. Validate After Import**
```
After bulk import:
1. Go to: Admin > Students
2. Check for "No user account" warnings
3. Run fix tool if needed
```

### **4. Monitor System Logs**
```
Check: /logs/error.log
Look for: "Failed to create user account"
Fix issues immediately
```

---

## Troubleshooting

### **Issue 1: Tool Shows 0 Students**

**Cause:** All students already have accounts  
**Solution:** No action needed! ✅

### **Issue 2: Account Creation Fails**

**Error:** "Duplicate username"

**Solution:**
```sql
-- Check for existing username
SELECT * FROM users WHERE username = 'amss/2025/0002';

-- If exists, delete old one first
DELETE FROM users WHERE username = 'amss/2025/0002' AND user_id NOT IN (SELECT user_id FROM students);
```

### **Issue 3: Student Still Can't Login**

**Check 1: Account Status**
```sql
SELECT username, status FROM users WHERE username = 'amss/2025/0002';
-- Status should be: active
```

**Check 2: Password**
```
Default: student123
Try password reset if needed
```

**Check 3: Role**
```sql
SELECT username, role FROM users WHERE username = 'amss/2025/0002';
-- Role should be: student
```

---

## Bulk Operations

### **Fix All Students at Once:**

1. Open tool: `http://localhost/sba/fix-missing-student-accounts.php`
2. Click: **Create X User Account(s)**
3. Wait for completion
4. Print/save all credentials
5. Distribute to students

### **Export Credentials to CSV:**

Run this SQL:
```sql
SELECT 
    s.admission_number,
    CONCAT(s.first_name, ' ', s.last_name) as name,
    c.class_name,
    u.username,
    'student123' as password
FROM students s
INNER JOIN users u ON s.user_id = u.user_id
LEFT JOIN classes c ON s.class_id = c.class_id
WHERE s.school_id = 1
ORDER BY c.class_name, s.admission_number;

-- Export to CSV and print for distribution
```

---

## Security Notes

**Default Password:**
- All students get: `student123`
- NOT SECURE for long-term use
- Students MUST change on first login

**Best Practices:**
1. ✅ Enable "Force Password Change" on first login
2. ✅ Set password expiry (90 days)
3. ✅ Require strong passwords
4. ✅ Email credentials securely
5. ❌ Don't write passwords on paper (if possible)

---

## Summary

**Problem:**
```
⚠️ No user account linked
Student: AMSS/2025/0002
```

**Solution:**
```
1. Open: http://localhost/sba/fix-missing-student-accounts.php
2. Click: Create User Accounts
3. Save credentials
4. Give to students
✅ Fixed!
```

**Result:**
```
✅ User account created
✅ Username: amss/2025/0002
✅ Password: student123
✅ Student can log in
```

---

**Need Help?** Contact system administrator
