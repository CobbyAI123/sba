# 🚀 Production Deployment Guide

## Pre-Deployment Checklist

### ✅ Security Configuration

#### 1. Environment Variables
```bash
# Create .env file from template
cp .env.example .env

# Update with production values
nano .env
```

Required environment variables:
- `APP_ENV=production`
- `DB_HOST`, `DB_USER`, `DB_PASS`, `DB_NAME`
- `PAYSTACK_PUBLIC_KEY`, `PAYSTACK_SECRET_KEY`
- `APP_URL` (your production URL)

#### 2. Database Setup
```sql
-- Import main schema
mysql -u root -p < database/schema.sql

-- Apply security updates
mysql -u root -p < database/security_updates.sql
```

#### 3. File Permissions
```bash
# Set proper permissions
chmod 755 /path/to/msms
chmod 755 /path/to/msms/uploads
chmod 755 /path/to/msms/logs
chmod 644 /path/to/msms/.htaccess
chmod 600 /path/to/msms/.env
chmod 600 /path/to/msms/config.php

# Ensure Apache can write to uploads and logs
chown -R www-data:www-data /path/to/msms/uploads
chown -R www-data:www-data /path/to/msms/logs
```

#### 4. Enable HTTPS
Update `.htaccess`:
```apache
# Uncomment these lines
<IfModule mod_rewrite.c>
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
</IfModule>
```

Update `config.php`:
```php
define('APP_URL', 'https://yourdomain.com/msms');
```

#### 5. Error Handling
Verify `config.php` has:
```php
define('APP_ENV', 'production');
```

This will:
- ✅ Disable error display
- ✅ Enable error logging to `/logs/error.log`
- ✅ Hide sensitive information

---

## Security Hardening

### ✅ Implemented Features

1. **CSRF Protection** ✅
   - Token generation and validation
   - All forms protected

2. **Session Security** ✅
   - Session regeneration on login
   - Session timeout (1 hour)
   - Session fingerprinting
   - Protection against fixation

3. **Rate Limiting** ✅
   - Max 5 login attempts
   - 15-minute lockout period
   - IP-based tracking

4. **Password Policy** ✅
   - Minimum 8 characters
   - Requires uppercase, lowercase, number, special char
   - Bcrypt hashing

5. **File Upload Security** ✅
   - MIME type validation
   - File size limits (5MB)
   - Proper permissions (0644)
   - Secure file naming

6. **SQL Injection Prevention** ✅
   - PDO prepared statements
   - Input sanitization

7. **XSS Protection** ✅
   - HTML entity encoding
   - Content Security Policy headers

8. **Security Headers** ✅
   - X-Content-Type-Options
   - X-Frame-Options
   - X-XSS-Protection
   - Referrer-Policy
   - Content-Security-Policy
   - Permissions-Policy

---

## Database Optimizations

### Indexes Applied
```sql
-- Performance indexes
ALTER TABLE students ADD INDEX idx_school_class (school_id, class_id);
ALTER TABLE students ADD INDEX idx_admission (admission_number);
ALTER TABLE attendance ADD INDEX idx_date (date);
ALTER TABLE attendance ADD INDEX idx_student (student_id);
ALTER TABLE payments ADD INDEX idx_status_date (status, payment_date);
ALTER TABLE payments ADD INDEX idx_student (student_id);
ALTER TABLE marks ADD INDEX idx_student_exam (student_id, exam_id);
ALTER TABLE notifications ADD INDEX idx_user_read (user_id, is_read);
ALTER TABLE activity_logs ADD INDEX idx_user_time (user_id, created_at);
```

### Backup Strategy
```bash
# Daily backup script
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
mysqldump -u root -p school_management_system > backup_$DATE.sql
gzip backup_$DATE.sql

# Keep last 30 days
find /backups -name "backup_*.sql.gz" -mtime +30 -delete
```

---

## Email Configuration

### SMTP Setup (Gmail Example)
```php
// In config.php or use environment variables
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'your-email@gmail.com');
define('MAIL_PASSWORD', 'your-app-password');
```

### Email Functions Available
- `send_welcome_email($user)` - New user registration
- `send_password_reset_email($user, $token)` - Password recovery
- `send_payment_confirmation_email($user, $payment)` - Payment receipts

---

## Performance Optimization

### 1. Enable OPcache
```ini
# php.ini
opcache.enable=1
opcache.memory_consumption=128
opcache.max_accelerated_files=10000
opcache.revalidate_freq=2
```

### 2. Enable Compression
Already configured in `.htaccess`:
```apache
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
</IfModule>
```

### 3. Browser Caching
Already configured in `.htaccess`:
```apache
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    # etc.
</IfModule>
```

### 4. Database Connection Pooling
Consider using persistent connections in production:
```php
PDO::ATTR_PERSISTENT => true
```

---

## Monitoring & Logging

### Error Logs
```bash
# View error logs
tail -f /path/to/msms/logs/error.log

# View Apache error logs
tail -f /var/log/apache2/error.log
```

### Activity Logs
Monitor via database:
```sql
-- Recent activities
SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 100;

-- Failed login attempts
SELECT * FROM login_attempts WHERE attempt_time > DATE_SUB(NOW(), INTERVAL 1 DAY);
```

### Performance Monitoring
```sql
-- Slow queries
SHOW PROCESSLIST;

-- Table sizes
SELECT 
    table_name,
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS "Size (MB)"
FROM information_schema.TABLES
WHERE table_schema = "school_management_system"
ORDER BY (data_length + index_length) DESC;
```

---

## Maintenance Tasks

### Daily
- ✅ Check error logs
- ✅ Monitor disk space
- ✅ Verify backups

### Weekly
- ✅ Database backup
- ✅ Review activity logs
- ✅ Check failed login attempts

### Monthly
- ✅ Clear old activity logs
- ✅ Archive old academic years
- ✅ Update student status
- ✅ Security audit

### Cleanup Scripts
```sql
-- Clear old login attempts (older than 30 days)
DELETE FROM login_attempts WHERE attempt_time < DATE_SUB(NOW(), INTERVAL 30 DAY);

-- Clear old activity logs (older than 90 days)
DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY);

-- Archive old notifications (older than 60 days)
UPDATE notifications SET is_read = 1 WHERE created_at < DATE_SUB(NOW(), INTERVAL 60 DAY);
```

---

## Troubleshooting

### Issue: Session Timeout Too Aggressive
```php
// Increase in config.php
define('SESSION_TIMEOUT', 7200); // 2 hours
```

### Issue: Login Rate Limiting Too Strict
```php
// Adjust in config.php
define('MAX_LOGIN_ATTEMPTS', 10);
define('LOGIN_LOCKOUT_TIME', 600); // 10 minutes
```

### Issue: File Upload Fails
```bash
# Check PHP settings
php -i | grep upload_max_filesize
php -i | grep post_max_size

# Update if needed
# php.ini
upload_max_filesize = 10M
post_max_size = 10M
```

### Issue: Email Not Sending
```php
// Test email configuration
$test = send_email('test@example.com', 'Test', 'Test message');
var_dump($test);

// Check PHP mail configuration
php -i | grep sendmail
```

---

## SSL Certificate Setup

### Using Let's Encrypt (Free)
```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-apache

# Get certificate
sudo certbot --apache -d yourdomain.com

# Auto-renewal
sudo certbot renew --dry-run
```

---

## Load Balancing (Optional)

For high-traffic deployments:

1. **Database Replication**
   - Master-slave setup
   - Read replicas

2. **Application Servers**
   - Multiple Apache instances
   - Load balancer (HAProxy/Nginx)

3. **Session Storage**
   - Redis/Memcached for sessions
   - Shared session storage

---

## Security Checklist

- [x] CSRF protection enabled
- [x] Error display disabled in production
- [x] Session security implemented
- [x] Rate limiting active
- [x] Password policy enforced
- [x] File upload validation
- [x] Security headers configured
- [x] HTTPS enabled
- [x] Environment variables used
- [x] Custom error pages
- [x] Logs directory protected
- [x] Database credentials secured
- [x] File permissions set correctly
- [x] Backups automated
- [x] Monitoring configured

---

## Post-Deployment

### 1. Change Default Credentials
```sql
-- Update superadmin password
UPDATE users 
SET password_hash = ? 
WHERE username = 'superadmin';
```

### 2. Test All Features
- [ ] Login/Logout
- [ ] Student management
- [ ] Payment processing
- [ ] Email notifications
- [ ] File uploads
- [ ] Reports generation

### 3. Monitor First 24 Hours
- Check error logs frequently
- Monitor server resources
- Test from different devices
- Verify email delivery

---

## Support & Maintenance

### Regular Updates
- Keep PHP updated
- Update dependencies
- Security patches
- Feature enhancements

### Documentation
- Keep deployment notes
- Document customizations
- Maintain change log

---

## Emergency Procedures

### Site Down
1. Check Apache status: `systemctl status apache2`
2. Check error logs
3. Verify database connection
4. Check disk space: `df -h`

### Database Corruption
1. Stop Apache
2. Restore from backup
3. Verify data integrity
4. Restart services

### Security Breach
1. Take site offline immediately
2. Change all passwords
3. Review activity logs
4. Restore from clean backup
5. Patch vulnerability
6. Notify users if needed

---

## Performance Benchmarks

### Expected Performance
- Page load: < 2 seconds
- Database queries: < 100ms
- File uploads: < 5 seconds
- Report generation: < 10 seconds

### Optimization Targets
- 99.9% uptime
- < 1% error rate
- < 500ms average response time

---

**Deployment Status: Production Ready ✅**

*Last Updated: 2024*
*Version: 1.0.0*
