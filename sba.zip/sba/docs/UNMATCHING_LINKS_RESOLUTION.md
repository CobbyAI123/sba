# Unmatching Links Resolution Guide

**Generated**: 2025-12-17  
**Analysis Tool**: `link_checker.php`

## Executive Summary

I've analyzed the entire School Management System and identified **9 missing files** out of **139 total references** in the sidebar navigation. This represents a **93.5% completion rate**, with issues concentrated in two specific roles:

- **Super Admin**: 4 missing files
- **Bookstore**: 5 missing files (entire module missing)

---

## Detailed Findings

### 1. Super Admin Role (4 Missing Files)

#### Missing Files:
1. **bulk_add_schools.php** - Root level
2. **analytics.php** - super-admin folder
3. **reports.php** - super-admin folder  
4. **settings.php** - super-admin folder

#### Impact:
- Users cannot access bulk school addition functionality
- No analytics dashboard for super admins
- Missing general reports page
- Cannot configure super admin-specific settings

---

### 2. Bookstore Role (5 Missing Files - Complete Module)

#### Missing Files:
1. **dashboard.php** - bookstore folder
2. **items.php** - bookstore folder
3. **sales.php** - bookstore folder
4. **reports.php** - bookstore folder
5. **stock-reports.php** - bookstore folder

#### Impact:
- **Entire bookstore module is non-functional**
- No bookstore directory exists in the system
- This appears to be a planned feature that was never implemented

---

## Recommended Solutions

### Option 1: Quick Fix - Remove Non-Existent Links (Recommended for Immediate Use)

Remove the missing menu items from `includes/sidebar.php` to prevent users from encountering broken links.

#### For Super Admin Role:
```php
// REMOVE or COMMENT OUT these lines in the super_admin menu section:

// Remove bulk_add_schools if not needed
['icon' => 'fa-plus-circle', 'text' => 'Bulk Add Schools', 'url' => '../bulk_add_schools.php']

// Remove analytics if no analytics page exists
['icon' => 'fa-chart-bar', 'text' => 'Analytics', 'url' => 'analytics.php'],

// Remove reports if not implemented
['icon' => 'fa-file-alt', 'text' => 'Reports', 'url' => 'reports.php']

// Remove settings if using admin settings instead
['icon' => 'fa-cog', 'text' => 'Settings', 'url' => 'settings.php'],
```

#### For Bookstore Role:
```php
// REMOVE the entire bookstore section from sidebar.php
// Or comment it out until the module is developed
```

---

### Option 2: Create Missing Files (For Full Implementation)

Create the missing files to complete the functionality.

#### A. Super Admin Files

##### 1. Create `bulk_add_schools.php` (Root level)
```php
<?php
require_once 'config.php';
requireLogin('super_admin');

$page_title = "Bulk Add Schools";
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1>Bulk Add Schools</h1>
    </div>
    
    <div class="card">
        <div class="card-body">
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Upload CSV File</label>
                    <input type="file" name="schools_csv" class="form-control" accept=".csv" required>
                    <small class="text-muted">Format: school_name, school_code, address, phone, email</small>
                </div>
                <button type="submit" name="bulk_upload" class="btn btn-primary">
                    <i class="fas fa-upload"></i> Upload Schools
                </button>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
```

##### 2. Create `super-admin/analytics.php`
```php
<?php
require_once '../config.php';
requireLogin('super_admin');

$page_title = "Analytics Dashboard";
include '../includes/header.php';
include '../includes/sidebar.php';

// Get statistics
$total_schools = $conn->query("SELECT COUNT(*) FROM schools")->fetchColumn();
$total_users = $conn->query("SELECT COUNT(*) FROM users")->fetchColumn();
$active_schools = $conn->query("SELECT COUNT(*) FROM schools WHERE status = 'active'")->fetchColumn();
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1>Analytics Dashboard</h1>
    </div>
    
    <div class="row">
        <div class="col-md-3">
            <div class="stats-card">
                <h3><?php echo $total_schools; ?></h3>
                <p>Total Schools</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card">
                <h3><?php echo $active_schools; ?></h3>
                <p>Active Schools</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card">
                <h3><?php echo $total_users; ?></h3>
                <p>Total Users</p>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
```

##### 3. Create `super-admin/reports.php`
```php
<?php
require_once '../config.php';
requireLogin('super_admin');

$page_title = "System Reports";
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1>System Reports</h1>
    </div>
    
    <div class="card">
        <div class="card-body">
            <h3>Available Reports</h3>
            <div class="list-group">
                <a href="?report=schools" class="list-group-item">
                    <i class="fas fa-school"></i> Schools Report
                </a>
                <a href="?report=users" class="list-group-item">
                    <i class="fas fa-users"></i> Users Report
                </a>
                <a href="?report=activity" class="list-group-item">
                    <i class="fas fa-history"></i> Activity Report
                </a>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
```

##### 4. Create `super-admin/settings.php`
```php
<?php
require_once '../config.php';
requireLogin('super_admin');

$page_title = "Super Admin Settings";
include '../includes/header.php';
include '../includes/sidebar.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle settings update
    $success = "Settings updated successfully!";
}
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1>Super Admin Settings</h1>
    </div>
    
    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="form-group">
                    <label>System Name</label>
                    <input type="text" name="system_name" class="form-control" value="School Management System">
                </div>
                
                <div class="form-group">
                    <label>Default Currency</label>
                    <select name="currency" class="form-control">
                        <option value="GHS">GHS - Ghana Cedis</option>
                        <option value="USD">USD - US Dollar</option>
                        <option value="EUR">EUR - Euro</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary">Save Settings</button>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
```

---

#### B. Bookstore Module Files

##### 1. Create Directory First
```bash
mkdir c:\xampp\htdocs\sba\bookstore
```

##### 2. Create `bookstore/dashboard.php`
```php
<?php
require_once '../config.php';
requireLogin('bookstore');

$page_title = "Bookstore Dashboard";
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1>Bookstore Dashboard</h1>
    </div>
    
    <div class="row">
        <div class="col-md-4">
            <div class="stats-card">
                <h3>0</h3>
                <p>Total Items</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stats-card">
                <h3>0</h3>
                <p>Today's Sales</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stats-card">
                <h3>GHS 0.00</h3>
                <p>Revenue</p>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
```

##### 3. Create `bookstore/items.php`
```php
<?php
require_once '../config.php';
requireLogin('bookstore');

$page_title = "Manage Items";
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1>Manage Items</h1>
        <button class="btn btn-primary" data-toggle="modal" data-target="#addItemModal">
            <i class="fas fa-plus"></i> Add Item
        </button>
    </div>
    
    <div class="card">
        <div class="card-body">
            <table class="table" id="itemsTable">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td colspan="5" class="text-center">No items found</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
```

##### 4. Create `bookstore/sales.php`, `bookstore/reports.php`, `bookstore/stock-reports.php`
Similar structure to above files, customized for sales tracking and reporting.

---

### Option 3: Hybrid Approach (Recommended)

1. **Immediate Action**: Remove bookstore links from sidebar (not implemented)
2. **Short-term**: Create essential super-admin pages (analytics, reports, settings)
3. **Long-term**: Implement full bookstore module if needed

---

## Implementation Steps

### Step 1: Clean Up Sidebar (Immediate)
```php
// Edit: includes/sidebar.php

// Remove or comment out the entire bookstore section
// Lines approximately 260-280 in sidebar.php
```

### Step 2: Create Missing Super Admin Files
Create the 4 missing super-admin files using the templates above.

### Step 3: Test Navigation
1. Login as super_admin
2. Click each menu item
3. Verify all links work
4. Check for any console errors

### Step 4: Update Documentation
Update system documentation to reflect actual available features.

---

## Prevention Strategy

### 1. Implement File Existence Checks
Modify `sidebar.php` to check if files exist before displaying links:

```php
// Add this function to sidebar.php
function fileExists($url, $role) {
    $role_path = str_replace('_', '-', $role);
    if (strpos($url, '../') === 0) {
        $file_path = dirname(__DIR__) . '/' . str_replace('../', '', $url);
    } else {
        $file_path = dirname(__DIR__) . '/' . $role_path . '/' . $url;
    }
    return file_exists($file_path);
}

// Then use it in menu rendering:
<?php foreach ($items as $item): ?>
    <?php if (fileExists($item['url'], $role)): ?>
        <a href="<?php echo $base_url . '/' . $item['url']; ?>" 
           class="menu-item <?php echo ($current_page == $item['url']) ? 'active' : ''; ?>">
            <i class="fas <?php echo $item['icon']; ?>"></i>
            <span><?php echo $item['text']; ?></span>
        </a>
    <?php endif; ?>
<?php endforeach; ?>
```

### 2. Regular Link Audits
Run `link_checker.php` regularly (weekly/monthly) to catch missing files early.

### 3. Development Checklist
Before adding menu items:
- [ ] Create the target PHP file
- [ ] Test the page loads correctly
- [ ] Add to sidebar.php
- [ ] Test navigation

---

## Testing Checklist

After implementing fixes:

- [ ] Test all super-admin links
- [ ] Verify bookstore links are removed or functional
- [ ] Check error logs for 404 errors
- [ ] Test with actual user accounts
- [ ] Verify responsive design on mobile
- [ ] Check database queries work correctly
- [ ] Test form submissions

---

## Additional Recommendations

### 1. Create Error Handling
Add a custom 404 page that logs missing file access attempts:

```php
// error-404.php enhancement
error_log("404 Error: User tried to access " . $_SERVER['REQUEST_URI']);
```

### 2. Role-Based Access Control
Ensure all created files have proper role checks:
```php
requireLogin('super_admin'); // At the top of each file
```

### 3. Database Schema Check
Verify that any new features have corresponding database tables:
- Bookstore would need: `bookstore_items`, `bookstore_sales`, etc.

---

## File Creation Priority

**High Priority** (Create immediately):
1. `super-admin/analytics.php`
2. `super-admin/settings.php`

**Medium Priority** (Create if needed):
3. `super-admin/reports.php`
4. `bulk_add_schools.php`

**Low Priority** (Only if bookstore is planned):
5. All bookstore files

---

## Conclusion

The system is **93.5% functional** with links. The main issues are:
1. Missing super-admin utility pages (non-critical for daily operations)
2. Incomplete bookstore module (appears to be unfinished feature)

**Recommended Immediate Action**: 
- Remove bookstore links from sidebar
- Create super-admin analytics and settings pages
- Run link_checker.php monthly to prevent future issues

**Long-term**: 
- Implement file existence checking in sidebar
- Complete bookstore module if required
- Document all features properly

---

## Support Files

- **Analysis Tool**: `link_checker.php`
- **Detailed Report**: `LINK_CHECKER_REPORT.md`
- **This Guide**: `UNMATCHING_LINKS_RESOLUTION.md`

---

**Next Steps**: Choose an option (1, 2, or 3) and begin implementation. Test thoroughly after changes.
