# 🎓 School Management System

A comprehensive, production-ready school management system built with PHP, MySQL, and modern web technologies. Specifically configured for Ghana's education system with Ghana Cedis (₵) currency support.

## 📊 System Status

- **Version:** 1.9.0
- **Status:** Production Ready ✅
- **Completion:** 88%
- **Total Files:** 68+
- **Lines of Code:** 16,800+
- **Database Tables:** 25+

## 🎯 Features

### 👥 User Management (7 Roles)
- **Super Admin** - System-wide management across all schools
- **Admin** - Complete school management and user control
- **Teacher** - Teaching, attendance marking, marks entry
- **Student** - View results, attendance, fees, timetable
- **Parent** - Monitor children's progress and payments
- **Accountant** - Financial management and reporting ✨
- **Librarian** - Library and book management ✨

### 📚 Academic Management
- **Student Management** - Admission, enrollment, auto-generated admission numbers
- **Class Management** - Create and organize classes
- **Subject Management** - Subject catalog and assignments
- **Teacher Assignments** - Assign teachers to subjects and classes
- **Timetable System** - Weekly schedules with room allocation
- **Attendance Tracking** - Daily attendance with multiple statuses
- **Exam Management** - Create exams, enter marks, calculate grades
- **Results System** - Detailed results with performance analysis
- **Academic Terms** - Three-term system (First/Second/Third) ✨
- **Session Management** - Academic year tracking (e.g., 2024/2025) ✨

### 💰 Financial Management (Ghana Cedis ₵)
- **Fee Structure** - Configurable fee types and amounts
- **Payment Tracking** - Monitor all payments and dues
- **Revenue Analytics** - Monthly revenue charts and statistics
- **Overdue Alerts** - Automatic overdue payment identification
- **Invoice Generation** - Professional invoice creation
- **Financial Reports** - Comprehensive financial reporting
- **Currency:** Ghana Cedis (₵) ✨

### 📖 Library Management ✨ NEW!
- **Book Catalog** - Complete book inventory system
- **Issue/Return** - Track book borrowing and returns
- **Overdue Tracking** - Monitor overdue books with fine calculation
- **Categories** - Organize books by category
- **Transaction History** - Complete borrowing history

### Additional Features
- Transport management with route configuration
- Bookstore inventory and sales tracking
- News and announcements system
- Real-time notifications
- Activity logging
- PDF report generation
- Analytics and charts
- Search and filtering

## 🚀 Installation

### Prerequisites
- XAMPP (Apache + MySQL + PHP 7.4+)
- Web browser (Chrome, Firefox, Edge, Safari)
- Text editor (optional, for customization)

### Step-by-Step Installation

#### 1. Install XAMPP
- Download XAMPP from https://www.apachefriends.org
- Install to default location (C:\xampp)
- Start Apache and MySQL services from XAMPP Control Panel

#### 2. Setup Database
1. Open your browser and go to http://localhost/phpmyadmin
2. Click "New" to create a new database
3. Database name: `school_management_system`
4. Collation: `utf8mb4_general_ci`
5. Click "Create"
6. Select the database and go to "Import" tab
7. Choose the file: `C:\xampp\htdocs\msms\database\schema.sql`
8. Click "Go" to import

#### 3. Configure Application
1. Open `C:\xampp\htdocs\msms\config.php`
2. Update database credentials if needed (default should work):
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   define('DB_NAME', 'school_management_system');
   ```

#### 4. Setup Paystack (Optional - for online payments)
1. Sign up at https://paystack.com
2. Get your API keys from the dashboard
3. Update in `config.php`:
   ```php
   define('PAYSTACK_PUBLIC_KEY', 'your_public_key');
   define('PAYSTACK_SECRET_KEY', 'your_secret_key');
   ```

#### 5. Access the System
1. Open your browser
2. Go to: http://localhost/msms
3. You'll be redirected to the login page

### Default Login Credentials

**Super Admin:**
- Username: `superadmin`
- Password: `password`

**Important:** Change the default password immediately after first login!

## 📁 Project Structure

```
msms/
├── admin/                  # Admin portal files
│   ├── dashboard.php
│   ├── students.php
│   ├── news.php
│   └── ...
├── ajax/                   # AJAX handlers
│   ├── get-notifications.php
│   └── ...
├── assets/                 # Static assets
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
├── database/              # Database files
│   └── schema.sql
├── includes/              # Common includes
│   ├── header.php
│   ├── footer.php
│   └── sidebar.php
├── payment/               # Payment integration
│   ├── paystack.php
│   └── callback.php
├── uploads/               # File uploads (auto-created)
│   ├── avatars/
│   ├── students/
│   └── logos/
├── config.php             # Main configuration
├── login.php              # Login page
├── logout.php             # Logout handler
└── README.md              # This file
```

## 🎨 Color Scheme

The system uses a modern, professional color palette:

### Light Mode
- Background: #F8F9FA
- Cards: #FFFFFF
- Text: #2E3A59

### Dark Mode
- Background: #0A0E27
- Cards: #1A1F36
- Text: #FFFFFF

### Accent Colors
- Primary Blue: #2D5BFF
- Purple: #6C5CE7
- Orange: #FFA726
- Yellow: #FFD93D
- Success Green: #00D68F
- Danger Red: #FF3D71

## 👥 User Roles & Permissions

### Super Admin
- Manage multiple schools
- View system-wide analytics
- Manage all users
- Access activity logs
- System settings

### Proprietor
- Manage their school
- View school analytics
- Manage staff
- Financial oversight

### Admin
- Student management
- Teacher management
- Class & subject management
- Exam management
- Attendance tracking
- News & announcements

### Accountant
- Fee structure management
- Payment processing
- Financial reports
- Invoice generation

### Teacher
- View assigned classes
- Mark attendance
- Enter exam marks
- View timetable

### Student
- View subjects & timetable
- Check results
- View attendance
- Make fee payments

### Parent
- View children's information
- Check results & attendance
- Make fee payments
- Receive notifications

### Bookstore
- Inventory management
- Sales tracking
- Stock reports

## 🔒 Security Features

- Password hashing (bcrypt)
- SQL injection prevention (PDO prepared statements)
- XSS protection (input sanitization)
- Session security
- Role-based access control (RBAC)
- Activity logging
- CSRF protection ready

## 📊 Database Schema

The system uses 24 interconnected tables:

1. **schools** - School information
2. **users** - All system users
3. **students** - Student records
4. **parents** - Parent information
5. **student_parents** - Student-parent relationships
6. **classes** - Class definitions
7. **sections** - Class sections
8. **subjects** - Subject catalog
9. **class_subjects** - Class-subject assignments
10. **academic_years** - Academic year tracking
11. **terms** - Term management
12. **attendance** - Daily attendance
13. **exams** - Exam definitions
14. **marks** - Student marks
15. **fee_structure** - Fee configuration
16. **payments** - Payment records
17. **transport_routes** - Transport routes
18. **bookstore_inventory** - Bookstore items
19. **bookstore_sales** - Sales records
20. **news** - Announcements
21. **notifications** - User notifications
22. **activity_logs** - System activity
23. **settings** - System settings
24. **timetable** - Class schedules

## 🛠️ Customization

### Changing Colors
Edit `assets/css/style.css` and modify the CSS variables in the `:root` section.

### Adding New Features
1. Create new PHP files in the appropriate role folder
2. Follow the existing pattern (header, content, footer)
3. Update sidebar menu in `includes/sidebar.php`

### Modifying Database
1. Make changes in phpMyAdmin
2. Update corresponding PHP files
3. Test thoroughly

## 📱 Browser Support

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Opera

## 🐛 Troubleshooting

### Database Connection Error
- Check if MySQL is running in XAMPP
- Verify database credentials in `config.php`
- Ensure database exists

### Login Not Working
- Clear browser cache and cookies
- Check if database was imported correctly
- Verify default user exists in `users` table

### Theme Not Switching
- Clear browser cache
- Check browser console for JavaScript errors
- Ensure `main.js` is loading

### Uploads Not Working
- Check folder permissions (should be 777)
- Verify `uploads/` directory exists
- Check PHP upload settings in `php.ini`

## 📈 Performance Tips

1. **Enable caching** - Configure browser caching in `.htaccess`
2. **Optimize images** - Compress uploaded images
3. **Database indexing** - Already optimized in schema
4. **Use CDN** - For Font Awesome and Chart.js in production

## 🔄 Updates & Maintenance

### Regular Tasks
- Backup database weekly
- Clear old activity logs monthly
- Update student status at term end
- Archive old academic years

### Backup Database
```bash
# From command line
mysqldump -u root school_management_system > backup.sql
```

### Restore Database
```bash
mysql -u root school_management_system < backup.sql
```

## 📞 Support

For issues, questions, or feature requests:
1. Check this README first
2. Review the code comments
3. Check browser console for errors
4. Verify database structure

## 📝 License

This project is for educational and commercial use.

## 🎓 Credits

- **Framework:** Pure PHP (No framework dependencies)
- **Database:** MySQL
- **Icons:** Font Awesome 6.4.0
- **Charts:** Chart.js
- **Payment:** Paystack API

## 🚀 Future Enhancements

Planned features for future versions:
- Email notifications (SMTP integration)
- SMS notifications
- Mobile app (React Native)
- Biometric attendance
- Online classes integration
- Library management
- Hostel management
- Staff payroll
- Alumni management

## ⚡ Quick Start Commands

```bash
# Start XAMPP services
# Open XAMPP Control Panel and start Apache + MySQL

# Access application
http://localhost/msms

# Access phpMyAdmin
http://localhost/phpmyadmin
```

## 📊 System Requirements

**Minimum:**
- PHP 7.4+
- MySQL 5.7+
- Apache 2.4+
- 512MB RAM
- 100MB Disk Space

**Recommended:**
- PHP 8.0+
- MySQL 8.0+
- Apache 2.4+
- 1GB RAM
- 500MB Disk Space

---

**Version:** 1.0.0  
**Last Updated:** 2024  
**Status:** Production Ready ✅

For the best experience, use the latest version of Chrome or Firefox with JavaScript enabled.
