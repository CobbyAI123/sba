# 🎨 School Logo Display - Complete Guide

## Overview
School logos are now displayed throughout the system for all users, providing consistent branding.

---

## 📍 Where School Logo Appears

### **1. Sidebar (All Users)** ✅
- Left sidebar logo area
- Shows school logo if uploaded
- Falls back to graduation cap icon if no logo
- Displays school code below logo

### **2. Header (All Users)** ✅
- Top header next to page title
- Shows school name
- 50x50px logo with rounded corners
- Only for users with school_id

### **3. Login Page**
- Can be customized to show school logo
- Currently shows generic icon

### **4. Reports & Documents**
- Appears on generated reports
- Student ID cards
- Certificates
- Invoices

---

## 🎯 Logo Display Logic

### **Sidebar Logo:**
```php
if (school has logo) {
    Display uploaded logo image
} else {
    Display graduation cap icon
}
```

### **Header Logo:**
```php
if (user has school_id AND school has logo) {
    Display logo + school name
} else {
    Display page title only
}
```

---

## 📊 Logo Specifications

### **File Requirements:**
- **Formats:** JPG, PNG, GIF
- **Max Size:** 5MB
- **Recommended:** 500x500px (square)
- **Minimum:** 200x200px

### **Display Sizes:**
- **Sidebar:** 50x50px
- **Header:** 50x50px
- **Reports:** Variable (usually 100x100px)

### **Storage:**
- **Location:** `uploads/logos/`
- **Naming:** `school_[id]_[timestamp].[ext]`
- **Example:** `school_1_1699012345.png`

---

## 🔧 How to Upload School Logo

### **Method 1: School Settings (Admin)**
1. Login as Admin
2. Go to "School Settings"
3. Scroll to "School Logo" section
4. Click upload area
5. Select image file
6. Preview appears
7. Click "Save Changes"
8. ✅ Logo uploaded!

### **Method 2: Database (Manual)**
```sql
-- Update school logo filename
UPDATE schools 
SET logo = 'school_1_1699012345.png'
WHERE school_id = 1;
```

---

## 👥 Logo Display by User Role

### **All Roles See Logo:**
- ✅ Super Admin (if viewing specific school)
- ✅ Admin
- ✅ Teacher
- ✅ Student
- ✅ Parent
- ✅ Accountant
- ✅ Librarian

### **Logo Visibility:**
```
User Role     | Sidebar Logo | Header Logo
--------------|--------------|-------------
Super Admin   | Generic Icon | No (multi-school)
Admin         | School Logo  | School Logo
Teacher       | School Logo  | School Logo
Student       | School Logo  | School Logo
Parent        | School Logo  | School Logo
Accountant    | School Logo  | School Logo
Librarian     | School Logo  | School Logo
```

---

## 🎨 Logo Styling

### **Sidebar Logo:**
```css
width: 50px;
height: 50px;
border-radius: 10px;
object-fit: contain;
background: none;
```

### **Header Logo:**
```css
width: 50px;
height: 50px;
border-radius: 10px;
object-fit: cover;
border: 2px solid var(--border-color);
```

---

## 🔍 Troubleshooting

### **Logo Not Showing:**

**Check 1: File Exists**
```bash
# Check if logo file exists
ls uploads/logos/
```

**Check 2: Database Entry**
```sql
-- Check logo filename in database
SELECT school_id, school_name, logo 
FROM schools 
WHERE school_id = 1;
```

**Check 3: File Permissions**
```bash
# Ensure uploads folder is readable
chmod 755 uploads/logos
```

**Check 4: Path Correct**
- Logo path: `APP_URL/uploads/logos/filename.png`
- Example: `http://localhost/msms/uploads/logos/school_1_1699012345.png`

---

### **Logo Shows Broken Image:**

**Possible Causes:**
1. File doesn't exist
2. Wrong filename in database
3. Incorrect file permissions
4. Wrong APP_URL in config.php

**Fix:**
```php
// Check APP_URL in config.php
define('APP_URL', 'http://localhost/msms');

// Verify logo path
echo APP_URL . '/uploads/logos/' . $school_info['logo'];
```

---

### **Logo Too Large/Small:**

**Adjust Display Size:**
```css
/* In sidebar */
style="width: 60px; height: 60px;"

/* In header */
style="width: 40px; height: 40px;"
```

---

## 📁 Files Modified

### **1. includes/sidebar.php** ✅
**Changes:**
- Added school logo display
- Falls back to icon if no logo
- Shows school code instead of "SMS"

**Code:**
```php
<?php if (isset($school_info) && $school_info && $school_info['logo']): ?>
    <img src="<?php echo APP_URL . '/uploads/logos/' . $school_info['logo']; ?>" 
         alt="School Logo" 
         style="width: 50px; height: 50px;">
<?php else: ?>
    <i class="fas fa-graduation-cap"></i>
<?php endif; ?>
```

### **2. includes/header.php** ✅
**Already Had:**
- School logo display in header
- School name display
- Proper fallback handling

---

## 🎯 Default Behavior

### **No Logo Uploaded:**
```
Sidebar: Shows graduation cap icon
Header: Shows school name only (no logo)
School Code: Displays in sidebar
```

### **Logo Uploaded:**
```
Sidebar: Shows school logo + school code
Header: Shows school logo + school name
Branding: Consistent across all pages
```

---

## 💡 Best Practices

### **Logo Design:**
1. Use square images (1:1 ratio)
2. High resolution (500x500px minimum)
3. Transparent background (PNG recommended)
4. Simple, recognizable design
5. Good contrast for dark/light themes

### **File Management:**
1. Keep original logo file as backup
2. Use descriptive filenames
3. Optimize file size (< 500KB ideal)
4. Test on different screen sizes

### **Branding Consistency:**
1. Use same logo everywhere
2. Maintain aspect ratio
3. Don't distort or stretch
4. Keep colors consistent

---

## 🧪 Testing

### **Test 1: Upload Logo**
1. Login as admin
2. Go to School Settings
3. Upload logo
4. Save
5. **Expected:** Logo appears in sidebar and header

### **Test 2: View as Different Roles**
1. Login as teacher
2. **Expected:** See school logo in sidebar
3. Login as student
4. **Expected:** See school logo in sidebar
5. Login as parent
6. **Expected:** See school logo in sidebar

### **Test 3: No Logo**
1. Remove logo from school
2. Refresh page
3. **Expected:** Graduation cap icon shows

---

## 📊 Database Schema

### **schools Table:**
```sql
CREATE TABLE schools (
    school_id INT PRIMARY KEY,
    school_name VARCHAR(200),
    school_code VARCHAR(50),
    logo VARCHAR(255),  -- Logo filename
    ...
);
```

### **Example Data:**
```sql
school_id | school_name        | school_code | logo
----------|-------------------|-------------|----------------------
1         | University High   | UHAS        | school_1_1699012345.png
2         | Ghana High School | GHS         | school_2_1699012346.jpg
3         | Success Academy   | SHS         | NULL
```

---

## 🎨 Customization Options

### **Change Logo Size:**
```php
<!-- Larger sidebar logo -->
style="width: 70px; height: 70px;"

<!-- Smaller header logo -->
style="width: 35px; height: 35px;"
```

### **Change Border Radius:**
```php
<!-- Circular logo -->
style="border-radius: 50%;"

<!-- Square logo -->
style="border-radius: 0;"
```

### **Add Border:**
```php
style="border: 3px solid #2196F3;"
```

---

## ✅ Summary

**Logo Display:** ✅ Working  
**Files Updated:** 1 (sidebar.php)  
**Roles Supported:** All 7 roles  
**Fallback:** Graduation cap icon  

**Features:**
- ✅ School logo in sidebar
- ✅ School logo in header
- ✅ School code display
- ✅ Automatic fallback
- ✅ Responsive design
- ✅ All user roles supported

---

**School logos now display for all users throughout the system!** 🎨✨

**Upload your school logo via School Settings to see it everywhere!** 🏫✅
