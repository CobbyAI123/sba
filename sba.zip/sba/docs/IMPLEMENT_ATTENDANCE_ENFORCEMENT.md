# ✅ Attendance Enforcement - Implementation Guide

## 🎯 Feature: Force Teachers to Mark Attendance Before Collecting Fees

Your system will now **require teachers to mark attendance** before they can collect canteen or bus fees.

---

## 📦 Files Created:

### 1. **includes/attendance-check.php** 
Helper functions for attendance enforcement

---

## 🔧 Implementation Steps:

### **For Canteen Fees Collection**

Edit: `accountant/collect-canteen-fees-teachers.php`

**Step 1:** Add at the top (after `require_once BASE_PATH . '/config.php';`):
```php
require_once BASE_PATH . '/includes/attendance-check.php';
```

**Step 2:** Add after getting staff list (around line 90):
```php
// Check attendance status for all staff
$attendance_status = checkStaffAttendanceStatus($db, $staff);
```

**Step 3:** Add inside payment submission (around line 20):
```php
// Enforce attendance before collection
if (!enforceAttendanceBeforeFeeCollection($db, $user_id, 'canteen fee')) {
    redirect(APP_URL . '/accountant/collect-canteen-fees-teachers.php');
    exit;
}
```

**Step 4:** Add notice after header (around line 130):
```php
<?php echo displayAttendanceEnforcementNotice(); ?>
```

**Step 5:** Add column in table header:
Change from: `grid-template-columns: 2fr 1fr 1fr 1fr auto`
To: `grid-template-columns: 2fr 1fr 1fr 1fr 120px auto`

Add new column header:
```php
<div>Attendance</div>
```

**Step 6:** Add attendance badge in table rows:
```php
<div>
    <?php echo getAttendanceStatusBadge($attendance_status[$person['user_id']] ?? false); ?>
</div>
```

**Step 7:** Update collect button logic:
```php
<?php if ($attendance_status[$person['user_id']] ?? false): ?>
    <button onclick="..." class="btn btn-primary btn-sm">
        <i class="fas fa-plus"></i> Collect
    </button>
<?php else: ?>
    <button class="btn btn-secondary btn-sm" disabled title="Teacher must mark attendance first">
        <i class="fas fa-lock"></i> Locked
    </button>
<?php endif; ?>
```

---

### **For Transport/Bus Fees Collection**

Edit: `accountant/collect-transport-fees-teachers.php`

Follow the same 7 steps as above, just change "canteen fee" to "transport fee".

---

## 🧪 **Testing:**

1. **Login as teacher** who hasn't marked attendance today
2. **Try to collect fees** from that teacher
3. **Should see:**
   - Red "Not Yet" badge
   - "Locked" button (disabled)
   - Error message if trying to submit
4. **Mark attendance** for today
5. **Refresh collection page**
6. **Should now see:**
   - Green "Marked" badge
   - "Collect" button (enabled)
   - Can submit payment successfully

---

## 📤 **Upload Instructions:**

1. Upload `includes/attendance-check.php` to server
2. Edit and upload `accountant/collect-canteen-fees-teachers.php`
3. Edit and upload `accountant/collect-transport-fees-teachers.php`
4. Test on live site

---

## ⚙️ **Configuration:**

### **To disable enforcement:**
Comment out the check:
```php
// if (!enforceAttendanceBeforeFeeCollection(...)) { ... }
```

### **To exempt certain roles:**
Add in attendance-check.php:
```php
if (in_array($user['role'], ['admin', 'proprietor'])) {
    return true; // Always allow
}
```

---

## 🎯 **Benefits:**

✅ Ensures teachers fulfill attendance duties  
✅ Improves data quality  
✅ Enforces school policy  
✅ Clear visual indicators  
✅ Server-side validation (can't bypass)  

---

## 🆘 **Troubleshooting:**

**Issue:** Everyone is locked out
- Check if `attendance_logs` table exists
- Check if attendance is being marked correctly
- Add admin override temporarily

**Issue:** Some teachers show "Marked" but haven't marked today
- Check `attendance_logs.marked_at` timestamps
- Ensure date comparison uses CURDATE()

**Issue:** Errors on page load
- Check `attendance_logs` table structure
- Ensure `marked_by` and `marked_at` columns exist

---

**Status:** ✅ READY TO IMPLEMENT  
**Files:** All created and tested locally  
**Next:** Upload to live server and test!

