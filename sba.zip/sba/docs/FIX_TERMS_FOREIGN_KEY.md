# 🔧 Fix Terms Table - Foreign Key Constraint Error

## ⚠️ Error: Cannot delete or update a parent row: a foreign key constraint fails

This means other tables have foreign keys pointing to the `terms` table. We need to temporarily disable foreign key checks.

---

## ✅ **SOLUTION (Run This SQL):**

### **Complete Fix Script:**

Copy and paste this ENTIRE script in phpMyAdmin SQL tab:

```sql
-- Disable foreign key checks temporarily
SET FOREIGN_KEY_CHECKS = 0;

-- Drop and recreate terms table
DROP TABLE IF EXISTS `terms`;

CREATE TABLE `terms` (
  `term_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `term_name` varchar(100) NOT NULL,
  `session_year` varchar(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`term_id`),
  KEY `school_id` (`school_id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample terms
INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) VALUES
(1, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1),
(1, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0),
(1, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0);

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;
```

---

## 🎯 **Step-by-Step:**

### **Step 1: Open phpMyAdmin**
- Go to: `http://localhost/phpmyadmin`
- Select database: `school_management_system`

### **Step 2: Click SQL Tab**
- Click the **SQL** tab at the top

### **Step 3: Copy & Paste**
- Copy the ENTIRE script above (including SET commands)
- Paste in the SQL box
- Click **Go**

### **Step 4: Verify Success**
- Should see: "3 rows inserted" ✅
- No errors!

---

## 🔍 **What This Does:**

1. **Disables foreign key checks** - Allows us to drop the table
2. **Drops the old terms table** - Removes the problematic table
3. **Creates new terms table** - With correct structure including `school_id`
4. **Inserts sample data** - 3 academic terms
5. **Re-enables foreign key checks** - Restores database integrity

---

## ✅ **Alternative: Just Add the Column (Safer)**

If you want to keep existing data, try this instead:

```sql
-- Just add the missing column without dropping the table
ALTER TABLE `terms` 
ADD COLUMN `school_id` int(11) NOT NULL DEFAULT 1 AFTER `term_id`;

-- Add index
ALTER TABLE `terms` 
ADD INDEX `school_id` (`school_id`);

-- Update existing rows to have school_id = 1
UPDATE `terms` SET `school_id` = 1 WHERE `school_id` = 0 OR `school_id` IS NULL;

-- Insert sample terms if they don't exist
INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) 
SELECT 1, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1
WHERE NOT EXISTS (SELECT 1 FROM `terms` WHERE `term_name` = 'First Term' AND `session_year` = '2024/2025');

INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) 
SELECT 1, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0
WHERE NOT EXISTS (SELECT 1 FROM `terms` WHERE `term_name` = 'Second Term' AND `session_year` = '2024/2025');

INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) 
SELECT 1, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0
WHERE NOT EXISTS (SELECT 1 FROM `terms` WHERE `term_name` = 'Third Term' AND `session_year` = '2024/2025');
```

---

## 📋 **Which Option to Use:**

### **Use Option 1 (Drop & Recreate) if:**
- ✅ You have NO existing terms data
- ✅ This is a fresh installation
- ✅ You don't mind losing existing terms

### **Use Option 2 (Add Column) if:**
- ✅ You have existing terms data
- ✅ You want to keep current data
- ✅ You want the safer approach

---

## 🧪 **Verify After Fix:**

### **Check Table Structure:**
```sql
DESCRIBE terms;
```

Should show:
- ✅ term_id
- ✅ school_id ← Must be here!
- ✅ term_name
- ✅ session_year
- ✅ start_date
- ✅ end_date
- ✅ is_active

### **Check Data:**
```sql
SELECT * FROM terms;
```

Should show at least 3 terms with `school_id = 1`

---

## 🚨 **If Still Getting Errors:**

### **Find Foreign Key Constraints:**
```sql
SELECT 
    TABLE_NAME,
    COLUMN_NAME,
    CONSTRAINT_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM
    INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE
    REFERENCED_TABLE_NAME = 'terms';
```

This will show which tables reference the `terms` table.

---

## ✅ **Recommended Approach:**

**Try Option 2 first (Add Column)** - It's safer and keeps your data.

If that fails, use **Option 1 (Drop & Recreate)** with foreign key checks disabled.

---

## 📁 **Summary:**

**Problem:** Foreign key constraint prevents dropping table  
**Solution 1:** Disable foreign keys, drop, recreate  
**Solution 2:** Just add the missing column (safer)  
**Result:** Terms table works correctly! ✅  

---

**Use Option 2 (Add Column) - it's the safest approach!** 🎉
