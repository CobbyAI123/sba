# 🔐 Login Fix Guide - Students & Teachers

## Diagnostic Tool Created

I've created a diagnostic tool to help identify login issues.

---

## 🧪 Step 1: Run Diagnostic

1. Go to: `http://localhost/msms/test_login.php`
2. This will show you:
   - ✅ If users table exists
   - ✅ Table structure
   - ✅ User counts by role
   - ✅ Sample users with usernames
   - ✅ Password hash verification

---

## 🔍 Common Login Issues & Fixes

### **Issue 1: No Users in Database**

**Symptoms:**
- Diagnostic shows 0 teachers/students
- Login always fails

**Fix:**
1. Login as Admin
2. Go to "Teachers" → Add teachers
3. Go to "Students" → Add students
4. Default passwords will be set automatically

---

### **Issue 2: Wrong Default Passwords**

**Default Passwords:**
- **Teachers:** `teacher123`
- **Students:** `student123`
- **Admin:** `Admin@123`
- **Super Admin:** `SuperAdmin@123`

**If these don't work:**
1. Admin can reset passwords
2. Go to user management
3. Click "Reset Password" button
4. Set new password

---

### **Issue 3: Users are Inactive**

**Symptoms:**
- User exists but can't login
- No error message

**Fix:**
1. Login as Admin
2. Go to user management
3. Find the user
4. Check status is "Active"
5. If "Inactive", edit and change to "Active"

---

### **Issue 4: Wrong Username**

**Common mistakes:**
- Using full name instead of username
- Wrong email address
- Typos in username

**Fix:**
1. Run diagnostic tool
2. Check exact username from table
3. Use that exact username to login

---

## ✅ Verification Steps

### **Test Teacher Login:**
1. Run diagnostic: `test_login.php`
2. Find a teacher username
3. Go to login page
4. Enter:
   - Username: [from diagnostic]
   - Password: `teacher123`
5. Click "Sign In"
6. ✅ Should redirect to teacher dashboard

### **Test Student Login:**
1. Run diagnostic: `test_login.php`
2. Find a student username
3. Go to login page
4. Enter:
   - Username: [from diagnostic]
   - Password: `student123`
5. Click "Sign In"
6. ✅ Should redirect to student dashboard

---

## 🔧 Manual Password Reset (If Needed)

If you need to manually reset a password in the database:

```sql
-- For student with user_id = 5
UPDATE users 
SET password_hash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'
WHERE user_id = 5;
-- This sets password to: password
```

Or use PHP to generate new hash:

```php
<?php
echo password_hash('student123', PASSWORD_BCRYPT);
?>
```

---

## 📊 Database Check

### **Check if users exist:**
```sql
SELECT user_id, username, email, role, status 
FROM users 
WHERE role IN ('teacher', 'student');
```

### **Check password column:**
```sql
DESCRIBE users;
```

Should show: `password_hash VARCHAR(255)`

### **Count active users:**
```sql
SELECT role, COUNT(*) as count 
FROM users 
WHERE status = 'active' 
GROUP BY role;
```

---

## 🎯 Quick Fix Checklist

- [ ] Run `test_login.php` diagnostic
- [ ] Verify users exist in database
- [ ] Check users are "active" status
- [ ] Note exact usernames from diagnostic
- [ ] Try default passwords (teacher123/student123)
- [ ] If fails, reset password via admin panel
- [ ] Clear browser cache and try again
- [ ] Check for typos in username

---

## 💡 Creating Test Users

### **Add Test Teacher:**
1. Login as Admin
2. Go to "Teachers"
3. Click "Add Teacher"
4. Fill details:
   - First Name: John
   - Last Name: Doe
   - Email: john@school.com
   - Username: john_teacher
   - Password: teacher123
5. Submit
6. ✅ Can now login with: john_teacher / teacher123

### **Add Test Student:**
1. Login as Admin
2. Go to "Students"
3. Click "Add Student"
4. Fill details:
   - First Name: Jane
   - Last Name: Smith
   - Email: jane@school.com
   - Username: jane_student
   - Class: Select a class
5. Submit
6. ✅ Can now login with: jane_student / student123

---

## 🔐 Password Security Notes

**Password Hashing:**
- System uses `PASSWORD_BCRYPT`
- Passwords are never stored in plain text
- Each hash is unique even for same password
- Hash length should be 60 characters

**Password Requirements:**
- Minimum 8 characters (configurable)
- Mix of letters and numbers recommended
- Special characters allowed

---

## 🆘 Still Can't Login?

### **Check these:**

1. **Database Connection:**
   - Verify config.php settings
   - Check MySQL is running
   - Test database connection

2. **Session Issues:**
   - Clear browser cookies
   - Try incognito/private mode
   - Check PHP sessions enabled

3. **File Permissions:**
   - Check config.php is readable
   - Verify includes folder accessible

4. **Error Messages:**
   - Check PHP error log
   - Enable error display temporarily
   - Look for specific error messages

---

## 📝 Default Credentials Summary

| Role | Username | Password | Notes |
|------|----------|----------|-------|
| Super Admin | superadmin | SuperAdmin@123 | System-wide access |
| Admin | [school_code]_admin | Admin@123 | Auto-created with school |
| Teacher | [assigned] | teacher123 | Set when teacher added |
| Student | [assigned] | student123 | Set when student added |
| Accountant | [assigned] | [set by admin] | Manual password |
| Librarian | [assigned] | [set by admin] | Manual password |

---

## ✅ Expected Behavior

### **Successful Login:**
1. Enter valid username/password
2. Click "Sign In"
3. Page redirects to appropriate dashboard
4. User sees their dashboard with data
5. Navigation menu shows role-specific options

### **Failed Login:**
1. Error message displays
2. "Invalid username/email or password"
3. User stays on login page
4. Can try again

---

## 🎯 Summary

**Diagnostic Tool:** `test_login.php`  
**Default Teacher Password:** `teacher123`  
**Default Student Password:** `student123`  
**Password Column:** `password_hash`  
**Status Required:** `active`  

---

**Run the diagnostic tool first to identify the exact issue!** 🔍

**File:** `http://localhost/msms/test_login.php`
