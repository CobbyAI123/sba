<?php
// admin/financial-reports.php - Comprehensive Financial Reports & Analytics
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['admin', 'super_admin', 'accountant']);
$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get date range from filters (default: current month)
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');
$report_type = $_GET['report_type'] ?? 'overview';
$class_filter = $_GET['class_id'] ?? 'all';

// Get all classes for filter
$classes = [];
try {
    $stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
    $stmt->execute([$school_id]);
    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $classes = [];
}

// ===== REVENUE SUMMARY =====
$revenue_stats = [
    'total_revenue' => 0,
    'total_payments' => 0,
    'total_expected' => 0,
    'collection_rate' => 0,
    'outstanding' => 0,
    'cash_payments' => 0,
    'online_payments' => 0,
    'bank_transfers' => 0
];

try {
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total_payments,
            SUM(amount) as total_revenue,
            SUM(CASE WHEN payment_method = 'cash' THEN amount ELSE 0 END) as cash_payments,
            SUM(CASE WHEN payment_method = 'online' THEN amount ELSE 0 END) as online_payments,
            SUM(CASE WHEN payment_method = 'bank_transfer' THEN amount ELSE 0 END) as bank_transfers
        FROM payments
        WHERE school_id = ?
        AND payment_status = 'success'
        AND payment_date BETWEEN ? AND ?
    ");
    $stmt->execute([$school_id, $start_date, $end_date]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        $revenue_stats['total_payments'] = $result['total_payments'] ?? 0;
        $revenue_stats['total_revenue'] = $result['total_revenue'] ?? 0;
        $revenue_stats['cash_payments'] = $result['cash_payments'] ?? 0;
        $revenue_stats['online_payments'] = $result['online_payments'] ?? 0;
        $revenue_stats['bank_transfers'] = $result['bank_transfers'] ?? 0;
    }
} catch (PDOException $e) {
    // Keep defaults
}

// Get expected fees
try {
    $stmt = $db->prepare("
        SELECT SUM(fs.amount) as total_expected
        FROM students s
        INNER JOIN fee_structure fs ON s.class_id = fs.class_id
        WHERE s.school_id = ?
        AND s.status = 'active'
    ");
    $stmt->execute([$school_id]);
    $expected = $stmt->fetch(PDO::FETCH_ASSOC);
    $revenue_stats['total_expected'] = $expected['total_expected'] ?? 0;
} catch (PDOException $e) {
    // Keep default
}

// Calculate outstanding and collection rate
$revenue_stats['outstanding'] = $revenue_stats['total_expected'] - $revenue_stats['total_revenue'];
if ($revenue_stats['total_expected'] > 0) {
    $revenue_stats['collection_rate'] = ($revenue_stats['total_revenue'] / $revenue_stats['total_expected']) * 100;
}

// ===== DAILY COLLECTION TREND =====
$daily_collections = [];
try {
    $stmt = $db->prepare("
        SELECT 
            DATE(payment_date) as date,
            COUNT(*) as transaction_count,
            SUM(amount) as daily_total
        FROM payments
        WHERE school_id = ?
        AND payment_status = 'success'
        AND payment_date BETWEEN ? AND ?
        GROUP BY DATE(payment_date)
        ORDER BY date ASC
    ");
    $stmt->execute([$school_id, $start_date, $end_date]);
    $daily_collections = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $daily_collections = [];
}

// ===== CLASS-WISE REVENUE =====
$class_revenue = [];
try {
    $class_query = "
        SELECT 
            c.class_name,
            COUNT(DISTINCT s.student_id) as student_count,
            COUNT(p.payment_id) as payment_count,
            COALESCE(SUM(p.amount), 0) as total_collected,
            COALESCE(SUM(fs.amount), 0) as total_expected
        FROM classes c
        LEFT JOIN students s ON c.class_id = s.class_id AND s.school_id = ?
        LEFT JOIN payments p ON s.student_id = p.student_id 
            AND p.payment_status = 'success'
            AND p.payment_date BETWEEN ? AND ?
        LEFT JOIN fee_structure fs ON c.class_id = fs.class_id
        WHERE c.school_id = ?
        GROUP BY c.class_id, c.class_name
        ORDER BY c.class_name
    ";
    
    $stmt = $db->prepare($class_query);
    $stmt->execute([$school_id, $start_date, $end_date, $school_id]);
    $class_revenue = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate percentage for each class
    foreach ($class_revenue as &$class) {
        $class['collection_rate'] = 0;
        if ($class['total_expected'] > 0) {
            $class['collection_rate'] = ($class['total_collected'] / $class['total_expected']) * 100;
        }
        $class['outstanding'] = $class['total_expected'] - $class['total_collected'];
    }
} catch (PDOException $e) {
    $class_revenue = [];
}

// ===== PAYMENT METHOD BREAKDOWN =====
$payment_methods = [];
try {
    $stmt = $db->prepare("
        SELECT 
            payment_method,
            COUNT(*) as count,
            SUM(amount) as total
        FROM payments
        WHERE school_id = ?
        AND payment_status = 'success'
        AND payment_date BETWEEN ? AND ?
        GROUP BY payment_method
    ");
    $stmt->execute([$school_id, $start_date, $end_date]);
    $payment_methods = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $payment_methods = [];
}

// ===== TOP PAYERS =====
$top_payers = [];
try {
    $stmt = $db->prepare("
        SELECT 
            u.first_name, u.last_name,
            s.admission_number,
            c.class_name,
            COUNT(p.payment_id) as payment_count,
            SUM(p.amount) as total_paid
        FROM payments p
        INNER JOIN students s ON p.student_id = s.student_id
        INNER JOIN users u ON s.user_id = u.user_id
        LEFT JOIN classes c ON s.class_id = c.class_id
        WHERE p.school_id = ?
        AND p.payment_status = 'success'
        AND p.payment_date BETWEEN ? AND ?
        GROUP BY s.student_id
        ORDER BY total_paid DESC
        LIMIT 10
    ");
    $stmt->execute([$school_id, $start_date, $end_date]);
    $top_payers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $top_payers = [];
}

// ===== OUTSTANDING FEES BY STUDENT =====
$outstanding_students = [];
try {
    $stmt = $db->prepare("
        SELECT 
            u.first_name, u.last_name,
            s.admission_number,
            c.class_name,
            COALESCE(SUM(fs.amount), 0) as expected_fees,
            COALESCE(SUM(p.amount), 0) as paid_fees,
            COALESCE(SUM(fs.amount), 0) - COALESCE(SUM(p.amount), 0) as outstanding
        FROM students s
        INNER JOIN users u ON s.user_id = u.user_id
        LEFT JOIN classes c ON s.class_id = c.class_id
        LEFT JOIN fee_structure fs ON s.class_id = fs.class_id
        LEFT JOIN payments p ON s.student_id = p.student_id AND p.payment_status = 'success'
        WHERE s.school_id = ?
        AND s.status = 'active'
        GROUP BY s.student_id
        HAVING outstanding > 0
        ORDER BY outstanding DESC
        LIMIT 20
    ");
    $stmt->execute([$school_id]);
    $outstanding_students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $outstanding_students = [];
}

require_once BASE_PATH . '/includes/header.php';
?>

<style>
.stats-card {
    border-radius: 10px;
    padding: 20px;
    color: white;
    margin-bottom: 20px;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}
.stats-card h3 { font-size: 36px; font-weight: bold; margin: 10px 0; }
.stats-card p { margin: 0; opacity: 0.9; font-size: 14px; }
.chart-container { background: var(--bg-card); padding: 20px; border-radius: 10px; margin-bottom: 20px; }
.report-table { width: 100%; margin-top: 20px; }
.report-table th { background: var(--primary-blue); color: white; padding: 12px; text-align: left; }
.report-table td { padding: 10px; border-bottom: 1px solid var(--border-color); }
.progress-bar { height: 20px; background: #e0e0e0; border-radius: 10px; overflow: hidden; }
.progress-fill { height: 100%; background: linear-gradient(90deg, #10B981 0%, #059669 100%); transition: width 0.3s; }
.badge { padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: bold; }
.badge-success { background: #10B981; color: white; }
.badge-warning { background: #F59E0B; color: white; }
.badge-danger { background: #EF4444; color: white; }
.filter-section { background: var(--bg-card); padding: 20px; border-radius: 10px; margin-bottom: 20px; }
</style>

<div class="container-fluid mt-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-chart-line"></i> Financial Reports & Analytics</h2>
        <div>
            <button onclick="window.print()" class="btn btn-secondary">
                <i class="fas fa-print"></i> Print Report
            </button>
            <button onclick="exportToExcel()" class="btn btn-success">
                <i class="fas fa-file-excel"></i> Export Excel
            </button>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="filter-section">
        <form method="GET" action="" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Start Date</label>
                <input type="date" name="start_date" class="form-control" value="<?php echo $start_date; ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">End Date</label>
                <input type="date" name="end_date" class="form-control" value="<?php echo $end_date; ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Class Filter</label>
                <select name="class_id" class="form-select">
                    <option value="all">All Classes</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['class_id']; ?>" <?php echo $class_filter == $class['class_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($class['class_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">&nbsp;</label>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-filter"></i> Apply Filters
                </button>
            </div>
        </form>
    </div>

    <!-- Revenue Statistics Cards -->
    <div class="row">
        <div class="col-md-3">
            <div class="stats-card" style="background: linear-gradient(135deg, #10B981 0%, #059669 100%);">
                <p><i class="fas fa-money-bill-wave"></i> Total Revenue</p>
                <h3>GH₵ <?php echo number_format($revenue_stats['total_revenue'], 2); ?></h3>
                <small><?php echo number_format($revenue_stats['total_payments']); ?> payments</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card" style="background: linear-gradient(135deg, #3B82F6 0%, #1E3A8A 100%);">
                <p><i class="fas fa-chart-line"></i> Expected Fees</p>
                <h3>GH₵ <?php echo number_format($revenue_stats['total_expected'], 2); ?></h3>
                <small>All active students</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card" style="background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%);">
                <p><i class="fas fa-exclamation-triangle"></i> Outstanding</p>
                <h3>GH₵ <?php echo number_format($revenue_stats['outstanding'], 2); ?></h3>
                <small>Pending collection</small>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card" style="background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%);">
                <p><i class="fas fa-percentage"></i> Collection Rate</p>
                <h3><?php echo number_format($revenue_stats['collection_rate'], 1); ?>%</h3>
                <small>Payment efficiency</small>
            </div>
        </div>
    </div>

    <!-- Payment Methods Breakdown -->
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="chart-container">
                <h5><i class="fas fa-credit-card"></i> Payment Methods</h5>
                <canvas id="paymentMethodsChart" height="250"></canvas>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="chart-container">
                <h5><i class="fas fa-calendar-alt"></i> Daily Collection Trend</h5>
                <canvas id="dailyTrendChart" height="250"></canvas>
            </div>
        </div>
    </div>

    <!-- Class-wise Revenue Analysis -->
    <div class="row mt-4">
        <div class="col-12">
            <div class="chart-container">
                <h5><i class="fas fa-school"></i> Class-wise Revenue Analysis</h5>
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>Class</th>
                            <th>Students</th>
                            <th>Payments</th>
                            <th>Expected</th>
                            <th>Collected</th>
                            <th>Outstanding</th>
                            <th>Collection Rate</th>
                            <th>Progress</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($class_revenue as $class): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($class['class_name']); ?></strong></td>
                                <td><?php echo number_format($class['student_count']); ?></td>
                                <td><?php echo number_format($class['payment_count']); ?></td>
                                <td>GH₵ <?php echo number_format($class['total_expected'], 2); ?></td>
                                <td>GH₵ <?php echo number_format($class['total_collected'], 2); ?></td>
                                <td>GH₵ <?php echo number_format($class['outstanding'], 2); ?></td>
                                <td>
                                    <?php
                                    $rate = $class['collection_rate'];
                                    $badge_class = $rate >= 80 ? 'success' : ($rate >= 50 ? 'warning' : 'danger');
                                    ?>
                                    <span class="badge badge-<?php echo $badge_class; ?>">
                                        <?php echo number_format($rate, 1); ?>%
                                    </span>
                                </td>
                                <td>
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: <?php echo min($rate, 100); ?>%;"></div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Top Payers and Outstanding Students -->
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="chart-container">
                <h5><i class="fas fa-trophy"></i> Top 10 Payers</h5>
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Student</th>
                            <th>Class</th>
                            <th>Payments</th>
                            <th>Total Paid</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $rank = 1; foreach ($top_payers as $payer): ?>
                            <tr>
                                <td>
                                    <?php if ($rank <= 3): ?>
                                        <span class="badge badge-warning"><?php echo $rank; ?></span>
                                    <?php else: ?>
                                        <?php echo $rank; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($payer['first_name'] . ' ' . $payer['last_name']); ?></strong><br>
                                    <small><?php echo htmlspecialchars($payer['admission_number']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($payer['class_name']); ?></td>
                                <td><?php echo number_format($payer['payment_count']); ?></td>
                                <td><strong>GH₵ <?php echo number_format($payer['total_paid'], 2); ?></strong></td>
                            </tr>
                        <?php $rank++; endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="chart-container">
                <h5><i class="fas fa-exclamation-circle"></i> Top 20 Outstanding Students</h5>
                <table class="report-table">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Class</th>
                            <th>Expected</th>
                            <th>Paid</th>
                            <th>Outstanding</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($outstanding_students as $student): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></strong><br>
                                    <small><?php echo htmlspecialchars($student['admission_number']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($student['class_name']); ?></td>
                                <td>GH₵ <?php echo number_format($student['expected_fees'], 2); ?></td>
                                <td>GH₵ <?php echo number_format($student['paid_fees'], 2); ?></td>
                                <td><strong class="text-danger">GH₵ <?php echo number_format($student['outstanding'], 2); ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<script>
// Payment Methods Pie Chart
const paymentMethodsCtx = document.getElementById('paymentMethodsChart').getContext('2d');
new Chart(paymentMethodsCtx, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode(array_column($payment_methods, 'payment_method')); ?>,
        datasets: [{
            data: <?php echo json_encode(array_column($payment_methods, 'total')); ?>,
            backgroundColor: ['#10B981', '#3B82F6', '#F59E0B', '#EF4444'],
            borderWidth: 2,
            borderColor: '#fff'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { position: 'bottom' },
            title: { display: false }
        }
    }
});

// Daily Trend Line Chart
const dailyTrendCtx = document.getElementById('dailyTrendChart').getContext('2d');
new Chart(dailyTrendCtx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode(array_column($daily_collections, 'date')); ?>,
        datasets: [{
            label: 'Daily Revenue (GH₵)',
            data: <?php echo json_encode(array_column($daily_collections, 'daily_total')); ?>,
            borderColor: '#10B981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: true },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        return 'GH₵ ' + context.parsed.y.toFixed(2);
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'GH₵ ' + value;
                    }
                }
            }
        }
    }
});

// Export to Excel function
function exportToExcel() {
    // Get current filter values
    const startDate = document.getElementById('start_date')?.value || '';
    const endDate = document.getElementById('end_date')?.value || '';
    const type = document.getElementById('filter_type')?.value || 'all';
    
    // Build export URL with filters
    const exportUrl = `export-financial-excel.php?start_date=${startDate}&end_date=${endDate}&type=${type}`;
    
    // Trigger download
    window.location.href = exportUrl;
}
</script>

<?php require_once BASE_PATH . '/includes/footer.php'; ?>
