<?php
// admin/print-receipt.php - Generate and display payment receipt
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/pdf-generator.php';

// Check permission
$current_user = check_permission(['admin', 'super_admin', 'accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get payment ID from query string
$payment_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$payment_id) {
    die('Payment ID required');
}

// Verify payment belongs to user's school (or super admin can access all)
if ($current_user['role'] !== 'super_admin') {
    $stmt = $db->prepare("SELECT school_id FROM payments WHERE payment_id = ?");
    $stmt->execute([$payment_id]);
    $payment_school = $stmt->fetchColumn();
    
    if ($payment_school != $school_id) {
        die('Unauthorized access');
    }
}

try {
    // Initialize PDF generator
    $pdf_generator = new PDFGenerator($db, $school_id);
    
    // Generate and output receipt
    $output = $pdf_generator->generatePaymentReceipt($payment_id);
    
    // If it's HTML (fallback), output directly
    if (is_string($output)) {
        echo $output;
    }
    
} catch (Exception $e) {
    die('Error generating receipt: ' . htmlspecialchars($e->getMessage()));
}
