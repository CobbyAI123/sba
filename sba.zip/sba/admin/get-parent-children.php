<?php
// admin/get-parent-children.php - API endpoint to get parent's children
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

header('Content-Type: application/json');

$current_user = check_permission(['admin']);
$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

$parent_id = isset($_GET['parent_id']) ? (int)$_GET['parent_id'] : 0;

if ($parent_id === 0) {
    echo json_encode([]);
    exit;
}

try {
    $stmt = $db->prepare("
        SELECT 
            s.student_id,
            s.class_id,
            s.admission_number,
            u.first_name,
            u.last_name,
            c.class_name
        FROM student_parents sp
        INNER JOIN students s ON sp.student_id = s.student_id
        LEFT JOIN users u ON s.user_id = u.user_id
        LEFT JOIN classes c ON s.class_id = c.class_id
        WHERE sp.parent_id = ? AND s.school_id = ?
        ORDER BY c.class_name, u.first_name, u.last_name
    ");
    $stmt->execute([$parent_id, $school_id]);
    $children = $stmt->fetchAll();
    
    echo json_encode($children);
} catch (PDOException $e) {
    echo json_encode([]);
}
