<?php
// admin/notifications-system.php - Communication & Notification System
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Notifications System';
$current_user = check_permission(['admin', 'super-admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle notification sending
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'send_notification') {
        $recipient_type = sanitize_input($_POST['recipient_type']); // all, students, parents, teachers
        $title = sanitize_input($_POST['title']);
        $message = sanitize_input($_POST['message']);
        $notification_type = sanitize_input($_POST['notification_type']); // sms, email
        
        try {
            // Get recipient IDs based on type
            $recipients = [];
            
            if ($recipient_type === 'all') {
                $stmt = $db->prepare("SELECT user_id, email, phone FROM users WHERE school_id = ? AND status = 'active'");
                $stmt->execute([$school_id]);
            } elseif ($recipient_type === 'students') {
                $stmt = $db->prepare("SELECT u.user_id, u.email, s.phone FROM users u INNER JOIN students s ON u.user_id = s.user_id WHERE u.school_id = ? AND u.status = 'active'");
                $stmt->execute([$school_id]);
            } elseif ($recipient_type === 'parents') {
                $stmt = $db->prepare("SELECT u.user_id, u.email, p.phone FROM users u INNER JOIN parents p ON u.user_id = p.user_id WHERE u.school_id = ? AND u.status = 'active'");
                $stmt->execute([$school_id]);
            } elseif ($recipient_type === 'teachers') {
                $stmt = $db->prepare("SELECT user_id, email, phone FROM users WHERE school_id = ? AND role = 'teacher' AND status = 'active'");
                $stmt->execute([$school_id]);
            }
            
            $recipients = $stmt->fetchAll();
            
            // Send notifications
            $sent_count = 0;
            foreach ($recipients as $recipient) {
                if ($notification_type === 'email' && $recipient['email']) {
                    // Send email (placeholder - implement actual email sending)
                    send_email($recipient['email'], $title, $message);
                    $sent_count++;
                } elseif ($notification_type === 'sms' && $recipient['phone']) {
                    // Send SMS (placeholder - implement actual SMS API)
                    send_sms($recipient['phone'], $message);
                    $sent_count++;
                }
                
                // Log notification in database
                $stmt = $db->prepare("
                    INSERT INTO notifications (user_id, title, message, type, created_at)
                    VALUES (?, ?, ?, ?, NOW())
                ");
                $stmt->execute([$recipient['user_id'], $title, $message, $notification_type]);
            }
            
            log_activity($current_user['user_id'], "Sent $sent_count notifications ($notification_type)", 'notifications');
            set_message('success', "Notification sent to $sent_count recipients!");
            redirect(APP_URL . '/admin/notifications-system.php');
        } catch (Exception $e) {
            set_message('error', 'Error sending notification: ' . $e->getMessage());
        }
    }
}

// Get notification history
$stmt = $db->prepare("
    SELECT n.*, u.first_name, u.last_name
    FROM notifications n
    LEFT JOIN users u ON n.user_id = u.user_id
    WHERE u.school_id = ?
    ORDER BY n.created_at DESC
    LIMIT 20
");
$stmt->execute([$school_id]);
$notification_history = $stmt->fetchAll();

// Get statistics
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN type = 'email' THEN 1 ELSE 0 END) as email_sent,
        SUM(CASE WHEN type = 'sms' THEN 1 ELSE 0 END) as sms_sent,
        SUM(CASE WHEN is_read = true THEN 1 ELSE 0 END) as read_count
    FROM notifications
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
");
$stmt->execute([]);
$stats = $stmt->fetch();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Statistics -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-envelope"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $stats['email_sent'] ?? 0; ?></h3>
                <p>Emails Sent (30 days)</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-comment"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $stats['sms_sent'] ?? 0; ?></h3>
                <p>SMS Sent (30 days)</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-bell"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $stats['total'] ?? 0; ?></h3>
                <p>Total Notifications</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon orange">
                <i class="fas fa-eye"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $stats['read_count'] ?? 0; ?></h3>
                <p>Read</p>
            </div>
        </div>
    </div>
    
    <!-- Send Notification Form -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-paper-plane"></i> Send Notification</h3>
        </div>
        <div style="padding: 20px;">
            <form method="POST">
                <input type="hidden" name="action" value="send_notification">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                    <div class="form-group">
                        <label>Recipients *</label>
                        <select name="recipient_type" required>
                            <option value="">-- Select Recipients --</option>
                            <option value="all">All Users</option>
                            <option value="students">Students Only</option>
                            <option value="parents">Parents Only</option>
                            <option value="teachers">Teachers Only</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Notification Method *</label>
                        <select name="notification_type" required>
                            <option value="">-- Select Method --</option>
                            <option value="email">Email</option>
                            <option value="sms">SMS</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Title *</label>
                    <input type="text" name="title" required placeholder="Notification title">
                </div>
                
                <div class="form-group">
                    <label>Message *</label>
                    <textarea name="message" rows="4" required placeholder="Notification message..."></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    <i class="fas fa-paper-plane"></i> Send Notification
                </button>
            </form>
        </div>
    </div>
    
    <!-- Notification History -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-history"></i> Recent Notifications</h3>
        </div>
        <div style="max-height: 600px; overflow-y: auto;">
            <?php if (count($notification_history) > 0): ?>
                <?php foreach ($notification_history as $notif): ?>
                    <div style="padding: 15px; border-bottom: 1px solid var(--border-color);">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
                            <strong><?php echo htmlspecialchars($notif['title']); ?></strong>
                            <span class="badge badge-<?php echo $notif['type'] === 'email' ? 'info' : 'success'; ?>">
                                <?php echo strtoupper($notif['type']); ?>
                            </span>
                        </div>
                        <p style="margin: 5px 0; color: var(--text-secondary); font-size: 0.9em;">
                            <?php echo htmlspecialchars(substr($notif['message'], 0, 100)) . (strlen($notif['message']) > 100 ? '...' : ''); ?>
                        </p>
                        <small style="color: var(--text-secondary);">
                            <i class="fas fa-clock"></i> <?php echo date('M d, Y H:i', strtotime($notif['created_at'])); ?>
                        </small>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="padding: 40px; text-align: center; color: var(--text-secondary);">
                    <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 10px; display: block;"></i>
                    <p>No notifications sent yet</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php 
    /**
     * Send email using configured SMTP settings
     * Uses the email system from config.php
     */
    function send_email($email, $subject, $message) {
        try {
            // Use the built-in send_email function from config.php
            return send_email($email, $subject, $message, 'School Management System');
        } catch (Exception $e) {
            error_log('Email sending failed: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Send SMS using configured gateway (Hubtel/Arkesel/Twilio)
     * Uses the SMSGateway class from includes/SMSGateway.php
     */
    function send_sms($phone, $message) {
        try {
            // Check if SMS is enabled in .env
            $sms_enabled = getenv('ENABLE_SMS_NOTIFICATIONS') === 'true' || 
                          (defined('ENABLE_SMS_NOTIFICATIONS') && ENABLE_SMS_NOTIFICATIONS);
            
            if (!$sms_enabled) {
                error_log('SMS notifications are disabled');
                return false;
            }
            
            // Use SMSGateway class if available
            if (class_exists('SMSGateway')) {
                $gateway = new SMSGateway(
                    Database::getInstance()->getConnection(),
                    $_SESSION['user']['school_id'] ?? 1
                );
                // Call the send method from SMSGateway
                return $gateway->send($phone, $message);
            }
            
            error_log('SMSGateway class not found');
            return false;
        } catch (Exception $e) {
            error_log('SMS sending failed: ' . $e->getMessage());
            return false;
        }
    }
    ?>

<?php include BASE_PATH . '/includes/footer.php'; ?>
