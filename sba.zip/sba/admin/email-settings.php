<?php
// admin/email-settings.php - Configure email/SMTP settings
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['admin', 'super_admin']);
$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

$success_msg = $error_msg = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['test_email'])) {
        // Test email configuration
        require_once BASE_PATH . '/includes/email-manager.php';
        $email_manager = new EmailManager($db);
        
        $test_email = $_POST['test_email_address'] ?? '';
        
        if (filter_var($test_email, FILTER_VALIDATE_EMAIL)) {
            $result = $email_manager->send(
                $test_email,
                'Test Email from School Management System',
                '<h2>Test Email</h2><p>If you received this, your email configuration is working correctly!</p>',
                ['is_html' => true]
            );
            
            if ($result['success']) {
                $success_msg = 'Test email sent successfully to ' . htmlspecialchars($test_email);
            } else {
                $error_msg = 'Failed to send test email: ' . $result['message'];
            }
        } else {
            $error_msg = 'Invalid email address';
        }
    } else {
        // Save SMTP settings
        $settings = [
            'smtp_host' => $_POST['smtp_host'] ?? '',
            'smtp_port' => $_POST['smtp_port'] ?? '587',
            'smtp_encryption' => $_POST['smtp_encryption'] ?? 'tls',
            'smtp_username' => $_POST['smtp_username'] ?? '',
            'smtp_password' => $_POST['smtp_password'] ?? '',
            'email_from' => $_POST['email_from'] ?? '',
            'email_from_name' => $_POST['email_from_name'] ?? ''
        ];
        
        try {
            foreach ($settings as $key => $value) {
                // Only update password if provided
                if ($key === 'smtp_password' && empty($value)) {
                    continue;
                }
                
                $stmt = $db->prepare("
                    INSERT INTO settings (setting_key, setting_value)
                    VALUES (?, ?)
                    ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
                ");
                $stmt->execute([$key, $value]);
            }
            
            $success_msg = 'Email settings saved successfully!';
        } catch (PDOException $e) {
            $error_msg = 'Error saving settings: ' . $e->getMessage();
        }
    }
}

// Load current settings
$current_settings = [];
try {
    $stmt = $db->prepare("
        SELECT setting_key, setting_value 
        FROM settings 
        WHERE setting_key LIKE 'smtp_%' OR setting_key LIKE 'email_%'
    ");
    $stmt->execute();
    $current_settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    // Settings table might not exist yet
}

// Get email statistics
$email_stats = ['total' => 0, 'sent' => 0, 'failed' => 0, 'pending' => 0];
try {
    $stmt = $db->query("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
        FROM email_log
    ");
    $email_stats = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Email log table might not exist yet
}

require_once BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4><i class="fas fa-envelope"></i> Email & SMTP Settings</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($success_msg): ?>
                            <div class="alert alert-success alert-dismissible fade show">
                                <i class="fas fa-check-circle"></i> <?php echo $success_msg; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($error_msg): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <i class="fas fa-exclamation-circle"></i> <?php echo $error_msg; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Email Statistics -->
                        <div class="row mb-4">
                            <div class="col-md-3">
                                <div class="card bg-primary text-white">
                                    <div class="card-body text-center">
                                        <h2><?php echo number_format($email_stats['total'] ?? 0); ?></h2>
                                        <p class="mb-0">Total Emails</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-success text-white">
                                    <div class="card-body text-center">
                                        <h2><?php echo number_format($email_stats['sent'] ?? 0); ?></h2>
                                        <p class="mb-0">Sent</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-danger text-white">
                                    <div class="card-body text-center">
                                        <h2><?php echo number_format($email_stats['failed'] ?? 0); ?></h2>
                                        <p class="mb-0">Failed</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-warning text-white">
                                    <div class="card-body text-center">
                                        <h2><?php echo number_format($email_stats['pending'] ?? 0); ?></h2>
                                        <p class="mb-0">Pending</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- SMTP Configuration Form -->
                        <form method="POST" action="">
                            <div class="row">
                                <div class="col-md-6">
                                    <h5 class="mb-3"><i class="fas fa-server"></i> SMTP Server Settings</h5>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">SMTP Host</label>
                                        <input type="text" name="smtp_host" class="form-control" 
                                               value="<?php echo htmlspecialchars($current_settings['smtp_host'] ?? ''); ?>"
                                               placeholder="smtp.gmail.com">
                                        <small class="text-muted">Gmail: smtp.gmail.com | Outlook: smtp.office365.com</small>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">SMTP Port</label>
                                        <input type="number" name="smtp_port" class="form-control" 
                                               value="<?php echo htmlspecialchars($current_settings['smtp_port'] ?? '587'); ?>">
                                        <small class="text-muted">TLS: 587 | SSL: 465 | Unencrypted: 25</small>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Encryption</label>
                                        <select name="smtp_encryption" class="form-select">
                                            <option value="tls" <?php echo ($current_settings['smtp_encryption'] ?? 'tls') == 'tls' ? 'selected' : ''; ?>>TLS</option>
                                            <option value="ssl" <?php echo ($current_settings['smtp_encryption'] ?? '') == 'ssl' ? 'selected' : ''; ?>>SSL</option>
                                            <option value="" <?php echo empty($current_settings['smtp_encryption']) ? 'selected' : ''; ?>>None</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">SMTP Username/Email</label>
                                        <input type="email" name="smtp_username" class="form-control" 
                                               value="<?php echo htmlspecialchars($current_settings['smtp_username'] ?? ''); ?>"
                                               placeholder="your-email@gmail.com">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">SMTP Password</label>
                                        <input type="password" name="smtp_password" class="form-control" 
                                               placeholder="Leave blank to keep current password">
                                        <small class="text-muted">For Gmail, use App Password (not your regular password)</small>
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <h5 class="mb-3"><i class="fas fa-envelope"></i> Email Settings</h5>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">From Email Address</label>
                                        <input type="email" name="email_from" class="form-control" required
                                               value="<?php echo htmlspecialchars($current_settings['email_from'] ?? ''); ?>"
                                               placeholder="noreply@yourschool.com">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">From Name</label>
                                        <input type="text" name="email_from_name" class="form-control" required
                                               value="<?php echo htmlspecialchars($current_settings['email_from_name'] ?? ''); ?>"
                                               placeholder="School Management System">
                                    </div>
                                    
                                    <div class="alert alert-info">
                                        <h6><i class="fas fa-info-circle"></i> Gmail Setup Instructions:</h6>
                                        <ol class="mb-0 small">
                                            <li>Enable 2-Step Verification in your Google Account</li>
                                            <li>Go to <strong>App Passwords</strong></li>
                                            <li>Generate an App Password for "Mail"</li>
                                            <li>Use that password (not your Google password)</li>
                                        </ol>
                                    </div>
                                    
                                    <div class="alert alert-warning">
                                        <h6><i class="fas fa-exclamation-triangle"></i> Important Notes:</h6>
                                        <ul class="mb-0 small">
                                            <li>Test your configuration before using it</li>
                                            <li>Keep SMTP credentials secure</li>
                                            <li>Monitor email logs regularly</li>
                                            <li>Check spam folder if emails not received</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="text-end mt-3">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Save Settings
                                </button>
                            </div>
                        </form>
                        
                        <!-- Test Email Form -->
                        <hr class="my-4">
                        <h5 class="mb-3"><i class="fas fa-paper-plane"></i> Test Email Configuration</h5>
                        <form method="POST" action="" class="row g-3">
                            <div class="col-md-8">
                                <input type="email" name="test_email_address" class="form-control" 
                                       placeholder="Enter email address to test" required>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" name="test_email" class="btn btn-success w-100">
                                    <i class="fas fa-paper-plane"></i> Send Test Email
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php require_once BASE_PATH . '/
</div>

includes/footer.php'; ?>