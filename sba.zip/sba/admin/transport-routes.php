<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Transport Routes';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = sanitize_input($_POST['action']);

    if ($action === 'add') {
        $route_name = sanitize_input($_POST['route_name'] ?? '');
        $vehicle_number = sanitize_input($_POST['vehicle_number'] ?? '');
        $driver_name = sanitize_input($_POST['driver_name'] ?? '');
        $driver_phone = sanitize_input($_POST['driver_phone'] ?? '');
        $monthly_fee = (float)($_POST['monthly_fee'] ?? 0);
        $status = sanitize_input($_POST['status'] ?? 'active');

        if ($route_name === '' || $monthly_fee <= 0) {
            set_message('error', 'Route name and monthly fee are required.');
            redirect(APP_URL . '/admin/transport-routes.php');
        }

        try {
            $stmt = $db->prepare("
                INSERT INTO transport_routes (school_id, route_name, vehicle_number, driver_name, driver_phone, monthly_fee, status)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$school_id, $route_name, $vehicle_number ?: null, $driver_name ?: null, $driver_phone ?: null, $monthly_fee, $status]);

            log_activity($current_user['user_id'], "Added transport route: $route_name", 'transport_routes', $db->lastInsertId());
            set_message('success', 'Transport route added successfully!');
            redirect(APP_URL . '/admin/transport-routes.php');
        } catch (PDOException $e) {
            set_message('error', 'Error adding route: ' . $e->getMessage());
            redirect(APP_URL . '/admin/transport-routes.php');
        }
    }

    if ($action === 'edit') {
        $route_id = (int)($_POST['route_id'] ?? 0);
        $route_name = sanitize_input($_POST['route_name'] ?? '');
        $vehicle_number = sanitize_input($_POST['vehicle_number'] ?? '');
        $driver_name = sanitize_input($_POST['driver_name'] ?? '');
        $driver_phone = sanitize_input($_POST['driver_phone'] ?? '');
        $monthly_fee = (float)($_POST['monthly_fee'] ?? 0);
        $status = sanitize_input($_POST['status'] ?? 'active');

        if ($route_id <= 0 || $route_name === '' || $monthly_fee <= 0) {
            set_message('error', 'Invalid route data.');
            redirect(APP_URL . '/admin/transport-routes.php');
        }

        try {
            $stmt = $db->prepare("
                UPDATE transport_routes
                SET route_name = ?, vehicle_number = ?, driver_name = ?, driver_phone = ?, monthly_fee = ?, status = ?
                WHERE route_id = ? AND school_id = ?
            ");
            $stmt->execute([$route_name, $vehicle_number ?: null, $driver_name ?: null, $driver_phone ?: null, $monthly_fee, $status, $route_id, $school_id]);

            log_activity($current_user['user_id'], "Updated transport route ID: $route_id", 'transport_routes', $route_id);
            set_message('success', 'Transport route updated successfully!');
            redirect(APP_URL . '/admin/transport-routes.php');
        } catch (PDOException $e) {
            set_message('error', 'Error updating route: ' . $e->getMessage());
            redirect(APP_URL . '/admin/transport-routes.php');
        }
    }

    if ($action === 'delete') {
        $route_id = (int)($_POST['route_id'] ?? 0);

        if ($route_id <= 0) {
            set_message('error', 'Invalid route.');
            redirect(APP_URL . '/admin/transport-routes.php');
        }

        try {
            $stmt = $db->prepare("DELETE FROM transport_routes WHERE route_id = ? AND school_id = ?");
            $stmt->execute([$route_id, $school_id]);

            log_activity($current_user['user_id'], "Deleted transport route ID: $route_id", 'transport_routes', $route_id);
            set_message('success', 'Transport route deleted successfully!');
            redirect(APP_URL . '/admin/transport-routes.php');
        } catch (PDOException $e) {
            set_message('error', 'Error deleting route: ' . $e->getMessage());
            redirect(APP_URL . '/admin/transport-routes.php');
        }
    }
}

$stmt = $db->prepare("SELECT * FROM transport_routes WHERE school_id = ? ORDER BY route_name");
$stmt->execute([$school_id]);
$routes = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
        <div>
            <h2 style="margin: 0;"><i class="fas fa-bus"></i> Transport Routes</h2>
        </div>
        <div>
            <button class="btn btn-primary" onclick="showAddRouteModal()">
                <i class="fas fa-plus"></i> Add Route
            </button>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-route"></i> Routes (<?php echo count($routes); ?>)</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Route</th>
                        <th>Vehicle</th>
                        <th>Driver</th>
                        <th>Phone</th>
                        <th>Monthly Fee</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($routes) > 0): ?>
                        <?php foreach ($routes as $route): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($route['route_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($route['vehicle_number'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($route['driver_name'] ?: '-'); ?></td>
                                <td><?php echo htmlspecialchars($route['driver_phone'] ?: '-'); ?></td>
                                <td><strong><?php echo format_currency($route['monthly_fee']); ?></strong></td>
                                <td>
                                    <span class="badge badge-<?php echo $route['status'] === 'active' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($route['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-info" onclick='editRoute(<?php echo json_encode($route); ?>)'>
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="deleteRoute(<?php echo (int)$route['route_id']; ?>, '<?php echo htmlspecialchars(addslashes($route['route_name'])); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                                No routes found
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div id="routeModal" class="modal">
        <div class="modal-content" style="max-width: 700px;">
            <div class="modal-header">
                <h3 id="routeModalTitle"><i class="fas fa-bus"></i> Add Route</h3>
                <span class="modal-close" onclick="closeRouteModal()">&times;</span>
            </div>
            <form method="POST" id="routeForm">
                <input type="hidden" name="action" id="routeAction" value="add">
                <input type="hidden" name="route_id" id="route_id" value="">
    
                <div class="form-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; padding: 20px;">
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label for="route_name">Route Name *</label>
                        <input type="text" name="route_name" id="route_name" required>
                    </div>
    
                    <div class="form-group">
                        <label for="vehicle_number">Vehicle Number</label>
                        <input type="text" name="vehicle_number" id="vehicle_number">
                    </div>
    
                    <div class="form-group">
                        <label for="monthly_fee">Monthly Fee *</label>
                        <input type="number" step="0.01" name="monthly_fee" id="monthly_fee" required>
                    </div>
    
                    <div class="form-group">
                        <label for="driver_name">Driver Name</label>
                        <input type="text" name="driver_name" id="driver_name">
                    </div>
    
                    <div class="form-group">
                        <label for="driver_phone">Driver Phone</label>
                        <input type="text" name="driver_phone" id="driver_phone">
                    </div>
    
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label for="status">Status</label>
                        <select name="status" id="status">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
    
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeRouteModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="routeSubmitBtn">
                        <i class="fas fa-save"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <form method="POST" id="deleteRouteForm" style="display:none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="route_id" id="delete_route_id" value="">
    </form>
    
    <script>
    function showAddRouteModal() {
        document.getElementById('routeModalTitle').innerHTML = '<i class="fas fa-bus"></i> Add Route';
        document.getElementById('routeAction').value = 'add';
        document.getElementById('route_id').value = '';
        document.getElementById('route_name').value = '';
        document.getElementById('vehicle_number').value = '';
        document.getElementById('driver_name').value = '';
        document.getElementById('driver_phone').value = '';
        document.getElementById('monthly_fee').value = '';
        document.getElementById('status').value = 'active';
        document.getElementById('routeModal').style.display = 'flex';
    }
    
    function editRoute(route) {
        document.getElementById('routeModalTitle').innerHTML = '<i class="fas fa-edit"></i> Edit Route';
        document.getElementById('routeAction').value = 'edit';
        document.getElementById('route_id').value = route.route_id;
        document.getElementById('route_name').value = route.route_name || '';
        document.getElementById('vehicle_number').value = route.vehicle_number || '';
        document.getElementById('driver_name').value = route.driver_name || '';
        document.getElementById('driver_phone').value = route.driver_phone || '';
        document.getElementById('monthly_fee').value = route.monthly_fee || '';
        document.getElementById('status').value = route.status || 'active';
        document.getElementById('routeModal').style.display = 'flex';
    }
    
    function closeRouteModal() {
        document.getElementById('routeModal').style.display = 'none';
    }
    
    function deleteRoute(routeId, routeName) {
        if (!confirm('Delete route "' + routeName + '"? This cannot be undone.')) return;
        document.getElementById('delete_route_id').value = routeId;
        document.getElementById('deleteRouteForm').submit();
    }
    
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('routeModal');
        if (event.target === modal) {
            closeRouteModal();
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
