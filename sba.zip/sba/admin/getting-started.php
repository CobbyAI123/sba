<?php
// admin/getting-started.php - Getting Started Guide
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Getting Started';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Check if school has basic setup (students, classes, teachers)
$total_students = 0;
$total_teachers = 0;
$total_classes = 0;

try {
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM students WHERE school_id = ?");
    $stmt->execute([$school_id]);
    $total_students = $stmt->fetch()['count'];

    $stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE school_id = ? AND role = 'teacher'");
    $stmt->execute([$school_id]);
    $total_teachers = $stmt->fetch()['count'];

    $stmt = $db->prepare("SELECT COUNT(*) as count FROM classes WHERE school_id = ?");
    $stmt->execute([$school_id]);
    $total_classes = $stmt->fetch()['count'];
} catch (PDOException $e) {
    // Database error - default to 0
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .getting-started-container {
        max-width: 1000px;
        margin: 0 auto;
    }
    
    .step-card {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 25px;
        margin-bottom: 20px;
        border-left: 5px solid var(--primary-blue);
        display: flex;
        gap: 20px;
        align-items: flex-start;
        transition: all 0.3s ease;
    }
    
    .step-card:hover {
        transform: translateX(5px);
        box-shadow: var(--shadow);
    }
    
    .step-card.completed {
        border-left-color: var(--success-green);
        background: rgba(76, 175, 80, 0.05);
    }
    
    .step-card.pending {
        border-left-color: var(--warning-orange);
        background: rgba(255, 152, 0, 0.05);
    }
    
    .step-icon {
        width: 60px;
        height: 60px;
        min-width: 60px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        background: var(--bg-secondary);
    }
    
    .step-card.completed .step-icon {
        background: rgba(76, 175, 80, 0.1);
        color: var(--success-green);
    }
    
    .step-card.pending .step-icon {
        background: rgba(255, 152, 0, 0.1);
        color: var(--warning-orange);
    }
    
    .step-content {
        flex: 1;
    }
    
    .step-title {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .step-description {
        color: var(--text-secondary);
        margin-bottom: 15px;
        line-height: 1.6;
    }
    
    .step-progress {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 14px;
        margin-bottom: 12px;
    }
    
    .progress-bar {
        width: 100%;
        height: 6px;
        background: var(--bg-secondary);
        border-radius: 3px;
        overflow: hidden;
    }
    
    .progress-fill {
        height: 100%;
        background: var(--primary-blue);
        transition: width 0.3s ease;
    }
    
    .step-action {
        display: flex;
        gap: 10px;
    }
    
    .status-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
    }
    
    .status-completed {
        background: rgba(76, 175, 80, 0.1);
        color: var(--success-green);
    }
    
    .status-pending {
        background: rgba(255, 152, 0, 0.1);
        color: var(--warning-orange);
    }
    
    .progress-section {
        margin-bottom: 30px;
    }
    
    .progress-title {
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .quick-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 30px;
    }
    
    .stat-item {
        background: var(--card-bg);
        padding: 20px;
        border-radius: 12px;
        text-align: center;
        border: 2px solid var(--border-color);
    }
    
    .stat-number {
        font-size: 32px;
        font-weight: 700;
        color: var(--primary-blue);
        margin-bottom: 5px;
    }
    
    .stat-label {
        font-size: 14px;
        color: var(--text-secondary);
    }
    </style>
    
    <div class="getting-started-container">
        <!-- Welcome Header -->
        <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); color: white;">
            <div style="padding: 40px;">
                <h2 style="margin: 0 0 10px 0; color: white; font-size: 28px;">
                    <i class="fas fa-rocket"></i> Welcome to Your School Dashboard!
                </h2>
                <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                    Let's set up your school system to make it fully operational. Follow these simple steps to get started.
                </p>
            </div>
        </div>
    
        <!-- Quick Stats -->
        <div class="quick-stats">
            <div class="stat-item">
                <div class="stat-number"><?php echo $total_students; ?></div>
                <div class="stat-label">Students Enrolled</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?php echo $total_classes; ?></div>
                <div class="stat-label">Classes Created</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?php echo $total_teachers; ?></div>
                <div class="stat-label">Teachers Added</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?php echo (($total_students > 0 ? 1 : 0) + ($total_classes > 0 ? 1 : 0) + ($total_teachers > 0 ? 1 : 0)) * 33; ?>%</div>
                <div class="stat-label">Setup Complete</div>
            </div>
        </div>
    
        <!-- Setup Steps -->
        <div class="progress-section">
            <div class="progress-title">
                <i class="fas fa-list-check"></i> Essential Setup Steps
            </div>
    
            <!-- Step 1: Create Classes -->
            <div class="step-card <?php echo $total_classes > 0 ? 'completed' : 'pending'; ?>">
                <div class="step-icon">
                    <i class="fas fa-book"></i>
                </div>
                <div class="step-content">
                    <div class="step-title">
                        Create Classes
                        <span class="status-badge <?php echo $total_classes > 0 ? 'status-completed' : 'status-pending'; ?>">
                            <?php echo $total_classes > 0 ? '✓ Done' : 'To Do'; ?>
                        </span>
                    </div>
                    <div class="step-description">
                        Set up your school classes (e.g., Class 1A, Form 2, Grade 6). This is the foundation of your school structure.
                    </div>
                    <div class="step-progress">
                        <span><?php echo $total_classes; ?> class<?php echo $total_classes !== 1 ? 'es' : ''; ?> created</span>
                        <div class="progress-bar" style="flex: 1;">
                            <div class="progress-fill" style="width: <?php echo min($total_classes * 25, 100); ?>%;"></div>
                        </div>
                    </div>
                    <div class="step-action">
                        <a href="<?php echo APP_URL; ?>/admin/classes.php" class="btn btn-primary">
                            <i class="fas fa-<?php echo $total_classes > 0 ? 'edit' : 'plus'; ?>"></i> 
                            <?php echo $total_classes > 0 ? 'Manage Classes' : 'Create First Class'; ?>
                        </a>
                    </div>
                </div>
            </div>
    
            <!-- Step 2: Add Teachers -->
            <div class="step-card <?php echo $total_teachers > 0 ? 'completed' : 'pending'; ?>">
                <div class="step-icon">
                    <i class="fas fa-chalkboard-user"></i>
                </div>
                <div class="step-content">
                    <div class="step-title">
                        Add Teachers
                        <span class="status-badge <?php echo $total_teachers > 0 ? 'status-completed' : 'status-pending'; ?>">
                            <?php echo $total_teachers > 0 ? '✓ Done' : 'To Do'; ?>
                        </span>
                    </div>
                    <div class="step-description">
                        Register all your teachers in the system. They can then log in and manage attendance, grades, and other classroom activities.
                    </div>
                    <div class="step-progress">
                        <span><?php echo $total_teachers; ?> teacher<?php echo $total_teachers !== 1 ? 's' : ''; ?> added</span>
                        <div class="progress-bar" style="flex: 1;">
                            <div class="progress-fill" style="width: <?php echo min($total_teachers * 25, 100); ?>%;"></div>
                        </div>
                    </div>
                    <div class="step-action">
                        <a href="<?php echo APP_URL; ?>/admin/teachers.php" class="btn btn-primary">
                            <i class="fas fa-<?php echo $total_teachers > 0 ? 'edit' : 'plus'; ?>"></i> 
                            <?php echo $total_teachers > 0 ? 'Manage Teachers' : 'Add First Teacher'; ?>
                        </a>
                    </div>
                </div>
            </div>
    
            <!-- Step 3: Enroll Students -->
            <div class="step-card <?php echo $total_students > 0 ? 'completed' : 'pending'; ?>">
                <div class="step-icon">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <div class="step-content">
                    <div class="step-title">
                        Enroll Students
                        <span class="status-badge <?php echo $total_students > 0 ? 'status-completed' : 'status-pending'; ?>">
                            <?php echo $total_students > 0 ? '✓ Done' : 'To Do'; ?>
                        </span>
                    </div>
                    <div class="step-description">
                        Register all students and assign them to their respective classes. You can add students individually or import them in bulk.
                    </div>
                    <div class="step-progress">
                        <span><?php echo $total_students; ?> student<?php echo $total_students !== 1 ? 's' : ''; ?> enrolled</span>
                        <div class="progress-bar" style="flex: 1;">
                            <div class="progress-fill" style="width: <?php echo min($total_students * 10, 100); ?>%;"></div>
                        </div>
                    </div>
                    <div class="step-action">
                        <a href="<?php echo APP_URL; ?>/admin/students.php" class="btn btn-primary">
                            <i class="fas fa-<?php echo $total_students > 0 ? 'edit' : 'plus'; ?>"></i> 
                            <?php echo $total_students > 0 ? 'Manage Students' : 'Add First Student'; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    
        <!-- Additional Features -->
        <div class="progress-section">
            <div class="progress-title">
                <i class="fas fa-star"></i> Additional Features (Optional)
            </div>
    
            <!-- Subjects -->
            <div class="step-card">
                <div class="step-icon">
                    <i class="fas fa-book-open"></i>
                </div>
                <div class="step-content">
                    <div class="step-title">Set Up Subjects</div>
                    <div class="step-description">
                        Create a list of subjects offered in your school and assign them to classes.
                    </div>
                    <div class="step-action">
                        <a href="<?php echo APP_URL; ?>/admin/subjects.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-right"></i> Go to Subjects
                        </a>
                    </div>
                </div>
            </div>
    
            <!-- Fee Structure -->
            <div class="step-card">
                <div class="step-icon">
                    <i class="fas fa-money-bill"></i>
                </div>
                <div class="step-content">
                    <div class="step-title">Configure Fee Structure</div>
                    <div class="step-description">
                        Set up your school fees and payment requirements for each class.
                    </div>
                    <div class="step-action">
                        <a href="<?php echo APP_URL; ?>/admin/fees.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-right"></i> Configure Fees
                        </a>
                    </div>
                </div>
            </div>
    
            <!-- Assign Teachers to Classes -->
            <div class="step-card">
                <div class="step-icon">
                    <i class="fas fa-link"></i>
                </div>
                <div class="step-content">
                    <div class="step-title">Assign Teachers to Classes</div>
                    <div class="step-description">
                        Assign class teachers and subject teachers to respective classes.
                    </div>
                    <div class="step-action">
                        <a href="<?php echo APP_URL; ?>/admin/teacher-classes.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-right"></i> Assign Teachers
                        </a>
                    </div>
                </div>
            </div>
    
            <!-- Parents/Guardians -->
            <div class="step-card">
                <div class="step-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="step-content">
                    <div class="step-title">Register Parents/Guardians</div>
                    <div class="step-description">
                        Add parent accounts and link them to students for better communication and fee management.
                    </div>
                    <div class="step-action">
                        <a href="<?php echo APP_URL; ?>/admin/parents.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-right"></i> Add Parents
                        </a>
                    </div>
                </div>
            </div>
        </div>
    
        <!-- Tips Section -->
        <div class="card" style="margin-top: 30px; margin-bottom: 30px; background: rgba(76, 175, 80, 0.05); border-left: 5px solid var(--success-green);">
            <div style="padding: 25px;">
                <h3 style="margin-top: 0; color: var(--success-green);">
                    <i class="fas fa-lightbulb"></i> Pro Tips
                </h3>
                <ul style="margin: 0; padding-left: 20px; color: var(--text-secondary);">
                    <li style="margin-bottom: 10px;">You can <strong>import students in bulk</strong> using a CSV file - saves time compared to adding them one by one</li>
                    <li style="margin-bottom: 10px;">Make sure to <strong>set up fee structure</strong> before collecting payments from parents</li>
                    <li style="margin-bottom: 10px;">Use the <strong>attendance marking feature</strong> daily to maintain accurate records</li>
                    <li style="margin-bottom: 10px;">Assign <strong>subject teachers to classes</strong> so they can manage marks and exams</li>
                    <li>Check the <strong>Dashboard</strong> regularly to monitor school activities and finances</li>
                </ul>
            </div>
        </div>
    
        <!-- Help Section -->
        <div class="card" style="margin-bottom: 30px; background: rgba(33, 150, 243, 0.05); border-left: 5px solid var(--primary-blue);">
            <div style="padding: 25px;">
                <h3 style="margin-top: 0; color: var(--primary-blue);">
                    <i class="fas fa-question-circle"></i> Need Help?
                </h3>
                <p style="color: var(--text-secondary); margin-bottom: 15px;">
                    If you encounter any issues or have questions about features, don't hesitate to:
                </p>
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <a href="#" class="btn btn-info" style="text-decoration: none;">
                        <i class="fas fa-book"></i> View Documentation
                    </a>
                    <a href="#" class="btn btn-info" style="text-decoration: none;">
                        <i class="fas fa-envelope"></i> Contact Support
                    </a>
                    <a href="<?php echo APP_URL; ?>/admin/dashboard.php" class="btn btn-secondary" style="text-decoration: none;">
                        <i class="fas fa-home"></i> Go to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
