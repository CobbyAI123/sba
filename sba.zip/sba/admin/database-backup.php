<?php
require_once '../config.php';

// Check permission - only admin and proprietor
$current_user = check_permission(['admin', 'proprietor']);
$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Create backups directory if it doesn't exist
$backup_dir = BASE_PATH . '/backups/';
if (!is_dir($backup_dir)) {
    mkdir($backup_dir, 0755, true);
}

// Handle backup actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_backup'])) {
        try {
            $backup_filename = create_database_backup($school_id, $current_user);
            set_message('success', 'Database backup created successfully: ' . $backup_filename);
            log_activity($current_user['user_id'], "Created database backup: $backup_filename", 'backups', null);
        } catch (Exception $e) {
            set_message('error', 'Backup failed: ' . $e->getMessage());
        }
        redirect(APP_URL . '/admin/database-backup.php');
    }
    
    if (isset($_POST['restore_backup']) && isset($_POST['backup_file'])) {
        $backup_file = $_POST['backup_file'];
        try {
            restore_database_backup($backup_file, $school_id, $current_user);
            set_message('success', 'Database restored successfully from: ' . $backup_file);
            log_activity($current_user['user_id'], "Restored database from backup: $backup_file", 'backups', null);
        } catch (Exception $e) {
            set_message('error', 'Restore failed: ' . $e->getMessage());
        }
        redirect(APP_URL . '/admin/database-backup.php');
    }
    
    if (isset($_POST['delete_backup']) && isset($_POST['backup_file'])) {
        $backup_file = $_POST['backup_file'];
        $file_path = $backup_dir . $backup_file;
        
        if (file_exists($file_path) && strpos($backup_file, '..') === false) {
            unlink($file_path);
            set_message('success', 'Backup file deleted: ' . $backup_file);
            log_activity($current_user['user_id'], "Deleted backup file: $backup_file", 'backups', null);
        } else {
            set_message('error', 'Backup file not found');
        }
        redirect(APP_URL . '/admin/database-backup.php');
    }
    
    if (isset($_POST['toggle_auto_backup'])) {
        $current_status = get_school_setting($school_id, 'auto_backup_enabled') ?? '0';
        $new_status = $current_status === '1' ? '0' : '1';
        
        $stmt = $db->prepare("INSERT INTO settings (school_id, setting_key, setting_value) VALUES (?, 'auto_backup_enabled', ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$school_id, $new_status, $new_status]);
        
        set_message('success', 'Auto-backup ' . ($new_status === '1' ? 'enabled' : 'disabled'));
        log_activity($current_user['user_id'], "Toggled auto-backup: " . ($new_status === '1' ? 'ON' : 'OFF'), 'settings', null);
        redirect(APP_URL . '/admin/database-backup.php');
    }
}

// Get existing backups
$backups = get_backup_files($backup_dir);

// Check auto-backup status
$auto_backup_enabled = get_school_setting($school_id, 'auto_backup_enabled') ?? '0';
$last_auto_backup = get_school_setting($school_id, 'last_auto_backup_date') ?? 'Never';

// Database backup creation function
function create_database_backup($school_id, $user) {
    $backup_dir = BASE_PATH . '/backups/';
    $timestamp = date('Y-m-d_H-i-s');
    $school_code = 'SCH' . $school_id;
    $filename = "backup_{$school_code}_{$timestamp}.sql";
    $filepath = $backup_dir . $filename;
    
    // Get database credentials
    $host = DB_HOST;
    $username = DB_USER;
    $password = DB_PASS;
    $database = DB_NAME;
    
    // Use mysqldump command
    $command = sprintf(
        'mysqldump --host=%s --user=%s --password=%s --single-transaction --routines --triggers %s > %s 2>&1',
        escapeshellarg($host),
        escapeshellarg($username),
        escapeshellarg($password),
        escapeshellarg($database),
        escapeshellarg($filepath)
    );
    
    // Execute backup
    exec($command, $output, $return_var);
    
    if ($return_var !== 0) {
        // If mysqldump fails, try PHP-based backup
        php_database_backup($filepath, $school_id);
    }
    
    // Verify backup was created
    if (!file_exists($filepath) || filesize($filepath) === 0) {
        throw new Exception('Backup file was not created or is empty');
    }
    
    // Compress backup
    $compressed_file = $filepath . '.gz';
    $fp = gzopen($compressed_file, 'w9');
    gzwrite($fp, file_get_contents($filepath));
    gzclose($fp);
    
    // Remove uncompressed file
    unlink($filepath);
    
    // Update last backup time
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("INSERT INTO settings (school_id, setting_key, setting_value) VALUES (?, 'last_manual_backup_date', NOW()) ON DUPLICATE KEY UPDATE setting_value = NOW()");
    $stmt->execute([$school_id]);
    
    return basename($compressed_file);
}

// PHP-based backup (fallback if mysqldump not available)
function php_database_backup($filepath, $school_id) {
    $db = Database::getInstance()->getConnection();
    
    // Get all tables
    $tables_stmt = $db->query("SHOW TABLES");
    $tables = $tables_stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $backup_content = "-- Database Backup\n";
    $backup_content .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
    $backup_content .= "-- School ID: " . $school_id . "\n\n";
    $backup_content .= "SET FOREIGN_KEY_CHECKS=0;\n\n";
    
    foreach ($tables as $table) {
        // Sanitize table name to prevent SQL injection
        $safe_table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        
        // Get CREATE TABLE statement
        $create_stmt = $db->prepare("SHOW CREATE TABLE `$safe_table`");
        $create_stmt->execute();
        $create_row = $create_stmt->fetch(PDO::FETCH_NUM);
        $backup_content .= "-- Table: $safe_table\n";
        $backup_content .= "DROP TABLE IF EXISTS `$safe_table`;\n";
        $backup_content .= $create_row[1] . ";\n\n";
        
        // Get table data using prepared statement
        $rows_stmt = $db->prepare("SELECT * FROM `$safe_table`");
        $rows_stmt->execute();
        $rows = $rows_stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($rows) > 0) {
            $backup_content .= "-- Data for table: $table\n";
            foreach ($rows as $row) {
                $values = array_map(function($value) use ($db) {
                    return $value === null ? 'NULL' : $db->quote($value);
                }, array_values($row));
                
                $backup_content .= "INSERT INTO `$safe_table` VALUES (" . implode(', ', $values) . ");\n";
            }
            $backup_content .= "\n";
        }
    }
    
    $backup_content .= "SET FOREIGN_KEY_CHECKS=1;\n";
    
    file_put_contents($filepath, $backup_content);
}

// Restore database from backup
function restore_database_backup($backup_file, $school_id, $user) {
    $backup_dir = BASE_PATH . '/backups/';
    $filepath = $backup_dir . $backup_file;
    
    if (!file_exists($filepath)) {
        throw new Exception('Backup file not found');
    }
    
    // Decompress if gzipped
    if (substr($backup_file, -3) === '.gz') {
        $sql_content = gzdecode(file_get_contents($filepath));
    } else {
        $sql_content = file_get_contents($filepath);
    }
    
    if ($sql_content === false || empty($sql_content)) {
        throw new Exception('Failed to read backup file');
    }
    
    // Execute SQL
    $db = Database::getInstance()->getConnection();
    
    try {
        $db->beginTransaction();
        
        // Split SQL into individual statements
        $statements = explode(';', $sql_content);
        
        foreach ($statements as $statement) {
            $statement = trim($statement);
            if (!empty($statement)) {
                $db->exec($statement);
            }
        }
        
        $db->commit();
    } catch (Exception $e) {
        $db->rollBack();
        throw new Exception('Restore failed: ' . $e->getMessage());
    }
}

// Get list of backup files
function get_backup_files($backup_dir) {
    $files = [];
    
    if (!is_dir($backup_dir)) {
        return $files;
    }
    
    $scan = scandir($backup_dir, SCANDIR_SORT_DESCENDING);
    
    foreach ($scan as $file) {
        if ($file !== '.' && $file !== '..' && (substr($file, -4) === '.sql' || substr($file, -7) === '.sql.gz')) {
            $filepath = $backup_dir . $file;
            $files[] = [
                'name' => $file,
                'size' => filesize($filepath),
                'date' => filemtime($filepath),
                'formatted_size' => format_bytes(filesize($filepath)),
                'formatted_date' => date('Y-m-d H:i:s', filemtime($filepath))
            ];
        }
    }
    
    return $files;
}

// Format bytes to human readable
function format_bytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    
    for ($i = 0; $bytes > 1024; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, $precision) . ' ' . $units[$i];
}

$page_title = 'Database Backup & Restore';
require_once '../includes/header.php';
?>

<div class="container-fluid">
    <!-- Page Header -->
    <div class="page-header">
        <div class="row align-items-center">
            <div class="col">
                <h3 class="page-title">
                    <i class="fas fa-database text-primary"></i> Database Backup & Restore
                </h3>
                <p class="text-muted">Manage database backups and restore points</p>
            </div>
            <div class="col-auto">
                <form method="POST" style="display: inline;">
                    <button type="submit" name="create_backup" class="btn btn-primary">
                        <i class="fas fa-plus-circle"></i> Create Backup Now
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Messages -->
    <?php if ($success = get_message('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if ($error = get_message('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Auto-Backup Settings -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-gradient-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-cog"></i> Auto-Backup Settings</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="mb-1">Automatic Backups</h6>
                            <small class="text-muted">Daily automated backups</small>
                        </div>
                        <form method="POST">
                            <button type="submit" name="toggle_auto_backup" class="btn btn-sm <?php echo $auto_backup_enabled === '1' ? 'btn-success' : 'btn-secondary'; ?>">
                                <i class="fas fa-<?php echo $auto_backup_enabled === '1' ? 'check' : 'times'; ?>"></i>
                                <?php echo $auto_backup_enabled === '1' ? 'Enabled' : 'Disabled'; ?>
                            </button>
                        </form>
                    </div>
                    
                    <hr>
                    
                    <div class="info-item">
                        <i class="fas fa-clock text-primary"></i>
                        <div>
                            <small class="text-muted">Last Auto-Backup</small>
                            <div class="fw-bold"><?php echo htmlspecialchars($last_auto_backup); ?></div>
                        </div>
                    </div>
                    
                    <div class="info-item mt-3">
                        <i class="fas fa-folder text-warning"></i>
                        <div>
                            <small class="text-muted">Backup Location</small>
                            <div class="fw-bold text-truncate">/backups/</div>
                        </div>
                    </div>
                    
                    <div class="alert alert-info mt-3 mb-0">
                        <small>
                            <i class="fas fa-info-circle"></i> 
                            Auto-backups run daily at 2:00 AM. Configure cron job for automated execution.
                        </small>
                    </div>
                </div>
            </div>
            
            <!-- Backup Information -->
            <div class="card mt-4">
                <div class="card-header bg-gradient-info text-white">
                    <h5 class="mb-0"><i class="fas fa-info-circle"></i> Backup Information</h5>
                </div>
                <div class="card-body">
                    <h6 class="text-primary">Best Practices</h6>
                    <ul class="small mb-3">
                        <li>Create backups before major changes</li>
                        <li>Store backups in secure location</li>
                        <li>Test restore process regularly</li>
                        <li>Keep multiple backup versions</li>
                    </ul>
                    
                    <h6 class="text-danger">Restore Warning</h6>
                    <ul class="small mb-0">
                        <li>Restoration will <strong>overwrite</strong> current data</li>
                        <li>Create a backup before restoring</li>
                        <li>Verify backup file integrity</li>
                        <li>Notify users of downtime</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Backup Files List -->
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header bg-gradient-success text-white">
                    <h5 class="mb-0">
                        <i class="fas fa-archive"></i> Available Backups 
                        <span class="badge bg-white text-dark"><?php echo count($backups); ?></span>
                    </h5>
                </div>
                <div class="card-body">
                    <?php if (empty($backups)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-database fa-4x text-muted mb-3"></i>
                            <h5 class="text-muted">No Backups Found</h5>
                            <p class="text-muted">Create your first backup to get started</p>
                            <form method="POST">
                                <button type="submit" name="create_backup" class="btn btn-primary">
                                    <i class="fas fa-plus-circle"></i> Create First Backup
                                </button>
                            </form>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead class="table-light">
                                    <tr>
                                        <th><i class="fas fa-file"></i> Backup File</th>
                                        <th><i class="fas fa-hdd"></i> Size</th>
                                        <th><i class="fas fa-calendar"></i> Created</th>
                                        <th class="text-center"><i class="fas fa-cogs"></i> Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($backups as $backup): ?>
                                        <tr>
                                            <td>
                                                <i class="fas fa-file-archive text-primary"></i>
                                                <span class="fw-bold"><?php echo htmlspecialchars($backup['name']); ?></span>
                                            </td>
                                            <td><?php echo $backup['formatted_size']; ?></td>
                                            <td>
                                                <span class="text-muted"><?php echo $backup['formatted_date']; ?></span><br>
                                                <small class="text-primary"><?php echo time_ago($backup['formatted_date']); ?></small>
                                            </td>
                                            <td class="text-center">
                                                <button type="button" class="btn btn-sm btn-info" onclick="downloadBackup('<?php echo $backup['name']; ?>')">
                                                    <i class="fas fa-download"></i>
                                                </button>
                                                <button type="button" class="btn btn-sm btn-warning" onclick="confirmRestore('<?php echo $backup['name']; ?>')">
                                                    <i class="fas fa-undo"></i>
                                                </button>
                                                <button type="button" class="btn btn-sm btn-danger" onclick="confirmDelete('<?php echo $backup['name']; ?>')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Restore Confirmation Modal -->
<div class="modal fade" id="restoreModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title"><i class="fas fa-exclamation-triangle"></i> Confirm Restore</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i>
                        <strong>Warning!</strong> This will overwrite ALL current database data.
                    </div>
                    <p>Are you sure you want to restore from backup:</p>
                    <p class="fw-bold text-primary" id="restoreFileName"></p>
                    <input type="hidden" name="backup_file" id="restoreFileInput">
                    
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="confirmRestore" required>
                        <label class="form-check-label" for="confirmRestore">
                            I understand this action cannot be undone
                        </label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="restore_backup" class="btn btn-warning">
                        <i class="fas fa-undo"></i> Restore Database
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="fas fa-trash"></i> Confirm Delete</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <p>Are you sure you want to delete this backup?</p>
                    <p class="fw-bold text-danger" id="deleteFileName"></p>
                    <input type="hidden" name="backup_file" id="deleteFileInput">
                    <p class="text-muted"><small>This action cannot be undone.</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="delete_backup" class="btn btn-danger">
                        <i class="fas fa-trash"></i> Delete Backup
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
.info-item {
    display: flex;
    align-items: flex-start;
    gap: 12px;
}

.info-item i {
    font-size: 1.5rem;
    margin-top: 4px;
}

.bg-gradient-primary {
    background: linear-gradient(135deg, #2D5BFF, #6C5CE7);
}

.bg-gradient-success {
    background: linear-gradient(135deg, #00D68F, #00B074);
}

.bg-gradient-info {
    background: linear-gradient(135deg, #36D1DC, #5B86E5);
}

.table-hover tbody tr:hover {
    background-color: rgba(45, 91, 255, 0.05);
}
</style>

<script>
function confirmRestore(filename) {
    document.getElementById('restoreFileName').textContent = filename;
    document.getElementById('restoreFileInput').value = filename;
    document.getElementById('confirmRestore').checked = false;
    new bootstrap.Modal(document.getElementById('restoreModal')).show();
}

function confirmDelete(filename) {
    document.getElementById('deleteFileName').textContent = filename;
    document.getElementById('deleteFileInput').value = filename;
    new bootstrap.Modal(document.getElementById('deleteModal')).show();
}

function downloadBackup(filename) {
    window.location.href = '<?php echo APP_URL; ?>/admin/download-backup.php?file=' + encodeURIComponent(filename);
}
</script>

<?php require_once '../includes/footer.php'; ?>
