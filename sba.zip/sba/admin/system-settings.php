<?php
// admin/system-settings.php - Consolidated System Settings (SMS, Email, Notifications, Payment Gateways)
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'System Settings';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        
        // SMS Settings
        if ($_POST['action'] == 'save_sms') {
            $provider = sanitize_input($_POST['sms_provider']);
            $api_key = sanitize_input($_POST['sms_api_key']);
            $sender_id = sanitize_input($_POST['sms_sender_id']);
            $enabled = isset($_POST['sms_enabled']) ? 1 : 0;
            
            try {
                $settings = [
                    'sms_provider' => $provider,
                    'sms_api_key' => $api_key,
                    'sms_sender_id' => $sender_id,
                    'sms_enabled' => $enabled
                ];
                
                foreach ($settings as $key => $value) {
                    $stmt = $db->prepare("
                        INSERT INTO settings (school_id, setting_key, setting_value)
                        VALUES (?, ?, ?)
                        ON DUPLICATE KEY UPDATE setting_value = ?
                    ");
                    $stmt->execute([$school_id, $key, $value, $value]);
                }
                
                log_activity($current_user['user_id'], "Updated SMS settings", 'settings', $school_id);
                set_message('success', 'SMS settings saved successfully!');
            } catch (PDOException $e) {
                set_message('error', 'Error saving SMS settings: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/system-settings.php?tab=sms');
        }
        
        // Email Settings
        if ($_POST['action'] == 'save_email') {
            $settings = [
                'smtp_host' => $_POST['smtp_host'] ?? '',
                'smtp_port' => $_POST['smtp_port'] ?? '587',
                'smtp_encryption' => $_POST['smtp_encryption'] ?? 'tls',
                'smtp_username' => $_POST['smtp_username'] ?? '',
                'smtp_password' => $_POST['smtp_password'] ?? '',
                'email_from' => $_POST['email_from'] ?? '',
                'email_from_name' => $_POST['email_from_name'] ?? ''
            ];
            
            try {
                foreach ($settings as $key => $value) {
                    if ($key === 'smtp_password' && empty($value)) {
                        continue; // Don't update password if empty
                    }
                    
                    $stmt = $db->prepare("
                        INSERT INTO settings (school_id, setting_key, setting_value)
                        VALUES (?, ?, ?)
                        ON DUPLICATE KEY UPDATE setting_value = ?
                    ");
                    $stmt->execute([$school_id, $key, $value, $value]);
                }
                
                log_activity($current_user['user_id'], "Updated email settings", 'settings', $school_id);
                set_message('success', 'Email settings saved successfully!');
            } catch (PDOException $e) {
                set_message('error', 'Error saving email settings: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/system-settings.php?tab=email');
        }
        
        // Notification Settings
        if ($_POST['action'] == 'save_notifications') {
            $auto_absence = isset($_POST['auto_absence_notification']) ? 1 : 0;
            $auto_fee = isset($_POST['auto_fee_reminder']) ? 1 : 0;
            $auto_result = isset($_POST['auto_result_notification']) ? 1 : 0;
            $auto_exam = isset($_POST['auto_exam_reminder']) ? 1 : 0;
            
            try {
                $settings = [
                    'auto_absence_notification' => $auto_absence,
                    'auto_fee_reminder' => $auto_fee,
                    'auto_result_notification' => $auto_result,
                    'auto_exam_reminder' => $auto_exam
                ];
                
                foreach ($settings as $key => $value) {
                    $stmt = $db->prepare("
                        INSERT INTO settings (school_id, setting_key, setting_value)
                        VALUES (?, ?, ?)
                        ON DUPLICATE KEY UPDATE setting_value = ?
                    ");
                    $stmt->execute([$school_id, $key, $value, $value]);
                }
                
                log_activity($current_user['user_id'], "Updated notification settings", 'settings', $school_id);
                set_message('success', 'Notification settings saved successfully!');
            } catch (PDOException $e) {
                set_message('error', 'Error saving notification settings: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/system-settings.php?tab=notifications');
        }
        
        // Payment Gateway Settings
        if ($_POST['action'] == 'save_payment_gateways') {
            $settings_to_save = [
                'mtn_momo_enabled' => isset($_POST['mtn_momo_enabled']) ? 1 : 0,
                'mtn_momo_api_url' => sanitize_input($_POST['mtn_momo_api_url'] ?? ''),
                'mtn_momo_api_key' => sanitize_input($_POST['mtn_momo_api_key'] ?? ''),
                'mtn_momo_user_id' => sanitize_input($_POST['mtn_momo_user_id'] ?? ''),
                'mtn_momo_subscription_key' => sanitize_input($_POST['mtn_momo_subscription_key'] ?? ''),
                'mtn_momo_environment' => sanitize_input($_POST['mtn_momo_environment'] ?? 'sandbox'),
                
                'tigo_cash_enabled' => isset($_POST['tigo_cash_enabled']) ? 1 : 0,
                'tigo_cash_api_url' => sanitize_input($_POST['tigo_cash_api_url'] ?? ''),
                'tigo_cash_merchant_code' => sanitize_input($_POST['tigo_cash_merchant_code'] ?? ''),
                'tigo_cash_merchant_pin' => sanitize_input($_POST['tigo_cash_merchant_pin'] ?? ''),
                'tigo_cash_username' => sanitize_input($_POST['tigo_cash_username'] ?? ''),
                'tigo_cash_password' => sanitize_input($_POST['tigo_cash_password'] ?? ''),
                
                'paystack_enabled' => isset($_POST['paystack_enabled']) ? 1 : 0,
                'paystack_public_key' => sanitize_input($_POST['paystack_public_key'] ?? ''),
                'paystack_secret_key' => sanitize_input($_POST['paystack_secret_key'] ?? '')
            ];
            
            try {
                foreach ($settings_to_save as $key => $value) {
                    $stmt = $db->prepare("
                        INSERT INTO settings (school_id, setting_key, setting_value)
                        VALUES (?, ?, ?)
                        ON DUPLICATE KEY UPDATE setting_value = ?
                    ");
                    $stmt->execute([$school_id, $key, $value, $value]);
                }
                
                log_activity($current_user['user_id'], "Updated payment gateway settings", 'settings', $school_id);
                set_message('success', 'Payment gateway settings saved successfully!');
            } catch (PDOException $e) {
                set_message('error', 'Error saving payment gateway settings: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/system-settings.php?tab=gateways');
        }
    }
}

// Load current settings
$current_settings = [];
try {
    $stmt = $db->prepare("
        SELECT setting_key, setting_value 
        FROM settings 
        WHERE school_id = ?
    ");
    $stmt->execute([$school_id]);
    $current_settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    $current_settings = [];
}

// Extract settings with defaults
$sms_enabled = isset($current_settings['sms_enabled']) && $current_settings['sms_enabled'] == '1';
$sms_provider = $current_settings['sms_provider'] ?? 'hubtel';
$sms_api_key = $current_settings['sms_api_key'] ?? '';
$sms_sender_id = $current_settings['sms_sender_id'] ?? 'SCHOOL';

$current_tab = $_GET['tab'] ?? 'sms';

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .settings-tabs {
        display: flex;
        gap: 10px;
        margin-bottom: 30px;
        border-bottom: 2px solid var(--border-color);
        flex-wrap: wrap;
    }
    
    .settings-tab-btn {
        padding: 12px 20px;
        background: none;
        border: none;
        cursor: pointer;
        font-size: 15px;
        color: var(--text-secondary);
        border-bottom: 3px solid transparent;
        margin-bottom: -2px;
        transition: all 0.3s ease;
    }
    
    .settings-tab-btn:hover {
        color: var(--text-primary);
    }
    
    .settings-tab-btn.active {
        color: var(--primary-blue);
        border-bottom-color: var(--primary-blue);
    }
    
    .tab-content {
        display: none;
    }
    
    .tab-content.active {
        display: block;
    }
    
    .settings-card {
        background: var(--bg-card);
        border-radius: 15px;
        padding: 30px;
        border: 1px solid var(--border-color);
        margin-bottom: 25px;
    }
    
    .settings-section {
        margin-bottom: 30px;
    }
    
    .settings-section h3 {
        margin: 0 0 20px 0;
        padding-bottom: 15px;
        border-bottom: 2px solid var(--border-color);
    }
    
    .form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
    }
    
    .toggle-switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 30px;
    }
    
    .toggle-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .4s;
        border-radius: 30px;
    }
    
    .slider:before {
        position: absolute;
        content: "";
        height: 22px;
        width: 22px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
    }
    
    input:checked + .slider {
        background-color: var(--primary-blue);
    }
    
    input:checked + .slider:before {
        transform: translateX(30px);
    }
    
    .info-box {
        background: rgba(45, 91, 255, 0.1);
        border-left: 4px solid var(--primary-blue);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    
    .gateway-card {
        border: 2px solid var(--border-color);
        border-radius: 10px;
        padding: 25px;
        margin-bottom: 30px;
    }
    
    .gateway-card.enabled {
        border-color: var(--success-green);
        background: rgba(76, 175, 80, 0.05);
    }
    
    .gateway-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 2px solid var(--border-color);
    }
    
    .provider-card {
        border: 2px solid var(--border-color);
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 15px;
        cursor: pointer;
        transition: all 0.3s;
    }
    
    .provider-card:hover {
        border-color: var(--primary-blue);
        background: var(--bg-secondary);
    }
    
    .provider-card.selected {
        border-color: var(--primary-blue);
        background: rgba(33, 150, 243, 0.1);
    }
    
    .provider-card h4 {
        margin: 0 0 10px 0;
        color: var(--primary-blue);
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-cog"></i> System Settings</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Configure SMS, Email, Notifications, and Payment Gateways
        </p>
    </div>
    
    <!-- Tab Navigation -->
    <div class="settings-tabs">
        <button class="settings-tab-btn <?php echo ($current_tab === 'sms') ? 'active' : ''; ?>" 
                onclick="switchTab('sms')">
            <i class="fas fa-sms"></i> SMS Settings
        </button>
        <button class="settings-tab-btn <?php echo ($current_tab === 'email') ? 'active' : ''; ?>" 
                onclick="switchTab('email')">
            <i class="fas fa-envelope"></i> Email Settings
        </button>
        <button class="settings-tab-btn <?php echo ($current_tab === 'notifications') ? 'active' : ''; ?>" 
                onclick="switchTab('notifications')">
            <i class="fas fa-bell"></i> Notifications
        </button>
        <button class="settings-tab-btn <?php echo ($current_tab === 'gateways') ? 'active' : ''; ?>" 
                onclick="switchTab('gateways')">
            <i class="fas fa-credit-card"></i> Payment Gateways
        </button>
    </div>
    
    <!-- SMS Settings Tab -->
    <div id="sms" class="tab-content <?php echo ($current_tab === 'sms') ? 'active' : ''; ?>">
        <div class="settings-card">
            <div class="settings-section">
                <h3><i class="fas fa-sms"></i> SMS Configuration</h3>
                
                <div class="info-box">
                    <i class="fas fa-info-circle"></i>
                    <strong>SMS Settings:</strong> Configure SMS provider to send attendance and payment notifications to parents.
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="save_sms">
                    
                    <!-- Enable SMS -->
                    <div class="form-group" style="background: var(--bg-secondary); padding: 20px; border-radius: 10px; margin-bottom: 25px;">
                        <label style="display: flex; align-items: center; gap: 15px; cursor: pointer; font-size: 18px;">
                            <label class="toggle-switch">
                                <input type="checkbox" name="sms_enabled" value="1" <?php echo $sms_enabled ? 'checked' : ''; ?>>
                                <span class="slider"></span>
                            </label>
                            <div>
                                <strong>Enable SMS Notifications</strong>
                                <div style="font-size: 14px; color: var(--text-secondary); margin-top: 5px;">
                                    <?php echo $sms_enabled ? '✓ Currently Enabled' : '✗ Currently Disabled'; ?>
                                </div>
                            </div>
                        </label>
                    </div>
                    
                    <!-- Provider Selection -->
                    <div class="form-group" style="margin-bottom: 25px;">
                        <label><strong>Select SMS Provider</strong></label>
                        
                        <div onclick="selectProvider('hubtel')" class="provider-card <?php echo $sms_provider == 'hubtel' ? 'selected' : ''; ?>" id="card-hubtel">
                            <h4><i class="fas fa-star"></i> Hubtel (Ghana)</h4>
                            <p style="margin: 0; color: var(--text-secondary); font-size: 14px;">
                                Reliable SMS provider in Ghana. Cost: ~GH₵ 0.03 per SMS
                            </p>
                        </div>
                        
                        <div onclick="selectProvider('arkesel')" class="provider-card <?php echo $sms_provider == 'arkesel' ? 'selected' : ''; ?>" id="card-arkesel">
                            <h4><i class="fas fa-mobile-alt"></i> Arkesel (Ghana)</h4>
                            <p style="margin: 0; color: var(--text-secondary); font-size: 14px;">
                                Good for bulk SMS. Competitive pricing
                            </p>
                        </div>
                        
                        <div onclick="selectProvider('twilio')" class="provider-card <?php echo $sms_provider == 'twilio' ? 'selected' : ''; ?>" id="card-twilio">
                            <h4><i class="fas fa-globe"></i> Twilio (Global)</h4>
                            <p style="margin: 0; color: var(--text-secondary); font-size: 14px;">
                                World's leading SMS platform. Works everywhere. Cost: ~$0.05 per SMS
                            </p>
                        </div>
                        
                        <div onclick="selectProvider('africastalking')" class="provider-card <?php echo $sms_provider == 'africastalking' ? 'selected' : ''; ?>" id="card-africastalking">
                            <h4><i class="fas fa-map-marked-alt"></i> Africa's Talking (Africa)</h4>
                            <p style="margin: 0; color: var(--text-secondary); font-size: 14px;">
                                Pan-African SMS platform. Great coverage across Africa
                            </p>
                        </div>
                        
                        <input type="hidden" name="sms_provider" id="sms_provider" value="<?php echo $sms_provider; ?>">
                    </div>
                    
                    <!-- API Configuration -->
                    <div class="form-grid">
                        <div class="form-group">
                            <label>API Key / Credentials <span style="color: red;">*</span></label>
                            <input type="text" name="sms_api_key" class="form-control" 
                                   value="<?php echo htmlspecialchars($sms_api_key); ?>" 
                                   placeholder="Enter credentials based on provider">
                            <small style="color: var(--text-secondary); margin-top: 5px; display: block;">
                                <strong>Format examples:</strong><br>
                                Hubtel: <code>ClientId:ClientSecret</code><br>
                                Arkesel: <code>YourAPIKey</code><br>
                                Twilio: <code>AccountSID:AuthToken</code>
                            </small>
                        </div>
                        
                        <div class="form-group">
                            <label>Sender ID / Phone Number</label>
                            <input type="text" name="sms_sender_id" class="form-control" 
                                   value="<?php echo htmlspecialchars($sms_sender_id); ?>" 
                                   placeholder="e.g., SCHOOL or +1234567890" maxlength="15">
                            <small style="color: var(--text-secondary); margin-top: 5px; display: block;">
                                Hubtel/Arkesel: Sender name (max 11 chars)<br>
                                Twilio: Your Twilio phone number
                            </small>
                        </div>
                    </div>
                    
                    <div style="text-align: right; margin-top: 25px;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save SMS Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Email Settings Tab -->
    <div id="email" class="tab-content <?php echo ($current_tab === 'email') ? 'active' : ''; ?>">
        <div class="settings-card">
            <div class="settings-section">
                <h3><i class="fas fa-envelope"></i> Email & SMTP Settings</h3>
                
                <div class="info-box">
                    <i class="fas fa-info-circle"></i>
                    <strong>Email Configuration:</strong> Use your email provider's SMTP settings. Gmail, Outlook, or custom SMTP server supported.
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="save_email">
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label>SMTP Host</label>
                            <input type="text" name="smtp_host" class="form-control" 
                                   value="<?php echo htmlspecialchars($current_settings['smtp_host'] ?? ''); ?>"
                                   placeholder="e.g., smtp.gmail.com">
                        </div>
                        
                        <div class="form-group">
                            <label>SMTP Port</label>
                            <input type="number" name="smtp_port" class="form-control" 
                                   value="<?php echo htmlspecialchars($current_settings['smtp_port'] ?? '587'); ?>"
                                   placeholder="587">
                        </div>
                        
                        <div class="form-group">
                            <label>SMTP Encryption</label>
                            <select name="smtp_encryption" class="form-control">
                                <option value="tls" <?php echo ($current_settings['smtp_encryption'] ?? 'tls') == 'tls' ? 'selected' : ''; ?>>TLS (Recommended)</option>
                                <option value="ssl" <?php echo ($current_settings['smtp_encryption'] ?? '') == 'ssl' ? 'selected' : ''; ?>>SSL</option>
                                <option value="" <?php echo empty($current_settings['smtp_encryption']) ? 'selected' : ''; ?>>None</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>SMTP Username/Email</label>
                            <input type="email" name="smtp_username" class="form-control" 
                                   value="<?php echo htmlspecialchars($current_settings['smtp_username'] ?? ''); ?>"
                                   placeholder="your-email@gmail.com">
                        </div>
                        
                        <div class="form-group">
                            <label>SMTP Password</label>
                            <input type="password" name="smtp_password" class="form-control" 
                                   placeholder="Leave blank to keep current password">
                            <small style="color: var(--text-secondary); margin-top: 5px; display: block;">
                                For Gmail, use App Password (not your regular password)
                            </small>
                        </div>
                        
                        <div class="form-group">
                            <label>From Email Address</label>
                            <input type="email" name="email_from" class="form-control" 
                                   value="<?php echo htmlspecialchars($current_settings['email_from'] ?? ''); ?>"
                                   placeholder="noreply@yourschool.com">
                        </div>
                        
                        <div class="form-group">
                            <label>From Name</label>
                            <input type="text" name="email_from_name" class="form-control" 
                                   value="<?php echo htmlspecialchars($current_settings['email_from_name'] ?? ''); ?>"
                                   placeholder="School Management System">
                        </div>
                    </div>
                    
                    <div class="alert alert-info" style="margin-top: 20px;">
                        <h6><i class="fas fa-info-circle"></i> Gmail Setup Instructions:</h6>
                        <ol style="margin: 10px 0 0 20px; font-size: 14px;">
                            <li>Enable 2-Step Verification in your Google Account</li>
                            <li>Go to <strong>App Passwords</strong></li>
                            <li>Generate an App Password for "Mail"</li>
                            <li>Use that password (not your Google password)</li>
                        </ol>
                    </div>
                    
                    <div style="text-align: right; margin-top: 25px;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Email Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Notification Settings Tab -->
    <div id="notifications" class="tab-content <?php echo ($current_tab === 'notifications') ? 'active' : ''; ?>">
        <div class="settings-card">
            <div class="settings-section">
                <h3><i class="fas fa-robot"></i> Automated Notifications</h3>
                
                <div class="info-box">
                    <i class="fas fa-info-circle"></i>
                    <strong>Automatic Triggers:</strong> These notifications will be sent automatically when certain events occur.
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="save_notifications">
                    
                    <div style="display: grid; gap: 15px;">
                        <label style="display: flex; align-items: center; gap: 10px;">
                            <label class="toggle-switch">
                                <input type="checkbox" name="auto_absence_notification" <?php echo ($current_settings['auto_absence_notification'] ?? 0) ? 'checked' : ''; ?>>
                                <span class="slider"></span>
                            </label>
                            <span><strong>Absence Alerts:</strong> Notify parents when student is marked absent</span>
                        </label>
                        
                        <label style="display: flex; align-items: center; gap: 10px;">
                            <label class="toggle-switch">
                                <input type="checkbox" name="auto_fee_reminder" <?php echo ($current_settings['auto_fee_reminder'] ?? 0) ? 'checked' : ''; ?>>
                                <span class="slider"></span>
                            </label>
                            <span><strong>Fee Reminders:</strong> Automatic reminders for outstanding fees</span>
                        </label>
                        
                        <label style="display: flex; align-items: center; gap: 10px;">
                            <label class="toggle-switch">
                                <input type="checkbox" name="auto_result_notification" <?php echo ($current_settings['auto_result_notification'] ?? 0) ? 'checked' : ''; ?>>
                                <span class="slider"></span>
                            </label>
                            <span><strong>Result Notifications:</strong> Alert when exam results are published</span>
                        </label>
                        
                        <label style="display: flex; align-items: center; gap: 10px;">
                            <label class="toggle-switch">
                                <input type="checkbox" name="auto_exam_reminder" <?php echo ($current_settings['auto_exam_reminder'] ?? 0) ? 'checked' : ''; ?>>
                                <span class="slider"></span>
                            </label>
                            <span><strong>Exam Reminders:</strong> Notify students/parents before exams</span>
                        </label>
                    </div>
                    
                    <div style="text-align: right; margin-top: 25px;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Notification Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Payment Gateways Tab -->
    <div id="gateways" class="tab-content <?php echo ($current_tab === 'gateways') ? 'active' : ''; ?>">
        <div class="settings-card">
            <div class="settings-section">
                <h3><i class="fas fa-credit-card"></i> Payment Gateway Settings</h3>
                
                <div class="info-box">
                    <i class="fas fa-info-circle"></i>
                    <strong>Payment Gateways:</strong> Configure online payment methods for school fees (tuition, exam fees, etc).
                </div>
                
                <form method="POST">
                    <input type="hidden" name="action" value="save_payment_gateways">
                    
                    <!-- MTN Mobile Money -->
                    <div class="gateway-card <?php echo ($current_settings['mtn_momo_enabled'] ?? 0) ? 'enabled' : ''; ?>">
                        <div class="gateway-header">
                            <div>
                                <h4 style="margin: 0; color: #FFCC00;">
                                    <i class="fas fa-mobile-alt"></i> MTN Mobile Money
                                </h4>
                                <p style="margin: 5px 0 0 0; color: var(--text-secondary); font-size: 14px;">
                                    Ghana's leading mobile money service
                                </p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="mtn_momo_enabled" value="1" 
                                       <?php echo ($current_settings['mtn_momo_enabled'] ?? 0) ? 'checked' : ''; ?>>
                                <span class="slider"></span>
                            </label>
                        </div>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label>API URL</label>
                                <input type="url" name="mtn_momo_api_url" class="form-control" 
                                       value="<?php echo htmlspecialchars($current_settings['mtn_momo_api_url'] ?? 'https://sandbox.momodeveloper.mtn.com'); ?>"
                                       placeholder="https://sandbox.momodeveloper.mtn.com">
                            </div>
                            
                            <div class="form-group">
                                <label>API Key</label>
                                <input type="text" name="mtn_momo_api_key" class="form-control" 
                                       value="<?php echo htmlspecialchars($current_settings['mtn_momo_api_key'] ?? ''); ?>"
                                       placeholder="Enter your MTN MoMo API Key">
                            </div>
                            
                            <div class="form-group">
                                <label>User ID</label>
                                <input type="text" name="mtn_momo_user_id" class="form-control" 
                                       value="<?php echo htmlspecialchars($current_settings['mtn_momo_user_id'] ?? ''); ?>"
                                       placeholder="Enter your User ID">
                            </div>
                            
                            <div class="form-group">
                                <label>Subscription Key</label>
                                <input type="text" name="mtn_momo_subscription_key" class="form-control" 
                                       value="<?php echo htmlspecialchars($current_settings['mtn_momo_subscription_key'] ?? ''); ?>"
                                       placeholder="Enter your Subscription Key">
                            </div>
                            
                            <div class="form-group">
                                <label>Environment</label>
                                <select name="mtn_momo_environment" class="form-control">
                                    <option value="sandbox" <?php echo ($current_settings['mtn_momo_environment'] ?? 'sandbox') == 'sandbox' ? 'selected' : ''; ?>>Sandbox (Testing)</option>
                                    <option value="production" <?php echo ($current_settings['mtn_momo_environment'] ?? '') == 'production' ? 'selected' : ''; ?>>Production (Live)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Tigo Cash -->
                    <div class="gateway-card <?php echo ($current_settings['tigo_cash_enabled'] ?? 0) ? 'enabled' : ''; ?>">
                        <div class="gateway-header">
                            <div>
                                <h4 style="margin: 0; color: #0066CC;">
                                    <i class="fas fa-money-bill-wave"></i> Tigo Cash
                                </h4>
                                <p style="margin: 5px 0 0 0; color: var(--text-secondary); font-size: 14px;">
                                    Alternative mobile money payment
                                </p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="tigo_cash_enabled" value="1" 
                                       <?php echo ($current_settings['tigo_cash_enabled'] ?? 0) ? 'checked' : ''; ?>>
                                <span class="slider"></span>
                            </label>
                        </div>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label>API URL</label>
                                <input type="url" name="tigo_cash_api_url" class="form-control" 
                                       value="<?php echo htmlspecialchars($current_settings['tigo_cash_api_url'] ?? 'https://api.tigo.com'); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Merchant Code</label>
                                <input type="text" name="tigo_cash_merchant_code" class="form-control" 
                                       value="<?php echo htmlspecialchars($current_settings['tigo_cash_merchant_code'] ?? ''); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Merchant PIN</label>
                                <input type="password" name="tigo_cash_merchant_pin" class="form-control" 
                                       value="<?php echo htmlspecialchars($current_settings['tigo_cash_merchant_pin'] ?? ''); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>API Username</label>
                                <input type="text" name="tigo_cash_username" class="form-control" 
                                       value="<?php echo htmlspecialchars($current_settings['tigo_cash_username'] ?? ''); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>API Password</label>
                                <input type="password" name="tigo_cash_password" class="form-control" 
                                       value="<?php echo htmlspecialchars($current_settings['tigo_cash_password'] ?? ''); ?>">
                            </div>
                        </div>
                    </div>
                    
                    <!-- PayStack -->
                    <div class="gateway-card <?php echo ($current_settings['paystack_enabled'] ?? 0) ? 'enabled' : ''; ?>">
                        <div class="gateway-header">
                            <div>
                                <h4 style="margin: 0; color: #00C3F7;">
                                    <i class="fas fa-credit-card"></i> PayStack
                                </h4>
                                <p style="margin: 5px 0 0 0; color: var(--text-secondary); font-size: 14px;">
                                    Accept card payments (Visa, Mastercard, Verve)
                                </p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" name="paystack_enabled" value="1" 
                                       <?php echo ($current_settings['paystack_enabled'] ?? 0) ? 'checked' : ''; ?>>
                                <span class="slider"></span>
                            </label>
                        </div>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label>Public Key</label>
                                <input type="text" name="paystack_public_key" class="form-control" 
                                       value="<?php echo htmlspecialchars($current_settings['paystack_public_key'] ?? ''); ?>"
                                       placeholder="pk_test_xxxxx or pk_live_xxxxx">
                                <small style="color: var(--text-secondary); margin-top: 5px; display: block;">Starts with pk_test_ or pk_live_</small>
                            </div>
                            
                            <div class="form-group">
                                <label>Secret Key</label>
                                <input type="password" name="paystack_secret_key" class="form-control" 
                                       value="<?php echo htmlspecialchars($current_settings['paystack_secret_key'] ?? ''); ?>"
                                       placeholder="sk_test_xxxxx or sk_live_xxxxx">
                                <small style="color: var(--text-secondary); margin-top: 5px; display: block;">Starts with sk_test_ or sk_live_</small>
                            </div>
                        </div>
                    </div>
                    
                    <div style="text-align: right; margin-top: 25px;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Payment Gateway Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
    function switchTab(tabName) {
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        
        // Remove active class from all buttons
        document.querySelectorAll('.settings-tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Show selected tab
        document.getElementById(tabName).classList.add('active');
        
        // Add active class to clicked button
        event.target.closest('.settings-tab-btn').classList.add('active');
        
        // Update URL
        window.history.replaceState({}, '', '?tab=' + tabName);
    }
    
    function selectProvider(provider) {
        document.getElementById('sms_provider').value = provider;
        
        document.querySelectorAll('.provider-card').forEach(card => {
            card.classList.remove('selected');
        });
        document.getElementById('card-' + provider).classList.add('selected');
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
