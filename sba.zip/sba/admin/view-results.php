<?php
// admin/view-results.php - View All Student Results
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'View Results';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Auto-create student_assessments table if it doesn't exist
try {
    $db->query("SELECT 1 FROM student_assessments LIMIT 1");
} catch (PDOException $e) {
    try {
        $sql = "CREATE TABLE IF NOT EXISTS `student_assessments` (
          `assessment_id` int(11) NOT NULL AUTO_INCREMENT,
          `school_id` int(11) NOT NULL,
          `student_id` int(11) NOT NULL,
          `class_id` int(11) NOT NULL,
          `subject_id` int(11) NOT NULL,
          `term_id` int(11) NOT NULL,
          `teacher_id` int(11),
          `ca_score` decimal(5,2) DEFAULT 0,
          `midterm_score` decimal(5,2) DEFAULT 0,
          `exam_score` decimal(5,2) DEFAULT 0,
          `total_score` decimal(5,2) DEFAULT 0,
          `grade` varchar(10),
          `remark` varchar(255),
          `position` int(11),
          `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`assessment_id`),
          KEY `school_id` (`school_id`),
          KEY `student_id` (`student_id`),
          KEY `class_id` (`class_id`),
          KEY `subject_id` (`subject_id`),
          KEY `term_id` (`term_id`),
          KEY `teacher_id` (`teacher_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        $db->exec($sql);
    } catch (PDOException $e) {
        // Table creation failed
    }
}

// Get active term
try {
    $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_active = 1");
    $stmt->execute([$school_id]);
    $active_term = $stmt->fetch();
} catch (PDOException $e) {
    try {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_current = 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    } catch (PDOException $e2) {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY start_date DESC LIMIT 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    }
}

// Get filters
$class_filter = $_GET['class'] ?? 'all';
$subject_filter = $_GET['subject'] ?? 'all';
$search = $_GET['search'] ?? '';

// Get classes
$classes = [];
try {
    $has_school_id = count($db->query("SHOW COLUMNS FROM classes LIKE 'school_id'")->fetchAll()) > 0;
    if ($has_school_id) {
        $stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
        $stmt->execute([$school_id]);
    } else {
        $stmt = $db->prepare("SELECT * FROM classes ORDER BY class_name");
        $stmt->execute();
    }
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $classes = [];
}

// Get subjects
$subjects = [];
try {
    $has_school_id = count($db->query("SHOW COLUMNS FROM subjects LIKE 'school_id'")->fetchAll()) > 0;
    if ($has_school_id) {
        $stmt = $db->prepare("SELECT * FROM subjects WHERE school_id = ? ORDER BY subject_name");
        $stmt->execute([$school_id]);
    } else {
        $stmt = $db->prepare("SELECT * FROM subjects ORDER BY subject_name");
        $stmt->execute();
    }
    $subjects = $stmt->fetchAll();
} catch (PDOException $e) {
    $subjects = [];
}

// Get results
$results = [];
if ($active_term) {
    try {
        // Check if school_id column exists in student_assessments
        $has_school_id = count($db->query("SHOW COLUMNS FROM student_assessments LIKE 'school_id'")->fetchAll()) > 0;
        
        $query = "
            SELECT 
                s.student_id,
                s.admission_number,
                COALESCE(u.first_name, s.first_name, '-') as first_name,
                COALESCE(u.last_name, s.last_name, '') as last_name,
                c.class_name,
                subj.subject_name,
                sa.ca_score,
                sa.midterm_score,
                sa.exam_score,
                sa.total_score,
                sa.grade,
                sa.remark,
                CONCAT(COALESCE(u2.first_name, ''), ' ', COALESCE(u2.last_name, '')) as teacher_name
            FROM student_assessments sa
            INNER JOIN students s ON sa.student_id = s.student_id
            INNER JOIN classes c ON sa.class_id = c.class_id
            INNER JOIN subjects subj ON sa.subject_id = subj.subject_id
            LEFT JOIN users u ON s.user_id = u.user_id
            LEFT JOIN users u2 ON sa.teacher_id = u2.user_id
            WHERE sa.term_id = ?
        ";
        
        $params = [$active_term['term_id']];
        
        if ($class_filter != 'all') {
            $query .= " AND sa.class_id = ?";
            $params[] = $class_filter;
        }
        
        if ($subject_filter != 'all') {
            $query .= " AND sa.subject_id = ?";
            $params[] = $subject_filter;
        }
        
        if ($search) {
            $query .= " AND (s.admission_number LIKE ? OR COALESCE(u.first_name, '') LIKE ? OR COALESCE(u.last_name, '') LIKE ?)";
            $search_term = "%$search%";
            $params[] = $search_term;
            $params[] = $search_term;
            $params[] = $search_term;
        }
        
        $query .= " ORDER BY c.class_name, s.admission_number, subj.subject_name";
        
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $results = $stmt->fetchAll();
    } catch (PDOException $e) {
        // student_assessments table doesn't exist yet
        $results = [];
    }
}
        
        // ... existing code ...

// Calculate statistics
$total_results = count($results);
$avg_total = $total_results > 0 ? round(array_sum(array_column($results, 'total_score')) / $total_results, 2) : 0;
$pass_count = count(array_filter($results, function($r) { return $r['total_score'] >= 50; }));
$fail_count = $total_results - $pass_count;
$pass_rate = $total_results > 0 ? round(($pass_count / $total_results) * 100, 1) : 0;

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .grade-badge {
        display: inline-block;
        padding: 5px 12px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 12px;
    }
    
    .grade-A-plus, .grade-A { background: #4CAF50; color: white; }
    .grade-B-plus, .grade-B { background: #2196F3; color: white; }
    .grade-C-plus, .grade-C { background: #FF9800; color: white; }
    .grade-D { background: #FFC107; color: black; }
    .grade-F { background: #F44336; color: white; }
    </style>
    
    <!-- Active Term Banner -->
    <?php if ($active_term): ?>
        <div class="card" style="margin-bottom: 10px; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white;">
            <div style="padding: 20px;">
                <h3 style="margin: 0 0 2px 0; color: white;">
                    <i class="fas fa-calendar-check"></i> Viewing Results For
                </h3>
                <h2 style="margin: 0; color: white;"><?php echo $active_term['term_name']; ?></h2>
                <p style="margin: 5px 0 0 0; opacity: 0.9;">
                    <?php echo isset($active_term['session_year']) ? $active_term['session_year'] : ''; ?>
                </p>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            <i class="fas fa-exclamation-triangle"></i>
            <strong>No Active Term!</strong> Please set an active term to view results.
        </div>
    <?php endif; ?>
    
    <!-- Statistics -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-file-alt"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $total_results; ?></h3>
                <p>Total Results</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $pass_count; ?></h3>
                <p>Passed (≥50)</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon red">
                <i class="fas fa-times-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $fail_count; ?></h3>
                <p>Failed (<50)</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $pass_rate; ?>%</h3>
                <p>Pass Rate</p>
            </div>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-filter"></i> Filter Results</h3>
        </div>
        <div style="padding: 20px;">
            <form method="GET">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 15px;">
                    <div>
                        <label>Class:</label>
                        <select name="class" class="form-control">
                            <option value="all">All Classes</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>" <?php echo $class_filter == $class['class_id'] ? 'selected' : ''; ?>>
                                    <?php echo $class['class_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div>
                        <label>Subject:</label>
                        <select name="subject" class="form-control">
                            <option value="all">All Subjects</option>
                            <?php foreach ($subjects as $subject): ?>
                                <option value="<?php echo $subject['subject_id']; ?>" <?php echo $subject_filter == $subject['subject_id'] ? 'selected' : ''; ?>>
                                    <?php echo $subject['subject_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div>
                        <label>Search Student:</label>
                        <input type="text" name="search" class="form-control" placeholder="Name or Admission No." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <div style="display: flex; align-items: flex-end; gap: 10px;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i> Filter
                        </button>
                        <a href="?" class="btn btn-secondary">
                            <i class="fas fa-redo"></i> Reset
                        </a>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Publish/Unpublish Controls -->
    <?php if ($active_term): ?>
        <div class="card" style="margin-bottom: 20px; background: linear-gradient(135deg, #FF9800, #F57C00); color: white;">
            <div style="padding: 20px;">
                <h3 style="margin: 0 0 10px 0; color: white;">
                    <i class="fas fa-eye"></i> Parent Visibility Controls
                </h3>
                <p style="margin: 0 0 15px 0; opacity: 0.9; font-size: 14px;">
                    Control which results parents can see on their portal. Published results are visible to parents immediately.
                </p>
                <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <button onclick="publishResults(true, <?php echo $class_filter != 'all' ? $class_filter : 'null'; ?>)" 
                            class="btn" style="background: white; color: #FF9800;">
                        <i class="fas fa-check-circle"></i> 
                        <?php echo $class_filter != 'all' ? 'Publish This Class' : 'Publish All Results'; ?>
                    </button>
                    <button onclick="publishResults(false, <?php echo $class_filter != 'all' ? $class_filter : 'null'; ?>)" 
                            class="btn" style="background: rgba(255,255,255,0.2); color: white;">
                        <i class="fas fa-eye-slash"></i> 
                        <?php echo $class_filter != 'all' ? 'Unpublish This Class' : 'Unpublish All Results'; ?>
                    </button>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Results Table -->
    <div class="card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
            <h3><i class="fas fa-table"></i> Student Results (<?php echo $total_results; ?>)</h3>
            <div>
                <a href="<?php echo APP_URL; ?>/admin/generate-results.php" class="btn btn-success btn-sm">
                    <i class="fas fa-file-pdf"></i> Generate Results
                </a>
            </div>
        </div>
        <div style="padding: 20px;">
            <?php if (count($results) > 0): ?>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 50px;">#</th>
                                <th>Admission No.</th>
                                <th>Student Name</th>
                                <th>Class</th>
                                <th>Subject</th>
                                <th style="text-align: center;">CA</th>
                                <th style="text-align: center;">Midterm</th>
                                <th style="text-align: center;">Exam</th>
                                <th style="text-align: center;">Total</th>
                                <th style="text-align: center;">Grade</th>
                                <th>Remark</th>
                                <th>Teacher</th>
                                <th style="text-align: center; width: 80px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $count = 1; ?>
                            <?php foreach ($results as $result): ?>
                                <tr>
                                    <td><?php echo $count++; ?></td>
                                    <td><?php echo $result['admission_number']; ?></td>
                                    <td><strong><?php echo $result['first_name'] . ' ' . $result['last_name']; ?></strong></td>
                                    <td><?php echo $result['class_name']; ?></td>
                                    <td><?php echo $result['subject_name']; ?></td>
                                    <td style="text-align: center;"><?php echo $result['ca_score'] ?? '-'; ?></td>
                                    <td style="text-align: center;"><?php echo $result['midterm_score'] ?? '-'; ?></td>
                                    <td style="text-align: center;"><?php echo $result['exam_score'] ?? '-'; ?></td>
                                    <td style="text-align: center;"><strong><?php echo $result['total_score']; ?></strong></td>
                                    <td style="text-align: center;">
                                        <span class="grade-badge grade-<?php echo str_replace('+', '-plus', $result['grade']); ?>">
                                            <?php echo $result['grade']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $result['remark']; ?></td>
                                    <td style="font-size: 12px;"><?php echo $result['teacher_name']; ?></td>
                                    <td style="text-align: center;">
                                        <a href="?preview=1&student=<?php echo $result['student_id']; ?>" class="btn btn-info btn-xs" title="View Report">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 60px;">
                    <i class="fas fa-inbox" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                    <h3>No Results Found</h3>
                    <p style="color: var(--text-secondary);">
                        <?php if ($class_filter != 'all' || $subject_filter != 'all' || $search): ?>
                            Try adjusting your filters or search criteria.
                        <?php else: ?>
                            No assessment results have been entered yet.
                        <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php
    // Handle single student report preview
    if (isset($_GET['preview']) && isset($_GET['student'])) {
        $preview_student_id = (int)$_GET['student'];
        
        // Get student details
        $stmt = $db->prepare("
            SELECT s.*, c.class_name, 
                   COALESCE(u.first_name, s.first_name, '-') as first_name, 
                   COALESCE(u.last_name, s.last_name, '') as last_name
            FROM students s
            LEFT JOIN classes c ON s.class_id = c.class_id
            LEFT JOIN users u ON s.user_id = u.user_id
            WHERE s.student_id = ? AND s.school_id = ?
        ");
        $stmt->execute([$preview_student_id, $school_id]);
        $preview_student = $stmt->fetch();
        
        if ($preview_student && $active_term) {
            echo "\n<!-- Student Report Preview -->\n";
            echo "<div class='card' style='margin-top: 30px; background: #f9f9f9;'>\n";
            echo "    <div class='card-header' style='background: linear-gradient(135deg, #4CAF50, #45a049); color: white;'>\n";
            echo "        <h3 style='color: white; margin: 0;'>\n";
            echo "            <i class='fas fa-file-alt'></i> Report Preview - " . htmlspecialchars($preview_student['first_name'] . ' ' . $preview_student['last_name']) . "\n";
            echo "        </h3>\n";
            echo "    </div>\n";
            echo "    <div style='padding: 30px;'>\n";
            
            // Get student's assessment results for active term
            try {
                $stmt = $db->prepare("
                    SELECT 
                        c.class_name,
                        s.subject_name,
                        sa.ca_score,
                        sa.midterm_score,
                        sa.exam_score,
                        sa.total_score,
                        sa.grade,
                        sa.remark,
                        u.first_name as teacher_first_name,
                        u.last_name as teacher_last_name
                    FROM student_assessments sa
                    JOIN classes c ON sa.class_id = c.class_id
                    JOIN subjects s ON sa.subject_id = s.subject_id
                    LEFT JOIN users u ON sa.teacher_id = u.user_id
                    WHERE sa.student_id = ? AND sa.school_id = ? AND sa.term_id = ?
                    ORDER BY s.subject_name
                ");
                $stmt->execute([$preview_student_id, $school_id, $active_term['term_id']]);
                $student_results = $stmt->fetchAll();
                
                if (count($student_results) > 0) {
                    echo "        <div style='margin-bottom: 25px; background: white; padding: 15px; border-radius: 8px;'>\n";
                    echo "            <div style='display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;'>\n";
                    echo "                <div>\n";
                    echo "                    <strong style='color: var(--text-secondary);'>Admission Number:</strong><br/>\n";
                    echo "                    <span style='font-size: 16px; font-weight: bold;'>" . htmlspecialchars($preview_student['admission_number']) . "</span>\n";
                    echo "                </div>\n";
                    echo "                <div>\n";
                    echo "                    <strong style='color: var(--text-secondary);'>Student Name:</strong><br/>\n";
                    echo "                    <span style='font-size: 16px; font-weight: bold;'>" . htmlspecialchars($preview_student['first_name'] . ' ' . $preview_student['last_name']) . "</span>\n";
                    echo "                </div>\n";
                    echo "                <div>\n";
                    echo "                    <strong style='color: var(--text-secondary);'>Class:</strong><br/>\n";
                    echo "                    <span style='font-size: 16px; font-weight: bold;'>" . htmlspecialchars($preview_student['class_name']) . "</span>\n";
                    echo "                </div>\n";
                    echo "                <div>\n";
                    echo "                    <strong style='color: var(--text-secondary);'>Term:</strong><br/>\n";
                    echo "                    <span style='font-size: 16px; font-weight: bold;'>" . htmlspecialchars($active_term['term_name']) . "</span>\n";
                    echo "                </div>\n";
                    echo "            </div>\n";
                    echo "        </div>\n";
                    
                    // Calculate subject average
                    $total_score_sum = array_sum(array_column($student_results, 'total_score'));
                    $subject_count = count($student_results);
                    $average = $subject_count > 0 ? round($total_score_sum / $subject_count, 2) : 0;
                    
                    echo "        <table style='width: 100%; border-collapse: collapse; margin-bottom: 20px;'>\n";
                    echo "            <thead>\n";
                    echo "                <tr style='background: #2196F3; color: white;'>\n";
                    echo "                    <th style='padding: 12px; text-align: left; border: 1px solid #ddd;'>Subject</th>\n";
                    echo "                    <th style='padding: 12px; text-align: center; border: 1px solid #ddd;'>CA</th>\n";
                    echo "                    <th style='padding: 12px; text-align: center; border: 1px solid #ddd;'>Midterm</th>\n";
                    echo "                    <th style='padding: 12px; text-align: center; border: 1px solid #ddd;'>Exam</th>\n";
                    echo "                    <th style='padding: 12px; text-align: center; border: 1px solid #ddd;'>Total</th>\n";
                    echo "                    <th style='padding: 12px; text-align: center; border: 1px solid #ddd;'>Grade</th>\n";
                    echo "                    <th style='padding: 12px; text-align: left; border: 1px solid #ddd;'>Remark</th>\n";
                    echo "                    <th style='padding: 12px; text-align: left; border: 1px solid #ddd;'>Teacher</th>\n";
                    echo "                </tr>\n";
                    echo "            </thead>\n";
                    echo "            <tbody>\n";
                    
                    foreach ($student_results as $row) {
                        $teacher_name = ($row['teacher_first_name'] && $row['teacher_last_name']) ? 
                            htmlspecialchars($row['teacher_first_name'] . ' ' . $row['teacher_last_name']) : '-';
                        
                        echo "                <tr style='background: #fff;'>\n";
                        echo "                    <td style='padding: 12px; border: 1px solid #ddd;'>" . htmlspecialchars($row['subject_name']) . "</td>\n";
                        echo "                    <td style='padding: 12px; border: 1px solid #ddd; text-align: center;'>" . ($row['ca_score'] ?? '-') . "</td>\n";
                        echo "                    <td style='padding: 12px; border: 1px solid #ddd; text-align: center;'>" . ($row['midterm_score'] ?? '-') . "</td>\n";
                        echo "                    <td style='padding: 12px; border: 1px solid #ddd; text-align: center;'>" . ($row['exam_score'] ?? '-') . "</td>\n";
                        echo "                    <td style='padding: 12px; border: 1px solid #ddd; text-align: center; font-weight: bold;'>" . ($row['total_score'] ?? '-') . "</td>\n";
                        echo "                    <td style='padding: 12px; border: 1px solid #ddd; text-align: center; font-weight: bold;'>" . htmlspecialchars($row['grade'] ?? '-') . "</td>\n";
                        echo "                    <td style='padding: 12px; border: 1px solid #ddd;'>" . htmlspecialchars($row['remark'] ?? '-') . "</td>\n";
                        echo "                    <td style='padding: 12px; border: 1px solid #ddd;'>" . $teacher_name . "</td>\n";
                        echo "                </tr>\n";
                    }
                    
                    echo "            </tbody>\n";
                    echo "        </table>\n";
                    
                    echo "        <div style='background: white; padding: 15px; border-radius: 8px; margin-top: 20px; border: 2px solid #2196F3;'>\n";
                    echo "            <div style='display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;'>\n";
                    echo "                <div style='text-align: center;'>\n";
                    echo "                    <strong style='color: var(--text-secondary);'>Total Subjects</strong><br/>\n";
                    echo "                    <span style='font-size: 24px; font-weight: bold; color: #2196F3;'>" . $subject_count . "</span>\n";
                    echo "                </div>\n";
                    echo "                <div style='text-align: center;'>\n";
                    echo "                    <strong style='color: var(--text-secondary);'>Total Score</strong><br/>\n";
                    echo "                    <span style='font-size: 24px; font-weight: bold; color: #4CAF50;'>" . $total_score_sum . "</span>\n";
                    echo "                </div>\n";
                    echo "                <div style='text-align: center;'>\n";
                    echo "                    <strong style='color: var(--text-secondary);'>Average Score</strong><br/>\n";
                    echo "                    <span style='font-size: 24px; font-weight: bold; color: #FF9800;'>" . $average . "</span>\n";
                    echo "                </div>\n";
                    echo "            </div>\n";
                    echo "        </div>\n";
                } else {
                    echo "        <div class='alert alert-warning'>\n";
                    echo "            <i class='fas fa-exclamation-triangle'></i>\n";
                    echo "            <strong>No Assessment Data:</strong> This student has no assessment results for the active term.\n";
                    echo "        </div>\n";
                }
            } catch (PDOException $e) {
                echo "        <div class='alert alert-danger'>\n";
                echo "            <i class='fas fa-exclamation-circle'></i>\n";
                echo "            <strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "\n";
                echo "        </div>\n";
            }
            
            echo "        <div style='margin-top: 20px; text-align: center;'>\n";
            echo "            <a href='?" . (isset($_GET['class']) ? 'class=' . $_GET['class'] . '&' : '') . (isset($_GET['subject']) ? 'subject=' . $_GET['subject'] . '&' : '') . (isset($_GET['search']) ? 'search=' . urlencode($_GET['search']) : '') . "' class='btn btn-secondary'>\n";
            echo "                <i class='fas fa-arrow-left'></i> Back to Results\n";
            echo "            </a>\n";
            echo "        </div>\n";
            echo "    </div>\n";
            echo "</div>\n";
        }
    }
    ?>
    
    <script>
    function publishResults(publish, classId) {
        const action = publish ? 'publish' : 'unpublish';
        const classText = classId ? 'this class' : 'all results';
        
        if (!confirm(`Are you sure you want to ${action} ${classText} for parents to view?`)) {
            return;
        }
        
        const data = {
            term_id: <?php echo $active_term ? $active_term['term_id'] : 0; ?>,
            class_id: classId,
            publish: publish ? 1 : 0
        };
        
        fetch('<?php echo APP_URL; ?>/admin/ajax/toggle-publish-results.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                alert(result.message);
                location.reload();
            } else {
                alert('Error: ' + result.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while updating results');
        });
    }
    </script>
    
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>

