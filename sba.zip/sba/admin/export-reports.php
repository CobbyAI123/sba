<?php
// admin/export-reports.php - Data Export and Reporting
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Export Reports';
$current_user = check_permission(['admin', 'super-admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle export requests
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['export_type'])) {
    $export_type = sanitize_input($_POST['export_type']);
    
    // Set proper headers for CSV download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $export_type . '_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    try {
        if ($export_type === 'students') {
            // Export students
            fputcsv($output, ['First Name', 'Last Name', 'Admission Number', 'Class', 'Gender', 'Phone', 'Email', 'Status', 'Date Admitted']);
            
            $stmt = $db->prepare("
                SELECT s.first_name, s.last_name, s.admission_number, c.class_name, s.gender, s.phone, s.email, s.status, s.date_admitted
                FROM students s
                LEFT JOIN classes c ON s.class_id = c.class_id
                WHERE s.school_id = ?
                ORDER BY s.first_name
            ");
            $stmt->execute([$school_id]);
            foreach ($stmt->fetchAll() as $row) {
                fputcsv($output, $row);
            }
        }
        
        elseif ($export_type === 'teachers') {
            // Export teachers
            fputcsv($output, ['First Name', 'Last Name', 'Email', 'Phone', 'Specialization', 'Employment Date', 'Status']);
            
            $stmt = $db->prepare("
                SELECT first_name, last_name, email, phone, specialization, employment_date, status
                FROM users
                WHERE school_id = ? AND role = 'teacher'
                ORDER BY first_name
            ");
            $stmt->execute([$school_id]);
            foreach ($stmt->fetchAll() as $row) {
                fputcsv($output, $row);
            }
        }
        
        elseif ($export_type === 'payments') {
            // Export payment records
            fputcsv($output, ['Date', 'Student Name', 'Admission #', 'Amount', 'Payment Method', 'Reference', 'Class']);
            
            $stmt = $db->prepare("
                SELECT p.created_at, CONCAT(s.first_name, ' ', s.last_name), s.admission_number, p.amount, p.payment_method, p.payment_reference, c.class_name
                FROM payments p
                INNER JOIN students s ON p.student_id = s.student_id
                LEFT JOIN classes c ON s.class_id = c.class_id
                WHERE p.school_id = ?
                ORDER BY p.created_at DESC
            ");
            $stmt->execute([$school_id]);
            foreach ($stmt->fetchAll() as $row) {
                fputcsv($output, $row);
            }
        }
        
        elseif ($export_type === 'attendance') {
            // Export attendance
            fputcsv($output, ['Date', 'Student Name', 'Admission #', 'Class', 'Status']);
            
            $stmt = $db->prepare("
                SELECT a.created_at, CONCAT(s.first_name, ' ', s.last_name), s.admission_number, c.class_name, a.status
                FROM attendance a
                INNER JOIN students s ON a.student_id = s.student_id
                LEFT JOIN classes c ON s.class_id = c.class_id
                WHERE a.school_id = ?
                ORDER BY a.created_at DESC
            ");
            $stmt->execute([$school_id]);
            foreach ($stmt->fetchAll() as $row) {
                fputcsv($output, $row);
            }
        }
        
        elseif ($export_type === 'marks') {
            // Export exam marks
            fputcsv($output, ['Student Name', 'Admission #', 'Class', 'Exam', 'Subject', 'CA Score', 'Exam Score', 'Total Score', 'Grade']);
            
            $stmt = $db->prepare("
                SELECT CONCAT(s.first_name, ' ', s.last_name), s.admission_number, c.class_name, e.exam_name, sub.subject_name, m.ca_score, m.exam_score, m.total_score, m.grade
                FROM marks m
                INNER JOIN students s ON m.student_id = s.student_id
                INNER JOIN exams e ON m.exam_id = e.exam_id
                INNER JOIN subjects sub ON m.subject_id = sub.subject_id
                LEFT JOIN classes c ON s.class_id = c.class_id
                WHERE s.school_id = ?
                ORDER BY e.created_at DESC, s.first_name
            ");
            $stmt->execute([$school_id]);
            foreach ($stmt->fetchAll() as $row) {
                fputcsv($output, $row);
            }
        }
        
        elseif ($export_type === 'books') {
            // Export books
            fputcsv($output, ['Title', 'ISBN', 'Author', 'Category', 'Total Copies', 'Available Copies', 'Date Added']);
            
            $stmt = $db->prepare("
                SELECT b.title, b.isbn, b.author, b.category, b.quantity, 
                       (b.quantity - (SELECT COUNT(*) FROM book_issues WHERE book_id = b.book_id AND return_date IS NULL)) as available,
                       b.created_at
                FROM books b
                WHERE b.school_id = ?
                ORDER BY b.title
            ");
            $stmt->execute([$school_id]);
            foreach ($stmt->fetchAll() as $row) {
                fputcsv($output, $row);
            }
        }
        
        elseif ($export_type === 'fees') {
            // Export fee structure
            fputcsv($output, ['Class', 'Term', 'Fee Type', 'Amount', 'Description']);
            
            $stmt = $db->prepare("
                SELECT c.class_name, t.term_name, fs.fee_type, fs.amount, fs.description
                FROM fee_structure fs
                LEFT JOIN classes c ON fs.class_id = c.class_id
                LEFT JOIN terms t ON fs.term_id = t.term_id
                WHERE fs.school_id = ?
                ORDER BY c.class_name, t.term_name
            ");
            $stmt->execute([$school_id]);
            foreach ($stmt->fetchAll() as $row) {
                fputcsv($output, $row);
            }
        }
        
        fclose($output);
        exit;
    } catch (Exception $e) {
        set_message('error', 'Error generating export');
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Export Options -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-download"></i> Download Data Reports</h3>
        </div>
        <div style="padding: 30px;">
            <p style="color: var(--text-secondary); margin-bottom: 25px;">
                Export data from various modules in CSV format for analysis, backup, or sharing with stakeholders.
            </p>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                <!-- Students Export -->
                <form method="POST" style="padding: 20px; border: 1px solid var(--border-color); border-radius: 10px;">
                    <input type="hidden" name="export_type" value="students">
                    <div style="text-align: center; margin-bottom: 15px;">
                        <i class="fas fa-user-graduate" style="font-size: 2.5em; color: var(--info-blue); margin-bottom: 10px; display: block;"></i>
                        <h4 style="margin: 0;">Student Directory</h4>
                        <small style="color: var(--text-secondary);">All student records</small>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-download"></i> Export Students
                    </button>
                </form>
                
                <!-- Teachers Export -->
                <form method="POST" style="padding: 20px; border: 1px solid var(--border-color); border-radius: 10px;">
                    <input type="hidden" name="export_type" value="teachers">
                    <div style="text-align: center; margin-bottom: 15px;">
                        <i class="fas fa-chalkboard-user" style="font-size: 2.5em; color: var(--warning-orange); margin-bottom: 10px; display: block;"></i>
                        <h4 style="margin: 0;">Staff Directory</h4>
                        <small style="color: var(--text-secondary);">All teacher records</small>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-download"></i> Export Teachers
                    </button>
                </form>
                
                <!-- Payments Export -->
                <form method="POST" style="padding: 20px; border: 1px solid var(--border-color); border-radius: 10px;">
                    <input type="hidden" name="export_type" value="payments">
                    <div style="text-align: center; margin-bottom: 15px;">
                        <i class="fas fa-money-bill-wave" style="font-size: 2.5em; color: var(--success-green); margin-bottom: 10px; display: block;"></i>
                        <h4 style="margin: 0;">Payment Records</h4>
                        <small style="color: var(--text-secondary);">All payment transactions</small>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-download"></i> Export Payments
                    </button>
                </form>
                
                <!-- Attendance Export -->
                <form method="POST" style="padding: 20px; border: 1px solid var(--border-color); border-radius: 10px;">
                    <input type="hidden" name="export_type" value="attendance">
                    <div style="text-align: center; margin-bottom: 15px;">
                        <i class="fas fa-calendar-check" style="font-size: 2.5em; color: var(--teal-cyan); margin-bottom: 10px; display: block;"></i>
                        <h4 style="margin: 0;">Attendance Records</h4>
                        <small style="color: var(--text-secondary);">Daily attendance logs</small>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-download"></i> Export Attendance
                    </button>
                </form>
                
                <!-- Marks Export -->
                <form method="POST" style="padding: 20px; border: 1px solid var(--border-color); border-radius: 10px;">
                    <input type="hidden" name="export_type" value="marks">
                    <div style="text-align: center; margin-bottom: 15px;">
                        <i class="fas fa-chart-line" style="font-size: 2.5em; color: var(--purple-pink); margin-bottom: 10px; display: block;"></i>
                        <h4 style="margin: 0;">Exam Marks</h4>
                        <small style="color: var(--text-secondary);">All student marks and grades</small>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-download"></i> Export Marks
                    </button>
                </form>
                
                <!-- Books Export -->
                <form method="POST" style="padding: 20px; border: 1px solid var(--border-color); border-radius: 10px;">
                    <input type="hidden" name="export_type" value="books">
                    <div style="text-align: center; margin-bottom: 15px;">
                        <i class="fas fa-book-open" style="font-size: 2.5em; color: var(--pink-coral); margin-bottom: 10px; display: block;"></i>
                        <h4 style="margin: 0;">Book Catalog</h4>
                        <small style="color: var(--text-secondary);">Library inventory</small>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-download"></i> Export Books
                    </button>
                </form>
                
                <!-- Fees Export -->
                <form method="POST" style="padding: 20px; border: 1px solid var(--border-color); border-radius: 10px;">
                    <input type="hidden" name="export_type" value="fees">
                    <div style="text-align: center; margin-bottom: 15px;">
                        <i class="fas fa-receipt" style="font-size: 2.5em; color: var(--danger-red); margin-bottom: 10px; display: block;"></i>
                        <h4 style="margin: 0;">Fee Structure</h4>
                        <small style="color: var(--text-secondary);">Fee configuration</small>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-download"></i> Export Fees
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Export Information -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-info-circle"></i> About Data Exports</h3>
        </div>
        <div style="padding: 20px;">
            <h4>Format</h4>
            <p style="color: var(--text-secondary);">All exports are in CSV (Comma-Separated Values) format, which can be opened in Excel, Google Sheets, or any spreadsheet application.</p>
            
            <h4 style="margin-top: 20px;">Data Included</h4>
            <ul style="color: var(--text-secondary); line-height: 1.8;">
                <li><strong>Student Directory</strong> - Names, admission numbers, classes, contact information</li>
                <li><strong>Staff Directory</strong> - Names, contact info, specialization, employment dates</li>
                <li><strong>Payment Records</strong> - Transaction dates, amounts, methods, student information</li>
                <li><strong>Attendance Records</strong> - Daily attendance logs with student and class information</li>
                <li><strong>Exam Marks</strong> - All exam scores, grades, and student performance data</li>
                <li><strong>Book Catalog</strong> - Book titles, ISBNs, authors, inventory levels</li>
                <li><strong>Fee Structure</strong> - Fee types, amounts, and applicable classes</li>
            </ul>
            
            <h4 style="margin-top: 20px;">Usage</h4>
            <p style="color: var(--text-secondary);">
                Use these exports for backup, data analysis, reporting to stakeholders, or integration with external systems. 
                Files are timestamped with the export date for easy organization and record-keeping.
            </p>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
