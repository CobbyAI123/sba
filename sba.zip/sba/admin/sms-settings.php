<?php
// admin/sms-settings.php - SMS Configuration and Testing
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'SMS Settings';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

$success_msg = $error_msg = '';

// Get current settings
$settings = [];
try {
    $stmt = $db->prepare("
        SELECT setting_key, setting_value FROM settings 
        WHERE school_id = ? AND setting_key LIKE 'sms_%'
    ");
    $stmt->execute([$school_id]);
    $results = $stmt->fetchAll();
    foreach ($results as $row) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
} catch (Exception $e) {
    // No settings yet
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'save_settings') {
            try {
                $provider = sanitize_input($_POST['sms_provider']);
                $twilio_sid = sanitize_input($_POST['sms_twilio_sid'] ?? '');
                $twilio_token = sanitize_input($_POST['sms_twilio_token'] ?? '');
                $twilio_phone = sanitize_input($_POST['sms_twilio_phone'] ?? '');
                $from_name = sanitize_input($_POST['sms_from_name']);
                $enabled = isset($_POST['sms_enabled']) ? 1 : 0;
                $attendance_alerts = isset($_POST['sms_attendance_alerts']) ? 1 : 0;
                $fee_reminders = isset($_POST['sms_fee_reminders']) ? 1 : 0;
                $twofa_enabled = isset($_POST['sms_2fa_enabled']) ? 1 : 0;
                
                $settings_to_save = [
                    'sms_provider' => $provider,
                    'sms_twilio_sid' => $twilio_sid,
                    'sms_twilio_token' => $twilio_token,
                    'sms_twilio_phone' => $twilio_phone,
                    'sms_from_name' => $from_name,
                    'sms_enabled' => $enabled,
                    'sms_attendance_alerts' => $attendance_alerts,
                    'sms_fee_reminders' => $fee_reminders,
                    'sms_2fa_enabled' => $twofa_enabled
                ];
                
                foreach ($settings_to_save as $key => $value) {
                    $stmt = $db->prepare("
                        INSERT INTO settings (school_id, setting_key, setting_value) 
                        VALUES (?, ?, ?)
                        ON DUPLICATE KEY UPDATE setting_value = ?
                    ");
                    $stmt->execute([$school_id, $key, $value, $value]);
                }
                
                $success_msg = 'SMS settings saved successfully!';
                
                // Log activity
                if (isset($GLOBALS['audit_logger'])) {
                    $GLOBALS['audit_logger']->log(
                        'Updated SMS settings',
                        'settings',
                        null,
                        null,
                        ['provider' => $provider, 'enabled' => $enabled],
                        true
                    );
                }
                
            } catch (Exception $e) {
                $error_msg = 'Error saving settings: ' . $e->getMessage();
            }
        } elseif ($_POST['action'] === 'test_sms') {
            try {
                require_once BASE_PATH . '/includes/SMSGateway.php';
                $sms = new SMSGateway($db);
                
                $test_phone = sanitize_input($_POST['test_phone']);
                $test_message = 'Test SMS from School Management System. If you received this, SMS configuration is working!';
                
                $result = $sms->send($test_phone, $test_message, 'test');
                
                if ($result['success']) {
                    $success_msg = 'Test SMS sent successfully to ' . htmlspecialchars($test_phone);
                } else {
                    $error_msg = 'Failed to send test SMS: ' . $result['message'];
                }
            } catch (Exception $e) {
                $error_msg = 'Error: ' . $e->getMessage();
            }
        }
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
        .settings-form {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .form-section {
            background: var(--bg-card);
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            border: 1px solid var(--border-color);
        }
        
        .form-section h3 {
            margin: 0 0 20px 0;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--primary-blue);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            font-family: monospace;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(45, 91, 255, 0.1);
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 15px 0;
        }
        
        .checkbox-group input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        
        .checkbox-group label {
            margin: 0;
            cursor: pointer;
            font-weight: normal;
        }
        
        .helper-text {
            font-size: 12px;
            color: var(--text-secondary);
            margin-top: 5px;
        }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: rgba(52, 199, 89, 0.1);
            border-left: 4px solid #34C759;
            color: #34C759;
        }
        
        .alert-error {
            background: rgba(255, 59, 48, 0.1);
            border-left: 4px solid #FF3B30;
            color: #FF3B30;
        }
        
        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }
    </style>
    
    <div style="margin-bottom: 30px;">
        <h2><i class="fas fa-envelope"></i> SMS Configuration</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            Configure SMS gateway for attendance alerts and fee reminders
        </p>
    </div>
    
    <?php if (!empty($success_msg)): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?php echo $success_msg; ?>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($error_msg)): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i> <?php echo $error_msg; ?>
        </div>
    <?php endif; ?>
    
    <form method="POST" class="settings-form">
        <input type="hidden" name="action" value="save_settings">
        
        <!-- Provider Selection -->
        <div class="form-section">
            <h3><i class="fas fa-cog"></i> SMS Provider</h3>
            
            <div class="form-group">
                <label>Select SMS Provider</label>
                <select name="sms_provider" required>
                    <option value="twilio" <?php echo ($settings['sms_provider'] ?? 'twilio') === 'twilio' ? 'selected' : ''; ?>>Twilio</option>
                    <option value="local" <?php echo ($settings['sms_provider'] ?? '') === 'local' ? 'selected' : ''; ?>>Local Queue (Manual Processing)</option>
                </select>
                <p class="helper-text">Twilio: Automatic sending via Twilio API | Local: Queue SMS for manual processing</p>
            </div>
        </div>
        
        <!-- Twilio Configuration -->
        <div class="form-section" id="twilio-section" style="display: <?php echo ($settings['sms_provider'] ?? 'twilio') === 'twilio' ? 'block' : 'none'; ?>">
            <h3><i class="fas fa-key"></i> Twilio Credentials</h3>
            
            <div class="form-group">
                <label>Account SID</label>
                <input type="text" name="sms_twilio_sid" value="<?php echo htmlspecialchars($settings['sms_twilio_sid'] ?? ''); ?>" placeholder="Get from twilio.com">
                <p class="helper-text">Your Twilio Account SID</p>
            </div>
            
            <div class="form-group">
                <label>Auth Token</label>
                <input type="password" name="sms_twilio_token" value="<?php echo htmlspecialchars($settings['sms_twilio_token'] ?? ''); ?>" placeholder="Keep secure!">
                <p class="helper-text">Your Twilio Auth Token (stored securely)</p>
            </div>
            
            <div class="form-group">
                <label>Twilio Phone Number</label>
                <input type="text" name="sms_twilio_phone" value="<?php echo htmlspecialchars($settings['sms_twilio_phone'] ?? ''); ?>" placeholder="+1234567890">
                <p class="helper-text">Your Twilio-assigned phone number with country code</p>
            </div>
        </div>
        
        <!-- General Settings -->
        <div class="form-section">
            <h3><i class="fas fa-sliders-h"></i> General Settings</h3>
            
            <div class="form-group">
                <label>Sender Name</label>
                <input type="text" name="sms_from_name" value="<?php echo htmlspecialchars($settings['sms_from_name'] ?? 'School'); ?>" required placeholder="School Name">
                <p class="helper-text">This name will appear in SMS messages</p>
            </div>
            
            <div class="checkbox-group">
                <input type="checkbox" id="sms_enabled" name="sms_enabled" value="1" <?php echo (($settings['sms_enabled'] ?? 0) == 1) ? 'checked' : ''; ?>>
                <label for="sms_enabled"><strong>Enable SMS Notifications</strong></label>
            </div>
            
            <div style="border-left: 3px solid var(--primary-blue); padding-left: 15px; margin-top: 20px;">
                <div class="checkbox-group">
                    <input type="checkbox" id="sms_attendance_alerts" name="sms_attendance_alerts" value="1" <?php echo (($settings['sms_attendance_alerts'] ?? 0) == 1) ? 'checked' : ''; ?>>
                    <label for="sms_attendance_alerts">Send SMS for Attendance Alerts</label>
                </div>
                
                <div class="checkbox-group">
                    <input type="checkbox" id="sms_fee_reminders" name="sms_fee_reminders" value="1" <?php echo (($settings['sms_fee_reminders'] ?? 0) == 1) ? 'checked' : ''; ?>>
                    <label for="sms_fee_reminders">Send SMS for Fee Reminders</label>
                </div>
                
                <div class="checkbox-group">
                    <input type="checkbox" id="sms_2fa_enabled" name="sms_2fa_enabled" value="1" <?php echo (($settings['sms_2fa_enabled'] ?? 0) == 1) ? 'checked' : ''; ?>>
                    <label for="sms_2fa_enabled">Allow SMS for 2FA Verification</label>
                </div>
            </div>
        </div>
        
        <div class="button-group">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Save Settings
            </button>
            <a href="javascript:history.back();" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>
    </form>
    
    <!-- Test SMS Section -->
    <div class="form-section" style="margin-top: 40px;">
        <h3><i class="fas fa-flask"></i> Test SMS Configuration</h3>
        
        <form method="POST">
            <input type="hidden" name="action" value="test_sms">
            
            <div class="form-group">
                <label>Test Phone Number (with country code)</label>
                <input type="tel" name="test_phone" placeholder="+233XXXXXXXXX" required>
                <p class="helper-text">Enter a valid phone number to receive a test SMS</p>
            </div>
            
            <button type="submit" class="btn btn-success">
                <i class="fas fa-paper-plane"></i> Send Test SMS
            </button>
        </form>
    </div>
    
    <!-- Help Section -->
    <div class="form-section" style="margin-top: 40px; background: rgba(45, 91, 255, 0.05);">
        <h3><i class="fas fa-question-circle"></i> Setup Instructions</h3>
        
        <div style="line-height: 1.8;">
            <h4>Getting Twilio Credentials:</h4>
            <ol>
                <li>Visit <a href="https://www.twilio.com" target="_blank" style="color: var(--primary-blue);">twilio.com</a> and create an account</li>
                <li>Go to your Console Dashboard</li>
                <li>Copy your <strong>Account SID</strong> and <strong>Auth Token</strong></li>
                <li>Get a phone number (comes with trial account)</li>
                <li>Paste credentials above and save</li>
                <li>Click "Send Test SMS" to verify setup</li>
            </ol>
            
            <h4 style="margin-top: 20px;">SMS Costs:</h4>
            <ul>
                <li>Twilio: ~$0.0075 per SMS (varies by country)</li>
                <li>Free trial includes $15 credit</li>
                <li>Perfect for testing before going live</li>
            </ul>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>

<script>
document.getElementById('sms_provider')?.addEventListener('change', function() {
    const twilioSection = document.getElementById('twilio-section');
    if (this.value === 'twilio') {
        twilioSection.style.display = 'block';
    } else {
        twilioSection.style.display = 'none';
    }
});
</script>
