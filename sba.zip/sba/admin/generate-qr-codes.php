<?php
// admin/generate-qr-codes.php - Generate QR Codes for Students
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Generate QR Codes';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle QR code generation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('error', 'Invalid request. Please try again.');
        redirect(APP_URL . '/admin/generate-qr-codes.php');
        exit;
    }
    
    if ($_POST['action'] == 'generate_all') {
        try {
            // Get all active students without QR codes or with expired ones
            $stmt = $db->prepare("
                SELECT s.student_id, s.student_code, s.first_name, s.last_name
                FROM students s
                WHERE s.school_id = ? AND s.status = 'active'
                AND (
                    NOT EXISTS (SELECT 1 FROM student_qr_codes WHERE student_id = s.student_id AND is_active = 1)
                    OR EXISTS (SELECT 1 FROM student_qr_codes WHERE student_id = s.student_id AND expires_at < NOW())
                )
            ");
            $stmt->execute([$school_id]);
            $students = $stmt->fetchAll();
            
            $generated_count = 0;
            foreach ($students as $student) {
                // Generate unique QR code data
                $qr_data = hash('sha256', $school_id . '_' . $student['student_id'] . '_' . time() . '_' . uniqid());
                $qr_code = 'QR_' . strtoupper(substr($qr_data, 0, 12));
                
                // Deactivate old QR codes
                $stmt = $db->prepare("UPDATE student_qr_codes SET is_active = 0 WHERE student_id = ?");
                $stmt->execute([$student['student_id']]);
                
                // Insert new QR code
                $stmt = $db->prepare("
                    INSERT INTO student_qr_codes (student_id, qr_code, expires_at, is_active)
                    VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 YEAR), 1)
                ");
                $stmt->execute([$student['student_id'], $qr_code]);
                
                $generated_count++;
            }
            
            log_activity($current_user['user_id'], "Generated QR codes for $generated_count students", 'qr_generation', $school_id);
            set_message('success', "Generated QR codes for $generated_count student(s)!");
            redirect(APP_URL . '/admin/generate-qr-codes.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error generating QR codes: ' . $e->getMessage());
        }
    } elseif ($_POST['action'] == 'regenerate_single') {
        $student_id = (int)$_POST['student_id'];
        
        try {
            // Generate new QR code
            $qr_data = hash('sha256', $school_id . '_' . $student_id . '_' . time() . '_' . uniqid());
            $qr_code = 'QR_' . strtoupper(substr($qr_data, 0, 12));
            
            // Deactivate old QR codes
            $stmt = $db->prepare("UPDATE student_qr_codes SET is_active = 0 WHERE student_id = ?");
            $stmt->execute([$student_id]);
            
            // Insert new QR code
            $stmt = $db->prepare("
                INSERT INTO student_qr_codes (student_id, qr_code, expires_at, is_active)
                VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 YEAR), 1)
            ");
            $stmt->execute([$student_id, $qr_code]);
            
            set_message('success', 'QR code regenerated successfully!');
            redirect(APP_URL . '/admin/generate-qr-codes.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error regenerating QR code: ' . $e->getMessage());
        }
    }
}

// Get all students with their QR codes
$students = [];
try {
    $stmt = $db->prepare("
        SELECT 
            s.student_id,
            s.student_code,
            s.first_name,
            s.last_name,
            c.class_name,
            qr.qr_code,
            qr.generated_at,
            qr.expires_at,
            qr.status as qr_status
        FROM students s
        INNER JOIN student_classes sc ON s.student_id = sc.student_id
        INNER JOIN classes c ON sc.class_id = c.class_id
        LEFT JOIN student_qr_codes qr ON s.student_id = qr.student_id AND qr.status = 'active'
        WHERE s.school_id = ? AND s.status = 'active'
        ORDER BY c.class_name, s.first_name, s.last_name
    ");
    $stmt->execute([$school_id]);
    $students = $stmt->fetchAll();
} catch (PDOException $e) {
    // Fallback without student_code if column missing
    try {
        $stmt = $db->prepare("
            SELECT 
                s.student_id,
                COALESCE(s.student_code, s.admission_number) as student_code,
                s.first_name,
                s.last_name,
                c.class_name,
                qr.qr_code,
                qr.generated_at,
                qr.expires_at,
                qr.status as qr_status
            FROM students s
            LEFT JOIN student_classes sc ON s.student_id = sc.student_id
            LEFT JOIN classes c ON sc.class_id = c.class_id
            LEFT JOIN student_qr_codes qr ON s.student_id = qr.student_id AND qr.status = 'active'
            WHERE s.school_id = ? AND s.status = 'active'
            ORDER BY c.class_name, s.first_name, s.last_name
        ");
        $stmt->execute([$school_id]);
        $students = $stmt->fetchAll();
    } catch (PDOException $e2) {
        $students = [];
    }
}

// Count statistics
$total_students = count($students);
$with_qr = count(array_filter($students, fn($s) => $s['qr_code']));
$without_qr = $total_students - $with_qr;

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .qr-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 25px;
    }
    
    .stat-card {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        color: white;
        padding: 20px;
        border-radius: 12px;
        text-align: center;
    }
    
    .stat-card.green {
        background: linear-gradient(135deg, #34C759, #30D158);
    }
    
    .stat-card.orange {
        background: linear-gradient(135deg, #FF9500, #FF9F0A);
    }
    
    .stat-card h3 {
        margin: 0;
        font-size: 36px;
        font-weight: 700;
    }
    
    .stat-card p {
        margin: 5px 0 0 0;
        opacity: 0.9;
    }
    
    .student-table {
        background: var(--bg-card);
        border-radius: 15px;
        padding: 25px;
        border: 1px solid var(--border-color);
    }
    
    .student-row {
        display: grid;
        grid-template-columns: 50px 1fr 150px 200px 150px 100px;
        gap: 15px;
        align-items: center;
        padding: 15px;
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 10px;
        margin-bottom: 10px;
    }
    
    .student-row:hover {
        border-color: var(--primary-blue);
        box-shadow: 0 3px 15px rgba(0,0,0,0.1);
    }
    
    .student-avatar {
        width: 45px;
        height: 45px;
        border-radius: 10px;
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 700;
        font-size: 16px;
    }
    
    .qr-badge {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
    }
    
    .qr-badge.active {
        background: rgba(52, 199, 89, 0.1);
        color: #34C759;
    }
    
    .qr-badge.missing {
        background: rgba(255, 149, 0, 0.1);
        color: #FF9500;
    }
    
    .qr-badge.expired {
        background: rgba(255, 59, 48, 0.1);
        color: #FF3B30;
    }
    
    .info-box {
        background: rgba(45, 91, 255, 0.1);
        border-left: 4px solid var(--primary-blue);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    
    @media (max-width: 768px) {
        .student-row {
            grid-template-columns: 1fr;
        }
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-qrcode"></i> QR Code Management</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Generate and manage student QR codes for quick attendance check-in
        </p>
    </div>
    
    <div class="info-box">
        <i class="fas fa-info-circle"></i>
        <strong>How it works:</strong> Each student gets a unique QR code. Teachers can scan these codes for instant attendance marking.
        QR codes expire after 1 year for security.
    </div>
    
    <!-- Statistics -->
    <div class="qr-stats">
        <div class="stat-card">
            <h3><?php echo number_format($total_students); ?></h3>
            <p>Total Students</p>
        </div>
        <div class="stat-card green">
            <h3><?php echo number_format($with_qr); ?></h3>
            <p>With QR Codes</p>
        </div>
        <div class="stat-card orange">
            <h3><?php echo number_format($without_qr); ?></h3>
            <p>Need QR Codes</p>
        </div>
    </div>
    
    <!-- Actions -->
    <div style="margin-bottom: 25px;">
        <?php if ($without_qr > 0): ?>
        <form method="POST" style="display: inline;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="generate_all">
            <button type="submit" class="btn btn-primary" onclick="return confirm('Generate QR codes for <?php echo $without_qr; ?> student(s)?')">
                <i class="fas fa-qrcode"></i> Generate Missing QR Codes (<?php echo $without_qr; ?>)
            </button>
        </form>
        <?php endif; ?>
        
        <a href="<?php echo APP_URL; ?>/teacher/scan-qr.php" class="btn btn-success">
            <i class="fas fa-camera"></i> Go to QR Scanner
        </a>
    </div>
    
    <!-- Students List -->
    <div class="student-table">
        <h3 style="margin: 0 0 20px 0;">
            <i class="fas fa-users"></i> Students (<?php echo count($students); ?>)
        </h3>
        
        <?php if (count($students) > 0): ?>
            <?php foreach ($students as $student): 
                $initials = strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1));
                
                if ($student['qr_code']) {
                    $is_expired = $student['expires_at'] && strtotime($student['expires_at']) < time();
                    $badge_class = $is_expired ? 'expired' : 'active';
                    $badge_text = $is_expired ? 'Expired' : 'Active';
                } else {
                    $badge_class = 'missing';
                    $badge_text = 'No QR Code';
                }
            ?>
                <div class="student-row">
                    <div class="student-avatar"><?php echo $initials; ?></div>
                    
                    <div>
                        <strong><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></strong>
                        <div style="font-size: 12px; color: var(--text-secondary);">
                            <?php echo htmlspecialchars($student['student_code']); ?>
                        </div>
                    </div>
                    
                    <div style="font-size: 13px; color: var(--text-secondary);">
                        <?php echo htmlspecialchars($student['class_name']); ?>
                    </div>
                    
                    <div>
                        <?php if ($student['qr_code']): ?>
                            <code style="font-size: 11px; background: rgba(0,0,0,0.05); padding: 4px 8px; border-radius: 4px;">
                                <?php echo htmlspecialchars($student['qr_code']); ?>
                            </code>
                        <?php else: ?>
                            <span style="color: var(--text-secondary); font-size: 13px;">-</span>
                        <?php endif; ?>
                    </div>
                    
                    <div>
                        <span class="qr-badge <?php echo $badge_class; ?>">
                            <?php echo $badge_text; ?>
                        </span>
                    </div>
                    
                    <div>
                        <form method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="action" value="regenerate_single">
                            <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">
                            <button type="submit" class="btn btn-sm btn-primary" title="Regenerate QR Code">
                                <i class="fas fa-sync"></i>
                            </button>
                        </form>
                        
                        <?php if ($student['qr_code']): ?>
                        <a href="<?php echo APP_URL; ?>/student/my-qr-code.php?student_id=<?php echo $student['student_id']; ?>" 
                           class="btn btn-sm btn-secondary" 
                           title="View QR Code" 
                           target="_blank">
                            <i class="fas fa-eye"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align: center; padding: 60px;">
                <i class="fas fa-users" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
                <h3 style="color: var(--text-secondary);">No Students Found</h3>
                <p style="color: var(--text-secondary);">Add students to generate QR codes.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
