<?php
// admin/print-result.php - Print Student Result Sheet
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get parameters
$student_id = (int)($_GET['student'] ?? 0);

if (!$student_id) {
    die('Student ID is required');
}

// Get active term
try {
    $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_active = 1");
    $stmt->execute([$school_id]);
    $active_term = $stmt->fetch();
} catch (PDOException $e) {
    try {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_current = 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    } catch (PDOException $e2) {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY start_date DESC LIMIT 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    }
}

if (!$active_term) {
    die('No active term found');
}

// Get student details with class teacher
$stmt = $db->prepare("
    SELECT s.*, c.class_name, c.class_teacher_id, sc.school_name, sc.logo as school_logo,
           COALESCE(u.first_name, s.first_name, '-') as first_name,
           COALESCE(u.last_name, s.last_name, '') as last_name,
           CONCAT(ct.first_name, ' ', ct.last_name) as class_teacher_name
    FROM students s
    INNER JOIN classes c ON s.class_id = c.class_id
    INNER JOIN schools sc ON s.school_id = sc.school_id
    LEFT JOIN users u ON s.user_id = u.user_id
    LEFT JOIN users ct ON c.class_teacher_id = ct.user_id
    WHERE s.student_id = ? AND s.school_id = ?
");
$stmt->execute([$student_id, $school_id]);
$student = $stmt->fetch();

if (!$student) {
    die('Student not found');
}

// Get all subject results
$stmt = $db->prepare("
    SELECT 
        subj.subject_name,
        sa.ca_score,
        sa.midterm_score,
        sa.exam_score,
        sa.total_score,
        sa.grade,
        sa.remark,
        sa.position,
        CONCAT(u.first_name, ' ', u.last_name) as teacher_name
    FROM student_assessments sa
    INNER JOIN subjects subj ON sa.subject_id = subj.subject_id
    LEFT JOIN users u ON sa.teacher_id = u.user_id
    WHERE sa.student_id = ? AND sa.term_id = ? AND sa.school_id = ?
    ORDER BY sa.total_score DESC, subj.subject_name
");
$stmt->execute([$student_id, $active_term['term_id'], $school_id]);
$results = $stmt->fetchAll();

// Calculate totals if missing and fix position
$position = 1;
foreach ($results as &$result) {
    // Calculate total if missing or 0
    if (($result['total_score'] == 0 || $result['total_score'] === null) &&
        ($result['ca_score'] > 0 || $result['midterm_score'] > 0 || $result['exam_score'] > 0)) {
        $result['total_score'] = calculate_total_score(
            $result['ca_score'] ?? 0,
            $result['midterm_score'] ?? 0,
            $result['exam_score'] ?? 0
        );
        // Calculate grade and remark if missing
        if (empty($result['grade']) || empty($result['remark'])) {
            $grade_info = calculate_grade_new($result['total_score']);
            $result['grade'] = $grade_info['grade'];
            $result['remark'] = $grade_info['remark'];
        }
    }
    
    // Set position
    if ($result['total_score'] !== null && $result['total_score'] > 0) {
        $result['position'] = $result['position'] ?? $position++;
    } else {
        $result['position'] = null;
    }
}
unset($result);

// Calculate overall statistics with fallback
$total_subjects = count($results);
$total_marks = 0;
$total_possible = $total_subjects * 100;

foreach ($results as $result) {
    $score_total = $result['total_score'];
    if ($score_total == 0 || $score_total === null) {
        $score_total = calculate_total_score(
            $result['ca_score'] ?? 0,
            $result['midterm_score'] ?? 0,
            $result['exam_score'] ?? 0
        );
    }
    $total_marks += $score_total;
}

$overall_average = $total_subjects > 0 ? round($total_marks / $total_subjects, 2) : 0;

// Calculate overall grade
function getOverallGrade($avg) {
    if ($avg >= 90) return 'A+';
    if ($avg >= 80) return 'A';
    if ($avg >= 75) return 'B+';
    if ($avg >= 70) return 'B';
    if ($avg >= 65) return 'C+';
    if ($avg >= 60) return 'C';
    if ($avg >= 50) return 'D';
    return 'F';
}

$overall_grade = getOverallGrade($overall_average);
$overall_remark = $overall_average >= 80 ? 'Excellent' : ($overall_average >= 70 ? 'Very Good' : ($overall_average >= 60 ? 'Good' : ($overall_average >= 50 ? 'Fair' : 'Fail')));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Result Sheet - <?php echo $student['first_name'] . ' ' . $student['last_name']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            padding: 20px;
            background: white;
        }
        
        .result-sheet {
            max-width: 900px;
            margin: 0 auto;
            border: 3px solid #333;
            padding: 30px;
            background: white;
        }
        
        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 3px solid #333;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .header-left {
            flex: 0 0 100px;
        }
        
        .school-logo {
            width: 80px;
            height: 80px;
            object-fit: contain;
        }
        
        .header-center {
            flex: 1;
            text-align: center;
        }
        
        .header-right {
            flex: 0 0 100px;
        }
        
        .student-photo {
            width: 100px;
            height: 120px;
            object-fit: cover;
            border: 2px solid #333;
            border-radius: 5px;
        }
        
        .school-name {
            font-size: 28px;
            font-weight: bold;
            color: #2196F3;
            margin-bottom: 5px;
        }
        
        .result-title {
            font-size: 22px;
            font-weight: bold;
            margin: 10px 0;
            text-transform: uppercase;
        }
        
        .term-info {
            font-size: 16px;
            color: #666;
        }
        
        .student-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 30px;
            padding: 20px;
            background: #f5f5f5;
            border-radius: 8px;
        }
        
        .info-item {
            display: flex;
            gap: 10px;
        }
        
        .info-label {
            font-weight: bold;
            min-width: 150px;
        }
        
        .results-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        
        .results-table th {
            background: #2196F3;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: bold;
        }
        
        .results-table td {
            padding: 10px 12px;
            border: 1px solid #ddd;
        }
        
        .results-table tr:nth-child(even) {
            background: #f9f9f9;
        }
        
        .text-center {
            text-align: center;
        }
        
        .grade-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 15px;
            font-weight: bold;
            font-size: 14px;
        }
        
        .grade-A-plus, .grade-A { background: #4CAF50; color: white; }
        .grade-B-plus, .grade-B { background: #2196F3; color: white; }
        .grade-C-plus, .grade-C { background: #FF9800; color: white; }
        .grade-D { background: #FFC107; color: black; }
        .grade-F { background: #F44336; color: white; }
        
        .summary {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .summary-box {
            padding: 20px;
            border: 2px solid #2196F3;
            border-radius: 8px;
            text-align: center;
        }
        
        .summary-box h3 {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
        }
        
        .summary-box .value {
            font-size: 32px;
            font-weight: bold;
            color: #2196F3;
        }
        
        .signatures {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
            margin-top: 50px;
            padding-top: 30px;
            border-top: 2px solid #ddd;
        }
        
        .signature-box {
            text-align: center;
        }
        
        .signature-line {
            border-top: 2px solid #333;
            margin-top: 60px;
            padding-top: 10px;
            font-weight: bold;
        }
        
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px solid #ddd;
            color: #666;
            font-size: 12px;
        }
        
        @media print {
            @page {
                size: A4;
                margin: 15mm;
            }
            
            body {
                padding: 0;
            }
            
            .no-print {
                display: none;
            }
            
            .result-sheet {
                border: none;
                padding: 0;
                max-width: 100%;
                page-break-after: always;
                min-height: 277mm; /* A4 height minus margins */
            }
        }
    </style>
</head>
<body>
    <div class="result-sheet">
        <!-- Header -->
        <div class="header">
            <div class="header-left">
                <?php if (!empty($student['school_logo'])): ?>
                    <img src="<?php echo APP_URL . '/uploads/logos/' . $student['school_logo']; ?>" 
                         alt="School Logo" class="school-logo">
                <?php endif; ?>
            </div>
            
            <div class="header-center">
                <div class="school-name"><?php echo strtoupper($student['school_name']); ?></div>
                <div class="result-title">Student Result Sheet</div>
                <div class="term-info">
                    <?php echo $active_term['term_name']; ?>
                    <?php echo isset($active_term['session_year']) ? ' - ' . $active_term['session_year'] : ''; ?>
                </div>
            </div>
            
            <div class="header-right">
                <?php if (!empty($student['photo'])): ?>
                    <img src="<?php echo APP_URL . '/uploads/students/' . $student['photo']; ?>" 
                         alt="Student Photo" class="student-photo">
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Student Information -->
        <div class="student-info">
            <div class="info-item">
                <span class="info-label">Student Name:</span>
                <span><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Admission Number:</span>
                <span><?php echo $student['admission_number']; ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Class:</span>
                <span><?php echo $student['class_name']; ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Gender:</span>
                <span><?php echo ucfirst($student['gender']); ?></span>
            </div>
        </div>
        
        <!-- Results Table -->
        <table class="results-table">
            <thead>
                <tr>
                    <th style="width: 50px;">#</th>
                    <th>Subject</th>
                    <th class="text-center" style="width: 80px;">CA<br>(20)</th>
                    <th class="text-center" style="width: 80px;">Midterm<br>(20)</th>
                    <th class="text-center" style="width: 80px;">Exam<br>(60)</th>
                    <th class="text-center" style="width: 80px;">Total<br>(100)</th>
                    <th class="text-center" style="width: 80px;">Grade</th>
                    <th class="text-center" style="width: 80px;">Position</th>
                    <th style="width: 100px;">Remark</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($results) > 0): ?>
                    <?php $count = 1; ?>
                    <?php foreach ($results as $result): ?>
                        <tr>
                            <td class="text-center"><?php echo $count++; ?></td>
                            <td><strong><?php echo $result['subject_name']; ?></strong></td>
                            <td class="text-center"><?php echo $result['ca_score'] ?? '-'; ?></td>
                            <td class="text-center"><?php echo $result['midterm_score'] ?? '-'; ?></td>
                            <td class="text-center"><?php echo $result['exam_score'] ?? '-'; ?></td>
                            <td class="text-center"><strong><?php echo $result['total_score']; ?></strong></td>
                            <td class="text-center">
                                <span class="grade-badge grade-<?php echo str_replace('+', '-plus', $result['grade']); ?>">
                                    <?php echo $result['grade']; ?>
                                </span>
                            </td>
                            <td class="text-center"><?php echo $result['position'] ?? '-'; ?></td>
                            <td><?php echo $result['remark']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center" style="padding: 40px;">
                            No results available for this student.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <!-- Summary -->
        <div class="summary">
            <div class="summary-box">
                <h3>Total Subjects</h3>
                <div class="value"><?php echo $total_subjects; ?></div>
            </div>
            <div class="summary-box">
                <h3>Overall Average</h3>
                <div class="value"><?php echo $overall_average; ?>%</div>
            </div>
            <div class="summary-box">
                <h3>Overall Grade</h3>
                <div class="value">
                    <span class="grade-badge grade-<?php echo str_replace('+', '-plus', $overall_grade); ?>">
                        <?php echo $overall_grade; ?>
                    </span>
                </div>
            </div>
        </div>
        
        <div style="text-align: center; padding: 20px; background: <?php echo $overall_average >= 50 ? '#E8F5E9' : '#FFEBEE'; ?>; border-radius: 8px; margin-bottom: 30px;">
            <h3 style="margin: 0; font-size: 24px; color: <?php echo $overall_average >= 50 ? '#4CAF50' : '#F44336'; ?>;">
                <?php echo $overall_remark; ?>
            </h3>
        </div>
        
        <!-- Signatures -->
        <div class="signatures">
            <div class="signature-box">
                <div class="signature-line">
                    Class Teacher
                    <?php if (!empty($student['class_teacher_name'])): ?>
                        <br><small style="font-weight: normal; font-size: 12px;">(<?php echo $student['class_teacher_name']; ?>)</small>
                    <?php endif; ?>
                </div>
            </div>
            <div class="signature-box">
                <div class="signature-line">Principal</div>
            </div>
            <div class="signature-box">
                <div class="signature-line">Parent/Guardian</div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <p>Generated on <?php echo date('F j, Y'); ?></p>
            <p style="margin-top: 5px;">This is an official result sheet from <?php echo $student['school_name']; ?></p>
        </div>
    </div>
    
    <!-- Print Button -->
    <div class="no-print" style="text-align: center; margin-top: 30px;">
        <button onclick="window.print()" style="padding: 15px 40px; font-size: 16px; background: #2196F3; color: white; border: none; border-radius: 5px; cursor: pointer;">
            <i class="fas fa-print"></i> Print Result
        </button>
        <button onclick="window.close()" style="padding: 15px 40px; font-size: 16px; background: #666; color: white; border: none; border-radius: 5px; cursor: pointer; margin-left: 10px;">
            Close
        </button>
    </div>
    
    <script>
        // Auto-print on load (optional)
        // window.onload = function() { window.print(); }
    </script>
</body>
</html>
