<?php
// admin/parents.php - Parent Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/default-passwords.php';

$page_title = 'Manage Parents';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        // Verify CSRF token
        if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
            set_message('error', 'Invalid request. Please try again.');
            redirect(APP_URL . '/admin/parents.php');
            exit;
        }
        if ($_POST['action'] == 'add') {
            // Add parent
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $email = sanitize_input($_POST['email']);
            $phone = sanitize_input($_POST['phone']);
            $address = sanitize_input($_POST['address']);
            $relationship = sanitize_input($_POST['relationship'] ?? 'guardian');
            
            // Get student IDs from dynamic fields
            $student_ids = [];
            if (isset($_POST['student_ids']) && is_array($_POST['student_ids'])) {
                $student_ids = array_filter(array_map('intval', $_POST['student_ids']), fn($id) => $id > 0);
            }
            
            try {
                $db->beginTransaction();
                
                // Create user account (without address - doesn't exist in users table)
                $base_username = strtolower($first_name . '.' . $last_name);
                $username = $base_username;
                $counter = 1;
                
                // Ensure unique username within school
                while (true) {
                    $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE username = ? AND school_id = ?");
                    $check_stmt->execute([$username, $school_id]);
                    if ($check_stmt->fetch()['count'] == 0) {
                        break;
                    }
                    $username = $base_username . '_' . $counter;
                    $counter++;
                }
                
                // Ensure unique email within school
                $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE email = ? AND school_id = ?");
                $check_stmt->execute([$email, $school_id]);
                if ($check_stmt->fetch()['count'] > 0) {
                    throw new Exception('Email already exists!');
                }
                
                // Use default password: parent123
                $default_credentials = generate_default_credentials('parent');
                $random_password = $default_credentials['password']; // parent123
                $default_password = $default_credentials['hash'];
                
                $stmt = $db->prepare("
                    INSERT INTO users (school_id, username, email, password_hash, role, first_name, last_name, phone, status)
                    VALUES (?, ?, ?, ?, 'parent', ?, ?, ?, 'active')
                ");
                $stmt->execute([$school_id, $username, $email, $default_password, $first_name, $last_name, $phone]);
                
                $user_id = $db->lastInsertId();
                
                // Create parent record
                $stmt = $db->prepare("
                    INSERT INTO parents (school_id, user_id)
                    VALUES (?, ?)
                ");
                $stmt->execute([$school_id, $user_id]);
                
                $parent_id = $db->lastInsertId();
                
                // Link to multiple students (if student_parents table exists)
                if (!empty($student_ids)) {
                    try {
                        $stmt = $db->prepare("
                            INSERT INTO student_parents (parent_id, student_id)
                            VALUES (?, ?)
                        ");
                        foreach ($student_ids as $student_id) {
                            $stmt->execute([$parent_id, $student_id]);
                        }
                    } catch (PDOException $e) {
                        // student_parents table may not exist, continue anyway
                    }
                }
                
                $db->commit();
                
                log_activity($current_user['user_id'], "Added new parent: $first_name $last_name with " . count($student_ids) . " child(ren)", 'parents', $parent_id);
                
                set_message('success', "Parent added successfully! Login - Username: $username, Password: $random_password (Please save this password)");
                redirect(APP_URL . '/admin/parents.php');
            } catch (PDOException $e) {
                $db->rollBack();
                set_message('error', 'Error adding parent: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'edit') {
            // Edit parent
            $user_id = (int)$_POST['user_id'];
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $email = sanitize_input($_POST['email']);
            $phone = sanitize_input($_POST['phone']);
            $address = sanitize_input($_POST['address']);
            $status = sanitize_input($_POST['status']);
            
            // Get student IDs from dynamic fields
            $student_ids = [];
            if (isset($_POST['student_ids']) && is_array($_POST['student_ids'])) {
                $student_ids = array_filter(array_map('intval', $_POST['student_ids']), fn($id) => $id > 0);
            }
            
            try {
                $db->beginTransaction();
                
                // Update user account (no address in users table)
                $stmt = $db->prepare("
                    UPDATE users 
                    SET first_name = ?, last_name = ?, email = ?, phone = ?, status = ?
                    WHERE user_id = ? AND school_id = ? AND role = 'parent'
                ");
                $stmt->execute([$first_name, $last_name, $email, $phone, $status, $user_id, $school_id]);
                
                // Get parent_id from parents table
                $stmt = $db->prepare("SELECT parent_id FROM parents WHERE user_id = ?");
                $stmt->execute([$user_id]);
                $parent_data = $stmt->fetch();
                
                if ($parent_data) {
                    $parent_id = $parent_data['parent_id'];
                    
                    // Update student links
                    // First, remove all existing links
                    try {
                        $stmt = $db->prepare("DELETE FROM student_parents WHERE parent_id = ?");
                        $stmt->execute([$parent_id]);
                        
                        // Then add new links
                        if (!empty($student_ids)) {
                            $stmt = $db->prepare("
                                INSERT INTO student_parents (parent_id, student_id)
                                VALUES (?, ?)
                            ");
                            foreach ($student_ids as $student_id) {
                                $stmt->execute([$parent_id, $student_id]);
                            }
                        }
                    } catch (PDOException $e) {
                        // student_parents table operations failed, but user update succeeded
                    }
                }
                
                $db->commit();
                
                log_activity($current_user['user_id'], "Updated parent: $first_name $last_name with " . count($student_ids) . " child(ren)", 'parents', $user_id);
                
                set_message('success', 'Parent updated successfully!');
                redirect(APP_URL . '/admin/parents.php');
            } catch (PDOException $e) {
                $db->rollBack();
                set_message('error', 'Error updating parent: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            // Delete parent
            $user_id = (int)$_POST['user_id'];
            
            try {
                $stmt = $db->prepare("DELETE FROM users WHERE user_id = ? AND school_id = ? AND role = 'parent'");
                $stmt->execute([$user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted parent", 'users', $user_id);
                
                set_message('success', 'Parent deleted successfully!');
                redirect(APP_URL . '/admin/parents.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting parent: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'reset_password') {
            // Reset password
            $user_id = (int)$_POST['user_id'];
            // Generate secure random password
            $random_password = bin2hex(random_bytes(4)); // 8 character random password
            $new_password = password_hash($random_password, PASSWORD_BCRYPT);
            
            try {
                $stmt = $db->prepare("UPDATE users SET password_hash = ? WHERE user_id = ? AND school_id = ?");
                $stmt->execute([$new_password, $user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Reset parent password", 'users', $user_id);
                
                set_message('success', "Password reset to: $random_password");
                redirect(APP_URL . '/admin/parents.php');
            } catch (PDOException $e) {
                set_message('error', 'Error resetting password: ' . $e->getMessage());
            }
        }
    }
}

// Get all parents
$parents = [];
try {
    $stmt = $db->prepare("
        SELECT 
            u.*,
            p.parent_id,
            COUNT(DISTINCT sp.student_id) as child_count
        FROM users u
        LEFT JOIN parents p ON u.user_id = p.user_id
        LEFT JOIN student_parents sp ON p.parent_id = sp.parent_id
        WHERE u.school_id = ? AND u.role = 'parent'
        GROUP BY u.user_id
        ORDER BY u.first_name, u.last_name
    ");
    $stmt->execute([$school_id]);
    $parents = $stmt->fetchAll();
} catch (PDOException $e) {
    // student_parents table may not exist
    $stmt = $db->prepare("SELECT * FROM users WHERE school_id = ? AND role = 'parent' ORDER BY first_name, last_name");
    $stmt->execute([$school_id]);
    $parents = $stmt->fetchAll();
    // Add default child_count for display
    foreach ($parents as &$parent) {
        $parent['child_count'] = 0;
    }
}

// Get students with class names for dropdown
$students = [];
try {
    $stmt = $db->prepare("
        SELECT s.student_id, s.admission_number, s.class_id, c.class_name,
               u.first_name, u.last_name
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.class_id
        LEFT JOIN users u ON s.user_id = u.user_id
        WHERE s.school_id = ?
        ORDER BY c.class_name, u.first_name, u.last_name
    ");
    $stmt->execute([$school_id]);
    $students = $stmt->fetchAll();
} catch (PDOException $e) {
    // If students table has different structure, fallback
    $students = [];
}

// Get classes for filtering
$stmt = $db->prepare("
    SELECT class_id, class_name
    FROM classes
    WHERE school_id = ?
    ORDER BY class_name
");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Statistics
$total_parents = count($parents);
$active_parents = count(array_filter($parents, fn($p) => $p['status'] == 'active'));
$inactive_parents = $total_parents - $active_parents;

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .parent-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
        margin-top: 20px;
    }
    
    .parent-card {
        background: var(--card-bg);
        border-radius: 15px;
        padding: 20px;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
    }
    
    .parent-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-hover);
    }
    
    .parent-avatar {
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: linear-gradient(135deg, #FF9800, #F57C00);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        font-weight: 700;
        margin: 0 auto 15px;
    }
    
    .parent-name {
        text-align: center;
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    .parent-email {
        text-align: center;
        color: var(--text-secondary);
        font-size: 13px;
        margin-bottom: 15px;
    }
    
    .parent-info {
        padding-top: 15px;
        border-top: 1px solid var(--border-color);
    }
    
    .info-row {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 10px;
        font-size: 14px;
    }
    
    .info-row i {
        color: var(--primary-blue);
        width: 16px;
    }
    
    .parent-actions {
        display: flex;
        gap: 5px;
        margin-top: 15px;
    }
    
    .action-btn {
        flex: 1;
        padding: 8px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 12px;
        transition: all 0.3s ease;
    }
    
    .status-badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .status-active {
        background: rgba(76, 175, 80, 0.1);
        color: #4CAF50;
    }
    
    .status-inactive {
        background: rgba(244, 67, 54, 0.1);
        color: #F44336;
    }
    </style>
    
    <!-- Page Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #FF9800, #F57C00); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-users-cog"></i> Manage Parents
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Add, edit, and manage parent accounts
            </p>
        </div>
    </div>
    
    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="background: linear-gradient(135deg, #FF9800, #F57C00); color: white; padding: 25px; border-radius: 15px;">
            <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Total Parents</div>
            <div style="font-size: 36px; font-weight: 700;"><?php echo $total_parents; ?></div>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #4CAF50, #388E3C); color: white; padding: 25px; border-radius: 15px;">
            <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Active</div>
            <div style="font-size: 36px; font-weight: 700;"><?php echo $active_parents; ?></div>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #F44336, #D32F2F); color: white; padding: 25px; border-radius: 15px;">
            <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Inactive</div>
            <div style="font-size: 36px; font-weight: 700;"><?php echo $inactive_parents; ?></div>
        </div>
    </div>
    
    <!-- Actions & View Toggle -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; gap: 10px;">
            <button onclick="document.getElementById('addModal').style.display='flex'" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add Parent
            </button>
            
            <!-- View Toggle -->
            <div class="btn-group" style="display: inline-flex; border: 2px solid var(--border-color); border-radius: 8px; overflow: hidden;">
                <button id="btnListView" onclick="setView('list')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--bg-secondary); color: var(--text-primary);">
                    <i class="fas fa-list"></i> List
                </button>
                <button id="btnGridView" onclick="setView('grid')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--primary-blue); color: white;">
                    <i class="fas fa-th"></i> Grid
                </button>
            </div>
        </div>
        
        <div style="font-weight: 600; color: var(--text-secondary);">
            Showing: <?php echo count($parents); ?> parents
        </div>
    </div>
    
    
    <!-- List View (Table) -->
    <?php if (count($parents) > 0): ?>
    <div id="parentsTable" class="card" style="display: none;">
        <div class="card-header">
            <h3><i class="fas fa-users-cog"></i> Parents List</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Parent Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Children</th>
                        <th>Login Credentials</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $count = 1; ?>
                    <?php foreach ($parents as $parent): ?>
                        <tr>
                            <td><?php echo $count++; ?></td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="width: 35px; height: 35px; border-radius: 50%; background: linear-gradient(135deg, #FF9800, #F57C00); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 12px;">
                                        <?php echo strtoupper(substr($parent['first_name'], 0, 1) . substr($parent['last_name'], 0, 1)); ?>
                                    </div>
                                    <strong><?php echo htmlspecialchars($parent['first_name'] . ' ' . $parent['last_name']); ?></strong>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($parent['email']); ?></td>
                            <td><?php echo htmlspecialchars($parent['phone'] ?? 'N/A'); ?></td>
                            <td>
                                <span class="badge badge-info">
                                    <i class="fas fa-child"></i> <?php echo $parent['child_count']; ?> child(ren)
                                </span>
                            </td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <div id="cred-hidden-<?php echo $parent['user_id']; ?>" style="font-family: monospace; font-size: 12px;">
                                        ••••••••
                                    </div>
                                    <div id="cred-shown-<?php echo $parent['user_id']; ?>" style="display: none; font-family: monospace; font-size: 11px; line-height: 1.4;">
                                        <strong>User:</strong> <?php echo htmlspecialchars($parent['username']); ?><br>
                                        <strong>Pass:</strong> parent123
                                    </div>
                                    <button onclick="toggleCredentials(<?php echo $parent['user_id']; ?>); return false;" type="button" class="btn btn-sm" style="padding: 4px 8px; background: var(--primary-blue); color: white; border: none; border-radius: 4px; cursor: pointer;">
                                        <i class="fas fa-eye" id="eye-<?php echo $parent['user_id']; ?>"></i>
                                    </button>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo $parent['status'] == 'active' ? 'success' : 'warning'; ?>">
                                    <?php echo ucfirst($parent['status']); ?>
                                </span>
                            </td>
                            <td>
                                <button onclick="editParent(<?php echo htmlspecialchars(json_encode($parent)); ?>)" class="btn btn-sm btn-info" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button onclick="resetParentPassword(<?php echo $parent['user_id']; ?>, '<?php echo htmlspecialchars($parent['first_name'] . ' ' . $parent['last_name']); ?>')" class="btn btn-sm btn-warning" title="Reset Password">
                                    <i class="fas fa-key"></i>
                                </button>
                                <button onclick="deleteParent(<?php echo $parent['user_id']; ?>, '<?php echo htmlspecialchars($parent['first_name'] . ' ' . $parent['last_name']); ?>')" class="btn btn-sm btn-danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Grid View (Cards) -->
    <div id="parentsGrid" class="parent-grid">
            <?php foreach ($parents as $parent): ?>
                <div class="parent-card">
                    <div class="parent-avatar">
                        <?php echo strtoupper(substr($parent['first_name'], 0, 1) . substr($parent['last_name'], 0, 1)); ?>
                    </div>
                    <div class="parent-name"><?php echo htmlspecialchars($parent['first_name'] . ' ' . $parent['last_name']); ?></div>
                    <div class="parent-email"><?php echo htmlspecialchars($parent['email']); ?></div>
                    
                    <div style="text-align: center; margin-bottom: 15px;">
                        <span class="status-badge status-<?php echo $parent['status']; ?>">
                            <?php echo ucfirst($parent['status']); ?>
                        </span>
                    </div>
                    
                    <div class="parent-info">
                        <div class="info-row">
                            <i class="fas fa-phone"></i>
                            <span><?php echo htmlspecialchars($parent['phone'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="info-row">
                            <i class="fas fa-child"></i>
                            <span><?php echo $parent['child_count']; ?> Child(ren)</span>
                        </div>
                        <div class="info-row">
                            <i class="fas fa-calendar"></i>
                            <span>Joined <?php echo date('M Y', strtotime($parent['created_at'])); ?></span>
                        </div>
                    </div>
                    
                    <!-- Credentials Section -->
                    <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-top: 12px; margin-bottom: 12px; font-size: 12px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                            <strong><i class="fas fa-key"></i> Login Credentials</strong>
                            <button onclick="toggleCredentials(<?php echo $parent['user_id']; ?>); return false;" type="button" class="btn btn-sm" style="padding: 4px 8px; background: var(--primary-blue); color: white; border: none; border-radius: 4px; cursor: pointer;">
                                <i class="fas fa-eye" id="eye-<?php echo $parent['user_id']; ?>"></i>
                            </button>
                        </div>
                        <div id="cred-hidden-<?php echo $parent['user_id']; ?>" style="font-family: monospace; color: var(--text-primary);">
                            ••••••••
                        </div>
                        <div id="cred-shown-<?php echo $parent['user_id']; ?>" style="display: none; font-family: monospace; line-height: 1.6; color: var(--text-primary);">
                            <strong>Username:</strong> <?php echo htmlspecialchars($parent['username']); ?><br>
                            <strong>Password:</strong> parent123
                        </div>
                    </div>
                    
                    <div class="parent-actions">
                        <button onclick="editParent(<?php echo htmlspecialchars(json_encode($parent)); ?>)" 
                                class="action-btn btn-primary" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button onclick="resetPassword(<?php echo $parent['user_id']; ?>)" 
                                class="action-btn btn-warning" title="Reset Password">
                            <i class="fas fa-key"></i>
                        </button>
                        <button onclick="deleteParent(<?php echo $parent['user_id']; ?>, '<?php echo htmlspecialchars($parent['first_name'] . ' ' . $parent['last_name']); ?>')" 
                                class="action-btn btn-danger" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                    </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
        <div class="card">
            <div style="padding: 60px; text-align: center;">
                <i class="fas fa-users-cog" style="font-size: 64px; color: var(--text-secondary); opacity: 0.3; margin-bottom: 20px;"></i>
                <h3 style="color: var(--text-secondary); margin-bottom: 10px;">No Parents Found</h3>
                <p style="color: var(--text-secondary);">Click "Add Parent" to create the first parent account.</p>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Add Modal -->
    <div id="addModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 700px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="addModalTitle"><i class="fas fa-plus"></i> Add Parent</h2>
                <button onclick="closeAddModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="POST" id="addParentForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="add">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label>First Name *</label>
                        <input type="text" name="first_name" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name *</label>
                        <input type="text" name="last_name" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label>Phone</label>
                    <input type="tel" name="phone">
                </div>
                
                <div class="form-group">
                    <label>Address</label>
                    <textarea name="address" rows="2"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Relationship</label>
                    <select name="relationship">
                        <option value="father">Father</option>
                        <option value="mother">Mother</option>
                        <option value="guardian" selected>Guardian</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                
                <div style="border-top: 2px solid var(--border-color); padding-top: 20px; margin-top: 20px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <label style="font-weight: 600; font-size: 16px; margin: 0;">
                            <i class="fas fa-child"></i> Link Children
                        </label>
                        <button type="button" onclick="addStudentField()" class="btn btn-success btn-sm">
                            <i class="fas fa-plus"></i> Add Child
                        </button>
                    </div>
                    
                    <div id="studentFieldsContainer">
                        <!-- Student fields will be added here dynamically -->
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" onclick="closeAddModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Add Parent</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div id="editModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 700px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2><i class="fas fa-edit"></i> Edit Parent</h2>
                <button onclick="closeEditModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="POST" id="editForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="user_id" id="edit_user_id">
                <input type="hidden" name="parent_id" id="edit_parent_id">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label>First Name *</label>
                        <input type="text" name="first_name" id="edit_first_name" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name *</label>
                        <input type="text" name="last_name" id="edit_last_name" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" id="edit_email" required>
                </div>
                
                <div class="form-group">
                    <label>Phone</label>
                    <input type="tel" name="phone" id="edit_phone">
                </div>
                
                <div class="form-group">
                    <label>Address</label>
                    <textarea name="address" id="edit_address" rows="2"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" id="edit_status">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                
                <div style="border-top: 2px solid var(--border-color); padding-top: 20px; margin-top: 20px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <label style="font-weight: 600; font-size: 16px; margin: 0;">
                            <i class="fas fa-child"></i> Manage Children
                        </label>
                        <button type="button" onclick="addEditStudentField()" class="btn btn-success btn-sm">
                            <i class="fas fa-plus"></i> Add Child
                        </button>
                    </div>
                    
                    <div id="editStudentFieldsContainer">
                        <!-- Student fields will be added here dynamically -->
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" onclick="closeEditModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Parent</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Form -->
    <form method="POST" id="deleteForm" style="display: none;">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="user_id" id="delete_user_id">
    </form>
    
    <!-- Reset Password Form -->
    <form method="POST" id="resetPasswordForm" style="display: none;">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="reset_password">
        <input type="hidden" name="user_id" id="reset_user_id">
    </form>
    
    <script>
    // Store students data for dynamic fields
    const studentsData = <?php echo json_encode($students); ?>;
    const classesData = <?php echo json_encode($classes); ?>;
    let studentFieldCount = 0;
    let editStudentFieldCount = 0;
    
    function addStudentField() {
        studentFieldCount++;
        const container = document.getElementById('studentFieldsContainer');
        
        const fieldDiv = document.createElement('div');
        fieldDiv.className = 'student-field-row';
        fieldDiv.id = `student-field-${studentFieldCount}`;
        fieldDiv.style.cssText = 'display: flex; gap: 10px; margin-bottom: 15px; align-items: flex-start; padding: 15px; background: #f8f9fa; border-radius: 8px;';
        
        // Create class filter dropdown
        let classOptions = '<option value="">-- Select Class --</option>';
        classesData.forEach(cls => {
            classOptions += `<option value="${cls.class_id}">${cls.class_name}</option>`;
        });
        
        fieldDiv.innerHTML = `
            <div style="flex: 1;">
                <label style="display: block; margin-bottom: 5px; font-size: 13px; font-weight: 600;">Class</label>
                <select class="class-filter" onchange="filterStudents(${studentFieldCount}, 'add')" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
                    ${classOptions}
                </select>
            </div>
            <div style="flex: 2;">
                <label style="display: block; margin-bottom: 5px; font-size: 13px; font-weight: 600;">Student Name</label>
                <select name="student_ids[]" id="student-select-${studentFieldCount}" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">-- Select Student --</option>
                </select>
            </div>
            <button type="button" onclick="removeStudentField(${studentFieldCount}, 'add')" class="btn btn-danger btn-sm" style="margin-top: 28px;">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        container.appendChild(fieldDiv);
    }
    
    function addEditStudentField() {
        editStudentFieldCount++;
        const container = document.getElementById('editStudentFieldsContainer');
        
        const fieldDiv = document.createElement('div');
        fieldDiv.className = 'student-field-row';
        fieldDiv.id = `edit-student-field-${editStudentFieldCount}`;
        fieldDiv.style.cssText = 'display: flex; gap: 10px; margin-bottom: 15px; align-items: flex-start; padding: 15px; background: #f8f9fa; border-radius: 8px;';
        
        // Create class filter dropdown
        let classOptions = '<option value="">-- Select Class --</option>';
        classesData.forEach(cls => {
            classOptions += `<option value="${cls.class_id}">${cls.class_name}</option>`;
        });
        
        fieldDiv.innerHTML = `
            <div style="flex: 1;">
                <label style="display: block; margin-bottom: 5px; font-size: 13px; font-weight: 600;">Class</label>
                <select class="class-filter" onchange="filterStudents(${editStudentFieldCount}, 'edit')" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
                    ${classOptions}
                </select>
            </div>
            <div style="flex: 2;">
                <label style="display: block; margin-bottom: 5px; font-size: 13px; font-weight: 600;">Student Name</label>
                <select name="student_ids[]" id="edit-student-select-${editStudentFieldCount}" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
                    <option value="">-- Select Student --</option>
                </select>
            </div>
            <button type="button" onclick="removeStudentField(${editStudentFieldCount}, 'edit')" class="btn btn-danger btn-sm" style="margin-top: 28px;">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        container.appendChild(fieldDiv);
    }
    
    function filterStudents(fieldId, mode) {
        const prefix = mode === 'edit' ? 'edit-' : '';
        const classFilter = document.querySelector(`#${prefix}student-field-${fieldId} .class-filter`);
        const studentSelect = document.getElementById(`${prefix}student-select-${fieldId}`);
        const selectedClassId = classFilter.value;
        
        // Clear current options
        studentSelect.innerHTML = '<option value="">-- Select Student --</option>';
        
        // Filter and add students
        const filteredStudents = selectedClassId 
            ? studentsData.filter(s => s.class_id == selectedClassId)
            : studentsData;
        
        filteredStudents.forEach(student => {
            const option = document.createElement('option');
            option.value = student.student_id;
            option.textContent = `${student.first_name} ${student.last_name} (${student.admission_number})`;
            studentSelect.appendChild(option);
        });
    }
    
    function removeStudentField(fieldId, mode) {
        const prefix = mode === 'edit' ? 'edit-' : '';
        const field = document.getElementById(`${prefix}student-field-${fieldId}`);
        if (field) {
            field.remove();
        }
    }
    
    // View Toggle Functions
    function setView(view) {
        const table = document.getElementById('parentsTable');
        const grid = document.getElementById('parentsGrid');
        const btnList = document.getElementById('btnListView');
        const btnGrid = document.getElementById('btnGridView');
        
        if (view === 'grid') {
            if (table) table.style.display = 'none';
            if (grid) grid.style.display = 'grid';
            btnList.style.background = 'var(--bg-secondary)';
            btnList.style.color = 'var(--text-primary)';
            btnGrid.style.background = 'var(--primary-blue)';
            btnGrid.style.color = 'white';
            localStorage.setItem('parentView', 'grid');
        } else {
            if (table) table.style.display = 'block';
            if (grid) grid.style.display = 'none';
            btnList.style.background = 'var(--primary-blue)';
            btnList.style.color = 'white';
            btnGrid.style.background = 'var(--bg-secondary)';
            btnGrid.style.color = 'var(--text-primary)';
            localStorage.setItem('parentView', 'list');
        }
    }
    
    // Toggle Credentials Visibility
    function toggleCredentials(userId) {
        const hidden = document.getElementById('cred-hidden-' + userId);
        const shown = document.getElementById('cred-shown-' + userId);
        const eyes = document.querySelectorAll('#eye-' + userId);
        
        if (hidden.style.display === 'none') {
            hidden.style.display = 'block';
            shown.style.display = 'none';
            eyes.forEach(eye => eye.className = 'fas fa-eye');
        } else {
            hidden.style.display = 'none';
            shown.style.display = 'block';
            eyes.forEach(eye => eye.className = 'fas fa-eye-slash');
        }
    }
    
    // Reset Password with Parent Name
    function resetParentPassword(userId, parentName) {
        if (confirm('Reset password for ' + parentName + '?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="user_id" value="${userId}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Load saved view preference on page load
    window.addEventListener('DOMContentLoaded', function() {
        const savedView = localStorage.getItem('parentView') || 'grid';
        setView(savedView);
    });
    
    async function editParent(parent) {
        document.getElementById('edit_user_id').value = parent.user_id;
        document.getElementById('edit_parent_id').value = parent.parent_id || '';
        document.getElementById('edit_first_name').value = parent.first_name;
        document.getElementById('edit_last_name').value = parent.last_name;
        document.getElementById('edit_email').value = parent.email;
        document.getElementById('edit_phone').value = parent.phone || '';
        document.getElementById('edit_address').value = parent.address || '';
        document.getElementById('edit_status').value = parent.status;
        
        // Clear existing student fields
        const container = document.getElementById('editStudentFieldsContainer');
        container.innerHTML = '';
        editStudentFieldCount = 0;
        
        // Load existing children if parent_id exists
        if (parent.parent_id) {
            try {
                const response = await fetch('<?php echo APP_URL; ?>/admin/get-parent-children.php?parent_id=' + parent.parent_id);
                const children = await response.json();
                
                if (children && children.length > 0) {
                    // Add fields for each existing child
                    children.forEach(child => {
                        editStudentFieldCount++;
                        const fieldDiv = document.createElement('div');
                        fieldDiv.id = `edit-student-field-${editStudentFieldCount}`;
                        fieldDiv.style.cssText = 'display: flex; gap: 10px; margin-bottom: 15px; align-items: flex-start; padding: 15px; background: #e3f2fd; border-radius: 8px; border-left: 4px solid #2196F3;';
                        
                        let classOptions = '<option value="">-- Select Class --</option>';
                        classesData.forEach(cls => {
                            const selected = cls.class_id == child.class_id ? 'selected' : '';
                            classOptions += `<option value="${cls.class_id}" ${selected}>${cls.class_name}</option>`;
                        });
                        
                        let studentOptions = '<option value="">-- Select Student --</option>';
                        studentsData.forEach(s => {
                            const selected = s.student_id == child.student_id ? 'selected' : '';
                            studentOptions += `<option value="${s.student_id}" ${selected}>${s.first_name} ${s.last_name} (${s.admission_number})</option>`;
                        });
                        
                        fieldDiv.innerHTML = `
                            <div style="flex: 1;">
                                <label style="display: block; margin-bottom: 5px; font-size: 13px; font-weight: 600;">Class</label>
                                <select class="class-filter" onchange="filterStudents(${editStudentFieldCount}, 'edit')" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
                                    ${classOptions}
                                </select>
                            </div>
                            <div style="flex: 2;">
                                <label style="display: block; margin-bottom: 5px; font-size: 13px; font-weight: 600;">Student Name</label>
                                <select name="student_ids[]" id="edit-student-select-${editStudentFieldCount}" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px;">
                                    ${studentOptions}
                                </select>
                            </div>
                            <button type="button" onclick="removeStudentField(${editStudentFieldCount}, 'edit')" class="btn btn-danger btn-sm" style="margin-top: 28px;">
                                <i class="fas fa-times"></i>
                            </button>
                        `;
                        
                        container.appendChild(fieldDiv);
                    });
                }
            } catch (error) {
                console.error('Error loading children:', error);
            }
        }
        
        // If no children, add one empty field
        if (editStudentFieldCount === 0) {
            addEditStudentField();
        }
        
        document.getElementById('editModal').style.display = 'block';
    }
    
    function closeAddModal() {
        document.getElementById('addModal').style.display = 'none';
    }
    
    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
    }
    
    function deleteParent(userId, parentName) {
        if (confirm('Are you sure you want to delete ' + parentName + '?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="user_id" value="${userId}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    function resetPassword(userId) {
        if (confirm('Reset password for this parent?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="user_id" value="${userId}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Auto-add first student field when modal opens
    document.addEventListener('click', function(e) {
        if (e.target && e.target.matches('[onclick*="addModal"]')) {
            setTimeout(() => {
                const container = document.getElementById('studentFieldsContainer');
                if (container && container.children.length === 0) {
                    addStudentField();
                }
            }, 100);
        }
    });
    
    // Close modal when clicking outside
    document.getElementById('addModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeAddModal();
        }
    });
    
    document.getElementById('editModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeEditModal();
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
