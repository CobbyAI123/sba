<?php
// admin/payment-gateway-settings.php - Payment Gateway Configuration
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Payment Gateway Settings';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] == 'save_settings') {
        $settings_to_save = [
            // MTN MoMo
            'mtn_momo_enabled' => isset($_POST['mtn_momo_enabled']) ? 1 : 0,
            'mtn_momo_api_url' => sanitize_input($_POST['mtn_momo_api_url'] ?? ''),
            'mtn_momo_api_key' => sanitize_input($_POST['mtn_momo_api_key'] ?? ''),
            'mtn_momo_user_id' => sanitize_input($_POST['mtn_momo_user_id'] ?? ''),
            'mtn_momo_subscription_key' => sanitize_input($_POST['mtn_momo_subscription_key'] ?? ''),
            'mtn_momo_environment' => sanitize_input($_POST['mtn_momo_environment'] ?? 'sandbox'),
            
            // Tigo Cash
            'tigo_cash_enabled' => isset($_POST['tigo_cash_enabled']) ? 1 : 0,
            'tigo_cash_api_url' => sanitize_input($_POST['tigo_cash_api_url'] ?? ''),
            'tigo_cash_merchant_code' => sanitize_input($_POST['tigo_cash_merchant_code'] ?? ''),
            'tigo_cash_merchant_pin' => sanitize_input($_POST['tigo_cash_merchant_pin'] ?? ''),
            'tigo_cash_username' => sanitize_input($_POST['tigo_cash_username'] ?? ''),
            'tigo_cash_password' => sanitize_input($_POST['tigo_cash_password'] ?? ''),
            
            // PayStack
            'paystack_enabled' => isset($_POST['paystack_enabled']) ? 1 : 0,
            'paystack_public_key' => sanitize_input($_POST['paystack_public_key'] ?? ''),
            'paystack_secret_key' => sanitize_input($_POST['paystack_secret_key'] ?? '')
        ];
        
        try {
            foreach ($settings_to_save as $key => $value) {
                $stmt = $db->prepare("
                    INSERT INTO settings (school_id, setting_key, setting_value)
                    VALUES (?, ?, ?)
                    ON DUPLICATE KEY UPDATE setting_value = ?
                ");
                $stmt->execute([$school_id, $key, $value, $value]);
            }
            
            set_message('success', 'Payment gateway settings saved successfully!');
        } catch (PDOException $e) {
            set_message('error', 'Error saving settings: ' . $e->getMessage());
        }
        redirect(APP_URL . '/admin/payment-gateway-settings.php');
    }
}

// Load current settings
$current_settings = [];
try {
    $stmt = $db->prepare("
        SELECT setting_key, setting_value 
        FROM settings 
        WHERE school_id = ? AND (
            setting_key LIKE 'mtn_momo_%' OR 
            setting_key LIKE 'tigo_cash_%' OR 
            setting_key LIKE 'paystack_%'
        )
    ");
    $stmt->execute([$school_id]);
    $current_settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    $current_settings = [];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .gateway-card {
        border: 2px solid var(--border-color);
        border-radius: 10px;
        padding: 25px;
        margin-bottom: 30px;
    }
    
    .gateway-card.enabled {
        border-color: var(--success-green);
        background: rgba(76, 175, 80, 0.05);
    }
    
    .gateway-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 2px solid var(--border-color);
    }
    
    .toggle-switch {
        position: relative;
        width: 60px;
        height: 30px;
    }
    
    .toggle-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .4s;
        border-radius: 30px;
    }
    
    .slider:before {
        position: absolute;
        content: "";
        height: 22px;
        width: 22px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
    }
    
    input:checked + .slider {
        background-color: var(--success-green);
    }
    
    input:checked + .slider:before {
        transform: translateX(30px);
    }
    </style>
    
    <div style="margin-bottom: 20px;">
        <h2><i class="fas fa-credit-card"></i> Payment Gateway Settings</h2>
        <p style="color: var(--text-secondary);">Configure online payment methods for school fees</p>
    </div>
    
    <div class="alert alert-info" style="margin-bottom: 30px;">
        <i class="fas fa-info-circle"></i>
        <strong>Important:</strong> Payment gateways are for <strong>SCHOOL FEES ONLY</strong> (tuition, exam fees, etc). 
        Canteen and bus fees are collected daily in cash by teachers.
    </div>
    
    <form method="POST">
        <input type="hidden" name="action" value="save_settings">
        
        <!-- MTN Mobile Money -->
        <div class="gateway-card <?php echo ($current_settings['mtn_momo_enabled'] ?? 0) ? 'enabled' : ''; ?>">
            <div class="gateway-header">
                <div>
                    <h3 style="margin: 0; color: #FFCC00;">
                        <i class="fas fa-mobile-alt"></i> MTN Mobile Money
                    </h3>
                    <p style="margin: 5px 0 0 0; color: var(--text-secondary);">
                        Ghana's leading mobile money service
                    </p>
                </div>
                <label class="toggle-switch">
                    <input type="checkbox" name="mtn_momo_enabled" value="1" 
                           <?php echo ($current_settings['mtn_momo_enabled'] ?? 0) ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
            </div>
            
            <div class="form-group">
                <label>API URL</label>
                <input type="url" name="mtn_momo_api_url" class="form-control" 
                       value="<?php echo htmlspecialchars($current_settings['mtn_momo_api_url'] ?? 'https://sandbox.momodeveloper.mtn.com'); ?>"
                       placeholder="https://sandbox.momodeveloper.mtn.com">
                <small style="color: var(--text-secondary);">Use sandbox URL for testing, production URL for live</small>
            </div>
            
            <div class="form-group">
                <label>API Key</label>
                <input type="text" name="mtn_momo_api_key" class="form-control" 
                       value="<?php echo htmlspecialchars($current_settings['mtn_momo_api_key'] ?? ''); ?>"
                       placeholder="Enter your MTN MoMo API Key">
            </div>
            
            <div class="form-group">
                <label>User ID</label>
                <input type="text" name="mtn_momo_user_id" class="form-control" 
                       value="<?php echo htmlspecialchars($current_settings['mtn_momo_user_id'] ?? ''); ?>"
                       placeholder="Enter your User ID">
            </div>
            
            <div class="form-group">
                <label>Subscription Key</label>
                <input type="text" name="mtn_momo_subscription_key" class="form-control" 
                       value="<?php echo htmlspecialchars($current_settings['mtn_momo_subscription_key'] ?? ''); ?>"
                       placeholder="Enter your Subscription Key">
            </div>
            
            <div class="form-group">
                <label>Environment</label>
                <select name="mtn_momo_environment" class="form-control">
                    <option value="sandbox" <?php echo ($current_settings['mtn_momo_environment'] ?? 'sandbox') == 'sandbox' ? 'selected' : ''; ?>>
                        Sandbox (Testing)
                    </option>
                    <option value="production" <?php echo ($current_settings['mtn_momo_environment'] ?? '') == 'production' ? 'selected' : ''; ?>>
                        Production (Live)
                    </option>
                </select>
            </div>
            
            <div class="alert alert-info" style="margin-top: 20px;">
                <strong>Setup Guide:</strong>
                <ol style="margin: 10px 0 0 20px;">
                    <li>Visit <a href="https://momodeveloper.mtn.com" target="_blank">MTN MoMo Developer Portal</a></li>
                    <li>Create account and subscribe to Collections product</li>
                    <li>Get your API Key and Subscription Key</li>
                    <li>Create a user in sandbox/production</li>
                    <li>Enter credentials above</li>
                </ol>
            </div>
        </div>
        
        <!-- Tigo Cash -->
        <div class="gateway-card <?php echo ($current_settings['tigo_cash_enabled'] ?? 0) ? 'enabled' : ''; ?>">
            <div class="gateway-header">
                <div>
                    <h3 style="margin: 0; color: #0066CC;">
                        <i class="fas fa-money-bill-wave"></i> Tigo Cash
                    </h3>
                    <p style="margin: 5px 0 0 0; color: var(--text-secondary);">
                        Alternative mobile money payment
                    </p>
                </div>
                <label class="toggle-switch">
                    <input type="checkbox" name="tigo_cash_enabled" value="1" 
                           <?php echo ($current_settings['tigo_cash_enabled'] ?? 0) ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
            </div>
            
            <div class="form-group">
                <label>API URL</label>
                <input type="url" name="tigo_cash_api_url" class="form-control" 
                       value="<?php echo htmlspecialchars($current_settings['tigo_cash_api_url'] ?? 'https://api.tigo.com'); ?>"
                       placeholder="https://api.tigo.com">
            </div>
            
            <div class="form-group">
                <label>Merchant Code</label>
                <input type="text" name="tigo_cash_merchant_code" class="form-control" 
                       value="<?php echo htmlspecialchars($current_settings['tigo_cash_merchant_code'] ?? ''); ?>"
                       placeholder="Enter your Merchant Code">
            </div>
            
            <div class="form-group">
                <label>Merchant PIN</label>
                <input type="password" name="tigo_cash_merchant_pin" class="form-control" 
                       value="<?php echo htmlspecialchars($current_settings['tigo_cash_merchant_pin'] ?? ''); ?>"
                       placeholder="Enter your Merchant PIN">
            </div>
            
            <div class="form-group">
                <label>API Username</label>
                <input type="text" name="tigo_cash_username" class="form-control" 
                       value="<?php echo htmlspecialchars($current_settings['tigo_cash_username'] ?? ''); ?>"
                       placeholder="Enter your API Username">
            </div>
            
            <div class="form-group">
                <label>API Password</label>
                <input type="password" name="tigo_cash_password" class="form-control" 
                       value="<?php echo htmlspecialchars($current_settings['tigo_cash_password'] ?? ''); ?>"
                       placeholder="Enter your API Password">
            </div>
            
            <div class="alert alert-info" style="margin-top: 20px;">
                <strong>Setup Guide:</strong>
                <ol style="margin: 10px 0 0 20px;">
                    <li>Contact Tigo Ghana for merchant account</li>
                    <li>Complete merchant registration</li>
                    <li>Receive merchant code and credentials</li>
                    <li>Get API access credentials</li>
                    <li>Enter credentials above</li>
                </ol>
            </div>
        </div>
        
        <!-- PayStack -->
        <div class="gateway-card <?php echo ($current_settings['paystack_enabled'] ?? 0) ? 'enabled' : ''; ?>">
            <div class="gateway-header">
                <div>
                    <h3 style="margin: 0; color: #00C3F7;">
                        <i class="fas fa-credit-card"></i> PayStack
                    </h3>
                    <p style="margin: 5px 0 0 0; color: var(--text-secondary);">
                        Accept card payments (Visa, Mastercard, Verve)
                    </p>
                </div>
                <label class="toggle-switch">
                    <input type="checkbox" name="paystack_enabled" value="1" 
                           <?php echo ($current_settings['paystack_enabled'] ?? 0) ? 'checked' : ''; ?>>
                    <span class="slider"></span>
                </label>
            </div>
            
            <div class="form-group">
                <label>Public Key</label>
                <input type="text" name="paystack_public_key" class="form-control" 
                       value="<?php echo htmlspecialchars($current_settings['paystack_public_key'] ?? ''); ?>"
                       placeholder="pk_test_xxxxx or pk_live_xxxxx">
                <small style="color: var(--text-secondary);">Starts with pk_test_ or pk_live_</small>
            </div>
            
            <div class="form-group">
                <label>Secret Key</label>
                <input type="password" name="paystack_secret_key" class="form-control" 
                       value="<?php echo htmlspecialchars($current_settings['paystack_secret_key'] ?? ''); ?>"
                       placeholder="sk_test_xxxxx or sk_live_xxxxx">
                <small style="color: var(--text-secondary);">Starts with sk_test_ or sk_live_</small>
            </div>
            
            <div class="alert alert-info" style="margin-top: 20px;">
                <strong>Setup Guide:</strong>
                <ol style="margin: 10px 0 0 20px;">
                    <li>Visit <a href="https://paystack.com" target="_blank">PayStack.com</a></li>
                    <li>Create a business account</li>
                    <li>Complete KYC verification</li>
                    <li>Go to Settings → API Keys</li>
                    <li>Copy Public and Secret keys</li>
                    <li>Enter keys above</li>
                </ol>
            </div>
        </div>
        
        <!-- Save Button -->
        <div style="text-align: right;">
            <button type="submit" class="btn btn-success btn-lg">
                <i class="fas fa-save"></i> Save All Settings
            </button>
        </div>
    </form>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
