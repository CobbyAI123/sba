<?php
// admin/manage-exams.php - Exam Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Manage Exams';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$user_id = $current_user['user_id'];

// Handle exam actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('error', 'Invalid request');
        redirect(APP_URL . '/admin/manage-exams.php');
        exit;
    }
    
    if ($_POST['action'] == 'create_exam') {
        $exam_name = sanitize_input($_POST['exam_name']);
        $exam_type = sanitize_input($_POST['exam_type']);
        $academic_year = sanitize_input($_POST['academic_year']);
        $start_date = sanitize_input($_POST['start_date']);
        $end_date = sanitize_input($_POST['end_date']);
        $term_id = !empty($_POST['term_id']) ? (int)$_POST['term_id'] : NULL;
        $instructions = sanitize_input($_POST['instructions']);
        
        try {
            $stmt = $db->prepare("
                INSERT INTO exams 
                (school_id, term_id, exam_name, exam_type, academic_year, start_date, end_date, instructions, created_by, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft')
            ");
            $stmt->execute([$school_id, $term_id, $exam_name, $exam_type, $academic_year, $start_date, $end_date, $instructions, $user_id]);
            
            $exam_id = $db->lastInsertId();
            log_activity($user_id, "Created exam: $exam_name", 'exams', $exam_id);
            set_message('success', 'Exam created successfully!');
            redirect(APP_URL . '/admin/exam-schedule.php?exam_id=' . $exam_id);
            
        } catch (PDOException $e) {
            set_message('error', 'Error creating exam: ' . $e->getMessage());
        }
    } elseif ($_POST['action'] == 'update_status') {
        $exam_id = (int)$_POST['exam_id'];
        $status = sanitize_input($_POST['status']);
        
        try {
            $stmt = $db->prepare("UPDATE exams SET status = ? WHERE exam_id = ? AND school_id = ?");
            $stmt->execute([$status, $exam_id, $school_id]);
            
            log_activity($user_id, "Updated exam status to: $status", 'exams', $exam_id);
            set_message('success', 'Status updated successfully!');
            redirect(APP_URL . '/admin/manage-exams.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error updating status: ' . $e->getMessage());
        }
    } elseif ($_POST['action'] == 'generate_hall_tickets') {
        $exam_id = (int)$_POST['exam_id'];
        
        try {
            $stmt = $db->prepare("CALL generate_hall_tickets(?, ?)");
            $stmt->execute([$exam_id, $school_id]);
            $result = $stmt->fetch();
            
            log_activity($user_id, "Generated hall tickets for exam ID: $exam_id", 'exams', $exam_id);
            set_message('success', $result['tickets_generated'] . ' hall tickets generated!');
            redirect(APP_URL . '/admin/manage-exams.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error generating tickets: ' . $e->getMessage());
        }
    } elseif ($_POST['action'] == 'delete_exam') {
        $exam_id = (int)$_POST['exam_id'];
        
        try {
            // Check if exam has any schedules
            $stmt = $db->prepare("SELECT COUNT(*) as count FROM exam_schedule WHERE exam_id = ?");
            $stmt->execute([$exam_id]);
            $has_schedule = $stmt->fetch()['count'] > 0;
            
            if ($has_schedule) {
                set_message('error', 'Cannot delete exam with schedules');
            } else {
                $stmt = $db->prepare("DELETE FROM exams WHERE exam_id = ? AND school_id = ?");
                $stmt->execute([$exam_id, $school_id]);
                
                log_activity($user_id, "Deleted exam ID: $exam_id", 'exams', $exam_id);
                set_message('success', 'Exam deleted successfully!');
            }
            redirect(APP_URL . '/admin/manage-exams.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error deleting exam: ' . $e->getMessage());
        }
    }
}

// Get all exams
$exams = [];
try {
    $stmt = $db->prepare("
        SELECT 
            e.*,
            COUNT(DISTINCT es.schedule_id) as total_papers,
            COUNT(DISTINCT ht.ticket_id) as hall_tickets_issued,
            COUNT(DISTINCT es.class_id) as classes_involved,
            DATEDIFF(e.start_date, CURDATE()) as days_until_start
        FROM exams e
        LEFT JOIN exam_schedule es ON e.exam_id = es.exam_id
        LEFT JOIN hall_tickets ht ON e.exam_id = ht.exam_id
        WHERE e.school_id = ?
        GROUP BY e.exam_id
        ORDER BY e.start_date DESC
    ");
    $stmt->execute([$school_id]);
    $exams = $stmt->fetchAll();
} catch (PDOException $e) {
    // Fallback if hall_tickets table doesn't exist
    try {
        $stmt = $db->prepare("
            SELECT 
                e.*,
                COUNT(DISTINCT es.schedule_id) as total_papers,
                0 as hall_tickets_issued,
                COUNT(DISTINCT es.class_id) as classes_involved,
                DATEDIFF(e.start_date, CURDATE()) as days_until_start
            FROM exams e
            LEFT JOIN exam_schedule es ON e.exam_id = es.exam_id
            WHERE e.school_id = ?
            GROUP BY e.exam_id
            ORDER BY e.start_date DESC
        ");
        $stmt->execute([$school_id]);
        $exams = $stmt->fetchAll();
    } catch (PDOException $e2) {
        $exams = [];
    }
}

// Get active terms for dropdown
$terms = [];
try {
    $stmt = $db->prepare("
        SELECT 
            term_id, 
            term_name, 
            COALESCE(session_year, CONCAT(YEAR(start_date), '/', YEAR(end_date)), '') as academic_year 
        FROM terms 
        WHERE school_id = ? AND is_current = 1 
        ORDER BY term_name
    ");
    $stmt->execute([$school_id]);
    $terms = $stmt->fetchAll();
} catch (PDOException $e) {
    // Fallback query without session_year
    try {
        $stmt = $db->prepare("
            SELECT 
                term_id, 
                term_name, 
                CONCAT(YEAR(start_date), '/', YEAR(end_date)) as academic_year 
            FROM terms 
            WHERE school_id = ? AND is_current = 1 
            ORDER BY term_name
        ");
        $stmt->execute([$school_id]);
        $terms = $stmt->fetchAll();
    } catch (PDOException $e2) {
        $terms = [];
    }
}

// Statistics
$total_exams = count($exams);
$upcoming = count(array_filter($exams, fn($e) => $e['status'] == 'scheduled' && $e['start_date'] >= date('Y-m-d')));
$ongoing = count(array_filter($exams, fn($e) => $e['status'] == 'ongoing'));
$completed = count(array_filter($exams, fn($e) => $e['status'] == 'completed'));

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .exam-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 15px;
        transition: all 0.3s ease;
    }
    
    .exam-card:hover {
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        border-color: var(--primary-blue);
    }
    
    .exam-card.draft {
        border-left: 4px solid #9E9E9E;
    }
    
    .exam-card.scheduled {
        border-left: 4px solid #2196F3;
    }
    
    .exam-card.ongoing {
        border-left: 4px solid #FF9500;
    }
    
    .exam-card.completed {
        border-left: 4px solid #34C759;
    }
    
    .status-badge {
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .badge-draft { background: rgba(158, 158, 158, 0.1); color: #9E9E9E; }
    .badge-scheduled { background: rgba(33, 150, 243, 0.1); color: #2196F3; }
    .badge-ongoing { background: rgba(255, 149, 0, 0.1); color: #FF9500; }
    .badge-completed { background: rgba(52, 199, 89, 0.1); color: #34C759; }
    .badge-cancelled { background: rgba(255, 59, 48, 0.1); color: #FF3B30; }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.7);
        z-index: 9999;
        overflow-y: auto;
    }
    
    .modal-content {
        max-width: 600px;
        margin: 30px auto;
        background: var(--bg-card);
        border-radius: 15px;
        padding: 30px;
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-clipboard-list"></i> Manage Exams</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Create and manage school examinations
        </p>
    </div>
    
    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 25px;">
        <div style="background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $total_exams; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Exams</p>
        </div>
        <div style="background: linear-gradient(135deg, #2196F3, #03A9F4); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $upcoming; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Upcoming</p>
        </div>
        <div style="background: linear-gradient(135deg, #FF9500, #FF9F0A); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $ongoing; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Ongoing</p>
        </div>
        <div style="background: linear-gradient(135deg, #34C759, #30D158); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $completed; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Completed</p>
        </div>
    </div>
    
    <!-- Actions -->
    <div style="margin-bottom: 20px;">
        <button onclick="showCreateModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Create New Exam
        </button>
    </div>
    
    <!-- Exams List -->
    <?php if (count($exams) > 0): ?>
        <?php foreach ($exams as $exam): ?>
            <div class="exam-card <?php echo $exam['status']; ?>">
                <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                            <h3 style="margin: 0;"><?php echo htmlspecialchars($exam['exam_name']); ?></h3>
                            <span class="status-badge badge-<?php echo $exam['status']; ?>">
                                <?php echo ucfirst(str_replace('_', ' ', $exam['status'])); ?>
                            </span>
                            <span class="status-badge" style="background: rgba(0,0,0,0.05); color: var(--text-secondary);">
                                <?php echo ucfirst(str_replace('_', ' ', $exam['exam_type'])); ?>
                            </span>
                        </div>
                        
                        <p style="margin: 0 0 10px 0; color: var(--text-secondary); font-size: 13px;">
                            <i class="fas fa-calendar"></i> 
                            <?php echo date('M d, Y', strtotime($exam['start_date'])); ?> - 
                            <?php echo date('M d, Y', strtotime($exam['end_date'])); ?>
                            <?php if ($exam['days_until_start'] > 0): ?>
                                | <i class="fas fa-clock"></i> <?php echo $exam['days_until_start']; ?> days until start
                            <?php endif; ?>
                        </p>
                        
                        <?php if ($exam['instructions']): ?>
                            <div style="background: rgba(0,0,0,0.02); padding: 10px; border-radius: 8px; margin-bottom: 10px;">
                                <p style="margin: 0; font-size: 13px; line-height: 1.5;">
                                    <?php echo nl2br(htmlspecialchars(substr($exam['instructions'], 0, 150))); ?>
                                    <?php if (strlen($exam['instructions']) > 150): ?>...<?php endif; ?>
                                </p>
                            </div>
                        <?php endif; ?>
                        
                        <div style="display: flex; gap: 20px; padding-top: 10px; border-top: 1px solid var(--border-color); font-size: 13px;">
                            <div>
                                <strong>Papers:</strong> <?php echo $exam['total_papers']; ?>
                            </div>
                            <div>
                                <strong>Classes:</strong> <?php echo $exam['classes_involved']; ?>
                            </div>
                            <div>
                                <strong>Hall Tickets:</strong> <?php echo $exam['hall_tickets_issued']; ?>
                            </div>
                            <div>
                                <strong>Year:</strong> <?php echo htmlspecialchars($exam['academic_year']); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 5px; margin-left: 20px;">
                        <a href="<?php echo APP_URL; ?>/admin/exam-schedule.php?exam_id=<?php echo $exam['exam_id']; ?>" 
                           class="btn btn-sm btn-primary" title="Manage Schedule">
                            <i class="fas fa-calendar-alt"></i> Schedule
                        </a>
                        
                        <?php if ($exam['status'] == 'draft'): ?>
                            <form method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="update_status">
                                <input type="hidden" name="exam_id" value="<?php echo $exam['exam_id']; ?>">
                                <input type="hidden" name="status" value="scheduled">
                                <button type="submit" class="btn btn-sm btn-success" title="Publish">
                                    <i class="fas fa-check"></i> Publish
                                </button>
                            </form>
                        <?php endif; ?>
                        
                        <?php if ($exam['total_papers'] > 0 && $exam['hall_tickets_issued'] == 0): ?>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Generate hall tickets for all students?')">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="generate_hall_tickets">
                                <input type="hidden" name="exam_id" value="<?php echo $exam['exam_id']; ?>">
                                <button type="submit" class="btn btn-sm btn-info" title="Generate Tickets">
                                    <i class="fas fa-ticket-alt"></i> Tickets
                                </button>
                            </form>
                        <?php endif; ?>
                        
                        <?php if ($exam['status'] == 'draft'): ?>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this exam?')">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="delete_exam">
                                <input type="hidden" name="exam_id" value="<?php echo $exam['exam_id']; ?>">
                                <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div style="text-align: center; padding: 60px; background: var(--bg-card); border-radius: 15px;">
            <i class="fas fa-clipboard-list" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
            <h3 style="color: var(--text-secondary);">No Exams Created Yet</h3>
            <p style="color: var(--text-secondary);">Create your first exam to get started</p>
        </div>
    <?php endif; ?>
    
    <!-- Create Exam Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="margin: 0;"><i class="fas fa-plus"></i> Create New Exam</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="create_exam">
                
                <div class="form-group">
                    <label>Exam Name *</label>
                    <input type="text" name="exam_name" required placeholder="e.g., Mid-Term Examination">
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <div class="form-group">
                        <label>Exam Type *</label>
                        <select name="exam_type" required>
                            <option value="mid_term">Mid-Term</option>
                            <option value="final">Final Exam</option>
                            <option value="quarterly">Quarterly</option>
                            <option value="monthly">Monthly Test</option>
                            <option value="unit_test">Unit Test</option>
                            <option value="mock">Mock Exam</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Term (Optional)</label>
                        <select name="term_id">
                            <option value="">-- Select Term --</option>
                            <?php foreach ($terms as $term): ?>
                                <option value="<?php echo $term['term_id']; ?>">
                                    <?php echo htmlspecialchars($term['term_name'] . ' - ' . $term['academic_year']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Academic Year *</label>
                    <input type="text" name="academic_year" required value="<?php echo date('Y'); ?>" placeholder="e.g., 2025">
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <div class="form-group">
                        <label>Start Date *</label>
                        <input type="date" name="start_date" required>
                    </div>
                    
                    <div class="form-group">
                        <label>End Date *</label>
                        <input type="date" name="end_date" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Instructions</label>
                    <textarea name="instructions" rows="3" placeholder="General exam instructions for students..."></textarea>
                </div>
                
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check"></i> Create Exam
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showCreateModal() {
        document.getElementById('createModal').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('createModal').style.display = 'none';
    }
    
    window.onclick = function(event) {
        const modal = document.getElementById('createModal');
        if (event.target == modal) {
            closeModal();
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
