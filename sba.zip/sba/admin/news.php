<?php
// admin/news.php - News Feed & Activities Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'News & Announcements';
$current_user = check_permission(['admin', 'proprietor', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $title = sanitize_input($_POST['title']);
            $content = sanitize_input($_POST['content']);
            $category = sanitize_input($_POST['category']);
            $target_audience = sanitize_input($_POST['target_audience']);
            $priority = sanitize_input($_POST['priority']);
            $publish_date = sanitize_input($_POST['publish_date']);
            $expiry_date = !empty($_POST['expiry_date']) ? sanitize_input($_POST['expiry_date']) : null;
            $status = sanitize_input($_POST['status']);
            
            try {
                $stmt = $db->prepare("
                    INSERT INTO news (school_id, title, content, category, target_audience, 
                                    priority, published_by, publish_date, expiry_date, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $school_id, $title, $content, $category, $target_audience,
                    $priority, $current_user['user_id'], $publish_date, $expiry_date, $status
                ]);
                
                $news_id = $db->lastInsertId();
                
                // Create notifications for target audience
                if ($status == 'published') {
                    createNewsNotifications($news_id, $title, $target_audience, $school_id);
                }
                
                log_activity($current_user['user_id'], "Created news: $title", 'news', $news_id);
                
                set_message('success', 'News published successfully!');
                redirect(APP_URL . '/admin/news.php');
            } catch (PDOException $e) {
                set_message('error', 'Error creating news: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'edit') {
            $news_id = sanitize_input($_POST['news_id']);
            $title = sanitize_input($_POST['title']);
            $content = sanitize_input($_POST['content']);
            $category = sanitize_input($_POST['category']);
            $target_audience = sanitize_input($_POST['target_audience']);
            $priority = sanitize_input($_POST['priority']);
            $publish_date = sanitize_input($_POST['publish_date']);
            $expiry_date = !empty($_POST['expiry_date']) ? sanitize_input($_POST['expiry_date']) : null;
            $status = sanitize_input($_POST['status']);
            
            try {
                $stmt = $db->prepare("
                    UPDATE news 
                    SET title = ?, content = ?, category = ?, target_audience = ?,
                        priority = ?, publish_date = ?, expiry_date = ?, status = ?
                    WHERE news_id = ? AND school_id = ?
                ");
                $stmt->execute([
                    $title, $content, $category, $target_audience, $priority,
                    $publish_date, $expiry_date, $status, $news_id, $school_id
                ]);
                
                log_activity($current_user['user_id'], "Updated news: $title", 'news', $news_id);
                
                set_message('success', 'News updated successfully!');
                redirect(APP_URL . '/admin/news.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating news: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            $news_id = sanitize_input($_POST['news_id']);
            
            try {
                $stmt = $db->prepare("DELETE FROM news WHERE news_id = ? AND school_id = ?");
                $stmt->execute([$news_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted news ID: $news_id", 'news', $news_id);
                
                set_message('success', 'News deleted successfully!');
                redirect(APP_URL . '/admin/news.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting news: ' . $e->getMessage());
            }
        }
    }
}

// Function to create notifications for news
function createNewsNotifications($news_id, $title, $target_audience, $school_id) {
    $db = Database::getInstance()->getConnection();
    
    $role_map = [
        'students' => 'student',
        'parents' => 'parent',
        'teachers' => 'teacher',
        'staff' => ['admin', 'accountant', 'bookstore']
    ];
    
    if ($target_audience == 'all') {
        $stmt = $db->prepare("SELECT user_id FROM users WHERE school_id = ? AND status = 'active'");
        $stmt->execute([$school_id]);
    } else {
        $roles = $role_map[$target_audience] ?? $target_audience;
        if (is_array($roles)) {
            $placeholders = str_repeat('?,', count($roles) - 1) . '?';
            $stmt = $db->prepare("SELECT user_id FROM users WHERE school_id = ? AND role IN ($placeholders) AND status = 'active'");
            $stmt->execute(array_merge([$school_id], $roles));
        } else {
            $stmt = $db->prepare("SELECT user_id FROM users WHERE school_id = ? AND role = ? AND status = 'active'");
            $stmt->execute([$school_id, $roles]);
        }
    }
    
    $users = $stmt->fetchAll();
    
    foreach ($users as $user) {
        create_notification(
            $user['user_id'],
            'New Announcement',
            $title,
            'info',
            APP_URL . '/admin/news.php?id=' . $news_id
        );
    }
}

// Get all news
$news_list = [];
try {
    $stmt = $db->prepare("
        SELECT n.*, u.first_name, u.last_name
        FROM news n
        LEFT JOIN users u ON n.published_by = u.user_id
        WHERE n.school_id = ?
        ORDER BY n.created_at DESC
    ");
    $stmt->execute([$school_id]);
    $news_list = $stmt->fetchAll();
} catch (PDOException $e) {
    // news table doesn't exist
    $news_list = [];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
            <button class="btn btn-primary" onclick="showAddModal()">
                <i class="fas fa-plus"></i> Create News
            </button>
        </div>
    </div>
    
    <!-- News Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 20px;">
        <?php foreach ($news_list as $news): ?>
            <div class="card">
                <div style="padding: 20px;">
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 15px;">
                        <span class="badge badge-<?php 
                            echo $news['category'] == 'announcement' ? 'primary' : 
                                ($news['category'] == 'event' ? 'success' : 
                                ($news['category'] == 'exam' ? 'warning' : 'info')); 
                        ?>">
                            <?php echo ucfirst($news['category']); ?>
                        </span>
                        <span class="badge badge-<?php 
                            echo $news['priority'] == 'high' ? 'danger' : 
                                ($news['priority'] == 'medium' ? 'warning' : 'info'); 
                        ?>">
                            <?php echo ucfirst($news['priority']); ?>
                        </span>
                    </div>
                    
                    <h3 style="font-size: 18px; margin-bottom: 10px;"><?php echo $news['title']; ?></h3>
                    <p style="color: var(--text-secondary); font-size: 14px; margin-bottom: 15px; line-height: 1.6;">
                        <?php echo substr($news['content'], 0, 150) . (strlen($news['content']) > 150 ? '...' : ''); ?>
                    </p>
                    
                    <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 15px; border-top: 1px solid var(--border-color);">
                        <div style="font-size: 12px; color: var(--text-secondary);">
                            <i class="fas fa-calendar"></i> <?php echo date('M d, Y', strtotime($news['publish_date'])); ?>
                        </div>
                        <div style="display: flex; gap: 5px;">
                            <button class="btn btn-sm btn-info" onclick='editNews(<?php echo json_encode($news); ?>)'>
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="deleteNews(<?php echo $news['news_id']; ?>, '<?php echo addslashes($news['title']); ?>')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Add/Edit News Modal -->
    <div id="newsModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 800px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Create News</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="newsForm">
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="news_id" id="newsId">
                
                <div class="form-group">
                    <label for="title">Title *</label>
                    <input type="text" name="title" id="title" required>
                </div>
                
                <div class="form-group">
                    <label for="content">Content *</label>
                    <textarea name="content" id="content" rows="6" required></textarea>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label for="category">Category *</label>
                        <select name="category" id="category" required>
                            <option value="announcement">Announcement</option>
                            <option value="event">Event</option>
                            <option value="holiday">Holiday</option>
                            <option value="exam">Exam</option>
                            <option value="general">General</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="target_audience">Target Audience *</label>
                        <select name="target_audience" id="target_audience" required>
                            <option value="all">All</option>
                            <option value="students">Students</option>
                            <option value="parents">Parents</option>
                            <option value="teachers">Teachers</option>
                            <option value="staff">Staff</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="priority">Priority *</label>
                        <select name="priority" id="priority" required>
                            <option value="low">Low</option>
                            <option value="medium" selected>Medium</option>
                            <option value="high">High</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="status">Status *</label>
                        <select name="status" id="status" required>
                            <option value="draft">Draft</option>
                            <option value="published">Published</option>
                            <option value="archived">Archived</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="publish_date">Publish Date *</label>
                        <input type="date" name="publish_date" id="publish_date" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="expiry_date">Expiry Date</label>
                        <input type="date" name="expiry_date" id="expiry_date">
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save News
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showAddModal() {
        document.getElementById('newsModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Create News';
        document.getElementById('formAction').value = 'add';
        document.getElementById('newsForm').reset();
        document.getElementById('newsId').value = '';
        document.getElementById('publish_date').value = new Date().toISOString().split('T')[0];
    }
    
    function editNews(news) {
        document.getElementById('newsModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Edit News';
        document.getElementById('formAction').value = 'edit';
        document.getElementById('newsId').value = news.news_id;
        document.getElementById('title').value = news.title;
        document.getElementById('content').value = news.content;
        document.getElementById('category').value = news.category;
        document.getElementById('target_audience').value = news.target_audience;
        document.getElementById('priority').value = news.priority;
        document.getElementById('status').value = news.status;
        document.getElementById('publish_date').value = news.publish_date;
        document.getElementById('expiry_date').value = news.expiry_date || '';
    }
    
    function closeModal() {
        document.getElementById('newsModal').style.display = 'none';
    }
    
    function deleteNews(newsId, newsTitle) {
        if (confirmDelete(`Are you sure you want to delete "${newsTitle}"?`)) {
            const form = document.createElement('form');
            form.method = 'POST';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete';
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'news_id';
            idInput.value = newsId;
            
            form.appendChild(actionInput);
            form.appendChild(idInput);
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Close modal on outside click
    document.getElementById('newsModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
