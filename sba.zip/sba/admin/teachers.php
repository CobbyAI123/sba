<?php
// admin/teachers.php - Teacher Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/default-passwords.php';

$page_title = 'Teacher Management';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        // Verify CSRF token
        if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
            set_message('error', 'Invalid request. Please try again.');
            redirect(APP_URL . '/admin/teachers.php');
            exit;
        }
        if ($_POST['action'] == 'add') {
            $username = sanitize_input($_POST['username']);
            $email = sanitize_input($_POST['email']);
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $phone = sanitize_input($_POST['phone']);
            // Use default password: teacher123
            $default_credentials = generate_default_credentials('teacher');
            $random_password = $default_credentials['password']; // teacher123
            $password = $default_credentials['hash'];
            
            try {
                // Ensure unique username
                $original_username = $username;
                $counter = 1;
                while (true) {
                    $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE username = ? AND school_id = ?");
                    $check_stmt->execute([$username, $school_id]);
                    if ($check_stmt->fetch()['count'] == 0) {
                        break;
                    }
                    $username = $original_username . '_' . $counter;
                    $counter++;
                }
                
                // Ensure unique email
                $original_email = $email;
                $counter = 1;
                while (true) {
                    $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE email = ? AND school_id = ?");
                    $check_stmt->execute([$email, $school_id]);
                    if ($check_stmt->fetch()['count'] == 0) {
                        break;
                    }
                    // Extract email parts
                    $email_parts = explode('@', $original_email);
                    $email = $email_parts[0] . '_' . $counter . '@' . $email_parts[1];
                    $counter++;
                }
                
                $stmt = $db->prepare("
                    INSERT INTO users (school_id, username, email, password_hash, role, 
                                     first_name, last_name, phone, status)
                    VALUES (?, ?, ?, ?, 'teacher', ?, ?, ?, 'active')
                ");
                $stmt->execute([$school_id, $username, $email, $password, $first_name, $last_name, $phone]);
                
                $user_id = $db->lastInsertId();
                
                // Prepare user data for email
                $user_data = [
                    'user_id' => $user_id,
                    'username' => $username,
                    'email' => $email,
                    'first_name' => $first_name,
                    'last_name' => $last_name,
                    'role' => 'teacher'
                ];
                
                // Send credentials email
                $email_sent = send_teacher_credentials_email($user_data, $random_password);
                
                log_activity($current_user['user_id'], "Added new teacher: $first_name $last_name" . ($email_sent ? ' (Email sent)' : ' (Email failed)'), 'users', $user_id);
                
                if ($email_sent) {
                    set_message('success', "Teacher added successfully! Login credentials have been sent to $email. <br>Backup Info - Username: $username, Password: $random_password");
                } else {
                    set_message('warning', "Teacher added successfully but email failed to send. <br>Please provide these credentials manually - Username: $username, Password: $random_password");
                }
                redirect(APP_URL . '/admin/teachers.php');
            } catch (PDOException $e) {
                set_message('error', 'Error adding teacher: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'edit') {
            $user_id = sanitize_input($_POST['user_id']);
            $email = sanitize_input($_POST['email']);
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $phone = sanitize_input($_POST['phone']);
            $status = sanitize_input($_POST['status']);
            
            try {
                $stmt = $db->prepare("
                    UPDATE users 
                    SET email = ?, first_name = ?, last_name = ?, phone = ?, status = ?
                    WHERE user_id = ? AND school_id = ? AND role = 'teacher'
                ");
                $stmt->execute([$email, $first_name, $last_name, $phone, $status, $user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Updated teacher: $first_name $last_name", 'users', $user_id);
                
                set_message('success', 'Teacher updated successfully!');
                redirect(APP_URL . '/admin/teachers.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating teacher: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            $user_id = sanitize_input($_POST['user_id']);
            
            try {
                $stmt = $db->prepare("DELETE FROM users WHERE user_id = ? AND school_id = ? AND role = 'teacher'");
                $stmt->execute([$user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted teacher ID: $user_id", 'users', $user_id);
                
                set_message('success', 'Teacher deleted successfully!');
                redirect(APP_URL . '/admin/teachers.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting teacher: ' . $e->getMessage());
            }
        }
    }
}

// Get all teachers
$teachers = [];
try {
    $stmt = $db->prepare("
        SELECT u.*,
               COUNT(DISTINCT cs.subject_id) as subject_count
        FROM users u
        LEFT JOIN class_subjects cs ON u.user_id = cs.teacher_id
        WHERE u.school_id = ? AND u.role = 'teacher'
        GROUP BY u.user_id
        ORDER BY u.created_at DESC
    ");
    $stmt->execute([$school_id]);
    $teachers = $stmt->fetchAll();
} catch (PDOException $e) {
    // class_subjects table may not exist
    $stmt = $db->prepare("SELECT * FROM users WHERE school_id = ? AND role = 'teacher' ORDER BY created_at DESC");
    $stmt->execute([$school_id]);
    $teachers = $stmt->fetchAll();
    // Add default subject_count for display
    foreach ($teachers as &$teacher) {
        $teacher['subject_count'] = 0;
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; gap: 10px;">
            <button class="btn btn-primary" onclick="showAddModal()">
                <i class="fas fa-plus"></i> Add Teacher
            </button>
            
            <!-- View Toggle -->
            <div class="btn-group" style="display: inline-flex; border: 2px solid var(--border-color); border-radius: 8px; overflow: hidden;">
                <button id="btnListView" onclick="setView('list')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--primary-blue); color: white;">
                    <i class="fas fa-list"></i> List
                </button>
                <button id="btnGridView" onclick="setView('grid')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--bg-secondary); color: var(--text-primary);">
                    <i class="fas fa-th"></i> Grid
                </button>
            </div>
        </div>
        
        <div style="font-weight: 600; color: var(--text-secondary);">
            Total Teachers: <?php echo count($teachers); ?>
        </div>
    </div>
    
    <!-- List View -->
    <div id="teachersTable" class="card">
        <div class="card-header">
            <h3><i class="fas fa-chalkboard-teacher"></i> Teachers (<?php echo count($teachers); ?>)</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Teacher Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Subjects</th>
                        <th>Login Credentials</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($teachers) > 0): ?>
                        <?php foreach ($teachers as $teacher): ?>
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 35px; height: 35px; border-radius: 8px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600;">
                                            <?php echo strtoupper(substr($teacher['first_name'], 0, 1) . substr($teacher['last_name'], 0, 1)); ?>
                                        </div>
                                        <span><?php echo $teacher['first_name'] . ' ' . $teacher['last_name']; ?></span>
                                    </div>
                                </td>
                                <td><strong><?php echo $teacher['username']; ?></strong></td>
                                <td><?php echo $teacher['email']; ?></td>
                                <td><?php echo $teacher['phone'] ?: 'N/A'; ?></td>
                                <td>
                                    <span class="badge badge-info">
                                        <?php echo $teacher['subject_count']; ?> subjects
                                    </span>
                                </td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <div id="cred-hidden-<?php echo $teacher['user_id']; ?>" style="font-family: monospace; font-size: 12px;">
                                            ••••••••
                                        </div>
                                        <div id="cred-shown-<?php echo $teacher['user_id']; ?>" style="display: none; font-family: monospace; font-size: 11px; line-height: 1.4;">
                                            <strong>User:</strong> <?php echo htmlspecialchars($teacher['username']); ?><br>
                                            <strong>Pass:</strong> teacher123
                                        </div>
                                        <button onclick="toggleCredentials(<?php echo $teacher['user_id']; ?>); return false;" type="button" class="btn btn-sm" style="padding: 4px 8px; background: var(--primary-blue); color: white; border: none; border-radius: 4px; cursor: pointer;">
                                            <i class="fas fa-eye" id="eye-<?php echo $teacher['user_id']; ?>"></i>
                                        </button>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge badge-<?php 
                                        echo $teacher['status'] == 'active' ? 'success' : 
                                            ($teacher['status'] == 'suspended' ? 'warning' : 'danger'); 
                                    ?>">
                                        <?php echo ucfirst($teacher['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-info" onclick='editTeacher(<?php echo json_encode($teacher); ?>)'>
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="deleteTeacher(<?php echo $teacher['user_id']; ?>, '<?php echo addslashes($teacher['first_name'] . ' ' . $teacher['last_name']); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 60px;">
                                <i class="fas fa-chalkboard-teacher" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                                <h3 style="margin-bottom: 10px;">No Teachers Yet</h3>
                                <p style="color: var(--text-secondary); margin-bottom: 20px;">Add teachers to manage classes and subjects</p>
                                <button class="btn btn-primary" onclick="showAddModal()">
                                    <i class="fas fa-plus"></i> Add Your First Teacher
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Grid View -->
    <div id="teachersGrid" style="display: none; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
        <?php foreach ($teachers as $teacher): ?>
            <div class="card" style="padding: 20px;">
                <div style="text-align: center; margin-bottom: 15px;">
                    <div style="width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 28px; margin: 0 auto;">
                        <?php echo strtoupper(substr($teacher['first_name'], 0, 1) . substr($teacher['last_name'], 0, 1)); ?>
                    </div>
                </div>
                
                <h4 style="text-align: center; margin: 0 0 5px 0;">
                    <?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']); ?>
                </h4>
                <p style="text-align: center; color: var(--text-secondary); font-size: 12px; margin: 0 0 15px 0;">
                    <i class="fas fa-chalkboard-teacher"></i> Teacher
                </p>
                
                <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-bottom: 12px; font-size: 13px;">
                    <div style="margin-bottom: 8px;">
                        <i class="fas fa-envelope" style="width: 20px;"></i> 
                        <strong>Email:</strong> <span style="font-size: 11px;"><?php echo htmlspecialchars($teacher['email']); ?></span>
                    </div>
                    <div style="margin-bottom: 8px;">
                        <i class="fas fa-phone" style="width: 20px;"></i> 
                        <strong>Phone:</strong> <?php echo htmlspecialchars($teacher['phone'] ?: 'N/A'); ?>
                    </div>
                    <div>
                        <i class="fas fa-book" style="width: 20px;"></i> 
                        <strong>Subjects:</strong> <?php echo $teacher['subject_count']; ?> subjects
                    </div>
                </div>
                
                <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-bottom: 12px; font-size: 12px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <strong><i class="fas fa-key"></i> Login Credentials</strong>
                        <button onclick="toggleCredentials(<?php echo $teacher['user_id']; ?>); return false;" type="button" class="btn btn-sm" style="padding: 4px 8px; background: var(--primary-blue); color: white; border: none; border-radius: 4px; cursor: pointer;">
                            <i class="fas fa-eye" id="eye-<?php echo $teacher['user_id']; ?>"></i>
                        </button>
                    </div>
                    <div id="cred-hidden-<?php echo $teacher['user_id']; ?>" style="font-family: monospace; color: var(--text-primary);">
                        ••••••••
                    </div>
                    <div id="cred-shown-<?php echo $teacher['user_id']; ?>" style="display: none; font-family: monospace; line-height: 1.6; color: var(--text-primary);">
                        <strong>Username:</strong> <?php echo htmlspecialchars($teacher['username']); ?><br>
                        <strong>Password:</strong> teacher123
                    </div>
                </div>
                
                <div style="text-align: center; margin-bottom: 12px;">
                    <span class="badge badge-<?php echo $teacher['status'] == 'active' ? 'success' : ($teacher['status'] == 'suspended' ? 'warning' : 'danger'); ?>">
                        <?php echo ucfirst($teacher['status']); ?>
                    </span>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
                    <button class="btn btn-sm btn-info" onclick='editTeacher(<?php echo json_encode($teacher); ?>)'>
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteTeacher(<?php echo $teacher['user_id']; ?>, '<?php echo addslashes($teacher['first_name'] . ' ' . $teacher['last_name']); ?>')">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Add/Edit Teacher Modal -->
    <div id="teacherModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Add Teacher</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="teacherForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="user_id" id="userId">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label for="first_name">First Name *</label>
                        <input type="text" name="first_name" id="first_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name *</label>
                        <input type="text" name="last_name" id="last_name" required>
                    </div>
                </div>
                
                <div class="form-group" id="usernameGroup">
                    <label for="username">Username *</label>
                    <input type="text" name="username" id="username" required>
                    <small style="color: var(--text-secondary); font-size: 12px;">Used for login</small>
                </div>
                
                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" name="email" id="email" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="tel" name="phone" id="phone">
                </div>
                
                <div class="form-group" id="statusGroup" style="display: none;">
                    <label for="status">Status *</label>
                    <select name="status" id="status">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="suspended">Suspended</option>
                    </select>
                </div>
                
                <div class="alert alert-info" id="passwordInfo" style="display: none; margin-top: 15px;">
                    <i class="fas fa-info-circle"></i>
                    <strong>Automatic Email Notification:</strong><br>
                    A secure random password will be generated and sent to the teacher's email address along with:
                    <ul style="margin: 10px 0 0 20px; font-size: 13px;">
                        <li>Username and password</li>
                        <li>Direct login link</li>
                        <li>Security instructions</li>
                    </ul>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Teacher
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    // View Toggle Functions
    function setView(view) {
        const table = document.getElementById('teachersTable');
        const grid = document.getElementById('teachersGrid');
        const btnList = document.getElementById('btnListView');
        const btnGrid = document.getElementById('btnGridView');
        
        if (view === 'grid') {
            table.style.display = 'none';
            grid.style.display = 'grid';
            btnList.style.background = 'var(--bg-secondary)';
            btnList.style.color = 'var(--text-primary)';
            btnGrid.style.background = 'var(--primary-blue)';
            btnGrid.style.color = 'white';
            localStorage.setItem('teacherView', 'grid');
        } else {
            table.style.display = 'block';
            grid.style.display = 'none';
            btnList.style.background = 'var(--primary-blue)';
            btnList.style.color = 'white';
            btnGrid.style.background = 'var(--bg-secondary)';
            btnGrid.style.color = 'var(--text-primary)';
            localStorage.setItem('teacherView', 'list');
        }
    }
    
    // Toggle Credentials Visibility
    function toggleCredentials(userId) {
        const hidden = document.getElementById('cred-hidden-' + userId);
        const shown = document.getElementById('cred-shown-' + userId);
        const eyes = document.querySelectorAll('#eye-' + userId);
        
        if (hidden.style.display === 'none') {
            hidden.style.display = 'block';
            shown.style.display = 'none';
            eyes.forEach(eye => eye.className = 'fas fa-eye');
        } else {
            hidden.style.display = 'none';
            shown.style.display = 'block';
            eyes.forEach(eye => eye.className = 'fas fa-eye-slash');
        }
    }
    
    // Load saved view preference
    window.addEventListener('DOMContentLoaded', function() {
        const savedView = localStorage.getItem('teacherView') || 'list';
        setView(savedView);
    });
    
    function showAddModal() {
        document.getElementById('teacherModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Add Teacher';
        document.getElementById('formAction').value = 'add';
        document.getElementById('teacherForm').reset();
        document.getElementById('userId').value = '';
        document.getElementById('usernameGroup').style.display = 'block';
        document.getElementById('statusGroup').style.display = 'none';
        document.getElementById('passwordInfo').style.display = 'block';
    }
    
    function editTeacher(teacher) {
        document.getElementById('teacherModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Edit Teacher';
        document.getElementById('formAction').value = 'edit';
        document.getElementById('userId').value = teacher.user_id;
        document.getElementById('first_name').value = teacher.first_name;
        document.getElementById('last_name').value = teacher.last_name;
        document.getElementById('email').value = teacher.email;
        document.getElementById('phone').value = teacher.phone || '';
        document.getElementById('status').value = teacher.status;
        document.getElementById('usernameGroup').style.display = 'none';
        document.getElementById('statusGroup').style.display = 'block';
        document.getElementById('passwordInfo').style.display = 'none';
    }
    
    function closeModal() {
        document.getElementById('teacherModal').style.display = 'none';
    }
    
    function deleteTeacher(userId, teacherName) {
        if (confirmDelete(`Are you sure you want to delete ${teacherName}?`)) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="user_id" value="${userId}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Close modal on outside click
    document.getElementById('teacherModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
