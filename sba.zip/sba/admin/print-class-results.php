<?php
// admin/print-class-results.php - Print All Students in Class
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get parameters
$class_id = (int)($_GET['class'] ?? 0);

if (!$class_id) {
    die('Class ID is required');
}

// Get active term
try {
    $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_active = 1");
    $stmt->execute([$school_id]);
    $active_term = $stmt->fetch();
} catch (PDOException $e) {
    try {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_current = 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    } catch (PDOException $e2) {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY start_date DESC LIMIT 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    }
}

if (!$active_term) {
    die('No active term found');
}

// Get class details
$stmt = $db->prepare("
    SELECT c.*, sc.school_name, sc.logo as school_logo
    FROM classes c
    INNER JOIN schools sc ON c.school_id = sc.school_id
    WHERE c.class_id = ? AND c.school_id = ?
");
$stmt->execute([$class_id, $school_id]);
$class = $stmt->fetch();

if (!$class) {
    die('Class not found');
}

// Get all students in class
try {
    $stmt = $db->prepare("
        SELECT s.*, c.class_name, 
               COALESCE(u.first_name, '-') as first_name, 
               COALESCE(u.last_name, '') as last_name,
               s.photo
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.class_id
        LEFT JOIN users u ON s.user_id = u.user_id
        WHERE s.class_id = ? AND s.school_id = ?
        ORDER BY s.admission_number
    ");
    $stmt->execute([$class_id, $school_id]);
    $students = $stmt->fetchAll();
} catch (PDOException $e) {
    die('Error fetching students: ' . $e->getMessage());
}

if (count($students) == 0) {
    die('No students found in this class');
}

// Define function once before the loop
function getOverallGrade($avg) {
    if ($avg >= 90) return 'A+';
    if ($avg >= 80) return 'A';
    if ($avg >= 75) return 'B+';
    if ($avg >= 70) return 'B';
    if ($avg >= 65) return 'C+';
    if ($avg >= 60) return 'C';
    if ($avg >= 50) return 'D';
    return 'F';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class Results - <?php echo $class['class_name']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        @page {
            size: A4;
            margin: 0;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            padding: 15px;
            background: white;
            margin: 0;
        }
        
        .page-break {
            page-break-after: always;
            break-after: always;
        }
        
        .result-sheet {
            max-width: 100%;
            margin: 0 auto;
            border: 2px solid #333;
            padding: 15px;
            background: white;
            font-size: 11px;
        }
        
        .no-print {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
        }
        
        @media print {
            html, body {
                margin: 0 !important;
                padding: 0 !important;
                width: 210mm;
                height: 297mm;
            }
            
            body {
                padding: 8mm !important;
            }
            
            .no-print {
                display: none !important;
            }
            
            .result-sheet {
                page-break-inside: avoid;
                break-inside: avoid;
                margin: 0;
                padding: 10px;
                font-size: 10px;
            }
        }
    </style>
</head>
<body>
    <!-- Print Button -->
    <div class="no-print">
        <button onclick="window.print()" style="padding: 15px 30px; font-size: 16px; background: #2196F3; color: white; border: none; border-radius: 5px; cursor: pointer; box-shadow: 0 2px 5px rgba(0,0,0,0.2);">
            Print All (<?php echo count($students); ?> students)
        </button>
        <button onclick="window.close()" style="padding: 15px 30px; font-size: 16px; background: #666; color: white; border: none; border-radius: 5px; cursor: pointer; margin-left: 10px; box-shadow: 0 2px 5px rgba(0,0,0,0.2);">
            Close
        </button>
    </div>
    
    <?php foreach ($students as $index => $student): ?>
        <?php
        // Get student results
        $stmt = $db->prepare("
            SELECT 
                subj.subject_name,
                sa.ca_score,
                sa.midterm_score,
                sa.exam_score,
                sa.total_score,
                sa.grade,
                sa.remark,
                sa.position
            FROM student_assessments sa
            INNER JOIN subjects subj ON sa.subject_id = subj.subject_id
            WHERE sa.student_id = ? AND sa.term_id = ? AND sa.school_id = ?
            ORDER BY subj.subject_name
        ");
        $stmt->execute([$student['student_id'], $active_term['term_id'], $school_id]);
        $results = $stmt->fetchAll();
        
        // Calculate statistics with fallback calculation
        $total_subjects = count($results);
        $total_marks = 0;
        foreach ($results as $result) {
            // Use calculated total if database value is 0 or null
            $score_total = $result['total_score'];
            if ($score_total == 0 || $score_total === null) {
                $score_total = calculate_total_score(
                    $result['ca_score'] ?? 0,
                    $result['midterm_score'] ?? 0,
                    $result['exam_score'] ?? 0
                );
            }
            $total_marks += $score_total;
        }
        $overall_average = $total_subjects > 0 ? round($total_marks / $total_subjects, 2) : 0;
        $overall_grade = getOverallGrade($overall_average);
        $overall_remark = $overall_average >= 80 ? 'Excellent' : ($overall_average >= 70 ? 'Very Good' : ($overall_average >= 60 ? 'Good' : ($overall_average >= 50 ? 'Fair' : 'Fail')));
        ?>
        
        <!-- Result Sheet -->
        <div class="result-sheet">
            <!-- Header with Logo and Student Photo -->
            <div style="position: relative; text-align: center; border-bottom: 2px solid #333; padding-bottom: 12px; margin-bottom: 15px; min-height: 70px;">
                <!-- Student Photo (Top Left) -->
                <?php if (!empty($student['photo'])): ?>
                    <div style="position: absolute; left: 0; top: 0;">
                        <img src="<?php echo APP_URL; ?>/uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" 
                             alt="Student Photo" 
                             style="width: 60px; height: 60px; object-fit: cover; border: 2px solid #2196F3; border-radius: 5px;"
                             onerror="this.style.display='none'">
                    </div>
                <?php endif; ?>
                
                <!-- School Logo (Top Right) -->
                <?php if (!empty($class['school_logo'])): ?>
                    <div style="position: absolute; right: 0; top: 0;">
                        <img src="<?php echo APP_URL; ?>/uploads/schools/<?php echo htmlspecialchars($class['school_logo']); ?>" 
                             alt="School Logo" 
                             style="width: 60px; height: 60px; object-fit: contain;"
                             onerror="this.style.display='none'">
                    </div>
                <?php endif; ?>
                
                <!-- School Name and Title -->
                <div style="font-size: 20px; font-weight: bold; color: #2196F3; margin-bottom: 3px;">
                    <?php echo strtoupper($class['school_name']); ?>
                </div>
                <div style="font-size: 16px; font-weight: bold; margin: 5px 0; text-transform: uppercase;">
                    Student Result Sheet
                </div>
                <div style="font-size: 12px; color: #666;">
                    <?php echo $active_term['term_name']; ?>
                    <?php echo isset($active_term['session_year']) ? ' - ' . $active_term['session_year'] : ''; ?>
                </div>
            </div>
            
            <!-- Student Information -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 15px; padding: 10px; background: #f5f5f5; border-radius: 5px; font-size: 11px;">
                <div style="display: flex; gap: 8px;">
                    <span style="font-weight: bold; min-width: 120px;">Student Name:</span>
                    <span><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></span>
                </div>
                <div style="display: flex; gap: 8px;">
                    <span style="font-weight: bold; min-width: 120px;">Admission Number:</span>
                    <span><?php echo $student['admission_number']; ?></span>
                </div>
                <div style="display: flex; gap: 8px;">
                    <span style="font-weight: bold; min-width: 120px;">Class:</span>
                    <span><?php echo $class['class_name']; ?></span>
                </div>
                <div style="display: flex; gap: 10px;">
                    <span style="font-weight: bold; min-width: 150px;">Gender:</span>
                    <span><?php echo ucfirst(($student['gender'] ?? 'N/A')); ?></span>
                </div>
            </div>
            
            <!-- Results Table -->
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                <thead>
                    <tr>
                        <th style="background: #2196F3; color: white; padding: 12px; text-align: left; width: 50px;">#</th>
                        <th style="background: #2196F3; color: white; padding: 12px; text-align: left;">Subject</th>
                        <th style="background: #2196F3; color: white; padding: 12px; text-align: center; width: 80px;">CA<br>(20)</th>
                        <th style="background: #2196F3; color: white; padding: 12px; text-align: center; width: 80px;">Midterm<br>(20)</th>
                        <th style="background: #2196F3; color: white; padding: 12px; text-align: center; width: 80px;">Exam<br>(60)</th>
                        <th style="background: #2196F3; color: white; padding: 12px; text-align: center; width: 80px;">Total<br>(100)</th>
                        <th style="background: #2196F3; color: white; padding: 12px; text-align: center; width: 80px;">Grade</th>
                        <th style="background: #2196F3; color: white; padding: 12px; text-align: center; width: 80px;">Position</th>
                        <th style="background: #2196F3; color: white; padding: 12px; text-align: left; width: 100px;">Remark</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($results) > 0): ?>
                        <?php $count = 1; ?>
                        <?php foreach ($results as $result): ?>
                            <?php
                            // Calculate total if not in database or is 0
                            $display_total = $result['total_score'];
                            if ($display_total == 0 || $display_total === null) {
                                $display_total = calculate_total_score(
                                    $result['ca_score'] ?? 0,
                                    $result['midterm_score'] ?? 0,
                                    $result['exam_score'] ?? 0
                                );
                            }
                            
                            // Calculate grade and remark if not in database
                            $display_grade = $result['grade'];
                            $display_remark = $result['remark'];
                            if (empty($display_grade) || empty($display_remark)) {
                                $grade_info = calculate_grade_new($display_total);
                                $display_grade = $display_grade ?: $grade_info['grade'];
                                $display_remark = $display_remark ?: $grade_info['remark'];
                            }
                            ?>
                            <tr style="<?php echo $count % 2 == 0 ? 'background: #f9f9f9;' : ''; ?>">
                                <td style="padding: 10px 12px; border: 1px solid #ddd; text-align: center;"><?php echo $count++; ?></td>
                                <td style="padding: 10px 12px; border: 1px solid #ddd;"><strong><?php echo $result['subject_name']; ?></strong></td>
                                <td style="padding: 10px 12px; border: 1px solid #ddd; text-align: center;"><?php echo number_format($result['ca_score'] ?? 0, 2); ?></td>
                                <td style="padding: 10px 12px; border: 1px solid #ddd; text-align: center;"><?php echo number_format($result['midterm_score'] ?? 0, 2); ?></td>
                                <td style="padding: 10px 12px; border: 1px solid #ddd; text-align: center;"><?php echo number_format($result['exam_score'] ?? 0, 2); ?></td>
                                <td style="padding: 10px 12px; border: 1px solid #ddd; text-align: center;"><strong><?php echo number_format($display_total, 2); ?></strong></td>
                                <td style="padding: 10px 12px; border: 1px solid #ddd; text-align: center;">
                                    <strong><?php echo $display_grade; ?></strong>
                                </td>
                                <td style="padding: 10px 12px; border: 1px solid #ddd; text-align: center;"><?php echo $result['position'] ?? '-'; ?></td>
                                <td style="padding: 10px 12px; border: 1px solid #ddd;"><?php echo $display_remark; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" style="padding: 40px; text-align: center; border: 1px solid #ddd;">
                                No results available for this student.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <!-- Summary -->
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 15px;">
                <div style="padding: 12px; border: 2px solid #2196F3; border-radius: 5px; text-align: center;">
                    <h3 style="font-size: 11px; color: #666; margin-bottom: 5px;">Total Subjects</h3>
                    <div style="font-size: 20px; font-weight: bold; color: #2196F3;"><?php echo $total_subjects; ?></div>
                </div>
                <div style="padding: 12px; border: 2px solid #2196F3; border-radius: 5px; text-align: center;">
                    <h3 style="font-size: 11px; color: #666; margin-bottom: 5px;">Overall Average</h3>
                    <div style="font-size: 20px; font-weight: bold; color: #2196F3;"><?php echo $overall_average; ?>%</div>
                </div>
                <div style="padding: 12px; border: 2px solid #2196F3; border-radius: 5px; text-align: center;">
                    <h3 style="font-size: 11px; color: #666; margin-bottom: 5px;">Overall Grade</h3>
                    <div style="font-size: 20px; font-weight: bold; color: #2196F3;"><?php echo $overall_grade; ?></div>
                </div>
            </div>
            
            <div style="text-align: center; padding: 12px; background: <?php echo $overall_average >= 50 ? '#E8F5E9' : '#FFEBEE'; ?>; border-radius: 5px; margin-bottom: 20px;">
                <h3 style="margin: 0; font-size: 18px; color: <?php echo $overall_average >= 50 ? '#4CAF50' : '#F44336'; ?>;">
                    <?php echo $overall_remark; ?>
                </h3>
            </div>
            
            <!-- Signatures -->
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 30px; margin-top: 30px; padding-top: 15px; border-top: 2px solid #ddd;">
                <div style="text-align: center;">
                    <div style="border-top: 2px solid #333; margin-top: 40px; padding-top: 8px; font-weight: bold; font-size: 11px;">Class Teacher</div>
                </div>
                <div style="text-align: center;">
                    <div style="border-top: 2px solid #333; margin-top: 40px; padding-top: 8px; font-weight: bold; font-size: 11px;">Principal</div>
                </div>
            </div>
            
            <!-- Footer -->
            <div style="text-align: center; margin-top: 15px; padding-top: 10px; border-top: 2px solid #ddd; color: #666; font-size: 9px;">
                <p>Generated on <?php echo date('F j, Y'); ?></p>
                <p style="margin-top: 3px;">Official result sheet from <?php echo $class['school_name']; ?></p>
            </div>
        </div>
        
        <?php if ($index < count($students) - 1): ?>
            <div class="page-break"></div>
        <?php endif; ?>
        
    <?php endforeach; ?>
    
</body>
</html>
