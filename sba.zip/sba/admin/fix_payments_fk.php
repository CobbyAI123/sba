<?php
// Admin fix script - Fix payments foreign key constraint
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['super_admin']);
$db = Database::getInstance()->getConnection();

try {
    // Drop the incorrect foreign key
    $db->exec("ALTER TABLE `payments` DROP FOREIGN KEY `payments_ibfk_3`");
    
    // Add the correct foreign key
    $db->exec("ALTER TABLE `payments` ADD CONSTRAINT `payments_ibfk_3` 
              FOREIGN KEY (`term_id`) REFERENCES `terms`(`term_id`) ON DELETE CASCADE");
    
    echo "<div style='padding: 20px; background: #d4edda; color: #155724; border-radius: 5px; margin: 20px;'>";
    echo "<h3>✓ Foreign Key Fixed Successfully!</h3>";
    echo "<p>The payments table foreign key constraint has been corrected.</p>";
    echo "<p>term_id now correctly references the <strong>terms</strong> table instead of <strong>terms_backup</strong>.</p>";
    echo "<p><a href='" . APP_URL . "/admin/dashboard.php' style='color: #155724; text-decoration: underline;'>Return to Dashboard</a></p>";
    echo "</div>";
} catch (PDOException $e) {
    echo "<div style='padding: 20px; background: #f8d7da; color: #721c24; border-radius: 5px; margin: 20px;'>";
    echo "<h3>✗ Error</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><a href='" . APP_URL . "/admin/dashboard.php' style='color: #721c24; text-decoration: underline;'>Return to Dashboard</a></p>";
    echo "</div>";
}
?>
