<?php
require_once '../config.php';

// Check permission - only admin and proprietor
$current_user = check_permission(['admin', 'proprietor']);

// Get backup file from GET parameter
if (!isset($_GET['file']) || empty($_GET['file'])) {
    set_message('error', 'No backup file specified');
    redirect(APP_URL . '/admin/database-backup.php');
    exit;
}

$backup_file = $_GET['file'];
$backup_dir = BASE_PATH . '/backups/';
$filepath = $backup_dir . $backup_file;

// Security check: prevent directory traversal
if (strpos($backup_file, '..') !== false || strpos($backup_file, '/') !== false || strpos($backup_file, '\\') !== false) {
    set_message('error', 'Invalid file name');
    redirect(APP_URL . '/admin/database-backup.php');
    exit;
}

// Check if file exists
if (!file_exists($filepath)) {
    set_message('error', 'Backup file not found');
    redirect(APP_URL . '/admin/database-backup.php');
    exit;
}

// Log download activity
log_activity($current_user['user_id'], "Downloaded backup: $backup_file", 'backups', null);

// Set headers for file download
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $backup_file . '"');
header('Content-Length: ' . filesize($filepath));
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Output file
readfile($filepath);
exit;
