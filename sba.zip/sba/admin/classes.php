<?php
// admin/classes.php - Class Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Class Management';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        // Verify CSRF token
        if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
            set_message('error', 'Invalid request. Please try again.');
            redirect(APP_URL . '/admin/classes.php');
            exit;
        }
        if ($_POST['action'] == 'add') {
            $class_name = sanitize_input($_POST['class_name']);
            $capacity = sanitize_input($_POST['capacity']);
            $class_number = isset($_POST['class_number']) ? sanitize_input($_POST['class_number']) : null;
            
            try {
                // Check if class_number column exists
                $column_check = $db->query("SHOW COLUMNS FROM classes LIKE 'class_number'");
                $has_class_number = $column_check->rowCount() > 0;
                
                if ($has_class_number && $class_number) {
                    $stmt = $db->prepare("
                        INSERT INTO classes (school_id, class_name, capacity, class_number)
                        VALUES (?, ?, ?, ?)
                    ");
                    $stmt->execute([$school_id, $class_name, $capacity, $class_number]);
                } else {
                    $stmt = $db->prepare("
                        INSERT INTO classes (school_id, class_name, capacity)
                        VALUES (?, ?, ?)
                    ");
                    $stmt->execute([$school_id, $class_name, $capacity]);
                }
                
                $class_id = $db->lastInsertId();
                log_activity($current_user['user_id'], "Added new class: $class_name", 'classes', $class_id);
                
                set_message('success', 'Class added successfully!');
                redirect(APP_URL . '/admin/classes.php');
            } catch (PDOException $e) {
                set_message('error', 'Error adding class: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'edit') {
            $class_id = sanitize_input($_POST['class_id']);
            $class_name = sanitize_input($_POST['class_name']);
            $capacity = sanitize_input($_POST['capacity']);
            $class_number = isset($_POST['class_number']) ? sanitize_input($_POST['class_number']) : null;
            
            try {
                // Check if class_number column exists
                $column_check = $db->query("SHOW COLUMNS FROM classes LIKE 'class_number'");
                $has_class_number = $column_check->rowCount() > 0;
                
                if ($has_class_number && $class_number) {
                    $stmt = $db->prepare("
                        UPDATE classes 
                        SET class_name = ?, capacity = ?, class_number = ?
                        WHERE class_id = ? AND school_id = ?
                    ");
                    $stmt->execute([$class_name, $capacity, $class_number, $class_id, $school_id]);
                } else {
                    $stmt = $db->prepare("
                        UPDATE classes 
                        SET class_name = ?, capacity = ?
                        WHERE class_id = ? AND school_id = ?
                    ");
                    $stmt->execute([$class_name, $capacity, $class_id, $school_id]);
                }
                
                log_activity($current_user['user_id'], "Updated class: $class_name", 'classes', $class_id);
                
                set_message('success', 'Class updated successfully!');
                redirect(APP_URL . '/admin/classes.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating class: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            $class_id = sanitize_input($_POST['class_id']);
            
            try {
                // Check if class has students
                $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM students WHERE class_id = ?");
                $check_stmt->execute([$class_id]);
                $student_count = $check_stmt->fetch()['count'];
                
                if ($student_count > 0) {
                    set_message('error', "Cannot delete class. It has $student_count students assigned.");
                    redirect(APP_URL . '/admin/classes.php');
                    exit;
                }
                
                $stmt = $db->prepare("DELETE FROM classes WHERE class_id = ? AND school_id = ?");
                $stmt->execute([$class_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted class ID: $class_id", 'classes', $class_id);
                
                set_message('success', 'Class deleted successfully!');
                redirect(APP_URL . '/admin/classes.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting class: ' . $e->getMessage());
            }
        }
    }
}

// Get all classes with student count
$classes = [];
try {
    $stmt = $db->prepare("
        SELECT c.*,
               COUNT(DISTINCT s.student_id) as student_count
        FROM classes c
        LEFT JOIN students s ON c.class_id = s.class_id AND s.status = 'active'
        WHERE c.school_id = ?
        GROUP BY c.class_id
        ORDER BY COALESCE(c.class_number, c.class_id) ASC
    ");
    $stmt->execute([$school_id]);
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    // Fallback if class_number doesn't exist
    $stmt = $db->prepare("
        SELECT c.*,
               COUNT(DISTINCT s.student_id) as student_count
        FROM classes c
        LEFT JOIN students s ON c.class_id = s.class_id AND s.status = 'active'
        WHERE c.school_id = ?
        GROUP BY c.class_id
        ORDER BY c.class_id ASC
    ");
    $stmt->execute([$school_id]);
    $classes = $stmt->fetchAll();
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .class-action-btn {
        padding: 8px 10px !important;
        font-size: 12px !important;
        white-space: nowrap;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        min-width: 0;
    }
    
    .class-action-btn i {
        font-size: 11px;
        flex-shrink: 0;
    }
    
    .class-action-btn span {
        overflow: hidden;
        text-overflow: ellipsis;
    }
    
    @media (max-width: 768px) {
        .class-action-btn {
            font-size: 11px !important;
            padding: 6px 8px !important;
        }
        
        .class-action-btn i {
            font-size: 10px;
        }
    }
    
    @media (max-width: 400px) {
        .class-action-btn span {
            display: none;
        }
        
        .class-action-btn {
            padding: 10px !important;
        }
    }
    </style>
    
    <!-- Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
            <button class="btn btn-primary" onclick="showAddModal()">
                <i class="fas fa-plus"></i> Add Class
            </button>
        </div>
    </div>
    
    <!-- Classes Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
        <?php foreach ($classes as $class): ?>
            <div class="card">
                <div style="padding: 25px;">
                    <div style="display: flex; justify-content: between; align-items: start; margin-bottom: 15px;">
                        <div style="flex: 1;">
                            <h3 style="font-size: 24px; margin-bottom: 5px;"><?php echo $class['class_name']; ?></h3>
                        </div>
                    </div>
                    
                    <div style="background: var(--bg-secondary); padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                            <span style="color: var(--text-secondary);">
                                <i class="fas fa-users"></i> Students
                            </span>
                            <strong><?php echo $class['student_count']; ?> / <?php echo $class['capacity']; ?></strong>
                        </div>
                        <div style="background: var(--border-color); height: 8px; border-radius: 4px; overflow: hidden;">
                            <?php 
                            $percentage = $class['capacity'] > 0 ? ($class['student_count'] / $class['capacity']) * 100 : 0;
                            $color = $percentage >= 90 ? 'var(--danger-red)' : ($percentage >= 70 ? 'var(--warning-orange)' : 'var(--success-green)');
                            ?>
                            <div style="width: <?php echo min($percentage, 100); ?>%; height: 100%; background: <?php echo $color; ?>; transition: width 0.3s ease;"></div>
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px;">
                        <a href="<?php echo APP_URL; ?>/admin/view-class-students.php?class_id=<?php echo $class['class_id']; ?>" 
                           class="btn btn-primary btn-sm class-action-btn" 
                           style="text-decoration: none;">
                            <i class="fas fa-users"></i>
                            <span>View</span>
                        </a>
                        <button class="btn btn-info btn-sm class-action-btn" 
                                onclick='editClass(<?php echo json_encode($class); ?>)'>
                            <i class="fas fa-edit"></i>
                            <span>Edit</span>
                        </button>
                        <button class="btn btn-danger btn-sm class-action-btn" 
                                onclick="deleteClass(<?php echo $class['class_id']; ?>, '<?php echo addslashes($class['class_name']); ?>')">
                            <i class="fas fa-trash"></i>
                            <span>Delete</span>
                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        
        <?php if (count($classes) == 0): ?>
            <div class="card" style="grid-column: 1 / -1;">
                <div style="padding: 60px; text-align: center;">
                    <i class="fas fa-book" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 20px;"></i>
                    <h3 style="margin-bottom: 10px;">No Classes Yet</h3>
                    <p style="color: var(--text-secondary); margin-bottom: 20px;">Get started by adding your first class</p>
                    <button class="btn btn-primary" onclick="showAddModal()">
                        <i class="fas fa-plus"></i> Add Your First Class
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Add/Edit Class Modal -->
    <div id="classModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Add Class</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="classForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="class_id" id="classId">
                
                <div class="form-group">
                    <label for="class_name">Class Name *</label>
                    <input type="text" name="class_name" id="class_name" placeholder="e.g., Class 1, Grade 5, JSS 1" required>
                </div>
                
                <div class="form-group">
                    <label for="class_number">Class Number (for sorting)</label>
                    <input type="number" name="class_number" id="class_number" placeholder="e.g., 1, 2, 3" min="1" max="50">
                    <small style="color: var(--text-secondary); font-size: 12px;">Used to sort classes in order (1-50) - Optional</small>
                </div>
                
                <div class="form-group">
                    <label for="capacity">Class Capacity *</label>
                    <input type="number" name="capacity" id="capacity" placeholder="e.g., 40" min="1" max="200" required>
                    <small style="color: var(--text-secondary); font-size: 12px;">Maximum number of students</small>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Class
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showAddModal() {
        document.getElementById('classModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Add Class';
        document.getElementById('formAction').value = 'add';
        document.getElementById('classForm').reset();
        document.getElementById('classId').value = '';
    }
    
    function editClass(classData) {
        document.getElementById('classModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Edit Class';
        document.getElementById('formAction').value = 'edit';
        document.getElementById('classId').value = classData.class_id;
        document.getElementById('class_name').value = classData.class_name;
        document.getElementById('capacity').value = classData.capacity;
        document.getElementById('class_number').value = classData.class_number || '';
    }
    
    function closeModal() {
        document.getElementById('classModal').style.display = 'none';
    }
    
    function deleteClass(classId, className) {
        if (confirm(`Are you sure you want to delete ${className}? This action cannot be undone.`)) {
            const form = document.createElement('form');
            form.method = 'POST';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete';
            form.appendChild(actionInput);
            
            const classIdInput = document.createElement('input');
            classIdInput.type = 'hidden';
            classIdInput.name = 'class_id';
            classIdInput.value = classId;
            form.appendChild(classIdInput);
            
            const csrfInput = document.createElement('input');
            csrfInput.type = 'hidden';
            csrfInput.name = 'csrf_token';
            csrfInput.value = '<?php echo generate_csrf_token(); ?>';
            form.appendChild(csrfInput);
            
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Close modal on outside click
    document.getElementById('classModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
