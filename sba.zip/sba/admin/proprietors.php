<?php
// admin/proprietors.php - Proprietor Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/default-passwords.php';

$page_title = 'Manage Proprietors';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $email = sanitize_input($_POST['email']);
                $first_name = sanitize_input($_POST['first_name']);
                $last_name = sanitize_input($_POST['last_name']);
                $phone = sanitize_input($_POST['phone'] ?? '');
                
                try {
                    // Check if email already exists
                    $stmt = $db->prepare("SELECT user_id FROM users WHERE email = ?");
                    $stmt->execute([$email]);
                    if ($stmt->fetch()) {
                        throw new Exception('Email already exists');
                    }
                    
                    // Generate username from email
                    $username = explode('@', $email)[0];
                    // Default password
                    $password = 'proprietor123';
                    
                    // Insert into users table (no address column in users table)
                    $password_hash = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $db->prepare("
                        INSERT INTO users (username, email, password_hash, first_name, last_name, phone, role, school_id, status, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, 'proprietor', ?, 'active', NOW())
                    ");
                    $stmt->execute([$username, $email, $password_hash, $first_name, $last_name, $phone, $school_id]);
                    $user_id = $db->lastInsertId();
                    
                    log_activity($current_user['user_id'], "Added new proprietor: $first_name $last_name", 'users', $user_id);
                    set_message('success', "Proprietor added successfully! Login: $email | Password: $password");
                } catch (Exception $e) {
                    set_message('error', 'Error adding proprietor: ' . $e->getMessage());
                }
                redirect(APP_URL . '/admin/proprietors.php');
                break;
                
            case 'delete':
                $user_id = (int)$_POST['user_id'];
                try {
                    $stmt = $db->prepare("DELETE FROM users WHERE user_id = ? AND role = 'proprietor' AND school_id = ?");
                    $stmt->execute([$user_id, $school_id]);
                    
                    log_activity($current_user['user_id'], "Deleted proprietor ID: $user_id", 'users', $user_id);
                    set_message('success', 'Proprietor deleted successfully!');
                } catch (PDOException $e) {
                    set_message('error', 'Error deleting proprietor: ' . $e->getMessage());
                }
                redirect(APP_URL . '/admin/proprietors.php');
                break;
                
            case 'toggle_status':
                $user_id = (int)$_POST['user_id'];
                $new_status = $_POST['new_status'];
                try {
                    $stmt = $db->prepare("UPDATE users SET status = ? WHERE user_id = ? AND role = 'proprietor' AND school_id = ?");
                    $stmt->execute([$new_status, $user_id, $school_id]);
                    
                    log_activity($current_user['user_id'], "Changed proprietor status to $new_status for ID: $user_id", 'users', $user_id);
                    set_message('success', 'Status updated successfully!');
                } catch (PDOException $e) {
                    set_message('error', 'Error updating status: ' . $e->getMessage());
                }
                redirect(APP_URL . '/admin/proprietors.php');
                break;
        }
    }
}

// Get all proprietors
$stmt = $db->prepare("
    SELECT * FROM users 
    WHERE role = 'proprietor' AND school_id = ?
    ORDER BY created_at DESC
");
$stmt->execute([$school_id]);
$proprietors = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fas fa-crown"></i>  Manage Proprietors</h1>
    </div>

    <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div style="display: flex; gap: 10px;">
            <button onclick="showAddModal()" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add New Proprietor
            </button>
            <div class="btn-group" style="display: inline-flex; border: 2px solid var(--border-color); border-radius: 8px; overflow: hidden;">
                <button id="btnListView" onclick="setView('list')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--primary-blue); color: white;">
                    <i class="fas fa-list"></i> List
                </button>
                <button id="btnGridView" onclick="setView('grid')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--bg-secondary); color: var(--text-primary);">
                    <i class="fas fa-th"></i> Grid
                </button>
            </div>
        </div>
        <div style="font-weight: 600; color: var(--text-secondary);">
            Total: <?php echo count($proprietors); ?>
        </div>
    </div>
    
    <?php if (count($proprietors) > 0): ?>
        <div id="proprietorsTable" class="card">
            <div class="card-header">
                <h3><i class="fas fa-users"></i> Proprietors (<?php echo count($proprietors); ?>)</h3>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Login Credentials</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $count = 1; ?>
                        <?php foreach ($proprietors as $proprietor): ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($proprietor['first_name'] . ' ' . $proprietor['last_name']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($proprietor['email']); ?></td>
                                <td><?php echo htmlspecialchars($proprietor['phone'] ?? '-'); ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <div id="cred-hidden-<?php echo $proprietor['user_id']; ?>" style="font-family: monospace; font-size: 12px;">••••••••</div>
                                        <div id="cred-shown-<?php echo $proprietor['user_id']; ?>" style="display: none; font-family: monospace; font-size: 11px; line-height: 1.4;">
                                            <strong>User:</strong> <?php echo htmlspecialchars($proprietor['username'] ?? explode('@', $proprietor['email'])[0]); ?><br>
                                            <strong>Pass:</strong> proprietor123
                                        </div>
                                        <button onclick="toggleCredentials(<?php echo $proprietor['user_id']; ?>); return false;" type="button" class="btn btn-sm" style="padding: 4px 8px; background: var(--primary-blue); color: white; border: none; border-radius: 4px; cursor: pointer;">
                                            <i class="fas fa-eye" id="eye-<?php echo $proprietor['user_id']; ?>"></i>
                                        </button>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($proprietor['status'] == 'active'): ?>
                                        <span class="badge badge-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($proprietor['created_at'])); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="<?php echo APP_URL; ?>/admin/edit-proprietor.php?id=<?php echo $proprietor['user_id']; ?>" 
                                           class="btn btn-sm btn-info" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Toggle status for this proprietor?');">
                                            <input type="hidden" name="action" value="toggle_status">
                                            <input type="hidden" name="user_id" value="<?php echo $proprietor['user_id']; ?>">
                                            <input type="hidden" name="new_status" value="<?php echo $proprietor['status'] == 'active' ? 'inactive' : 'active'; ?>">
                                            <button type="submit" class="btn btn-sm btn-warning" title="Toggle Status">
                                                <i class="fas fa-toggle-<?php echo $proprietor['status'] == 'active' ? 'on' : 'off'; ?>"></i>
                                            </button>
                                        </form>
                                        
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this proprietor?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="user_id" value="<?php echo $proprietor['user_id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    <!-- Grid View -->
    <div id="proprietorsGrid" style="display: none; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
        <?php foreach ($proprietors as $proprietor): ?>
            <div class="card" style="padding: 20px;">
                <div style="text-align: center; margin-bottom: 15px;">
                    <div style="width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #FFD700, #FFA500); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 28px; margin: 0 auto;">
                        <?php echo strtoupper(substr($proprietor['first_name'], 0, 1) . substr($proprietor['last_name'], 0, 1)); ?>
                    </div>
                </div>
                <h4 style="text-align: center; margin: 0 0 5px 0;"><?php echo htmlspecialchars($proprietor['first_name'] . ' ' . $proprietor['last_name']); ?></h4>
                <p style="text-align: center; color: var(--text-secondary); font-size: 12px; margin: 0 0 15px 0;"><i class="fas fa-crown"></i> Proprietor</p>
                <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-bottom: 12px; font-size: 13px;">
                    <div style="margin-bottom: 8px;"><i class="fas fa-envelope" style="width: 20px;"></i> <strong>Email:</strong> <span style="font-size: 11px;"><?php echo htmlspecialchars($proprietor['email']); ?></span></div>
                    <div><i class="fas fa-phone" style="width: 20px;"></i> <strong>Phone:</strong> <?php echo htmlspecialchars($proprietor['phone'] ?? 'N/A'); ?></div>
                </div>
                <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-bottom: 12px; font-size: 12px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <strong><i class="fas fa-key"></i> Credentials</strong>
                        <button onclick="toggleCredentials(<?php echo $proprietor['user_id']; ?>); return false;" type="button" class="btn btn-sm" style="padding: 4px 8px; background: var(--primary-blue); color: white; border: none; border-radius: 4px;"><i class="fas fa-eye" id="eye-<?php echo $proprietor['user_id']; ?>"></i></button>
                    </div>
                    <div id="cred-hidden-<?php echo $proprietor['user_id']; ?>" style="font-family: monospace;">••••••••</div>
                    <div id="cred-shown-<?php echo $proprietor['user_id']; ?>" style="display: none; font-family: monospace; line-height: 1.6;">
                        <strong>User:</strong> <?php echo htmlspecialchars($proprietor['username'] ?? explode('@', $proprietor['email'])[0]); ?><br>
                        <strong>Pass:</strong> proprietor123
                    </div>
                </div>
                <div style="text-align: center; margin-bottom: 12px;"><span class="badge badge-<?php echo $proprietor['status'] == 'active' ? 'success' : 'danger'; ?>"><?php echo ucfirst($proprietor['status']); ?></span></div>
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px;">
                    <a href="<?php echo APP_URL; ?>/admin/edit-proprietor.php?id=<?php echo $proprietor['user_id']; ?>" class="btn btn-sm btn-info"><i class="fas fa-edit"></i></a>
                    <form method="POST" style="display: inline;" onsubmit="return confirm('Toggle?');"><input type="hidden" name="action" value="toggle_status"><input type="hidden" name="user_id" value="<?php echo $proprietor['user_id']; ?>"><input type="hidden" name="new_status" value="<?php echo $proprietor['status'] == 'active' ? 'inactive' : 'active'; ?>"><button type="submit" class="btn btn-sm btn-warning" style="width: 100%;"><i class="fas fa-toggle-<?php echo $proprietor['status'] == 'active' ? 'on' : 'off'; ?>"></i></button></form>
                    <form method="POST" style="display: inline;" onsubmit="return confirm('Delete?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="user_id" value="<?php echo $proprietor['user_id']; ?>"><button type="submit" class="btn btn-sm btn-danger" style="width: 100%;"><i class="fas fa-trash"></i></button></form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <?php else: ?>
        <div class="card">
            <div style="text-align: center; padding: 60px;">
                <i class="fas fa-crown" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                <h3>No Proprietors Found</h3>
                <p style="color: var(--text-secondary); margin-bottom: 30px;">You haven't added any proprietors yet.</p>
                <button onclick="showAddModal()" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add First Proprietor
                </button>
            </div>
        </div>
    <?php endif; ?>
    
    <style>
    .action-buttons {
        display: flex;
        gap: 5px;
        justify-content: center;
    }
    
    .badge {
        padding: 5px 10px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
    }
    
    .badge-success {
        background: #4CAF50;
        color: white;
    }
    
    .badge-danger {
        background: #f44336;
        color: white;
    }
    
    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
    }
    
    .form-control {
        width: 100%;
        padding: 10px 15px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
    }
    
    @media (max-width: 768px) {
        .form-grid {
            grid-template-columns: 1fr;
        }
    }
    </style>
    
    <!-- Add Proprietor Modal -->
    <div id="proprietorModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 700px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2><i class="fas fa-crown"></i> Add Proprietor</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <!-- Personal Information -->
                <div class="form-grid">
                    <div class="form-group">
                        <label for="first_name">First Name <span style="color: red;">*</span></label>
                        <input type="text" id="first_name" name="first_name" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name <span style="color: red;">*</span></label>
                        <input type="text" id="last_name" name="last_name" class="form-control" required>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="email">Email Address <span style="color: red;">*</span></label>
                        <input type="email" id="email" name="email" class="form-control" required>
                        <small style="color: #6B7280;">Will be used as login username</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="phone" class="form-control">
                    </div>
                </div>
                
                <!-- Info Alert -->
                <div class="alert alert-info" style="margin-top: 20px;">
                    <i class="fas fa-info-circle"></i>
                    <strong>Note:</strong> Default password is <strong>proprietor123</strong>. User should change it after first login.
                </div>
                
                <!-- Submit Buttons -->
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 30px;">
                    <button type="button" onclick="closeModal()" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Add Proprietor
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function setView(view) {
        const table = document.getElementById('proprietorsTable');
        const grid = document.getElementById('proprietorsGrid');
        const btnList = document.getElementById('btnListView');
        const btnGrid = document.getElementById('btnGridView');
        if (view === 'grid') {
            if (table) table.style.display = 'none';
            if (grid) grid.style.display = 'grid';
            btnList.style.background = 'var(--bg-secondary)';
            btnList.style.color = 'var(--text-primary)';
            btnGrid.style.background = 'var(--primary-blue)';
            btnGrid.style.color = 'white';
            localStorage.setItem('proprietorView', 'grid');
        } else {
            if (table) table.style.display = 'block';
            if (grid) grid.style.display = 'none';
            btnList.style.background = 'var(--primary-blue)';
            btnList.style.color = 'white';
            btnGrid.style.background = 'var(--bg-secondary)';
            btnGrid.style.color = 'var(--text-primary)';
            localStorage.setItem('proprietorView', 'list');
        }
    }
    function toggleCredentials(userId) {
        const hidden = document.getElementById('cred-hidden-' + userId);
        const shown = document.getElementById('cred-shown-' + userId);
        const eyes = document.querySelectorAll('#eye-' + userId);
        if (hidden.style.display === 'none') {
            hidden.style.display = 'block';
            shown.style.display = 'none';
            eyes.forEach(eye => eye.className = 'fas fa-eye');
        } else {
            hidden.style.display = 'none';
            shown.style.display = 'block';
            eyes.forEach(eye => eye.className = 'fas fa-eye-slash');
        }
    }
    window.addEventListener('DOMContentLoaded', function() {
        const savedView = localStorage.getItem('proprietorView') || 'list';
        setView(savedView);
    });
    function showAddModal() {
        document.getElementById('proprietorModal').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('proprietorModal').style.display = 'none';
    }
    
    // Close modal on outside click
    document.getElementById('proprietorModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
