<!-- Add Proprietor Modal -->
<div id="addProprietorModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
    <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2><i class="fas fa-crown"></i> Add Proprietor</h2>
            <button onclick="closeAddProprietorModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <form method="POST">
            <input type="hidden" name="action" value="add_proprietor">
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label>First Name *</label>
                    <input type="text" name="first_name" required>
                </div>
                
                <div class="form-group">
                    <label>Last Name *</label>
                    <input type="text" name="last_name" required>
                </div>
                
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label>Phone</label>
                    <input type="tel" name="phone">
                </div>
                
                <div class="form-group" style="grid-column: 1 / -1;">
                    <div style="background: #e3f2fd; padding: 12px; border-radius: 8px; border-left: 4px solid #2196f3;">
                        <p style="margin: 0; font-size: 14px; color: #1565c0;">
                            <i class="fas fa-info-circle"></i> <strong>Auto-Generated:</strong> Username and password will be created automatically. 
                            Default password: <strong>proprietor123</strong>
                        </p>
                    </div>
                </div>
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button type="button" class="btn btn-secondary" onclick="closeAddProprietorModal()">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Add Proprietor</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Proprietor Modal -->
<div id="editProprietorModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
    <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2><i class="fas fa-edit"></i> Edit Proprietor</h2>
            <button onclick="closeEditProprietorModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <form method="POST" id="editProprietorForm">
            <input type="hidden" name="action" value="edit_proprietor">
            <input type="hidden" name="user_id" id="edit_user_id">
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label>First Name *</label>
                    <input type="text" name="first_name" id="edit_first_name" required>
                </div>
                
                <div class="form-group">
                    <label>Last Name *</label>
                    <input type="text" name="last_name" id="edit_last_name" required>
                </div>
                
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" id="edit_email" required>
                </div>
                
                <div class="form-group">
                    <label>Phone</label>
                    <input type="tel" name="phone" id="edit_phone">
                </div>
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button type="button" class="btn btn-secondary" onclick="closeEditProprietorModal()">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Proprietor</button>
            </div>
        </form>
    </div>
</div>

<!-- Reset Password Modal -->
<div id="resetPasswordModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
    <div style="max-width: 500px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2><i class="fas fa-key"></i> Reset Password</h2>
            <button onclick="closeResetPasswordModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <form method="POST">
            <input type="hidden" name="action" value="reset_password">
            <input type="hidden" name="user_id" id="reset_user_id">
            
            <div class="form-group">
                <label>User</label>
                <input type="text" id="reset_user_name" readonly style="background: #f5f5f5;">
            </div>
            
            <div class="form-group">
                <label>New Password *</label>
                <input type="password" name="new_password" required minlength="6" placeholder="Minimum 6 characters">
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button type="button" class="btn btn-secondary" onclick="closeResetPasswordModal()">Cancel</button>
                <button type="submit" class="btn btn-warning"><i class="fas fa-key"></i> Reset Password</button>
            </div>
        </form>
    </div>
</div>

<!-- Reset All Passwords Modal -->
<div id="resetAllModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
    <div style="max-width: 500px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2><i class="fas fa-key"></i> Reset All Passwords</h2>
            <button onclick="closeResetAllModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div class="alert alert-warning" style="margin-bottom: 20px;">
            <i class="fas fa-exclamation-triangle"></i>
            <strong>Warning!</strong> This will reset passwords for ALL users in your school (except super admin).
        </div>
        
        <form method="POST" onsubmit="return confirm('Are you sure you want to reset ALL user passwords? This action cannot be undone!');">
            <input type="hidden" name="action" value="reset_all_passwords">
            
            <div class="form-group">
                <label>Default Password *</label>
                <input type="password" name="default_password" required minlength="6" placeholder="This will be the new password for all users">
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button type="button" class="btn btn-secondary" onclick="closeResetAllModal()">Cancel</button>
                <button type="submit" class="btn btn-danger"><i class="fas fa-exclamation-triangle"></i> Reset All Passwords</button>
            </div>
        </form>
    </div>
</div>

<script>
// Add Proprietor Modal
function openAddProprietorModal() {
    document.getElementById('addProprietorModal').style.display = 'block';
}
function closeAddProprietorModal() {
    document.getElementById('addProprietorModal').style.display = 'none';
}

// Edit Proprietor Modal
function openEditProprietorModal(user) {
    document.getElementById('edit_user_id').value = user.user_id;
    document.getElementById('edit_first_name').value = user.first_name;
    document.getElementById('edit_last_name').value = user.last_name;
    document.getElementById('edit_email').value = user.email;
    document.getElementById('edit_phone').value = user.phone || '';
    document.getElementById('editProprietorModal').style.display = 'block';
}
function closeEditProprietorModal() {
    document.getElementById('editProprietorModal').style.display = 'none';
}

// Reset Password Modal
function openResetPasswordModal(userId, userName) {
    document.getElementById('reset_user_id').value = userId;
    document.getElementById('reset_user_name').value = userName;
    document.getElementById('resetPasswordModal').style.display = 'block';
}
function closeResetPasswordModal() {
    document.getElementById('resetPasswordModal').style.display = 'none';
}

// Reset All Modal
function openResetAllModal() {
    document.getElementById('resetAllModal').style.display = 'block';
}
function closeResetAllModal() {
    document.getElementById('resetAllModal').style.display = 'none';
}

// Close modals on outside click
window.onclick = function(e) {
    if (e.target.id === 'addProprietorModal') e.target.style.display = 'none';
    if (e.target.id === 'editProprietorModal') e.target.style.display = 'none';
    if (e.target.id === 'resetPasswordModal') e.target.style.display = 'none';
    if (e.target.id === 'resetAllModal') e.target.style.display = 'none';
}
</script>
