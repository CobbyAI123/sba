<?php
// admin/view-class-students.php - View Students in a Class
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Class Students';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;

if ($class_id == 0) {
    set_message('error', 'Invalid class selected.');
    redirect(APP_URL . '/admin/classes.php');
}

// Get class details
$stmt = $db->prepare("SELECT * FROM classes WHERE class_id = ? AND school_id = ?");
$stmt->execute([$class_id, $school_id]);
$class_info = $stmt->fetch();

if (!$class_info) {
    set_message('error', 'Class not found.');
    redirect(APP_URL . '/admin/classes.php');
}

// Get students in this class
$stmt = $db->prepare("
    SELECT 
        s.*,
        CONCAT(u.first_name, ' ', u.last_name) as full_name,
        u.status as account_status,
        u.email
    FROM students s
    INNER JOIN users u ON s.user_id = u.user_id
    WHERE s.class_id = ? AND s.school_id = ?
    ORDER BY u.first_name, u.last_name
");
$stmt->execute([$class_id, $school_id]);
$students = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .student-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 20px;
        margin-top: 20px;
    }
    
    .student-card {
        background: var(--card-bg);
        border-radius: 15px;
        padding: 20px;
        box-shadow: var(--shadow);
        transition: all 0.3s ease;
        text-align: center;
    }
    
    .student-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-hover);
    }
    
    .student-avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, #2196F3, #9C27B0);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 32px;
        font-weight: 700;
        margin: 0 auto 15px;
    }
    
    .student-name {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    .student-admission {
        color: var(--text-secondary);
        font-size: 13px;
        margin-bottom: 15px;
    }
    
    .student-info {
        padding-top: 15px;
        border-top: 1px solid var(--border-color);
        text-align: left;
    }
    
    .info-row {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 10px;
        font-size: 14px;
    }
    
    .info-row i {
        color: var(--primary-blue);
        width: 16px;
    }
    
    .status-badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .status-active {
        background: rgba(76, 175, 80, 0.1);
        color: #4CAF50;
    }
    
    .status-inactive {
        background: rgba(244, 67, 54, 0.1);
        color: #F44336;
    }
    </style>
    
    <!-- Page Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white;">
        <div style="padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h2 style="margin: 0 0 10px 0; color: white;">
                        <i class="fas fa-users"></i> <?php echo htmlspecialchars($class_info['class_name']); ?> Students
                    </h2>
                    <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                        Total Students: <?php echo count($students); ?> / Capacity: <?php echo $class_info['capacity']; ?>
                    </p>
                </div>
                <a href="<?php echo APP_URL; ?>/admin/classes.php" class="btn" style="background: white; color: #2196F3;">
                    <i class="fas fa-arrow-left"></i> Back to Classes
                </a>
            </div>
        </div>
    </div>
    
    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="background: linear-gradient(135deg, #2196F3, #1976D2); color: white; padding: 25px; border-radius: 15px;">
            <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Total Students</div>
            <div style="font-size: 36px; font-weight: 700;"><?php echo count($students); ?></div>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #4CAF50, #388E3C); color: white; padding: 25px; border-radius: 15px;">
            <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Active Accounts</div>
            <div style="font-size: 36px; font-weight: 700;">
                <?php echo count(array_filter($students, fn($s) => $s['account_status'] == 'active')); ?>
            </div>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #FF9800, #F57C00); color: white; padding: 25px; border-radius: 15px;">
            <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Available Seats</div>
            <div style="font-size: 36px; font-weight: 700;">
                <?php echo max(0, $class_info['capacity'] - count($students)); ?>
            </div>
        </div>
    </div>
    
    <?php if (count($students) > 0): ?>
        <!-- Action Bar -->
        <div style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <a href="<?php echo APP_URL; ?>/admin/students.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add New Student
                </a>
            </div>
            <div style="color: var(--text-secondary);">
                <i class="fas fa-info-circle"></i> Click on a student to edit or manage
            </div>
        </div>
        
        <div class="student-grid">
            <?php foreach ($students as $student): ?>
                <div class="student-card">
                    <div class="student-avatar">
                        <?php echo strtoupper(substr($student['full_name'] ?? '', 0, 1) . substr($student['full_name'] ?? '', strpos($student['full_name'] ?? ' ', ' ') + 1, 1)); ?>
                    </div>
                    <div class="student-name"><?php echo htmlspecialchars($student['full_name']); ?></div>
                    <div class="student-admission"><?php echo htmlspecialchars($student['admission_number']); ?></div>
                    
                    <div style="margin-bottom: 15px;">
                        <span class="status-badge status-<?php echo $student['account_status'] ?? 'inactive'; ?>">
                            <?php echo ucfirst($student['account_status'] ?? 'No Account'); ?>
                        </span>
                    </div>
                    
                    <div class="student-info">
                        <div class="info-row">
                            <i class="fas fa-envelope"></i>
                            <span style="font-size: 12px;"><?php echo htmlspecialchars($student['email']); ?></span>
                        </div>
                        <div class="info-row">
                            <i class="fas fa-phone"></i>
                            <span><?php echo htmlspecialchars($student['phone'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="info-row">
                            <i class="fas fa-venus-mars"></i>
                            <span><?php echo ucfirst($student['gender']); ?></span>
                        </div>
                        <div class="info-row">
                            <i class="fas fa-calendar"></i>
                            <span><?php echo date('M j, Y', strtotime($student['date_of_birth'])); ?></span>
                        </div>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div style="margin-top: 15px; display: flex; gap: 8px;">
                        <a href="<?php echo APP_URL; ?>/admin/students.php?edit=<?php echo $student['student_id']; ?>" 
                           class="btn btn-info btn-sm" style="flex: 1; text-decoration: none;" title="Edit Student">
                            <i class="fas fa-edit"></i>
                        </a>
                        <a href="<?php echo APP_URL; ?>/student/profile.php?id=<?php echo $student['student_id']; ?>" 
                           class="btn btn-primary btn-sm" style="flex: 1; text-decoration: none;" title="View Profile" target="_blank">
                            <i class="fas fa-eye"></i>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="card">
            <div style="padding: 60px; text-align: center;">
                <i class="fas fa-users" style="font-size: 64px; color: var(--text-secondary); opacity: 0.3; margin-bottom: 20px;"></i>
                <h3 style="color: var(--text-secondary); margin-bottom: 10px;">No Students Found</h3>
                <p style="color: var(--text-secondary);">This class doesn't have any students yet.</p>
                <a href="<?php echo APP_URL; ?>/admin/students.php" class="btn btn-primary" style="margin-top: 20px;">
                    <i class="fas fa-plus"></i> Add Students
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
