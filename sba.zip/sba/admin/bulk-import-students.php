<?php
// admin/bulk-import-students.php - Bulk Import Students from CSV
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Bulk Import Students';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get available classes
$stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

$success_count = 0;
$error_count = 0;
$skipped_count = 0;
$errors = [];
$imported_students = [];
$skipped_students = [];

// Handle CSV upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid security token. Please try again.';
    } else {
        $file = $_FILES['csv_file'];
        
        if ($file['error'] === UPLOAD_ERR_OK) {
            $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            
            if ($file_ext !== 'csv') {
                $errors[] = 'Please upload a CSV file only.';
            } else {
                // Read CSV file
                if (($handle = fopen($file['tmp_name'], 'r')) !== FALSE) {
                    // Get header row
                    $header = fgetcsv($handle);
                    
                    // Expected headers - SIMPLIFIED: only first_name and class_id required
                    $expected_headers = [
                        'first_name', 'class_id', 'middle_name', 'last_name',
                        'date_of_birth', 'gender', 'blood_group',
                        'phone', 'email', 'address', 'parent_name', 'parent_phone', 'parent_email'
                    ];
                    
                    // Validate headers
                    if ($header !== $expected_headers) {
                        $errors[] = 'CSV headers do not match template. Please use the correct template.';
                    } else {
                        $row_number = 1;
                        
                        // Start transaction
                        $db->beginTransaction();
                        
                        try {
                            while (($data = fgetcsv($handle)) !== FALSE) {
                                $row_number++;
                                
                                // Skip empty rows
                                if (empty(array_filter($data))) {
                                    continue;
                                }
                                
                                // Map data to array
                                $student = array_combine($header, $data);
                                
                                // Validate required fields - ONLY first_name and class_id
                                $missing_fields = [];
                                if (empty($student['first_name'])) $missing_fields[] = 'first_name';
                                if (empty($student['class_id'])) $missing_fields[] = 'class_id';
                                
                                if (!empty($missing_fields)) {
                                    $errors[] = "Row $row_number: Missing required fields: " . implode(', ', $missing_fields);
                                    $error_count++;
                                    continue;
                                }
                                
                                // Handle multi-word first names - split into first_name and last_name
                                $name_parts = explode(' ', trim($student['first_name']), 2);
                                $first_name = $name_parts[0];
                                $last_name = !empty($name_parts[1]) ? $name_parts[1] : ($student['last_name'] ?? '');
                                
                                // If last_name is still empty, use first_name as last_name
                                if (empty($last_name)) {
                                    $last_name = $first_name;
                                }
                                
                                // CHECK IF STUDENT ALREADY EXISTS (by name and class)
                                $existing_check = $db->prepare("
                                    SELECT s.student_id, s.admission_number, u.first_name, u.last_name
                                    FROM students s
                                    INNER JOIN users u ON s.user_id = u.user_id
                                    WHERE s.school_id = ? 
                                    AND s.class_id = ?
                                    AND u.first_name = ?
                                    AND u.last_name = ?
                                ");
                                $existing_check->execute([$school_id, $student['class_id'], $first_name, $last_name]);
                                $existing_student = $existing_check->fetch();
                                
                                if ($existing_student) {
                                    // Student already exists - SKIP
                                    $skipped_count++;
                                    $skipped_students[] = [
                                        'name' => $first_name . ' ' . $last_name,
                                        'admission_number' => $existing_student['admission_number'],
                                        'reason' => 'Already exists in class'
                                    ];
                                    continue; // Skip to next student
                                }
                                
                                // Validate class exists
                                $class_check = $db->prepare("SELECT class_id FROM classes WHERE class_id = ? AND school_id = ?");
                                $class_check->execute([$student['class_id'], $school_id]);
                                
                                if (!$class_check->fetch()) {
                                    $errors[] = "Row $row_number: Class ID {$student['class_id']} does not exist.";
                                    $error_count++;
                                    continue;
                                }
                                
                                // AUTO-GENERATE admission number with class_id
                                $admission_number = generate_admission_number($school_id, $student['class_id']);
                                
                                // Validate gender if provided (OPTIONAL)
                                if (!empty($student['gender']) && !in_array($student['gender'], ['Male', 'Female', 'male', 'female'])) {
                                    $errors[] = "Row $row_number: Invalid gender '{$student['gender']}'. Use 'Male' or 'Female'.";
                                    $error_count++;
                                    continue;
                                }
                                $gender = !empty($student['gender']) ? ucfirst(strtolower($student['gender'])) : null;
                                
                                // Validate date of birth if provided (OPTIONAL)
                                $date_of_birth = null;
                                if (!empty($student['date_of_birth'])) {
                                    $dob = DateTime::createFromFormat('Y-m-d', $student['date_of_birth']);
                                    if (!$dob || $dob->format('Y-m-d') !== $student['date_of_birth']) {
                                        $errors[] = "Row $row_number: Invalid date of birth '{$student['date_of_birth']}'. Use YYYY-MM-DD format (e.g., 2010-05-15) or leave empty.";
                                        $error_count++;
                                        continue;
                                    }
                                    $date_of_birth = $student['date_of_birth'];
                                }
                                
                                // Generate random password
                                $default_credentials = generate_default_credentials('student');
                                $random_password = $default_credentials['password']; // student123
                                $hashed_password = $default_credentials['hash'];
                                
                                // Create username from admission number
                                $username = strtolower(str_replace('/', '', $admission_number));
                                $original_username = $username;
                                $counter = 1;
                                
                                // Ensure unique username
                                while (true) {
                                    $user_check = $db->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND school_id = ?");
                                    $user_check->execute([$username, $school_id]);
                                    if ($user_check->fetchColumn() == 0) {
                                        break;
                                    }
                                    $username = $original_username . '_' . $counter;
                                    $counter++;
                                }
                                
                                // Insert student
                                $insert_stmt = $db->prepare("
                                    INSERT INTO students (
                                        school_id, admission_number, first_name, middle_name, last_name,
                                        date_of_birth, gender, blood_group, class_id,
                                        phone, email, address, status, admission_date, created_at
                                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', NOW(), NOW())
                                ");
                                
                                $insert_stmt->execute([
                                    $school_id,
                                    $admission_number,
                                    $first_name,
                                    $student['middle_name'] ?? '',
                                    $last_name,
                                    $date_of_birth,
                                    $gender,
                                    $student['blood_group'] ?? '',
                                    $student['class_id'],
                                    $student['phone'] ?? '',
                                    $student['email'] ?? '',
                                    $student['address'] ?? ''
                                ]);
                                
                                $student_id = $db->lastInsertId();
                                
                                // Check if email already exists (if provided)
                                if (!empty($student['email'] ?? '')) {
                                    $check_email = $db->prepare("SELECT COUNT(*) as count FROM users WHERE email = ? AND school_id = ?");
                                    $check_email->execute([$student['email'], $school_id]);
                                    if ($check_email->fetch()['count'] > 0) {
                                        // Email already exists, skip this student
                                        $errors[] = "Row $row_number: Email '{$student['email']}' is already in use by another user. Skipping student.";
                                        $error_count++;
                                        continue;
                                    }
                                }
                                
                                // Create user account for student
                                $user_stmt = $db->prepare("
                                    INSERT INTO users (
                                        school_id, username, password_hash, email, first_name, last_name,
                                        role, status, created_at
                                    ) VALUES (?, ?, ?, ?, ?, ?, 'student', 'active', NOW())
                                ");
                                
                                $user_stmt->execute([
                                    $school_id,
                                    $username,
                                    $hashed_password,
                                    $student['email'] ?? '',
                                    $first_name,
                                    $last_name
                                ]);
                                
                                $user_id = $db->lastInsertId();
                                
                                // Link user to student
                                $link_stmt = $db->prepare("UPDATE students SET user_id = ? WHERE student_id = ?");
                                $link_stmt->execute([$user_id, $student_id]);
                                
                                // Create parent if provided
                                if (!empty($student['parent_name']) && !empty($student['parent_phone'])) {
                                    // Check if parent exists by phone
                                    $parent_check = $db->prepare("SELECT parent_id FROM parents WHERE phone = ? AND school_id = ?");
                                    $parent_check->execute([$student['parent_phone'], $school_id]);
                                    $existing_parent = $parent_check->fetch();
                                    
                                    if ($existing_parent) {
                                        $parent_id = $existing_parent['parent_id'];
                                    } else {
                                        // Create new parent
                                        $parent_username = 'parent_' . strtolower(str_replace(' ', '', $student['parent_name'])) . '_' . substr($student['parent_phone'], -4);
                                        $parent_password = bin2hex(random_bytes(4));
                                        $parent_hashed = password_hash($parent_password, PASSWORD_BCRYPT);
                                        
                                        $parent_stmt = $db->prepare("
                                            INSERT INTO parents (
                                                school_id, name, phone, email, address, created_at
                                            ) VALUES (?, ?, ?, ?, '', NOW())
                                        ");
                                        
                                        $parent_stmt->execute([
                                            $school_id,
                                            $student['parent_name'],
                                            $student['parent_phone'],
                                            $student['parent_email']
                                        ]);
                                        
                                        $parent_id = $db->lastInsertId();
                                        
                                        // Create parent user account
                                        $parent_user_stmt = $db->prepare("
                                            INSERT INTO users (
                                                school_id, username, password_hash, email, first_name, last_name,
                                                role, status, created_at
                                            ) VALUES (?, ?, ?, ?, ?, '', 'parent', 'active', NOW())
                                        ");
                                        
                                        $parent_user_stmt->execute([
                                            $school_id,
                                            $parent_username,
                                            $parent_hashed,
                                            $student['parent_email'],
                                            $student['parent_name']
                                        ]);
                                    }
                                    
                                    // Link student to parent
                                    $link_parent_stmt = $db->prepare("
                                        INSERT INTO student_parents (student_id, parent_id, relationship, created_at)
                                        VALUES (?, ?, 'Parent', NOW())
                                    ");
                                    $link_parent_stmt->execute([$student_id, $parent_id]);
                                }
                                
                                $success_count++;
                                $imported_students[] = [
                                    'admission_number' => $admission_number,
                                    'name' => $first_name . ' ' . $last_name,
                                    'username' => $username,
                                    'password' => $random_password
                                ];
                                
                                // Log activity
                                log_activity($current_user['user_id'], "Bulk imported student: {$first_name} {$last_name}", 'students', $student_id);
                            }
                            
                            // Commit transaction
                            $db->commit();
                            
                            // Build detailed success message
                            $message_parts = [];
                            if ($success_count > 0) {
                                $message_parts[] = "<strong>✅ Imported:</strong> $success_count new student(s)";
                            }
                            if ($skipped_count > 0) {
                                $message_parts[] = "<strong>⏭️ Skipped:</strong> $skipped_count existing student(s)";
                            }
                            if ($error_count > 0) {
                                $message_parts[] = "<strong>❌ Errors:</strong> $error_count failed";
                            }
                            
                            $full_message = implode(' | ', $message_parts);
                            
                            if ($success_count > 0) {
                                set_message('success', $full_message);
                            } elseif ($skipped_count > 0 && $error_count == 0) {
                                set_message('info', $full_message);
                            }
                            
                        } catch (Exception $e) {
                            $db->rollBack();
                            $errors[] = 'Database error: ' . $e->getMessage();
                        }
                    }
                    
                    fclose($handle);
                } else {
                    $errors[] = 'Could not read CSV file.';
                }
            }
        } else {
            $errors[] = 'File upload error. Please try again.';
        }
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
        .import-card {
            background: var(--bg-card);
            border-radius: 15px;
            padding: 30px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }
        
        .upload-area {
            border: 3px dashed var(--border-color);
            border-radius: 15px;
            padding: 40px;
            text-align: center;
            background: var(--bg-secondary);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .upload-area:hover {
            border-color: var(--primary-blue);
            background: var(--bg-hover);
        }
        
        .upload-area i {
            font-size: 48px;
            color: var(--primary-blue);
            margin-bottom: 20px;
        }
        
        .instructions {
            background: var(--bg-secondary);
            border-left: 4px solid var(--info-blue);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        
        .instructions h4 {
            color: var(--info-blue);
            margin-bottom: 15px;
        }
        
        .instructions ol {
            margin-left: 20px;
        }
        
        .instructions li {
            margin-bottom: 10px;
            color: var(--text-secondary);
        }
        
        .result-table {
            margin-top: 30px;
        }
        
        .result-table table {
            width: 100%;
            background: var(--bg-card);
            border-radius: 10px;
            overflow: hidden;
        }
        
        .error-list {
            background: rgba(220, 38, 38, 0.1);
            border-left: 4px solid var(--danger-red);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .error-list h4 {
            color: var(--danger-red);
            margin-bottom: 15px;
        }
        
        .error-list ul {
            list-style: none;
            padding: 0;
        }
        
        .error-list li {
            padding: 8px 0;
            border-bottom: 1px solid var(--border-color);
        }
        
        .error-list li:last-child {
            border-bottom: none;
        }
        
        .success-summary {
            background: rgba(5, 150, 105, 0.1);
            border-left: 4px solid var(--success-green);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        
        .success-summary h4 {
            color: var(--success-green);
            margin-bottom: 10px;
        }
    </style>
    
    <!-- Page Header -->
    <div class="card" style="margin-bottom: 30px; background: var(--gradient-primary); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-file-import"></i> Bulk Import Students
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Import multiple students at once using a CSV file
            </p>
        </div>
    </div>
    
    <!-- Instructions -->
    <div class="instructions">
        <h4><i class="fas fa-info-circle"></i> How to Import Students</h4>
        <ol>
            <li>Download the CSV template file below</li>
            <li>Fill in <strong>ONLY two required fields</strong>: <code>first_name</code> and <code>class_id</code></li>
            <li><strong>Multi-word names:</strong> If first_name has multiple words (e.g., "John Smith"), the second word automatically becomes the last name</li>
            <li><strong>Optional fields:</strong> date_of_birth, gender, email, phone, etc. can be updated later</li>
            <li><strong>Admission numbers are AUTO-GENERATED</strong> in the format: SCHOOL_CODE/YEAR/CLASS_ID/00001</li>
            <li>Save the file as CSV format and upload below</li>
        </ol>
        <div style="background: #FFF3E0; padding: 15px; border-radius: 8px; margin-top: 15px; border-left: 4px solid #FF9800;">
            <strong><i class="fas fa-lightbulb"></i> Example:</strong><br>
            • <code>first_name: "John Smith"</code> + <code>class_id: 1</code> → First Name: John, Last Name: Smith<br>
            • <code>first_name: "Mary"</code> + <code>class_id: 2</code> → First Name: Mary, Last Name: Mary<br>
            • Admission Number: <code>UHAS/2025/01/00001</code> (auto-generated)
        </div>
        <div style="margin-top: 20px;">
            <a href="<?php echo APP_URL; ?>/templates/student_import_template.csv" class="btn btn-primary" download>
                <i class="fas fa-download"></i> Download CSV Template
            </a>
            <a href="<?php echo APP_URL; ?>/admin/students.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Students
            </a>
        </div>
    </div>
    
    <!-- Available Classes Reference -->
    <div class="card" style="margin-bottom: 30px;">
        <h3 style="margin-bottom: 20px;">
            <i class="fas fa-list"></i> Available Classes
        </h3>
        <p style="color: var(--text-secondary); margin-bottom: 20px;">
            Use these Class IDs in your CSV file:
        </p>
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px;">
            <?php foreach ($classes as $class): ?>
                <div style="background: var(--bg-secondary); padding: 15px; border-radius: 10px; border-left: 4px solid var(--primary-blue);">
                    <div style="font-weight: 600; margin-bottom: 5px;"><?php echo htmlspecialchars($class['class_name']); ?></div>
                    <div style="color: var(--text-secondary); font-size: 12px;">Class ID: <strong><?php echo $class['class_id']; ?></strong></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Error Messages -->
    <?php if (!empty($errors)): ?>
    <div class="error-list">
        <h4><i class="fas fa-exclamation-triangle"></i> Import Errors (<?php echo count($errors); ?>)</h4>
        <ul>
            <?php foreach ($errors as $error): ?>
                <li><i class="fas fa-times-circle" style="color: var(--danger-red); margin-right: 8px;"></i><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    
    <!-- Success Summary -->
    <?php if ($success_count > 0 || $skipped_count > 0): ?>
    <div class="success-summary">
        <h4><i class="fas fa-check-circle"></i> Import Summary</h4>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-top: 15px;">
            <?php if ($success_count > 0): ?>
            <div style="background: rgba(5, 150, 105, 0.2); padding: 15px; border-radius: 8px; text-align: center;">
                <div style="font-size: 32px; font-weight: 700; color: var(--success-green);"><?php echo $success_count; ?></div>
                <div style="color: var(--text-secondary); margin-top: 5px;">New Students Imported</div>
            </div>
            <?php endif; ?>
            
            <?php if ($skipped_count > 0): ?>
            <div style="background: rgba(251, 191, 36, 0.2); padding: 15px; border-radius: 8px; text-align: center;">
                <div style="font-size: 32px; font-weight: 700; color: var(--warning-orange);"><?php echo $skipped_count; ?></div>
                <div style="color: var(--text-secondary); margin-top: 5px;">Existing Students Skipped</div>
            </div>
            <?php endif; ?>
            
            <?php if ($error_count > 0): ?>
            <div style="background: rgba(220, 38, 38, 0.2); padding: 15px; border-radius: 8px; text-align: center;">
                <div style="font-size: 32px; font-weight: 700; color: var(--danger-red);"><?php echo $error_count; ?></div>
                <div style="color: var(--text-secondary); margin-top: 5px;">Rows with Errors</div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Upload Form -->
    <div class="import-card">
        <h3 style="margin-bottom: 25px;">
            <i class="fas fa-upload"></i> Upload CSV File
        </h3>
        
        <form method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            
            <div class="upload-area" onclick="document.getElementById('csv_file').click()">
                <i class="fas fa-cloud-upload-alt"></i>
                <h4>Click to select CSV file or drag and drop</h4>
                <p style="color: var(--text-secondary); margin-top: 10px;">
                    Maximum file size: 5MB
                </p>
                <input type="file" name="csv_file" id="csv_file" accept=".csv" style="display: none;" required onchange="showFileName(this)">
                <div id="file-name" style="margin-top: 15px; font-weight: 600; color: var(--primary-blue);"></div>
            </div>
            
            <div style="margin-top: 30px; text-align: center;">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-file-import"></i> Import Students
                </button>
            </div>
        </form>
    </div>
    
    <!-- Imported Students Table -->
    <?php if (!empty($imported_students)): ?>
    <div class="result-table">
        <div class="card">
            <h3 style="margin-bottom: 20px;">
                <i class="fas fa-users"></i> Newly Imported Students - Login Credentials
            </h3>
            <p style="color: var(--text-secondary); margin-bottom: 20px;">
                <i class="fas fa-exclamation-circle"></i> <strong>Important:</strong> Save these credentials! They won't be shown again.
            </p>
            
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Admission Number</th>
                            <th>Student Name</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($imported_students as $student): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($student['admission_number']); ?></td>
                                <td><?php echo htmlspecialchars($student['name']); ?></td>
                                <td><code><?php echo htmlspecialchars($student['username']); ?></code></td>
                                <td><code><?php echo htmlspecialchars($student['password']); ?></code></td>
                                <td>
                                    <button class="btn btn-sm btn-secondary" onclick="copyCredentials('<?php echo htmlspecialchars($student['username']); ?>', '<?php echo htmlspecialchars($student['password']); ?>')">
                                        <i class="fas fa-copy"></i> Copy
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div style="margin-top: 20px; text-align: center;">
                <button class="btn btn-success" onclick="exportCredentials()">
                    <i class="fas fa-download"></i> Download All Credentials as CSV
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Skipped Students Table -->
    <?php if (!empty($skipped_students)): ?>
    <div class="result-table">
        <div class="card" style="background: rgba(251, 191, 36, 0.05);">
            <h3 style="margin-bottom: 20px; color: var(--warning-orange);">
                <i class="fas fa-user-slash"></i> Skipped Students (Already Exist)
            </h3>
            <p style="color: var(--text-secondary); margin-bottom: 20px;">
                <i class="fas fa-info-circle"></i> These students were not imported because they already exist in the system.
            </p>
            
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Student Name</th>
                            <th>Existing Admission Number</th>
                            <th>Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($skipped_students as $student): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($student['name']); ?></strong></td>
                                <td><code><?php echo htmlspecialchars($student['admission_number']); ?></code></td>
                                <td>
                                    <span style="background: rgba(251, 191, 36, 0.2); padding: 4px 12px; border-radius: 12px; font-size: 13px; color: var(--warning-orange);">
                                        <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($student['reason']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <script>
    function showFileName(input) {
        if (input.files && input.files[0]) {
            document.getElementById('file-name').textContent = input.files[0].name;
        }
    }
    
    function copyCredentials(username, password) {
        const text = `Username: ${username}\nPassword: ${password}`;
        navigator.clipboard.writeText(text).then(() => {
            alert('Credentials copied to clipboard!');
        });
    }
    
    function exportCredentials() {
        const table = document.querySelector('.result-table table');
        let csv = 'Admission Number,Student Name,Username,Password\n';
        
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            csv += `"${cells[0].textContent}","${cells[1].textContent}","${cells[2].textContent}","${cells[3].textContent}"\n`;
        });
        
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'imported_students_credentials_' + new Date().toISOString().split('T')[0] + '.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }
    
    // Drag and drop
    const uploadArea = document.querySelector('.upload-area');
    
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = 'var(--primary-blue)';
        uploadArea.style.background = 'var(--bg-hover)';
    });
    
    uploadArea.addEventListener('dragleave', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = 'var(--border-color)';
        uploadArea.style.background = 'var(--bg-secondary)';
    });
    
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.style.borderColor = 'var(--border-color)';
        uploadArea.style.background = 'var(--bg-secondary)';
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            document.getElementById('csv_file').files = files;
            showFileName(document.getElementById('csv_file'));
        }
    });
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
