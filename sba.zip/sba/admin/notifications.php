<?php
// admin/notifications.php - Manage Notifications
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Notifications';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action']) && $_POST['action'] == 'send') {
        $title = sanitize_input($_POST['title']);
        $message = sanitize_input($_POST['message']);
        $type = sanitize_input($_POST['type']);
        $recipient_type = sanitize_input($_POST['recipient_type']);
        
        try {
            $db->beginTransaction();
            
            // Get recipients based on type
            $recipients = [];
            
            if ($recipient_type == 'all') {
                $stmt = $db->prepare("SELECT user_id FROM users WHERE school_id = ? AND status = 'active'");
                $stmt->execute([$school_id]);
                $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
            } elseif ($recipient_type == 'students') {
                $stmt = $db->prepare("SELECT user_id FROM users WHERE school_id = ? AND role = 'student' AND status = 'active'");
                $stmt->execute([$school_id]);
                $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
            } elseif ($recipient_type == 'teachers') {
                $stmt = $db->prepare("SELECT user_id FROM users WHERE school_id = ? AND role = 'teacher' AND status = 'active'");
                $stmt->execute([$school_id]);
                $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
            } elseif ($recipient_type == 'parents') {
                $stmt = $db->prepare("SELECT user_id FROM users WHERE school_id = ? AND role = 'parent' AND status = 'active'");
                $stmt->execute([$school_id]);
                $recipients = $stmt->fetchAll(PDO::FETCH_COLUMN);
            }
            
            // Insert notifications for all recipients
            $stmt = $db->prepare("
                INSERT INTO notifications (user_id, title, message, type, is_read)
                VALUES (?, ?, ?, ?, 0)
            ");
            
            foreach ($recipients as $user_id) {
                $stmt->execute([$user_id, $title, $message, $type]);
            }
            
            $db->commit();
            
            log_activity($current_user['user_id'], "Sent notification to $recipient_type: $title", 'notifications', 0);
            
            set_message('success', 'Notification sent to ' . count($recipients) . ' users!');
            redirect(APP_URL . '/admin/notifications.php');
        } catch (PDOException $e) {
            $db->rollBack();
            set_message('error', 'Error sending notification: ' . $e->getMessage());
        }
    }
}

// Get recent notifications
$notifications = [];
try {
    $stmt = $db->prepare("
        SELECT 
            n.*,
            u.first_name,
            u.last_name,
            u.role
        FROM notifications n
        INNER JOIN users u ON n.user_id = u.user_id
        WHERE u.school_id = ?
        ORDER BY n.created_at DESC
        LIMIT 50
    ");
    $stmt->execute([$school_id]);
    $notifications = $stmt->fetchAll();
} catch (PDOException $e) {
    // notifications table doesn't exist
    $notifications = [];
}

// Statistics
$stats = ['total' => 0, 'unread' => 0];
try {
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN is_read = 0 THEN 1 ELSE 0 END) as unread
        FROM notifications n
        INNER JOIN users u ON n.user_id = u.user_id
        WHERE u.school_id = ?
    ");
    $stmt->execute([$school_id]);
    $stats = $stmt->fetch();
} catch (PDOException $e) {
    // notifications table doesn't exist
    $stats = ['total' => 0, 'unread' => 0];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .notification-card {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 15px;
        border-left: 4px solid var(--primary-blue);
        transition: all 0.3s ease;
    }
    
    .notification-card:hover {
        transform: translateX(5px);
        box-shadow: var(--shadow);
    }
    
    .notification-card.unread {
        background: rgba(33, 150, 243, 0.05);
        border-left-color: #2196F3;
    }
    
    .notification-header {
        display: flex;
        justify-content: space-between;
        align-items: start;
        margin-bottom: 10px;
    }
    
    .notification-title {
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    .notification-meta {
        display: flex;
        gap: 15px;
        font-size: 13px;
        color: var(--text-secondary);
    }
    
    .notification-message {
        margin-top: 10px;
        color: var(--text-secondary);
    }
    
    .type-badge {
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .type-info { background: rgba(33, 150, 243, 0.1); color: #2196F3; }
    .type-success { background: rgba(76, 175, 80, 0.1); color: #4CAF50; }
    .type-warning { background: rgba(255, 152, 0, 0.1); color: #FF9800; }
    .type-error { background: rgba(244, 67, 54, 0.1); color: #F44336; }
    </style>
    
    <!-- Page Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-bell"></i> Notifications
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Send and manage system notifications
            </p>
        </div>
    </div>
    
    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="background: linear-gradient(135deg, #2196F3, #1976D2); color: white; padding: 25px; border-radius: 15px;">
            <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Total Notifications</div>
            <div style="font-size: 36px; font-weight: 700;"><?php echo $stats['total']; ?></div>
        </div>
        <div class="stat-card" style="background: linear-gradient(135deg, #FF9800, #F57C00); color: white; padding: 25px; border-radius: 15px;">
            <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Unread</div>
            <div style="font-size: 36px; font-weight: 700;"><?php echo $stats['unread']; ?></div>
        </div>
    </div>
    
    <!-- Send Notification Button -->
    <div style="margin-bottom: 20px;">
        <button onclick="document.getElementById('sendModal').style.display='flex'" class="btn btn-primary">
            <i class="fas fa-paper-plane"></i> Send Notification
        </button>
    </div>
    
    <!-- Notifications List -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Recent Notifications</h3>
        </div>
        <div style="padding: 20px;">
            <?php if (count($notifications) > 0): ?>
                <?php foreach ($notifications as $notification): ?>
                    <div class="notification-card <?php echo $notification['is_read'] == 0 ? 'unread' : ''; ?>">
                        <div class="notification-header">
                            <div style="flex: 1;">
                                <div class="notification-title"><?php echo htmlspecialchars($notification['title']); ?></div>
                                <div class="notification-meta">
                                    <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($notification['first_name'] . ' ' . $notification['last_name']); ?></span>
                                    <span><i class="fas fa-tag"></i> <?php echo ucfirst($notification['role']); ?></span>
                                    <span><i class="fas fa-clock"></i> <?php echo date('M j, Y g:i A', strtotime($notification['created_at'])); ?></span>
                                </div>
                            </div>
                            <span class="type-badge type-<?php echo $notification['type']; ?>">
                                <?php echo ucfirst($notification['type']); ?>
                            </span>
                        </div>
                        <div class="notification-message">
                            <?php echo htmlspecialchars($notification['message']); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="padding: 40px; text-align: center; color: var(--text-secondary);">
                    <i class="fas fa-bell-slash" style="font-size: 48px; opacity: 0.3; margin-bottom: 15px;"></i>
                    <p>No notifications yet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Send Notification Modal -->
    <div id="sendModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-paper-plane"></i> Send Notification</h3>
                <span class="modal-close" onclick="document.getElementById('sendModal').style.display='none'">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="send">
                
                <div class="form-group">
                    <label>Title *</label>
                    <input type="text" name="title" required placeholder="Notification title">
                </div>
                
                <div class="form-group">
                    <label>Message *</label>
                    <textarea name="message" rows="4" required placeholder="Notification message"></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Type *</label>
                        <select name="type" required>
                            <option value="info">Info</option>
                            <option value="success">Success</option>
                            <option value="warning">Warning</option>
                            <option value="error">Error</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Send To *</label>
                        <select name="recipient_type" required>
                            <option value="all">All Users</option>
                            <option value="students">All Students</option>
                            <option value="teachers">All Teachers</option>
                            <option value="parents">All Parents</option>
                        </select>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" onclick="document.getElementById('sendModal').style.display='none'" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Notification</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
