<?php
// admin/upload-user-picture.php - Upload user profile picture
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['admin']);
$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['profile_picture'])) {
    $user_id = (int)$_POST['user_id'];
    
    // Verify this is a user in the same school
    $verify = $db->prepare("SELECT user_id FROM users WHERE user_id = ? AND school_id = ?");
    $verify->execute([$user_id, $school_id]);
    
    if (!$verify->fetch()) {
        die(json_encode(['error' => 'User not found']));
    }
    
    $file = $_FILES['profile_picture'];
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $max_size = 5 * 1024 * 1024; // 5MB
    
    if (!in_array($file['type'], $allowed_types)) {
        die(json_encode(['error' => 'Invalid file type. Only JPG, PNG, GIF allowed']));
    }
    
    if ($file['size'] > $max_size) {
        die(json_encode(['error' => 'File too large. Max 5MB']));
    }
    
    // Create uploads directory
    $upload_dir = BASE_PATH . '/uploads/avatars';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    // Save file with user_id as name
    $ext = explode('/', $file['type'])[1];
    $filename = 'user_' . $user_id . '.' . $ext;
    $filepath = $upload_dir . '/' . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        echo json_encode(['success' => true, 'url' => APP_URL . '/uploads/avatars/' . $filename]);
    } else {
        echo json_encode(['error' => 'Failed to upload file']);
    }
    exit;
}

// Display form
include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="card" style="max-width: 600px; margin: 20px auto;">
        <div class="card-header">
            <h3><i class="fas fa-image"></i> Upload User Profile Picture</h3>
        </div>
        <div style="padding: 30px;">
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="user_id">Select User *</label>
                    <select name="user_id" id="user_id" required>
                        <option value="">-- Select User --</option>
                        <?php
                        $stmt = $db->prepare("SELECT user_id, CONCAT(first_name, ' ', last_name, ' (', username, ')') as name 
                                             FROM users WHERE school_id = ? AND role IN ('admin','teacher','accountant','librarian') 
                                             ORDER BY first_name");
                        $stmt->execute([$school_id]);
                        foreach ($stmt->fetchAll() as $user):
                        ?>
                            <option value="<?php echo $user['user_id']; ?>"><?php echo htmlspecialchars($user['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="profile_picture">Upload Picture *</label>
                    <input type="file" name="profile_picture" id="profile_picture" accept="image/*" required>
                    <small style="color: var(--text-secondary);">JPG, PNG, GIF (Max 5MB)</small>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="reset" class="btn btn-secondary">Clear</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-upload"></i> Upload Picture
                    </button>
                </div>
            </form>
            
            <div id="result" style="margin-top: 20px; display: none; padding: 15px; border-radius: 8px;"></div>
        </div>
    </div>
    
    <script>
    document.querySelector('form').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const resultDiv = document.getElementById('result');
        
        try {
            const response = await fetch(window.location.href, {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                resultDiv.style.display = 'block';
                resultDiv.style.background = 'rgba(76, 175, 80, 0.1)';
                resultDiv.style.color = '#4CAF50';
                resultDiv.innerHTML = '<i class="fas fa-check-circle"></i> Picture uploaded successfully!';
                this.reset();
            } else {
                resultDiv.style.display = 'block';
                resultDiv.style.background = 'rgba(255, 67, 54, 0.1)';
                resultDiv.style.color = '#FF3D71';
                resultDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + data.error;
            }
        } catch (error) {
            resultDiv.style.display = 'block';
            resultDiv.style.background = 'rgba(255, 67, 54, 0.1)';
            resultDiv.style.color = '#FF3D71';
            resultDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> Error uploading file';
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
