<?php
// admin/dashboard.php - Modern Admin Dashboard with Donkomie Design
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Dashboard';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Fetch statistics
$stats = [];

// Total Students
$stmt = $db->prepare("SELECT COUNT(*) as count FROM students WHERE school_id = ? AND status = 'active'");
$stmt->execute([$school_id]);
$stats['total_students'] = $stmt->fetch()['count'];

// Total Teachers
$stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE school_id = ? AND role = 'teacher' AND status = 'active'");
$stmt->execute([$school_id]);
$stats['total_teachers'] = $stmt->fetch()['count'];

// Total Classes
try {
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM classes WHERE school_id = ?");
    $stmt->execute([$school_id]);
    $stats['total_classes'] = $stmt->fetch()['count'];
} catch (PDOException $e) {
    // classes table may not have status column
    $stats['total_classes'] = 0;
}

// Total Revenue (All Time) - Student Fees
$student_revenue = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE student_id IN (SELECT student_id FROM students WHERE school_id = ?) AND status IN ('paid', 'completed')
    ");
    $stmt->execute([$school_id]);
    $student_revenue = $stmt->fetch()['total'];
} catch (PDOException $e) {
    // payments table may not exist yet
    $student_revenue = 0;
}

// Staff Payments Revenue (Canteen + Transport)
$staff_revenue = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM staff_payments 
        WHERE school_id = ? AND status = 'paid'
    ");
    $stmt->execute([$school_id]);
    $staff_revenue = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $staff_revenue = 0;
}

// Combined Total Revenue
$stats['total_revenue'] = $student_revenue + $staff_revenue;

// Total Subjects
$stmt = $db->prepare("SELECT COUNT(*) as count FROM subjects WHERE school_id = ? AND status = 'active'");
$stmt->execute([$school_id]);
$stats['total_subjects'] = $stmt->fetch()['count'];

// Exams This Term
try {
    $stmt = $db->prepare("
        SELECT COUNT(DISTINCT e.exam_id) as count
        FROM exams e
        INNER JOIN terms t ON e.term_id = t.term_id
        WHERE e.school_id = ?
        ORDER BY e.created_at DESC
        LIMIT 1
    ");
    $stmt->execute([$school_id]);
    $stats['exams_this_term'] = $stmt->fetch()['count'] ?? 0;
} catch (PDOException $e) {
    $stats['exams_this_term'] = 0;
}

// Marks Pending (Not all students have marks)
try {
    $stmt = $db->prepare("
        SELECT COUNT(DISTINCT s.student_id) as count
        FROM students s
        WHERE s.school_id = ? AND s.status = 'active'
    ");
    $stmt->execute([$school_id]);
    $stats['marks_pending'] = $stmt->fetch()['count'] ?? 0;
} catch (PDOException $e) {
    $stats['marks_pending'] = 0;
}

// Additional Financial Statistics

// Pending Revenue
$stats['pending_revenue'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE student_id IN (SELECT student_id FROM students WHERE school_id = ?) AND status = 'pending'
    ");
    $stmt->execute([$school_id]);
    $stats['pending_revenue'] = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $stats['pending_revenue'] = 0;
}

// Overdue Payments
$stats['overdue'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE student_id IN (SELECT student_id FROM students WHERE school_id = ?) 
        AND status = 'pending' 
        AND payment_date < CURDATE()
    ");
    $stmt->execute([$school_id]);
    $stats['overdue'] = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $stats['overdue'] = 0;
}

// This Month Income
$month_student_income = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE student_id IN (SELECT student_id FROM students WHERE school_id = ?) 
        AND status IN ('paid', 'completed')
        AND MONTH(payment_date) = MONTH(CURRENT_DATE()) 
        AND YEAR(payment_date) = YEAR(CURRENT_DATE())
    ");
    $stmt->execute([$school_id]);
    $month_student_income = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $month_student_income = 0;
}

// This Month Staff Payments
$month_staff_income = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM staff_payments 
        WHERE school_id = ? AND status = 'paid'
        AND MONTH(payment_date) = MONTH(CURRENT_DATE()) 
        AND YEAR(payment_date) = YEAR(CURRENT_DATE())
    ");
    $stmt->execute([$school_id]);
    $month_staff_income = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $month_staff_income = 0;
}

$stats['month_income'] = $month_student_income + $month_staff_income;

// This Month Expenditure
$stats['month_expenditure'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM expenses 
        WHERE school_id = ? 
        AND MONTH(expense_date) = MONTH(CURRENT_DATE()) 
        AND YEAR(expense_date) = YEAR(CURRENT_DATE())
    ");
    $stmt->execute([$school_id]);
    $stats['month_expenditure'] = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $stats['month_expenditure'] = 0;
}

// Canteen Revenue
$stats['canteen_revenue'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM staff_payments 
        WHERE school_id = ? AND status = 'paid' AND payment_type = 'canteen'
    ");
    $stmt->execute([$school_id]);
    $stats['canteen_revenue'] = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $stats['canteen_revenue'] = 0;
}

// Bus Fee Revenue
$stats['bus_revenue'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM staff_payments 
        WHERE school_id = ? AND status = 'paid' AND payment_type = 'transport'
    ");
    $stmt->execute([$school_id]);
    $stats['bus_revenue'] = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $stats['bus_revenue'] = 0;
}

// Collection Rate
$total_expected = $stats['total_revenue'] + $stats['pending_revenue'];
$stats['collection_rate'] = $total_expected > 0 ? round(($stats['total_revenue'] / $total_expected) * 100, 1) : 0;

// ==============================================
// TRANSACTION & PAYMENT GATEWAY STATISTICS
// ==============================================

// Online Transactions (MTN, Tigo, PayStack)
$stats['online_transactions'] = 0;
$stats['online_revenue'] = 0;
try {
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total
        FROM transactions
        WHERE school_id = ?
        AND gateway_name IN ('mtn_momo', 'tigo_cash', 'paystack')
        AND status = 'completed'
    ");
    $stmt->execute([$school_id]);
    $result = $stmt->fetch();
    $stats['online_transactions'] = $result['count'];
    $stats['online_revenue'] = $result['total'];
} catch (PDOException $e) {
    $stats['online_transactions'] = 0;
    $stats['online_revenue'] = 0;
}

// Pending Transactions
$stats['pending_transactions'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COUNT(*) as count
        FROM transactions
        WHERE school_id = ? AND status = 'pending'
    ");
    $stmt->execute([$school_id]);
    $stats['pending_transactions'] = $stmt->fetch()['count'];
} catch (PDOException $e) {
    $stats['pending_transactions'] = 0;
}

// Failed Transactions
$stats['failed_transactions'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COUNT(*) as count
        FROM transactions
        WHERE school_id = ? AND status = 'failed'
    ");
    $stmt->execute([$school_id]);
    $stats['failed_transactions'] = $stmt->fetch()['count'];
} catch (PDOException $e) {
    $stats['failed_transactions'] = 0;
}

// Payment Gateway Breakdown
$gateway_stats = [];
try {
    $stmt = $db->prepare("
        SELECT 
            gateway_name,
            COUNT(*) as transaction_count,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as successful,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
            COALESCE(SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END), 0) as total_amount
        FROM transactions
        WHERE school_id = ?
        AND gateway_name IN ('mtn_momo', 'tigo_cash', 'paystack')
        GROUP BY gateway_name
    ");
    $stmt->execute([$school_id]);
    $gateway_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $gateway_stats = [];
}

// Today's Transactions
$stats['today_transactions'] = 0;
$stats['today_revenue'] = 0;
try {
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total
        FROM transactions
        WHERE school_id = ?
        AND DATE(created_at) = CURDATE()
        AND status = 'completed'
    ");
    $stmt->execute([$school_id]);
    $result = $stmt->fetch();
    $stats['today_transactions'] = $result['count'];
    $stats['today_revenue'] = $result['total'];
} catch (PDOException $e) {
    $stats['today_transactions'] = 0;
    $stats['today_revenue'] = 0;
}

// Recent Transactions (Last 10)
$recent_transactions = [];
try {
    $stmt = $db->prepare("
        SELECT 
            t.*,
            s.admission_number,
            CONCAT(u.first_name, ' ', u.last_name) as student_name
        FROM transactions t
        LEFT JOIN students s ON t.student_id = s.student_id
        LEFT JOIN users u ON s.user_id = u.user_id
        WHERE t.school_id = ?
        ORDER BY t.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$school_id]);
    $recent_transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    $recent_transactions = [];
}

// Recent Students
try {
    $stmt = $db->prepare("
        SELECT s.*, c.class_name, COALESCE(u.first_name, '-') as first_name, COALESCE(u.last_name, '') as last_name, COALESCE(u.gender, 'N/A') as gender
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.class_id
        LEFT JOIN users u ON s.user_id = u.user_id
        WHERE s.school_id = ?
        ORDER BY s.created_at DESC
        LIMIT 5
    ");
    $stmt->execute([$school_id]);
    $recent_students = $stmt->fetchAll();
} catch (PDOException $e) {
    $recent_students = [];
}

// Attendance Summary (Today)
$attendance_today = ['present' => 0, 'absent' => 0, 'late' => 0];
try {
    $stmt = $db->prepare("
        SELECT 
            SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
            SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent,
            SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) as late
        FROM attendance
        WHERE date = CURDATE() AND class_id IN (
            SELECT class_id FROM classes WHERE school_id = ?
        )
    ");
    $stmt->execute([$school_id]);
    $attendance_today = $stmt->fetch();
} catch (PDOException $e) {
    // attendance table may not exist yet
    $attendance_today = ['present' => 0, 'absent' => 0, 'late' => 0];
}

// Monthly Revenue Data (for chart)
$monthly_revenue = [];
try {
    $stmt = $db->prepare("
        SELECT 
            DATE_FORMAT(payment_date, '%b') as month,
            SUM(amount) as total
        FROM payments
        WHERE school_id = ? 
        AND status = 'completed'
        AND payment_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(payment_date, '%Y-%m')
        ORDER BY payment_date
    ");
    $stmt->execute([$school_id]);
    $monthly_revenue = $stmt->fetchAll();
} catch (PDOException $e) {
    // payments table may not exist yet
    $monthly_revenue = [];
}

// Top Performing Classes
try {
    $stmt = $db->prepare("
        SELECT c.class_id, c.class_name,
               COUNT(DISTINCT s.student_id) as students_with_marks,
               ROUND(AVG(m.total_score), 2) as average_score
        FROM classes c
        LEFT JOIN students s ON c.class_id = s.class_id AND s.status = 'active'
        LEFT JOIN marks m ON s.student_id = m.student_id
        WHERE c.school_id = ?
        GROUP BY c.class_id, c.class_name
        HAVING COUNT(m.mark_id) > 0
        ORDER BY average_score DESC
        LIMIT 5
    ");
    $stmt->execute([$school_id]);
    $top_classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $top_classes = [];
}

// Upcoming Exams
try {
    $stmt = $db->prepare("
        SELECT e.exam_id, e.exam_name, e.status, e.start_date,
               t.term_name,
               DATE_FORMAT(e.start_date, '%M %d, %Y') as formatted_date
        FROM exams e
        LEFT JOIN terms t ON e.term_id = t.term_id
        WHERE e.school_id = ? AND e.status IN ('scheduled', 'ongoing')
        ORDER BY e.start_date ASC
        LIMIT 5
    ");
    $stmt->execute([$school_id]);
    $upcoming_exams = $stmt->fetchAll();
} catch (PDOException $e) {
    $upcoming_exams = [];
}

// Top Active Users (Activity logs)
try {
    $stmt = $db->prepare("
        SELECT u.user_id, u.first_name, u.last_name, u.role,
               COUNT(al.log_id) as pending_count
        FROM users u
        LEFT JOIN activity_logs al ON u.user_id = al.user_id
        AND al.created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        WHERE u.school_id = ? AND u.status = 'active'
        GROUP BY u.user_id
        ORDER BY pending_count DESC
        LIMIT 5
    ");
    $stmt->execute([$school_id]);
    $top_active_users = $stmt->fetchAll();
} catch (PDOException $e) {
    $top_active_users = [];
}

include BASE_PATH . '/includes/header.php';

// Check if school is newly set up (no students, classes, or teachers)
$is_new_school = ($stats['total_students'] == 0 && $stats['total_classes'] == 0 && $stats['total_teachers'] == 0);
?>

<!-- Modern Dashboard Styles -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
<style>
    :root {
        --primary-red: #ff6b6b;
        --success-green: #10b981;
        --info-blue: #3b82f6;
        --warning-orange: #f59e0b;
        --purple: #8b5cf6;
        --cyan: #06b6d4;
        --dark-bg: #1a1f2e;
        --card-bg: #252d3d;
        --border-color: rgba(255, 255, 255, 0.1);
    }

    body {
        background: linear-gradient(135deg, #0f1419 0%, #1a1f2e 100%);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #e0e0e0;
    }

    .content-wrapper {
        padding: 25px;
    }

    /* Welcome Banner */
    .welcome-banner {
        background: linear-gradient(135deg, rgba(255, 107, 107, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%);
        border: 1px solid rgba(255, 107, 107, 0.2);
        border-radius: 15px;
        padding: 30px;
        margin-bottom: 30px;
        backdrop-filter: blur(10px);
    }

    .welcome-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }

    .welcome-header h1 {
        font-size: 28px;
        color: #fff;
        font-weight: 600;
    }

    .time-filters {
        display: flex;
        gap: 10px;
    }

    .filter-btn {
        padding: 10px 25px;
        border: 2px solid #FF577F;
        background: transparent;
        color: #FF577F;
        border-radius: 8px;
        cursor: pointer;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .filter-btn.active {
        background: #FF577F;
        color: white;
        box-shadow: 0 4px 12px rgba(255, 87, 127, 0.3);
    }

    /* Stats Grid */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 25px;
        margin-bottom: 30px;
    }

    .stat-card {
        background: var(--card-bg);
        border: 1px solid var(--border-color);
        border-radius: 15px;
        padding: 25px;
        backdrop-filter: blur(10px);
        position: relative;
        overflow: hidden;
        transition: all 0.3s ease;
        border-left: 4px solid var(--border-red);
    }

    .stat-card:nth-child(2) { border-left-color: #00E676; }
    .stat-card:nth-child(3) { border-left-color: #2196F3; }
    .stat-card:nth-child(4) { border-left-color: #00BCD4; }
    .stat-card:nth-child(5) { border-left-color: #9C27B0; }
    .stat-card:nth-child(6) { border-left-color: #2196F3; }

    .stat-card:hover {
        transform: translateY(-5px);
        border-color: rgba(255, 255, 255, 0.2);
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
    }

    .stat-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 15px;
    }

    .stat-icon {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
    }

    .stat-icon.blue { background: rgba(33, 150, 243, 0.15); color: #2196F3; }
    .stat-icon.purple { background: rgba(156, 39, 176, 0.15); color: #9C27B0; }
    .stat-icon.orange { background: rgba(255, 152, 0, 0.15); color: #FF9800; }
    .stat-icon.green { background: rgba(0, 230, 118, 0.15); color: #00E676; }
    .stat-icon.cyan { background: rgba(0, 188, 212, 0.15); color: #00BCD4; }
    .stat-icon.indigo { background: rgba(33, 150, 243, 0.15); color: #2196F3; }
    .stat-icon.yellow { background: rgba(255, 235, 59, 0.15); color: #FFEB3B; }
    .stat-icon.red { background: rgba(255, 87, 87, 0.15); color: #FF5757; }

    .stat-trend {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 12px;
        padding: 4px 8px;
        border-radius: 6px;
        font-weight: 600;
    }

    .stat-trend.up {
        background: rgba(0, 230, 118, 0.15);
        color: #00E676;
    }

    .stat-trend.down {
        background: rgba(255, 87, 87, 0.15);
        color: #FF5757;
    }

    .stat-body h3 {
        font-size: 32px;
        font-weight: 700;
        color: #fff;
        margin: 0 0 5px 0;
    }

    .stat-body p {
        font-size: 14px;
        color: #a0a0a0;
        margin: 0;
    }

    /* Charts Grid */
    .charts-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
        gap: 25px;
        margin-bottom: 30px;
    }

    .chart-card {
        background: linear-gradient(135deg, rgba(30, 35, 50, 0.8) 0%, rgba(20, 25, 40, 0.8) 100%);
        border: 1px solid var(--border-color);
        border-radius: 15px;
        padding: 25px;
        backdrop-filter: blur(10px);
    }

    .chart-title {
        font-size: 18px;
        font-weight: 600;
        color: #fff;
        margin-bottom: 20px;
    }

    .chart-container {
        position: relative;
        height: 300px;
    }

    /* Tables */
    table {
        width: 100%;
        border-collapse: collapse;
    }

    thead {
        background: rgba(255, 255, 255, 0.05);
    }

    th {
        padding: 15px;
        text-align: left;
        font-size: 13px;
        font-weight: 600;
        color: #a0a0a0;
        text-transform: uppercase;
        border-bottom: 1px solid var(--border-color);
    }

    td {
        padding: 15px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        font-size: 13px;
    }

    tr:hover {
        background: rgba(255, 255, 255, 0.05);
    }

    .status-badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 11px;
        font-weight: 600;
    }

    .status-success {
        background: rgba(16, 185, 129, 0.2);
        color: #10b981;
    }

    .status-warning {
        background: rgba(245, 158, 11, 0.2);
        color: #f59e0b;
    }

    .status-danger {
        background: rgba(239, 68, 68, 0.2);
        color: #ef4444;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .stats-grid {
            grid-template-columns: 1fr;
        }

        .charts-grid {
            grid-template-columns: 1fr;
        }

        .welcome-header {
            flex-direction: column;
            align-items: flex-start;
        }

        .time-filters {
            margin-top: 15px;
        }
    }

    /* Animations */
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .stat-card {
        animation: fadeIn 0.6s ease forwards;
    }

    .stat-card:nth-child(1) { animation-delay: 0s; }
    .stat-card:nth-child(2) { animation-delay: 0.1s; }
    .stat-card:nth-child(3) { animation-delay: 0.2s; }
    .stat-card:nth-child(4) { animation-delay: 0.3s; }
    .stat-card:nth-child(5) { animation-delay: 0.4s; }
    .stat-card:nth-child(6) { animation-delay: 0.5s; }
</style>

<!-- Welcome Section with Time Filters -->
<div class="welcome-banner">
    <div class="welcome-header">
        <div>
            <h1>Welcome back, <?php echo htmlspecialchars($current_user['first_name']); ?>! 👋</h1>
            <p style="color: #a0a0a0; margin-top: 5px;">Last login was today • <a href="#" style="color: #ff6b6b; text-decoration: none;">View details</a></p>
        </div>
        <div class="time-filters">
            <button class="filter-btn active" onclick="filterTime('month')">Monthly</button>
            <button class="filter-btn" onclick="filterTime('quarter')">Quarterly</button>
            <button class="filter-btn" onclick="filterTime('year')">Yearly</button>
        </div>
    </div>
</div>

<!-- Stats Cards Grid -->
<div class="stats-grid">
    <!-- Total Students -->
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon blue">
                <i class="fas fa-user-graduate"></i>
            </div>
            <div class="stat-trend up">
                📈 +12.5%
            </div>
        </div>
        <div class="stat-body">
            <h3><?php echo number_format($stats['total_students']); ?></h3>
            <p>Total Students</p>
        </div>
    </div>

    <!-- Total Revenue -->
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon green">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="stat-trend up">
                📈 +23.1%
            </div>
        </div>
        <div class="stat-body">
            <h3><?php echo format_currency($stats['total_revenue']); ?></h3>
            <p>Total Revenue</p>
        </div>
    </div>

    <!-- Pending Payments -->
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon orange">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-trend down">
                📉 -8.2%
            </div>
        </div>
        <div class="stat-body">
            <h3><?php echo format_currency($stats['pending_revenue']); ?></h3>
            <p>Pending Payments</p>
        </div>
    </div>

    <!-- Collection Rate -->
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon cyan">
                <i class="fas fa-percentage"></i>
            </div>
            <div class="stat-trend up">
                📈 +5.3%
            </div>
        </div>
        <div class="stat-body">
            <h3><?php echo $stats['collection_rate']; ?>%</h3>
            <p>Collection Rate</p>
        </div>
    </div>

    <!-- Total Teachers -->
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon purple">
                <i class="fas fa-chalkboard-teacher"></i>
            </div>
        </div>
        <div class="stat-body">
            <h3><?php echo number_format($stats['total_teachers']); ?></h3>
            <p>Total Teachers</p>
        </div>
    </div>

    <!-- Total Classes -->
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon indigo">
                <i class="fas fa-school"></i>
            </div>
        </div>
        <div class="stat-body">
            <h3><?php echo number_format($stats['total_classes']); ?></h3>
            <p>Total Classes</p>
        </div>
    </div>
</div>

<!-- Financial Overview Cards -->
<div class="card" style="margin-top: 30px; margin-bottom: 20px;">
    <div class="card-header">
        <h3><i class="fas fa-chart-line"></i> Financial Overview - This Month</h3>
    </div>
</div>

<div class="stats-grid">
    <!-- This Month Income -->
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon green">
                <i class="fas fa-arrow-circle-up"></i>
            </div>
        </div>
        <div class="stat-body">
            <h3 data-stat="month-income"><?php echo format_currency($stats['month_income']); ?></h3>
            <p>This Month Income</p>
        </div>
    </div>

    <!-- This Month Expenses -->
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon red">
                <i class="fas fa-arrow-circle-down"></i>
            </div>
        </div>
        <div class="stat-body">
            <h3 data-stat="month-expenses"><?php echo format_currency($stats['month_expenditure']); ?></h3>
            <p>This Month Expenses</p>
        </div>
    </div>

    <!-- This Month Revenue (Net) -->
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon blue">
                <i class="fas fa-chart-line"></i>
            </div>
        </div>
        <div class="stat-body">
            <h3 data-stat="month-revenue"><?php echo format_currency($stats['month_income'] - $stats['month_expenditure']); ?></h3>
            <p>This Month Revenue (Net)</p>
        </div>
    </div>

    <!-- Canteen Revenue -->
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon purple">
                <i class="fas fa-utensils"></i>
            </div>
        </div>
        <div class="stat-body">
            <h3 data-stat="canteen-revenue"><?php echo format_currency($stats['canteen_revenue']); ?></h3>
            <p>Canteen Revenue</p>
        </div>
    </div>

    <!-- Bus Fee Revenue -->
    <div class="stat-card">
        <div class="stat-header">
            <div class="stat-icon cyan">
                <i class="fas fa-bus"></i>
            </div>
        </div>
        <div class="stat-body">
            <h3 data-stat="bus-revenue"><?php echo format_currency($stats['bus_revenue']); ?></h3>
            <p>Bus Fee Revenue</p>
        </div>
    </div>
</div>

<!-- ONLINE PAYMENT & TRANSACTION STATISTICS -->
<div class="card" style="margin-top: 30px; margin-bottom: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none;">
    <div style="padding: 25px;">
        <h3 style="margin: 0 0 10px 0; color: white;">
            <i class="fas fa-credit-card"></i> Online Payment System
        </h3>
        <p style="margin: 0; opacity: 0.9; font-size: 14px;">Real-time transaction monitoring and gateway performance</p>
    </div>
</div>

<div class="stats-grid" style="margin-bottom: 30px;">
    <div class="stat-card" style="border-left: 4px solid #667eea;">
        <div class="stat-header">
            <div class="stat-icon" style="background: linear-gradient(135deg, #667eea, #764ba2);">
                <i class="fas fa-mobile-alt"></i>
            </div>
            <div class="stat-trend up">
                <i class="fas fa-arrow-up"></i>
                <span>New</span>
            </div>
        </div>
        <div class="stat-body">
            <h3><?php echo number_format($stats['online_transactions']); ?></h3>
            <p>Online Transactions</p>
            <small style="color: var(--text-secondary); font-size: 12px;">
                <?php echo format_currency($stats['online_revenue']); ?> processed
            </small>
        </div>
    </div>

    <div class="stat-card" style="border-left: 4px solid #f093fb;">
        <div class="stat-header">
            <div class="stat-icon" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
                <i class="fas fa-clock"></i>
            </div>
        </div>
        <div class="stat-body">
            <h3><?php echo number_format($stats['pending_transactions']); ?></h3>
            <p>Pending Transactions</p>
            <small style="color: var(--text-secondary); font-size: 12px;">Awaiting confirmation</small>
        </div>
    </div>

    <div class="stat-card" style="border-left: 4px solid #fa709a;">
        <div class="stat-header">
            <div class="stat-icon" style="background: linear-gradient(135deg, #fa709a, #fee140);">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
        </div>
        <div class="stat-body">
            <h3><?php echo number_format($stats['failed_transactions']); ?></h3>
            <p>Failed Transactions</p>
            <small style="color: var(--text-secondary); font-size: 12px;">Requires attention</small>
        </div>
    </div>

    <div class="stat-card" style="border-left: 4px solid #4facfe;">
        <div class="stat-header">
            <div class="stat-icon" style="background: linear-gradient(135deg, #4facfe, #00f2fe);">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="stat-trend up">
                <i class="fas fa-arrow-up"></i>
                <span><?php echo $stats['today_transactions']; ?></span>
            </div>
        </div>
        <div class="stat-body">
            <h3><?php echo format_currency($stats['today_revenue']); ?></h3>
            <p>Today's Revenue</p>
            <small style="color: var(--text-secondary); font-size: 12px;">
                <?php echo $stats['today_transactions']; ?> transactions
            </small>
        </div>
    </div>
</div>

<!-- Payment Gateway Performance -->
<?php if (!empty($gateway_stats)): ?>
<div class="card" style="margin-bottom: 30px;">
    <div class="card-header">
        <h3><i class="fas fa-chart-pie"></i> Payment Gateway Performance</h3>
        <a href="<?php echo APP_URL; ?>/admin/payment-gateway-settings.php" class="btn btn-sm btn-primary">
            <i class="fas fa-cog"></i> Configure
        </a>
    </div>
    <div style="padding: 20px;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
            <?php foreach ($gateway_stats as $gateway): ?>
                <?php
                $gateway_icon = [
                    'mtn_momo' => ['icon' => 'fa-mobile-alt', 'color' => '#FFCC00', 'name' => 'MTN Mobile Money'],
                    'tigo_cash' => ['icon' => 'fa-money-bill-wave', 'color' => '#0066CC', 'name' => 'Tigo Cash'],
                    'paystack' => ['icon' => 'fa-credit-card', 'color' => '#00C3F7', 'name' => 'PayStack']
                ];
                $info = $gateway_icon[$gateway['gateway_name']] ?? ['icon' => 'fa-wallet', 'color' => '#666', 'name' => ucfirst($gateway['gateway_name'])];
                $success_rate = $gateway['transaction_count'] > 0 ? round(($gateway['successful'] / $gateway['transaction_count']) * 100, 1) : 0;
                ?>
                <div style="background: var(--bg-secondary); border-radius: 12px; padding: 20px; border-left: 4px solid <?php echo $info['color']; ?>;">
                    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 15px;">
                        <div style="width: 50px; height: 50px; border-radius: 10px; background: <?php echo $info['color']; ?>; color: white; display: flex; align-items: center; justify-content: center; font-size: 24px;">
                            <i class="fas <?php echo $info['icon']; ?>"></i>
                        </div>
                        <div>
                            <h4 style="margin: 0; font-size: 16px;"><?php echo $info['name']; ?></h4>
                            <p style="margin: 0; font-size: 12px; color: var(--text-secondary);"><?php echo $gateway['transaction_count']; ?> transactions</p>
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                            <span style="font-size: 12px; color: var(--text-secondary);">Success Rate</span>
                            <strong style="color: var(--success-green);"><?php echo $success_rate; ?>%</strong>
                        </div>
                        <div style="width: 100%; height: 8px; background: var(--bg-primary); border-radius: 4px; overflow: hidden;">
                            <div style="width: <?php echo $success_rate; ?>%; height: 100%; background: var(--success-green); transition: width 0.3s;"></div>
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-top: 15px;">
                        <div style="text-align: center; padding: 10px; background: rgba(0, 214, 143, 0.1); border-radius: 8px;">
                            <div style="font-size: 18px; font-weight: 700; color: var(--success-green);"><?php echo $gateway['successful']; ?></div>
                            <div style="font-size: 10px; color: var(--text-secondary); margin-top: 2px;">Success</div>
                        </div>
                        <div style="text-align: center; padding: 10px; background: rgba(255, 170, 0, 0.1); border-radius: 8px;">
                            <div style="font-size: 18px; font-weight: 700; color: var(--warning-orange);"><?php echo $gateway['pending']; ?></div>
                            <div style="font-size: 10px; color: var(--text-secondary); margin-top: 2px;">Pending</div>
                        </div>
                        <div style="text-align: center; padding: 10px; background: rgba(255, 61, 113, 0.1); border-radius: 8px;">
                            <div style="font-size: 18px; font-weight: 700; color: var(--danger-red);"><?php echo $gateway['failed']; ?></div>
                            <div style="font-size: 10px; color: var(--text-secondary); margin-top: 2px;">Failed</div>
                        </div>
                    </div>
                    
                    <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border-color);">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="font-size: 12px; color: var(--text-secondary);">Total Revenue</span>
                            <strong style="font-size: 18px; color: var(--primary-blue);"><?php echo format_currency($gateway['total_amount']); ?></strong>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Recent Transactions -->
<?php if (!empty($recent_transactions)): ?>
<div class="card" style="margin-bottom: 30px;">
    <div class="card-header">
        <h3><i class="fas fa-receipt"></i> Recent Transactions</h3>
        <a href="<?php echo APP_URL; ?>/accountant/transactions.php" class="btn btn-sm btn-primary">
            <i class="fas fa-eye"></i> View All
        </a>
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Reference</th>
                    <th>Student</th>
                    <th>Amount</th>
                    <th>Gateway</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recent_transactions as $txn): ?>
                    <?php
                    $status_colors = [
                        'completed' => 'success',
                        'pending' => 'warning',
                        'failed' => 'danger'
                    ];
                    $status_color = $status_colors[$txn['status']] ?? 'secondary';
                    
                    $gateway_names = [
                        'mtn_momo' => 'MTN MoMo',
                        'tigo_cash' => 'Tigo Cash',
                        'paystack' => 'PayStack'
                    ];
                    $gateway_display = $gateway_names[$txn['gateway_name']] ?? ucfirst($txn['payment_method']);
                    ?>
                    <tr>
                        <td>
                            <strong style="font-family: monospace; font-size: 12px;"><?php echo htmlspecialchars($txn['reference']); ?></strong>
                        </td>
                        <td>
                            <?php echo htmlspecialchars($txn['student_name'] ?? 'N/A'); ?>
                            <?php if ($txn['admission_number']): ?>
                                <br><small style="color: var(--text-secondary);"><?php echo htmlspecialchars($txn['admission_number']); ?></small>
                            <?php endif; ?>
                        </td>
                        <td><strong><?php echo format_currency($txn['amount']); ?></strong></td>
                        <td>
                            <?php if ($txn['gateway_name']): ?>
                                <span style="padding: 4px 8px; background: var(--bg-secondary); border-radius: 4px; font-size: 11px;">
                                    <?php echo htmlspecialchars($gateway_display); ?>
                                </span>
                            <?php else: ?>
                                <span style="color: var(--text-secondary);">Cash</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge badge-<?php echo $status_color; ?>">
                                <?php echo ucfirst($txn['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('M d, Y H:i', strtotime($txn['created_at'])); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Quick Actions -->
<div class="card" style="margin-bottom: 30px;">
    <div class="card-header">
        <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
    </div>
    <div style="padding: 20px; display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 15px;">
        <a href="<?php echo APP_URL; ?>/admin/students.php" class="btn btn-primary" style="text-decoration: none; text-align: center; padding: 15px;">
            <i class="fas fa-user-plus" style="font-size: 20px;"></i>
            <div style="font-size: 12px; margin-top: 8px; font-weight: 600;">Add Student</div>
        </a>
        <a href="<?php echo APP_URL; ?>/admin/teachers.php" class="btn btn-info" style="text-decoration: none; text-align: center; padding: 15px;">
            <i class="fas fa-chalkboard-user" style="font-size: 20px;"></i>
            <div style="font-size: 12px; margin-top: 8px; font-weight: 600;">Add Teacher</div>
        </a>
        <a href="<?php echo APP_URL; ?>/admin/classes.php" class="btn btn-success" style="text-decoration: none; text-align: center; padding: 15px;">
            <i class="fas fa-book" style="font-size: 20px;"></i>
            <div style="font-size: 12px; margin-top: 8px; font-weight: 600;">Manage Classes</div>
        </a>
        <a href="<?php echo APP_URL; ?>/admin/attendance.php" class="btn btn-warning" style="text-decoration: none; text-align: center; padding: 15px;">
            <i class="fas fa-calendar-check" style="font-size: 20px;"></i>
            <div style="font-size: 12px; margin-top: 8px; font-weight: 600;">Mark Attendance</div>
        </a>
        <a href="<?php echo APP_URL; ?>/admin/reports.php" class="btn btn-danger" style="text-decoration: none; text-align: center; padding: 15px;">
            <i class="fas fa-chart-bar" style="font-size: 20px;"></i>
            <div style="font-size: 12px; margin-top: 8px; font-weight: 600;">View Reports</div>
        </a>
    </div>
</div>

<!-- Charts Row -->
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-bottom: 30px;">
    <!-- Revenue Chart -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-chart-bar"></i> Monthly Revenue</h3>
            <div class="card-actions">
                <select style="padding: 8px 12px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-secondary); color: var(--text-primary);">
                    <option>Last 6 Months</option>
                    <option>Last Year</option>
                </select>
            </div>
        </div>
        <canvas id="revenueChart" height="80"></canvas>
    </div>

    <!-- Attendance Today -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-calendar-check"></i> Today's Attendance</h3>
        </div>
        <canvas id="attendanceChart"></canvas>
        <div style="margin-top: 20px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                <span style="color: var(--text-secondary);">Present</span>
                <strong style="color: var(--success-green);"><?php echo $attendance_today['present'] ?? 0; ?></strong>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                <span style="color: var(--text-secondary);">Absent</span>
                <strong style="color: var(--danger-red);"><?php echo $attendance_today['absent'] ?? 0; ?></strong>
            </div>
            <div style="display: flex; justify-content: space-between;">
                <span style="color: var(--text-secondary);">Late</span>
                <strong style="color: var(--warning-orange);"><?php echo $attendance_today['late'] ?? 0; ?></strong>
            </div>
        </div>
    </div>
</div>

<!-- Second Row - Top Classes and Upcoming Exams -->
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">
    <!-- Top Performing Classes -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-award"></i> Top Performing Classes</h3>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
            <?php if (count($top_classes) > 0): ?>
                <?php foreach ($top_classes as $index => $class): ?>
                    <div style="padding: 15px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span style="width: 30px; height: 30px; border-radius: 50%; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white; display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 12px;">
                                #<?php echo $index + 1; ?>
                            </span>
                            <div>
                                <p style="margin: 0; font-weight: 600;"><?php echo htmlspecialchars($class['class_name']); ?></p>
                                <p style="margin: 0; font-size: 12px; color: var(--text-secondary);"><?php echo $class['students_with_marks']; ?> students</p>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <p style="margin: 0; font-weight: 600; color: var(--primary-blue);"><?php echo number_format($class['average_score'], 1); ?>%</p>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="padding: 30px; text-align: center; color: var(--text-secondary);">
                    <i class="fas fa-inbox" style="font-size: 32px; margin-bottom: 10px; display: block;"></i>
                    No class data available
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Upcoming Exams -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-calendar-alt"></i> Upcoming Exams</h3>
            <a href="exams.php" style="color: var(--primary-blue); text-decoration: none; font-size: 12px;">View All</a>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
            <?php if (count($upcoming_exams) > 0): ?>
                <?php foreach ($upcoming_exams as $exam): ?>
                    <div style="padding: 15px; border-bottom: 1px solid var(--border-color);">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
                            <strong style="font-size: 14px;"><?php echo htmlspecialchars($exam['exam_name']); ?></strong>
                            <span style="font-size: 11px; background: <?php echo $exam['status'] == 'ongoing' ? 'rgba(255, 152, 0, 0.2)' : 'rgba(33, 150, 243, 0.2)'; ?>; padding: 3px 8px; border-radius: 4px; color: <?php echo $exam['status'] == 'ongoing' ? 'var(--warning-orange)' : 'var(--primary-blue)'; ?>;">
                                <?php echo ucfirst($exam['status']); ?>
                            </span>
                        </div>
                        <p style="margin: 0; font-size: 12px; color: var(--text-secondary);">
                            <i class="fas fa-calendar"></i> <?php echo $exam['formatted_date']; ?>
                        </p>
                        <p style="margin: 5px 0 0 0; font-size: 12px; color: var(--text-secondary);">
                            <i class="fas fa-graduation-cap"></i> <?php echo htmlspecialchars($exam['term_name']); ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="padding: 30px; text-align: center; color: var(--text-secondary);">
                    <i class="fas fa-inbox" style="font-size: 32px; margin-bottom: 10px; display: block;"></i>
                    No upcoming exams
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Recent Students Table -->
<div class="card">
    <div class="card-header">
        <h3><i class="fas fa-user-graduate"></i> Recent Admissions</h3>
        <div class="card-actions">
            <a href="students.php" class="btn btn-primary btn-sm">
                <i class="fas fa-eye"></i> View All
            </a>
        </div>
    </div>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Admission No.</th>
                    <th>Student Name</th>
                    <th>Class</th>
                    <th>Gender</th>
                    <th>Admission Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($recent_students) > 0): ?>
                    <?php foreach ($recent_students as $student): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($student['admission_number'] ?? 'N/A'); ?></strong></td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="width: 35px; height: 35px; border-radius: 8px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600;">
                                        <?php 
                                            $fname = $student['first_name'] ?? '-';
                                            $lname = $student['last_name'] ?? '';
                                            echo strtoupper(substr($fname, 0, 1) . substr($lname, 0, 1));
                                        ?>
                                    </div>
                                    <span><?php echo htmlspecialchars(($student['first_name'] ?? '-') . ' ' . ($student['last_name'] ?? '')); ?></span>
                                </div>
                            </td>
                            <td><?php echo htmlspecialchars($student['class_name'] ?? 'Not Assigned'); ?></td>
                            <td><?php echo htmlspecialchars(ucfirst($student['gender'] ?? 'N/A')); ?></td>
                            <td><?php echo !empty($student['admission_date']) && $student['admission_date'] != '0000-00-00' ? date('M d, Y', strtotime($student['admission_date'])) : 'N/A'; ?></td>
                            <td><span class="badge badge-success"><?php echo htmlspecialchars(ucfirst($student['status'] ?? 'active')); ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--text-secondary); padding: 30px;">
                            No recent admissions
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Top Active Users -->
<div class="card" style="margin-top: 30px;">
    <div class="card-header">
        <h3><i class="fas fa-users-cog"></i> Most Active Users (Last 24 Hours)</h3>
    </div>
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px; padding: 20px;">
        <?php if (count($top_active_users) > 0): ?>
            <?php foreach ($top_active_users as $user): ?>
                <div style="padding: 15px; background: var(--bg-secondary); border-radius: 10px; border-left: 4px solid var(--primary-blue);">
                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                        <div style="width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white; display: flex; align-items: center; justify-content: center; font-weight: 600;">
                            <?php echo strtoupper(substr($user['first_name'] ?? 'U', 0, 1)); ?>
                        </div>
                        <div>
                            <p style="margin: 0; font-weight: 600;"><?php echo htmlspecialchars(($user['first_name'] ?? 'User') . ' ' . ($user['last_name'] ?? '')); ?></p>
                            <p style="margin: 0; font-size: 12px; color: var(--text-secondary);"><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $user['role'] ?? 'user'))); ?></p>
                        </div>
                    </div>
                    <div style="background: var(--bg-primary); padding: 10px; border-radius: 6px; text-align: center;">
                        <p style="margin: 0; font-size: 12px; color: var(--text-secondary);">Activities</p>
                        <p style="margin: 5px 0 0 0; font-size: 18px; font-weight: 700; color: var(--primary-blue);"><?php echo $user['pending_count'] ?? 0; ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--text-secondary);">
                <i class="fas fa-inbox" style="font-size: 32px; margin-bottom: 10px; display: block;"></i>
                No activity data
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Revenue Chart
const revenueCtx = document.getElementById('revenueChart').getContext('2d');
const revenueChart = new Chart(revenueCtx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode(array_column($monthly_revenue, 'month')); ?>,
        datasets: [{
            label: 'Revenue',
            data: <?php echo json_encode(array_column($monthly_revenue, 'total')); ?>,
            backgroundColor: 'rgba(45, 91, 255, 0.8)',
            borderColor: 'rgba(45, 91, 255, 1)',
            borderWidth: 2,
            borderRadius: 8
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(0, 0, 0, 0.05)'
                }
            },
            x: {
                grid: {
                    display: false
                }
            }
        }
    }
});

// Attendance Pie Chart
const attendanceCtx = document.getElementById('attendanceChart').getContext('2d');
const attendanceChart = new Chart(attendanceCtx, {
    type: 'doughnut',
    data: {
        labels: ['Present', 'Absent', 'Late'],
        datasets: [{
            data: [
                <?php echo $attendance_today['present'] ?? 0; ?>,
                <?php echo $attendance_today['absent'] ?? 0; ?>,
                <?php echo $attendance_today['late'] ?? 0; ?>
            ],
            backgroundColor: [
                'rgba(0, 214, 143, 0.8)',
                'rgba(255, 61, 113, 0.8)',
                'rgba(255, 170, 0, 0.8)'
            ],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});
</script>

<script>
// Auto-refresh dashboard statistics every 30 seconds
function refreshDashboardStats() {
    fetch('<?php echo APP_URL; ?>/admin/ajax/get-dashboard-stats.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update Total Revenue
                const totalRevenueElement = document.querySelector('[data-stat="total-revenue"]');
                if (totalRevenueElement) {
                    totalRevenueElement.textContent = data.total_revenue_formatted;
                }
                
                // Update This Month Income
                const monthIncomeElement = document.querySelector('[data-stat="month-income"]');
                if (monthIncomeElement) {
                    monthIncomeElement.textContent = data.month_income_formatted;
                }
                
                // Update Collection Rate
                const collectionRateElement = document.querySelector('[data-stat="collection-rate"]');
                if (collectionRateElement) {
                    collectionRateElement.textContent = data.collection_rate + '%';
                }
                
                // Update Pending Revenue
                const pendingRevenueElement = document.querySelector('[data-stat="pending-revenue"]');
                if (pendingRevenueElement) {
                    pendingRevenueElement.textContent = data.pending_revenue_formatted;
                }
                
                // Update Overdue
                const overdueElement = document.querySelector('[data-stat="overdue"]');
                if (overdueElement) {
                    overdueElement.textContent = data.overdue_formatted;
                }
                
                // Update Monthly Expenses
                const monthExpensesElement = document.querySelector('[data-stat="month-expenses"]');
                if (monthExpensesElement) {
                    monthExpensesElement.textContent = data.month_expenditure_formatted;
                }
                
                // Update Canteen Revenue
                const canteenRevenueElement = document.querySelector('[data-stat="canteen-revenue"]');
                if (canteenRevenueElement) {
                    canteenRevenueElement.textContent = data.canteen_revenue_formatted;
                }
                
                // Update Bus Fee Revenue
                const busRevenueElement = document.querySelector('[data-stat="bus-revenue"]');
                if (busRevenueElement) {
                    busRevenueElement.textContent = data.bus_revenue_formatted;
                }
                
                console.log('Dashboard stats updated:', data.timestamp);
            }
        })
        .catch(error => {
            console.error('Error refreshing dashboard stats:', error);
        });
}

// Refresh immediately on load, then every 30 seconds
setTimeout(() => {
    refreshDashboardStats();
    setInterval(refreshDashboardStats, 30000); // 30 seconds
}, 2000); // Wait 2 seconds after page load

// Filter function for time periods
function filterTime(period) {
    const buttons = document.querySelectorAll('.filter-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    console.log('Filtered by:', period);
    // Add AJAX call here to filter data by period if needed
}
</script>

<?php include BASE_PATH . '/includes/footer.php'; ?>
