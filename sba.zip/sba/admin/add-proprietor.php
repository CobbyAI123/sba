<?php
// admin/add-proprietor.php - Add Proprietor
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Add Proprietor';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $email = sanitize_input($_POST['email']);
    $first_name = sanitize_input($_POST['first_name']);
    $last_name = sanitize_input($_POST['last_name']);
    $phone = sanitize_input($_POST['phone'] ?? '');
    $address = sanitize_input($_POST['address'] ?? '');
    $designation = sanitize_input($_POST['designation'] ?? 'Proprietor');
    $joining_date = sanitize_input($_POST['joining_date'] ?? date('Y-m-d'));
    $emergency_contact = sanitize_input($_POST['emergency_contact'] ?? '');
    
    // Validate required fields
    if (empty($email) || empty($first_name) || empty($last_name)) {
        set_message('error', 'Please fill in all required fields');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        set_message('error', 'Invalid email address');
    } else {
        try {
            // Check if email already exists
            $stmt = $db->prepare("SELECT user_id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                throw new Exception('Email already exists');
            }
            
            // Generate username from email
            $username = explode('@', $email)[0];
            // Generate random password
            $password = bin2hex(random_bytes(4)); // 8 character password
            
            // Insert into users table
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("
                INSERT INTO users (username, email, password_hash, first_name, last_name, phone, address, role, school_id, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'proprietor', ?, 'active', NOW())
            ");
            $stmt->execute([$username, $email, $password_hash, $first_name, $last_name, $phone, $address, $school_id]);
            $user_id = $db->lastInsertId();
            
            // Log activity
            log_activity($current_user['user_id'], "Added new proprietor: $first_name $last_name", 'users', $user_id);
            
            set_message('success', "Proprietor added successfully! Login: $email | Password: $password");
            redirect(APP_URL . '/admin/proprietors.php');
        } catch (Exception $e) {
            set_message('error', $e->getMessage());
        }
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fas fa-crown"></i>  Manage Proprietors</h1>
    </div>

    <style>
    .form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
        margin-bottom: 20px;
    }
    
    .form-section {
        background: #F9FAFB;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 20px;
    }
    
    .form-section h3 {
        margin: 0 0 15px 0;
        color: #1F2937;
        font-size: 18px;
        border-bottom: 2px solid #E5E7EB;
        padding-bottom: 10px;
    }
    </style>
    
    <!-- Page Header -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <div>
            
            <p style="margin: 0; color: var(--text-secondary);">Add and manage proprietors</p>
        </div>
        <button onclick="showAddModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add Proprietor
        </button>
    </div>
    
    <!-- Redirect to proprietors page -->
    <script>
        window.location.href = '<?php echo APP_URL; ?>/admin/proprietors.php';
    </script>
    
    <!-- Add Proprietor Modal -->
    <div id="proprietorModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 700px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle"><i class="fas fa-crown"></i> Add Proprietor</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="proprietorForm">
                <!-- Personal Information -->
                <div class="form-grid">
                    <div class="form-group">
                        <label for="first_name">First Name <span style="color: red;">*</span></label>
                        <input type="text" id="first_name" name="first_name" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name <span style="color: red;">*</span></label>
                        <input type="text" id="last_name" name="last_name" class="form-control" required>
                    </div>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="email">Email Address <span style="color: red;">*</span></label>
                        <input type="email" id="email" name="email" class="form-control" required>
                        <small style="color: #6B7280;">Will be used as login username</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="phone" class="form-control">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea id="address" name="address" class="form-control" rows="2"></textarea>
                </div>
                
                <!-- Professional Information -->
                <div class="form-grid">
                    <div class="form-group">
                        <label for="designation">Designation</label>
                        <input type="text" id="designation" name="designation" class="form-control" value="Proprietor">
                    </div>
                    
                    <div class="form-group">
                        <label for="joining_date">Joining Date</label>
                        <input type="date" id="joining_date" name="joining_date" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="emergency_contact">Emergency Contact</label>
                    <input type="tel" id="emergency_contact" name="emergency_contact" class="form-control">
                </div>
                
                <!-- Info Alert -->
                <div class="alert alert-info" style="margin-top: 20px;">
                    <i class="fas fa-info-circle"></i>
                    <strong>Note:</strong> Login credentials will be auto-generated and displayed after creation.
                </div>
                
                <!-- Submit Buttons -->
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 30px;">
                    <button type="button" onclick="closeModal()" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Add Proprietor
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showAddModal() {
        document.getElementById('proprietorModal').style.display = 'block';
        document.getElementById('proprietorForm').reset();
    }
    
    function closeModal() {
        document.getElementById('proprietorModal').style.display = 'none';
    }
    
    // Close modal on outside click
    document.getElementById('proprietorModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
