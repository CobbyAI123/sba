<?php
// admin/fee-categories.php - Manage Fee Categories
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Fee Categories';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$user_id = $current_user['user_id'];

// Handle actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('error', 'Invalid request');
        redirect(APP_URL . '/admin/fee-categories.php');
        exit;
    }
    
    if ($_POST['action'] == 'add_category') {
        $category_name = sanitize_input($_POST['category_name']);
        $description = sanitize_input($_POST['description']);
        $is_mandatory = isset($_POST['is_mandatory']) ? 1 : 0;
        
        try {
            $stmt = $db->prepare("
                INSERT INTO fee_categories (school_id, category_name, description, is_mandatory, status)
                VALUES (?, ?, ?, ?, 'active')
            ");
            $stmt->execute([$school_id, $category_name, $description, $is_mandatory]);
            
            log_activity($user_id, "Added fee category: $category_name", 'fee_categories', $db->lastInsertId());
            set_message('success', 'Category added successfully!');
            
        } catch (PDOException $e) {
            set_message('error', 'Error: ' . $e->getMessage());
        }
        redirect(APP_URL . '/admin/fee-categories.php');
    }
}

// Get categories
$stmt = $db->prepare("
    SELECT fc.*, COUNT(DISTINCT fs.structure_id) as structure_count
    FROM fee_categories fc
    LEFT JOIN fee_structure fs ON fc.category_id = fs.category_id
    WHERE fc.school_id = ?
    GROUP BY fc.category_id
    ORDER BY fc.category_name
");
$stmt->execute([$school_id]);
$categories = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .category-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 15px;
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.7);
        z-index: 9999;
    }
    
    .modal-content {
        max-width: 500px;
        margin: 50px auto;
        background: var(--bg-card);
        border-radius: 15px;
        padding: 30px;
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-list"></i> Fee Categories</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Manage types of fees charged
        </p>
    </div>
    
    <div style="margin-bottom: 20px;">
        <button onclick="showModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add Category
        </button>
        <a href="<?php echo APP_URL; ?>/admin/manage-fees.php" class="btn btn-secondary">
            <i class="fas fa-money-bill-wave"></i> Fee Structure
        </a>
    </div>
    
    <?php foreach ($categories as $cat): ?>
        <div class="category-card">
            <div style="display: flex; justify-content: space-between; align-items: start;">
                <div style="flex: 1;">
                    <h3 style="margin: 0 0 10px 0;">
                        <?php echo htmlspecialchars($cat['category_name']); ?>
                        <?php if ($cat['is_mandatory']): ?>
                            <span style="background: rgba(255, 59, 48, 0.1); color: #FF3B30; padding: 3px 8px; border-radius: 8px; font-size: 11px; margin-left: 10px;">
                                MANDATORY
                            </span>
                        <?php endif; ?>
                    </h3>
                    <?php if ($cat['description']): ?>
                        <p style="margin: 0 0 10px 0; color: var(--text-secondary);">
                            <?php echo htmlspecialchars($cat['description']); ?>
                        </p>
                    <?php endif; ?>
                    <div style="font-size: 13px; color: var(--text-secondary);">
                        <strong>Used in:</strong> <?php echo $cat['structure_count']; ?> fee structure(s)
                    </div>
                </div>
                <span class="status-badge" style="background: rgba(52, 199, 89, 0.1); color: #34C759;">
                    Active
                </span>
            </div>
        </div>
    <?php endforeach; ?>
    
    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <h2 style="margin: 0 0 20px 0;"><i class="fas fa-plus"></i> Add Fee Category</h2>
            
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="add_category">
                
                <div class="form-group">
                    <label>Category Name *</label>
                    <input type="text" name="category_name" required placeholder="e.g., Tuition Fee">
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="3" placeholder="Brief description..."></textarea>
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="is_mandatory" checked>
                        <span>Mandatory for all students</span>
                    </label>
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Category</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showModal() {
        document.getElementById('addModal').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('addModal').style.display = 'none';
    }
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
