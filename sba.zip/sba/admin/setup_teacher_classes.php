<?php
// admin/setup_teacher_classes.php - Setup Teacher Classes Table
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['super_admin']);
$db = Database::getInstance()->getConnection();

try {
    // Create teacher_classes table
    $db->exec("
        CREATE TABLE IF NOT EXISTS `teacher_classes` (
            `id` INT PRIMARY KEY AUTO_INCREMENT,
            `school_id` INT NOT NULL,
            `teacher_id` INT NOT NULL,
            `class_id` INT NOT NULL,
            `is_class_teacher` BOOLEAN DEFAULT FALSE,
            `assigned_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY `unique_assignment` (`teacher_id`, `class_id`, `school_id`),
            FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
            FOREIGN KEY (`teacher_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
            FOREIGN KEY (`class_id`) REFERENCES `classes`(`class_id`) ON DELETE CASCADE
        )
    ");
    
    // Create indexes
    try {
        $db->exec("CREATE INDEX idx_teacher_classes_school ON `teacher_classes`(`school_id`)");
    } catch (PDOException $e) {
    }
    try {
        $db->exec("CREATE INDEX idx_teacher_classes_teacher ON `teacher_classes`(`teacher_id`)");
    } catch (PDOException $e) {
    }
    try {
        $db->exec("CREATE INDEX idx_teacher_classes_class ON `teacher_classes`(`class_id`)");
    } catch (PDOException $e) {
    }
    
    echo "<div style='padding: 20px; background: #d4edda; color: #155724; border-radius: 5px; margin: 20px;'>";
    echo "<h3>✓ Database Setup Complete!</h3>";
    echo "<p>The teacher_classes table has been created successfully.</p>";
    echo "<p><a href='" . APP_URL . "/admin/dashboard.php' style='color: #155724; text-decoration: underline;'>Return to Dashboard</a></p>";
    echo "</div>";
} catch (PDOException $e) {
    echo "<div style='padding: 20px; background: #f8d7da; color: #721c24; border-radius: 5px; margin: 20px;'>";
    echo "<h3>✗ Error</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p><a href='" . APP_URL . "/admin/dashboard.php' style='color: #721c24; text-decoration: underline;'>Return to Dashboard</a></p>";
    echo "</div>";
}
?>
