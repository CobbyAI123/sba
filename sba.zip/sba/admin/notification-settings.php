<?php
// admin/notification-settings.php - Notification System Settings
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Notification Settings';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('error', 'Invalid request. Please try again.');
        redirect(APP_URL . '/admin/notification-settings.php');
        exit;
    }
    
    if ($_POST['action'] == 'update_settings') {
        try {
            // SMS Settings
            $sms_enabled = isset($_POST['sms_enabled']) ? 1 : 0;
            $sms_gateway = sanitize_input($_POST['sms_gateway'] ?? '');
            $sms_api_key = sanitize_input($_POST['sms_api_key'] ?? '');
            $sms_api_secret = sanitize_input($_POST['sms_api_secret'] ?? '');
            $sms_sender_id = sanitize_input($_POST['sms_sender_id'] ?? '');
            
            // Email Settings
            $email_enabled = isset($_POST['email_enabled']) ? 1 : 0;
            $smtp_host = sanitize_input($_POST['smtp_host'] ?? '');
            $smtp_port = (int)($_POST['smtp_port'] ?? 587);
            $smtp_username = sanitize_input($_POST['smtp_username'] ?? '');
            $smtp_password = sanitize_input($_POST['smtp_password'] ?? '');
            $smtp_encryption = sanitize_input($_POST['smtp_encryption'] ?? 'tls');
            $email_from_address = sanitize_input($_POST['email_from_address'] ?? '');
            $email_from_name = sanitize_input($_POST['email_from_name'] ?? '');
            
            // Auto Notifications
            $auto_absence = isset($_POST['auto_absence_notification']) ? 1 : 0;
            $auto_fee = isset($_POST['auto_fee_reminder']) ? 1 : 0;
            $auto_result = isset($_POST['auto_result_notification']) ? 1 : 0;
            $auto_exam = isset($_POST['auto_exam_reminder']) ? 1 : 0;
            
            // Update or insert settings
            $stmt = $db->prepare("
                INSERT INTO notification_settings 
                (school_id, sms_enabled, sms_gateway, sms_api_key, sms_api_secret, sms_sender_id,
                 email_enabled, smtp_host, smtp_port, smtp_username, smtp_password, smtp_encryption,
                 email_from_address, email_from_name, auto_absence_notification, auto_fee_reminder,
                 auto_result_notification, auto_exam_reminder)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                sms_enabled = VALUES(sms_enabled),
                sms_gateway = VALUES(sms_gateway),
                sms_api_key = VALUES(sms_api_key),
                sms_api_secret = VALUES(sms_api_secret),
                sms_sender_id = VALUES(sms_sender_id),
                email_enabled = VALUES(email_enabled),
                smtp_host = VALUES(smtp_host),
                smtp_port = VALUES(smtp_port),
                smtp_username = VALUES(smtp_username),
                smtp_password = VALUES(smtp_password),
                smtp_encryption = VALUES(smtp_encryption),
                email_from_address = VALUES(email_from_address),
                email_from_name = VALUES(email_from_name),
                auto_absence_notification = VALUES(auto_absence_notification),
                auto_fee_reminder = VALUES(auto_fee_reminder),
                auto_result_notification = VALUES(auto_result_notification),
                auto_exam_reminder = VALUES(auto_exam_reminder)
            ");
            
            $stmt->execute([
                $school_id, $sms_enabled, $sms_gateway, $sms_api_key, $sms_api_secret, $sms_sender_id,
                $email_enabled, $smtp_host, $smtp_port, $smtp_username, $smtp_password, $smtp_encryption,
                $email_from_address, $email_from_name, $auto_absence, $auto_fee, $auto_result, $auto_exam
            ]);
            
            log_activity($current_user['user_id'], 'Updated notification settings', 'notification_settings', $school_id);
            set_message('success', 'Notification settings updated successfully!');
            redirect(APP_URL . '/admin/notification-settings.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error updating settings: ' . $e->getMessage());
        }
    }
}

// Get current settings
$stmt = $db->prepare("SELECT * FROM notification_settings WHERE school_id = ?");
$stmt->execute([$school_id]);
$settings = $stmt->fetch();

if (!$settings) {
    // Create default settings
    $stmt = $db->prepare("
        INSERT INTO notification_settings (school_id, email_enabled, in_app_enabled)
        VALUES (?, 1, 1)
    ");
    $stmt->execute([$school_id]);
    
    $stmt = $db->prepare("SELECT * FROM notification_settings WHERE school_id = ?");
    $stmt->execute([$school_id]);
    $settings = $stmt->fetch();
}

// Get notification stats
$stmt = $db->prepare("
    SELECT 
        notification_type,
        COUNT(*) as total,
        SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
        SUM(cost) as total_cost
    FROM notification_history
    WHERE school_id = ? AND sent_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY notification_type
");
$stmt->execute([$school_id]);
$stats = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .settings-card {
        background: var(--bg-card);
        border-radius: 15px;
        padding: 25px;
        border: 1px solid var(--border-color);
        margin-bottom: 25px;
    }
    
    .settings-section {
        margin-bottom: 30px;
    }
    
    .settings-section h3 {
        margin: 0 0 20px 0;
        padding-bottom: 10px;
        border-bottom: 2px solid var(--border-color);
    }
    
    .form-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
    }
    
    .toggle-switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 30px;
    }
    
    .toggle-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .4s;
        border-radius: 30px;
    }
    
    .slider:before {
        position: absolute;
        content: "";
        height: 22px;
        width: 22px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
    }
    
    input:checked + .slider {
        background-color: var(--primary-blue);
    }
    
    input:checked + .slider:before {
        transform: translateX(30px);
    }
    
    .info-box {
        background: rgba(45, 91, 255, 0.1);
        border-left: 4px solid var(--primary-blue);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    
    .stat-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 25px;
    }
    
    .stat-card {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        color: white;
        padding: 20px;
        border-radius: 12px;
        text-align: center;
    }
    
    .stat-card h3 {
        margin: 0;
        font-size: 32px;
        border: none;
        padding: 0;
    }
    
    .stat-card p {
        margin: 5px 0 0 0;
        opacity: 0.9;
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-bell"></i> Notification Settings</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Configure SMS, Email, and automated notification settings
        </p>
    </div>
    
    <!-- Statistics -->
    <?php if (count($stats) > 0): ?>
    <div class="stat-grid">
        <?php foreach ($stats as $stat): ?>
            <div class="stat-card">
                <h3><?php echo number_format($stat['total']); ?></h3>
                <p><?php echo ucfirst($stat['notification_type']); ?> (30 days)</p>
                <p style="font-size: 12px;">✓ <?php echo $stat['sent']; ?> | ✗ <?php echo $stat['failed']; ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    
    <form method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="update_settings">
        
        <!-- SMS Settings -->
        <div class="settings-card">
            <div class="settings-section">
                <h3><i class="fas fa-sms"></i> SMS Settings</h3>
                
                <div class="info-box">
                    <i class="fas fa-info-circle"></i>
                    <strong>SMS Gateway Integration:</strong> Configure your SMS provider to send automated notifications.
                    Supported: Twilio, Africa's Talking, Nexmo.
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <label class="toggle-switch">
                            <input type="checkbox" name="sms_enabled" <?php echo $settings['sms_enabled'] ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                        <span>Enable SMS Notifications</span>
                    </label>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>SMS Gateway Provider</label>
                        <select name="sms_gateway">
                            <option value="">-- Select Gateway --</option>
                            <option value="twilio" <?php echo $settings['sms_gateway'] == 'twilio' ? 'selected' : ''; ?>>Twilio</option>
                            <option value="africastalking" <?php echo $settings['sms_gateway'] == 'africastalking' ? 'selected' : ''; ?>>Africa's Talking</option>
                            <option value="nexmo" <?php echo $settings['sms_gateway'] == 'nexmo' ? 'selected' : ''; ?>>Nexmo/Vonage</option>
                            <option value="custom" <?php echo $settings['sms_gateway'] == 'custom' ? 'selected' : ''; ?>>Custom</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Sender ID / Phone Number</label>
                        <input type="text" name="sms_sender_id" value="<?php echo htmlspecialchars($settings['sms_sender_id'] ?? ''); ?>" 
                               placeholder="e.g., SCHOOL or +1234567890">
                    </div>
                    
                    <div class="form-group">
                        <label>API Key / Account SID</label>
                        <input type="text" name="sms_api_key" value="<?php echo htmlspecialchars($settings['sms_api_key'] ?? ''); ?>" 
                               placeholder="Enter API Key">
                    </div>
                    
                    <div class="form-group">
                        <label>API Secret / Auth Token</label>
                        <input type="password" name="sms_api_secret" value="<?php echo htmlspecialchars($settings['sms_api_secret'] ?? ''); ?>" 
                               placeholder="Enter API Secret">
                    </div>
                </div>
                
                <?php if ($settings['sms_balance']): ?>
                <div style="margin-top: 15px; padding: 10px; background: rgba(52, 199, 89, 0.1); border-radius: 8px;">
                    <strong>Current Balance:</strong> $<?php echo number_format($settings['sms_balance'], 2); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Email Settings -->
        <div class="settings-card">
            <div class="settings-section">
                <h3><i class="fas fa-envelope"></i> Email Settings (SMTP)</h3>
                
                <div class="info-box">
                    <i class="fas fa-info-circle"></i>
                    <strong>SMTP Configuration:</strong> Use your email provider's SMTP settings. 
                    Gmail, Outlook, or custom SMTP server supported.
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <label class="toggle-switch">
                            <input type="checkbox" name="email_enabled" <?php echo $settings['email_enabled'] ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                        <span>Enable Email Notifications</span>
                    </label>
                </div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>SMTP Host</label>
                        <input type="text" name="smtp_host" value="<?php echo htmlspecialchars($settings['smtp_host'] ?? ''); ?>" 
                               placeholder="e.g., smtp.gmail.com">
                    </div>
                    
                    <div class="form-group">
                        <label>SMTP Port</label>
                        <input type="number" name="smtp_port" value="<?php echo $settings['smtp_port'] ?? 587; ?>" 
                               placeholder="587">
                    </div>
                    
                    <div class="form-group">
                        <label>SMTP Username</label>
                        <input type="text" name="smtp_username" value="<?php echo htmlspecialchars($settings['smtp_username'] ?? ''); ?>" 
                               placeholder="your-email@gmail.com">
                    </div>
                    
                    <div class="form-group">
                        <label>SMTP Password</label>
                        <input type="password" name="smtp_password" value="<?php echo htmlspecialchars($settings['smtp_password'] ?? ''); ?>" 
                               placeholder="App Password">
                    </div>
                    
                    <div class="form-group">
                        <label>Encryption</label>
                        <select name="smtp_encryption">
                            <option value="none" <?php echo $settings['smtp_encryption'] == 'none' ? 'selected' : ''; ?>>None</option>
                            <option value="ssl" <?php echo $settings['smtp_encryption'] == 'ssl' ? 'selected' : ''; ?>>SSL</option>
                            <option value="tls" <?php echo $settings['smtp_encryption'] == 'tls' ? 'selected' : ''; ?>>TLS (Recommended)</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>From Email Address</label>
                        <input type="email" name="email_from_address" value="<?php echo htmlspecialchars($settings['email_from_address'] ?? ''); ?>" 
                               placeholder="noreply@school.com">
                    </div>
                    
                    <div class="form-group">
                        <label>From Name</label>
                        <input type="text" name="email_from_name" value="<?php echo htmlspecialchars($settings['email_from_name'] ?? ''); ?>" 
                               placeholder="School Name">
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Auto Notifications -->
        <div class="settings-card">
            <div class="settings-section">
                <h3><i class="fas fa-robot"></i> Automated Notifications</h3>
                
                <div class="info-box">
                    <i class="fas fa-info-circle"></i>
                    <strong>Automatic Triggers:</strong> These notifications will be sent automatically when certain events occur.
                </div>
                
                <div style="display: grid; gap: 15px;">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <label class="toggle-switch">
                            <input type="checkbox" name="auto_absence_notification" <?php echo $settings['auto_absence_notification'] ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                        <span><strong>Absence Alerts:</strong> Notify parents when student is marked absent</span>
                    </label>
                    
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <label class="toggle-switch">
                            <input type="checkbox" name="auto_fee_reminder" <?php echo $settings['auto_fee_reminder'] ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                        <span><strong>Fee Reminders:</strong> Automatic reminders for outstanding fees</span>
                    </label>
                    
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <label class="toggle-switch">
                            <input type="checkbox" name="auto_result_notification" <?php echo $settings['auto_result_notification'] ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                        <span><strong>Result Notifications:</strong> Alert when exam results are published</span>
                    </label>
                    
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <label class="toggle-switch">
                            <input type="checkbox" name="auto_exam_reminder" <?php echo $settings['auto_exam_reminder'] ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                        <span><strong>Exam Reminders:</strong> Notify students/parents before exams</span>
                    </label>
                </div>
            </div>
        </div>
        
        <!-- Submit Button -->
        <div style="text-align: center; margin-top: 25px;">
            <button type="submit" class="btn btn-primary" style="padding: 15px 50px; font-size: 16px;">
                <i class="fas fa-save"></i> Save Settings
            </button>
        </div>
    </form>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
