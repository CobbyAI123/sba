<?php
// admin/library-books.php - Library Book Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Library Books';
$current_user = check_permission(['admin', 'librarian']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$user_id = $current_user['user_id'];

// Handle book actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('error', 'Invalid request. Please try again.');
        redirect(APP_URL . '/admin/library-books.php');
        exit;
    }
    
    if ($_POST['action'] == 'add_book') {
        $isbn = sanitize_input($_POST['isbn']);
        $title = sanitize_input($_POST['title']);
        $author = sanitize_input($_POST['author']);
        $publisher = sanitize_input($_POST['publisher']);
        $category = sanitize_input($_POST['category']);
        $edition = sanitize_input($_POST['edition']);
        $publication_year = (int)$_POST['publication_year'];
        $total_copies = (int)$_POST['total_copies'];
        $book_location = sanitize_input($_POST['book_location']);
        $description = sanitize_input($_POST['description']);
        $price = (float)$_POST['price'];
        
        try {
            $stmt = $db->prepare("
                INSERT INTO library_books 
                (school_id, isbn, title, author, publisher, category, edition, publication_year, 
                 total_copies, available_copies, book_location, description, price, added_by, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'available')
            ");
            
            $stmt->execute([
                $school_id, $isbn, $title, $author, $publisher, $category, $edition, $publication_year,
                $total_copies, $total_copies, $book_location, $description, $price, $user_id
            ]);
            
            log_activity($user_id, "Added book: $title", 'library_books', $db->lastInsertId());
            set_message('success', 'Book added successfully!');
            redirect(APP_URL . '/admin/library-books.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error adding book: ' . $e->getMessage());
        }
    } elseif ($_POST['action'] == 'delete_book') {
        $book_id = (int)$_POST['book_id'];
        
        try {
            // Check if book has active issues
            $stmt = $db->prepare("SELECT COUNT(*) as active_issues FROM library_issues WHERE book_id = ? AND status = 'issued'");
            $stmt->execute([$book_id]);
            $active = $stmt->fetch();
            
            if ($active['active_issues'] > 0) {
                set_message('error', 'Cannot delete book with active issues');
            } else {
                $stmt = $db->prepare("DELETE FROM library_books WHERE book_id = ? AND school_id = ?");
                $stmt->execute([$book_id, $school_id]);
                
                log_activity($user_id, "Deleted book ID: $book_id", 'library_books', $book_id);
                set_message('success', 'Book deleted successfully!');
            }
            
            redirect(APP_URL . '/admin/library-books.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error deleting book: ' . $e->getMessage());
        }
    }
}

// Get search/filter parameters
$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$category_filter = isset($_GET['category']) ? sanitize_input($_GET['category']) : '';

// Build query
$query = "
    SELECT 
        lb.*,
        (lb.total_copies - lb.available_copies) as issued_copies,
        COUNT(DISTINCT CASE WHEN li.status = 'issued' THEN li.issue_id END) as current_issues
    FROM library_books lb
    LEFT JOIN library_issues li ON lb.book_id = li.book_id
    WHERE lb.school_id = ?
";

$params = [$school_id];

if ($search) {
    $query .= " AND (lb.title LIKE ? OR lb.author LIKE ? OR lb.isbn LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

if ($category_filter) {
    $query .= " AND lb.category = ?";
    $params[] = $category_filter;
}

$query .= " GROUP BY lb.book_id ORDER BY lb.title";

$stmt = $db->prepare($query);
$stmt->execute($params);
$books = $stmt->fetchAll();

// Get categories for filter
$stmt = $db->prepare("SELECT DISTINCT category_name FROM library_categories WHERE school_id = ? ORDER BY category_name");
$stmt->execute([$school_id]);
$categories = $stmt->fetchAll();

// Statistics
$total_books = count($books);
$total_copies = array_sum(array_column($books, 'total_copies'));
$available = array_sum(array_column($books, 'available_copies'));
$issued = $total_copies - $available;

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .book-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 15px;
        display: flex;
        gap: 20px;
        transition: all 0.3s ease;
    }
    
    .book-card:hover {
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        border-color: var(--primary-blue);
    }
    
    .book-cover {
        width: 80px;
        height: 120px;
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 48px;
        flex-shrink: 0;
    }
    
    .book-details {
        flex: 1;
    }
    
    .availability-badge {
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .badge-available {
        background: rgba(52, 199, 89, 0.1);
        color: #34C759;
    }
    
    .badge-limited {
        background: rgba(255, 149, 0, 0.1);
        color: #FF9500;
    }
    
    .badge-unavailable {
        background: rgba(255, 59, 48, 0.1);
        color: #FF3B30;
    }
    
    .search-bar {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
        padding: 20px;
        background: var(--bg-card);
        border-radius: 15px;
        border: 1px solid var(--border-color);
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.7);
        z-index: 9999;
        overflow-y: auto;
    }
    
    .modal-content {
        max-width: 700px;
        margin: 30px auto;
        background: var(--bg-card);
        border-radius: 15px;
        padding: 30px;
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-book"></i> Library Books</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Manage your school library catalog
        </p>
    </div>
    
    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 25px;">
        <div style="background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $total_books; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Titles</p>
        </div>
        <div style="background: linear-gradient(135deg, #5856D6, #5E5CE6); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $total_copies; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Copies</p>
        </div>
        <div style="background: linear-gradient(135deg, #34C759, #30D158); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $available; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Available</p>
        </div>
        <div style="background: linear-gradient(135deg, #FF9500, #FF9F0A); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $issued; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Issued</p>
        </div>
    </div>
    
    <!-- Search & Filter -->
    <form method="GET" class="search-bar">
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
               placeholder="Search by title, author, or ISBN..." style="flex: 1;">
        <select name="category" style="min-width: 150px;">
            <option value="">All Categories</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?php echo htmlspecialchars($cat['category_name']); ?>" 
                        <?php echo $category_filter == $cat['category_name'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($cat['category_name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-search"></i> Search
        </button>
        <?php if ($search || $category_filter): ?>
            <a href="<?php echo APP_URL; ?>/admin/library-books.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Clear
            </a>
        <?php endif; ?>
    </form>
    
    <!-- Actions -->
    <div style="margin-bottom: 20px;">
        <button onclick="showAddModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add New Book
        </button>
        <a href="<?php echo APP_URL; ?>/admin/library-issues.php" class="btn btn-success">
            <i class="fas fa-exchange-alt"></i> Issue/Return Books
        </a>
    </div>
    
    <!-- Books List -->
    <?php if (count($books) > 0): ?>
        <?php foreach ($books as $book): 
            $availability_percentage = $book['total_copies'] > 0 
                ? ($book['available_copies'] / $book['total_copies']) * 100 
                : 0;
            
            if ($book['available_copies'] == 0) {
                $badge_class = 'unavailable';
                $badge_text = 'All Issued';
            } elseif ($availability_percentage < 50) {
                $badge_class = 'limited';
                $badge_text = 'Limited';
            } else {
                $badge_class = 'available';
                $badge_text = 'Available';
            }
        ?>
            <div class="book-card">
                <div class="book-cover">
                    <i class="fas fa-book"></i>
                </div>
                
                <div class="book-details">
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 10px;">
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 5px;">
                                <h3 style="margin: 0;"><?php echo htmlspecialchars($book['title']); ?></h3>
                                <span class="availability-badge badge-<?php echo $badge_class; ?>">
                                    <?php echo $badge_text; ?>
                                </span>
                            </div>
                            <p style="margin: 0 0 5px 0; color: var(--text-secondary);">
                                <i class="fas fa-user"></i> <?php echo htmlspecialchars($book['author']); ?>
                                <?php if ($book['isbn']): ?>
                                    | <i class="fas fa-barcode"></i> <?php echo htmlspecialchars($book['isbn']); ?>
                                <?php endif; ?>
                            </p>
                            <p style="margin: 0; font-size: 13px; color: var(--text-secondary);">
                                <?php if ($book['publisher']): ?>
                                    <i class="fas fa-building"></i> <?php echo htmlspecialchars($book['publisher']); ?> 
                                <?php endif; ?>
                                <?php if ($book['publication_year']): ?>
                                    | <?php echo $book['publication_year']; ?>
                                <?php endif; ?>
                                <?php if ($book['category']): ?>
                                    | <i class="fas fa-tag"></i> <?php echo htmlspecialchars($book['category']); ?>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div style="display: flex; gap: 5px;">
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this book?')">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="delete_book">
                                <input type="hidden" name="book_id" value="<?php echo $book['book_id']; ?>">
                                <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                    
                    <?php if ($book['description']): ?>
                        <div style="background: rgba(0,0,0,0.02); padding: 10px; border-radius: 8px; margin-bottom: 10px;">
                            <p style="margin: 0; font-size: 13px; line-height: 1.5;">
                                <?php echo nl2br(htmlspecialchars(substr($book['description'], 0, 200))); ?>
                                <?php if (strlen($book['description']) > 200): ?>...<?php endif; ?>
                            </p>
                        </div>
                    <?php endif; ?>
                    
                    <div style="display: flex; gap: 20px; padding-top: 10px; border-top: 1px solid var(--border-color); font-size: 13px;">
                        <div>
                            <strong>Total Copies:</strong> <?php echo $book['total_copies']; ?>
                        </div>
                        <div>
                            <strong>Available:</strong> 
                            <span style="color: <?php echo $book['available_copies'] > 0 ? '#34C759' : '#FF3B30'; ?>;">
                                <?php echo $book['available_copies']; ?>
                            </span>
                        </div>
                        <div>
                            <strong>Issued:</strong> <?php echo $book['issued_copies']; ?>
                        </div>
                        <?php if ($book['book_location']): ?>
                            <div>
                                <strong>Location:</strong> <?php echo htmlspecialchars($book['book_location']); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($book['price']): ?>
                            <div>
                                <strong>Price:</strong> $<?php echo number_format($book['price'], 2); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div style="text-align: center; padding: 60px; background: var(--bg-card); border-radius: 15px;">
            <i class="fas fa-book" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
            <h3 style="color: var(--text-secondary);">No Books Found</h3>
            <p style="color: var(--text-secondary);">
                <?php echo $search ? 'Try a different search term' : 'Add books to start building your library'; ?>
            </p>
        </div>
    <?php endif; ?>
    
    <!-- Add Book Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="margin: 0;"><i class="fas fa-plus"></i> Add New Book</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="add_book">
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <div class="form-group">
                        <label>Title *</label>
                        <input type="text" name="title" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Author *</label>
                        <input type="text" name="author" required>
                    </div>
                    
                    <div class="form-group">
                        <label>ISBN</label>
                        <input type="text" name="isbn">
                    </div>
                    
                    <div class="form-group">
                        <label>Publisher</label>
                        <input type="text" name="publisher">
                    </div>
                    
                    <div class="form-group">
                        <label>Category</label>
                        <select name="category">
                            <option value="">-- Select Category --</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo htmlspecialchars($cat['category_name']); ?>">
                                    <?php echo htmlspecialchars($cat['category_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Edition</label>
                        <input type="text" name="edition">
                    </div>
                    
                    <div class="form-group">
                        <label>Publication Year</label>
                        <input type="number" name="publication_year" min="1900" max="<?php echo date('Y'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Total Copies *</label>
                        <input type="number" name="total_copies" value="1" min="1" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Location (Shelf/Section)</label>
                        <input type="text" name="book_location" placeholder="e.g., A-12">
                    </div>
                    
                    <div class="form-group">
                        <label>Price</label>
                        <input type="number" name="price" step="0.01" min="0">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="3" placeholder="Brief description of the book..."></textarea>
                </div>
                
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check"></i> Add Book
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showAddModal() {
        document.getElementById('addModal').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('addModal').style.display = 'none';
    }
    
    window.onclick = function(event) {
        const modal = document.getElementById('addModal');
        if (event.target == modal) {
            closeModal();
        }
    }
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
