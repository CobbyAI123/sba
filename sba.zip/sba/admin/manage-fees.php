<?php
// admin/manage-fees.php - Fee Structure Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Fee Structure Management';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$user_id = $current_user['user_id'];

// Handle actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('error', 'Invalid request');
        redirect(APP_URL . '/admin/manage-fees.php');
        exit;
    }
    
    if ($_POST['action'] == 'add_structure') {
        $category_id = (int)$_POST['category_id'];
        $class_id = !empty($_POST['class_id']) ? (int)$_POST['class_id'] : NULL;
        $academic_year = sanitize_input($_POST['academic_year']);
        $amount = (float)$_POST['amount'];
        $frequency = sanitize_input($_POST['payment_frequency']);
        $due_date = !empty($_POST['due_date']) ? sanitize_input($_POST['due_date']) : NULL;
        
        try {
            $stmt = $db->prepare("
                INSERT INTO fee_structure 
                (school_id, category_id, class_id, academic_year, amount, payment_frequency, due_date, created_by, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')
            ");
            $stmt->execute([$school_id, $category_id, $class_id, $academic_year, $amount, $frequency, $due_date, $user_id]);
            
            log_activity($user_id, "Added fee structure", 'fee_structure', $db->lastInsertId());
            set_message('success', 'Fee structure added successfully!');
            
        } catch (PDOException $e) {
            set_message('error', 'Error adding structure: ' . $e->getMessage());
        }
        redirect(APP_URL . '/admin/manage-fees.php');
    } elseif ($_POST['action'] == 'delete_structure') {
        $structure_id = (int)$_POST['structure_id'];
        
        try {
            $stmt = $db->prepare("DELETE FROM fee_structure WHERE structure_id = ? AND school_id = ?");
            $stmt->execute([$structure_id, $school_id]);
            
            log_activity($user_id, "Deleted fee structure", 'fee_structure', $structure_id);
            set_message('success', 'Structure deleted!');
            
        } catch (PDOException $e) {
            set_message('error', 'Error deleting: ' . $e->getMessage());
        }
        redirect(APP_URL . '/admin/manage-fees.php');
    }
}

// Get fee structures
$stmt = $db->prepare("
    SELECT 
        fs.*,
        fc.category_name,
        c.class_name,
        COUNT(DISTINCT sf.student_fee_id) as students_assigned
    FROM fee_structure fs
    INNER JOIN fee_categories fc ON fs.category_id = fc.category_id
    LEFT JOIN classes c ON fs.class_id = c.class_id
    LEFT JOIN student_fees sf ON fs.structure_id = sf.structure_id
    WHERE fs.school_id = ?
    GROUP BY fs.structure_id
    ORDER BY fs.academic_year DESC, fc.category_name
");
$stmt->execute([$school_id]);
$structures = $stmt->fetchAll();

// Get categories for dropdown
$stmt = $db->prepare("SELECT category_id, category_name FROM fee_categories WHERE school_id = ? AND status = 'active' ORDER BY category_name");
$stmt->execute([$school_id]);
$categories = $stmt->fetchAll();

// Get classes for dropdown
$stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .fee-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 15px;
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.7);
        z-index: 9999;
        overflow-y: auto;
    }
    
    .modal-content {
        max-width: 600px;
        margin: 30px auto;
        background: var(--bg-card);
        border-radius: 15px;
        padding: 30px;
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-money-bill-wave"></i> Fee Structure Management</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Define fee amounts for different categories and classes
        </p>
    </div>
    
    <!-- Actions -->
    <div style="margin-bottom: 20px;">
        <button onclick="showAddModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add Fee Structure
        </button>
        <a href="<?php echo APP_URL; ?>/admin/fee-categories.php" class="btn btn-secondary">
            <i class="fas fa-list"></i> Manage Categories
        </a>
        <a href="<?php echo APP_URL; ?>/admin/collect-fee.php" class="btn btn-success">
            <i class="fas fa-cash-register"></i> Collect Payment
        </a>
    </div>
    
    <!-- Fee Structures -->
    <?php if (count($structures) > 0): ?>
        <?php 
        $current_year = '';
        foreach ($structures as $structure): 
            if ($structure['academic_year'] != $current_year):
                if ($current_year != '') echo "</div>";
                $current_year = $structure['academic_year'];
        ?>
            <h3 style="margin: 30px 0 15px 0; color: var(--primary-blue);">
                <i class="fas fa-calendar"></i> Academic Year: <?php echo htmlspecialchars($current_year); ?>
            </h3>
            <div style="margin-left: 20px;">
        <?php endif; ?>
        
            <div class="fee-card">
                <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div style="flex: 1;">
                        <h4 style="margin: 0 0 10px 0;">
                            <?php echo htmlspecialchars($structure['category_name']); ?>
                        </h4>
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px;">
                            <div>
                                <strong>Amount:</strong> 
                                ₹<?php echo number_format($structure['amount'], 2); ?>
                            </div>
                            <div>
                                <strong>Class:</strong> 
                                <?php echo $structure['class_name'] ? htmlspecialchars($structure['class_name']) : 'All Classes'; ?>
                            </div>
                            <div>
                                <strong>Frequency:</strong> 
                                <?php echo ucfirst(str_replace('_', ' ', $structure['payment_frequency'])); ?>
                            </div>
                            <?php if ($structure['due_date']): ?>
                                <div>
                                    <strong>Due Date:</strong> 
                                    <?php echo date('M d, Y', strtotime($structure['due_date'])); ?>
                                </div>
                            <?php endif; ?>
                            <div>
                                <strong>Students:</strong> <?php echo $structure['students_assigned']; ?>
                            </div>
                        </div>
                    </div>
                    
                    <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this structure?')">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="action" value="delete_structure">
                        <input type="hidden" name="structure_id" value="<?php echo $structure['structure_id']; ?>">
                        <button type="submit" class="btn btn-sm btn-danger">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                </div>
            </div>
        
        <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 60px; background: var(--bg-card); border-radius: 15px;">
            <i class="fas fa-money-bill-wave" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
            <h3 style="color: var(--text-secondary);">No Fee Structure Defined</h3>
            <p style="color: var(--text-secondary);">Create your first fee structure to get started</p>
        </div>
    <?php endif; ?>
    
    <!-- Add Structure Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="margin: 0;"><i class="fas fa-plus"></i> Add Fee Structure</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="add_structure">
                
                <div class="form-group">
                    <label>Fee Category *</label>
                    <select name="category_id" required>
                        <option value="">-- Select Category --</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat['category_id']; ?>">
                                <?php echo htmlspecialchars($cat['category_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Class (Optional - leave blank for all classes)</label>
                    <select name="class_id">
                        <option value="">-- All Classes --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>">
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <div class="form-group">
                        <label>Academic Year *</label>
                        <input type="text" name="academic_year" required value="<?php echo date('Y'); ?>" placeholder="2025">
                    </div>
                    
                    <div class="form-group">
                        <label>Amount (₹) *</label>
                        <input type="number" name="amount" required min="0" step="0.01" placeholder="5000.00">
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <div class="form-group">
                        <label>Payment Frequency *</label>
                        <select name="payment_frequency" required>
                            <option value="one_time">One Time</option>
                            <option value="monthly">Monthly</option>
                            <option value="quarterly">Quarterly</option>
                            <option value="annually">Annually</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Due Date (Optional)</label>
                        <input type="date" name="due_date">
                    </div>
                </div>
                
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check"></i> Add Structure
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showAddModal() {
        document.getElementById('addModal').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('addModal').style.display = 'none';
    }
    
    window.onclick = function(event) {
        const modal = document.getElementById('addModal');
        if (event.target == modal) {
            closeModal();
        }
    }
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
