<?php
// admin/attendance-analytics.php - Attendance Analytics Dashboard
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Attendance Analytics';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get date range
$date_from = isset($_GET['date_from']) ? sanitize_input($_GET['date_from']) : date('Y-m-01');
$date_to = isset($_GET['date_to']) ? sanitize_input($_GET['date_to']) : date('Y-m-d');

// Overall Statistics
$stmt = $db->prepare("
    SELECT 
        COUNT(DISTINCT al.student_id) as total_students,
        COUNT(al.log_id) as total_records,
        COUNT(CASE WHEN al.status = 'present' THEN 1 END) as present_count,
        COUNT(CASE WHEN al.status = 'absent' THEN 1 END) as absent_count,
        COUNT(CASE WHEN al.status = 'late' THEN 1 END) as late_count,
        COUNT(CASE WHEN al.status = 'excused' THEN 1 END) as excused_count,
        ROUND(COUNT(CASE WHEN al.status = 'present' THEN 1 END) * 100.0 / NULLIF(COUNT(al.log_id), 0), 2) as overall_percentage
    FROM attendance_logs al
    WHERE al.school_id = ? AND al.date BETWEEN ? AND ?
");
$stmt->execute([$school_id, $date_from, $date_to]);
$overall_stats = $stmt->fetch();

// Daily Attendance Trend
$stmt = $db->prepare("
    SELECT 
        al.date,
        COUNT(CASE WHEN al.status = 'present' THEN 1 END) as present,
        COUNT(CASE WHEN al.status = 'absent' THEN 1 END) as absent,
        COUNT(CASE WHEN al.status = 'late' THEN 1 END) as late,
        COUNT(al.log_id) as total
    FROM attendance_logs al
    WHERE al.school_id = ? AND al.date BETWEEN ? AND ?
    GROUP BY al.date
    ORDER BY al.date
");
$stmt->execute([$school_id, $date_from, $date_to]);
$daily_trend = $stmt->fetchAll();

// Class-wise Statistics
$class_stats = [];
try {
    $stmt = $db->prepare("
        SELECT 
            c.class_name,
            COUNT(DISTINCT al.student_id) as total_students,
            COUNT(CASE WHEN al.status = 'present' THEN 1 END) as present_count,
            COUNT(CASE WHEN al.status = 'absent' THEN 1 END) as absent_count,
            ROUND(COUNT(CASE WHEN al.status = 'present' THEN 1 END) * 100.0 / NULLIF(COUNT(al.log_id), 0), 2) as attendance_percentage
        FROM attendance_logs al
        INNER JOIN classes c ON al.class_id = c.class_id
        WHERE al.school_id = ? AND al.date BETWEEN ? AND ?
        GROUP BY c.class_id, c.class_name
        ORDER BY attendance_percentage DESC
    ");
    $stmt->execute([$school_id, $date_from, $date_to]);
    $class_stats = $stmt->fetchAll();
} catch (PDOException $e) {
    // Fallback if class_id column missing
    $class_stats = [];
}

// Students with Low Attendance
$stmt = $db->prepare("
    SELECT 
        s.student_id,
        CONCAT(s.first_name, ' ', s.last_name) as student_name,
        s.student_code,
        c.class_name,
        COUNT(CASE WHEN al.status = 'present' THEN 1 END) as present_count,
        COUNT(al.log_id) as total_days,
        ROUND(COUNT(CASE WHEN al.status = 'present' THEN 1 END) * 100.0 / NULLIF(COUNT(al.log_id), 0), 2) as attendance_percentage
    FROM students s
    INNER JOIN student_classes sc ON s.student_id = sc.student_id
    INNER JOIN classes c ON sc.class_id = c.class_id
    LEFT JOIN attendance_logs al ON s.student_id = al.student_id AND al.date BETWEEN ? AND ?
    WHERE s.school_id = ? AND s.status = 'active'
    GROUP BY s.student_id, s.first_name, s.last_name, s.student_code, c.class_name
    HAVING attendance_percentage < 75 OR attendance_percentage IS NULL
    ORDER BY attendance_percentage ASC
    LIMIT 10
");
$stmt->execute([$date_from, $date_to, $school_id]);
$low_attendance_students = $stmt->fetchAll();

// Active Alerts
$alerts = [];
try {
    $stmt = $db->prepare("
        SELECT 
            aa.*,
            CONCAT(s.first_name, ' ', s.last_name) as student_name,
            s.student_code,
            c.class_name
        FROM attendance_alerts aa
        INNER JOIN students s ON aa.student_id = s.student_id
        INNER JOIN student_classes sc ON s.student_id = sc.student_id
        INNER JOIN classes c ON sc.class_id = c.class_id
        WHERE aa.school_id = ? AND aa.is_resolved = 0
        ORDER BY aa.created_at DESC
        LIMIT 20
    ");
    $stmt->execute([$school_id]);
    $alerts = $stmt->fetchAll();
} catch (PDOException $e) {
    // Table doesn't exist yet - no alerts to show
    $alerts = [];
    error_log("Attendance alerts table not found: " . $e->getMessage());
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .analytics-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        color: white;
        padding: 25px;
        border-radius: 15px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }
    
    .stat-card.green {
        background: linear-gradient(135deg, #34C759, #30D158);
    }
    
    .stat-card.red {
        background: linear-gradient(135deg, #FF3B30, #FF453A);
    }
    
    .stat-card.orange {
        background: linear-gradient(135deg, #FF9500, #FF9F0A);
    }
    
    .stat-card.purple {
        background: linear-gradient(135deg, #5856D6, #5E5CE6);
    }
    
    .stat-card h3 {
        margin: 0 0 5px 0;
        font-size: 42px;
        font-weight: 700;
    }
    
    .stat-card p {
        margin: 0;
        opacity: 0.9;
        font-size: 15px;
    }
    
    .stat-card .icon {
        font-size: 32px;
        opacity: 0.3;
        float: right;
    }
    
    .chart-container {
        background: var(--bg-card);
        border-radius: 15px;
        padding: 25px;
        border: 1px solid var(--border-color);
        margin-bottom: 25px;
        position: relative;
        height: 350px;
    }
    
    .date-filter {
        display: flex;
        gap: 15px;
        align-items: center;
        margin-bottom: 25px;
        padding: 20px;
        background: var(--bg-card);
        border-radius: 15px;
        border: 1px solid var(--border-color);
    }
    
    .date-filter input {
        padding: 10px 15px;
        border-radius: 8px;
        border: 1px solid var(--border-color);
    }
    
    .progress-bar {
        width: 100%;
        height: 8px;
        background: rgba(255,255,255,0.2);
        border-radius: 4px;
        overflow: hidden;
        margin-top: 10px;
    }
    
    .progress-fill {
        height: 100%;
        background: white;
        border-radius: 4px;
        transition: width 0.3s ease;
    }
    
    .alert-card {
        background: var(--bg-card);
        border-left: 4px solid var(--border-color);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 10px;
    }
    
    .alert-card.warning {
        border-left-color: #FF9500;
        background: rgba(255, 149, 0, 0.05);
    }
    
    .alert-card.danger {
        border-left-color: #FF3B30;
        background: rgba(255, 59, 48, 0.05);
    }
    
    .student-list {
        display: grid;
        gap: 10px;
    }
    
    .student-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px;
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 10px;
    }
    
    .student-item:hover {
        border-color: var(--primary-blue);
        box-shadow: 0 3px 15px rgba(0,0,0,0.1);
    }
    
    .percentage-badge {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 13px;
        font-weight: 600;
    }
    
    .percentage-good {
        background: rgba(52, 199, 89, 0.1);
        color: #34C759;
    }
    
    .percentage-warning {
        background: rgba(255, 149, 0, 0.1);
        color: #FF9500;
    }
    
    .percentage-danger {
        background: rgba(255, 59, 48, 0.1);
        color: #FF3B30;
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-chart-line"></i> Attendance Analytics</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Comprehensive attendance insights and trends
        </p>
    </div>
    
    <!-- Date Filter -->
    <form method="GET" class="date-filter">
        <div>
            <label style="display: block; margin-bottom: 5px; font-weight: 600;">
                <i class="fas fa-calendar"></i> From Date
            </label>
            <input type="date" name="date_from" value="<?php echo $date_from; ?>" required>
        </div>
        <div>
            <label style="display: block; margin-bottom: 5px; font-weight: 600;">
                <i class="fas fa-calendar"></i> To Date
            </label>
            <input type="date" name="date_to" value="<?php echo $date_to; ?>" required>
        </div>
        <div style="padding-top: 28px;">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-filter"></i> Apply Filter
            </button>
        </div>
    </form>
    
    <!-- Overall Statistics -->
    <div class="analytics-grid">
        <div class="stat-card">
            <i class="fas fa-users icon"></i>
            <h3><?php echo number_format($overall_stats['total_students'] ?? 0); ?></h3>
            <p>Total Students</p>
        </div>
        
        <div class="stat-card green">
            <i class="fas fa-check-circle icon"></i>
            <h3><?php echo number_format($overall_stats['present_count'] ?? 0); ?></h3>
            <p>Total Present</p>
            <div class="progress-bar">
                <div class="progress-fill" style="width: <?php echo $overall_stats['overall_percentage'] ?? 0; ?>%;"></div>
            </div>
        </div>
        
        <div class="stat-card red">
            <i class="fas fa-times-circle icon"></i>
            <h3><?php echo number_format($overall_stats['absent_count'] ?? 0); ?></h3>
            <p>Total Absent</p>
        </div>
        
        <div class="stat-card orange">
            <i class="fas fa-clock icon"></i>
            <h3><?php echo number_format($overall_stats['late_count'] ?? 0); ?></h3>
            <p>Total Late</p>
        </div>
        
        <div class="stat-card purple">
            <i class="fas fa-percentage icon"></i>
            <h3><?php echo number_format($overall_stats['overall_percentage'] ?? 0, 1); ?>%</h3>
            <p>Overall Attendance</p>
        </div>
    </div>
    
    <!-- Charts Row -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(500px, 1fr)); gap: 20px; margin-bottom: 25px;">
        
        <!-- Daily Trend Chart -->
        <div class="chart-container">
            <h3 style="margin: 0 0 20px 0; position: relative; z-index: 1;">
                <i class="fas fa-chart-area"></i> Daily Attendance Trend
            </h3>
            <canvas id="dailyTrendChart" style="position: relative; z-index: 2;"></canvas>
        </div>
        
        <!-- Class Comparison Chart -->
        <div class="chart-container">
            <h3 style="margin: 0 0 20px 0; position: relative; z-index: 1;">
                <i class="fas fa-chart-bar"></i> Class-wise Attendance
            </h3>
            <canvas id="classChart" style="position: relative; z-index: 2;"></canvas>
        </div>
    </div>
    
    <!-- Low Attendance Students -->
    <?php if (count($low_attendance_students) > 0): ?>
    <div class="chart-container">
        <h3 style="margin: 0 0 20px 0;">
            <i class="fas fa-exclamation-triangle"></i> Students with Low Attendance (< 75%)
        </h3>
        <div class="student-list">
            <?php foreach ($low_attendance_students as $student): 
                $percentage = $student['attendance_percentage'] ?? 0;
                $badge_class = $percentage >= 75 ? 'good' : ($percentage >= 50 ? 'warning' : 'danger');
            ?>
                <div class="student-item">
                    <div>
                        <strong><?php echo htmlspecialchars($student['student_name']); ?></strong>
                        <span style="color: var(--text-secondary); margin-left: 10px;">
                            <?php echo htmlspecialchars($student['student_code']); ?> | 
                            <?php echo htmlspecialchars($student['class_name']); ?>
                        </span>
                    </div>
                    <div style="text-align: right;">
                        <span class="percentage-badge percentage-<?php echo $badge_class; ?>">
                            <?php echo number_format($percentage, 1); ?>%
                        </span>
                        <div style="font-size: 12px; color: var(--text-secondary); margin-top: 3px;">
                            <?php echo $student['present_count']; ?> / <?php echo $student['total_days']; ?> days
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Active Alerts -->
    <?php if (count($alerts) > 0): ?>
    <div class="chart-container">
        <h3 style="margin: 0 0 20px 0;">
            <i class="fas fa-bell"></i> Active Attendance Alerts (<?php echo count($alerts); ?>)
        </h3>
        <?php foreach ($alerts as $alert): ?>
            <div class="alert-card <?php echo $alert['alert_type'] == 'consecutive_absence' ? 'danger' : 'warning'; ?>">
                <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div>
                        <strong><?php echo htmlspecialchars($alert['student_name']); ?></strong>
                        <span style="color: var(--text-secondary); margin-left: 10px;">
                            <?php echo htmlspecialchars($alert['class_name']); ?>
                        </span>
                        <p style="margin: 8px 0 0 0; color: var(--text-secondary);">
                            <?php echo htmlspecialchars($alert['message']); ?>
                        </p>
                    </div>
                    <div style="text-align: right;">
                        <span style="font-size: 12px; color: var(--text-secondary);">
                            <?php echo time_elapsed_string($alert['created_at']); ?>
                        </span>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <script>
    // Daily Trend Chart
    const dailyCtx = document.getElementById('dailyTrendChart').getContext('2d');
    const dailyChart = new Chart(dailyCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_column($daily_trend, 'date')); ?>,
            datasets: [{
                label: 'Present',
                data: <?php echo json_encode(array_column($daily_trend, 'present')); ?>,
                borderColor: '#34C759',
                backgroundColor: 'rgba(52, 199, 89, 0.1)',
                tension: 0.4
            }, {
                label: 'Absent',
                data: <?php echo json_encode(array_column($daily_trend, 'absent')); ?>,
                borderColor: '#FF3B30',
                backgroundColor: 'rgba(255, 59, 48, 0.1)',
                tension: 0.4
            }, {
                label: 'Late',
                data: <?php echo json_encode(array_column($daily_trend, 'late')); ?>,
                borderColor: '#FF9500',
                backgroundColor: 'rgba(255, 149, 0, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    
    // Class Chart
    const classCtx = document.getElementById('classChart').getContext('2d');
    const classChart = new Chart(classCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode(array_column($class_stats, 'class_name')); ?>,
            datasets: [{
                label: 'Attendance Percentage',
                data: <?php echo json_encode(array_column($class_stats, 'attendance_percentage')); ?>,
                backgroundColor: 'rgba(45, 91, 255, 0.8)',
                borderColor: 'rgba(45, 91, 255, 1)',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
