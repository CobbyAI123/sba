<?php
// admin/profile.php - Admin Profile (same structure as accountant/librarian)
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'My Profile';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'upload_avatar') {
            // Handle profile picture upload
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
                $allowed = ['jpg', 'jpeg', 'png', 'gif'];
                $filename = $_FILES['avatar']['name'];
                $filetype = $_FILES['avatar']['type'];
                $filesize = $_FILES['avatar']['size'];
                
                $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                
                if (!in_array($ext, $allowed)) {
                    set_message('error', 'Only JPG, JPEG, PNG & GIF files are allowed.');
                } elseif ($filesize > 5000000) { // 5MB max
                    set_message('error', 'File size must be less than 5MB.');
                } else {
                    // Create uploads directory if it doesn't exist
                    $upload_dir = BASE_PATH . '/uploads/avatars/';
                    if (!file_exists($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    
                    // Generate unique filename
                    $new_filename = 'avatar_' . $current_user['user_id'] . '_' . time() . '.' . $ext;
                    $upload_path = $upload_dir . $new_filename;
                    
                    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $upload_path)) {
                        // Delete old avatar if exists
                        if (!empty($user['avatar']) && file_exists(BASE_PATH . $user['avatar'])) {
                            unlink(BASE_PATH . $user['avatar']);
                        }
                        
                        // Update database
                        $avatar_path = '/uploads/avatars/' . $new_filename;
                        try {
                            $stmt = $db->prepare("UPDATE users SET avatar = ? WHERE user_id = ?");
                            $stmt->execute([$avatar_path, $current_user['user_id']]);
                            
                            log_activity($current_user['user_id'], "Updated profile picture", 'users', $current_user['user_id']);
                            
                            set_message('success', 'Profile picture updated successfully!');
                            redirect(APP_URL . '/admin/profile.php');
                        } catch (PDOException $e) {
                            set_message('error', 'Error updating profile picture: ' . $e->getMessage());
                        }
                    } else {
                        set_message('error', 'Error uploading file.');
                    }
                }
            } else {
                set_message('error', 'Please select a file to upload.');
            }
        } elseif ($_POST['action'] == 'remove_avatar') {
            // Remove profile picture
            if (!empty($user['avatar']) && file_exists(BASE_PATH . $user['avatar'])) {
                unlink(BASE_PATH . $user['avatar']);
            }
            
            try {
                $stmt = $db->prepare("UPDATE users SET avatar = NULL WHERE user_id = ?");
                $stmt->execute([$current_user['user_id']]);
                
                log_activity($current_user['user_id'], "Removed profile picture", 'users', $current_user['user_id']);
                
                set_message('success', 'Profile picture removed successfully!');
                redirect(APP_URL . '/admin/profile.php');
            } catch (PDOException $e) {
                set_message('error', 'Error removing profile picture: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'update_profile') {
            $phone = sanitize_input($_POST['phone']);
            // Note: address field removed - users table doesn't have address column
            
            try {
                $stmt = $db->prepare("
                    UPDATE users 
                    SET phone = ?
                    WHERE user_id = ?
                ");
                $stmt->execute([$phone, $current_user['user_id']]);
                
                log_activity($current_user['user_id'], "Updated profile information", 'users', $current_user['user_id']);
                
                set_message('success', 'Profile updated successfully!');
                redirect(APP_URL . '/admin/profile.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating profile: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'change_password') {
            $current_password = $_POST['current_password'];
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            if (!password_verify($current_password, $current_user['password_hash'])) {
                set_message('error', 'Current password is incorrect!');
            } elseif ($new_password !== $confirm_password) {
                set_message('error', 'New passwords do not match!');
            } elseif (strlen($new_password) < 6) {
                set_message('error', 'Password must be at least 6 characters!');
            } else {
                try {
                    $password_hash = password_hash($new_password, PASSWORD_BCRYPT);
                    $stmt = $db->prepare("UPDATE users SET password_hash = ? WHERE user_id = ?");
                    $stmt->execute([$password_hash, $current_user['user_id']]);
                    
                    log_activity($current_user['user_id'], "Changed password", 'users', $current_user['user_id']);
                    
                    set_message('success', 'Password changed successfully!');
                    redirect(APP_URL . '/admin/profile.php');
                } catch (PDOException $e) {
                    set_message('error', 'Error changing password: ' . $e->getMessage());
                }
            }
        }
    }
}

// Get fresh user data
$stmt = $db->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$current_user['user_id']]);
$user = $stmt->fetch();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .profile-container {
        display: grid;
        grid-template-columns: 300px 1fr;
        gap: 30px;
    }
    
    .profile-sidebar {
        background: var(--card-bg);
        border-radius: 15px;
        padding: 30px;
        text-align: center;
        height: fit-content;
    }
    
    .profile-avatar {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        background: linear-gradient(135deg, #2196F3, #9C27B0);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 48px;
        font-weight: 700;
        margin: 0 auto 20px;
        position: relative;
        overflow: hidden;
    }
    
    .profile-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .avatar-upload-btn {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.7);
        color: white;
        padding: 8px;
        text-align: center;
        cursor: pointer;
        font-size: 12px;
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .profile-avatar:hover .avatar-upload-btn {
        opacity: 1;
    }
    
    .avatar-actions {
        display: flex;
        gap: 10px;
        margin-top: 15px;
        justify-content: center;
    }
    
    .profile-name {
        font-size: 22px;
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    .profile-role {
        color: var(--text-secondary);
        margin-bottom: 20px;
    }
    
    .profile-main {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }
    
    @media (max-width: 768px) {
        .profile-container {
            grid-template-columns: 1fr;
        }
    }
    </style>
    
    <!-- Page Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-user"></i> My Profile
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Manage your account information
            </p>
        </div>
    </div>
    
    <div class="profile-container">
        <!-- Sidebar -->
        <div class="profile-sidebar">
            <div class="profile-avatar">
                <?php if (!empty($user['avatar'])): ?>
                    <img src="<?php echo APP_URL . htmlspecialchars($user['avatar']); ?>" alt="Profile Picture">
                <?php else: ?>
                    <?php echo strtoupper(substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1)); ?>
                <?php endif; ?>
                <label for="avatar-upload" class="avatar-upload-btn">
                    <i class="fas fa-camera"></i> Change Photo
                </label>
            </div>
            
            <!-- Avatar Upload Form (Hidden) -->
            <form method="POST" enctype="multipart/form-data" id="avatarForm" style="display: none;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="upload_avatar">
                <input type="file" name="avatar" id="avatar-upload" accept="image/*" onchange="document.getElementById('avatarForm').submit();">
            </form>
            
            <!-- Remove Avatar Button -->
            <?php if (!empty($user['avatar'])): ?>
            <div class="avatar-actions">
                <form method="POST" style="margin: 0;" onsubmit="return confirm('Remove profile picture?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="remove_avatar">
                    <button type="submit" class="btn btn-secondary btn-sm" style="font-size: 12px; padding: 6px 12px;">
                        <i class="fas fa-trash"></i> Remove Photo
                    </button>
                </form>
            </div>
            <?php endif; ?>
            <div class="profile-name"><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></div>
            <div class="profile-role"><?php echo ucfirst($user['role']); ?></div>
            <div style="padding-top: 20px; border-top: 1px solid var(--border-color); text-align: left;">
                <div style="margin-bottom: 15px;">
                    <i class="fas fa-envelope" style="color: var(--primary-blue); margin-right: 10px;"></i>
                    <span style="font-size: 14px;"><?php echo htmlspecialchars($user['email']); ?></span>
                </div>
                <div style="margin-bottom: 15px;">
                    <i class="fas fa-phone" style="color: var(--primary-blue); margin-right: 10px;"></i>
                    <span style="font-size: 14px;"><?php echo htmlspecialchars($user['phone'] ?? 'Not set'); ?></span>
                </div>
                <div>
                    <i class="fas fa-calendar" style="color: var(--primary-blue); margin-right: 10px;"></i>
                    <span style="font-size: 14px;">Joined <?php echo date('M Y', strtotime($user['created_at'])); ?></span>
                </div>
            </div>
        </div>
    
        <!-- Main Content -->
        <div class="profile-main">
            <!-- Update Profile -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-user-edit"></i> Update Profile</h3>
                </div>
                <form method="POST" style="padding: 20px;">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" value="<?php echo htmlspecialchars($user['first_name']); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" value="<?php echo htmlspecialchars($user['last_name']); ?>" disabled>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                    </div>
                    
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" placeholder="Enter phone number">
                    </div>
                    
                    <div class="form-group">
                        <label>Address</label>
                        <textarea name="address" rows="3" placeholder="Enter address"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Profile
                    </button>
                </form>
            </div>
    
            <!-- Change Password -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-lock"></i> Change Password</h3>
                </div>
                <form method="POST" style="padding: 20px;">
                    <input type="hidden" name="action" value="change_password">
                    
                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" name="current_password" required>
                    </div>
                    
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" required minlength="6">
                    </div>
                    
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" required minlength="6">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                </form>
            </div>
        </div>
    </div>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
