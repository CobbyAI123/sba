<?php
// admin/terms.php - Academic Term Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Academic Terms';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Auto-create terms table if it doesn't exist
try {
    $db->query("SELECT 1 FROM terms LIMIT 1");
} catch (PDOException $e) {
    try {
        $sql = "CREATE TABLE IF NOT EXISTS `terms` (
          `term_id` int(11) NOT NULL AUTO_INCREMENT,
          `school_id` int(11) NOT NULL,
          `term_name` varchar(100) NOT NULL,
          `session_year` varchar(20) NOT NULL,
          `start_date` date NOT NULL,
          `end_date` date NOT NULL,
          `is_active` tinyint(1) DEFAULT 0,
          `is_current` tinyint(1) DEFAULT 0,
          `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`term_id`),
          KEY `school_id` (`school_id`),
          KEY `is_active` (`is_active`),
          KEY `is_current` (`is_current`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        $db->exec($sql);
    } catch (PDOException $e) {
        // Table creation failed, will handle error later
    }
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        // Ensure terms table exists before processing
        try {
            $db->query("SELECT 1 FROM terms LIMIT 1");
        } catch (PDOException $e) {
            try {
                $sql = "CREATE TABLE IF NOT EXISTS `terms` (
                  `term_id` int(11) NOT NULL AUTO_INCREMENT,
                  `school_id` int(11) NOT NULL,
                  `term_name` varchar(100) NOT NULL,
                  `session_year` varchar(20) NOT NULL,
                  `start_date` date NOT NULL,
                  `end_date` date NOT NULL,
                  `is_active` tinyint(1) DEFAULT 0,
                  `is_current` tinyint(1) DEFAULT 0,
                  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`term_id`),
                  KEY `school_id` (`school_id`),
                  KEY `is_active` (`is_active`),
                  KEY `is_current` (`is_current`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
                $db->exec($sql);
            } catch (PDOException $e) {
                set_message('error', 'Error creating terms table: ' . $e->getMessage());
                redirect(APP_URL . '/admin/terms.php');
            }
        }
        
        if ($_POST['action'] == 'add') {
            $term_name = sanitize_input($_POST['term_name']);
            $session_year = sanitize_input($_POST['session_year']);
            $start_date = sanitize_input($_POST['start_date']);
            $end_date = sanitize_input($_POST['end_date']);
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            try {
                // Check which columns exist
                $has_school_id = count($db->query("SHOW COLUMNS FROM terms LIKE 'school_id'")->fetchAll()) > 0;
                $has_session_year = count($db->query("SHOW COLUMNS FROM terms LIKE 'session_year'")->fetchAll()) > 0;
                $has_is_active = count($db->query("SHOW COLUMNS FROM terms LIKE 'is_active'")->fetchAll()) > 0;
                $has_is_current = count($db->query("SHOW COLUMNS FROM terms LIKE 'is_current'")->fetchAll()) > 0;
                $has_year_id = count($db->query("SHOW COLUMNS FROM terms LIKE 'year_id'")->fetchAll()) > 0;
                $has_term_number = count($db->query("SHOW COLUMNS FROM terms LIKE 'term_number'")->fetchAll()) > 0;
                
                // If setting as active, deactivate all other terms
                if ($is_active) {
                    try {
                        if ($has_is_active) {
                            if ($has_school_id) {
                                $stmt = $db->prepare("UPDATE terms SET is_active = 0 WHERE school_id = ?");
                                $stmt->execute([$school_id]);
                            } else {
                                $stmt = $db->prepare("UPDATE terms SET is_active = 0");
                                $stmt->execute();
                            }
                        } elseif ($has_is_current) {
                            if ($has_school_id) {
                                $stmt = $db->prepare("UPDATE terms SET is_current = 0 WHERE school_id = ?");
                                $stmt->execute([$school_id]);
                            } else {
                                $stmt = $db->prepare("UPDATE terms SET is_current = 0");
                                $stmt->execute();
                            }
                        }
                    } catch (PDOException $e) {
                        // Ignore if column doesn't exist
                    }
                }
                
                // Build INSERT query based on available columns
                $columns_list = ['term_name'];
                $values_list = [$term_name];
                $placeholders = ['?'];
                
                // Only add school_id if the column exists
                if ($has_school_id) {
                    $columns_list[] = 'school_id';
                    $values_list[] = $school_id;
                    $placeholders[] = '?';
                }
                
                // Handle year_id if it exists (set to NULL or 1 as default)
                if ($has_year_id) {
                    $columns_list[] = 'year_id';
                    $values_list[] = null; // Set to NULL since we don't have academic_years
                    $placeholders[] = '?';
                }
                
                // Handle term_number if it exists
                if ($has_term_number) {
                    $columns_list[] = 'term_number';
                    // Extract term number from term name (First Term = 1, Second = 2, Third = 3)
                    $term_num = 1;
                    if (stripos($term_name, 'second') !== false) $term_num = 2;
                    elseif (stripos($term_name, 'third') !== false) $term_num = 3;
                    $values_list[] = $term_num;
                    $placeholders[] = '?';
                }
                
                if ($has_session_year) {
                    $columns_list[] = 'session_year';
                    $values_list[] = $session_year;
                    $placeholders[] = '?';
                }
                
                $columns_list[] = 'start_date';
                $columns_list[] = 'end_date';
                $values_list[] = $start_date;
                $values_list[] = $end_date;
                $placeholders[] = '?';
                $placeholders[] = '?';
                
                if ($has_is_active) {
                    $columns_list[] = 'is_active';
                    $values_list[] = $is_active;
                    $placeholders[] = '?';
                } elseif ($has_is_current) {
                    $columns_list[] = 'is_current';
                    $values_list[] = $is_active;
                    $placeholders[] = '?';
                }
                
                $sql = "INSERT INTO terms (" . implode(', ', $columns_list) . ") VALUES (" . implode(', ', $placeholders) . ")";
                $stmt = $db->prepare($sql);
                $stmt->execute($values_list);
                
                $term_id = $db->lastInsertId();
                log_activity($current_user['user_id'], "Created term: $term_name ($session_year)", 'terms', $term_id);
                
                set_message('success', 'Academic term created successfully!');
                redirect(APP_URL . '/admin/terms.php');
            } catch (PDOException $e) {
                set_message('error', 'Error creating term: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'edit') {
            $term_id = sanitize_input($_POST['term_id']);
            $term_name = sanitize_input($_POST['term_name']);
            $session_year = sanitize_input($_POST['session_year']);
            $start_date = sanitize_input($_POST['start_date']);
            $end_date = sanitize_input($_POST['end_date']);
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            try {
                // Check which columns exist
                $has_school_id = count($db->query("SHOW COLUMNS FROM terms LIKE 'school_id'")->fetchAll()) > 0;
                $has_session_year = count($db->query("SHOW COLUMNS FROM terms LIKE 'session_year'")->fetchAll()) > 0;
                $has_is_active = count($db->query("SHOW COLUMNS FROM terms LIKE 'is_active'")->fetchAll()) > 0;
                $has_is_current = count($db->query("SHOW COLUMNS FROM terms LIKE 'is_current'")->fetchAll()) > 0;
                
                // If setting as active, deactivate all other terms
                if ($is_active) {
                    try {
                        if ($has_is_active) {
                            if ($has_school_id) {
                                $stmt = $db->prepare("UPDATE terms SET is_active = 0 WHERE school_id = ? AND term_id != ?");
                                $stmt->execute([$school_id, $term_id]);
                            } else {
                                $stmt = $db->prepare("UPDATE terms SET is_active = 0 WHERE term_id != ?");
                                $stmt->execute([$term_id]);
                            }
                        } elseif ($has_is_current) {
                            if ($has_school_id) {
                                $stmt = $db->prepare("UPDATE terms SET is_current = 0 WHERE school_id = ? AND term_id != ?");
                                $stmt->execute([$school_id, $term_id]);
                            } else {
                                $stmt = $db->prepare("UPDATE terms SET is_current = 0 WHERE term_id != ?");
                                $stmt->execute([$term_id]);
                            }
                        }
                    } catch (PDOException $e) {
                        // Ignore if column doesn't exist
                    }
                }
                
                // Build UPDATE query based on available columns
                $set_parts = ['term_name = ?'];
                $values_list = [$term_name];
                
                if ($has_session_year) {
                    $set_parts[] = 'session_year = ?';
                    $values_list[] = $session_year;
                }
                
                $set_parts[] = 'start_date = ?';
                $set_parts[] = 'end_date = ?';
                $values_list[] = $start_date;
                $values_list[] = $end_date;
                
                if ($has_is_active) {
                    $set_parts[] = 'is_active = ?';
                    $values_list[] = $is_active;
                } elseif ($has_is_current) {
                    $set_parts[] = 'is_current = ?';
                    $values_list[] = $is_active;
                }
                
                $values_list[] = $term_id;
                
                // Build WHERE clause based on available columns
                $where_clause = "WHERE term_id = ?";
                if ($has_school_id) {
                    $where_clause .= " AND school_id = ?";
                    $values_list[] = $school_id;
                }
                
                $sql = "UPDATE terms SET " . implode(', ', $set_parts) . " " . $where_clause;
                $stmt = $db->prepare($sql);
                $stmt->execute($values_list);
                
                log_activity($current_user['user_id'], "Updated term ID: $term_id", 'terms', $term_id);
                
                set_message('success', 'Academic term updated successfully!');
                redirect(APP_URL . '/admin/terms.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating term: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            $term_id = sanitize_input($_POST['term_id']);
            
            try {
                // Check if school_id column exists
                $has_school_id = count($db->query("SHOW COLUMNS FROM terms LIKE 'school_id'")->fetchAll()) > 0;
                
                // Check if term has associated data
                $stmt = $db->prepare("SELECT COUNT(*) as count FROM exams WHERE term_id = ?");
                $stmt->execute([$term_id]);
                $exam_count = $stmt->fetch()['count'];
                
                if ($exam_count > 0) {
                    set_message('error', 'Cannot delete term with associated exams. Please delete exams first.');
                } else {
                    if ($has_school_id) {
                        $stmt = $db->prepare("DELETE FROM terms WHERE term_id = ? AND school_id = ?");
                        $stmt->execute([$term_id, $school_id]);
                    } else {
                        $stmt = $db->prepare("DELETE FROM terms WHERE term_id = ?");
                        $stmt->execute([$term_id]);
                    }
                    
                    log_activity($current_user['user_id'], "Deleted term ID: $term_id", 'terms', $term_id);
                    
                    set_message('success', 'Academic term deleted successfully!');
                }
                redirect(APP_URL . '/admin/terms.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting term: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'set_active') {
            $term_id = sanitize_input($_POST['term_id']);
            
            try {
                // Check which column exists
                $has_school_id = count($db->query("SHOW COLUMNS FROM terms LIKE 'school_id'")->fetchAll()) > 0;
                $has_is_active = count($db->query("SHOW COLUMNS FROM terms LIKE 'is_active'")->fetchAll()) > 0;
                $has_is_current = count($db->query("SHOW COLUMNS FROM terms LIKE 'is_current'")->fetchAll()) > 0;
                
                if ($has_is_active) {
                    // Deactivate all terms
                    if ($has_school_id) {
                        $stmt = $db->prepare("UPDATE terms SET is_active = 0 WHERE school_id = ?");
                        $stmt->execute([$school_id]);
                        
                        // Activate selected term
                        $stmt = $db->prepare("UPDATE terms SET is_active = 1 WHERE term_id = ? AND school_id = ?");
                        $stmt->execute([$term_id, $school_id]);
                    } else {
                        $stmt = $db->prepare("UPDATE terms SET is_active = 0");
                        $stmt->execute();
                        
                        // Activate selected term
                        $stmt = $db->prepare("UPDATE terms SET is_active = 1 WHERE term_id = ?");
                        $stmt->execute([$term_id]);
                    }
                } elseif ($has_is_current) {
                    // Deactivate all terms
                    if ($has_school_id) {
                        $stmt = $db->prepare("UPDATE terms SET is_current = 0 WHERE school_id = ?");
                        $stmt->execute([$school_id]);
                        
                        // Activate selected term
                        $stmt = $db->prepare("UPDATE terms SET is_current = 1 WHERE term_id = ? AND school_id = ?");
                        $stmt->execute([$term_id, $school_id]);
                    } else {
                        $stmt = $db->prepare("UPDATE terms SET is_current = 0");
                        $stmt->execute();
                        
                        // Activate selected term
                        $stmt = $db->prepare("UPDATE terms SET is_current = 1 WHERE term_id = ?");
                        $stmt->execute([$term_id]);
                    }
                }
                
                log_activity($current_user['user_id'], "Set active term ID: $term_id", 'terms', $term_id);
                
                set_message('success', 'Active term updated successfully!');
                redirect(APP_URL . '/admin/terms.php');
            } catch (PDOException $e) {
                set_message('error', 'Error setting active term: ' . $e->getMessage());
            }
        }
    }
}

// Get all terms
$terms = [];
$active_term = null;
try {
    // Check if school_id column exists
    $has_school_id = count($db->query("SHOW COLUMNS FROM terms LIKE 'school_id'")->fetchAll()) > 0;
    
    if ($has_school_id) {
        $stmt = $db->prepare("
            SELECT * FROM terms 
            WHERE school_id = ?
            ORDER BY start_date DESC
        ");
        $stmt->execute([$school_id]);
    } else {
        $stmt = $db->prepare("
            SELECT * FROM terms 
            ORDER BY start_date DESC
        ");
        $stmt->execute();
    }
    $terms = $stmt->fetchAll();
    
    // Get active term - handle both is_active and is_current columns
    try {
        if ($has_school_id) {
            $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_active = 1");
            $stmt->execute([$school_id]);
        } else {
            $stmt = $db->prepare("SELECT * FROM terms WHERE is_active = 1 LIMIT 1");
            $stmt->execute();
        }
        $active_term = $stmt->fetch();
    } catch (PDOException $e) {
        // Fallback to is_current if is_active doesn't exist
        try {
            if ($has_school_id) {
                $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_current = 1");
                $stmt->execute([$school_id]);
            } else {
                $stmt = $db->prepare("SELECT * FROM terms WHERE is_current = 1 LIMIT 1");
                $stmt->execute();
            }
            $active_term = $stmt->fetch();
        } catch (PDOException $e2) {
            // If neither column exists, just get the first term
            try {
                if ($has_school_id) {
                    $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? LIMIT 1");
                    $stmt->execute([$school_id]);
                } else {
                    $stmt = $db->prepare("SELECT * FROM terms LIMIT 1");
                    $stmt->execute();
                }
                $active_term = $stmt->fetch();
            } catch (PDOException $e3) {
                $active_term = null;
            }
        }
    }
} catch (PDOException $e) {
    // Terms table doesn't exist - set default empty arrays
    $terms = [];
    $active_term = null;
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Active Term Banner -->
    <?php if ($active_term): ?>
        <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #4CAF50, #8BC34A); color: white;">
            <div style="padding: 20px;">
                <h3 style="margin: 0 0 10px 0; color: white;">
                    <i class="fas fa-calendar-check"></i> Current Academic Term
                </h3>
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                    <div>
                        <h2 style="margin: 0; color: white;"><?php echo $active_term['term_name']; ?></h2>
                        <p style="margin: 5px 0 0 0; font-size: 16px; opacity: 0.9;">
                            <?php echo isset($active_term['session_year']) ? $active_term['session_year'] . ' | ' : ''; ?>
                            <?php echo date('M d, Y', strtotime($active_term['start_date'])); ?> - 
                            <?php echo date('M d, Y', strtotime($active_term['end_date'])); ?>
                        </p>
                    </div>
                    <span class="badge" style="background: white; color: #4CAF50; padding: 10px 20px; font-size: 14px;">
                        <i class="fas fa-check-circle"></i> Active
                    </span>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning" style="margin-bottom: 30px;">
            <i class="fas fa-exclamation-triangle"></i>
            <strong>No Active Term!</strong> Please set an active academic term to continue operations.
        </div>
    <?php endif; ?>
    
    <!-- Statistics -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-calendar-alt"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo count($terms); ?></h3>
                <p>Total Terms</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $active_term ? 1 : 0; ?></h3>
                <p>Active Term</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-calendar-plus"></i>
            </div>
            <div class="stat-details">
                <h3><button onclick="openAddTermModal()" class="btn btn-primary btn-sm">Add New</button></h3>
                <p>Create Term</p>
            </div>
        </div>
    </div>
    
    <!-- Terms Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-calendar-alt"></i> Academic Terms</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Term Name</th>
                        <th>Session Year</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Duration</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($terms) > 0): ?>
                        <?php $count = 1; ?>
                        <?php foreach ($terms as $term): ?>
                            <?php
                            $start = new DateTime($term['start_date']);
                            $end = new DateTime($term['end_date']);
                            $duration = $start->diff($end)->days;
                            $is_current = isset($term['is_active']) ? $term['is_active'] : (isset($term['is_current']) ? $term['is_current'] : 0);
                            
                            // Generate session year from dates if not available
                            $session_year = isset($term['session_year']) && !empty($term['session_year']) 
                                ? $term['session_year'] 
                                : $start->format('Y') . '/' . $end->format('Y');
                            ?>
                            <tr style="<?php echo $is_current ? 'background: rgba(76, 175, 80, 0.05);' : ''; ?>">
                                <td><?php echo $count++; ?></td>
                                <td>
                                    <a href="#" onclick="toggleTermMenu(event, <?php echo $term['term_id']; ?>)" style="color: #007bff; cursor: pointer; text-decoration: none;">
                                        <strong><?php echo $term['term_name']; ?></strong>
                                        <i class="fas fa-chevron-down" style="font-size: 10px; margin-left: 5px;"></i>
                                    </a>
                                    <?php if ($is_current): ?>
                                        <br><span class="badge badge-success" style="font-size: 11px;">Current</span>
                                    <?php endif; ?>
                                    <!-- Term Menu Dropdown -->
                                    <div id="termMenu<?php echo $term['term_id']; ?>" style="display: none; position: absolute; background: white; border: 1px solid #ddd; border-radius: 5px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); z-index: 1000; min-width: 250px; margin-top: 5px;">
                                        <a href="../admin/marks.php?term_id=<?php echo $term['term_id']; ?>" style="display: block; padding: 10px 15px; color: #333; text-decoration: none; border-bottom: 1px solid #eee;">
                                            <i class="fas fa-pen" style="color: #007bff; width: 18px;"></i> Enter Marks
                                        </a>
                                        <a href="../admin/exams.php?term_id=<?php echo $term['term_id']; ?>" style="display: block; padding: 10px 15px; color: #333; text-decoration: none; border-bottom: 1px solid #eee;">
                                            <i class="fas fa-file-alt" style="color: #28a745; width: 18px;"></i> View Exams
                                        </a>
                                        <a href="../admin/report-cards.php?term_id=<?php echo $term['term_id']; ?>" style="display: block; padding: 10px 15px; color: #333; text-decoration: none; border-bottom: 1px solid #eee;">
                                            <i class="fas fa-graduation-cap" style="color: #17a2b8; width: 18px;"></i> Report Cards
                                        </a>
                                        <a href="../accountant/collect-school-fees.php?term_id=<?php echo $term['term_id']; ?>" style="display: block; padding: 10px 15px; color: #333; text-decoration: none; border-bottom: 1px solid #eee;">
                                            <i class="fas fa-money-bill-wave" style="color: #ffc107; width: 18px;"></i> Collect Fees
                                        </a>
                                        <a href="../accountant/fee-structure.php?term_id=<?php echo $term['term_id']; ?>" style="display: block; padding: 10px 15px; color: #333; text-decoration: none; border-bottom: 1px solid #eee;">
                                            <i class="fas fa-list-ul" style="color: #6c757d; width: 18px;"></i> Fee Structure
                                        </a>
                                        <a href="../admin/attendance-reports.php?term_id=<?php echo $term['term_id']; ?>" style="display: block; padding: 10px 15px; color: #333; text-decoration: none;">
                                            <i class="fas fa-chart-bar" style="color: #dc3545; width: 18px;"></i> Attendance Reports
                                        </a>
                                    </div>
                                </td>
                                <td><strong><?php echo $session_year; ?></strong></td>
                                <td><?php echo date('M d, Y', strtotime($term['start_date'])); ?></td>
                                <td><?php echo date('M d, Y', strtotime($term['end_date'])); ?></td>
                                <td><?php echo $duration; ?> days</td>
                                <td>
                                    <?php if ($is_current): ?>
                                        <span class="badge badge-success">Active</span>
                                    <?php else: ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="set_active">
                                            <input type="hidden" name="term_id" value="<?php echo $term['term_id']; ?>">
                                            <button type="submit" class="btn btn-success btn-sm">
                                                <i class="fas fa-check"></i> Set Active
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button onclick='openEditTermModal(<?php echo json_encode($term); ?>)' 
                                            class="btn btn-info btn-sm" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php if (!$is_current): ?>
                                        <button onclick="deleteTerm(<?php echo $term['term_id']; ?>, '<?php echo addslashes($term['term_name']); ?>')" 
                                                class="btn btn-danger btn-sm" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 60px;">
                                <i class="fas fa-calendar-alt" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                                <h3>No Academic Terms</h3>
                                <p style="color: var(--text-secondary); margin-bottom: 20px;">
                                    Create your first academic term to start managing the school year.
                                </p>
                                <button onclick="openAddTermModal()" class="btn btn-primary">
                                    <i class="fas fa-plus"></i> Add First Term
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Add/Edit Term Modal -->
    <div id="termModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="termModalTitle">Add Academic Term</h2>
                <button onclick="closeTermModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="termForm">
                <input type="hidden" name="action" id="termAction" value="add">
                <input type="hidden" name="term_id" id="termId">
                
                <div class="alert alert-info" style="margin-bottom: 20px;" id="termAlertBox">
                    <i class="fas fa-info-circle"></i>
                    <strong>Note:</strong> <span id="termAlertText">Create a new academic term</span>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label for="term_name">Term Name *</label>
                        <select name="term_name" id="term_name" required>
                            <option value="">-- Select Term --</option>
                            <option value="First Term">First Term</option>
                            <option value="Second Term">Second Term</option>
                            <option value="Third Term">Third Term</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="session_year">Session Year *</label>
                        <input type="text" name="session_year" id="session_year" placeholder="e.g., 2024/2025" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="start_date">Start Date *</label>
                        <input type="date" name="start_date" id="start_date" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="end_date">End Date *</label>
                        <input type="date" name="end_date" id="end_date" required>
                    </div>
                </div>
                
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                        <input type="checkbox" name="is_active" id="is_active">
                        <span>Set as active term</span>
                    </label>
                    <small style="color: var(--text-secondary);">Only one term can be active at a time</small>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeTermModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> <span id="termSubmitText">Create Term</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Form -->
    <form method="POST" id="deleteForm" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="term_id" id="delete_term_id">
    </form>
    
    <script>
    function openAddTermModal() {
        document.getElementById('termModal').style.display = 'block';
        document.getElementById('termModalTitle').textContent = 'Add Academic Term';
        document.getElementById('termAction').value = 'add';
        document.getElementById('termAlertText').textContent = 'Create a new academic term';
        document.getElementById('termSubmitText').textContent = 'Create Term';
        document.getElementById('termForm').reset();
        document.getElementById('termId').value = '';
    }
    
    function openEditTermModal(term) {
        document.getElementById('termModal').style.display = 'block';
        document.getElementById('termModalTitle').textContent = 'Edit Academic Term';
        document.getElementById('termAction').value = 'edit';
        document.getElementById('termAlertText').textContent = 'Update term information below';
        document.getElementById('termSubmitText').textContent = 'Update Term';
        document.getElementById('termId').value = term.term_id;
        document.getElementById('term_name').value = term.term_name;
        document.getElementById('session_year').value = term.session_year;
        document.getElementById('start_date').value = term.start_date;
        document.getElementById('end_date').value = term.end_date;
        document.getElementById('is_active').checked = term.is_active == 1;
    }
    
    function closeTermModal() {
        document.getElementById('termModal').style.display = 'none';
    }
    
    function deleteTerm(termId, termName) {
        if (confirm('Are you sure you want to delete ' + termName + '? This action cannot be undone.')) {
            document.getElementById('delete_term_id').value = termId;
            document.getElementById('deleteForm').submit();
        }
    }
    
    // ... existing code ...
    document.getElementById('termModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeTermModal();
        }
    });
    
    // Handle term menu dropdown
    function toggleTermMenu(event, termId) {
        event.preventDefault();
        const menu = document.getElementById('termMenu' + termId);
        
        // Close all other menus
        document.querySelectorAll('[id^="termMenu"]').forEach(m => {
            if (m.id !== 'termMenu' + termId) {
                m.style.display = 'none';
            }
        });
        
        // Toggle current menu
        menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
    }
    
    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('a[onclick^="toggleTermMenu"]')) {
            document.querySelectorAll('[id^="termMenu"]').forEach(menu => {
                menu.style.display = 'none';
            });
        }
    });
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
