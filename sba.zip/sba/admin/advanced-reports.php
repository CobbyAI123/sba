<?php
// admin/advanced-reports.php - Advanced Analytics and Reports
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Advanced Reports';
$current_user = check_permission(['admin', 'super-admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get report type
$report_type = sanitize_input($_GET['type'] ?? 'academic');

// Initialize report data
$report_data = [];

if ($report_type === 'academic') {
    // Academic Performance Report
    $stmt = $db->prepare("
        SELECT c.class_name,
               COUNT(DISTINCT s.student_id) as total_students,
               AVG(sa.total_score) as avg_score,
               MAX(sa.total_score) as highest_score,
               MIN(sa.total_score) as lowest_score,
               COUNT(DISTINCT CASE WHEN sa.total_score >= 70 THEN s.student_id END) as excellent,
               COUNT(DISTINCT CASE WHEN sa.total_score >= 50 AND sa.total_score < 70 THEN s.student_id END) as good,
               COUNT(DISTINCT CASE WHEN sa.total_score < 50 THEN s.student_id END) as needs_improvement
        FROM classes c
        LEFT JOIN students s ON c.class_id = s.class_id AND s.status = 'active'
        LEFT JOIN student_assessments sa ON s.student_id = sa.student_id
        WHERE c.school_id = ?
        GROUP BY c.class_id, c.class_name
        ORDER BY avg_score DESC
    ");
    $stmt->execute([$school_id]);
    $report_data['classes'] = $stmt->fetchAll();
    
    // Subject performance
    $stmt = $db->prepare("
        SELECT s.subject_name,
               COUNT(DISTINCT sa.student_id) as students_examined,
               AVG(sa.total_score) as avg_score,
               COUNT(DISTINCT CASE WHEN sa.total_score >= 50 THEN sa.student_id END) as passed
        FROM subjects s
        LEFT JOIN student_assessments sa ON s.subject_id = sa.subject_id
        WHERE s.school_id = ?
        GROUP BY s.subject_id, s.subject_name
        ORDER BY avg_score DESC
    ");
    $stmt->execute([$school_id]);
    $report_data['subjects'] = $stmt->fetchAll();
}

elseif ($report_type === 'attendance') {
    // Attendance Report
    $stmt = $db->prepare("
        SELECT c.class_name,
               COUNT(DISTINCT CASE WHEN a.status = 'present' THEN a.student_id END) as present_count,
               COUNT(DISTINCT CASE WHEN a.status = 'absent' THEN a.student_id END) as absent_count,
               COUNT(DISTINCT a.student_id) as total_students,
               ROUND(COUNT(DISTINCT CASE WHEN a.status = 'present' THEN a.student_id END) * 100.0 / COUNT(DISTINCT a.student_id), 1) as attendance_rate
        FROM classes c
        LEFT JOIN students s ON c.class_id = s.class_id
        LEFT JOIN attendance a ON s.student_id = a.student_id
        WHERE c.school_id = ? AND a.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY c.class_id, c.class_name
        ORDER BY attendance_rate DESC
    ");
    $stmt->execute([$school_id]);
    $report_data['classes'] = $stmt->fetchAll();
}

elseif ($report_type === 'financial') {
    // Financial Report
    $stmt = $db->prepare("
        SELECT c.class_name,
               COUNT(DISTINCT s.student_id) as total_students,
               SUM(f.amount) as total_fees,
               SUM(CASE WHEN p.payment_id IS NOT NULL THEN p.amount ELSE 0 END) as collected,
               SUM(f.amount) - SUM(CASE WHEN p.payment_id IS NOT NULL THEN p.amount ELSE 0 END) as outstanding,
               ROUND(SUM(CASE WHEN p.payment_id IS NOT NULL THEN p.amount ELSE 0 END) * 100.0 / NULLIF(SUM(f.amount), 0), 1) as collection_rate
        FROM classes c
        INNER JOIN students s ON c.class_id = s.class_id
        LEFT JOIN fee_structure f ON c.class_id = f.class_id
        LEFT JOIN payments p ON s.student_id = p.student_id
        WHERE c.school_id = ? AND s.status = 'active'
        GROUP BY c.class_id, c.class_name
        ORDER BY collection_rate DESC
    ");
    $stmt->execute([$school_id]);
    $report_data['classes'] = $stmt->fetchAll();
}

elseif ($report_type === 'enrollment') {
    // Enrollment Report
    $stmt = $db->prepare("
        SELECT c.class_name,
               COUNT(CASE WHEN s.gender = 'male' THEN 1 END) as male,
               COUNT(CASE WHEN s.gender = 'female' THEN 1 END) as female,
               COUNT(s.student_id) as total,
               COUNT(CASE WHEN s.status = 'active' THEN 1 END) as active,
               COUNT(CASE WHEN s.status = 'inactive' THEN 1 END) as inactive
        FROM classes c
        LEFT JOIN students s ON c.class_id = s.class_id
        WHERE c.school_id = ?
        GROUP BY c.class_id, c.class_name
        ORDER BY total DESC
    ");
    $stmt->execute([$school_id]);
    $report_data['classes'] = $stmt->fetchAll();
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Report Navigation -->
    <div style="margin-bottom: 30px; display: flex; gap: 10px; flex-wrap: wrap;">
        <a href="?type=academic" class="btn <?php echo $report_type === 'academic' ? 'btn-primary' : 'btn-secondary'; ?>">
            <i class="fas fa-chart-bar"></i> Academic Performance
        </a>
        <a href="?type=attendance" class="btn <?php echo $report_type === 'attendance' ? 'btn-primary' : 'btn-secondary'; ?>">
            <i class="fas fa-calendar-check"></i> Attendance
        </a>
        <a href="?type=financial" class="btn <?php echo $report_type === 'financial' ? 'btn-primary' : 'btn-secondary'; ?>">
            <i class="fas fa-money-bill-wave"></i> Financial
        </a>
        <a href="?type=enrollment" class="btn <?php echo $report_type === 'enrollment' ? 'btn-primary' : 'btn-secondary'; ?>">
            <i class="fas fa-users"></i> Enrollment
        </a>
        <button onclick="window.print()" class="btn btn-info" style="margin-left: auto;">
            <i class="fas fa-print"></i> Print Report
        </button>
    </div>
    
    <?php if ($report_type === 'academic'): ?>
        <!-- Academic Performance Report -->
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h3><i class="fas fa-graduation-cap"></i> Class Performance Summary</h3>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Class</th>
                            <th>Students</th>
                            <th>Average Score</th>
                            <th>Highest Score</th>
                            <th>Lowest Score</th>
                            <th style="text-align: center;">Excellent (70+)</th>
                            <th style="text-align: center;">Good (50-69)</th>
                            <th style="text-align: center;">Needs Improvement (&lt;50)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($report_data['classes'] as $class): ?>
                            <tr>
                                <td><strong><?php echo $class['class_name']; ?></strong></td>
                                <td><?php echo $class['total_students']; ?></td>
                                <td><?php echo number_format($class['avg_score'] ?? 0, 1); ?>%</td>
                                <td><?php echo number_format($class['highest_score'] ?? 0, 1); ?>%</td>
                                <td><?php echo number_format($class['lowest_score'] ?? 0, 1); ?>%</td>
                                <td style="text-align: center;">
                                    <span style="background: var(--success-green); color: white; padding: 3px 8px; border-radius: 3px; font-weight: bold;">
                                        <?php echo $class['excellent']; ?>
                                    </span>
                                </td>
                                <td style="text-align: center;">
                                    <span style="background: var(--warning-orange); color: white; padding: 3px 8px; border-radius: 3px; font-weight: bold;">
                                        <?php echo $class['good']; ?>
                                    </span>
                                </td>
                                <td style="text-align: center;">
                                    <span style="background: var(--danger-red); color: white; padding: 3px 8px; border-radius: 3px; font-weight: bold;">
                                        <?php echo $class['needs_improvement']; ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Subject Performance -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-book"></i> Subject Performance Analysis</h3>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Subject</th>
                            <th>Students Examined</th>
                            <th>Average Score</th>
                            <th>Pass Rate</th>
                            <th>Performance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($report_data['subjects'] as $subject): ?>
                            <tr>
                                <td><strong><?php echo $subject['subject_name']; ?></strong></td>
                                <td><?php echo $subject['students_examined']; ?></td>
                                <td><?php echo number_format($subject['avg_score'] ?? 0, 1); ?>%</td>
                                <td>
                                    <?php 
                                        $pass_rate = ($subject['passed'] / max($subject['students_examined'], 1)) * 100;
                                        echo number_format($pass_rate, 1) . '%';
                                    ?>
                                </td>
                                <td>
                                    <div style="width: 100%; height: 8px; background: var(--bg-secondary); border-radius: 4px; overflow: hidden;">
                                        <div style="height: 100%; width: <?php echo min($subject['avg_score'] ?? 0, 100); ?>%; background: var(--success-green);"></div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    <?php elseif ($report_type === 'attendance'): ?>
        <!-- Attendance Report -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-calendar-check"></i> Class Attendance Report (Last 30 days)</h3>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Class</th>
                            <th>Total Students</th>
                            <th style="text-align: center;">Present</th>
                            <th style="text-align: center;">Absent</th>
                            <th>Attendance Rate</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($report_data['classes'] as $class): ?>
                            <tr>
                                <td><strong><?php echo $class['class_name']; ?></strong></td>
                                <td><?php echo $class['total_students']; ?></td>
                                <td style="text-align: center;"><?php echo $class['present_count']; ?></td>
                                <td style="text-align: center;"><?php echo $class['absent_count']; ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="flex: 1;">
                                            <div style="width: 100%; height: 8px; background: var(--bg-secondary); border-radius: 4px; overflow: hidden;">
                                                <div style="height: 100%; width: <?php echo $class['attendance_rate']; ?>%; background: var(--success-green);"></div>
                                            </div>
                                        </div>
                                        <strong><?php echo number_format($class['attendance_rate'], 1); ?>%</strong>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    
    <?php elseif ($report_type === 'financial'): ?>
        <!-- Financial Report -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-money-bill-wave"></i> Financial Collection Report</h3>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Class</th>
                            <th>Students</th>
                            <th>Total Fees</th>
                            <th>Amount Collected</th>
                            <th>Outstanding</th>
                            <th>Collection Rate</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $grand_total_fees = 0;
                            $grand_total_collected = 0;
                            $grand_outstanding = 0;
                            foreach ($report_data['classes'] as $class): 
                                $grand_total_fees += $class['total_fees'] ?? 0;
                                $grand_total_collected += $class['collected'] ?? 0;
                                $grand_outstanding += $class['outstanding'] ?? 0;
                        ?>
                            <tr>
                                <td><strong><?php echo $class['class_name']; ?></strong></td>
                                <td><?php echo $class['total_students']; ?></td>
                                <td><?php echo format_currency($class['total_fees'] ?? 0); ?></td>
                                <td><strong style="color: var(--success-green);"><?php echo format_currency($class['collected'] ?? 0); ?></strong></td>
                                <td style="color: var(--danger-red);"><?php echo format_currency($class['outstanding'] ?? 0); ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="flex: 1;">
                                            <div style="width: 100%; height: 8px; background: var(--bg-secondary); border-radius: 4px; overflow: hidden;">
                                                <div style="height: 100%; width: <?php echo $class['collection_rate'] ?? 0; ?>%; background: var(--success-green);"></div>
                                            </div>
                                        </div>
                                        <strong><?php echo number_format($class['collection_rate'] ?? 0, 1); ?>%</strong>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <tr style="background: var(--bg-secondary); font-weight: bold;">
                            <td colspan="2">TOTAL</td>
                            <td><?php echo format_currency($grand_total_fees); ?></td>
                            <td style="color: var(--success-green);"><?php echo format_currency($grand_total_collected); ?></td>
                            <td style="color: var(--danger-red);"><?php echo format_currency($grand_outstanding); ?></td>
                            <td>
                                <?php 
                                    $overall_rate = ($grand_total_collected / max($grand_total_fees, 1)) * 100;
                                    echo number_format($overall_rate, 1) . '%';
                                ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    
    <?php elseif ($report_type === 'enrollment'): ?>
        <!-- Enrollment Report -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-users"></i> Enrollment Summary</h3>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Class</th>
                            <th style="text-align: center;">Male</th>
                            <th style="text-align: center;">Female</th>
                            <th>Total Enrolled</th>
                            <th style="text-align: center;">Active</th>
                            <th style="text-align: center;">Inactive</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $total_male = 0;
                            $total_female = 0;
                            $total_students = 0;
                            $total_active = 0;
                            $total_inactive = 0;
                            foreach ($report_data['classes'] as $class): 
                                $total_male += $class['male'];
                                $total_female += $class['female'];
                                $total_students += $class['total'];
                                $total_active += $class['active'];
                                $total_inactive += $class['inactive'];
                        ?>
                            <tr>
                                <td><strong><?php echo $class['class_name']; ?></strong></td>
                                <td style="text-align: center;">
                                    <span style="background: var(--info-blue); color: white; padding: 3px 8px; border-radius: 3px;">
                                        <?php echo $class['male']; ?>
                                    </span>
                                </td>
                                <td style="text-align: center;">
                                    <span style="background: var(--pink-coral); color: white; padding: 3px 8px; border-radius: 3px;">
                                        <?php echo $class['female']; ?>
                                    </span>
                                </td>
                                <td><strong><?php echo $class['total']; ?></strong></td>
                                <td style="text-align: center;" style="color: var(--success-green);"><?php echo $class['active']; ?></td>
                                <td style="text-align: center;" style="color: var(--danger-red);"><?php echo $class['inactive']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <tr style="background: var(--bg-secondary); font-weight: bold;">
                            <td>TOTAL</td>
                            <td style="text-align: center;"><?php echo $total_male; ?></td>
                            <td style="text-align: center;"><?php echo $total_female; ?></td>
                            <td><?php echo $total_students; ?></td>
                            <td style="text-align: center;"><?php echo $total_active; ?></td>
                            <td style="text-align: center;"><?php echo $total_inactive; ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    
    <?php endif; ?>
    
    <style media="print">
        @media print {
            .btn, [onclick] { display: none !important; }
            body { background: white; }
            .card { break-inside: avoid; }
        }
    </style>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
