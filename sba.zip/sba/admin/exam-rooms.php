<?php
// admin/exam-rooms.php - Manage Exam Rooms
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Exam Rooms';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$user_id = $current_user['user_id'];

// Handle room actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('error', 'Invalid request');
        redirect(APP_URL . '/admin/exam-rooms.php');
        exit;
    }
    
    if ($_POST['action'] == 'add_room') {
        $room_number = sanitize_input($_POST['room_number']);
        $room_name = sanitize_input($_POST['room_name']);
        $capacity = (int)$_POST['capacity'];
        $rows = !empty($_POST['rows']) ? (int)$_POST['rows'] : NULL;
        $columns = !empty($_POST['columns']) ? (int)$_POST['columns'] : NULL;
        $floor = sanitize_input($_POST['floor']);
        $building = sanitize_input($_POST['building']);
        $facilities = sanitize_input($_POST['facilities']);
        
        try {
            $stmt = $db->prepare("
                INSERT INTO exam_rooms 
                (school_id, room_number, room_name, capacity, rows, columns, floor, building, facilities, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
            ");
            $stmt->execute([$school_id, $room_number, $room_name, $capacity, $rows, $columns, $floor, $building, $facilities]);
            
            log_activity($user_id, "Added exam room: $room_number", 'exam_rooms', $db->lastInsertId());
            set_message('success', 'Exam room added successfully!');
            redirect(APP_URL . '/admin/exam-rooms.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error adding room: ' . $e->getMessage());
        }
    } elseif ($_POST['action'] == 'update_status') {
        $room_id = (int)$_POST['room_id'];
        $status = sanitize_input($_POST['status']);
        
        try {
            $stmt = $db->prepare("UPDATE exam_rooms SET status = ? WHERE room_id = ? AND school_id = ?");
            $stmt->execute([$status, $room_id, $school_id]);
            
            log_activity($user_id, "Updated room status", 'exam_rooms', $room_id);
            set_message('success', 'Room status updated!');
            redirect(APP_URL . '/admin/exam-rooms.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error updating status: ' . $e->getMessage());
        }
    } elseif ($_POST['action'] == 'delete_room') {
        $room_id = (int)$_POST['room_id'];
        
        try {
            $stmt = $db->prepare("DELETE FROM exam_rooms WHERE room_id = ? AND school_id = ?");
            $stmt->execute([$room_id, $school_id]);
            
            log_activity($user_id, "Deleted exam room ID: $room_id", 'exam_rooms', $room_id);
            set_message('success', 'Room deleted successfully!');
            redirect(APP_URL . '/admin/exam-rooms.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error deleting room: ' . $e->getMessage());
        }
    }
}

// Get all rooms
// ... existing code ...
$stmt = $db->prepare("
    SELECT 
        r.*,
        COUNT(DISTINCT es.schedule_id) as exams_scheduled
    FROM exam_rooms r
    LEFT JOIN exam_schedule es ON r.room_id = es.room_id
    WHERE r.school_id = ?
    GROUP BY r.room_id
    ORDER BY r.room_number
");
$stmt->execute([$school_id]);
$rooms = $stmt->fetchAll();

// Statistics
$total_rooms = count($rooms);
$active_rooms = count(array_filter($rooms, fn($r) => $r['status'] == 'active'));
$total_capacity = array_sum(array_column($rooms, 'capacity'));

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .room-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 15px;
        transition: all 0.3s ease;
    }
    
    .room-card:hover {
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        border-color: var(--primary-blue);
    }
    
    .room-card.active {
        border-left: 4px solid #34C759;
    }
    
    .room-card.maintenance {
        border-left: 4px solid #FF9500;
    }
    
    .room-card.unavailable {
        border-left: 4px solid #FF3B30;
    }
    
    .status-badge {
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .badge-active { background: rgba(52, 199, 89, 0.1); color: #34C759; }
    .badge-maintenance { background: rgba(255, 149, 0, 0.1); color: #FF9500; }
    .badge-unavailable { background: rgba(255, 59, 48, 0.1); color: #FF3B30; }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.7);
        z-index: 9999;
        overflow-y: auto;
    }
    
    .modal-content {
        max-width: 600px;
        margin: 30px auto;
        background: var(--bg-card);
        border-radius: 15px;
        padding: 30px;
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-door-open"></i> Exam Rooms</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Manage examination rooms and facilities
        </p>
    </div>
    
    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 25px;">
        <div style="background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $total_rooms; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Rooms</p>
        </div>
        <div style="background: linear-gradient(135deg, #34C759, #30D158); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $active_rooms; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Active Rooms</p>
        </div>
        <div style="background: linear-gradient(135deg, #5856D6, #5E5CE6); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $total_capacity; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Capacity</p>
        </div>
    </div>
    
    <!-- Actions -->
    <div style="margin-bottom: 20px;">
        <button onclick="showAddModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add Exam Room
        </button>
        <a href="<?php echo APP_URL; ?>/admin/manage-exams.php" class="btn btn-secondary">
            <i class="fas fa-clipboard-list"></i> Manage Exams
        </a>
    </div>
    
    <!-- Rooms List -->
    <?php if (count($rooms) > 0): ?>
        <?php foreach ($rooms as $room): ?>
            <div class="room-card <?php echo $room['status']; ?>">
                <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                            <h3 style="margin: 0;">
                                <i class="fas fa-door-open"></i> <?php echo htmlspecialchars($room['room_number']); ?>
                                <?php if ($room['room_name']): ?>
                                    - <?php echo htmlspecialchars($room['room_name']); ?>
                                <?php endif; ?>
                            </h3>
                            <span class="status-badge badge-<?php echo $room['status']; ?>">
                                <?php echo ucfirst($room['status']); ?>
                            </span>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin: 15px 0;">
                            <div>
                                <strong>Capacity:</strong> <?php echo $room['capacity']; ?> students
                            </div>
                            <?php if ($room['rows'] && $room['columns']): ?>
                                <div>
                                    <strong>Layout:</strong> <?php echo $room['rows']; ?> × <?php echo $room['columns']; ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($room['floor']): ?>
                                <div>
                                    <strong>Floor:</strong> <?php echo htmlspecialchars($room['floor']); ?>
                                </div>
                            <?php endif; ?>
                            <?php if ($room['building']): ?>
                                <div>
                                    <strong>Building:</strong> <?php echo htmlspecialchars($room['building']); ?>
                                </div>
                            <?php endif; ?>
                            <div>
                                <strong>Exams Scheduled:</strong> <?php echo $room['exams_scheduled']; ?>
                            </div>
                        </div>
                        
                        <?php if ($room['facilities']): ?>
                            <div style="background: rgba(0,0,0,0.02); padding: 10px; border-radius: 8px; margin-top: 10px;">
                                <strong>Facilities:</strong> <?php echo htmlspecialchars($room['facilities']); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 5px; margin-left: 20px;">
                        <?php if ($room['status'] == 'active'): ?>
                            <form method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="update_status">
                                <input type="hidden" name="room_id" value="<?php echo $room['room_id']; ?>">
                                <input type="hidden" name="status" value="maintenance">
                                <button type="submit" class="btn btn-sm btn-warning" title="Mark Maintenance">
                                    <i class="fas fa-tools"></i>
                                </button>
                            </form>
                        <?php else: ?>
                            <form method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="update_status">
                                <input type="hidden" name="room_id" value="<?php echo $room['room_id']; ?>">
                                <input type="hidden" name="status" value="active">
                                <button type="submit" class="btn btn-sm btn-success" title="Mark Active">
                                    <i class="fas fa-check"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                        
                        <?php if ($room['exams_scheduled'] == 0): ?>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this room?')">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="delete_room">
                                <input type="hidden" name="room_id" value="<?php echo $room['room_id']; ?>">
                                <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div style="text-align: center; padding: 60px; background: var(--bg-card); border-radius: 15px;">
            <i class="fas fa-door-open" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
            <h3 style="color: var(--text-secondary);">No Exam Rooms Yet</h3>
            <p style="color: var(--text-secondary);">Add examination rooms to get started</p>
        </div>
    <?php endif; ?>
    
    <!-- Add Room Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="margin: 0;"><i class="fas fa-plus"></i> Add Exam Room</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="add_room">
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <div class="form-group">
                        <label>Room Number *</label>
                        <input type="text" name="room_number" required placeholder="e.g., ROOM-001">
                    </div>
                    
                    <div class="form-group">
                        <label>Room Name</label>
                        <input type="text" name="room_name" placeholder="e.g., Main Hall">
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                    <div class="form-group">
                        <label>Capacity *</label>
                        <input type="number" name="capacity" required min="1" placeholder="50">
                    </div>
                    
                    <div class="form-group">
                        <label>Rows</label>
                        <input type="number" name="rows" min="1" placeholder="10">
                    </div>
                    
                    <div class="form-group">
                        <label>Columns</label>
                        <input type="number" name="columns" min="1" placeholder="5">
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <div class="form-group">
                        <label>Floor</label>
                        <input type="text" name="floor" placeholder="e.g., Ground Floor">
                    </div>
                    
                    <div class="form-group">
                        <label>Building</label>
                        <input type="text" name="building" placeholder="e.g., Main Building">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Facilities</label>
                    <textarea name="facilities" rows="2" placeholder="e.g., AC, Projector, Whiteboard..."></textarea>
                </div>
                
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check"></i> Add Room
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showAddModal() {
        document.getElementById('addModal').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('addModal').style.display = 'none';
    }
    
    window.onclick = function(event) {
        const modal = document.getElementById('addModal');
        if (event.target == modal) {
            closeModal();
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
