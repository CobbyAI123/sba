<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'DB Migrations';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

$results = [];

function table_exists(PDO $db, string $table): bool {
    $stmt = $db->prepare("SHOW TABLES LIKE ?");
    $stmt->execute([$table]);
    return (bool)$stmt->fetchColumn();
}

function column_exists(PDO $db, string $table, string $column): bool {
    $stmt = $db->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
    $stmt->execute([$column]);
    return (bool)$stmt->fetch();
}

function index_exists(PDO $db, string $table, string $index_name): bool {
    $stmt = $db->prepare("SHOW INDEX FROM `$table` WHERE Key_name = ?");
    $stmt->execute([$index_name]);
    return (bool)$stmt->fetch();
}

function run_step(array &$results, string $label, callable $fn): void {
    try {
        $changed = $fn();
        $results[] = [
            'label' => $label,
            'status' => $changed ? 'updated' : 'ok',
            'message' => $changed ? 'Applied.' : 'Already up to date.'
        ];
    } catch (Throwable $e) {
        $results[] = [
            'label' => $label,
            'status' => 'error',
            'message' => $e->getMessage()
        ];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'run') {
    run_step($results, 'Schools: website + principal_name columns', function() use ($db) {
        $changed = false;
        if (!column_exists($db, 'schools', 'website')) {
            $db->exec("ALTER TABLE schools ADD COLUMN website VARCHAR(255) NULL AFTER email");
            $changed = true;
        }
        if (!column_exists($db, 'schools', 'principal_name')) {
            $db->exec("ALTER TABLE schools ADD COLUMN principal_name VARCHAR(255) NULL AFTER website");
            $changed = true;
        }
        return $changed;
    });

    run_step($results, 'Students: exemption columns', function() use ($db) {
        $changed = false;
        $cols = [
            ['is_exempt_tuition', "ALTER TABLE students ADD COLUMN is_exempt_tuition BOOLEAN DEFAULT FALSE"],
            ['is_exempt_transport', "ALTER TABLE students ADD COLUMN is_exempt_transport BOOLEAN DEFAULT FALSE"],
            ['is_exempt_canteen', "ALTER TABLE students ADD COLUMN is_exempt_canteen BOOLEAN DEFAULT FALSE"],
            ['exempt_tuition_reason', "ALTER TABLE students ADD COLUMN exempt_tuition_reason VARCHAR(255) NULL"],
            ['exempt_transport_reason', "ALTER TABLE students ADD COLUMN exempt_transport_reason VARCHAR(255) NULL"],
            ['exempt_canteen_reason', "ALTER TABLE students ADD COLUMN exempt_canteen_reason VARCHAR(255) NULL"],
        ];
        foreach ($cols as $c) {
            if (!column_exists($db, 'students', $c[0])) {
                $db->exec($c[1]);
                $changed = true;
            }
        }
        return $changed;
    });

    run_step($results, 'Students: transport fields (transport_opted + route_id)', function() use ($db) {
        $changed = false;
        if (!column_exists($db, 'students', 'transport_opted')) {
            $db->exec("ALTER TABLE students ADD COLUMN transport_opted TINYINT(1) DEFAULT 0");
            $changed = true;
        }
        if (!column_exists($db, 'students', 'route_id')) {
            $db->exec("ALTER TABLE students ADD COLUMN route_id INT NULL");
            $changed = true;
        }
        if (table_exists($db, 'students') && column_exists($db, 'students', 'route_id')) {
            if (!index_exists($db, 'students', 'idx_students_route_id')) {
                $db->exec("ALTER TABLE students ADD INDEX idx_students_route_id (route_id)");
                $changed = true;
            }
        }
        return $changed;
    });

    run_step($results, 'Transport routes table + monthly_fee column', function() use ($db) {
        $changed = false;
        if (!table_exists($db, 'transport_routes')) {
            $db->exec("
                CREATE TABLE transport_routes (
                    route_id INT PRIMARY KEY AUTO_INCREMENT,
                    school_id INT NOT NULL,
                    route_name VARCHAR(100) NOT NULL,
                    vehicle_number VARCHAR(50),
                    driver_name VARCHAR(100),
                    driver_phone VARCHAR(20),
                    monthly_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
                    status ENUM('active','inactive') DEFAULT 'active',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    KEY idx_school (school_id),
                    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE
                )
            ");
            $changed = true;
        }

        if (!column_exists($db, 'transport_routes', 'monthly_fee')) {
            $db->exec("ALTER TABLE transport_routes ADD COLUMN monthly_fee DECIMAL(10,2) NOT NULL DEFAULT 0");
            $changed = true;

            if (column_exists($db, 'transport_routes', 'fare')) {
                $db->exec("UPDATE transport_routes SET monthly_fee = fare WHERE monthly_fee = 0 AND fare IS NOT NULL");
            }
        }

        if (column_exists($db, 'transport_routes', 'fare') && !column_exists($db, 'transport_routes', 'monthly_fee')) {
            $db->exec("ALTER TABLE transport_routes CHANGE fare monthly_fee DECIMAL(10,2) NOT NULL DEFAULT 0");
            $changed = true;
        }

        return $changed;
    });

    run_step($results, 'Teacher class assignments table', function() use ($db) {
        $changed = false;
        if (!table_exists($db, 'teacher_classes')) {
            $db->exec("
                CREATE TABLE teacher_classes (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    school_id INT NOT NULL,
                    teacher_id INT NOT NULL,
                    class_id INT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY uniq_school_teacher_class (school_id, teacher_id, class_id),
                    KEY idx_teacher (teacher_id),
                    KEY idx_class (class_id),
                    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
                    FOREIGN KEY (teacher_id) REFERENCES users(user_id) ON DELETE CASCADE,
                    FOREIGN KEY (class_id) REFERENCES classes(class_id) ON DELETE CASCADE
                )
            ");
            $changed = true;
        }
        return $changed;
    });

    run_step($results, 'Canteen/Bus collection table', function() use ($db) {
        $changed = false;
        if (!table_exists($db, 'student_canteen_bus_payments')) {
            $db->exec("
                CREATE TABLE student_canteen_bus_payments (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    school_id INT NOT NULL,
                    student_id INT NOT NULL,
                    class_id INT NOT NULL,
                    payment_date DATE NOT NULL,
                    period ENUM('weekly','monthly') NOT NULL,
                    canteen_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
                    bus_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
                    collected_by INT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY uniq_student_day_period (school_id, student_id, payment_date, period),
                    KEY idx_school_class_date (school_id, class_id, payment_date),
                    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
                    FOREIGN KEY (class_id) REFERENCES classes(class_id) ON DELETE CASCADE,
                    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
                    FOREIGN KEY (collected_by) REFERENCES users(user_id) ON DELETE SET NULL
                )
            ");
            $changed = true;
        }
        return $changed;
    });

    if (count(array_filter($results, fn($r) => $r['status'] === 'error')) > 0) {
        set_message('error', 'Some migrations failed. See results below.');
    } else {
        set_message('success', 'Migrations completed.');
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
        <div>
            <h2 style="margin: 0;"><i class="fas fa-database"></i> DB Migrations</h2>
            <p style="margin: 5px 0 0; color: var(--text-secondary);">Run safe, idempotent schema updates for this installation.</p>
        </div>
        <div>
            <form method="POST" style="margin: 0;">
                <input type="hidden" name="action" value="run">
                <button class="btn btn-primary" type="submit">
                    <i class="fas fa-play"></i> Run Migrations
                </button>
            </form>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list-check"></i> Results</h3>
        </div>
        <div style="padding: 20px; overflow-x: auto;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Step</th>
                        <th>Status</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($results) === 0): ?>
                        <tr>
                            <td colspan="3" style="color: var(--text-secondary);">No migrations run yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($results as $r): ?>
                            <?php
                                $badge = 'info';
                                if ($r['status'] === 'ok') $badge = 'success';
                                if ($r['status'] === 'updated') $badge = 'warning';
                                if ($r['status'] === 'error') $badge = 'danger';
                            ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($r['label']); ?></strong></td>
                                <td>
                                    <span class="badge badge-<?php echo $badge; ?>">
                                        <?php echo htmlspecialchars($r['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($r['message']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

include BASE_PATH . '/includes/footer.php';
