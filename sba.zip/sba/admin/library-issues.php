<?php
// admin/library-issues.php - Issue and Return Books
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Library Issues';
$current_user = check_permission(['admin', 'librarian']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$user_id = $current_user['user_id'];

// Get library settings
$stmt = $db->prepare("SELECT * FROM library_settings WHERE school_id = ?");
$stmt->execute([$school_id]);
$settings = $stmt->fetch();

// Handle issue/return actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('error', 'Invalid request. Please try again.');
        redirect(APP_URL . '/admin/library-issues.php');
        exit;
    }
    
    if ($_POST['action'] == 'issue_book') {
        $book_id = (int)$_POST['book_id'];
        $student_id = (int)$_POST['student_id'];
        $issue_duration = (int)($_POST['issue_duration'] ?? $settings['issue_duration_days']);
        
        try {
            // Check if book is available
            $stmt = $db->prepare("SELECT available_copies, title FROM library_books WHERE book_id = ? AND school_id = ?");
            $stmt->execute([$book_id, $school_id]);
            $book = $stmt->fetch();
            
            if (!$book || $book['available_copies'] <= 0) {
                set_message('error', 'Book is not available for issue');
                redirect(APP_URL . '/admin/library-issues.php');
                exit;
            }
            
            // Check student's current issues
            $stmt = $db->prepare("SELECT COUNT(*) as count FROM library_issues WHERE student_id = ? AND status = 'issued'");
            $stmt->execute([$student_id]);
            $current_issues = $stmt->fetch()['count'];
            
            if ($current_issues >= $settings['max_books_per_student']) {
                set_message('error', 'Student has reached maximum book limit');
                redirect(APP_URL . '/admin/library-issues.php');
                exit;
            }
            
            // Issue the book
            $issue_date = date('Y-m-d');
            $due_date = date('Y-m-d', strtotime("+$issue_duration days"));
            
            $stmt = $db->prepare("
                INSERT INTO library_issues 
                (school_id, book_id, student_id, issued_by, issue_date, due_date, status)
                VALUES (?, ?, ?, ?, ?, ?, 'issued')
            ");
            $stmt->execute([$school_id, $book_id, $student_id, $user_id, $issue_date, $due_date]);
            
            log_activity($user_id, "Issued book '{$book['title']}' to student ID: $student_id", 'library_issues', $db->lastInsertId());
            set_message('success', 'Book issued successfully!');
            redirect(APP_URL . '/admin/library-issues.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error issuing book: ' . $e->getMessage());
        }
    } elseif ($_POST['action'] == 'return_book') {
        $issue_id = (int)$_POST['issue_id'];
        $book_condition = sanitize_input($_POST['book_condition']);
        
        try {
            // Get issue details
            $stmt = $db->prepare("
                SELECT li.*, lb.title, ls.fine_per_day, ls.auto_calculate_fines
                FROM library_issues li
                INNER JOIN library_books lb ON li.book_id = lb.book_id
                INNER JOIN library_settings ls ON li.school_id = ls.school_id
                WHERE li.issue_id = ? AND li.school_id = ?
            ");
            $stmt->execute([$issue_id, $school_id]);
            $issue = $stmt->fetch();
            
            if (!$issue) {
                set_message('error', 'Issue record not found');
                redirect(APP_URL . '/admin/library-issues.php');
                exit;
            }
            
            // Calculate fine if overdue
            $fine_amount = 0;
            $return_date = date('Y-m-d');
            
            if ($issue['auto_calculate_fines'] && $return_date > $issue['due_date']) {
                $days_late = (strtotime($return_date) - strtotime($issue['due_date'])) / 86400;
                $fine_amount = $days_late * $issue['fine_per_day'];
            }
            
            // Update issue record
            $stmt = $db->prepare("
                UPDATE library_issues 
                SET return_date = ?, 
                    returned_by = ?, 
                    book_condition_on_return = ?,
                    fine_amount = ?,
                    fine_status = ?,
                    status = 'returned'
                WHERE issue_id = ?
            ");
            
            $fine_status = $fine_amount > 0 ? 'pending' : 'none';
            $stmt->execute([$return_date, $user_id, $book_condition, $fine_amount, $fine_status, $issue_id]);
            
            log_activity($user_id, "Returned book '{$issue['title']}' from student ID: {$issue['student_id']}", 'library_issues', $issue_id);
            set_message('success', 'Book returned successfully!' . ($fine_amount > 0 ? ' Fine: $' . number_format($fine_amount, 2) : ''));
            redirect(APP_URL . '/admin/library-issues.php');
            
        } catch (PDOException $e) {
            set_message('error', 'Error returning book: ' . $e->getMessage());
        }
    }
}

// Get current issues
$stmt = $db->prepare("
    SELECT 
        li.issue_id,
        li.issue_date,
        li.due_date,
        DATEDIFF(CURDATE(), li.due_date) as days_overdue,
        CASE 
            WHEN li.due_date < CURDATE() THEN 'overdue'
            WHEN DATEDIFF(li.due_date, CURDATE()) <= 2 THEN 'due_soon'
            ELSE 'active'
        END as issue_status,
        lb.book_id,
        lb.title as book_title,
        lb.author,
        lb.isbn,
        s.student_id,
        s.first_name,
        s.last_name,
        c.class_name,
        li.fine_amount,
        li.fine_paid,
        li.fine_status
    FROM library_issues li
    INNER JOIN library_books lb ON li.book_id = lb.book_id
    INNER JOIN students s ON li.student_id = s.student_id
    INNER JOIN classes c ON s.class_id = c.class_id
    WHERE li.school_id = ? AND li.status = 'issued'
    ORDER BY 
        CASE 
            WHEN li.due_date < CURDATE() THEN 1 
            WHEN DATEDIFF(li.due_date, CURDATE()) <= 2 THEN 2 
            ELSE 3 
        END,
        li.due_date
");
$stmt->execute([$school_id]);
$current_issues = $stmt->fetchAll();

// Get available books for issue
$stmt = $db->prepare("
    SELECT book_id, title, author, isbn, available_copies 
    FROM library_books 
    WHERE school_id = ? AND available_copies > 0 
    ORDER BY title
");
$stmt->execute([$school_id]);
$available_books = $stmt->fetchAll();

// Get active students
$stmt = $db->prepare("
    SELECT s.student_id, s.first_name, s.last_name, c.class_name,
           COUNT(li.issue_id) as current_issues
    FROM students s
    INNER JOIN classes c ON s.class_id = c.class_id
    LEFT JOIN library_issues li ON s.student_id = li.student_id AND li.status = 'issued'
    WHERE s.school_id = ? AND s.status = 'active'
    GROUP BY s.student_id
    ORDER BY s.first_name, s.last_name
");
$stmt->execute([$school_id]);
$students = $stmt->fetchAll();

// Statistics
$total_issued = count($current_issues);
$overdue = count(array_filter($current_issues, fn($i) => $i['issue_status'] == 'overdue'));
$due_soon = count(array_filter($current_issues, fn($i) => $i['issue_status'] == 'due_soon'));

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .issue-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 15px;
        transition: all 0.3s ease;
    }
    
    .issue-card:hover {
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }
    
    .issue-card.overdue {
        border-left: 4px solid #FF3B30;
        background: rgba(255, 59, 48, 0.02);
    }
    
    .issue-card.due-soon {
        border-left: 4px solid #FF9500;
        background: rgba(255, 149, 0, 0.02);
    }
    
    .status-badge {
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .badge-overdue {
        background: rgba(255, 59, 48, 0.1);
        color: #FF3B30;
    }
    
    .badge-due-soon {
        background: rgba(255, 149, 0, 0.1);
        color: #FF9500;
    }
    
    .badge-active {
        background: rgba(52, 199, 89, 0.1);
        color: #34C759;
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.7);
        z-index: 9999;
        overflow-y: auto;
    }
    
    .modal-content {
        max-width: 600px;
        margin: 30px auto;
        background: var(--bg-card);
        border-radius: 15px;
        padding: 30px;
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-exchange-alt"></i> Library Issues & Returns</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Manage book issues and returns
        </p>
    </div>
    
    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 25px;">
        <div style="background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $total_issued; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Currently Issued</p>
        </div>
        <div style="background: linear-gradient(135deg, #FF3B30, #FF453A); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $overdue; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Overdue</p>
        </div>
        <div style="background: linear-gradient(135deg, #FF9500, #FF9F0A); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo $due_soon; ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Due Soon (2 days)</p>
        </div>
    </div>
    
    <!-- Actions -->
    <div style="margin-bottom: 20px;">
        <button onclick="showIssueModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Issue Book
        </button>
        <a href="<?php echo APP_URL; ?>/admin/library-books.php" class="btn btn-secondary">
            <i class="fas fa-book"></i> View Books
        </a>
    </div>
    
    <!-- Current Issues -->
    <h3 style="margin-bottom: 15px;">Current Issues</h3>
    
    <?php if (count($current_issues) > 0): ?>
        <?php foreach ($current_issues as $issue): ?>
            <div class="issue-card <?php echo $issue['issue_status'] == 'overdue' ? 'overdue' : ($issue['issue_status'] == 'due_soon' ? 'due-soon' : ''); ?>">
                <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                            <h4 style="margin: 0;"><?php echo htmlspecialchars($issue['book_title']); ?></h4>
                            <?php if ($issue['issue_status'] == 'overdue'): ?>
                                <span class="status-badge badge-overdue">
                                    <i class="fas fa-exclamation-triangle"></i> Overdue (<?php echo $issue['days_overdue']; ?> days)
                                </span>
                            <?php elseif ($issue['issue_status'] == 'due_soon'): ?>
                                <span class="status-badge badge-due-soon">
                                    <i class="fas fa-clock"></i> Due Soon
                                </span>
                            <?php else: ?>
                                <span class="status-badge badge-active">
                                    <i class="fas fa-check"></i> Active
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <p style="margin: 0 0 8px 0; color: var(--text-secondary); font-size: 13px;">
                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($issue['author']); ?>
                            <?php if ($issue['isbn']): ?>
                                | <i class="fas fa-barcode"></i> <?php echo htmlspecialchars($issue['isbn']); ?>
                            <?php endif; ?>
                        </p>
                        
                        <div style="background: rgba(0,0,0,0.02); padding: 10px; border-radius: 8px; margin-bottom: 10px;">
                            <strong>Student:</strong> <?php echo htmlspecialchars($issue['first_name'] . ' ' . $issue['last_name']); ?> | 
                            <?php echo htmlspecialchars($issue['class_name']); ?>
                        </div>
                        
                        <div style="display: flex; gap: 20px; font-size: 13px;">
                            <div>
                                <strong>Issued:</strong> <?php echo date('M d, Y', strtotime($issue['issue_date'])); ?>
                            </div>
                            <div>
                                <strong>Due:</strong> 
                                <span style="color: <?php echo $issue['issue_status'] == 'overdue' ? '#FF3B30' : 'inherit'; ?>;">
                                    <?php echo date('M d, Y', strtotime($issue['due_date'])); ?>
                                </span>
                            </div>
                            <?php if ($issue['fine_amount'] > 0): ?>
                                <div>
                                    <strong>Fine:</strong> 
                                    <span style="color: #FF3B30;">
                                        $<?php echo number_format($issue['fine_amount'], 2); ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <button onclick="showReturnModal(<?php echo $issue['issue_id']; ?>, '<?php echo addslashes($issue['book_title']); ?>', '<?php echo addslashes($issue['first_name'] . ' ' . $issue['last_name']); ?>')" 
                            class="btn btn-success">
                        <i class="fas fa-undo"></i> Return
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div style="text-align: center; padding: 60px; background: var(--bg-card); border-radius: 15px;">
            <i class="fas fa-check-circle" style="font-size: 64px; color: #34C759; margin-bottom: 20px;"></i>
            <h3 style="color: var(--text-secondary);">No Books Currently Issued</h3>
            <p style="color: var(--text-secondary);">All books are in the library!</p>
        </div>
    <?php endif; ?>
    
    <!-- Issue Book Modal -->
    <div id="issueModal" class="modal">
        <div class="modal-content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="margin: 0;"><i class="fas fa-plus"></i> Issue Book</h2>
                <button onclick="closeModal('issueModal')" style="background: none; border: none; font-size: 24px; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="issue_book">
                
                <div class="form-group">
                    <label>Select Book *</label>
                    <select name="book_id" required style="width: 100%;">
                        <option value="">-- Select Book --</option>
                        <?php foreach ($available_books as $book): ?>
                            <option value="<?php echo $book['book_id']; ?>">
                                <?php echo htmlspecialchars($book['title']); ?> by <?php echo htmlspecialchars($book['author']); ?>
                                (<?php echo $book['available_copies']; ?> available)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Select Student *</label>
                    <select name="student_id" required style="width: 100%;">
                        <option value="">-- Select Student --</option>
                        <?php foreach ($students as $student): ?>
                            <option value="<?php echo $student['student_id']; ?>">
                                <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?> - 
                                <?php echo htmlspecialchars($student['class_name']); ?>
                                (Current: <?php echo $student['current_issues']; ?>/<?php echo $settings['max_books_per_student']; ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Issue Duration (days)</label>
                    <input type="number" name="issue_duration" value="<?php echo $settings['issue_duration_days']; ?>" min="1" max="90">
                </div>
                
                <div style="background: rgba(45, 91, 255, 0.1); padding: 12px; border-radius: 8px; margin: 15px 0;">
                    <p style="margin: 0; font-size: 13px;">
                        <i class="fas fa-info-circle"></i> 
                        <strong>Max books per student:</strong> <?php echo $settings['max_books_per_student']; ?> | 
                        <strong>Fine per day:</strong> $<?php echo number_format($settings['fine_per_day'], 2); ?>
                    </p>
                </div>
                
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('issueModal')">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check"></i> Issue Book
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Return Book Modal -->
    <div id="returnModal" class="modal">
        <div class="modal-content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="margin: 0;"><i class="fas fa-undo"></i> Return Book</h2>
                <button onclick="closeModal('returnModal')" style="background: none; border: none; font-size: 24px; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="return_book">
                <input type="hidden" name="issue_id" id="return_issue_id">
                
                <div style="background: rgba(0,0,0,0.02); padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <p style="margin: 0 0 5px 0;"><strong>Book:</strong> <span id="return_book_title"></span></p>
                    <p style="margin: 0;"><strong>Student:</strong> <span id="return_student_name"></span></p>
                </div>
                
                <div class="form-group">
                    <label>Book Condition on Return *</label>
                    <select name="book_condition" required>
                        <option value="excellent">Excellent</option>
                        <option value="good" selected>Good</option>
                        <option value="fair">Fair</option>
                        <option value="poor">Poor (Damaged)</option>
                    </select>
                </div>
                
                <div style="background: rgba(255, 149, 0, 0.1); padding: 12px; border-radius: 8px; margin: 15px 0;">
                    <p style="margin: 0; font-size: 13px;">
                        <i class="fas fa-info-circle"></i> 
                        Fine will be auto-calculated if book is overdue
                    </p>
                </div>
                
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('returnModal')">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check"></i> Return Book
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showIssueModal() {
        document.getElementById('issueModal').style.display = 'block';
    }
    
    function showReturnModal(issueId, bookTitle, studentName) {
        document.getElementById('return_issue_id').value = issueId;
        document.getElementById('return_book_title').textContent = bookTitle;
        document.getElementById('return_student_name').textContent = studentName;
        document.getElementById('returnModal').style.display = 'block';
    }
    
    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }
    
    window.onclick = function(event) {
        if (event.target.className === 'modal') {
            event.target.style.display = 'none';
        }
    }
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
