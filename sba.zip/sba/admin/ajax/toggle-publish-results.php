<?php
// admin/ajax/toggle-publish-results.php - Toggle Results Publishing to Parents
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/RateLimiter.php';

// Rate limiting: max 10 requests per minute
if (!RateLimiter::check('publish_results', 10, 60)) {
    RateLimiter::sendLimitExceeded();
}

// Check permission
$current_user = check_permission(['admin', 'super_admin']);

// Set JSON header
header('Content-Type: application/json');

// Get JSON input
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['term_id']) || !isset($data['publish'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid request data']);
    exit;
}

$term_id = (int)$data['term_id'];
$class_id = isset($data['class_id']) ? (int)$data['class_id'] : null;
$publish = (int)$data['publish'];
$school_id = $current_user['school_id'];

try {
    $db = Database::getInstance()->getConnection();
    
    // Verify term belongs to this school
    $stmt = $db->prepare("SELECT term_id FROM terms WHERE term_id = ? AND school_id = ?");
    $stmt->execute([$term_id, $school_id]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Term not found or access denied']);
        exit;
    }
    
    // Start transaction
    $db->beginTransaction();
    
    // Update student_assessments table (for parents)
    if ($class_id) {
        // Publish/unpublish for specific class only
        $published_at = $publish ? date('Y-m-d H:i:s') : null;
        $published_by_id = $publish ? $current_user['user_id'] : null;
        
        $stmt = $db->prepare("
            UPDATE student_assessments 
            SET published_to_parents = ?, 
                published_at = ?,
                published_by = ?
            WHERE term_id = ? AND school_id = ? AND class_id = ?
        ");
        $stmt->execute([$publish, $published_at, $published_by_id, $term_id, $school_id, $class_id]);
    } else {
        // Publish/unpublish for all classes in term
        $published_at = $publish ? date('Y-m-d H:i:s') : null;
        $published_by_id = $publish ? $current_user['user_id'] : null;
        
        $stmt = $db->prepare("
            UPDATE student_assessments 
            SET published_to_parents = ?, 
                published_at = ?,
                published_by = ?
            WHERE term_id = ? AND school_id = ?
        ");
        $stmt->execute([$publish, $published_at, $published_by_id, $term_id, $school_id]);
    }
    
    $affected = $stmt->rowCount();
    
    // Update terms table (for students) - only if publishing all classes
    if (!$class_id) {
        $stmt = $db->prepare("
            UPDATE terms 
            SET results_published = ?
            WHERE term_id = ? AND school_id = ?
        ");
        $stmt->execute([$publish, $term_id, $school_id]);
    }
    
    // Commit transaction
    $db->commit();
    
    // Log activity
    $action = $publish ? 'Published results to students and parents' : 'Unpublished results from students and parents';
    $action .= $class_id ? ' for class ID: ' . $class_id : ' for all classes';
    log_activity($current_user['user_id'], $action . ' (Term ID: ' . $term_id . ')', 'student_assessments', $term_id);
    
    echo json_encode([
        'success' => true,
        'message' => $publish ? 
            "Results published successfully to students and parents ($affected records)" : 
            "Results unpublished successfully ($affected records)",
        'affected' => $affected
    ]);
    
} catch (PDOException $e) {
    // Rollback on error
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    error_log("Toggle publish results error: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Database error occurred: ' . $e->getMessage()]);
}
