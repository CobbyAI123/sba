<?php
// admin/ajax/get-dashboard-stats.php - Auto-refresh dashboard statistics
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/config.php';

// Prevent any output before JSON
ob_start();

// Set JSON header
header('Content-Type: application/json');

try {
    $current_user = check_permission(['admin']);
    $db = Database::getInstance()->getConnection();
    $school_id = $current_user['school_id'];
    
    $stats = [];

// Total Revenue (All Time) - Student Fees
$student_revenue = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE student_id IN (SELECT student_id FROM students WHERE school_id = ?) AND status IN ('paid', 'completed')
    ");
    $stmt->execute([$school_id]);
    $student_revenue = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $student_revenue = 0;
}

// Staff Payments Revenue (Canteen + Transport)
$staff_revenue = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM staff_payments 
        WHERE school_id = ? AND status = 'paid'
    ");
    $stmt->execute([$school_id]);
    $staff_revenue = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $staff_revenue = 0;
}

// Combined Total Revenue
$stats['total_revenue'] = $student_revenue + $staff_revenue;
$stats['total_revenue_formatted'] = format_currency($stats['total_revenue']);

// This Month Income
$month_student_income = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE student_id IN (SELECT student_id FROM students WHERE school_id = ?) 
        AND status IN ('paid', 'completed')
        AND MONTH(payment_date) = MONTH(CURRENT_DATE()) 
        AND YEAR(payment_date) = YEAR(CURRENT_DATE())
    ");
    $stmt->execute([$school_id]);
    $month_student_income = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $month_student_income = 0;
}

$month_staff_income = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM staff_payments 
        WHERE school_id = ? AND status = 'paid'
        AND MONTH(payment_date) = MONTH(CURRENT_DATE()) 
        AND YEAR(payment_date) = YEAR(CURRENT_DATE())
    ");
    $stmt->execute([$school_id]);
    $month_staff_income = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $month_staff_income = 0;
}

$stats['month_income'] = $month_student_income + $month_staff_income;
$stats['month_income_formatted'] = format_currency($stats['month_income']);

// Pending Revenue
$stats['pending_revenue'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE student_id IN (SELECT student_id FROM students WHERE school_id = ?) AND status = 'pending'
    ");
    $stmt->execute([$school_id]);
    $stats['pending_revenue'] = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $stats['pending_revenue'] = 0;
}
$stats['pending_revenue_formatted'] = format_currency($stats['pending_revenue']);

// Overdue Payments
$stats['overdue'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE student_id IN (SELECT student_id FROM students WHERE school_id = ?) 
        AND status = 'pending' 
        AND payment_date < CURDATE()
    ");
    $stmt->execute([$school_id]);
    $stats['overdue'] = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $stats['overdue'] = 0;
}
$stats['overdue_formatted'] = format_currency($stats['overdue']);

// Collection Rate
$total_expected = $stats['total_revenue'] + $stats['pending_revenue'];
$stats['collection_rate'] = $total_expected > 0 ? round(($stats['total_revenue'] / $total_expected) * 100, 1) : 0;

// This Month Expenditure
$stats['month_expenditure'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM expenses 
        WHERE school_id = ? 
        AND MONTH(expense_date) = MONTH(CURRENT_DATE()) 
        AND YEAR(expense_date) = YEAR(CURRENT_DATE())
    ");
    $stmt->execute([$school_id]);
    $stats['month_expenditure'] = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $stats['month_expenditure'] = 0;
}
$stats['month_expenditure_formatted'] = format_currency($stats['month_expenditure']);

// Canteen Revenue
$stats['canteen_revenue'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM staff_payments 
        WHERE school_id = ? AND status = 'paid' AND payment_type = 'canteen'
    ");
    $stmt->execute([$school_id]);
    $stats['canteen_revenue'] = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $stats['canteen_revenue'] = 0;
}
$stats['canteen_revenue_formatted'] = format_currency($stats['canteen_revenue']);

// Bus Fee Revenue
$stats['bus_revenue'] = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM staff_payments 
        WHERE school_id = ? AND status = 'paid' AND payment_type = 'transport'
    ");
    $stmt->execute([$school_id]);
    $stats['bus_revenue'] = $stmt->fetch()['total'];
} catch (PDOException $e) {
    $stats['bus_revenue'] = 0;
}
$stats['bus_revenue_formatted'] = format_currency($stats['bus_revenue']);

    $stats['success'] = true;
    $stats['timestamp'] = date('Y-m-d H:i:s');
    
    // Clear any buffered output
    ob_clean();
    
    // Output JSON
    echo json_encode($stats);
    
} catch (Exception $e) {
    // Clear any buffered output
    ob_clean();
    
    // Return error as JSON
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ]);
}
?>
```
</invoke>