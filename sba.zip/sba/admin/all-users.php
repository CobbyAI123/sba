<?php
// admin/all-users.php - View all users in grid or list format
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'All Users';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle POST actions (update, delete, status change)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'update') {
        try {
            $user_id = (int)$_POST['user_id'];
            $first_name = trim($_POST['first_name']);
            $last_name = trim($_POST['last_name']);
            $email = trim($_POST['email']);
            $username = trim($_POST['username']);
            $role = $_POST['role'];
            $status = $_POST['status'];
            
            // Verify user belongs to this school
            $stmt = $db->prepare("SELECT user_id FROM users WHERE user_id = ? AND school_id = ? AND role != 'super_admin'");
            $stmt->execute([$user_id, $school_id]);
            if (!$stmt->fetch()) {
                throw new Exception('User not found or cannot be modified');
            }
            
            // Update user
            $stmt = $db->prepare("
                UPDATE users 
                SET first_name = ?, last_name = ?, email = ?, username = ?, role = ?, status = ?
                WHERE user_id = ? AND school_id = ?
            ");
            $stmt->execute([$first_name, $last_name, $email, $username, $role, $status, $user_id, $school_id]);
            
            set_message('success', 'User updated successfully!');
            redirect(APP_URL . '/admin/all-users.php?view=' . ($_POST['view_mode'] ?? 'grid'));
        } catch (Exception $e) {
            set_message('error', 'Error: ' . $e->getMessage());
        }
    } elseif ($action == 'delete') {
        try {
            $user_id = (int)$_POST['user_id'];
            
            // Verify user belongs to this school and is not super_admin or admin
            $stmt = $db->prepare("SELECT user_id, role FROM users WHERE user_id = ? AND school_id = ? AND role NOT IN ('super_admin', 'admin')");
            $stmt->execute([$user_id, $school_id]);
            $user_to_delete = $stmt->fetch();
            
            if (!$user_to_delete) {
                throw new Exception('User not found or cannot be deleted. Admin accounts can only be deleted when the school is deleted by Super Admin.');
            }
            
            // Delete related records first
            if ($user_to_delete['role'] == 'student') {
                $db->prepare("DELETE FROM students WHERE user_id = ?")->execute([$user_id]);
                $db->prepare("DELETE FROM student_assessments WHERE student_id IN (SELECT student_id FROM students WHERE user_id = ?)");
            }
            
            // Delete the user
            $stmt = $db->prepare("DELETE FROM users WHERE user_id = ? AND school_id = ?");
            $stmt->execute([$user_id, $school_id]);
            
            set_message('success', 'User deleted successfully!');
            redirect(APP_URL . '/admin/all-users.php?view=' . ($_POST['view_mode'] ?? 'grid'));
        } catch (Exception $e) {
            set_message('error', 'Error: ' . $e->getMessage());
        }
    } elseif ($action == 'toggle_status') {
        try {
            $user_id = (int)$_POST['user_id'];
            $new_status = $_POST['new_status'];
            
            // Verify user belongs to this school
            $stmt = $db->prepare("SELECT user_id FROM users WHERE user_id = ? AND school_id = ? AND role != 'super_admin'");
            $stmt->execute([$user_id, $school_id]);
            if (!$stmt->fetch()) {
                throw new Exception('User not found');
            }
            
            // Update status
            $stmt = $db->prepare("UPDATE users SET status = ? WHERE user_id = ? AND school_id = ?");
            $stmt->execute([$new_status, $user_id, $school_id]);
            
            set_message('success', 'User status updated!');
            redirect(APP_URL . '/admin/all-users.php?view=' . ($_POST['view_mode'] ?? 'grid'));
        } catch (Exception $e) {
            set_message('error', 'Error: ' . $e->getMessage());
        }
    }
}

// Get view mode from query parameter
$view_mode = $_GET['view'] ?? 'grid';
$role_filter = $_GET['role'] ?? '';

// Get all users in school (excluding super admin)
$query = "
    SELECT u.*, 
           COUNT(CASE WHEN u.role = 'teacher' THEN 1 END) as teacher_count,
           COUNT(CASE WHEN u.role = 'student' THEN 1 END) as student_count,
           COUNT(CASE WHEN u.role = 'parent' THEN 1 END) as parent_count,
           COUNT(CASE WHEN u.role = 'librarian' THEN 1 END) as librarian_count,
           COUNT(CASE WHEN u.role = 'accountant' THEN 1 END) as accountant_count,
           COUNT(CASE WHEN u.role = 'proprietor' THEN 1 END) as proprietor_count
    FROM users u
    WHERE u.school_id = ? AND u.role != 'super_admin'
";

$params = [$school_id];

if ($role_filter) {
    $query .= " AND u.role = ?";
    $params[] = $role_filter;
}

$query .= " GROUP BY u.user_id ORDER BY u.role ASC, u.first_name ASC";

$stmt = $db->prepare($query);
$stmt->execute($params);
$users = $stmt->fetchAll();

// Get role counts
$stmt = $db->prepare("
    SELECT role, COUNT(*) as count 
    FROM users 
    WHERE school_id = ? AND role != 'super_admin'
    GROUP BY role
    ORDER BY role ASC
");
$stmt->execute([$school_id]);
$role_counts = [];
foreach ($stmt->fetchAll() as $row) {
    $role_counts[$row['role']] = $row['count'];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Statistics -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo count($users); ?></h3>
                <p>Total Users</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-chalkboard-teacher"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $role_counts['teacher'] ?? 0; ?></h3>
                <p>Teachers</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-user-graduate"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $role_counts['student'] ?? 0; ?></h3>
                <p>Students</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon orange">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $role_counts['parent'] ?? 0; ?></h3>
                <p>Parents</p>
            </div>
        </div>
    </div>
    
    <!-- Filters and View Mode -->
    <div class="card" style="margin-bottom: 30px;">
        <div style="padding: 20px; display: flex; gap: 20px; justify-content: space-between; align-items: center; flex-wrap: wrap;">
            <!-- Role Filter -->
            <div style="display: flex; gap: 10px; align-items: center;">
                <label style="font-weight: 600;">Filter by Role:</label>
                <select onchange="window.location.href='?view=' + '<?php echo $view_mode; ?>' + (this.value ? '&role=' + this.value : '')" 
                        style="padding: 8px 15px; border: 1px solid var(--border-color); border-radius: 6px; cursor: pointer;">
                    <option value="">All Roles</option>
                    <option value="teacher" <?php echo $role_filter == 'teacher' ? 'selected' : ''; ?>>Teachers</option>
                    <option value="student" <?php echo $role_filter == 'student' ? 'selected' : ''; ?>>Students</option>
                    <option value="parent" <?php echo $role_filter == 'parent' ? 'selected' : ''; ?>>Parents</option>
                    <option value="librarian" <?php echo $role_filter == 'librarian' ? 'selected' : ''; ?>>Librarians</option>
                    <option value="accountant" <?php echo $role_filter == 'accountant' ? 'selected' : ''; ?>>Accountants</option>
                    <option value="proprietor" <?php echo $role_filter == 'proprietor' ? 'selected' : ''; ?>>Proprietors</option>
                </select>
            </div>
            
            <div style="display: flex; gap: 10px; align-items: center;">
                <!-- Show/Hide Passwords -->
                <button type="button" class="btn btn-sm btn-warning" onclick="togglePasswords()" id="togglePasswordsBtn">
                    <i class="fas fa-eye" id="togglePasswordIcon"></i> <span id="togglePasswordText">Show Passwords</span>
                </button>
                
                <!-- View Mode Toggle -->
                <div style="display: flex; gap: 5px;">
                    <a href="?view=grid<?php echo $role_filter ? '&role=' . $role_filter : ''; ?>" 
                       class="btn btn-sm <?php echo $view_mode == 'grid' ? 'btn-primary' : 'btn-secondary'; ?>" style="text-decoration: none;">
                        <i class="fas fa-th"></i> Grid
                    </a>
                    <a href="?view=list<?php echo $role_filter ? '&role=' . $role_filter : ''; ?>" 
                       class="btn btn-sm <?php echo $view_mode == 'list' ? 'btn-primary' : 'btn-secondary'; ?>" style="text-decoration: none;">
                        <i class="fas fa-list"></i> List
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <?php if ($view_mode == 'grid'): ?>
        <!-- Grid View -->
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px;">
            <?php if (count($users) > 0): ?>
                <?php foreach ($users as $user): ?>
                    <div class="card" style="overflow: hidden; transition: transform 0.3s, box-shadow 0.3s;">
                        <div style="padding: 20px; text-align: center; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); color: white;">
                            <div style="width: 80px; height: 80px; margin: 0 auto 15px; border-radius: 50%; background: rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; font-size: 30px;">
                                <?php echo strtoupper(substr($user['first_name'] ?? '', 0, 1) . substr($user['last_name'] ?? '', 0, 1)); ?>
                            </div>
                            <h3 style="margin: 0 0 5px 0; color: white;"><?php echo htmlspecialchars(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')); ?></h3>
                            <p style="margin: 5px 0; font-size: 13px; opacity: 0.9;"><?php echo ucfirst($user['role']); ?></p>
                        </div>
                        <div style="padding: 20px;">
                            <div style="margin-bottom: 15px;">
                                <p style="margin: 5px 0; color: var(--text-secondary); font-size: 13px;">
                                    <i class="fas fa-envelope"></i> <strong>Email</strong>
                                </p>
                                <p style="margin: 5px 0;"><?php echo $user['email']; ?></p>
                            </div>
                            <div style="margin-bottom: 15px;">
                                <p style="margin: 5px 0; color: var(--text-secondary); font-size: 13px;">
                                    <i class="fas fa-user-tag"></i> <strong>Username</strong>
                                </p>
                                <p style="margin: 5px 0;"><?php echo $user['username']; ?></p>
                            </div>
                            <div style="margin-bottom: 15px;" class="password-field">
                                <p style="margin: 5px 0; color: var(--text-secondary); font-size: 13px;">
                                    <i class="fas fa-key"></i> <strong>Password</strong>
                                </p>
                                <p style="margin: 5px 0; font-family: monospace;">
                                    <span class="password-hidden">••••••••</span>
                                    <span class="password-visible" style="display: none;"><?php echo htmlspecialchars($user['password'] ?? 'Not set'); ?></span>
                                </p>
                            </div>
                            <div style="margin-bottom: 15px;">
                                <span class="badge badge-<?php echo $user['status'] == 'active' ? 'success' : 'danger'; ?>">
                                    <?php echo ucfirst($user['status']); ?>
                                </span>
                            </div>
                            <div style="display: flex; gap: 5px; justify-content: center;">
                                <button type="button" class="btn btn-sm btn-primary" onclick="editUser(<?php echo htmlspecialchars(json_encode($user)); ?>)" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-<?php echo $user['status'] == 'active' ? 'warning' : 'success'; ?>" onclick="toggleStatus(<?php echo $user['user_id']; ?>, '<?php echo $user['status'] == 'active' ? 'inactive' : 'active'; ?>')" title="<?php echo $user['status'] == 'active' ? 'Deactivate' : 'Activate'; ?>">
                                    <i class="fas fa-<?php echo $user['status'] == 'active' ? 'ban' : 'check'; ?>"></i>
                                </button>
                                <button type="button" class="btn btn-sm btn-danger" onclick="deleteUser(<?php echo $user['user_id']; ?>, '<?php echo htmlspecialchars(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')); ?>')" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; color: var(--text-secondary);">
                    <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 20px; display: block;"></i>
                    <h3>No Users Found</h3>
                    <p><?php echo $role_filter ? 'No users found for the selected role.' : 'No users available.'; ?></p>
                </div>
            <?php endif; ?>
        </div>
    
    <?php else: ?>
        <!-- List View -->
        <div class="card">
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th class="password-field">Password</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($users) > 0): ?>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 10px;">
                                            <div style="width: 35px; height: 35px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600;">
                                                <?php echo strtoupper(substr($user['first_name'] ?? '', 0, 1) . substr($user['last_name'] ?? '', 0, 1)); ?>
                                            </div>
                                            <strong><?php echo htmlspecialchars(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')); ?></strong>
                                        </div>
                                    </td>
                                    <td><?php echo $user['username']; ?></td>
                                    <td><?php echo $user['email']; ?></td>
                                    <td class="password-field" style="font-family: monospace;">
                                        <span class="password-hidden">••••••••</span>
                                        <span class="password-visible" style="display: none;"><?php echo htmlspecialchars($user['password'] ?? 'Not set'); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge badge-info"><?php echo ucfirst($user['role']); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo $user['status'] == 'active' ? 'success' : 'danger'; ?>">
                                            <?php echo ucfirst($user['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-primary" onclick="editUser(<?php echo htmlspecialchars(json_encode($user)); ?>)" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-<?php echo $user['status'] == 'active' ? 'warning' : 'success'; ?>" onclick="toggleStatus(<?php echo $user['user_id']; ?>, '<?php echo $user['status'] == 'active' ? 'inactive' : 'active'; ?>')" title="<?php echo $user['status'] == 'active' ? 'Deactivate' : 'Activate'; ?>">
                                            <i class="fas fa-<?php echo $user['status'] == 'active' ? 'ban' : 'check'; ?>"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="deleteUser(<?php echo $user['user_id']; ?>, '<?php echo htmlspecialchars(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '')); ?>')" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" style="text-align: center; padding: 40px;">
                                    <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 10px; display: block; color: var(--text-secondary);"></i>
                                    <h3>No Users Found</h3>
                                    <p style="color: var(--text-secondary);"><?php echo $role_filter ? 'No users found for the selected role.' : 'No users available.'; ?></p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Edit User Modal -->
    <div id="editModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Edit User</h2>
                <button onclick="closeEditModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="user_id" id="edit_user_id">
                <input type="hidden" name="view_mode" value="<?php echo $view_mode; ?>">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>First Name *</label>
                        <input type="text" name="first_name" id="edit_first_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Last Name *</label>
                        <input type="text" name="last_name" id="edit_last_name" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Email *</label>
                    <input type="email" name="email" id="edit_email" required>
                </div>
                
                <div class="form-group">
                    <label>Username *</label>
                    <input type="text" name="username" id="edit_username" required>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Role *</label>
                        <select name="role" id="edit_role" required>
                            <option value="admin">Admin</option>
                            <option value="teacher">Teacher</option>
                            <option value="student">Student</option>
                            <option value="parent">Parent</option>
                            <option value="accountant">Accountant</option>
                            <option value="librarian">Librarian</option>
                            <option value="proprietor">Proprietor</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Status *</label>
                        <select name="status" id="edit_status" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update User</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
        <div style="max-width: 400px; margin: 150px auto; background: var(--bg-card); border-radius: 15px; padding: 30px; text-align: center;">
            <i class="fas fa-exclamation-triangle" style="font-size: 48px; color: var(--danger-red); margin-bottom: 15px; display: block;"></i>
            <h2>Delete User?</h2>
            <p style="color: var(--text-secondary); margin: 15px 0;" id="deleteUserName"></p>
            <p style="color: var(--danger-red); font-weight: 600;">This action cannot be undone!</p>
            <form method="POST" style="display: inline;">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="user_id" id="delete_user_id">
                <input type="hidden" name="view_mode" value="<?php echo $view_mode; ?>">
                <div style="display: flex; gap: 10px; justify-content: center; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Toggle Status Form -->
    <form method="POST" id="toggleStatusForm" style="display: none;">
        <input type="hidden" name="action" value="toggle_status">
        <input type="hidden" name="user_id" id="toggle_user_id">
        <input type="hidden" name="new_status" id="toggle_new_status">
        <input type="hidden" name="view_mode" value="<?php echo $view_mode; ?>">
    </form>
    
    <script>
    function editUser(user) {
        document.getElementById('edit_user_id').value = user.user_id;
        document.getElementById('edit_first_name').value = user.first_name || '';
        document.getElementById('edit_last_name').value = user.last_name || '';
        document.getElementById('edit_email').value = user.email || '';
        document.getElementById('edit_username').value = user.username || '';
        document.getElementById('edit_role').value = user.role || '';
        document.getElementById('edit_status').value = user.status || 'active';
        document.getElementById('editModal').style.display = 'block';
    }
    
    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
    }
    
    function deleteUser(userId, userName) {
        document.getElementById('delete_user_id').value = userId;
        document.getElementById('deleteUserName').textContent = 'Are you sure you want to delete ' + userName + '?';
        document.getElementById('deleteModal').style.display = 'block';
    }
    
    function closeDeleteModal() {
        document.getElementById('deleteModal').style.display = 'none';
    }
    
    function toggleStatus(userId, newStatus) {
        if (confirm('Are you sure you want to ' + (newStatus == 'active' ? 'activate' : 'deactivate') + ' this user?')) {
            document.getElementById('toggle_user_id').value = userId;
            document.getElementById('toggle_new_status').value = newStatus;
            document.getElementById('toggleStatusForm').submit();
        }
    }
    
    window.onclick = function(event) {
        if (event.target.id === 'editModal') closeEditModal();
        if (event.target.id === 'deleteModal') closeDeleteModal();
    }
    
    // Password visibility toggle
    let passwordsVisible = false;
    
    function togglePasswords() {
        passwordsVisible = !passwordsVisible;
        
        const hiddenElements = document.querySelectorAll('.password-hidden');
        const visibleElements = document.querySelectorAll('.password-visible');
        const icon = document.getElementById('togglePasswordIcon');
        const text = document.getElementById('togglePasswordText');
        
        if (passwordsVisible) {
            // Show passwords
            hiddenElements.forEach(el => el.style.display = 'none');
            visibleElements.forEach(el => el.style.display = 'inline');
            icon.className = 'fas fa-eye-slash';
            text.textContent = 'Hide Passwords';
            
            // Save preference
            localStorage.setItem('showUserPasswords', 'true');
        } else {
            // Hide passwords
            hiddenElements.forEach(el => el.style.display = 'inline');
            visibleElements.forEach(el => el.style.display = 'none');
            icon.className = 'fas fa-eye';
            text.textContent = 'Show Passwords';
            
            // Save preference
            localStorage.setItem('showUserPasswords', 'false');
        }
    }
    
    // Load saved preference on page load
    window.addEventListener('DOMContentLoaded', function() {
        const savedPreference = localStorage.getItem('showUserPasswords');
        if (savedPreference === 'true') {
            togglePasswords();
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
