<?php
// admin/transcripts.php - Transcript Generation
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Transcript Generation';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get all classes
$stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get students for selected class
$students = [];
if (isset($_GET['class_id'])) {
    $class_id = (int)$_GET['class_id'];
    try {
        $stmt = $db->prepare("
            SELECT s.*, COALESCE(u.first_name, '-') as first_name, COALESCE(u.last_name, '') as last_name
            FROM students s
            LEFT JOIN users u ON s.user_id = u.user_id
            WHERE s.school_id = ? AND s.class_id = ? 
            ORDER BY s.admission_number
        ");
        $stmt->execute([$school_id, $class_id]);
        $students = $stmt->fetchAll();
    } catch (PDOException $e) {
        $students = [];
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fas fa-file-alt"></i>  Transcript Generation</h1>
    </div>

    <div class="page-header">
        
    </div>
    
    <div class="alert alert-info" style="margin-bottom: 30px;">
        <i class="fas fa-info-circle"></i>
        <strong>About Transcripts:</strong> Transcripts show a cumulative record of student performance across all terms and classes. They include only Total Score and Grade for each subject (no CA, Midterm, or Position).
    </div>
    
    <!-- Single Student Transcript -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header" style="background: linear-gradient(135deg, #2196F3, #03A9F4); color: white;">
            <h3 style="color: white; margin: 0;">
                <i class="fas fa-user"></i> Generate Single Student Transcript
            </h3>
        </div>
        <div style="padding: 30px;">
            <form method="GET" id="singleForm">
                <div class="form-row">
                    <div class="form-group">
                        <label>Select Class *</label>
                        <select name="class_id" id="class_id_single" class="form-control" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>" 
                                        <?php echo (isset($_GET['class_id']) && $_GET['class_id'] == $class['class_id']) ? 'selected' : ''; ?>>
                                    <?php echo $class['class_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Select Student *</label>
                        <select name="student_id" id="student_id_single" class="form-control" required>
                            <option value="">-- Select Student --</option>
                            <?php foreach ($students as $student): ?>
                                <option value="<?php echo $student['student_id']; ?>">
                                    <?php echo $student['admission_number'] . ' - ' . $student['first_name'] . ' ' . $student['last_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px;">
                    <button type="submit" name="action" value="view" class="btn btn-info">
                        <i class="fas fa-eye"></i> Preview
                    </button>
                    <button type="submit" name="action" value="generate" class="btn btn-primary" onclick="this.form.target='_blank'">
                        <i class="fas fa-file-pdf"></i> Generate PDF
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <?php
    // Handle single student report preview/generation
    if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['student_id']) && isset($_GET['action']) && isset($_GET['class_id'])) {
        $student_id = (int)$_GET['student_id'];
        $action = $_GET['action'];
        $class_id = (int)$_GET['class_id'];
        
        // Get student details
        $stmt = $db->prepare("
            SELECT s.*, c.class_name, COALESCE(u.first_name, '-') as first_name, COALESCE(u.last_name, '') as last_name
            FROM students s
            LEFT JOIN classes c ON s.class_id = c.class_id
            LEFT JOIN users u ON s.user_id = u.user_id
            WHERE s.student_id = ? AND s.school_id = ? AND s.class_id = ?
        ");
        $stmt->execute([$student_id, $school_id, $class_id]);
        $student = $stmt->fetch();
        
        if ($student && $action == 'view') {
            echo "\n<!-- Student Report Preview -->\n";
            echo "<div class='card' style='margin-bottom: 30px; background: #f9f9f9;'>\n";
            echo "    <div class='card-header' style='background: linear-gradient(135deg, #4CAF50, #45a049); color: white;'>\n";
            echo "        <h3 style='color: white; margin: 0;'>\n";
            echo "            <i class='fas fa-file-alt'></i> Report Preview - " . htmlspecialchars($student['first_name'] . ' ' . $student['last_name']) . "\n";
            echo "        </h3>\n";
            echo "    </div>\n";
            echo "    <div style='padding: 30px;'>\n";
            
            // Get student transcript
            try {
                $stmt = $db->prepare("
                    SELECT 
                        c.class_name,
                        t.term_name,
                        s.subject_name,
                        sa.total_score,
                        sa.grade,
                        sa.remark
                    FROM student_assessments sa
                    JOIN classes c ON sa.class_id = c.class_id
                    JOIN terms t ON sa.term_id = t.term_id
                    JOIN subjects s ON sa.subject_id = s.subject_id
                    WHERE sa.student_id = ? AND sa.school_id = ?
                    ORDER BY c.class_name, t.start_date, s.subject_name
                ");
                $stmt->execute([$student_id, $school_id]);
                $transcript = $stmt->fetchAll();
                
                if (count($transcript) > 0) {
                    echo "        <div style='margin-bottom: 20px;'>\n";
                    echo "            <strong>Student:</strong> " . htmlspecialchars($student['admission_number'] . ' - ' . $student['first_name'] . ' ' . $student['last_name']) . "<br/>\n";
                    echo "            <strong>Class:</strong> " . htmlspecialchars($student['class_name']) . "<br/>\n";
                    echo "        </div>\n";
                    
                    echo "        <table style='width: 100%; border-collapse: collapse; margin-top: 20px;'>\n";
                    echo "            <thead>\n";
                    echo "                <tr style='background: #f0f0f0;'>\n";
                    echo "                    <th style='padding: 10px; text-align: left; border: 1px solid #ddd;'>Class</th>\n";
                    echo "                    <th style='padding: 10px; text-align: left; border: 1px solid #ddd;'>Term</th>\n";
                    echo "                    <th style='padding: 10px; text-align: left; border: 1px solid #ddd;'>Subject</th>\n";
                    echo "                    <th style='padding: 10px; text-align: center; border: 1px solid #ddd;'>Score</th>\n";
                    echo "                    <th style='padding: 10px; text-align: center; border: 1px solid #ddd;'>Grade</th>\n";
                    echo "                    <th style='padding: 10px; text-align: left; border: 1px solid #ddd;'>Remark</th>\n";
                    echo "                </tr>\n";
                    echo "            </thead>\n";
                    echo "            <tbody>\n";
                    
                    foreach ($transcript as $row) {
                        echo "                <tr>\n";
                        echo "                    <td style='padding: 10px; border: 1px solid #ddd;'>" . htmlspecialchars($row['class_name']) . "</td>\n";
                        echo "                    <td style='padding: 10px; border: 1px solid #ddd;'>" . htmlspecialchars($row['term_name']) . "</td>\n";
                        echo "                    <td style='padding: 10px; border: 1px solid #ddd;'>" . htmlspecialchars($row['subject_name']) . "</td>\n";
                        echo "                    <td style='padding: 10px; border: 1px solid #ddd; text-align: center;'>" . ($row['total_score'] ?? '-') . "</td>\n";
                        echo "                    <td style='padding: 10px; border: 1px solid #ddd; text-align: center; font-weight: bold;'>" . htmlspecialchars($row['grade'] ?? '-') . "</td>\n";
                        echo "                    <td style='padding: 10px; border: 1px solid #ddd;'>" . htmlspecialchars($row['remark'] ?? '-') . "</td>\n";
                        echo "                </tr>\n";
                    }
                    
                    echo "            </tbody>\n";
                    echo "        </table>\n";
                    
                    echo "        <div style='margin-top: 20px; text-align: right;'>\n";
                    echo "            <button onclick=\"document.getElementById('singleForm').action='generate-transcript.php'; document.getElementById('singleForm').target='_blank'; document.getElementById('singleForm').submit(); return false;\" class='btn btn-primary'>\n";
                    echo "                <i class='fas fa-file-pdf'></i> Generate PDF from Preview\n";
                    echo "            </button>\n";
                    echo "        </div>\n";
                } else {
                    echo "        <div class='alert alert-warning'>\n";
                    echo "            <i class='fas fa-exclamation-triangle'></i>\n";
                    echo "            <strong>No Assessment Data:</strong> This student has no assessment records yet.\n";
                    echo "        </div>\n";
                }
            } catch (PDOException $e) {
                echo "        <div class='alert alert-danger'>\n";
                echo "            <i class='fas fa-exclamation-circle'></i>\n";
                echo "            <strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "\n";
                echo "        </div>\n";
            }
            
            echo "    </div>\n";
            echo "</div>\n";
        }
    }
    ?>
    
    
    <!-- Class Transcripts -->
    <div class="card">
        <div class="card-header" style="background: linear-gradient(135deg, #9C27B0, #E91E63); color: white;">
            <h3 style="color: white; margin: 0;">
                <i class="fas fa-users"></i> Generate All Transcripts for Class
            </h3>
        </div>
        <div style="padding: 30px;">
            <form method="GET" action="generate-all-transcripts.php" target="_blank">
                <div class="form-group">
                    <label>Select Class *</label>
                    <select name="class_id" class="form-control" required>
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>">
                                <?php echo $class['class_name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Note:</strong> This will generate transcripts for all students in the selected class. This may take some time depending on the number of students.
                </div>
                
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-file-pdf"></i> Generate All Transcripts
                </button>
            </form>
        </div>
    </div>
    
    <style>
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: var(--text-primary);
    }
    
    .form-control {
        width: 100%;
        padding: 10px 15px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
    }
    
    .form-control:focus {
        outline: none;
        border-color: var(--primary-blue);
        box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
    }
    
    @media (max-width: 768px) {
        .form-row {
            grid-template-columns: 1fr;
        }
    }
    </style>
    
    <script>
    // Load students when class is selected
    document.getElementById('class_id_single').addEventListener('change', function() {
        const classId = this.value;
        if (classId) {
            // Reset student select
            document.getElementById('student_id_single').value = '';
            // Reload page with selected class
            window.location.href = '?class_id=' + classId;
        }
    });
    
    // Handle form submission
    document.getElementById('singleForm').addEventListener('submit', function(e) {
        const action = e.submitter?.value;
        const studentId = document.getElementById('student_id_single').value;
        const classId = document.getElementById('class_id_single').value;
        
        if (!studentId || !classId) {
            e.preventDefault();
            alert('Please select both class and student');
            return false;
        }
        
        if (action === 'generate') {
            // Generate PDF in new window
            this.action = 'generate-transcript.php';
            this.target = '_blank';
        } else if (action === 'view') {
            // Preview on same page
            this.action = '';
            this.target = '';
        }
    });
    </script>
    
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
