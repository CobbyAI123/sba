<?php
// admin/librarians.php - Librarian Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/default-passwords.php';

$page_title = 'Manage Librarians';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $email = sanitize_input($_POST['email']);
            $phone = sanitize_input($_POST['phone']);
            
            try {
                // Auto-generate username from email
                $base_username = strtolower(explode('@', $email)[0]);
                $username = $base_username;
                $counter = 1;
                
                // Ensure unique username within school
                while (true) {
                    $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE username = ? AND school_id = ?");
                    $check_stmt->execute([$username, $school_id]);
                    if ($check_stmt->fetch()['count'] == 0) {
                        break;
                    }
                    $username = $base_username . '_' . $counter;
                    $counter++;
                }
                
                // Ensure unique email within school
                $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE email = ? AND school_id = ?");
                $check_stmt->execute([$email, $school_id]);
                if ($check_stmt->fetch()['count'] > 0) {
                    throw new Exception('Email already exists!');
                }
                
                // Auto-generate password: librarian123
                $default_credentials = generate_default_credentials('librarian');
                $default_password = $default_credentials['password'];
                $password = $default_credentials['hash'];
                
                $stmt = $db->prepare("
                    INSERT INTO users (school_id, username, email, password_hash, first_name, last_name, phone, role, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'librarian', 'active')
                ");
                $stmt->execute([$school_id, $username, $email, $password, $first_name, $last_name, $phone]);
                
                $user_id = $db->lastInsertId();
                log_activity($current_user['user_id'], "Added librarian: $first_name $last_name", 'users', $user_id);
                
                set_message('success', "Librarian added successfully! Login - Username: $username, Password: $default_password");
                redirect(APP_URL . '/admin/librarians.php');
            } catch (Exception $e) {
                set_message('error', 'Error adding librarian: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'edit') {
            $user_id = sanitize_input($_POST['user_id']);
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $email = sanitize_input($_POST['email']);
            $username = sanitize_input($_POST['username']);
            $phone = sanitize_input($_POST['phone']);
            $status = sanitize_input($_POST['status']);
            
            try {
                $stmt = $db->prepare("
                    UPDATE users 
                    SET first_name = ?, last_name = ?, email = ?, username = ?, phone = ?, status = ?
                    WHERE user_id = ? AND school_id = ? AND role = 'librarian'
                ");
                $stmt->execute([$first_name, $last_name, $email, $username, $phone, $status, $user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Updated librarian ID: $user_id", 'users', $user_id);
                
                set_message('success', 'Librarian updated successfully!');
                redirect(APP_URL . '/admin/librarians.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating librarian: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            $user_id = sanitize_input($_POST['user_id']);
            
            try {
                $stmt = $db->prepare("DELETE FROM users WHERE user_id = ? AND school_id = ? AND role = 'librarian'");
                $stmt->execute([$user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted librarian ID: $user_id", 'users', $user_id);
                
                set_message('success', 'Librarian deleted successfully!');
                redirect(APP_URL . '/admin/librarians.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting librarian: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'reset_password') {
            $user_id = sanitize_input($_POST['user_id']);
            $default_credentials = generate_default_credentials('librarian');
            $default_password = $default_credentials['password'];
            $new_password = $default_credentials['hash'];
            
            try {
                $stmt = $db->prepare("UPDATE users SET password_hash = ? WHERE user_id = ? AND school_id = ? AND role = 'librarian'");
                $stmt->execute([$new_password, $user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Reset password for librarian ID: $user_id", 'users', $user_id);
                
                set_message('success', "Password reset to: $default_password");
                redirect(APP_URL . '/admin/librarians.php');
            } catch (PDOException $e) {
                set_message('error', 'Error resetting password: ' . $e->getMessage());
            }
        }
    }
}

// Get all librarians
$stmt = $db->prepare("
    SELECT * FROM users 
    WHERE school_id = ? AND role = 'librarian'
    ORDER BY first_name, last_name
");
$stmt->execute([$school_id]);
$librarians = $stmt->fetchAll();

$total = count($librarians);
$active = count(array_filter($librarians, function($l) { return $l['status'] == 'active'; }));

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Statistics -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-book-reader"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $total; ?></h3>
                <p>Total Librarians</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $active; ?></h3>
                <p>Active</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-user-plus"></i>
            </div>
            <div class="stat-details">
                <h3><button type="button" onclick="showAddModal()" class="btn btn-primary btn-sm">Add New</button></h3>
                <p>Add Librarian</p>
            </div>
        </div>
    </div>
    
    <!-- View Toggle & Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; gap: 10px;">
            <button class="btn btn-primary" onclick="showAddModal()">
                <i class="fas fa-plus"></i> Add Librarian
            </button>
            <div class="btn-group" style="display: inline-flex; border: 2px solid var(--border-color); border-radius: 8px; overflow: hidden;">
                <button id="btnListView" onclick="setView('list')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--primary-blue); color: white;">
                    <i class="fas fa-list"></i> List
                </button>
                <button id="btnGridView" onclick="setView('grid')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--bg-secondary); color: var(--text-primary);">
                    <i class="fas fa-th"></i> Grid
                </button>
            </div>
        </div>
        <div style="font-weight: 600; color: var(--text-secondary);">
            Total: <?php echo count($librarians); ?>
        </div>
    </div>
    
    <!-- List View -->
    <div id="librariansTable" class="card">
        <div class="card-header">
            <h3><i class="fas fa-book-reader"></i> Librarians List</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Phone</th>
                        <th>Login Credentials</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($librarians) > 0): ?>
                        <?php $count = 1; ?>
                        <?php foreach ($librarians as $librarian): ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 35px; height: 35px; border-radius: 8px; background: linear-gradient(135deg, #4CAF50, #8BC34A); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 12px;">
                                            <?php echo strtoupper(substr($librarian['first_name'], 0, 1) . substr($librarian['last_name'], 0, 1)); ?>
                                        </div>
                                        <strong><?php echo $librarian['first_name'] . ' ' . $librarian['last_name']; ?></strong>
                                    </div>
                                </td>
                                <td><?php echo $librarian['email']; ?></td>
                                <td><?php echo $librarian['username']; ?></td>
                                <td><?php echo $librarian['phone'] ?: '-'; ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <div id="cred-hidden-<?php echo $librarian['user_id']; ?>" style="font-family: monospace; font-size: 12px;">
                                            ••••••••
                                        </div>
                                        <div id="cred-shown-<?php echo $librarian['user_id']; ?>" style="display: none; font-family: monospace; font-size: 11px; line-height: 1.4;">
                                            <strong>User:</strong> <?php echo htmlspecialchars($librarian['username']); ?><br>
                                            <strong>Pass:</strong> librarian123
                                        </div>
                                        <button onclick="toggleCredentials(<?php echo $librarian['user_id']; ?>); return false;" type="button" class="btn btn-sm" style="padding: 4px 8px; background: var(--primary-blue); color: white; border: none; border-radius: 4px; cursor: pointer;">
                                            <i class="fas fa-eye" id="eye-<?php echo $librarian['user_id']; ?>"></i>
                                        </button>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $librarian['status'] == 'active' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($librarian['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button onclick='editLibrarian(<?php echo json_encode($librarian); ?>)' 
                                            class="btn btn-info btn-sm">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="openPasswordModal(<?php echo $librarian['user_id']; ?>, '<?php echo addslashes($librarian['first_name'] . ' ' . $librarian['last_name']); ?>')" 
                                            class="btn btn-warning btn-sm">
                                        <i class="fas fa-key"></i>
                                    </button>
                                    <button onclick="deleteLibrarian(<?php echo $librarian['user_id']; ?>, '<?php echo addslashes($librarian['first_name'] . ' ' . $librarian['last_name']); ?>')" 
                                            class="btn btn-danger btn-sm">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 60px;">
                                <i class="fas fa-book-reader" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                                <h3>No Librarians Found</h3>
                                <button type="button" onclick="showAddModal()" class="btn btn-primary" style="margin-top: 15px;">
                                    <i class="fas fa-plus"></i> Add First Librarian
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Grid View -->
    <div id="librariansGrid" style="display: none; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
        <?php foreach ($librarians as $librarian): ?>
            <div class="card" style="padding: 20px;">
                <div style="text-align: center; margin-bottom: 15px;">
                    <div style="width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #4CAF50, #8BC34A); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 28px; margin: 0 auto;">
                        <?php echo strtoupper(substr($librarian['first_name'], 0, 1) . substr($librarian['last_name'], 0, 1)); ?>
                    </div>
                </div>
                <h4 style="text-align: center; margin: 0 0 5px 0;">
                    <?php echo htmlspecialchars($librarian['first_name'] . ' ' . $librarian['last_name']); ?>
                </h4>
                <p style="text-align: center; color: var(--text-secondary); font-size: 12px; margin: 0 0 15px 0;">
                    <i class="fas fa-book-reader"></i> Librarian
                </p>
                <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-bottom: 12px; font-size: 13px;">
                    <div style="margin-bottom: 8px;">
                        <i class="fas fa-envelope" style="width: 20px;"></i> 
                        <strong>Email:</strong> <span style="font-size: 11px;"><?php echo htmlspecialchars($librarian['email']); ?></span>
                    </div>
                    <div style="margin-bottom: 8px;">
                        <i class="fas fa-user" style="width: 20px;"></i> 
                        <strong>Username:</strong> <?php echo htmlspecialchars($librarian['username']); ?>
                    </div>
                    <div>
                        <i class="fas fa-phone" style="width: 20px;"></i> 
                        <strong>Phone:</strong> <?php echo htmlspecialchars($librarian['phone'] ?: 'N/A'); ?>
                    </div>
                </div>
                <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-bottom: 12px; font-size: 12px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <strong><i class="fas fa-key"></i> Login Credentials</strong>
                        <button onclick="toggleCredentials(<?php echo $librarian['user_id']; ?>); return false;" type="button" class="btn btn-sm" style="padding: 4px 8px; background: var(--primary-blue); color: white; border: none; border-radius: 4px; cursor: pointer;">
                            <i class="fas fa-eye" id="eye-<?php echo $librarian['user_id']; ?>"></i>
                        </button>
                    </div>
                    <div id="cred-hidden-<?php echo $librarian['user_id']; ?>" style="font-family: monospace; color: var(--text-primary);">
                        ••••••••
                    </div>
                    <div id="cred-shown-<?php echo $librarian['user_id']; ?>" style="display: none; font-family: monospace; line-height: 1.6; color: var(--text-primary);">
                        <strong>Username:</strong> <?php echo htmlspecialchars($librarian['username']); ?><br>
                        <strong>Password:</strong> librarian123
                    </div>
                </div>
                <div style="text-align: center; margin-bottom: 12px;">
                    <span class="badge badge-<?php echo $librarian['status'] == 'active' ? 'success' : 'warning'; ?>">
                        <?php echo ucfirst($librarian['status']); ?>
                    </span>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px;">
                    <button class="btn btn-sm btn-info" onclick='editLibrarian(<?php echo json_encode($librarian); ?>)'>
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-warning" onclick="openPasswordModal(<?php echo $librarian['user_id']; ?>, '<?php echo addslashes($librarian['first_name'] . ' ' . $librarian['last_name']); ?>')">
                        <i class="fas fa-key"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteLibrarian(<?php echo $librarian['user_id']; ?>, '<?php echo addslashes($librarian['first_name'] . ' ' . $librarian['last_name']); ?>')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Add/Edit Librarian Modal -->
    <div id="librarianModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 700px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Add Librarian</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="librarianForm">
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="user_id" id="userId">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label for="first_name">First Name *</label>
                        <input type="text" name="first_name" id="first_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name *</label>
                        <input type="text" name="last_name" id="last_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" name="email" id="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="username">Username *</label>
                        <input type="text" name="username" id="username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="tel" name="phone" id="phone">
                    </div>
                    
                    <div class="form-group" id="statusGroup" style="display: none;">
                        <label for="status">Status *</label>
                        <select name="status" id="status" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                
                <!-- Password Info for Add Mode -->
                <div id="passwordInfo" style="background: #E8F5E9; border-left: 4px solid #4CAF50; padding: 12px; border-radius: 5px; margin-top: 15px; display: none;">
                    <p style="margin: 0; color: #2E7D32; font-size: 14px;">
                        <i class="fas fa-info-circle"></i> <strong>Default Password:</strong> librarian123 (will be auto-generated)
                    </p>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> <span id="submitText">Save Librarian</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <div id="passwordModal" class="modal">
        <div class="modal-content" style="max-width: 400px;">
            <div class="modal-header">
                <h3><i class="fas fa-key"></i> Reset Password</h3>
                <span class="close" onclick="closePasswordModal()">&times;</span>
            </div>
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="user_id" id="password_user_id">
                <p id="password_user_name" style="margin-bottom: 20px; color: var(--text-secondary); font-weight: 500;"></p>
                <div class="form-group">
                    <label for="new_password">New Password *</label>
                    <input type="password" name="new_password" id="new_password" required minlength="6" class="form-control">
                    <small style="color: var(--text-secondary);">Minimum 6 characters</small>
                </div>
                <div class="modal-footer">
                    <button type="button" onclick="closePasswordModal()" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-key"></i> Reset Password
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <form method="POST" id="deleteForm" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="user_id" id="delete_user_id">
    </form>
    
    <script>
    function setView(view) {
        const table = document.getElementById('librariansTable');
        const grid = document.getElementById('librariansGrid');
        const btnList = document.getElementById('btnListView');
        const btnGrid = document.getElementById('btnGridView');
        if (view === 'grid') {
            table.style.display = 'none';
            grid.style.display = 'grid';
            btnList.style.background = 'var(--bg-secondary)';
            btnList.style.color = 'var(--text-primary)';
            btnGrid.style.background = 'var(--primary-blue)';
            btnGrid.style.color = 'white';
            localStorage.setItem('librarianView', 'grid');
        } else {
            table.style.display = 'block';
            grid.style.display = 'none';
            btnList.style.background = 'var(--primary-blue)';
            btnList.style.color = 'white';
            btnGrid.style.background = 'var(--bg-secondary)';
            btnGrid.style.color = 'var(--text-primary)';
            localStorage.setItem('librarianView', 'list');
        }
    }
    function toggleCredentials(userId) {
        const hidden = document.getElementById('cred-hidden-' + userId);
        const shown = document.getElementById('cred-shown-' + userId);
        const eyes = document.querySelectorAll('#eye-' + userId);
        if (hidden.style.display === 'none') {
            hidden.style.display = 'block';
            shown.style.display = 'none';
            eyes.forEach(eye => eye.className = 'fas fa-eye');
        } else {
            hidden.style.display = 'none';
            shown.style.display = 'block';
            eyes.forEach(eye => eye.className = 'fas fa-eye-slash');
        }
    }
    window.addEventListener('DOMContentLoaded', function() {
        const savedView = localStorage.getItem('librarianView') || 'list';
        setView(savedView);
    });
    function showAddModal() {
        document.getElementById('librarianModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Add Librarian';
        document.getElementById('formAction').value = 'add';
        document.getElementById('librarianForm').reset();
        document.getElementById('userId').value = '';
        document.getElementById('passwordInfo').style.display = 'block';
        document.getElementById('statusGroup').style.display = 'none';
        document.getElementById('submitText').textContent = 'Save Librarian';
    }
    
    function editLibrarian(lib) {
        document.getElementById('librarianModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Edit Librarian';
        document.getElementById('formAction').value = 'edit';
        document.getElementById('userId').value = lib.user_id;
        document.getElementById('first_name').value = lib.first_name;
        document.getElementById('last_name').value = lib.last_name;
        document.getElementById('email').value = lib.email;
        document.getElementById('username').value = lib.username;
        document.getElementById('phone').value = lib.phone || '';
        document.getElementById('status').value = lib.status;
        document.getElementById('passwordInfo').style.display = 'none';
        document.getElementById('statusGroup').style.display = 'block';
        document.getElementById('submitText').textContent = 'Update Librarian';
    }
    
    function closeModal() {
        document.getElementById('librarianModal').style.display = 'none';
    }
    
    function openPasswordModal(id, name) {
        document.getElementById('password_user_id').value = id;
        document.getElementById('password_user_name').textContent = 'Reset password for: ' + name;
        document.getElementById('passwordModal').style.display = 'block';
    }
    
    function closePasswordModal() { 
        document.getElementById('passwordModal').style.display = 'none'; 
    }
    
    function deleteLibrarian(id, name) {
        if (confirm('Delete ' + name + '?')) {
            document.getElementById('delete_user_id').value = id;
            document.getElementById('deleteForm').submit();
        }
    }
    
    window.onclick = function(e) { 
        if (e.target.id === 'librarianModal') {
            e.target.style.display = 'none';
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
