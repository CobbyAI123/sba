<?php
// admin/subjects.php - Subject Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Subject Management';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        // Verify CSRF token
        if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
            set_message('error', 'Invalid request. Please try again.');
            redirect(APP_URL . '/admin/subjects.php');
            exit;
        }
        if ($_POST['action'] == 'add') {
            $subject_name = sanitize_input($_POST['subject_name']);
            $subject_code = sanitize_input($_POST['subject_code']);
            $description = sanitize_input($_POST['description'] ?? '');
            
            try {
                // Try with description column first
                try {
                    $stmt = $db->prepare("
                        INSERT INTO subjects (school_id, subject_name, subject_code, description, status)
                        VALUES (?, ?, ?, ?, 'active')
                    ");
                    $stmt->execute([$school_id, $subject_name, $subject_code, $description]);
                } catch (PDOException $e) {
                    // If description column doesn't exist, try without it
                    if ($e->getCode() == 42000 || $e->getCode() == '42S22') {
                        $stmt = $db->prepare("
                            INSERT INTO subjects (school_id, subject_name, subject_code, status)
                            VALUES (?, ?, ?, 'active')
                        ");
                        $stmt->execute([$school_id, $subject_name, $subject_code]);
                    } else {
                        throw $e;
                    }
                }
                
                $subject_id = $db->lastInsertId();
                log_activity($current_user['user_id'], "Added new subject: $subject_name", 'subjects', $subject_id);
                
                set_message('success', 'Subject added successfully!');
                redirect(APP_URL . '/admin/subjects.php');
            } catch (PDOException $e) {
                if ($e->getCode() == 23000) {
                    set_message('error', 'Subject code already exists. Please use a unique code.');
                } else {
                    set_message('error', 'Error adding subject: ' . $e->getMessage());
                }
            }
        } elseif ($_POST['action'] == 'edit') {
            $subject_id = sanitize_input($_POST['subject_id']);
            $subject_name = sanitize_input($_POST['subject_name']);
            $subject_code = sanitize_input($_POST['subject_code']);
            $description = sanitize_input($_POST['description'] ?? '');
            $status = sanitize_input($_POST['status']);
            
            try {
                // Try with description column first
                try {
                    $stmt = $db->prepare("
                        UPDATE subjects 
                        SET subject_name = ?, subject_code = ?, description = ?, status = ?
                        WHERE subject_id = ? AND school_id = ?
                    ");
                    $stmt->execute([$subject_name, $subject_code, $description, $status, $subject_id, $school_id]);
                } catch (PDOException $e) {
                    // If description column doesn't exist, update without it
                    if ($e->getCode() == 42000 || $e->getCode() == '42S22') {
                        $stmt = $db->prepare("
                            UPDATE subjects 
                            SET subject_name = ?, subject_code = ?, status = ?
                            WHERE subject_id = ? AND school_id = ?
                        ");
                        $stmt->execute([$subject_name, $subject_code, $status, $subject_id, $school_id]);
                    } else {
                        throw $e;
                    }
                }
                
                log_activity($current_user['user_id'], "Updated subject: $subject_name", 'subjects', $subject_id);
                
                set_message('success', 'Subject updated successfully!');
                redirect(APP_URL . '/admin/subjects.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating subject: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            $subject_id = sanitize_input($_POST['subject_id']);
            
            try {
                // Check if subject is assigned to any classes
                $stmt = $db->prepare("SELECT COUNT(*) as count FROM class_subjects WHERE subject_id = ?");
                $stmt->execute([$subject_id]);
                $check = $stmt->fetch();
                
                if ($check && $check['count'] > 0) {
                    set_message('error', 'Cannot delete this subject. It is currently assigned to ' . $check['count'] . ' class(es). Please remove the assignments first.');
                    redirect(APP_URL . '/admin/subjects.php');
                    exit;
                }
                
                // Get subject name before deletion for logging
                $stmt = $db->prepare("SELECT subject_name FROM subjects WHERE subject_id = ? AND school_id = ?");
                $stmt->execute([$subject_id, $school_id]);
                $subject = $stmt->fetch();
                $subject_name = $subject ? $subject['subject_name'] : 'Unknown';
                
                // Delete the subject
                $stmt = $db->prepare("DELETE FROM subjects WHERE subject_id = ? AND school_id = ?");
                $stmt->execute([$subject_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted subject: $subject_name", 'subjects', $subject_id);
                
                set_message('success', 'Subject deleted successfully!');
                redirect(APP_URL . '/admin/subjects.php');
            } catch (PDOException $e) {
                // Handle foreign key constraint errors
                if ($e->getCode() == 23000) {
                    set_message('error', 'Cannot delete this subject. It is currently being used in the system. Please remove all related data first.');
                } else {
                    set_message('error', 'Error deleting subject: ' . $e->getMessage());
                }
                redirect(APP_URL . '/admin/subjects.php');
            }
        }
    }
}

// Get all subjects
$subjects = [];
try {
    $stmt = $db->prepare("
        SELECT s.*,
               COUNT(DISTINCT cs.class_id) as class_count
        FROM subjects s
        LEFT JOIN class_subjects cs ON s.subject_id = cs.subject_id
        WHERE s.school_id = ?
        GROUP BY s.subject_id
        ORDER BY s.subject_name ASC
    ");
    $stmt->execute([$school_id]);
    $subjects = $stmt->fetchAll();
} catch (PDOException $e) {
    // class_subjects table may not exist
    $stmt = $db->prepare("SELECT * FROM subjects WHERE school_id = ? ORDER BY subject_name ASC");
    $stmt->execute([$school_id]);
    $subjects = $stmt->fetchAll();
    // Add default class_count for display
    foreach ($subjects as &$subject) {
        $subject['class_count'] = 0;
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
            <button class="btn btn-primary" onclick="showAddModal()">
                <i class="fas fa-plus"></i> Add Subject
            </button>
        </div>
    </div>
    
    <!-- Subjects Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-book-open"></i> Subjects (<?php echo count($subjects); ?>)</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Subject Code</th>
                        <th>Subject Name</th>
                        <th>Description</th>
                        <th>Classes</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($subjects) > 0): ?>
                        <?php foreach ($subjects as $subject): ?>
                            <tr>
                                <td><strong><?php echo $subject['subject_code']; ?></strong></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 35px; height: 35px; border-radius: 8px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600;">
                                            <?php echo strtoupper(substr($subject['subject_name'], 0, 2)); ?>
                                        </div>
                                        <span><?php echo $subject['subject_name']; ?></span>
                                    </div>
                                </td>
                                <td style="max-width: 300px;">
                                    <?php 
                                    $desc = $subject['description'] ?? '';
                                    echo $desc ? (strlen($desc) > 50 ? substr($desc, 0, 50) . '...' : $desc) : 'N/A'; 
                                    ?>
                                </td>
                                <td>
                                    <span class="badge badge-info">
                                        <?php echo $subject['class_count']; ?> classes
                                    </span>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $subject['status'] == 'active' ? 'success' : 'danger'; ?>">
                                        <?php echo ucfirst($subject['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-info" onclick='editSubject(<?php echo json_encode($subject); ?>)'>
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php if ($subject['class_count'] > 0): ?>
                                        <button class="btn btn-sm btn-secondary" disabled title="Cannot delete: Subject is assigned to <?php echo $subject['class_count']; ?> class(es)">
                                            <i class="fas fa-lock"></i>
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-sm btn-danger" onclick="deleteSubject(<?php echo $subject['subject_id']; ?>, '<?php echo addslashes($subject['subject_name']); ?>')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 60px;">
                                <i class="fas fa-book-open" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                                <h3 style="margin-bottom: 10px;">No Subjects Yet</h3>
                                <p style="color: var(--text-secondary); margin-bottom: 20px;">Add subjects like Mathematics, English, Science, etc.</p>
                                <button class="btn btn-primary" onclick="showAddModal()">
                                    <i class="fas fa-plus"></i> Add Your First Subject
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Add/Edit Subject Modal -->
    <div id="subjectModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Add Subject</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="subjectForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="subject_id" id="subjectId">
                
                <div class="form-group">
                    <label for="subject_name">Subject Name *</label>
                    <input type="text" name="subject_name" id="subject_name" placeholder="e.g., Mathematics, English, Biology" required>
                </div>
                
                <div class="form-group">
                    <label for="subject_code">Subject Code *</label>
                    <input type="text" name="subject_code" id="subject_code" placeholder="e.g., MATH101, ENG101" required style="text-transform: uppercase;">
                    <small style="color: var(--text-secondary); font-size: 12px;">Unique code for this subject</small>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" id="description" rows="3" placeholder="Brief description of the subject"></textarea>
                </div>
                
                <div class="form-group" id="statusGroup" style="display: none;">
                    <label for="status">Status *</label>
                    <select name="status" id="status">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Subject
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showAddModal() {
        document.getElementById('subjectModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Add Subject';
        document.getElementById('formAction').value = 'add';
        document.getElementById('subjectForm').reset();
        document.getElementById('subjectId').value = '';
        document.getElementById('statusGroup').style.display = 'none';
    }
    
    function editSubject(subject) {
        document.getElementById('subjectModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Edit Subject';
        document.getElementById('formAction').value = 'edit';
        document.getElementById('subjectId').value = subject.subject_id;
        document.getElementById('subject_name').value = subject.subject_name;
        document.getElementById('subject_code').value = subject.subject_code;
        document.getElementById('description').value = subject.description || '';
        document.getElementById('status').value = subject.status;
        document.getElementById('statusGroup').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('subjectModal').style.display = 'none';
    }
    
    function deleteSubject(subjectId, subjectName) {
        if (confirmDelete(`Are you sure you want to delete "${subjectName}"? This action cannot be undone.`)) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="subject_id" value="${subjectId}">
            `;
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Auto-uppercase subject code
    document.getElementById('subject_code').addEventListener('input', function(e) {
        e.target.value = e.target.value.toUpperCase();
    });
    
    // Close modal on outside click
    document.getElementById('subjectModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
