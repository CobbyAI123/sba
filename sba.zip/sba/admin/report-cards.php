<?php
// admin/report-cards.php - Generate Report Cards
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Report Cards';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get filter parameters
$class_filter = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$term_filter = isset($_GET['term_id']) ? (int)$_GET['term_id'] : 0;
$student_filter = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;

// Get classes
$stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get terms
$stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY start_date DESC");
$stmt->execute([$school_id]);
$terms = $stmt->fetchAll();

// Get students if class is selected
$students = [];
if ($class_filter > 0) {
    $stmt = $db->prepare("
        SELECT s.student_id, s.admission_number, u.first_name, u.last_name
        FROM students s
        INNER JOIN users u ON s.user_id = u.user_id
        WHERE s.class_id = ? AND s.school_id = ?
        ORDER BY u.first_name, u.last_name
    ");
    $stmt->execute([$class_filter, $school_id]);
    $students = $stmt->fetchAll();
}

// Get report card data if all filters are set
$report_data = null;
if ($class_filter > 0 && $term_filter > 0 && $student_filter > 0) {
    // Get student details
    $stmt = $db->prepare("
        SELECT s.*, c.class_name, c.section
        FROM students s
        INNER JOIN classes c ON s.class_id = c.class_id
        WHERE s.student_id = ?
    ");
    $stmt->execute([$student_filter]);
    $student_info = $stmt->fetch();
    
    // Get term details
    $stmt = $db->prepare("SELECT * FROM terms WHERE term_id = ?");
    $stmt->execute([$term_filter]);
    $term_info = $stmt->fetch();
    
    // Get marks for all subjects
    $stmt = $db->prepare("
        SELECT 
            s.subject_name,
            s.subject_code,
            e.exam_name,
            e.total_marks,
            m.marks_obtained,
            m.remarks
        FROM marks m
        INNER JOIN exams e ON m.exam_id = e.exam_id
        INNER JOIN subjects s ON m.subject_id = s.subject_id
        WHERE m.student_id = ? 
        AND e.class_id = ?
        AND e.exam_date BETWEEN ? AND ?
        ORDER BY s.subject_name, e.exam_date
    ");
    $stmt->execute([
        $student_filter, 
        $class_filter,
        $term_info['start_date'],
        $term_info['end_date']
    ]);
    $marks = $stmt->fetchAll();
    
    // Get attendance
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total_days,
            SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_days
        FROM attendance
        WHERE student_id = ?
        AND attendance_date BETWEEN ? AND ?
    ");
    $stmt->execute([
        $student_filter,
        $term_info['start_date'],
        $term_info['end_date']
    ]);
    $attendance = $stmt->fetch();
    
    // Calculate overall performance
    $total_marks_obtained = array_sum(array_column($marks, 'marks_obtained'));
    $total_marks_possible = array_sum(array_column($marks, 'total_marks'));
    $overall_percentage = $total_marks_possible > 0 ? ($total_marks_obtained / $total_marks_possible) * 100 : 0;
    
    // Determine grade
    if ($overall_percentage >= 80) $overall_grade = 'A - Excellent';
    elseif ($overall_percentage >= 70) $overall_grade = 'B - Very Good';
    elseif ($overall_percentage >= 60) $overall_grade = 'C - Good';
    elseif ($overall_percentage >= 50) $overall_grade = 'D - Pass';
    else $overall_grade = 'F - Fail';
    
    $report_data = [
        'student' => $student_info,
        'term' => $term_info,
        'marks' => $marks,
        'attendance' => $attendance,
        'total_obtained' => $total_marks_obtained,
        'total_possible' => $total_marks_possible,
        'percentage' => $overall_percentage,
        'grade' => $overall_grade
    ];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fa-file"></i> REPORT CARD</h1>
    </div>

    <style>
    .report-card {
        background: white;
        color: #000;
        max-width: 900px;
        margin: 0 auto;
        padding: 40px;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
    }
    
    .report-header {
        text-align: center;
        border-bottom: 3px solid #2196F3;
        padding-bottom: 20px;
        margin-bottom: 30px;
    }
    
    .report-header h1 {
        color: #2196F3;
        margin: 10px 0;
    }
    
    .student-info {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
        margin-bottom: 30px;
        background: #f5f5f5;
        padding: 20px;
        border-radius: 10px;
    }
    
    .info-item {
        display: flex;
        gap: 10px;
    }
    
    .info-label {
        font-weight: 600;
        color: #555;
    }
    
    .marks-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 30px;
    }
    
    .marks-table th {
        background: #2196F3;
        color: white;
        padding: 12px;
        text-align: left;
    }
    
    .marks-table td {
        padding: 10px 12px;
        border-bottom: 1px solid #ddd;
    }
    
    .marks-table tr:hover {
        background: #f5f5f5;
    }
    
    .summary-section {
        background: #e3f2fd;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 20px;
    }
    
    .summary-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
        text-align: center;
    }
    
    .summary-item {
        background: white;
        padding: 15px;
        border-radius: 8px;
    }
    
    .summary-value {
        font-size: 32px;
        font-weight: 700;
        color: #2196F3;
    }
    
    .summary-label {
        color: #666;
        font-size: 14px;
    }
    
    .remarks-section {
        margin-top: 40px;
        padding-top: 20px;
        border-top: 2px solid #ddd;
    }
    
    .signature-section {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 30px;
        margin-top: 50px;
    }
    
    .signature-box {
        text-align: center;
    }
    
    .signature-line {
        border-top: 2px solid #000;
        margin-top: 50px;
        padding-top: 10px;
    }
    
    @media print {
        body {
            background: white;
        }
        
        .sidebar, .header, .no-print {
            display: none !important;
        }
        
        .main-content {
            margin: 0;
            width: 100%;
        }
        
        .report-card {
            box-shadow: none;
            padding: 20px;
        }
    }
    </style>
    
    <!-- Page Header -->
    <div class="card no-print" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-file-pdf"></i> Report Cards
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Generate and print student report cards
            </p>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card no-print" style="margin-bottom: 30px;">
        <div style="padding: 25px;">
            <h3 style="margin-bottom: 20px;"><i class="fas fa-filter"></i> Select Student</h3>
            <form method="GET">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                    <div class="form-group">
                        <label>Class *</label>
                        <select name="class_id" required onchange="this.form.submit()">
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>" <?php echo $class_filter == $class['class_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($class['class_name']); ?>
                                    <?php echo !empty($class['section']) ? ' - ' . htmlspecialchars($class['section']) : ''; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Term *</label>
                        <select name="term_id" required onchange="this.form.submit()">
                            <option value="">-- Select Term --</option>
                            <?php foreach ($terms as $term): ?>
                                <option value="<?php echo $term['term_id']; ?>" <?php echo $term_filter == $term['term_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($term['term_name'] . ' - ' . $term['session_year']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Student *</label>
                        <select name="student_id" required onchange="this.form.submit()">
                            <option value="">-- Select Student --</option>
                            <?php foreach ($students as $student): ?>
                                <option value="<?php echo $student['student_id']; ?>" <?php echo $student_filter == $student['student_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name'] . ' (' . $student['admission_number'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <?php if ($report_data): ?>
        <!-- Print Button -->
        <div class="no-print" style="text-align: right; margin-bottom: 20px;">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Print Report Card
            </button>
        </div>
        
        <!-- Report Card -->
        <div class="report-card">
            <!-- Header -->
            <div class="report-header">
                
                <h3><?php echo htmlspecialchars($report_data['term']['term_name']); ?> - <?php echo htmlspecialchars($report_data['term']['session_year']); ?></h3>
            </div>
            
            <!-- Student Information -->
            <div class="student-info">
                <div class="info-item">
                    <span class="info-label">Name:</span>
                    <span><?php echo htmlspecialchars($report_data['student']['first_name'] . ' ' . $report_data['student']['last_name']); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Admission No:</span>
                    <span><?php echo htmlspecialchars($report_data['student']['admission_number']); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Class:</span>
                    <span><?php echo htmlspecialchars($report_data['student']['class_name']); ?>
                        <?php echo $report_data['student']['section'] ? ' - ' . htmlspecialchars($report_data['student']['section']) : ''; ?>
                    </span>
                </div>
                <div class="info-item">
                    <span class="info-label">Date of Birth:</span>
                    <span><?php echo date('M j, Y', strtotime($report_data['student']['date_of_birth'])); ?></span>
                </div>
            </div>
            
            <!-- Academic Performance -->
            <h3 style="margin-bottom: 15px; color: #2196F3;">Academic Performance</h3>
            <table class="marks-table">
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Exam</th>
                        <th style="text-align: center;">Total Marks</th>
                        <th style="text-align: center;">Marks Obtained</th>
                        <th style="text-align: center;">Percentage</th>
                        <th style="text-align: center;">Grade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($report_data['marks'] as $mark): 
                        $percentage = ($mark['marks_obtained'] / $mark['total_marks']) * 100;
                        if ($percentage >= 80) $grade = 'A';
                        elseif ($percentage >= 70) $grade = 'B';
                        elseif ($percentage >= 60) $grade = 'C';
                        elseif ($percentage >= 50) $grade = 'D';
                        else $grade = 'F';
                    ?>
                        <tr>
                            <td><?php echo htmlspecialchars($mark['subject_name']); ?></td>
                            <td><?php echo htmlspecialchars($mark['exam_name']); ?></td>
                            <td style="text-align: center;"><?php echo $mark['total_marks']; ?></td>
                            <td style="text-align: center;"><strong><?php echo $mark['marks_obtained']; ?></strong></td>
                            <td style="text-align: center;"><?php echo number_format($percentage, 1); ?>%</td>
                            <td style="text-align: center;"><strong><?php echo $grade; ?></strong></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <!-- Summary -->
            <div class="summary-section">
                <h3 style="margin-bottom: 20px; color: #2196F3;">Overall Performance</h3>
                <div class="summary-grid">
                    <div class="summary-item">
                        <div class="summary-value"><?php echo number_format($report_data['percentage'], 1); ?>%</div>
                        <div class="summary-label">Overall Percentage</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-value"><?php echo $report_data['grade']; ?></div>
                        <div class="summary-label">Grade</div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-value">
                            <?php 
                            $attendance_percentage = $report_data['attendance']['total_days'] > 0 
                                ? ($report_data['attendance']['present_days'] / $report_data['attendance']['total_days']) * 100 
                                : 0;
                            echo number_format($attendance_percentage, 1); 
                            ?>%
                        </div>
                        <div class="summary-label">Attendance</div>
                    </div>
                </div>
            </div>
            
            <!-- Remarks -->
            <div class="remarks-section">
                <h4>Class Teacher's Remarks:</h4>
                <p style="min-height: 60px; padding: 15px; background: #f5f5f5; border-radius: 5px; margin-top: 10px;">
                    <?php 
                    if ($report_data['percentage'] >= 80) {
                        echo "Excellent performance! Keep up the good work.";
                    } elseif ($report_data['percentage'] >= 70) {
                        echo "Very good performance. Continue working hard.";
                    } elseif ($report_data['percentage'] >= 60) {
                        echo "Good performance. There is room for improvement.";
                    } elseif ($report_data['percentage'] >= 50) {
                        echo "Satisfactory performance. More effort needed.";
                    } else {
                        echo "Needs significant improvement. Extra attention required.";
                    }
                    ?>
                </p>
            </div>
            
            <!-- Signatures -->
            <div class="signature-section">
                <div class="signature-box">
                    <div class="signature-line">Class Teacher</div>
                </div>
                <div class="signature-box">
                    <div class="signature-line">Principal</div>
                </div>
                <div class="signature-box">
                    <div class="signature-line">Parent/Guardian</div>
                </div>
            </div>
            
            <!-- Footer -->
            <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; font-size: 12px;">
                <p>Generated on <?php echo date('F j, Y'); ?></p>
            </div>
        </div>
    <?php else: ?>
        <div class="card">
            <div style="padding: 60px; text-align: center;">
                <i class="fas fa-file-pdf" style="font-size: 64px; color: var(--text-secondary); opacity: 0.3; margin-bottom: 20px;"></i>
                <h3 style="color: var(--text-secondary); margin-bottom: 10px;">Select Filters</h3>
                <p style="color: var(--text-secondary);">Please select class, term, and student to generate report card.</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
