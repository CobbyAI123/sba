<?php
// admin/analytics-dashboard.php - Visual Analytics Dashboard
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['admin', 'super_admin', 'proprietor']);
$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get current academic year/term
$current_term = null;
try {
    $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_current = 1 LIMIT 1");
    $stmt->execute([$school_id]);
    $current_term = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // No current term
}

// ===== KEY METRICS =====
$metrics = [
    'total_students' => 0,
    'total_teachers' => 0,
    'total_classes' => 0,
    'total_revenue' => 0,
    'attendance_rate' => 0,
    'active_parents' => 0
];

// Get student count
try {
    $stmt = $db->prepare("SELECT COUNT(*) FROM students WHERE school_id = ? AND status = 'active'");
    $stmt->execute([$school_id]);
    $metrics['total_students'] = $stmt->fetchColumn();
} catch (PDOException $e) {}

// Get teacher count
try {
    $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE school_id = ? AND role = 'teacher'");
    $stmt->execute([$school_id]);
    $metrics['total_teachers'] = $stmt->fetchColumn();
} catch (PDOException $e) {}

// Get class count
try {
    $stmt = $db->prepare("SELECT COUNT(*) FROM classes WHERE school_id = ?");
    $stmt->execute([$school_id]);
    $metrics['total_classes'] = $stmt->fetchColumn();
} catch (PDOException $e) {}

// Get total revenue (this year)
try {
    $stmt = $db->prepare("
        SELECT SUM(amount) 
        FROM payments 
        WHERE school_id = ? 
        AND payment_status = 'success'
        AND YEAR(payment_date) = YEAR(CURDATE())
    ");
    $stmt->execute([$school_id]);
    $metrics['total_revenue'] = $stmt->fetchColumn() ?? 0;
} catch (PDOException $e) {}

// Get attendance rate (last 30 days)
try {
    $stmt = $db->prepare("
        SELECT 
            AVG(CASE WHEN status = 'present' THEN 100 ELSE 0 END) as attendance_rate
        FROM attendance
        WHERE school_id = ?
        AND attendance_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    ");
    $stmt->execute([$school_id]);
    $metrics['attendance_rate'] = $stmt->fetchColumn() ?? 0;
} catch (PDOException $e) {}

// Get active parents
try {
    $stmt = $db->prepare("SELECT COUNT(DISTINCT parent_id) FROM students WHERE school_id = ?");
    $stmt->execute([$school_id]);
    $metrics['active_parents'] = $stmt->fetchColumn() ?? 0;
} catch (PDOException $e) {}

// ===== STUDENT ENROLLMENT TREND (Last 12 months) =====
$enrollment_trend = [];
try {
    $stmt = $db->prepare("
        SELECT 
            DATE_FORMAT(admission_date, '%Y-%m') as month,
            COUNT(*) as student_count
        FROM students
        WHERE school_id = ?
        AND admission_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
        GROUP BY month
        ORDER BY month ASC
    ");
    $stmt->execute([$school_id]);
    $enrollment_trend = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $enrollment_trend = [];
}

// ===== REVENUE TREND (Last 12 months) =====
$revenue_trend = [];
try {
    $stmt = $db->prepare("
        SELECT 
            DATE_FORMAT(payment_date, '%Y-%m') as month,
            SUM(amount) as revenue
        FROM payments
        WHERE school_id = ?
        AND payment_status = 'success'
        AND payment_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
        GROUP BY month
        ORDER BY month ASC
    ");
    $stmt->execute([$school_id]);
    $revenue_trend = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $revenue_trend = [];
}

// ===== ATTENDANCE TREND (Last 30 days) =====
$attendance_trend = [];
try {
    $stmt = $db->prepare("
        SELECT 
            attendance_date,
            COUNT(CASE WHEN status = 'present' THEN 1 END) as present,
            COUNT(CASE WHEN status = 'absent' THEN 1 END) as absent,
            COUNT(*) as total
        FROM attendance
        WHERE school_id = ?
        AND attendance_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY attendance_date
        ORDER BY attendance_date ASC
    ");
    $stmt->execute([$school_id]);
    $attendance_trend = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $attendance_trend = [];
}

// ===== CLASS DISTRIBUTION =====
$class_distribution = [];
try {
    $stmt = $db->prepare("
        SELECT 
            c.class_name,
            COUNT(s.student_id) as student_count
        FROM classes c
        LEFT JOIN students s ON c.class_id = s.class_id AND s.status = 'active'
        WHERE c.school_id = ?
        GROUP BY c.class_id
        ORDER BY c.class_name
    ");
    $stmt->execute([$school_id]);
    $class_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $class_distribution = [];
}

// ===== PERFORMANCE OVERVIEW (if exams exist) =====
$performance_data = [];
try {
    $stmt = $db->prepare("
        SELECT 
            AVG(total_score) as avg_score,
            MAX(total_score) as max_score,
            MIN(total_score) as min_score,
            COUNT(*) as total_assessments
        FROM student_assessments sa
        INNER JOIN students s ON sa.student_id = s.student_id
        WHERE s.school_id = ?
    ");
    $stmt->execute([$school_id]);
    $performance_data = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $performance_data = ['avg_score' => 0, 'max_score' => 0, 'min_score' => 0, 'total_assessments' => 0];
}

// ===== GENDER DISTRIBUTION =====
$gender_distribution = [];
try {
    $stmt = $db->prepare("
        SELECT 
            gender,
            COUNT(*) as count
        FROM students
        WHERE school_id = ?
        AND status = 'active'
        GROUP BY gender
    ");
    $stmt->execute([$school_id]);
    $gender_distribution = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $gender_distribution = [];
}

require_once BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .metric-card {
        background: var(--bg-card);
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 20px;
        box-shadow: var(--shadow-md);
        border-left: 5px solid;
        transition: transform 0.3s, box-shadow 0.3s;
    }
    .metric-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-lg);
    }
    .metric-card.blue { border-color: #3B82F6; }
    .metric-card.green { border-color: #10B981; }
    .metric-card.orange { border-color: #F59E0B; }
    .metric-card.purple { border-color: #8B5CF6; }
    .metric-card.pink { border-color: #EC4899; }
    .metric-card.red { border-color: #EF4444; }
    
    .metric-icon {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        color: white;
        margin-bottom: 15px;
    }
    .metric-value {
        font-size: 36px;
        font-weight: bold;
        color: var(--text-primary);
        margin: 10px 0;
    }
    .metric-label {
        color: var(--text-secondary);
        font-size: 14px;
    }
    .chart-card {
        background: var(--bg-card);
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 20px;
        box-shadow: var(--shadow-md);
    }
    .chart-title {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 20px;
        color: var(--text-primary);
    }
    </style>
    
    <div class="container-fluid mt-4">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2><i class="fas fa-chart-bar"></i> Analytics Dashboard</h2>
                <p class="text-muted mb-0">Comprehensive school performance insights</p>
            </div>
            <div>
                <button onclick="location.reload()" class="btn btn-primary">
                    <i class="fas fa-sync-alt"></i> Refresh
                </button>
            </div>
        </div>
    
        <!-- Key Metrics -->
        <div class="row">
            <div class="col-md-4 col-lg-2">
                <div class="metric-card blue">
                    <div class="metric-icon" style="background: #3B82F6;">
                        <i class="fas fa-user-graduate"></i>
                    </div>
                    <div class="metric-value"><?php echo number_format($metrics['total_students']); ?></div>
                    <div class="metric-label">Total Students</div>
                </div>
            </div>
            <div class="col-md-4 col-lg-2">
                <div class="metric-card green">
                    <div class="metric-icon" style="background: #10B981;">
                        <i class="fas fa-chalkboard-teacher"></i>
                    </div>
                    <div class="metric-value"><?php echo number_format($metrics['total_teachers']); ?></div>
                    <div class="metric-label">Teachers</div>
                </div>
            </div>
            <div class="col-md-4 col-lg-2">
                <div class="metric-card orange">
                    <div class="metric-icon" style="background: #F59E0B;">
                        <i class="fas fa-door-open"></i>
                    </div>
                    <div class="metric-value"><?php echo number_format($metrics['total_classes']); ?></div>
                    <div class="metric-label">Classes</div>
                </div>
            </div>
            <div class="col-md-4 col-lg-2">
                <div class="metric-card purple">
                    <div class="metric-icon" style="background: #8B5CF6;">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                    <div class="metric-value">₵<?php echo number_format($metrics['total_revenue']/1000, 1); ?>K</div>
                    <div class="metric-label">Revenue (YTD)</div>
                </div>
            </div>
            <div class="col-md-4 col-lg-2">
                <div class="metric-card pink">
                    <div class="metric-icon" style="background: #EC4899;">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="metric-value"><?php echo number_format($metrics['attendance_rate'], 1); ?>%</div>
                    <div class="metric-label">Attendance Rate</div>
                </div>
            </div>
            <div class="col-md-4 col-lg-2">
                <div class="metric-card red">
                    <div class="metric-icon" style="background: #EF4444;">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="metric-value"><?php echo number_format($metrics['active_parents']); ?></div>
                    <div class="metric-label">Active Parents</div>
                </div>
            </div>
        </div>
    
        <!-- Charts Row 1 -->
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="chart-card">
                    <div class="chart-title">
                        <i class="fas fa-chart-line text-primary"></i> Student Enrollment Trend (12 Months)
                    </div>
                    <canvas id="enrollmentChart" height="250"></canvas>
                </div>
            </div>
            <div class="col-md-6">
                <div class="chart-card">
                    <div class="chart-title">
                        <i class="fas fa-money-bill-trend-up text-success"></i> Revenue Trend (12 Months)
                    </div>
                    <canvas id="revenueChart" height="250"></canvas>
                </div>
            </div>
        </div>
    
        <!-- Charts Row 2 -->
        <div class="row">
            <div class="col-md-8">
                <div class="chart-card">
                    <div class="chart-title">
                        <i class="fas fa-calendar-check text-info"></i> Attendance Trend (30 Days)
                    </div>
                    <canvas id="attendanceChart" height="250"></canvas>
                </div>
            </div>
            <div class="col-md-4">
                <div class="chart-card">
                    <div class="chart-title">
                        <i class="fas fa-venus-mars text-warning"></i> Gender Distribution
                    </div>
                    <canvas id="genderChart" height="250"></canvas>
                </div>
            </div>
        </div>
    
        <!-- Charts Row 3 -->
        <div class="row">
            <div class="col-md-6">
                <div class="chart-card">
                    <div class="chart-title">
                        <i class="fas fa-school text-primary"></i> Students by Class
                    </div>
                    <canvas id="classChart" height="300"></canvas>
                </div>
            </div>
            <div class="col-md-6">
                <div class="chart-card">
                    <div class="chart-title">
                        <i class="fas fa-graduation-cap text-success"></i> Performance Overview
                    </div>
                    <div class="row text-center mt-4">
                        <div class="col-4">
                            <div class="metric-icon mx-auto" style="background: #10B981; width: 80px; height: 80px;">
                                <i class="fas fa-award"></i>
                            </div>
                            <div class="metric-value" style="font-size: 28px;"><?php echo number_format($performance_data['avg_score'] ?? 0, 1); ?>%</div>
                            <div class="metric-label">Average Score</div>
                        </div>
                        <div class="col-4">
                            <div class="metric-icon mx-auto" style="background: #3B82F6; width: 80px; height: 80px;">
                                <i class="fas fa-trophy"></i>
                            </div>
                            <div class="metric-value" style="font-size: 28px;"><?php echo number_format($performance_data['max_score'] ?? 0, 1); ?>%</div>
                            <div class="metric-label">Highest Score</div>
                        </div>
                        <div class="col-4">
                            <div class="metric-icon mx-auto" style="background: #F59E0B; width: 80px; height: 80px;">
                                <i class="fas fa-chart-bar"></i>
                            </div>
                            <div class="metric-value" style="font-size: 28px;"><?php echo number_format($performance_data['total_assessments'] ?? 0); ?></div>
                            <div class="metric-label">Total Assessments</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <script>
    // Chart.js default settings
    Chart.defaults.font.family = 'Segoe UI, Arial, sans-serif';
    Chart.defaults.color = '#666';
    
    // 1. Enrollment Trend Chart
    const enrollmentCtx = document.getElementById('enrollmentChart');
    if (enrollmentCtx) {
        new Chart(enrollmentCtx.getContext('2d'), {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($enrollment_trend, 'month')); ?>,
                datasets: [{
                    label: 'New Students',
                    data: <?php echo json_encode(array_column($enrollment_trend, 'student_count')); ?>,
                    borderColor: '#3B82F6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointRadius: 5,
                    pointHoverRadius: 7
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true }
                },
                animation: {
                    duration: 750,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }
    
    // 2. Revenue Trend Chart
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        new Chart(revenueCtx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($revenue_trend, 'month')); ?>,
                datasets: [{
                    label: 'Revenue (GH₵)',
                    data: <?php echo json_encode(array_column($revenue_trend, 'revenue')); ?>,
                    backgroundColor: 'rgba(16, 185, 129, 0.8)',
                    borderColor: '#10B981',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (context) => 'GH₵ ' + context.parsed.y.toFixed(2)
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: (value) => 'GH₵ ' + value.toLocaleString()
                        }
                    }
                },
                animation: {
                    duration: 750,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }
    
    // 3. Attendance Trend Chart
    const attendanceCtx = document.getElementById('attendanceChart');
    if (attendanceCtx) {
        new Chart(attendanceCtx.getContext('2d'), {
            type: 'line',
            data: {
                labels: <?php echo json_encode(array_column($attendance_trend, 'attendance_date')); ?>,
                datasets: [
                    {
                        label: 'Present',
                        data: <?php echo json_encode(array_column($attendance_trend, 'present')); ?>,
                        borderColor: '#10B981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Absent',
                        data: <?php echo json_encode(array_column($attendance_trend, 'absent')); ?>,
                        borderColor: '#EF4444',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top' }
                },
                scales: {
                    y: { beginAtZero: true }
                },
                animation: {
                    duration: 750,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }
    
    // 4. Gender Distribution Chart
    const genderCtx = document.getElementById('genderChart');
    if (genderCtx) {
        new Chart(genderCtx.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode(array_column($gender_distribution, 'gender')); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_column($gender_distribution, 'count')); ?>,
                    backgroundColor: ['#3B82F6', '#EC4899'],
                    borderWidth: 3,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                },
                animation: {
                    duration: 750,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }
    
    // 5. Class Distribution Chart
    const classCtx = document.getElementById('classChart');
    if (classCtx) {
        new Chart(classCtx.getContext('2d'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($class_distribution, 'class_name')); ?>,
                datasets: [{
                    label: 'Students',
                    data: <?php echo json_encode(array_column($class_distribution, 'student_count')); ?>,
                    backgroundColor: 'rgba(139, 92, 246, 0.8)',
                    borderColor: '#8B5CF6',
                    borderWidth: 2
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: { beginAtZero: true }
                },
                animation: {
                    duration: 750,
                    easing: 'easeInOutQuart'
                }
            }
        });
    }
    </script>
    
    <?php require_once BASE_PATH . '/
</div>

includes/footer.php'; ?>