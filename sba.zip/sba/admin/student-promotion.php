<?php
// admin/student-promotion.php - Student Promotion System
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Student Promotion';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'promote_students') {
            $academic_year = sanitize_input($_POST['academic_year']);
            $from_class_id = (int)$_POST['from_class_id'];
            $to_class_id = !empty($_POST['to_class_id']) ? (int)$_POST['to_class_id'] : null;
            $pass_mark = (float)$_POST['pass_mark'];
            $selected_term_id = !empty($_POST['term_id']) ? (int)$_POST['term_id'] : null;
            
            try {
                $db->beginTransaction();
                
                // Get students from the class
                $stmt = $db->prepare("
                    SELECT s.student_id, s.admission_number, s.entry_term, u.first_name, u.last_name
                    FROM students s
                    INNER JOIN users u ON s.user_id = u.user_id
                    WHERE s.school_id = ? AND s.class_id = ? AND s.status = 'active'
                ");
                $stmt->execute([$school_id, $from_class_id]);
                $students = $stmt->fetchAll();
                
                $promoted_count = 0;
                $repeated_count = 0;
                
                foreach ($students as $student) {
                    // Get student's entry term (default to 1 if not set)
                    $student_entry_term = $student['entry_term'] ?? 1;
                    
                    // Calculate student's performance based on selected term or their entry term
                    $performance = calculateStudentPerformance($db, $student['student_id'], $academic_year, $student_entry_term, $selected_term_id);
                    
                    $promotion_type = 'promoted';
                    $decision_reason = '';
                    $new_class_id = $to_class_id;
                    
                    // Decision logic based on annual average
                    if ($performance['annual_average'] < $pass_mark) {
                        $promotion_type = 'repeated';
                        $new_class_id = $from_class_id; // Stay in same class
                        $decision_reason = "Annual average ({$performance['annual_average']}%) below pass mark ({$pass_mark}%). Calculation: {$performance['calculation_basis']}";
                        $repeated_count++;
                    } else {
                        if ($to_class_id === null) {
                            $promotion_type = 'graduated';
                            $decision_reason = "Completed final class with {$performance['annual_average']}% average";
                        } else {
                            $decision_reason = "Annual average: {$performance['annual_average']}% - Passed. {$performance['calculation_basis']}";
                        }
                        $promoted_count++;
                    }
                    
                    // Record promotion with detailed information
                    $stmt = $db->prepare("
                        INSERT INTO student_promotions 
                        (school_id, student_id, academic_year, from_class_id, to_class_id, 
                         promotion_type, promotion_date, annual_average, annual_total, pass_mark, 
                         decision_reason, terms_completed, entry_term, promoted_by)
                        VALUES (?, ?, ?, ?, ?, ?, CURDATE(), ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $school_id,
                        $student['student_id'],
                        $academic_year,
                        $from_class_id,
                        $new_class_id,
                        $promotion_type,
                        $performance['annual_average'],
                        $performance['annual_total'],
                        $pass_mark,
                        $decision_reason,
                        $performance['terms_completed'],
                        $student_entry_term,
                        $current_user['user_id']
                    ]);
                    
                    // Update student's class and promotion status
                    // IMPORTANT: Admission number is NEVER changed - it's permanent
                    if ($promotion_type !== 'graduated') {
                        $stmt = $db->prepare("
                            UPDATE students 
                            SET class_id = ?, promotion_status = ?, current_academic_year = ?
                            WHERE student_id = ?
                        ");
                        $stmt->execute([$new_class_id, $promotion_type, $academic_year, $student['student_id']]);
                    } else {
                        // Mark as graduated - admission number remains unchanged
                        $stmt = $db->prepare("
                            UPDATE students 
                            SET promotion_status = 'graduated', status = 'graduated'
                            WHERE student_id = ?
                        ");
                        $stmt->execute([$student['student_id']]);
                    }
                }
                
                $db->commit();
                
                log_activity($current_user['user_id'], "Promoted/Repeated students: {$promoted_count} promoted, {$repeated_count} repeated", 'students', null);
                set_message('success', "Promotion complete! {$promoted_count} student(s) promoted, {$repeated_count} student(s) repeated.");
                redirect(APP_URL . '/admin/student-promotion.php');
            } catch (PDOException $e) {
                $db->rollBack();
                set_message('error', 'Error processing promotions: ' . $e->getMessage());
            }
        }
    }
}

// Get current academic year
// First try to get from academic_years table if it exists
$current_year = null;
try {
    $stmt = $db->prepare("SELECT * FROM academic_years WHERE school_id = ? AND is_current = 1");
    $stmt->execute([$school_id]);
    $current_year = $stmt->fetch();
} catch (PDOException $e) {
    // academic_years table might not exist, try getting current term instead
    try {
        $stmt = $db->prepare("SELECT term_id, term_name as year_name, session_year, start_date, end_date FROM terms WHERE school_id = ? AND is_current = 1 LIMIT 1");
        $stmt->execute([$school_id]);
        $current_year = $stmt->fetch();
        if ($current_year) {
            $current_year['vacation_start'] = $current_year['end_date'] ?? null;
            $current_year['reopening_date'] = null;
        }
    } catch (PDOException $e2) {
        // Neither table works, continue without current year
    }
}

// Get all academic years
$academic_years = [];
try {
    $stmt = $db->prepare("SELECT * FROM academic_years WHERE school_id = ? ORDER BY year_name DESC");
    $stmt->execute([$school_id]);
    $academic_years = $stmt->fetchAll();
} catch (PDOException $e) {
    // If academic_years doesn't exist, get unique session years from terms
    try {
        $stmt = $db->prepare("SELECT DISTINCT session_year as year_name, MAX(is_current) as is_current FROM terms WHERE school_id = ? GROUP BY session_year ORDER BY session_year DESC");
        $stmt->execute([$school_id]);
        $academic_years = $stmt->fetchAll();
    } catch (PDOException $e2) {
        // No terms either
    }
}

// Get classes
$stmt = $db->prepare("SELECT c.*, cp.next_class_id, cp.is_final_class, cp.class_order FROM classes c LEFT JOIN class_progression cp ON c.class_id = cp.current_class_id AND c.school_id = cp.school_id WHERE c.school_id = ? ORDER BY COALESCE(cp.class_order, 0), c.class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get all terms for the school
$stmt = $db->prepare("SELECT term_id, term_name, session_year, is_current FROM terms WHERE school_id = ? ORDER BY session_year DESC, term_id ASC");
$stmt->execute([$school_id]);
$terms = $stmt->fetchAll();

// Get promotion history
$stmt = $db->prepare("
    SELECT sp.*, u.first_name, u.last_name, s.admission_number,
           c1.class_name as from_class_name, c2.class_name as to_class_name
    FROM student_promotions sp
    INNER JOIN students s ON sp.student_id = s.student_id
    INNER JOIN users u ON s.user_id = u.user_id
    LEFT JOIN classes c1 ON sp.from_class_id = c1.class_id
    LEFT JOIN classes c2 ON sp.to_class_id = c2.class_id
    WHERE sp.school_id = ?
    ORDER BY sp.created_at DESC
    LIMIT 50
");
$stmt->execute([$school_id]);
$promotion_history = $stmt->fetchAll();

// Get promotion statistics for current year
$promotion_stats = [
    'total' => 0,
    'promoted' => 0,
    'repeated' => 0,
    'graduated' => 0,
    'avg_score' => 0
];

if ($current_year && isset($current_year['year_name'])) {
    try {
        $stmt = $db->prepare("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN promotion_type = 'promoted' THEN 1 ELSE 0 END) as promoted,
                SUM(CASE WHEN promotion_type = 'repeated' THEN 1 ELSE 0 END) as repeated,
                SUM(CASE WHEN promotion_type = 'graduated' THEN 1 ELSE 0 END) as graduated,
                ROUND(AVG(annual_average), 2) as avg_score
            FROM student_promotions
            WHERE school_id = ? AND academic_year = ?
        ");
        $stmt->execute([$school_id, $current_year['year_name']]);
        $stats = $stmt->fetch();
        if ($stats) {
            $promotion_stats = $stats;
        }
    } catch (PDOException $e) {
        // Stats not available
    }
}

/**
 * Calculate student performance for promotion decision
 * UPDATED: Now considers entry term and optional specific term selection:
 * - If specific term selected: Uses only that term
 * - Term 1 entry: Uses T1 + T2 + T3 (÷3)
 * - Term 2 entry: Uses T2 + T3 (÷2)
 * - Term 3 entry: Uses T3 only (÷1)
 */
function calculateStudentPerformance($db, $student_id, $academic_year, $entry_term, $specific_term_id = null) {
    // If a specific term is selected, use only that term
    if ($specific_term_id) {
        $stmt = $db->prepare("
            SELECT 
                sa.student_id,
                sa.term_id,
                t.term_name,
                SUM(sa.total_score) as term_total,
                COUNT(DISTINCT sa.subject_id) as subjects_count
            FROM student_assessments sa
            INNER JOIN terms t ON sa.term_id = t.term_id
            WHERE sa.student_id = ? 
            AND sa.term_id = ?
            GROUP BY sa.term_id
        ");
        $stmt->execute([$student_id, $specific_term_id]);
        $term_results = $stmt->fetchAll();
        
        if (empty($term_results)) {
            return [
                'annual_total' => 0,
                'annual_average' => 0,
                'terms_completed' => 0,
                'entry_term' => $entry_term,
                'terms_used' => [],
                'calculation_basis' => 'Selected Term Only',
                'divisor' => 1
            ];
        }
        
        $term_total = $term_results[0]['term_total'];
        
        return [
            'annual_total' => $term_total,
            'annual_average' => $term_total,
            'terms_completed' => 1,
            'entry_term' => $entry_term,
            'terms_used' => [[
                'term_name' => $term_results[0]['term_name'],
                'term_total' => $term_total,
                'subjects_count' => $term_results[0]['subjects_count']
            ]],
            'calculation_basis' => 'Selected Term: ' . $term_results[0]['term_name'],
            'divisor' => 1
        ];
    }
    
    // Otherwise, use entry-term based calculation
    // Determine which terms to include based on entry term
    // Map entry term number to term names
    $term_names = [];
    $divisor = 1;
    
    if ($entry_term == 1) {
        // Student admitted in Term 1 - use all three terms
        $term_names = ['First Term', 'Second Term', 'Third Term'];
        $divisor = 3;
    } elseif ($entry_term == 2) {
        // Student admitted in Term 2 - use only Term 2 and 3
        $term_names = ['Second Term', 'Third Term'];
        $divisor = 2;
    } else {
        // Student admitted in Term 3 - use only Term 3
        $term_names = ['Third Term'];
        $divisor = 1;
    }
    
    // Build IN clause for term names
    $placeholders = str_repeat('?,', count($term_names) - 1) . '?';
    
    // Get marks from student_assessments table (CA + Midterm + Exam)
    $stmt = $db->prepare("
        SELECT 
            sa.student_id,
            sa.term_id,
            t.term_name,
            SUM(sa.total_score) as term_total,
            COUNT(DISTINCT sa.subject_id) as subjects_count
        FROM student_assessments sa
        INNER JOIN terms t ON sa.term_id = t.term_id
        WHERE sa.student_id = ? 
        AND t.session_year = ?
        AND t.term_name IN ({$placeholders})
        GROUP BY sa.term_id, t.term_name
        ORDER BY 
            CASE t.term_name
                WHEN 'First Term' THEN 1
                WHEN 'Second Term' THEN 2
                WHEN 'Third Term' THEN 3
            END
    ");
    $params = array_merge([$student_id, $academic_year], $term_names);
    $stmt->execute($params);
    $term_results = $stmt->fetchAll();
    
    if (empty($term_results)) {
        return [
            'annual_total' => 0,
            'annual_average' => 0,
            'terms_completed' => 0,
            'entry_term' => $entry_term,
            'terms_used' => [],
            'calculation_basis' => get_calculation_basis_text($entry_term)
        ];
    }
    
    // Calculate annual total and average
    $annual_total = 0;
    $terms_completed = 0;
    $terms_used = [];
    
    foreach ($term_results as $result) {
        $annual_total += $result['term_total'];
        $terms_completed++;
        $terms_used[] = [
            'term_name' => $result['term_name'],
            'term_total' => $result['term_total'],
            'subjects_count' => $result['subjects_count']
        ];
    }
    
    // Calculate average based on number of terms the student should have
    $annual_average = $terms_completed > 0 ? round($annual_total / $divisor, 2) : 0;
    
    return [
        'annual_total' => $annual_total,
        'annual_average' => $annual_average,
        'terms_completed' => $terms_completed,
        'entry_term' => $entry_term,
        'terms_used' => $terms_used,
        'calculation_basis' => get_calculation_basis_text($entry_term),
        'divisor' => $divisor
    ];
}

/**
 * Get human-readable calculation basis text
 */
function get_calculation_basis_text($entry_term) {
    if ($entry_term == 1) {
        return 'All 3 terms (T1 + T2 + T3 ÷ 3)';
    } elseif ($entry_term == 2) {
        return 'Term 2 & 3 only (T2 + T3 ÷ 2)';
    } else {
        return 'Term 3 only (T3 ÷ 1)';
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fas fa-user-graduate"></i>  Student Promotion System</h1>
    </div>

    <div class="page-header">
        
        <p>Promote or repeat students based on academic performance</p>
    </div>
    
    <?php if (empty($current_year)): ?>
        <div class="alert alert-warning">
            <h3><i class="fas fa-exclamation-triangle"></i> No Active Academic Year</h3>
            <p>Please create an academic year and terms first before promoting students.</p>
            <a href="<?php echo APP_URL; ?>/admin/terms.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Manage Academic Terms
            </a>
        </div>
    <?php else: ?>
    
    <!-- Current Academic Year Info -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 15px 0; color: white;"><i class="fas fa-calendar-alt"></i> Current Academic Year</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                <div>
                    <div style="font-size: 14px; opacity: 0.9;">Academic Year</div>
                    <div style="font-size: 24px; font-weight: 700;"><?php echo htmlspecialchars($current_year['year_name']); ?></div>
                </div>
                <div>
                    <div style="font-size: 14px; opacity: 0.9;">Vacation Date</div>
                    <div style="font-size: 18px; font-weight: 600;">
                        <?php echo $current_year['vacation_start'] ? date('M d, Y', strtotime($current_year['vacation_start'])) : 'Not Set'; ?>
                    </div>
                </div>
                <div>
                    <div style="font-size: 14px; opacity: 0.9;">Reopening Date</div>
                    <div style="font-size: 18px; font-weight: 600;">
                        <?php echo $current_year['reopening_date'] ? date('M d, Y', strtotime($current_year['reopening_date'])) : 'Not Set'; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Promotion Statistics Dashboard -->
    <?php if ($promotion_stats['total'] > 0): ?>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="card" style="background: linear-gradient(135deg, #10B981 0%, #059669 100%); color: white; text-align: center;">
            <div style="padding: 20px;">
                <i class="fas fa-arrow-up" style="font-size: 32px; opacity: 0.8; margin-bottom: 10px;"></i>
                <div style="font-size: 36px; font-weight: 700;"><?php echo number_format($promotion_stats['promoted']); ?></div>
                <div style="font-size: 14px; opacity: 0.9; margin-top: 5px;">Promoted</div>
            </div>
        </div>
        
        <div class="card" style="background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%); color: white; text-align: center;">
            <div style="padding: 20px;">
                <i class="fas fa-redo" style="font-size: 32px; opacity: 0.8; margin-bottom: 10px;"></i>
                <div style="font-size: 36px; font-weight: 700;"><?php echo number_format($promotion_stats['repeated']); ?></div>
                <div style="font-size: 14px; opacity: 0.9; margin-top: 5px;">Repeated</div>
            </div>
        </div>
        
        <div class="card" style="background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%); color: white; text-align: center;">
            <div style="padding: 20px;">
                <i class="fas fa-graduation-cap" style="font-size: 32px; opacity: 0.8; margin-bottom: 10px;"></i>
                <div style="font-size: 36px; font-weight: 700;"><?php echo number_format($promotion_stats['graduated']); ?></div>
                <div style="font-size: 14px; opacity: 0.9; margin-top: 5px;">Graduated</div>
            </div>
        </div>
        
        <div class="card" style="background: linear-gradient(135deg, #F59E0B 0%, #D97706 100%); color: white; text-align: center;">
            <div style="padding: 20px;">
                <i class="fas fa-chart-line" style="font-size: 32px; opacity: 0.8; margin-bottom: 10px;"></i>
                <div style="font-size: 36px; font-weight: 700;"><?php echo number_format($promotion_stats['avg_score'], 1); ?>%</div>
                <div style="font-size: 14px; opacity: 0.9; margin-top: 5px;">Average Score</div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Promotion Form -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-graduation-cap"></i> Process Class Promotion</h3>
        </div>
        <div class="card-body">
            <form method="POST" onsubmit="return confirm('Process promotion for all students in this class? This will evaluate each student performance and promote or repeat accordingly.');">
                <input type="hidden" name="action" value="promote_students">
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 20px;">
                    <div class="form-group">
                        <label>Academic Year *</label>
                        <select name="academic_year" id="academicYear" required onchange="loadTermsForYear(this.value)">
                            <option value="">Select Year</option>
                            <?php foreach ($academic_years as $year): ?>
                                <option value="<?php echo htmlspecialchars($year['year_name']); ?>" <?php echo $year['is_current'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($year['year_name']); ?>
                                    <?php echo $year['is_current'] ? ' (Current)' : ''; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Select Term (Optional)</label>
                        <select name="term_id" id="termSelect">
                            <option value="">Use Student's Entry Term</option>
                            <?php 
                            $current_year_name = $current_year['year_name'] ?? '';
                            foreach ($terms as $term): 
                            ?>
                                <option value="<?php echo $term['term_id']; ?>" 
                                        data-year="<?php echo htmlspecialchars($term['session_year']); ?>"
                                        <?php echo ($term['session_year'] == $current_year_name) ? '' : 'style="display:none;"'; ?>>
                                    <?php echo htmlspecialchars($term['term_name']); ?> 
                                    (<?php echo htmlspecialchars($term['session_year']); ?>)
                                    <?php echo $term['is_current'] ? ' - Current' : ''; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small style="color: var(--text-secondary);">Leave empty to use automatic calculation based on each student's entry term</small>
                    </div>
                    
                    <div class="form-group">
                        <label>From Class *</label>
                        <select name="from_class_id" id="fromClass" required onchange="updateToClass(this.value)">
                            <option value="">Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>" 
                                        data-next="<?php echo $class['next_class_id'] ?? ''; ?>"
                                        data-final="<?php echo $class['is_final_class'] ?? 0; ?>">
                                    <?php echo htmlspecialchars($class['class_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>To Class (Next Level)</label>
                        <select name="to_class_id" id="toClass">
                            <option value="">-- Will Auto-Select --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>">
                                    <?php echo htmlspecialchars($class['class_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small style="color: var(--text-secondary);">Leave empty for final class (graduation)</small>
                    </div>
                    
                    <div class="form-group">
                        <label>Pass Mark (%)</label>
                        <input type="number" name="pass_mark" value="50" step="0.01" min="0" max="100" required>
                        <small style="color: var(--text-secondary);">Students below this will repeat</small>
                    </div>
                </div>
                
                <div style="background: #F3F4F6; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <h4 style="margin: 0 0 10px 0;"><i class="fas fa-info-circle"></i> How It Works:</h4>
                    <ul style="margin: 0; padding-left: 20px; line-height: 1.8;">
                        <li>System calculates each student's average score from their entry term to end of year</li>
                        <li>Students starting <strong>Term 1</strong>: All 3 terms evaluated</li>
                        <li>Students starting <strong>Term 2</strong>: Terms 2 & 3 evaluated</li>
                        <li>Students starting <strong>Term 3</strong>: Only Term 3 evaluated</li>
                        <li>If average ≥ Pass Mark: <strong style="color: #10B981;">PROMOTED</strong> to next class</li>
                        <li>If average < Pass Mark: <strong style="color: #EF4444;">REPEATED</strong> (stays in same class)</li>
                        <li>Final class students: <strong style="color: #3B82F6;">GRADUATED</strong></li>
                    </ul>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    <i class="fas fa-graduation-cap"></i> Process Promotion for Selected Class
                </button>
            </form>
        </div>
    </div>
    
    <!-- Promotion History -->
    <div class="card" style="margin-top: 30px;">
        <div class=\"card-header\">
            <h3><i class=\"fas fa-history\"></i> Recent Promotion History</h3>
        </div>
        <div class=\"card-body\">
            <?php if (count($promotion_history) > 0): ?>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Student</th>
                                <th>Year</th>
                                <th>From Class</th>
                                <th>To Class</th>
                                <th>Decision</th>
                                <th>Average</th>
                                <th>Terms</th>
                                <th>Reason</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($promotion_history as $p): ?>
                                <tr>
                                    <td><?php echo date('M d, Y', strtotime($p['promotion_date'])); ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($p['first_name'] . ' ' . $p['last_name']); ?></strong>
                                        <br><small><?php echo htmlspecialchars($p['admission_number'] ?? ''); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($p['academic_year']); ?></td>
                                    <td><?php echo htmlspecialchars($p['from_class_name'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($p['to_class_name'] ?? '-'); ?></td>
                                    <td>
                                        <?php if ($p['promotion_type'] == 'promoted'): ?>
                                            <span class="badge" style="background: #10B981; color: white;">
                                                <i class="fas fa-arrow-up"></i> Promoted
                                            </span>
                                        <?php elseif ($p['promotion_type'] == 'repeated'): ?>
                                            <span class="badge" style="background: #EF4444; color: white;">
                                                <i class="fas fa-redo"></i> Repeated
                                            </span>
                                        <?php else: ?>
                                            <span class="badge" style="background: #3B82F6; color: white;">
                                                <i class="fas fa-graduation-cap"></i> Graduated
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td><strong><?php echo number_format($p['annual_average'] ?? 0, 2); ?>%</strong></td>
                                    <td><?php echo $p['terms_completed'] ?? 0; ?> term(s)</td>
                                    <td><small><?php echo htmlspecialchars($p['decision_reason'] ?? ''); ?></small></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 60px;">
                    <i class="fas fa-inbox" style="font-size: 64px; color: var(--text-secondary); opacity: 0.3; margin-bottom: 20px;"></i>
                    <h3 style="color: var(--text-secondary);">No Promotion History</h3>
                    <p style="color: var(--text-secondary);">Promotions will appear here after processing</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php endif; ?>
    
    <script>
    function loadTermsForYear(yearName) {
        const termSelect = document.getElementById('termSelect');
        const options = termSelect.querySelectorAll('option');
        
        // Show/hide terms based on selected year
        options.forEach(option => {
            if (option.value === '') {
                option.style.display = 'block'; // Always show "Use Student's Entry Term"
            } else {
                const termYear = option.dataset.year;
                option.style.display = (termYear === yearName) ? 'block' : 'none';
            }
        });
        
        // Reset selection if current selection is hidden
        if (termSelect.selectedIndex > 0 && termSelect.options[termSelect.selectedIndex].style.display === 'none') {
            termSelect.selectedIndex = 0;
        }
    }
    
    function updateToClass(fromClassId) {
        const fromClass = document.querySelector(`#fromClass option[value=\"${fromClassId}\"]`);
        const toClassSelect = document.getElementById('toClass');
        
        if (fromClass) {
            const nextClassId = fromClass.dataset.next;
            const isFinal = fromClass.dataset.final == '1';
            
            if (isFinal) {
                toClassSelect.value = '';
                toClassSelect.disabled = true;
                alert('This is a final class. Students will be marked as GRADUATED.');
            } else if (nextClassId) {
                toClassSelect.value = nextClassId;
                toClassSelect.disabled = false;
            } else {
                toClassSelect.value = '';
                toClassSelect.disabled = false;
            }
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
