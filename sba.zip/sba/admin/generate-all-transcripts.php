<?php
// admin/generate-all-transcripts.php - Generate Transcripts for All Students in a Class
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['admin']);
$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Auto-create student_assessments table if it doesn't exist
try {
    $db->query("SELECT 1 FROM student_assessments LIMIT 1");
} catch (PDOException $e) {
    try {
        $sql = "CREATE TABLE IF NOT EXISTS `student_assessments` (
          `assessment_id` int(11) NOT NULL AUTO_INCREMENT,
          `school_id` int(11) NOT NULL,
          `student_id` int(11) NOT NULL,
          `class_id` int(11) NOT NULL,
          `subject_id` int(11) NOT NULL,
          `term_id` int(11) NOT NULL,
          `teacher_id` int(11),
          `ca_score` decimal(5,2) DEFAULT 0,
          `midterm_score` decimal(5,2) DEFAULT 0,
          `exam_score` decimal(5,2) DEFAULT 0,
          `total_score` decimal(5,2) DEFAULT 0,
          `grade` varchar(10),
          `remark` varchar(255),
          `position` int(11),
          `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`assessment_id`),
          KEY `school_id` (`school_id`),
          KEY `student_id` (`student_id`),
          KEY `class_id` (`class_id`),
          KEY `subject_id` (`subject_id`),
          KEY `term_id` (`term_id`),
          KEY `teacher_id` (`teacher_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        $db->exec($sql);
    } catch (PDOException $e) {
        // Table creation failed
    }
}

$class_id = (int)($_GET['class_id'] ?? 0);

if ($class_id == 0) {
    die('Class ID is required');
}

// Get class info
$stmt = $db->prepare("SELECT * FROM classes WHERE class_id = ? AND school_id = ?");
$stmt->execute([$class_id, $school_id]);
$class_info = $stmt->fetch();

if (!$class_info) {
    die('Class not found');
}

// Get school info
$stmt = $db->prepare("SELECT * FROM schools WHERE school_id = ?");
$stmt->execute([$school_id]);
$school_info = $stmt->fetch();

// Get all students in class
try {
    $stmt = $db->prepare("
        SELECT s.*, COALESCE(u.first_name, '-') as first_name, COALESCE(u.last_name, '') as last_name
        FROM students s
        LEFT JOIN users u ON s.user_id = u.user_id
        WHERE s.class_id = ? AND s.school_id = ?
        ORDER BY s.admission_number
    ");
    $stmt->execute([$class_id, $school_id]);
    $students = $stmt->fetchAll();
} catch (PDOException $e) {
    $students = [];
}

if (count($students) == 0) {
    die('No students found in this class');
}

// Function to get student transcript data
function getStudentTranscript($db, $student_id, $school_id) {
    try {
        $stmt = $db->prepare("
            SELECT 
                c.class_name,
                t.term_name,
                t.start_date,
                s.subject_name,
                sa.total_score,
                sa.grade,
                sa.remark
            FROM student_assessments sa
            JOIN classes c ON sa.class_id = c.class_id
            JOIN terms t ON sa.term_id = t.term_id
            JOIN subjects s ON sa.subject_id = s.subject_id
            WHERE sa.student_id = ? AND sa.school_id = ?
            ORDER BY c.class_name, t.start_date, s.subject_name
        ");
        $stmt->execute([$student_id, $school_id]);
        $all_results = $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
    
    // Group results by class and term
    $transcript = [];
    foreach ($all_results as $result) {
        $class = $result['class_name'];
        $term = $result['term_name'];
        
        if (!isset($transcript[$class])) {
            $transcript[$class] = [];
        }
        
        if (!isset($transcript[$class][$term])) {
            $transcript[$class][$term] = [];
        }
        
        $transcript[$class][$term][] = [
            'subject' => $result['subject_name'],
            'score' => $result['total_score'],
            'grade' => $result['grade']
        ];
    }
    
    return $transcript;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class Transcripts - <?php echo $class_info['class_name']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            background: white;
        }
        
        .transcript-page {
            page-break-after: always;
            padding: 20mm;
        }
        
        .transcript-page:last-child {
            page-break-after: auto;
        }
        
        .header {
            text-align: center;
            border-bottom: 3px solid #333;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .school-logo {
            width: 100px;
            height: 100px;
            object-fit: contain;
            margin-bottom: 10px;
        }
        
        .school-name {
            font-size: 28px;
            font-weight: bold;
            color: #2196F3;
            margin-bottom: 5px;
        }
        
        .transcript-title {
            font-size: 24px;
            font-weight: bold;
            margin: 10px 0;
            text-transform: uppercase;
            color: #333;
        }
        
        .student-info {
            background: #f5f5f5;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        
        .student-info p {
            margin: 8px 0;
            font-size: 14px;
        }
        
        .student-info strong {
            display: inline-block;
            min-width: 150px;
        }
        
        .class-section {
            margin-bottom: 30px;
        }
        
        .class-title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;
            padding: 10px;
            background: #2196F3;
            color: white;
            border-radius: 5px;
        }
        
        .term-section {
            margin-bottom: 20px;
        }
        
        .term-title {
            font-size: 15px;
            font-weight: bold;
            margin-bottom: 10px;
            color: #2196F3;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            font-size: 13px;
        }
        
        th {
            background: #f0f0f0;
            font-weight: bold;
            padding: 8px;
            text-align: left;
            border: 1px solid #333;
        }
        
        td {
            border: 1px solid #333;
            padding: 6px;
        }
        
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        
        .text-center {
            text-align: center;
        }
        
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 15px;
            border-top: 2px solid #ddd;
            color: #666;
            font-size: 11px;
        }
        
        @media print {
            @page {
                size: A4;
                margin: 15mm;
            }
            
            body {
                padding: 0;
            }
            
            .no-print {
                display: none;
            }
            
            .transcript-page {
                page-break-after: always;
            }
            
            .transcript-page:last-child {
                page-break-after: auto;
            }
        }
    </style>
</head>
<body>
    <?php foreach ($students as $index => $student): ?>
        <?php $transcript = getStudentTranscript($db, $student['student_id'], $school_id); ?>
        
        <div class="transcript-page">
            <!-- Header -->
            <div class="header">
                <?php if (!empty($school_info['logo'])): ?>
                    <img src="<?php echo APP_URL . '/uploads/logos/' . $school_info['logo']; ?>" 
                         alt="School Logo" class="school-logo">
                <?php endif; ?>
                <div class="school-name"><?php echo strtoupper($school_info['school_name']); ?></div>
                <div class="transcript-title">Official Transcript</div>
            </div>
            
            <!-- Student Information -->
            <div class="student-info">
                <p><strong>Student Name:</strong> <?php echo $student['first_name'] . ' ' . $student['last_name']; ?></p>
                <p><strong>Admission Number:</strong> <?php echo $student['admission_number']; ?></p>
                <p><strong>Current Class:</strong> <?php echo $class_info['class_name']; ?></p>
                <p><strong>Date Generated:</strong> <?php echo date('F d, Y'); ?></p>
            </div>
            
            <?php if (count($transcript) > 0): ?>
                <?php foreach ($transcript as $class_name => $terms): ?>
                    <div class="class-section">
                        <div class="class-title"><?php echo strtoupper($class_name); ?></div>
                        
                        <?php foreach ($terms as $term_name => $subjects): ?>
                            <div class="term-section">
                                <div class="term-title"><?php echo $term_name; ?></div>
                                
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Subject</th>
                                            <th class="text-center" style="width: 100px;">Score</th>
                                            <th class="text-center" style="width: 80px;">Grade</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($subjects as $subject): ?>
                                            <tr>
                                                <td><?php echo $subject['subject']; ?></td>
                                                <td class="text-center"><?php echo number_format($subject['score'], 1); ?></td>
                                                <td class="text-center"><?php echo $subject['grade']; ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 40px;">
                    <p style="font-size: 16px; color: #666;">No assessment records found for this student.</p>
                </div>
            <?php endif; ?>
            
            <!-- Footer -->
            <div class="footer">
                <p>This is an official transcript generated on <?php echo date('F d, Y \a\t h:i A'); ?></p>
                <p><?php echo $school_info['school_name']; ?></p>
            </div>
        </div>
    <?php endforeach; ?>
    
    <div class="no-print" style="text-align: center; padding: 30px; position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); background: white; box-shadow: 0 0 20px rgba(0,0,0,0.2); border-radius: 10px;">
        <p style="margin-bottom: 15px; font-size: 16px; font-weight: bold;">
            Generated <?php echo count($students); ?> transcripts for <?php echo $class_info['class_name']; ?>
        </p>
        <button onclick="window.print()" style="padding: 12px 30px; background: #2196F3; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; margin-right: 10px;">
            <i class="fas fa-print"></i> Print All
        </button>
        <button onclick="window.close()" style="padding: 12px 30px; background: #666; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px;">
            Close
        </button>
    </div>
</body>
</html>
