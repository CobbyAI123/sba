<?php
// admin/canteen-fees.php - Manage Class-Based Canteen Fees
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Canteen Fee Structure';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get current academic year and term
$stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_current = 1 LIMIT 1");
$stmt->execute([$school_id]);
$current_term = $stmt->fetch();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add' || $action == 'edit') {
            $class_id = intval($_POST['class_id']);
            $daily_fee = floatval($_POST['daily_fee']);
            $academic_year = sanitize_input($_POST['academic_year']);
            $term_id = !empty($_POST['term_id']) ? intval($_POST['term_id']) : null;
            $description = sanitize_input($_POST['description']);
            
            try {
                if ($action == 'add') {
                    $stmt = $db->prepare("
                        INSERT INTO canteen_fee_structure (school_id, class_id, daily_fee, academic_year, term_id, description, created_by)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$school_id, $class_id, $daily_fee, $academic_year, $term_id, $description, $current_user['user_id']]);
                    set_message('success', 'Canteen fee structure added successfully!');
                } else {
                    $canteen_fee_id = intval($_POST['canteen_fee_id']);
                    $status = sanitize_input($_POST['status']);
                    $stmt = $db->prepare("
                        UPDATE canteen_fee_structure 
                        SET class_id = ?, daily_fee = ?, academic_year = ?, term_id = ?, description = ?, status = ?
                        WHERE canteen_fee_id = ? AND school_id = ?
                    ");
                    $stmt->execute([$class_id, $daily_fee, $academic_year, $term_id, $description, $status, $canteen_fee_id, $school_id]);
                    set_message('success', 'Canteen fee structure updated successfully!');
                }
            } catch (PDOException $e) {
                set_message('error', 'Error: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/canteen-fees.php');
        }
        
        if ($action == 'delete') {
            $canteen_fee_id = intval($_POST['canteen_fee_id']);
            try {
                // Check if there are any daily collection records for this class
                $stmt = $db->prepare("
                    SELECT COUNT(*) as count
                    FROM daily_collections dc
                    INNER JOIN canteen_fee_structure cfs ON dc.class_id = cfs.class_id
                    WHERE cfs.canteen_fee_id = ? AND dc.canteen_paid = 1
                ");
                $stmt->execute([$canteen_fee_id]);
                $result = $stmt->fetch();
                
                if ($result['count'] > 0) {
                    set_message('error', "Cannot delete: {$result['count']} payment record(s) exist for this canteen fee. Consider marking it as inactive instead.");
                } else {
                    // Safe to delete
                    $stmt = $db->prepare("DELETE FROM canteen_fee_structure WHERE canteen_fee_id = ? AND school_id = ?");
                    $stmt->execute([$canteen_fee_id, $school_id]);
                    
                    log_activity($current_user['user_id'], "Deleted canteen fee structure ID: $canteen_fee_id", 'canteen_fee_structure', $canteen_fee_id);
                    set_message('success', 'Canteen fee deleted successfully!');
                }
            } catch (PDOException $e) {
                set_message('error', 'Error deleting fee: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/canteen-fees.php');
        }
    }
}

// Get all canteen fees with class info
$stmt = $db->prepare("
    SELECT 
        cfs.*,
        c.class_name,
        t.term_name,
        COUNT(DISTINCT s.student_id) as student_count
    FROM canteen_fee_structure cfs
    INNER JOIN classes c ON cfs.class_id = c.class_id
    LEFT JOIN terms t ON cfs.term_id = t.term_id
    LEFT JOIN students s ON c.class_id = s.class_id AND s.exempt_canteen = 0
    WHERE cfs.school_id = ?
    GROUP BY cfs.canteen_fee_id
    ORDER BY c.class_name
");
$stmt->execute([$school_id]);
$canteen_fees = $stmt->fetchAll();

// Get all classes
$stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get all terms
$stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY start_date DESC");
$stmt->execute([$school_id]);
$terms = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-utensils"></i> Canteen Fee Structure</h3>
            <button onclick="openAddModal()" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add Canteen Fee
            </button>
        </div>
        
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Class</th>
                        <th>Daily Fee</th>
                        <th>Academic Year</th>
                        <th>Term</th>
                        <th>Students</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($canteen_fees) > 0): ?>
                        <?php foreach ($canteen_fees as $fee): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($fee['class_name']); ?></strong></td>
                                <td><strong><?php echo format_currency($fee['daily_fee']); ?></strong></td>
                                <td><?php echo htmlspecialchars($fee['academic_year']); ?></td>
                                <td><?php echo htmlspecialchars($fee['term_name'] ?? 'All Terms'); ?></td>
                                <td><span class="badge badge-info"><?php echo $fee['student_count']; ?> students</span></td>
                                <td>
                                    <span class="badge badge-<?php echo $fee['status'] == 'active' ? 'success' : 'secondary'; ?>">
                                        <?php echo ucfirst($fee['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button onclick='openEditModal(<?php echo json_encode($fee); ?>)' class="btn btn-sm btn-info">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="confirmDelete(<?php echo $fee['canteen_fee_id']; ?>, '<?php echo htmlspecialchars($fee['class_name']); ?>')" 
                                            class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 40px;">
                                <i class="fas fa-utensils" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 10px; display: block;"></i>
                                <h3>No Canteen Fees Set</h3>
                                <p style="color: var(--text-secondary);">Click "Add Canteen Fee" to get started</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-plus"></i> Add Canteen Fee</h3>
                <span class="close" onclick="closeAddModal()">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label>Class <span style="color: red;">*</span></label>
                    <select name="class_id" class="form-control" required>
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>">
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Daily Canteen Fee (₵) <span style="color: red;">*</span></label>
                    <input type="number" step="0.01" name="daily_fee" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Academic Year <span style="color: red;">*</span></label>
                    <input type="text" name="academic_year" class="form-control" 
                           value="<?php echo $current_term['session_year'] ?? date('Y') . '/' . (date('Y') + 1); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Term (Optional - Leave blank for all terms)</label>
                    <select name="term_id" class="form-control">
                        <option value="">All Terms</option>
                        <?php foreach ($terms as $term): ?>
                            <option value="<?php echo $term['term_id']; ?>" <?php echo ($current_term && $term['term_id'] == $current_term['term_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($term['term_name'] . ' - ' . $term['session_year']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="2" placeholder="Optional notes"></textarea>
                </div>
                
                <div style="text-align: right; margin-top: 20px;">
                    <button type="button" onclick="closeAddModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit Canteen Fee</h3>
                <span class="close" onclick="closeEditModal()">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="canteen_fee_id" id="edit_canteen_fee_id">
                
                <div class="form-group">
                    <label>Class <span style="color: red;">*</span></label>
                    <select name="class_id" id="edit_class_id" class="form-control" required>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>">
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Daily Canteen Fee (₵) <span style="color: red;">*</span></label>
                    <input type="number" step="0.01" name="daily_fee" id="edit_daily_fee" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Academic Year <span style="color: red;">*</span></label>
                    <input type="text" name="academic_year" id="edit_academic_year" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Term</label>
                    <select name="term_id" id="edit_term_id" class="form-control">
                        <option value="">All Terms</option>
                        <?php foreach ($terms as $term): ?>
                            <option value="<?php echo $term['term_id']; ?>">
                                <?php echo htmlspecialchars($term['term_name'] . ' - ' . $term['session_year']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" id="edit_description" class="form-control" rows="2"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" id="edit_status" class="form-control">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                
                <div style="text-align: right; margin-top: 20px;">
                    <button type="button" onclick="closeEditModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <form method="POST" id="deleteForm" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="canteen_fee_id" id="delete_canteen_fee_id">
    </form>
    
    <style>
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        overflow-y: auto;
    }
    
    .modal-content {
        background: var(--card-bg);
        margin: 50px auto;
        padding: 30px;
        width: 90%;
        max-width: 600px;
        border-radius: 10px;
    }
    
    .modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 2px solid var(--border-color);
    }
    
    .close {
        font-size: 28px;
        cursor: pointer;
    }
    </style>
    
    <script>
    function openAddModal() {
        document.getElementById('addModal').style.display = 'block';
    }
    
    function closeAddModal() {
        document.getElementById('addModal').style.display = 'none';
    }
    
    function openEditModal(fee) {
        document.getElementById('edit_canteen_fee_id').value = fee.canteen_fee_id;
        document.getElementById('edit_class_id').value = fee.class_id;
        document.getElementById('edit_daily_fee').value = fee.daily_fee;
        document.getElementById('edit_academic_year').value = fee.academic_year;
        document.getElementById('edit_term_id').value = fee.term_id || '';
        document.getElementById('edit_description').value = fee.description || '';
        document.getElementById('edit_status').value = fee.status;
        document.getElementById('editModal').style.display = 'block';
    }
    
    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
    }
    
    function confirmDelete(id, className) {
        if (confirm(`Are you sure you want to delete canteen fee for "${className}"?`)) {
            document.getElementById('delete_canteen_fee_id').value = id;
            document.getElementById('deleteForm').submit();
        }
    }
    
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
