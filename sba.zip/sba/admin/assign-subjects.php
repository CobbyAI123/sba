<?php
// admin/assign-subjects.php - Assign Subjects to Classes and Teachers
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Assign Subjects to Teachers';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'assign') {
            $class_id = sanitize_input($_POST['class_id']);
            $subject_id = sanitize_input($_POST['subject_id']);
            $teacher_id = sanitize_input($_POST['teacher_id']);
            
            try {
                // Check if assignment already exists
                try {
                    $stmt = $db->prepare("
                        SELECT id FROM class_subjects 
                        WHERE class_id = ? AND subject_id = ?
                    ");
                    $stmt->execute([$class_id, $subject_id]);
                    $existing = $stmt->fetch();
                } catch (PDOException $e) {
                    // Try with class_subject_id column
                    $stmt = $db->prepare("
                        SELECT class_subject_id FROM class_subjects 
                        WHERE class_id = ? AND subject_id = ?
                    ");
                    $stmt->execute([$class_id, $subject_id]);
                    $existing = $stmt->fetch();
                }
                
                if ($existing) {
                    // Update existing assignment
                    $stmt = $db->prepare("
                        UPDATE class_subjects 
                        SET teacher_id = ? 
                        WHERE class_id = ? AND subject_id = ?
                    ");
                    $stmt->execute([$teacher_id, $class_id, $subject_id]);
                    $message = 'Subject assignment updated successfully!';
                } else {
                    // Create new assignment
                    $stmt = $db->prepare("
                        INSERT INTO class_subjects (class_id, subject_id, teacher_id)
                        VALUES (?, ?, ?)
                    ");
                    $stmt->execute([$class_id, $subject_id, $teacher_id]);
                    $message = 'Subject assigned successfully!';
                }
                
                log_activity($current_user['user_id'], "Assigned subject to class with teacher", 'class_subjects', $db->lastInsertId());
                
                set_message('success', $message);
                redirect(APP_URL . '/admin/assign-subjects.php');
            } catch (PDOException $e) {
                set_message('error', 'Error assigning subject: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            $assignment_id = sanitize_input($_POST['assignment_id']);
            
            try {
                // Try to delete using class_subject_id
                try {
                    $stmt = $db->prepare("DELETE FROM class_subjects WHERE class_subject_id = ?");
                    $stmt->execute([$assignment_id]);
                } catch (PDOException $e) {
                    // Try using id column instead
                    $stmt = $db->prepare("DELETE FROM class_subjects WHERE id = ?");
                    $stmt->execute([$assignment_id]);
                }
                
                log_activity($current_user['user_id'], "Removed subject assignment", 'class_subjects', $assignment_id);
                
                set_message('success', 'Assignment removed successfully!');
                redirect(APP_URL . '/admin/assign-subjects.php');
            } catch (PDOException $e) {
                set_message('error', 'Error removing assignment: ' . $e->getMessage());
            }
        }
    }
}

// Get all classes
$stmt = $db->prepare("
    SELECT class_id, class_name 
    FROM classes 
    WHERE school_id = ? 
    ORDER BY class_name
");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get all subjects
$stmt = $db->prepare("
    SELECT subject_id, subject_name, subject_code 
    FROM subjects 
    WHERE school_id = ? AND status = 'active'
    ORDER BY subject_name
");
$stmt->execute([$school_id]);
$subjects = $stmt->fetchAll();

// Get all teachers
$stmt = $db->prepare("
    SELECT user_id, first_name, last_name, email 
    FROM users 
    WHERE school_id = ? AND role = 'teacher' AND status = 'active'
    ORDER BY first_name, last_name
");
$stmt->execute([$school_id]);
$teachers = $stmt->fetchAll();

// Get all assignments with details
$assignments = [];
try {
    $query = "
        SELECT cs.*,
               c.class_name,
               s.subject_name, s.subject_code,
               u.first_name, u.last_name, u.email
        FROM class_subjects cs
        INNER JOIN classes c ON cs.class_id = c.class_id
        INNER JOIN subjects s ON cs.subject_id = s.subject_id
        LEFT JOIN users u ON cs.teacher_id = u.user_id
        WHERE c.school_id = ?
        ORDER BY c.class_name, s.subject_name
    ";
    
    // Check if class_subject_id exists, if not we can still fetch
    try {
        $db->query("SELECT class_subject_id FROM class_subjects LIMIT 1");
    } catch (PDOException $e) {
        // Fallback without class_subject_id
        $query = "
            SELECT 
                ROW_NUMBER() OVER (ORDER BY c.class_name, s.subject_name) as class_subject_id,
                cs.*,
                c.class_name,
                s.subject_name, s.subject_code,
                u.first_name, u.last_name, u.email
            FROM class_subjects cs
            INNER JOIN classes c ON cs.class_id = c.class_id
            INNER JOIN subjects s ON cs.subject_id = s.subject_id
            LEFT JOIN users u ON cs.teacher_id = u.user_id
            WHERE c.school_id = ?
            ORDER BY c.class_name, s.subject_name
        ";
    }
    
    $stmt = $db->prepare($query);
    $stmt->execute([$school_id]);
    $assignments = $stmt->fetchAll();
} catch (PDOException $e) {
    // class_subjects table may not exist
    $assignments = [];
}

// Group assignments by class
$assignments_by_class = [];
foreach ($assignments as $assignment) {
    $class_key = $assignment['class_name'];
    if (!isset($assignments_by_class[$class_key])) {
        $assignments_by_class[$class_key] = [];
    }
    $assignments_by_class[$class_key][] = $assignment;
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Statistics Cards -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-chalkboard"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo count($classes); ?></h3>
                <p>Total Classes</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-book"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo count($subjects); ?></h3>
                <p>Total Subjects</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-chalkboard-teacher"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo count($teachers); ?></h3>
                <p>Total Teachers</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon orange">
                <i class="fas fa-link"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo count($assignments); ?></h3>
                <p>Total Assignments</p>
            </div>
        </div>
    </div>
    
    <!-- Assign Subject Form -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-plus-circle"></i> Assign Subject to Class</h3>
        </div>
        <div style="padding: 30px;">
            <form method="POST">
                <input type="hidden" name="action" value="assign">
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                    <div class="form-group">
                        <label for="class_id">Select Class *</label>
                        <select name="class_id" id="class_id" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>">
                                    <?php echo $class['class_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
    
                    <div class="form-group">
                        <label for="subject_id">Select Subject *</label>
                        <select name="subject_id" id="subject_id" required>
                            <option value="">-- Select Subject --</option>
                            <?php foreach ($subjects as $subject): ?>
                                <option value="<?php echo $subject['subject_id']; ?>">
                                    <?php echo $subject['subject_name'] . ' (' . $subject['subject_code'] . ')'; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
    
                    <div class="form-group">
                        <label for="teacher_id">Assign Teacher *</label>
                        <select name="teacher_id" id="teacher_id" required>
                            <option value="">-- Select Teacher --</option>
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?php echo $teacher['user_id']; ?>">
                                    <?php echo $teacher['first_name'] . ' ' . $teacher['last_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
    
                    <div class="form-group" style="display: flex; align-items: flex-end;">
                        <button type="submit" class="btn btn-primary" style="width: 100%;">
                            <i class="fas fa-check"></i> Assign Subject
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Current Assignments -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Current Subject Assignments</h3>
        </div>
        <div style="padding: 20px;">
            <?php if (count($assignments_by_class) > 0): ?>
                <?php foreach ($assignments_by_class as $class_name => $class_assignments): ?>
                    <div style="margin-bottom: 30px;">
                        <h4 style="padding: 15px; background: var(--bg-secondary); border-radius: 8px; margin-bottom: 15px;">
                            <i class="fas fa-chalkboard"></i> <?php echo $class_name; ?>
                            <span style="float: right; font-size: 14px; color: var(--text-secondary);">
                                <?php echo count($class_assignments); ?> Subject(s)
                            </span>
                        </h4>
                        
                        <div class="table-responsive">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Subject</th>
                                        <th>Subject Code</th>
                                        <th>Assigned Teacher</th>
                                        <th>Teacher Email</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($class_assignments as $assignment): ?>
                                        <tr>
                                            <td><strong><?php echo $assignment['subject_name']; ?></strong></td>
                                            <td><?php echo $assignment['subject_code']; ?></td>
                                            <td>
                                                <?php if ($assignment['teacher_id']): ?>
                                                    <div style="display: flex; align-items: center; gap: 10px;">
                                                        <div style="width: 35px; height: 35px; border-radius: 8px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600;">
                                                            <?php echo strtoupper(substr($assignment['first_name'], 0, 1) . substr($assignment['last_name'], 0, 1)); ?>
                                                        </div>
                                                        <span><?php echo $assignment['first_name'] . ' ' . $assignment['last_name']; ?></span>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="badge badge-warning">Not Assigned</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if ($assignment['teacher_id']): ?>
                                                    <a href="mailto:<?php echo $assignment['email']; ?>" style="color: var(--primary-blue);">
                                                        <?php echo $assignment['email']; ?>
                                                    </a>
                                                <?php else: ?>
                                                    <span style="color: var(--text-secondary);">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button onclick="editAssignment(<?php echo htmlspecialchars(json_encode($assignment)); ?>)" 
                                                        class="btn btn-info btn-sm">
                                                    <i class="fas fa-edit"></i> Edit
                                                </button>
                                                <button onclick="deleteAssignment(<?php echo $assignment['class_subject_id']; ?>)" 
                                                        class="btn btn-danger btn-sm">
                                                    <i class="fas fa-trash"></i> Remove
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 60px 20px;">
                    <i class="fas fa-link" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
                    <h3 style="margin-bottom: 10px;">No Subject Assignments Yet</h3>
                    <p style="color: var(--text-secondary); margin-bottom: 20px;">
                        Start by assigning subjects to classes and teachers using the form above.
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Info Alert -->
    <div class="alert alert-info" style="margin-top: 30px;">
        <i class="fas fa-info-circle"></i>
        <strong>How it works:</strong> 
        <ul style="margin: 10px 0 0 20px;">
            <li>Select a class, subject, and teacher to create an assignment</li>
            <li>Teachers will see their assigned classes and subjects on their dashboard</li>
            <li>Students in the class will see the assigned teacher for each subject</li>
            <li>You can update or remove assignments anytime</li>
        </ul>
    </div>
    
    <script>
    function editAssignment(assignment) {
        document.getElementById('class_id').value = assignment.class_id;
        document.getElementById('subject_id').value = assignment.subject_id;
        document.getElementById('teacher_id').value = assignment.teacher_id;
        
        // Scroll to form
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        // Highlight form
        const form = document.querySelector('form');
        form.style.border = '2px solid var(--primary-blue)';
        setTimeout(() => {
            form.style.border = 'none';
        }, 2000);
    }
    
    function deleteAssignment(id) {
        if (confirm('Are you sure you want to remove this assignment?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete';
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'assignment_id';
            idInput.value = id;
            
            form.appendChild(actionInput);
            form.appendChild(idInput);
            document.body.appendChild(form);
            form.submit();
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
