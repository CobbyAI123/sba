<?php
// admin/fee-payment-schedule.php - Manage Student Fee Payment Schedule
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Fee Payment Schedule';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action']) && $_POST['action'] == 'update_schedule') {
        $student_id = (int)sanitize_input($_POST['student_id']);
        $canteen_fee_type = sanitize_input($_POST['canteen_fee_type']);
        $bus_fee_type = sanitize_input($_POST['bus_fee_type']);
        
        try {
            $stmt = $db->prepare("
                UPDATE students 
                SET canteen_fee_type = ?, bus_fee_type = ?
                WHERE student_id = ? AND school_id = ?
            ");
            $stmt->execute([$canteen_fee_type, $bus_fee_type, $student_id, $school_id]);
            
            log_activity($current_user['user_id'], "Updated fee payment schedule for student ID: $student_id", 'students', $student_id);
            
            set_message('success', 'Fee payment schedule updated successfully!');
            redirect(APP_URL . '/admin/fee-payment-schedule.php');
        } catch (PDOException $e) {
            set_message('error', 'Error updating schedule: ' . $e->getMessage());
        }
    }
}

// Get all classes for filter
$classes = [];
$stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get selected class filter
$selected_class = isset($_GET['class_id']) ? sanitize_input($_GET['class_id']) : 'all';

// Get students with fee payment schedule
$students = [];
$query = "
    SELECT 
        s.student_id,
        s.admission_number,
        s.first_name,
        s.last_name,
        s.exempt_canteen,
        s.exempt_bus,
        s.canteen_fee_type,
        s.bus_fee_type,
        c.class_name,
        s.photo
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.class_id
    WHERE s.school_id = ? AND s.status = 'active'
";

if ($selected_class != 'all') {
    $query .= " AND s.class_id = ?";
    $stmt = $db->prepare($query . " ORDER BY c.class_name, s.first_name, s.last_name");
    $stmt->execute([$school_id, $selected_class]);
} else {
    $stmt = $db->prepare($query . " ORDER BY c.class_name, s.first_name, s.last_name");
    $stmt->execute([$school_id]);
}
$students = $stmt->fetchAll();

// Get statistics
$stats = [
    'daily' => 0,
    'weekly' => 0,
    'monthly' => 0,
    'exempt' => 0
];

foreach ($students as $student) {
    if ($student['exempt_canteen'] && $student['exempt_bus']) {
        $stats['exempt']++;
    } else {
        if (!$student['exempt_canteen']) {
            if ($student['canteen_fee_type'] == 'weekly') $stats['weekly']++;
            if ($student['canteen_fee_type'] == 'monthly') $stats['monthly']++;
            if ($student['canteen_fee_type'] == 'daily') $stats['daily']++;
        }
        if (!$student['exempt_bus']) {
            if ($student['bus_fee_type'] == 'weekly') $stats['weekly']++;
            if ($student['bus_fee_type'] == 'monthly') $stats['monthly']++;
            if ($student['bus_fee_type'] == 'daily') $stats['daily']++;
        }
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: var(--bg-card);
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            border: 2px solid var(--border-color);
        }
        
        .stat-card.daily { border-color: #2196F3; }
        .stat-card.weekly { border-color: #FF9800; }
        .stat-card.monthly { border-color: #4CAF50; }
        .stat-card.exempt { border-color: #9E9E9E; }
        
        .stat-number {
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .stat-card.daily .stat-number { color: #2196F3; }
        .stat-card.weekly .stat-number { color: #FF9800; }
        .stat-card.monthly .stat-number { color: #4CAF50; }
        .stat-card.exempt .stat-number { color: #9E9E9E; }
        
        .student-table {
            width: 100%;
            border-collapse: collapse;
            background: var(--bg-card);
            border-radius: 12px;
            overflow: hidden;
        }
        
        .student-table th,
        .student-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        .student-table th {
            background: var(--bg-secondary);
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .student-photo {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .student-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-blue);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
        }
        
        .fee-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .fee-badge.daily {
            background: #E3F2FD;
            color: #1976D2;
        }
        
        .fee-badge.weekly {
            background: #FFF3E0;
            color: #F57C00;
        }
        
        .fee-badge.monthly {
            background: #E8F5E9;
            color: #388E3C;
        }
        
        .fee-badge.exempt {
            background: #F5F5F5;
            color: #616161;
        }
        
        .filter-bar {
            display: flex;
            gap: 15px;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .filter-bar select {
            padding: 10px 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            background: var(--bg-card);
            color: var(--text-primary);
            font-size: 14px;
        }
    </style>
    
    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card daily">
            <div class="stat-number"><?php echo $stats['daily']; ?></div>
            <div class="stat-label">Daily Payers</div>
            <small>Pay fees daily</small>
        </div>
        
        <div class="stat-card weekly">
            <div class="stat-number"><?php echo $stats['weekly']; ?></div>
            <div class="stat-label">Weekly Payers</div>
            <small>Pay fees weekly</small>
        </div>
        
        <div class="stat-card monthly">
            <div class="stat-number"><?php echo $stats['monthly']; ?></div>
            <div class="stat-label">Monthly Payers</div>
            <small>Pay fees monthly</small>
        </div>
        
        <div class="stat-card exempt">
            <div class="stat-number"><?php echo $stats['exempt']; ?></div>
            <div class="stat-label">Exempt Students</div>
            <small>Don't pay fees</small>
        </div>
    </div>
    
    <!-- Filter Bar -->
    <div class="filter-bar">
        <label style="font-weight: 600; color: var(--text-secondary);">
            <i class="fas fa-filter"></i> Filter by Class:
        </label>
        <select id="classFilter" onchange="window.location.href='?class_id=' + this.value">
            <option value="all" <?php echo $selected_class == 'all' ? 'selected' : ''; ?>>All Classes</option>
            <?php foreach ($classes as $class): ?>
                <option value="<?php echo $class['class_id']; ?>" <?php echo $selected_class == $class['class_id'] ? 'selected' : ''; ?>>
                    <?php echo $class['class_name']; ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    
    <!-- Students Table -->
    <div class="card" style="margin-top: 20px;">
        <table class="student-table">
            <thead>
                <tr>
                    <th>Photo</th>
                    <th>Student</th>
                    <th>Admission No.</th>
                    <th>Class</th>
                    <th>Canteen Fee</th>
                    <th>Bus Fee</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($students) > 0): ?>
                    <?php foreach ($students as $student): ?>
                        <tr>
                            <td>
                                <?php if (!empty($student['photo'])): ?>
                                    <img src="<?php echo APP_URL . '/uploads/avatars/' . $student['photo']; ?>" 
                                         alt="<?php echo $student['first_name']; ?>" 
                                         class="student-photo">
                                <?php else: ?>
                                    <div class="student-avatar">
                                        <?php echo strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)); ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></strong>
                            </td>
                            <td><?php echo $student['admission_number']; ?></td>
                            <td><?php echo $student['class_name'] ?? 'N/A'; ?></td>
                            <td>
                                <?php if ($student['exempt_canteen']): ?>
                                    <span class="fee-badge exempt">
                                        <i class="fas fa-ban"></i> Exempt
                                    </span>
                                <?php else: ?>
                                    <span class="fee-badge <?php echo $student['canteen_fee_type'] ?? 'daily'; ?>">
                                        <?php echo ucfirst($student['canteen_fee_type'] ?? 'daily'); ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($student['exempt_bus']): ?>
                                    <span class="fee-badge exempt">
                                        <i class="fas fa-ban"></i> Exempt
                                    </span>
                                <?php else: ?>
                                    <span class="fee-badge <?php echo $student['bus_fee_type'] ?? 'daily'; ?>">
                                        <?php echo ucfirst($student['bus_fee_type'] ?? 'daily'); ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-primary" onclick='editSchedule(<?php echo json_encode($student); ?>)'>
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 60px;">
                            <i class="fas fa-user-graduate" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                            <h3 style="margin-bottom: 10px;">No Students Found</h3>
                            <p style="color: var(--text-secondary);">Add students to manage their fee payment schedules.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Edit Schedule Modal -->
    <div id="editScheduleModal" class="modal">
        <div class="modal-content" style="max-width: 500px;">
            <span class="close" onclick="closeEditScheduleModal()">&times;</span>
            <h2 style="margin-bottom: 20px;">
                <i class="fas fa-calendar-alt"></i> Edit Fee Payment Schedule
            </h2>
            
            <form method="POST" action="">
                <input type="hidden" name="action" value="update_schedule">
                <input type="hidden" name="student_id" id="edit_student_id">
                
                <div id="studentInfo" style="background: var(--bg-secondary); padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <p style="margin: 0; font-weight: 600; font-size: 16px;" id="studentName"></p>
                    <p style="margin: 5px 0 0 0; color: var(--text-secondary); font-size: 14px;" id="studentClass"></p>
                </div>
                
                <div class="form-group">
                    <label for="canteen_fee_type">
                        <i class="fas fa-utensils"></i> Canteen Fee Payment
                    </label>
                    <select name="canteen_fee_type" id="canteen_fee_type" required>
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                    </select>
                    <small style="color: var(--text-secondary); display: block; margin-top: 5px;">
                        How often the student pays for canteen
                    </small>
                </div>
                
                <div class="form-group">
                    <label for="bus_fee_type">
                        <i class="fas fa-bus"></i> Bus Fee Payment
                    </label>
                    <select name="bus_fee_type" id="bus_fee_type" required>
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                    </select>
                    <small style="color: var(--text-secondary); display: block; margin-top: 5px;">
                        How often the student pays for bus transport
                    </small>
                </div>
                
                <div class="form-actions" style="display: flex; gap: 10px; margin-top: 25px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="closeEditScheduleModal()" style="flex: 1;">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function editSchedule(student) {
        document.getElementById('edit_student_id').value = student.student_id;
        document.getElementById('studentName').textContent = student.first_name + ' ' + student.last_name;
        document.getElementById('studentClass').textContent = 'Class: ' + (student.class_name || 'N/A') + ' | Admission: ' + student.admission_number;
        
        // Set fee types (handle exempt students)
        if (student.exempt_canteen) {
            document.getElementById('canteen_fee_type').value = 'daily';
            document.getElementById('canteen_fee_type').disabled = true;
        } else {
            document.getElementById('canteen_fee_type').value = student.canteen_fee_type || 'daily';
            document.getElementById('canteen_fee_type').disabled = false;
        }
        
        if (student.exempt_bus) {
            document.getElementById('bus_fee_type').value = 'daily';
            document.getElementById('bus_fee_type').disabled = true;
        } else {
            document.getElementById('bus_fee_type').value = student.bus_fee_type || 'daily';
            document.getElementById('bus_fee_type').disabled = false;
        }
        
        document.getElementById('editScheduleModal').style.display = 'block';
    }
    
    function closeEditScheduleModal() {
        document.getElementById('editScheduleModal').style.display = 'none';
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
        const modal = document.getElementById('editScheduleModal');
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
