<?php
// admin/fee-payments.php - Payment History
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Payment History';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get payments
$stmt = $db->prepare("
    SELECT 
        fp.*,
        CONCAT(s.first_name, ' ', s.last_name) as student_name,
        c.class_name,
        CONCAT(u.first_name, ' ', u.last_name) as collected_by_name
    FROM fee_payments fp
    INNER JOIN students s ON fp.student_id = s.student_id
    INNER JOIN classes c ON s.class_id = c.class_id
    INNER JOIN users u ON fp.collected_by = u.user_id
    WHERE s.school_id = ? AND fp.status = 'verified'
    ORDER BY fp.payment_date DESC, fp.created_at DESC
    LIMIT 100
");
$stmt->execute([$school_id]);
$payments = $stmt->fetchAll();

$total_amount = array_sum(array_column($payments, 'amount'));

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-receipt"></i> Payment History</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> View all fee payment transactions
        </p>
    </div>
    
    <div style="background: linear-gradient(135deg, #34C759, #30D158); color: white; padding: 20px; border-radius: 12px; margin-bottom: 25px;">
        <h3 style="margin: 0; font-size: 28px;">₹<?php echo number_format($total_amount, 2); ?></h3>
        <p style="margin: 5px 0 0 0; opacity: 0.9;"><?php echo count($payments); ?> Recent Payments</p>
    </div>
    
    <?php foreach ($payments as $payment): ?>
        <div style="background: var(--bg-card); border: 1px solid var(--border-color); padding: 15px; border-radius: 8px; margin-bottom: 10px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="flex: 1;">
                    <h4 style="margin: 0 0 5px 0;"><?php echo htmlspecialchars($payment['student_name']); ?></h4>
                    <div style="font-size: 13px; color: var(--text-secondary);">
                        <i class="fas fa-receipt"></i> <?php echo htmlspecialchars($payment['receipt_number']); ?> | 
                        <i class="fas fa-graduation-cap"></i> <?php echo htmlspecialchars($payment['class_name']); ?> | 
                        <i class="fas fa-calendar"></i> <?php echo date('M d, Y', strtotime($payment['payment_date'])); ?> | 
                        <i class="fas fa-credit-card"></i> <?php echo strtoupper($payment['payment_method']); ?> | 
                        <i class="fas fa-user"></i> <?php echo htmlspecialchars($payment['collected_by_name']); ?>
                    </div>
                </div>
                <div style="font-size: 24px; font-weight: 700; color: #34C759; margin-left: 20px;">
                    ₹<?php echo number_format($payment['amount'], 2); ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
    
    <?php if (count($payments) == 0): ?>
        <div style="text-align: center; padding: 60px; background: var(--bg-card); border-radius: 15px;">
            <i class="fas fa-receipt" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
            <h3 style="color: var(--text-secondary);">No Payments Yet</h3>
        </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
