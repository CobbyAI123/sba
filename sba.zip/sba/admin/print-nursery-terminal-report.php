<?php
// admin/print-nursery-terminal-report.php - Nursery/Reception Terminal Report
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['admin', 'teacher']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get student ID from URL
$student_id = (int)($_GET['student'] ?? 0);

if (!$student_id) {
    die('Student ID is required');
}

// Get active term
try {
    $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_active = 1");
    $stmt->execute([$school_id]);
    $active_term = $stmt->fetch();
} catch (PDOException $e) {
    try {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_current = 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    } catch (PDOException $e2) {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY start_date DESC LIMIT 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    }
}

if (!$active_term) {
    die('No active term found');
}

// Get student details
$stmt = $db->prepare("
    SELECT s.*, c.class_name, sc.school_name, sc.logo, sc.address, sc.phone, sc.email, sc.motto,
           COALESCE(u.first_name, s.first_name, '-') as first_name,
           COALESCE(u.last_name, s.last_name, '') as last_name
    FROM students s
    INNER JOIN classes c ON s.class_id = c.class_id
    INNER JOIN schools sc ON s.school_id = sc.school_id
    LEFT JOIN users u ON s.user_id = u.user_id
    WHERE s.student_id = ? AND s.school_id = ?
");
$stmt->execute([$student_id, $school_id]);
$student = $stmt->fetch();

if (!$student) {
    die('Student not found');
}

// Check if this is a nursery/reception class
$nursery_classes = [
    'CREACHE', 'NURSERY 1', 'NURSERY 1A', 'NURSERY 1B', 'NURSERY 2', 'NURSERY 2A', 'NURSERY 2B',
    'NURSERY 3', 'NURSERY 3A', 'NURSERY 3B', 'RECEPTION 1', 'RECEPTION 1A', 'RECEPTION 1B',
    'RECEPTION 2', 'RECEPTION 2A', 'RECEPTION 2B'
];

if (!in_array(strtoupper($student['class_name']), $nursery_classes)) {
    die('This report format is only for Nursery and Reception classes');
}

// Get results
$stmt = $db->prepare("
    SELECT 
        subj.subject_name,
        sa.ca_score,
        sa.midterm_score,
        sa.exam_score,
        sa.total_score,
        sa.grade,
        sa.remark,
        sa.position
    FROM student_assessments sa
    INNER JOIN subjects subj ON sa.subject_id = subj.subject_id
    WHERE sa.student_id = ? AND sa.term_id = ? AND sa.school_id = ?
    ORDER BY subj.subject_name
");
$stmt->execute([$student_id, $active_term['term_id'], $school_id]);
$results = $stmt->fetchAll();

// Calculate totals
foreach ($results as &$result) {
    if (($result['total_score'] == 0 || $result['total_score'] === null) &&
        ($result['ca_score'] > 0 || $result['midterm_score'] > 0 || $result['exam_score'] > 0)) {
        $result['total_score'] = calculate_total_score(
            $result['ca_score'] ?? 0,
            $result['midterm_score'] ?? 0,
            $result['exam_score'] ?? 0
        );
        if (empty($result['grade']) || empty($result['remark'])) {
            $grade_info = calculate_grade_new($result['total_score']);
            $result['grade'] = $grade_info['grade'];
            $result['remark'] = $grade_info['remark'];
        }
    }
}
unset($result);

// Calculate statistics
$total_subjects = count($results);
$total_marks = 0;
foreach ($results as $result) {
    $score_total = $result['total_score'] ?? 0;
    if ($score_total == 0) {
        $score_total = calculate_total_score(
            $result['ca_score'] ?? 0,
            $result['midterm_score'] ?? 0,
            $result['exam_score'] ?? 0
        );
    }
    $total_marks += $score_total;
}
$overall_average = $total_subjects > 0 ? round($total_marks / $total_subjects, 2) : 0;

// Get attendance
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_days,
        SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_days
    FROM attendance 
    WHERE student_id = ? AND term_id = ?
");
$stmt->execute([$student_id, $active_term['term_id']]);
$attendance = $stmt->fetch();

$attendance_days = $attendance['present_days'] ?? 0;
$out_of_days = $attendance['total_days'] ?? 0;

// Calculate position
$stmt = $db->prepare("
    SELECT COUNT(*) + 1 as position
    FROM (
        SELECT student_id, AVG(total_score) as avg_score
        FROM student_assessments
        WHERE term_id = ? AND class_id = ? AND school_id = ?
        GROUP BY student_id
        HAVING AVG(total_score) > ?
    ) as rankings
");
$stmt->execute([$active_term['term_id'], $student['class_id'], $school_id, $overall_average]);
$position_result = $stmt->fetch();
$overall_position = $position_result['position'] ?? 1;

function getOrdinalSuffix($number) {
    $ends = array('th','st','nd','rd','th','th','th','th','th','th');
    if ((($number % 100) >= 11) && (($number % 100) <= 13))
        return 'th';
    else
        return $ends[$number % 10];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terminal Report - <?php echo $student['first_name'] . ' ' . $student['last_name']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        @page {
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background: white;
        }
        
        .report-container {
            width: 210mm;
            min-height: 297mm;
            margin: 0;
            padding: 0;
            background: white;
            position: relative;
        }
        
        /* Header Section */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 8mm 10mm;
            border-bottom: 2px solid #000;
        }
        
        .logo-section {
            width: 25mm;
        }
        
        .logo {
            width: 25mm;
            height: 25mm;
            object-fit: contain;
            border: 1px solid #000;
        }
        
        .school-info {
            flex: 1;
            text-align: center;
            padding: 0 5mm;
        }
        
        .school-name {
            font-size: 18pt;
            font-weight: bold;
            color: #000;
            text-transform: uppercase;
            margin-bottom: 2mm;
            letter-spacing: 1px;
        }
        
        .school-motto {
            font-size: 10pt;
            font-style: italic;
            color: #333;
            margin-bottom: 1mm;
        }
        
        .school-location {
            font-size: 9pt;
            color: #666;
        }
        
        .student-photo-section {
            width: 25mm;
        }
        
        .student-photo {
            width: 25mm;
            height: 30mm;
            border: 1px solid #000;
            object-fit: cover;
        }
        
        /* Report Title */
        .report-title {
            background: #000;
            color: white;
            text-align: center;
            padding: 3mm 0;
            font-size: 14pt;
            font-weight: bold;
            letter-spacing: 3px;
        }
        
        /* Student Details */
        .student-details {
            padding: 5mm 10mm;
            border-bottom: 1px solid #000;
        }
        
        .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2mm 5mm;
            font-size: 10pt;
        }
        
        .detail-row {
            display: flex;
            gap: 3mm;
        }
        
        .detail-label {
            font-weight: bold;
            color: #000;
            min-width: 35mm;
        }
        
        .detail-value {
            color: #333;
            flex: 1;
        }
        
        /* Subjects Table */
        .subjects-section {
            padding: 0;
        }
        
        .subjects-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .subjects-table th {
            background: #000;
            color: white;
            font-weight: bold;
            padding: 2mm;
            text-align: center;
            border: 1px solid #000;
            font-size: 9pt;
        }
        
        .subjects-table td {
            padding: 2mm;
            text-align: center;
            border: 1px solid #000;
            font-size: 9pt;
        }
        
        .subject-name-cell {
            text-align: left !important;
            font-weight: bold;
            padding-left: 3mm !important;
        }
        
        .grade-cell {
            font-weight: bold;
            font-size: 10pt;
        }
        
        .remark-cell {
            font-style: italic;
            color: #333;
        }
        
        /* Grade Key */
        .grade-key {
            padding: 3mm 10mm;
            border-top: 1px solid #000;
            border-bottom: 1px solid #000;
        }
        
        .key-box {
            border: 1px dashed #000;
            padding: 2mm;
            text-align: center;
            font-size: 8pt;
            line-height: 1.4;
        }
        
        /* Additional Info */
        .additional-info {
            padding: 5mm 10mm;
            border-bottom: 1px solid #000;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2mm 5mm;
            font-size: 9pt;
        }
        
        .info-item {
            display: flex;
            gap: 2mm;
        }
        
        .info-label {
            font-weight: bold;
            min-width: 40mm;
        }
        
        /* Signatures */
        .signatures-section {
            padding: 10mm 10mm 5mm;
            display: flex;
            justify-content: space-around;
            gap: 10mm;
        }
        
        .signature-box {
            text-align: center;
            flex: 1;
        }
        
        .signature-line {
            border-top: 2px solid #000;
            margin-top: 15mm;
            padding-top: 2mm;
            font-weight: bold;
            font-size: 10pt;
        }
        
        /* Footer */
        .report-footer {
            position: absolute;
            bottom: 5mm;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 8pt;
            color: #666;
            font-style: italic;
        }
        
        @media print {
            body {
                margin: 0;
                padding: 0;
            }
            
            .report-container {
                margin: 0;
                padding: 0;
            }
            
            @page {
                size: A4;
                margin: 0;
            }
        }
    </style>
</head>
<body>
    <div class="report-container">
        <!-- Header -->
        <div class="header">
            <div class="logo-section">
                <?php if (!empty($student['logo'])): ?>
                    <img src="<?php echo APP_URL . '/uploads/schools/' . $student['logo']; ?>" alt="Logo" class="logo">
                <?php else: ?>
                    <div class="logo" style="display: flex; align-items: center; justify-content: center; font-size: 20pt; color: #000; font-weight: bold;">
                        <?php echo strtoupper(substr($student['school_name'], 0, 1)); ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="school-info">
                <div class="school-name"><?php echo strtoupper($student['school_name']); ?></div>
                <div class="school-motto"><?php echo $student['motto'] ?? 'EXCELLENCE IN EDUCATION'; ?></div>
                <div class="school-location"><?php echo $student['address'] ?? ''; ?></div>
            </div>
            
            <div class="student-photo-section">
                <?php if (!empty($student['photo'])): ?>
                    <img src="<?php echo APP_URL . '/uploads/students/' . $student['photo']; ?>" alt="Photo" class="student-photo">
                <?php else: ?>
                    <div class="student-photo" style="display: flex; align-items: center; justify-content: center; background: #f0f0f0; color: #000; font-size: 18pt; font-weight: bold;">
                        <?php echo strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Report Title -->
        <div class="report-title">TERMINAL REPORT</div>
        
        <!-- Student Details -->
        <div class="student-details">
            <div class="details-grid">
                <div class="detail-row">
                    <span class="detail-label">Pupil's Name:</span>
                    <span class="detail-value"><?php echo strtoupper($student['first_name'] . ' ' . $student['last_name']); ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Class:</span>
                    <span class="detail-value"><?php echo strtoupper($student['class_name']); ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Admission Number:</span>
                    <span class="detail-value"><?php echo $student['admission_number']; ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Term:</span>
                    <span class="detail-value"><?php echo $active_term['term_name']; ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Academic Year:</span>
                    <span class="detail-value"><?php echo isset($active_term['session_year']) ? $active_term['session_year'] : date('Y'); ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Position:</span>
                    <span class="detail-value"><?php echo $overall_position . getOrdinalSuffix($overall_position); ?></span>
                </div>
            </div>
        </div>
        
        <!-- Subjects Table -->
        <div class="subjects-section">
            <table class="subjects-table">
                <thead>
                    <tr>
                        <th style="width: 35%;">SUBJECT</th>
                        <th style="width: 10%;">CLASS<br>SCORE</th>
                        <th style="width: 10%;">EXAM<br>SCORE</th>
                        <th style="width: 10%;">TOTAL<br>(100)</th>
                        <th style="width: 10%;">GRADE</th>
                        <th style="width: 25%;">REMARK</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($results) > 0): ?>
                        <?php foreach ($results as $result): ?>
                            <?php
                            $class_score = ($result['ca_score'] + $result['midterm_score']) * 0.5;
                            $exam_score = $result['exam_score'] / 2;
                            ?>
                            <tr>
                                <td class="subject-name-cell"><?php echo strtoupper($result['subject_name']); ?></td>
                                <td><?php echo number_format($class_score, 1); ?></td>
                                <td><?php echo number_format($exam_score, 1); ?></td>
                                <td class="grade-cell"><?php echo number_format($result['total_score'], 1); ?></td>
                                <td class="grade-cell"><?php echo $result['grade']; ?></td>
                                <td class="remark-cell"><?php echo $result['remark']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 10mm; color: #999;">No results available for this term</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Grade Key -->
        <div class="grade-key">
            <div class="key-box">
                <strong>GRADING KEY:</strong> HP (80-100) = Highly Proficient | P (68-79) = Proficient | AP (53-67) = Approaching Proficient | D (40-52) = Developing | E (0-39) = Emerging
            </div>
        </div>
        
        <!-- Additional Information -->
        <div class="additional-info">
            <div class="info-grid">
                <div class="info-item">
                    <span class="info-label">Attendance:</span>
                    <span><?php echo $attendance_days; ?> out of <?php echo $out_of_days; ?> days</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Overall Average:</span>
                    <span><?php echo number_format($overall_average, 1); ?>%</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Conduct:</span>
                    <span>Excellent</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Interest:</span>
                    <span>Learning</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Class Teacher's Remark:</span>
                    <span>Good performance</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Head Teacher's Remark:</span>
                    <span>Keep up the good work</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Vacation Date:</span>
                    <span><?php echo isset($active_term['end_date']) ? date('d/m/Y', strtotime($active_term['end_date'])) : ''; ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Re-opening Date:</span>
                    <span><?php echo isset($active_term['next_term_start']) ? date('d/m/Y', strtotime($active_term['next_term_start'])) : ''; ?></span>
                </div>
            </div>
        </div>
        
        <!-- Signatures -->
        <div class="signatures-section">
            <div class="signature-box">
                <div class="signature-line">CLASS TEACHER</div>
            </div>
            <div class="signature-box">
                <div class="signature-line">HEAD TEACHER</div>
            </div>
            <div class="signature-box">
                <div class="signature-line">PARENT/GUARDIAN</div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="report-footer">
            Printed on: <?php echo date('d/m/Y'); ?>
        </div>
    </div>
    
    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>
```
