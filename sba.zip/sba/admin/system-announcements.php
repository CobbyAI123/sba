<?php
// admin/system-announcements.php - System-wide Announcements
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'System Announcements';
$current_user = check_permission(['admin', 'super-admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$admin_id = $current_user['user_id'];

// Handle announcement actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'create') {
            $title = sanitize_input($_POST['title']);
            $content = sanitize_input($_POST['content']);
            $target_roles = isset($_POST['target_roles']) ? $_POST['target_roles'] : [];
            $priority = sanitize_input($_POST['priority'] ?? 'normal');
            $expiry_date = sanitize_input($_POST['expiry_date'] ?? null);
            
            if (empty($title) || empty($content)) {
                set_message('error', 'Title and content are required');
            } else {
                try {
                    $stmt = $db->prepare("
                        INSERT INTO announcements (title, content, priority, target_roles, expiry_date, created_by, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, NOW())
                    ");
                    $target_roles_str = implode(',', $target_roles);
                    $stmt->execute([$title, $content, $priority, $target_roles_str, $expiry_date, $admin_id]);
                    
                    log_activity($admin_id, "Created announcement: $title", 'announcements');
                    set_message('success', 'Announcement created and will be sent to all selected users!');
                    redirect(APP_URL . '/admin/system-announcements.php');
                } catch (PDOException $e) {
                    set_message('error', 'Error creating announcement');
                }
            }
        }
        elseif ($_POST['action'] == 'delete') {
            $announcement_id = (int)$_POST['announcement_id'];
            
            try {
                $stmt = $db->prepare("DELETE FROM announcements WHERE announcement_id = ?");
                $stmt->execute([$announcement_id]);
                
                log_activity($admin_id, "Deleted announcement", 'announcements');
                set_message('success', 'Announcement deleted!');
                redirect(APP_URL . '/admin/system-announcements.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting announcement');
            }
        }
    }
}

// Get announcements
$stmt = $db->prepare("
    SELECT a.*, COUNT(an.notification_id) as read_count
    FROM announcements a
    LEFT JOIN announcement_notifications an ON a.announcement_id = an.announcement_id
    WHERE a.school_id = ? OR a.school_id IS NULL
    GROUP BY a.announcement_id
    ORDER BY a.created_at DESC
");
$stmt->execute([$school_id]);
$announcements = $stmt->fetchAll();

// Get role statistics
$stmt = $db->prepare("
    SELECT role, COUNT(*) as count
    FROM users
    WHERE school_id = ? AND role != 'student' AND role != 'parent'
    GROUP BY role
");
$stmt->execute([$school_id]);
$role_stats = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Announcement Stats -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-bullhorn"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo count($announcements); ?></h3>
                <p>Total Announcements</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-details">
                <h3><?php 
                    $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE school_id = ? AND role IN ('teacher', 'accountant', 'librarian')");
                    $stmt->execute([$school_id]);
                    echo $stmt->fetch()[0];
                ?></h3>
                <p>Active Staff</p>
            </div>
        </div>
    </div>
    
    <!-- Create Announcement Button -->
    <div style="margin-bottom: 20px;">
        <button type="button" onclick="openCreateModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Create Announcement
        </button>
    </div>
    
    <!-- Announcements List -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Announcements</h3>
        </div>
        <div style="padding: 20px;">
            <?php if (count($announcements) > 0): ?>
                <?php foreach ($announcements as $ann): ?>
                    <?php 
                        $is_expired = $ann['expiry_date'] && strtotime($ann['expiry_date']) < time();
                        $target_roles = explode(',', $ann['target_roles'] ?? '');
                    ?>
                    <div style="border: 1px solid var(--border-color); border-radius: 8px; padding: 15px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: start;">
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 5px;">
                                <h4 style="margin: 0;"><?php echo $ann['title']; ?></h4>
                                <span class="badge badge-<?php echo $ann['priority'] === 'urgent' ? 'danger' : ($ann['priority'] === 'high' ? 'warning' : 'info'); ?>">
                                    <?php echo ucfirst($ann['priority']); ?>
                                </span>
                                <?php if ($is_expired): ?>
                                    <span class="badge badge-secondary">Expired</span>
                                <?php endif; ?>
                            </div>
                            
                            <p style="color: var(--text-secondary); margin: 5px 0;">
                                <?php echo $ann['content']; ?>
                            </p>
                            
                            <div style="display: flex; gap: 15px; font-size: 0.85em; color: var(--text-secondary); margin-top: 10px;">
                                <span><i class="fas fa-users"></i> To: <?php echo implode(', ', $target_roles); ?></span>
                                <span><i class="fas fa-calendar"></i> Created: <?php echo date('M d, Y', strtotime($ann['created_at'])); ?></span>
                                <?php if ($ann['expiry_date']): ?>
                                    <span><i class="fas fa-clock"></i> Expires: <?php echo date('M d, Y', strtotime($ann['expiry_date'])); ?></span>
                                <?php endif; ?>
                                <span><i class="fas fa-eye"></i> Views: <?php echo $ann['read_count']; ?></span>
                            </div>
                        </div>
                        
                        <button type="button" class="btn btn-sm btn-danger" onclick="deleteAnnouncement(<?php echo $ann['announcement_id']; ?>)">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 40px; color: var(--text-secondary);">
                    <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 10px; display: block;"></i>
                    <h3>No Announcements Yet</h3>
                    <p>Create your first announcement to communicate with your staff</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Create Announcement Modal -->
    <div id="createModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 700px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Create Announcement</h2>
                <button onclick="closeCreateModal()" style="background: none; border: none; font-size: 24px; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="create">
                
                <div class="form-group">
                    <label>Title *</label>
                    <input type="text" name="title" required placeholder="Announcement title">
                </div>
                
                <div class="form-group">
                    <label>Content *</label>
                    <textarea name="content" rows="5" required placeholder="Announcement details..."></textarea>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Priority *</label>
                        <select name="priority" required>
                            <option value="normal">Normal</option>
                            <option value="high">High</option>
                            <option value="urgent">Urgent</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Expiry Date</label>
                        <input type="date" name="expiry_date">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Send To (Select at least one) *</label>
                    <div style="border: 1px solid var(--border-color); border-radius: 5px; padding: 15px;">
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <input type="checkbox" name="target_roles" value="teacher">
                            <span>Teachers</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <input type="checkbox" name="target_roles" value="accountant">
                            <span>Accountants</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <input type="checkbox" name="target_roles" value="librarian">
                            <span>Librarians</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 10px;">
                            <input type="checkbox" name="target_roles" value="admin">
                            <span>Admin Staff</span>
                        </label>
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeCreateModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-send"></i> Send Announcement</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Modal -->
    <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
        <div style="max-width: 400px; margin: 150px auto; background: var(--bg-card); border-radius: 15px; padding: 30px; text-align: center;">
            <i class="fas fa-exclamation-triangle" style="font-size: 48px; color: var(--danger-red); margin-bottom: 15px; display: block;"></i>
            <h2>Delete Announcement?</h2>
            <p style="color: var(--text-secondary); margin: 15px 0;">This will remove the announcement from all users.</p>
            <form method="POST" style="display: inline;">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="announcement_id" id="deleteId">
                <div style="display: flex; gap: 10px; justify-content: center; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function openCreateModal() {
        document.getElementById('createModal').style.display = 'block';
    }
    
    function closeCreateModal() {
        document.getElementById('createModal').style.display = 'none';
    }
    
    function deleteAnnouncement(announcementId) {
        document.getElementById('deleteId').value = announcementId;
        document.getElementById('deleteModal').style.display = 'block';
    }
    
    function closeDeleteModal() {
        document.getElementById('deleteModal').style.display = 'none';
    }
    
    window.onclick = function(event) {
        if (event.target.id === 'createModal') event.target.style.display = 'none';
        if (event.target.id === 'deleteModal') event.target.style.display = 'none';
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
