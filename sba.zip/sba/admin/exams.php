<?php
// admin/exams.php - Exam Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Exam Management';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get term filter if provided
$term_filter = isset($_GET['term_id']) ? (int)$_GET['term_id'] : 0;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $exam_name = sanitize_input($_POST['exam_name']);
            $exam_type = sanitize_input($_POST['exam_type']);
            $term_id = sanitize_input($_POST['term_id']);
            $start_date = sanitize_input($_POST['start_date']);
            $end_date = sanitize_input($_POST['end_date']);
            
            try {
                $stmt = $db->prepare("
                    INSERT INTO exams (school_id, exam_name, exam_type, term_id, start_date, end_date, status)
                    VALUES (?, ?, ?, ?, ?, ?, 'scheduled')
                ");
                $stmt->execute([$school_id, $exam_name, $exam_type, $term_id, $start_date, $end_date]);
                
                $exam_id = $db->lastInsertId();
                log_activity($current_user['user_id'], "Created exam: $exam_name", 'exams', $exam_id);
                
                set_message('success', 'Exam created successfully!');
                redirect(APP_URL . '/admin/exams.php');
            } catch (PDOException $e) {
                set_message('error', 'Error creating exam: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'edit') {
            $exam_id = sanitize_input($_POST['exam_id']);
            $exam_name = sanitize_input($_POST['exam_name']);
            $exam_type = sanitize_input($_POST['exam_type']);
            $term_id = sanitize_input($_POST['term_id']);
            $start_date = sanitize_input($_POST['start_date']);
            $end_date = sanitize_input($_POST['end_date']);
            $status = sanitize_input($_POST['status']);
            
            try {
                $stmt = $db->prepare("
                    UPDATE exams 
                    SET exam_name = ?, exam_type = ?, term_id = ?, start_date = ?, 
                        end_date = ?, status = ?
                    WHERE exam_id = ? AND school_id = ?
                ");
                $stmt->execute([$exam_name, $exam_type, $term_id, $start_date, $end_date, $status, $exam_id, $school_id]);
                
                log_activity($current_user['user_id'], "Updated exam: $exam_name", 'exams', $exam_id);
                
                set_message('success', 'Exam updated successfully!');
                redirect(APP_URL . '/admin/exams.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating exam: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            $exam_id = sanitize_input($_POST['exam_id']);
            
            try {
                $stmt = $db->prepare("DELETE FROM exams WHERE exam_id = ? AND school_id = ?");
                $stmt->execute([$exam_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted exam ID: $exam_id", 'exams', $exam_id);
                
                set_message('success', 'Exam deleted successfully!');
                redirect(APP_URL . '/admin/exams.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting exam: ' . $e->getMessage());
            }
        }
    }
}

// Get all exams
$stmt = $db->prepare("
    SELECT e.*, t.term_name, t.session_year,
           COUNT(DISTINCT m.mark_id) as marks_entered
    FROM exams e
    LEFT JOIN terms t ON e.term_id = t.term_id
    LEFT JOIN marks m ON e.exam_id = m.exam_id
    WHERE e.school_id = ?
    " . ($term_filter > 0 ? "AND e.term_id = ?" : "") . "
    GROUP BY e.exam_id
    ORDER BY e.start_date DESC
");
if ($term_filter > 0) {
    $stmt->execute([$school_id, $term_filter]);
} else {
    $stmt->execute([$school_id]);
}
$exams = $stmt->fetchAll();

// Get terms for dropdown
$stmt = $db->prepare("
    SELECT * FROM terms
    WHERE school_id = ?
    ORDER BY session_year DESC, start_date DESC
");
$stmt->execute([$school_id]);
$terms = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
            <button class="btn btn-primary" onclick="showAddModal()">
                <i class="fas fa-plus"></i> Create Exam
            </button>
        </div>
    </div>
    
    <!-- Exams Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 20px;">
        <?php foreach ($exams as $exam): ?>
            <div class="card">
                <div style="padding: 25px;">
                    <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 15px;">
                        <div style="flex: 1;">
                            <h3 style="font-size: 18px; margin-bottom: 5px;"><?php echo $exam['exam_name']; ?></h3>
                            <p style="color: var(--text-secondary); font-size: 13px;">
                                <?php echo $exam['term_name'] . ' (' . $exam['session_year'] . ')'; ?>
                            </p>
                        </div>
                        <span class="badge badge-<?php 
                            echo $exam['status'] == 'completed' ? 'success' : 
                                ($exam['status'] == 'ongoing' ? 'warning' : 'info'); 
                        ?>">
                            <?php echo ucfirst($exam['status']); ?>
                        </span>
                    </div>
                    
                    <div style="background: var(--bg-secondary); padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                            <div>
                                <p style="font-size: 11px; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 5px;">Type</p>
                                <p style="font-size: 14px; font-weight: 600; text-transform: capitalize;">
                                    <?php echo str_replace('_', ' ', $exam['exam_type']); ?>
                                </p>
                            </div>
                            <div>
                                <p style="font-size: 11px; color: var(--text-secondary); text-transform: uppercase; margin-bottom: 5px;">Exam Status</p>
                                <p style="font-size: 14px; font-weight: 600; color: var(--primary-blue);">
                                    <?php echo ucfirst($exam['status']); ?>
                                </p>
                            </div>
                        </div>
                        
                        <div style="padding-top: 10px; border-top: 1px solid var(--border-color);">
                            <p style="font-size: 12px; color: var(--text-secondary); margin-bottom: 5px;">
                                <i class="fas fa-calendar-alt"></i> 
                                <?php echo date('M d', strtotime($exam['start_date'])); ?> - 
                                <?php echo date('M d, Y', strtotime($exam['end_date'])); ?>
                            </p>
                            <p style="font-size: 12px; color: var(--text-secondary);">
                                <i class="fas fa-check-circle"></i> 
                                <?php echo $exam['marks_entered']; ?> marks entered
                            </p>
                        </div>
                    </div>
                    
                    <div style="display: flex; gap: 10px;">
                        <button class="btn btn-info btn-sm" onclick='editExam(<?php echo json_encode($exam); ?>)' style="flex: 1;">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="deleteExam(<?php echo $exam['exam_id']; ?>, '<?php echo addslashes($exam['exam_name']); ?>')" style="flex: 1;">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        
        <?php if (count($exams) == 0): ?>
            <div class="card" style="grid-column: 1 / -1;">
                <div style="padding: 60px; text-align: center;">
                    <i class="fas fa-file-alt" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 20px;"></i>
                    <h3 style="margin-bottom: 10px;">No Exams Yet</h3>
                    <p style="color: var(--text-secondary); margin-bottom: 20px;">Create exams for different terms</p>
                    <button class="btn btn-primary" onclick="showAddModal()">
                        <i class="fas fa-plus"></i> Create Your First Exam
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Add/Edit Exam Modal -->
    <div id="examModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Create Exam</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="examForm">
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="exam_id" id="examId">
                
                <div class="form-group">
                    <label for="exam_name">Exam Name *</label>
                    <input type="text" name="exam_name" id="exam_name" placeholder="e.g., Mid-Term Exam, Final Exam" required>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label for="exam_type">Exam Type *</label>
                        <select name="exam_type" id="exam_type" required>
                            <option value="">-- Select Type --</option>
                            <option value="CA">Continuous Assessment (CA)</option>
                            <option value="Final">Final Exam</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="term_id">Term *</label>
                    <select name="term_id" id="term_id" required>
                        <option value="">-- Select Term --</option>
                        <?php foreach ($terms as $term): ?>
                            <option value="<?php echo $term['term_id']; ?>">
                                <?php echo $term['term_name'] . ' (' . $term['session_year'] . ')'; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label for="start_date">Start Date *</label>
                        <input type="date" name="start_date" id="start_date" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="end_date">End Date *</label>
                        <input type="date" name="end_date" id="end_date" required>
                    </div>
                </div>
                
                <div class="form-group" id="statusGroup" style="display: none;">
                    <label for="status">Status *</label>
                    <select name="status" id="status">
                        <option value="scheduled">Scheduled</option>
                        <option value="ongoing">Ongoing</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Exam
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showAddModal() {
        document.getElementById('examModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Create Exam';
        document.getElementById('formAction').value = 'add';
        document.getElementById('examForm').reset();
        document.getElementById('examId').value = '';
        document.getElementById('statusGroup').style.display = 'none';
    }
    
    function editExam(exam) {
        document.getElementById('examModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Edit Exam';
        document.getElementById('formAction').value = 'edit';
        document.getElementById('examId').value = exam.exam_id;
        document.getElementById('exam_name').value = exam.exam_name;
        document.getElementById('exam_type').value = exam.exam_type;
        document.getElementById('term_id').value = exam.term_id;
        document.getElementById('start_date').value = exam.start_date;
        document.getElementById('end_date').value = exam.end_date;
        document.getElementById('status').value = exam.status;
        document.getElementById('statusGroup').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('examModal').style.display = 'none';
    }
    
    function deleteExam(examId, examName) {
        if (confirmDelete(`Are you sure you want to delete ${examName}?`)) {
            const form = document.createElement('form');
            form.method = 'POST';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete';
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'exam_id';
            idInput.value = examId;
            
            form.appendChild(actionInput);
            form.appendChild(idInput);
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Validate end date is after start date
    document.getElementById('end_date').addEventListener('change', function() {
        const startDate = document.getElementById('start_date').value;
        const endDate = this.value;
        
        if (startDate && endDate && endDate < startDate) {
            alert('End date must be after start date');
            this.value = '';
        }
    });
    
    // Close modal on outside click
    document.getElementById('examModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
