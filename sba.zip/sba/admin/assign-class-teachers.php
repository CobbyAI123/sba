<?php
// admin/assign-class-teachers.php - Assign Class Teachers
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Assign Class Teachers';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get current term
$stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_current = 1 LIMIT 1");
$stmt->execute([$school_id]);
$current_term = $stmt->fetch();
$academic_year = $current_term['session_year'] ?? date('Y') . '/' . (date('Y') + 1);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'assign') {
            $class_id = intval($_POST['class_id']);
            $teacher_id = intval($_POST['teacher_id']);
            $is_primary = isset($_POST['is_primary']) ? 1 : 0;
            
            try {
                // Check if teacher is already assigned to this class for this year
                $stmt = $db->prepare("
                    SELECT COUNT(*) FROM class_teachers 
                    WHERE class_id = ? AND teacher_id = ? AND academic_year = ? AND school_id = ?
                ");
                $stmt->execute([$class_id, $teacher_id, $academic_year, $school_id]);
                
                if ($stmt->fetchColumn() > 0) {
                    set_message('error', 'This teacher is already assigned to this class for this academic year');
                } else {
                    // If setting as primary, remove primary status from other teachers for this class
                    if ($is_primary) {
                        $stmt = $db->prepare("
                            UPDATE class_teachers 
                            SET is_primary = 0 
                            WHERE class_id = ? AND academic_year = ? AND school_id = ?
                        ");
                        $stmt->execute([$class_id, $academic_year, $school_id]);
                    }
                    
                    // Assign teacher
                    $stmt = $db->prepare("
                        INSERT INTO class_teachers (school_id, class_id, teacher_id, academic_year, is_primary, assigned_date)
                        VALUES (?, ?, ?, ?, ?, CURDATE())
                    ");
                    $stmt->execute([$school_id, $class_id, $teacher_id, $academic_year, $is_primary]);
                    
                    set_message('success', 'Class teacher assigned successfully!');
                }
            } catch (PDOException $e) {
                set_message('error', 'Error assigning teacher: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/assign-class-teachers.php');
        }
        
        if ($action == 'edit') {
            $assignment_id = intval($_POST['assignment_id']);
            $class_id = intval($_POST['class_id']);
            $teacher_id = intval($_POST['teacher_id']);
            $is_primary = isset($_POST['is_primary']) ? 1 : 0;
            
            try {
                // If setting as primary, remove primary status from other teachers for this class
                if ($is_primary) {
                    $stmt = $db->prepare("
                        UPDATE class_teachers 
                        SET is_primary = 0 
                        WHERE class_id = ? AND academic_year = ? AND school_id = ? AND assignment_id != ?
                    ");
                    $stmt->execute([$class_id, $academic_year, $school_id, $assignment_id]);
                }
                
                // Update assignment
                $stmt = $db->prepare("
                    UPDATE class_teachers 
                    SET class_id = ?, teacher_id = ?, is_primary = ?
                    WHERE assignment_id = ? AND school_id = ?
                ");
                $stmt->execute([$class_id, $teacher_id, $is_primary, $assignment_id, $school_id]);
                
                set_message('success', 'Class teacher assignment updated successfully!');
            } catch (PDOException $e) {
                set_message('error', 'Error updating assignment: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/assign-class-teachers.php');
        }
        
        if ($action == 'remove') {
            $assignment_id = intval($_POST['assignment_id']);
            
            try {
                $stmt = $db->prepare("
                    DELETE FROM class_teachers 
                    WHERE assignment_id = ? AND school_id = ?
                ");
                $stmt->execute([$assignment_id, $school_id]);
                set_message('success', 'Class teacher removed successfully!');
            } catch (PDOException $e) {
                set_message('error', 'Error removing teacher: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/assign-class-teachers.php');
        }
        
        if ($action == 'toggle_status') {
            $assignment_id = intval($_POST['assignment_id']);
            $new_status = sanitize_input($_POST['new_status']);
            
            try {
                $stmt = $db->prepare("
                    UPDATE class_teachers 
                    SET status = ? 
                    WHERE assignment_id = ? AND school_id = ?
                ");
                $stmt->execute([$new_status, $assignment_id, $school_id]);
                set_message('success', 'Status updated successfully!');
            } catch (PDOException $e) {
                set_message('error', 'Error updating status: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/assign-class-teachers.php');
        }
    }
}

// Get all class teacher assignments
$stmt = $db->prepare("
    SELECT 
        ct.*,
        c.class_name,
        CONCAT(u.first_name, ' ', u.last_name) as teacher_name,
        u.email as teacher_email,
        COUNT(DISTINCT s.student_id) as student_count
    FROM class_teachers ct
    INNER JOIN classes c ON ct.class_id = c.class_id
    INNER JOIN users u ON ct.teacher_id = u.user_id
    LEFT JOIN students s ON c.class_id = s.class_id AND s.status = 'active'
    WHERE ct.school_id = ? AND ct.academic_year = ?
    GROUP BY ct.assignment_id
    ORDER BY c.class_name, ct.is_primary DESC
");
$stmt->execute([$school_id, $academic_year]);
$assignments = $stmt->fetchAll();

// Get all classes
$stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get all teachers (from users table with role='teacher')
$stmt = $db->prepare("
    SELECT u.user_id as teacher_id, CONCAT(u.first_name, ' ', u.last_name) as teacher_name, u.email
    FROM users u
    WHERE u.school_id = ? AND u.role = 'teacher' AND u.status = 'active'
    ORDER BY u.first_name
");
$stmt->execute([$school_id]);
$teachers = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .assignment-card {
        background: var(--card-bg);
        border: 2px solid var(--border-color);
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 15px;
    }
    
    .assignment-card.primary {
        border-left: 5px solid var(--primary-blue);
        background: linear-gradient(to right, rgba(33, 150, 243, 0.05), var(--card-bg));
    }
    
    .badge-primary-teacher {
        background: var(--primary-blue);
        color: white;
        padding: 4px 12px;
        border-radius: 15px;
        font-size: 11px;
        font-weight: 600;
    }
    </style>
    
    <div style="margin-bottom: 20px;">
        <h2><i class="fas fa-chalkboard-teacher"></i> Class Teacher Assignments</h2>
        <p style="color: var(--text-secondary);">Assign teachers to classes. Only assigned class teachers can mark attendance for their class.</p>
    </div>
    
    <!-- Academic Year Info -->
    <div class="alert alert-info" style="margin-bottom: 20px;">
        <i class="fas fa-calendar"></i>
        <strong>Current Academic Year:</strong> <?php echo htmlspecialchars($academic_year); ?>
    </div>
    
    <!-- Add Assignment Card -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-plus"></i> Assign Class Teacher</h3>
        </div>
        <div style="padding: 20px;">
            <form method="POST">
                <input type="hidden" name="action" value="assign">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr auto auto; gap: 15px; align-items: end;">
                    <div class="form-group" style="margin: 0;">
                        <label>Class <span style="color: red;">*</span></label>
                        <select name="class_id" class="form-control" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>">
                                    <?php echo htmlspecialchars($class['class_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label>Teacher <span style="color: red;">*</span></label>
                        <select name="teacher_id" class="form-control" required>
                            <option value="">-- Select Teacher --</option>
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?php echo $teacher['teacher_id']; ?>">
                                    <?php echo htmlspecialchars($teacher['teacher_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group" style="margin: 0;">
                        <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                            <input type="checkbox" name="is_primary" value="1">
                            <span>Primary Class Teacher</span>
                        </label>
                        <small style="color: var(--text-secondary);">Main teacher responsible for the class</small>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="margin: 0;">
                        <i class="fas fa-plus"></i> Assign
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Assignments List -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Current Assignments (<?php echo count($assignments); ?>)</h3>
        </div>
        <div style="padding: 20px;">
            <?php if (count($assignments) > 0): ?>
                <?php 
                $grouped = [];
                foreach ($assignments as $assignment) {
                    $grouped[$assignment['class_name']][] = $assignment;
                }
                ?>
                
                <?php foreach ($grouped as $class_name => $class_assignments): ?>
                    <div style="margin-bottom: 30px;">
                        <h4 style="margin-bottom: 15px; color: var(--primary-blue);">
                            <i class="fas fa-school"></i> <?php echo htmlspecialchars($class_name); ?>
                            <span style="font-size: 14px; font-weight: normal; color: var(--text-secondary);">
                                (<?php echo $class_assignments[0]['student_count']; ?> students)
                            </span>
                        </h4>
                        
                        <?php foreach ($class_assignments as $assignment): ?>
                            <div class="assignment-card <?php echo $assignment['is_primary'] ? 'primary' : ''; ?>">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div style="flex: 1;">
                                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                                            <h5 style="margin: 0;">
                                                <i class="fas fa-user"></i> <?php echo htmlspecialchars($assignment['teacher_name']); ?>
                                            </h5>
                                            <?php if ($assignment['is_primary']): ?>
                                                <span class="badge-primary-teacher">PRIMARY</span>
                                            <?php endif; ?>
                                            <span class="badge badge-<?php echo $assignment['status'] == 'active' ? 'success' : 'secondary'; ?>">
                                                <?php echo ucfirst($assignment['status']); ?>
                                            </span>
                                        </div>
                                        <p style="margin: 0; color: var(--text-secondary); font-size: 14px;">
                                            <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($assignment['teacher_email']); ?>
                                            &nbsp;|&nbsp;
                                            <i class="fas fa-calendar"></i> Assigned: <?php echo date('M d, Y', strtotime($assignment['assigned_date'])); ?>
                                        </p>
                                    </div>
                                    
                                    <div style="display: flex; gap: 10px;">
                                        <button class="btn btn-sm btn-info" onclick="editAssignment(this)" 
                                            data-assignment='<?php echo htmlspecialchars(json_encode($assignment), ENT_QUOTES, 'UTF-8'); ?>'
                                            title="Edit Assignment">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        
                                        <?php if ($assignment['status'] == 'active'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="toggle_status">
                                                <input type="hidden" name="assignment_id" value="<?php echo $assignment['assignment_id']; ?>">
                                                <input type="hidden" name="new_status" value="inactive">
                                                <button type="submit" class="btn btn-sm btn-warning" title="Deactivate">
                                                    <i class="fas fa-pause"></i> Deactivate
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="toggle_status">
                                                <input type="hidden" name="assignment_id" value="<?php echo $assignment['assignment_id']; ?>">
                                                <input type="hidden" name="new_status" value="active">
                                                <button type="submit" class="btn btn-sm btn-success" title="Activate">
                                                    <i class="fas fa-play"></i> Activate
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to remove this assignment?');">
                                            <input type="hidden" name="action" value="remove">
                                            <input type="hidden" name="assignment_id" value="<?php echo $assignment['assignment_id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-danger">
                                                <i class="fas fa-trash"></i> Remove
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 40px;">
                    <i class="fas fa-chalkboard-teacher" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 10px; display: block;"></i>
                    <h3>No Class Teachers Assigned</h3>
                    <p style="color: var(--text-secondary);">Use the form above to assign teachers to classes</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="alert alert-warning" style="margin-top: 20px;">
        <i class="fas fa-info-circle"></i>
        <strong>Important:</strong> Only assigned class teachers can mark attendance for their classes. Make sure to assign at least one teacher to each class.
    </div>
    
    <!-- Edit Assignment Modal -->
    <div id="editModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 80px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2><i class="fas fa-edit"></i> Edit Class Teacher Assignment</h2>
                <button onclick="closeEditModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="assignment_id" id="edit_assignment_id">
                
                <div class="form-group" style="margin-bottom: 20px;">
                    <label for="edit_class_id">Class <span style="color: red;">*</span></label>
                    <select name="class_id" id="edit_class_id" class="form-control" required>
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>">
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 20px;">
                    <label for="edit_teacher_id">Teacher <span style="color: red;">*</span></label>
                    <select name="teacher_id" id="edit_teacher_id" class="form-control" required>
                        <option value="">-- Select Teacher --</option>
                        <?php foreach ($teachers as $teacher): ?>
                            <option value="<?php echo $teacher['teacher_id']; ?>">
                                <?php echo htmlspecialchars($teacher['teacher_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 20px;">
                    <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                        <input type="checkbox" name="is_primary" id="edit_is_primary" value="1">
                        <span>Primary Class Teacher</span>
                    </label>
                    <small style="color: var(--text-secondary);">Main teacher responsible for the class</small>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Assignment
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function editAssignment(button) {
        console.log('🔵 Edit button clicked!');
        
        try {
            const assignmentDataRaw = button.getAttribute('data-assignment');
            console.log('📝 Raw assignment data:', assignmentDataRaw);
            
            if (!assignmentDataRaw) {
                throw new Error('No assignment data found on button');
            }
            
            // Decode HTML entities
            const textarea = document.createElement('textarea');
            textarea.innerHTML = assignmentDataRaw;
            const assignmentDataDecoded = textarea.value;
            console.log('✏️ Decoded assignment data:', assignmentDataDecoded);
            
            const assignment = JSON.parse(assignmentDataDecoded);
            console.log('📊 Parsed assignment object:', assignment);
            
            // Get modal
            const modal = document.getElementById('editModal');
            if (!modal) {
                throw new Error('Edit modal not found in DOM');
            }
            
            // Show modal
            modal.style.display = 'block';
            console.log('✅ Modal displayed');
            
            // Populate form fields
            document.getElementById('edit_assignment_id').value = assignment.assignment_id || '';
            document.getElementById('edit_class_id').value = assignment.class_id || '';
            document.getElementById('edit_teacher_id').value = assignment.teacher_id || '';
            document.getElementById('edit_is_primary').checked = assignment.is_primary == 1;
            
            console.log('✅✅✅ Assignment data loaded successfully!');
        } catch (error) {
            console.error('❌ Error in editAssignment:', error);
            console.error('Stack:', error.stack);
            alert('ERROR: ' + error.message + '\n\nCheck browser console (F12) for details.');
        }
    }
    
    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
    }
    
    // Close modal when clicking outside
    document.addEventListener('DOMContentLoaded', function() {
        const editModal = document.getElementById('editModal');
        if (editModal) {
            editModal.addEventListener('click', function(e) {
                if (e.target === this) {
                    closeEditModal();
                }
            });
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
