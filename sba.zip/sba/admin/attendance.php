<?php
// admin/attendance.php - Attendance Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Mark Attendance';
$current_user = check_permission(['admin', 'teacher']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle attendance submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_attendance'])) {
    $class_id = sanitize_input($_POST['class_id']);
    $date = sanitize_input($_POST['date']);
    $attendance_data = $_POST['attendance'] ?? [];
    
    try {
        $db->beginTransaction();
        
        // Delete existing attendance for this class and date
        $delete_stmt = $db->prepare("DELETE FROM attendance WHERE class_id = ? AND date = ?");
        $delete_stmt->execute([$class_id, $date]);
        
        // Insert new attendance records
        $insert_stmt = $db->prepare("
            INSERT INTO attendance (student_id, class_id, date, status, marked_by)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        foreach ($attendance_data as $student_id => $status) {
            $insert_stmt->execute([$student_id, $class_id, $date, $status, $current_user['user_id']]);
        }
        
        $db->commit();
        
        log_activity($current_user['user_id'], "Marked attendance for class ID: $class_id on $date", 'attendance', null);
        
        set_message('success', 'Attendance marked successfully!');
        redirect(APP_URL . '/admin/attendance.php?class_id=' . $class_id . '&date=' . $date);
    } catch (PDOException $e) {
        $db->rollBack();
        set_message('error', 'Error marking attendance: ' . $e->getMessage());
    }
}

// Get filter parameters
$selected_class = isset($_GET['class_id']) ? sanitize_input($_GET['class_id']) : '';
$selected_date = isset($_GET['date']) ? sanitize_input($_GET['date']) : date('Y-m-d');

// Get all classes
$classes = [];
try {
    $stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
    $stmt->execute([$school_id]);
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $classes = [];
}

// Get students if class is selected
$students = [];
$existing_attendance = [];
if ($selected_class) {
    try {
        $stmt = $db->prepare("
            SELECT s.student_id, s.admission_number, s.class_id
            FROM students s
            WHERE s.class_id = ?
            ORDER BY s.admission_number
        ");
        $stmt->execute([$selected_class]);
        $students = $stmt->fetchAll();
        // Add default first/last name for display
        foreach ($students as &$student) {
            $student['first_name'] = 'Student';
            $student['last_name'] = '';
        }
    } catch (PDOException $e) {
        $students = [];
    }
    
    // Get existing attendance for this date
    try {
        $stmt = $db->prepare("
            SELECT student_id, status 
            FROM attendance 
            WHERE class_id = ? AND date = ?
        ");
        $stmt->execute([$selected_class, $selected_date]);
        $attendance_records = $stmt->fetchAll();
        
        foreach ($attendance_records as $record) {
            $existing_attendance[$record['student_id']] = $record['status'];
        }
    } catch (PDOException $e) {
        // attendance table doesn't exist, start fresh
        $existing_attendance = [];
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Filter Bar -->
    <div class="card" style="margin-bottom: 20px;">
        <div style="padding: 20px;">
            <form method="GET" style="display: grid; grid-template-columns: 2fr 1fr auto; gap: 15px; align-items: end;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="class_id">Select Class *</label>
                    <select name="class_id" id="class_id" required onchange="this.form.submit()">
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>" <?php echo $selected_class == $class['class_id'] ? 'selected' : ''; ?>>
                                <?php echo $class['class_name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label for="date">Date *</label>
                    <input type="date" name="date" id="date" value="<?php echo $selected_date; ?>" required onchange="this.form.submit()">
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </form>
        </div>
    </div>
    
    <?php if ($selected_class && count($students) > 0): ?>
        <!-- Attendance Form -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-calendar-check"></i> Mark Attendance - <?php echo date('F d, Y', strtotime($selected_date)); ?></h3>
                <div style="display: flex; gap: 10px;">
                    <button type="button" class="btn btn-success btn-sm" onclick="markAll('present')">
                        <i class="fas fa-check"></i> All Present
                    </button>
                    <button type="button" class="btn btn-danger btn-sm" onclick="markAll('absent')">
                        <i class="fas fa-times"></i> All Absent
                    </button>
                </div>
            </div>
            
            <form method="POST" id="attendanceForm">
                <input type="hidden" name="class_id" value="<?php echo $selected_class; ?>">
                <input type="hidden" name="date" value="<?php echo $selected_date; ?>">
                
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Admission No.</th>
                                <th>Student Name</th>
                                <th style="text-align: center;">Present</th>
                                <th style="text-align: center;">Absent</th>
                                <th style="text-align: center;">Late</th>
                                <th style="text-align: center;">Excused</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $index => $student): ?>
                                <?php $current_status = $existing_attendance[$student['student_id']] ?? 'present'; ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td><strong><?php echo $student['admission_number']; ?></strong></td>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 10px;">
                                            <div style="width: 35px; height: 35px; border-radius: 8px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600;">
                                                <?php echo strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)); ?>
                                            </div>
                                            <span><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></span>
                                        </div>
                                    </td>
                                    <td style="text-align: center;">
                                        <input type="radio" name="attendance[<?php echo $student['student_id']; ?>]" 
                                               value="present" <?php echo $current_status == 'present' ? 'checked' : ''; ?>
                                               style="width: 20px; height: 20px; cursor: pointer;">
                                    </td>
                                    <td style="text-align: center;">
                                        <input type="radio" name="attendance[<?php echo $student['student_id']; ?>]" 
                                               value="absent" <?php echo $current_status == 'absent' ? 'checked' : ''; ?>
                                               style="width: 20px; height: 20px; cursor: pointer;">
                                    </td>
                                    <td style="text-align: center;">
                                        <input type="radio" name="attendance[<?php echo $student['student_id']; ?>]" 
                                               value="late" <?php echo $current_status == 'late' ? 'checked' : ''; ?>
                                               style="width: 20px; height: 20px; cursor: pointer;">
                                    </td>
                                    <td style="text-align: center;">
                                        <input type="radio" name="attendance[<?php echo $student['student_id']; ?>]" 
                                               value="excused" <?php echo $current_status == 'excused' ? 'checked' : ''; ?>
                                               style="width: 20px; height: 20px; cursor: pointer;">
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div style="padding: 20px; border-top: 1px solid var(--border-color); display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" class="btn btn-secondary" onclick="window.location.href='<?php echo APP_URL; ?>/admin/dashboard.php'">
                        Cancel
                    </button>
                    <button type="submit" name="submit_attendance" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Attendance
                    </button>
                </div>
            </form>
        </div>
    
    <?php elseif ($selected_class): ?>
        <!-- No Students -->
        <div class="card">
            <div style="padding: 60px; text-align: center;">
                <i class="fas fa-user-graduate" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 20px;"></i>
                <h3 style="margin-bottom: 10px;">No Students in This Class</h3>
                <p style="color: var(--text-secondary); margin-bottom: 20px;">Add students to this class to mark attendance</p>
                <a href="<?php echo APP_URL; ?>/admin/students.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add Students
                </a>
            </div>
        </div>
    
    <?php else: ?>
        <!-- Select Class Prompt -->
        <div class="card">
            <div style="padding: 60px; text-align: center;">
                <i class="fas fa-calendar-check" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 20px;"></i>
                <h3 style="margin-bottom: 10px;">Select a Class</h3>
                <p style="color: var(--text-secondary);">Choose a class from the dropdown above to mark attendance</p>
            </div>
        </div>
    <?php endif; ?>
    
    <script>
    function markAll(status) {
        const radios = document.querySelectorAll(`input[type="radio"][value="${status}"]`);
        radios.forEach(radio => {
            radio.checked = true;
        });
    }
    
    // Confirm before leaving if changes made
    let formChanged = false;
    document.getElementById('attendanceForm')?.addEventListener('change', function() {
        formChanged = true;
    });
    
    window.addEventListener('beforeunload', function(e) {
        if (formChanged) {
            e.preventDefault();
            e.returnValue = '';
        }
    });
    
    document.getElementById('attendanceForm')?.addEventListener('submit', function() {
        formChanged = false;
    });
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
