<?php
// admin/timetable.php - Timetable Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Timetable Management';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Auto-create class_subjects table if it doesn't exist
try {
    $db->query("SELECT 1 FROM class_subjects LIMIT 1");
} catch (PDOException $e) {
    try {
        $sql = "CREATE TABLE IF NOT EXISTS `class_subjects` (
          `class_subject_id` int(11) NOT NULL AUTO_INCREMENT,
          `class_id` int(11) NOT NULL,
          `subject_id` int(11) NOT NULL,
          `teacher_id` int(11) NULL,
          PRIMARY KEY (`class_subject_id`),
          UNIQUE KEY `idx_class_subject` (`class_id`, `subject_id`),
          KEY `idx_teacher` (`teacher_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        $db->exec($sql);
    } catch (PDOException $e) {
        // Table creation failed, will handle error when accessing
    }
}

// Auto-create timetable table if it doesn't exist
try {
    $db->query("SELECT 1 FROM timetable LIMIT 1");
} catch (PDOException $e) {
    try {
        $sql = "CREATE TABLE IF NOT EXISTS `timetable` (
          `timetable_id` int(11) NOT NULL AUTO_INCREMENT,
          `school_id` int(11) NOT NULL,
          `class_id` int(11) NOT NULL,
          `subject_id` int(11) NOT NULL,
          `teacher_id` int(11),
          `day_of_week` varchar(20) NOT NULL,
          `start_time` time NOT NULL,
          `end_time` time NOT NULL,
          `room_number` varchar(50),
          `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`timetable_id`),
          KEY `school_id` (`school_id`),
          KEY `class_id` (`class_id`),
          KEY `subject_id` (`subject_id`),
          KEY `teacher_id` (`teacher_id`),
          KEY `day_of_week` (`day_of_week`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        $db->exec($sql);
    } catch (PDOException $e) {
        // Table creation failed, will handle error when accessing
    }
}

// AJAX endpoint to get assigned teacher for a subject
if (isset($_GET['ajax']) && $_GET['ajax'] == 'get_teacher') {
    header('Content-Type: application/json');
    
    $class_id = $_GET['class_id'] ?? null;
    $subject_id = $_GET['subject_id'] ?? null;
    
    if ($class_id && $subject_id) {
        try {
            $stmt = $db->prepare("
                SELECT teacher_id 
                FROM class_subjects 
                WHERE class_id = ? AND subject_id = ?
                LIMIT 1
            ");
            $stmt->execute([$class_id, $subject_id]);
            $result = $stmt->fetch();
            
            echo json_encode([
                'success' => true,
                'teacher_id' => $result ? $result['teacher_id'] : null
            ]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'teacher_id' => null]);
        }
    } else {
        echo json_encode(['success' => false, 'teacher_id' => null]);
    }
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $class_id = sanitize_input($_POST['class_id']);
            $subject_id = sanitize_input($_POST['subject_id']);
            $teacher_id = sanitize_input($_POST['teacher_id']);
            $day_of_week = sanitize_input($_POST['day_of_week']);
            $start_time = sanitize_input($_POST['start_time']);
            $end_time = sanitize_input($_POST['end_time']);
            $room_number = sanitize_input($_POST['room_number']);
            
            try {
                $stmt = $db->prepare("
                    INSERT INTO timetable (school_id, class_id, subject_id, teacher_id, day_of_week, start_time, end_time, room_number)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$school_id, $class_id, $subject_id, $teacher_id, $day_of_week, $start_time, $end_time, $room_number]);
                
                log_activity($current_user['user_id'], "Added timetable entry", 'timetable');
                
                set_message('success', 'Timetable entry added successfully!');
                redirect(APP_URL . '/admin/timetable.php?class_id=' . $class_id);
            } catch (PDOException $e) {
                set_message('error', 'Error adding timetable entry: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            $timetable_id = sanitize_input($_POST['timetable_id']);
            
            try {
                $stmt = $db->prepare("DELETE FROM timetable WHERE timetable_id = ?");
                $stmt->execute([$timetable_id]);
                
                log_activity($current_user['user_id'], "Deleted timetable entry ID: $timetable_id", 'timetable');
                
                set_message('success', 'Timetable entry deleted successfully!');
                redirect(APP_URL . '/admin/timetable.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting timetable entry: ' . $e->getMessage());
            }
        }
    }
}

// Get all classes
$stmt = $db->prepare("
    SELECT class_id, class_name 
    FROM classes 
    WHERE school_id = ? 
    ORDER BY class_name
");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get selected class
$selected_class_id = $_GET['class_id'] ?? ($classes[0]['class_id'] ?? null);

// Get subjects and teachers
$subjects = [];
$teachers = [];
$timetable = [];

if ($selected_class_id) {
    // Get subjects for this class
    try {
        $stmt = $db->prepare("
            SELECT DISTINCT s.subject_id, s.subject_name, s.subject_code
            FROM subjects s
            INNER JOIN class_subjects cs ON s.subject_id = cs.subject_id
            WHERE cs.class_id = ?
            ORDER BY s.subject_name
        ");
        $stmt->execute([$selected_class_id]);
        $subjects = $stmt->fetchAll();
    } catch (PDOException $e) {
        // class_subjects table may not exist or be empty
        $subjects = [];
    }
    
    // Get teachers
    $stmt = $db->prepare("
        SELECT user_id, first_name, last_name
        FROM users
        WHERE school_id = ? AND role = 'teacher' AND status = 'active'
        ORDER BY first_name, last_name
    ");
    $stmt->execute([$school_id]);
    $teachers = $stmt->fetchAll();
    
    // Get timetable for selected class
    try {
        $stmt = $db->prepare("
            SELECT 
                t.*,
                s.subject_name,
                s.subject_code,
                u.first_name,
                u.last_name
            FROM timetable t
            INNER JOIN subjects s ON t.subject_id = s.subject_id
            LEFT JOIN users u ON t.teacher_id = u.user_id
            WHERE t.class_id = ?
            ORDER BY 
                FIELD(t.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
                t.start_time
        ");
        $stmt->execute([$selected_class_id]);
        $timetable_entries = $stmt->fetchAll();
    } catch (PDOException $e) {
        // timetable table may not exist
        $timetable_entries = [];
    }
    
    // Group by day
    $timetable = [];
    foreach ($timetable_entries as $entry) {
        $timetable[$entry['day_of_week']][] = $entry;
    }
}

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Class Selection -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-filter"></i> Select Class</h3>
        </div>
        <div style="padding: 20px;">
            <form method="GET">
                <div style="display: grid; grid-template-columns: 1fr auto; gap: 15px; align-items: end;">
                    <div class="form-group" style="margin: 0;">
                        <label for="class_id">Class</label>
                        <select name="class_id" id="class_id" onchange="this.form.submit()">
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>" 
                                        <?php echo $selected_class_id == $class['class_id'] ? 'selected' : ''; ?>>
                                    <?php echo $class['class_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-eye"></i> View Timetable
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <?php if ($selected_class_id): ?>
        <!-- Add Entry Form -->
        <div class="card" style="margin-bottom: 30px;">
            <div class="card-header">
                <h3><i class="fas fa-plus"></i> Add Timetable Entry</h3>
            </div>
            <div style="padding: 20px;">
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    <input type="hidden" name="class_id" value="<?php echo $selected_class_id; ?>">
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                        <div class="form-group">
                            <label for="day_of_week">Day *</label>
                            <select name="day_of_week" id="day_of_week" required>
                                <option value="">-- Select Day --</option>
                                <?php foreach ($days as $day): ?>
                                    <option value="<?php echo $day; ?>"><?php echo $day; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="subject_id">Subject *</label>
                            <select name="subject_id" id="subject_id" required>
                                <option value="">-- Select Subject --</option>
                                <?php foreach ($subjects as $subject): ?>
                                    <option value="<?php echo $subject['subject_id']; ?>">
                                        <?php echo $subject['subject_name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="teacher_id">
                                Teacher * 
                                <small id="teacher_auto_label" style="color: #4caf50; display: none;">
                                    <i class="fas fa-check-circle"></i> Auto-selected
                                </small>
                            </label>
                            <select name="teacher_id" id="teacher_id" required>
                                <option value="">-- Select Teacher --</option>
                                <?php foreach ($teachers as $teacher): ?>
                                    <option value="<?php echo $teacher['user_id']; ?>">
                                        <?php echo $teacher['first_name'] . ' ' . $teacher['last_name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="start_time">Start Time *</label>
                            <input type="time" name="start_time" id="start_time" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="end_time">End Time *</label>
                            <input type="time" name="end_time" id="end_time" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="room_number">Room/Location</label>
                            <input type="text" name="room_number" id="room_number" placeholder="e.g., Room 101">
                        </div>
                    </div>
                    
                    <div style="margin-top: 15px;">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add Entry
                        </button>
                    </div>
                </form>
            </div>
        </div>
    
        <!-- Timetable Display -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-calendar-alt"></i> Weekly Timetable</h3>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 100px;">Day</th>
                            <th>Time</th>
                            <th>Subject</th>
                            <th>Teacher</th>
                            <th>Room</th>
                            <th style="width: 100px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($timetable) > 0): ?>
                            <?php foreach ($days as $day): ?>
                                <?php if (isset($timetable[$day]) && count($timetable[$day]) > 0): ?>
                                    <?php $day_entries = $timetable[$day]; ?>
                                    <?php foreach ($day_entries as $index => $entry): ?>
                                        <tr>
                                            <?php if ($index == 0): ?>
                                                <td rowspan="<?php echo count($day_entries); ?>" style="background: var(--bg-secondary); font-weight: 600; vertical-align: middle;">
                                                    <?php echo $day; ?>
                                                </td>
                                            <?php endif; ?>
                                            <td>
                                                <strong><?php echo date('h:i A', strtotime($entry['start_time'])); ?></strong>
                                                -
                                                <?php echo date('h:i A', strtotime($entry['end_time'])); ?>
                                            </td>
                                            <td>
                                                <strong><?php echo $entry['subject_name']; ?></strong><br>
                                                <small style="color: var(--text-secondary);"><?php echo $entry['subject_code']; ?></small>
                                            </td>
                                            <td>
                                                <?php if ($entry['first_name']): ?>
                                                    <?php echo $entry['first_name'] . ' ' . $entry['last_name']; ?>
                                                <?php else: ?>
                                                    <span style="color: var(--text-secondary);">Not Assigned</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo $entry['room_number'] ?: '-'; ?>
                                            </td>
                                            <td>
                                                <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this entry?');">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="timetable_id" value="<?php echo $entry['timetable_id']; ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td style="background: var(--bg-secondary); font-weight: 600;"><?php echo $day; ?></td>
                                        <td colspan="5" style="text-align: center; color: var(--text-secondary); padding: 20px;">
                                            No classes scheduled
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 60px 20px;">
                                    <i class="fas fa-calendar-times" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                                    <h3 style="margin-bottom: 10px;">No Timetable Entries</h3>
                                    <p style="color: var(--text-secondary);">
                                        Add entries using the form above to create the timetable.
                                    </p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i>
            <strong>Select a Class</strong> to view and manage its timetable.
        </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>

<script>
// Auto-select teacher when subject is selected
document.addEventListener('DOMContentLoaded', function() {
    const subjectSelect = document.getElementById('subject_id');
    const teacherSelect = document.getElementById('teacher_id');
    const autoLabel = document.getElementById('teacher_auto_label');
    const classId = <?php echo $selected_class_id ? $selected_class_id : 'null'; ?>;
    
    if (subjectSelect && teacherSelect && classId) {
        subjectSelect.addEventListener('change', function() {
            const subjectId = this.value;
            
            // Hide auto-selected label
            if (autoLabel) autoLabel.style.display = 'none';
            
            if (subjectId) {
                // Show loading state
                teacherSelect.disabled = true;
                const originalHTML = teacherSelect.innerHTML;
                teacherSelect.innerHTML = '<option value="">Loading...</option>';
                
                // Fetch assigned teacher
                fetch(`?ajax=get_teacher&class_id=${classId}&subject_id=${subjectId}`)
                    .then(response => response.json())
                    .then(data => {
                        // Restore teacher options
                        teacherSelect.innerHTML = originalHTML;
                        teacherSelect.disabled = false;
                        
                        if (data.success && data.teacher_id) {
                            // Auto-select the assigned teacher
                            teacherSelect.value = data.teacher_id;
                            
                            // Show auto-selected label
                            if (autoLabel) {
                                autoLabel.style.display = 'inline';
                            }
                            
                            // Visual feedback
                            teacherSelect.style.background = '#e8f5e9';
                            setTimeout(() => {
                                teacherSelect.style.background = '';
                            }, 1500);
                        } else {
                            // No teacher assigned, reset selection
                            teacherSelect.value = '';
                            if (autoLabel) autoLabel.style.display = 'none';
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching teacher:', error);
                        teacherSelect.innerHTML = originalHTML;
                        teacherSelect.disabled = false;
                        teacherSelect.value = '';
                        if (autoLabel) autoLabel.style.display = 'none';
                    });
            } else {
                // Reset teacher selection if no subject selected
                teacherSelect.value = '';
            }
        });
        
        // Hide auto-label if teacher is manually changed
        teacherSelect.addEventListener('change', function() {
            if (autoLabel && autoLabel.style.display === 'inline') {
                setTimeout(() => {
                    if (autoLabel) autoLabel.style.display = 'none';
                }, 2000);
            }
        });
    }
});
</script>
