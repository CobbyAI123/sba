<?php
// admin/edit-proprietor.php - Edit Proprietor
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Edit Proprietor';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get proprietor ID
$user_id = (int)($_GET['id'] ?? 0);

// Fetch proprietor details
$stmt = $db->prepare("SELECT * FROM users WHERE user_id = ? AND role = 'proprietor' AND school_id = ?");
$stmt->execute([$user_id, $school_id]);
$proprietor = $stmt->fetch();

if (!$proprietor) {
    set_message('error', 'Proprietor not found!');
    redirect(APP_URL . '/admin/proprietors.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $status = $_POST['status'];
    
    try {
        // Check if email exists for another user
        $stmt = $db->prepare("SELECT user_id FROM users WHERE email = ? AND user_id != ?");
        $stmt->execute([$email, $user_id]);
        if ($stmt->fetch()) {
            throw new Exception('Email already exists for another user!');
        }
        
        // Update proprietor
        $stmt = $db->prepare("
            UPDATE users 
            SET first_name = ?, last_name = ?, email = ?, phone = ?, address = ?, status = ?, updated_at = NOW()
            WHERE user_id = ? AND school_id = ?
        ");
        $stmt->execute([$first_name, $last_name, $email, $phone, $address, $status, $user_id, $school_id]);
        
        // Update password if provided
        if (!empty($_POST['password'])) {
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $stmt = $db->prepare("UPDATE users SET password = ? WHERE user_id = ?");
            $stmt->execute([$password, $user_id]);
        }
        
        log_activity($current_user['user_id'], "Updated proprietor: $first_name $last_name", 'users', $user_id);
        set_message('success', 'Proprietor updated successfully!');
        redirect(APP_URL . '/admin/proprietors.php');
    } catch (Exception $e) {
        set_message('error', 'Error: ' . $e->getMessage());
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fas fa-edit"></i>  Edit Proprietor</h1>
    </div>

    <div class="page-header">
        
        <div class="page-actions">
            <a href="<?php echo APP_URL; ?>/admin/proprietors.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back
            </a>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header">
            <h3>Proprietor Information</h3>
        </div>
        <div style="padding: 30px;">
            <form method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label>First Name *</label>
                        <input type="text" name="first_name" class="form-control" 
                               value="<?php echo htmlspecialchars($proprietor['first_name']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Last Name *</label>
                        <input type="text" name="last_name" class="form-control" 
                               value="<?php echo htmlspecialchars($proprietor['last_name']); ?>" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Email *</label>
                        <input type="email" name="email" class="form-control" 
                               value="<?php echo htmlspecialchars($proprietor['email']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" class="form-control" 
                               value="<?php echo htmlspecialchars($proprietor['phone'] ?? ''); ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Address</label>
                    <textarea name="address" class="form-control" rows="3"><?php echo htmlspecialchars($proprietor['address'] ?? ''); ?></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Status *</label>
                        <select name="status" class="form-control" required>
                            <option value="active" <?php echo $proprietor['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo $proprietor['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>New Password (leave blank to keep current)</label>
                        <input type="password" name="password" class="form-control" 
                               placeholder="Enter new password">
                    </div>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Proprietor
                    </button>
                    <a href="<?php echo APP_URL; ?>/admin/proprietors.php" class="btn btn-secondary">
                        Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <style>
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-bottom: 20px;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: var(--text-primary);
    }
    
    .form-control {
        width: 100%;
        padding: 10px 15px;
        border: 1px solid #ddd;
        border-radius: 8px;
        font-size: 14px;
    }
    
    .form-control:focus {
        outline: none;
        border-color: var(--primary-blue);
        box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
    }
    
    @media (max-width: 768px) {
        .form-row {
            grid-template-columns: 1fr;
        }
    }
    </style>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
