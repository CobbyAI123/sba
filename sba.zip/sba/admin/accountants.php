<?php
// admin/accountants.php - Accountant Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/default-passwords.php';

$page_title = 'Manage Accountants';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $email = sanitize_input($_POST['email']);
            $phone = sanitize_input($_POST['phone']);
            
            try {
                // Auto-generate username from email
                $base_username = strtolower(explode('@', $email)[0]);
                $username = $base_username;
                $counter = 1;
                
                // Ensure unique username within school
                while (true) {
                    $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE username = ? AND school_id = ?");
                    $check_stmt->execute([$username, $school_id]);
                    if ($check_stmt->fetch()['count'] == 0) {
                        break;
                    }
                    $username = $base_username . '_' . $counter;
                    $counter++;
                }
                
                // Ensure unique email within school
                $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE email = ? AND school_id = ?");
                $check_stmt->execute([$email, $school_id]);
                if ($check_stmt->fetch()['count'] > 0) {
                    throw new Exception('Email already exists!');
                }
                
                // Auto-generate password: accountant123
                $default_credentials = generate_default_credentials('accountant');
                $default_password = $default_credentials['password'];
                $password = $default_credentials['hash'];
                
                $stmt = $db->prepare("
                    INSERT INTO users (school_id, username, email, password_hash, first_name, last_name, phone, role, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'accountant', 'active')
                ");
                $stmt->execute([$school_id, $username, $email, $password, $first_name, $last_name, $phone]);
                
                $user_id = $db->lastInsertId();
                log_activity($current_user['user_id'], "Added accountant: $first_name $last_name", 'users', $user_id);
                
                set_message('success', "Accountant added successfully! Login - Username: $username, Password: $default_password");
                redirect(APP_URL . '/admin/accountants.php');
            } catch (Exception $e) {
                set_message('error', 'Error adding accountant: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'edit') {
            $user_id = sanitize_input($_POST['user_id']);
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $email = sanitize_input($_POST['email']);
            $username = sanitize_input($_POST['username']);
            $phone = sanitize_input($_POST['phone']);
            $status = sanitize_input($_POST['status']);
            
            try {
                $stmt = $db->prepare("
                    UPDATE users 
                    SET first_name = ?, last_name = ?, email = ?, username = ?, phone = ?, status = ?
                    WHERE user_id = ? AND school_id = ? AND role = 'accountant'
                ");
                $stmt->execute([$first_name, $last_name, $email, $username, $phone, $status, $user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Updated accountant ID: $user_id", 'users', $user_id);
                
                set_message('success', 'Accountant updated successfully!');
                redirect(APP_URL . '/admin/accountants.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating accountant: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            $user_id = sanitize_input($_POST['user_id']);
            
            try {
                $stmt = $db->prepare("DELETE FROM users WHERE user_id = ? AND school_id = ? AND role = 'accountant'");
                $stmt->execute([$user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted accountant ID: $user_id", 'users', $user_id);
                
                set_message('success', 'Accountant deleted successfully!');
                redirect(APP_URL . '/admin/accountants.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting accountant: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'reset_password') {
            $user_id = sanitize_input($_POST['user_id']);
            $default_credentials = generate_default_credentials('accountant');
            $default_password = $default_credentials['password'];
            $new_password = $default_credentials['hash'];
            
            try {
                $stmt = $db->prepare("UPDATE users SET password_hash = ? WHERE user_id = ? AND school_id = ? AND role = 'accountant'");
                $stmt->execute([$new_password, $user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Reset password for accountant ID: $user_id", 'users', $user_id);
                
                set_message('success', "Password reset to: $default_password");
                redirect(APP_URL . '/admin/accountants.php');
            } catch (PDOException $e) {
                set_message('error', 'Error resetting password: ' . $e->getMessage());
            }
        }
    }
}

// Get all accountants
$stmt = $db->prepare("
    SELECT * FROM users 
    WHERE school_id = ? AND role = 'accountant'
    ORDER BY first_name, last_name
");
$stmt->execute([$school_id]);
$accountants = $stmt->fetchAll();

// Get statistics
$total_accountants = count($accountants);
$active_accountants = count(array_filter($accountants, function($a) { return $a['status'] == 'active'; }));
$inactive_accountants = $total_accountants - $active_accountants;

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Statistics Cards -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-calculator"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $total_accountants; ?></h3>
                <p>Total Accountants</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $active_accountants; ?></h3>
                <p>Active</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon orange">
                <i class="fas fa-pause-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $inactive_accountants; ?></h3>
                <p>Inactive</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-user-plus"></i>
            </div>
            <div class="stat-details">
                <h3><button type="button" onclick="showAddModal()" class="btn btn-primary btn-sm">Add New</button></h3>
                <p>Add Accountant</p>
            </div>
        </div>
    </div>
    
    <!-- View Toggle & Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; gap: 10px;">
            <button class="btn btn-primary" onclick="showAddModal()">
                <i class="fas fa-plus"></i> Add Accountant
            </button>
            
            <!-- View Toggle -->
            <div class="btn-group" style="display: inline-flex; border: 2px solid var(--border-color); border-radius: 8px; overflow: hidden;">
                <button id="btnListView" onclick="setView('list')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--primary-blue); color: white;">
                    <i class="fas fa-list"></i> List
                </button>
                <button id="btnGridView" onclick="setView('grid')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--bg-secondary); color: var(--text-primary);">
                    <i class="fas fa-th"></i> Grid
                </button>
            </div>
        </div>
        
        <div style="font-weight: 600; color: var(--text-secondary);">
            Total: <?php echo count($accountants); ?>
        </div>
    </div>
    
    <!-- List View -->
    <div id="accountantsTable" class="card">
        <div class="card-header">
            <h3><i class="fas fa-calculator"></i> Accountants List</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Phone</th>
                        <th>Login Credentials</th>
                        <th>Status</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($accountants) > 0): ?>
                        <?php $count = 1; ?>
                        <?php foreach ($accountants as $accountant): ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 35px; height: 35px; border-radius: 8px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 12px;">
                                            <?php echo strtoupper(substr($accountant['first_name'], 0, 1) . substr($accountant['last_name'], 0, 1)); ?>
                                        </div>
                                        <strong><?php echo $accountant['first_name'] . ' ' . $accountant['last_name']; ?></strong>
                                    </div>
                                </td>
                                <td><?php echo $accountant['email']; ?></td>
                                <td><?php echo $accountant['username']; ?></td>
                                <td><?php echo $accountant['phone'] ?: '-'; ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <div id="cred-hidden-<?php echo $accountant['user_id']; ?>" style="font-family: monospace; font-size: 12px;">
                                            ••••••••
                                        </div>
                                        <div id="cred-shown-<?php echo $accountant['user_id']; ?>" style="display: none; font-family: monospace; font-size: 11px; line-height: 1.4;">
                                            <strong>User:</strong> <?php echo htmlspecialchars($accountant['username']); ?><br>
                                            <strong>Pass:</strong> accountant123
                                        </div>
                                        <button onclick="toggleCredentials(<?php echo $accountant['user_id']; ?>); return false;" type="button" class="btn btn-sm" style="padding: 4px 8px; background: var(--primary-blue); color: white; border: none; border-radius: 4px; cursor: pointer;">
                                            <i class="fas fa-eye" id="eye-<?php echo $accountant['user_id']; ?>"></i>
                                        </button>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $accountant['status'] == 'active' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($accountant['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($accountant['created_at'])); ?></td>
                                <td>
                                    <button type="button" onclick="editAccountant(<?php echo htmlspecialchars(json_encode($accountant)); ?>)" 
                                            class="btn btn-info btn-sm" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="openPasswordModal(<?php echo $accountant['user_id']; ?>, '<?php echo $accountant['first_name'] . ' ' . $accountant['last_name']; ?>')" 
                                            class="btn btn-warning btn-sm" title="Reset Password">
                                        <i class="fas fa-key"></i>
                                    </button>
                                    <button onclick="deleteAccountant(<?php echo $accountant['user_id']; ?>, '<?php echo $accountant['first_name'] . ' ' . $accountant['last_name']; ?>')" 
                                            class="btn btn-danger btn-sm" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 60px 20px;">
                                <i class="fas fa-calculator" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                                <h3 style="margin-bottom: 10px;">No Accountants Found</h3>
                                <p style="color: var(--text-secondary); margin-bottom: 20px;">
                                    Start by adding your first accountant to manage finances.
                                </p>
                                <button type="button" onclick="showAddModal()" class="btn btn-primary">
                                    <i class="fas fa-plus"></i> Add First Accountant
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Grid View -->
    <div id="accountantsGrid" style="display: none; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
        <?php foreach ($accountants as $accountant): ?>
            <div class="card" style="padding: 20px;">
                <div style="text-align: center; margin-bottom: 15px;">
                    <div style="width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 28px; margin: 0 auto;">
                        <?php echo strtoupper(substr($accountant['first_name'], 0, 1) . substr($accountant['last_name'], 0, 1)); ?>
                    </div>
                </div>
                
                <h4 style="text-align: center; margin: 0 0 5px 0;">
                    <?php echo htmlspecialchars($accountant['first_name'] . ' ' . $accountant['last_name']); ?>
                </h4>
                <p style="text-align: center; color: var(--text-secondary); font-size: 12px; margin: 0 0 15px 0;">
                    <i class="fas fa-calculator"></i> Accountant
                </p>
                
                <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-bottom: 12px; font-size: 13px;">
                    <div style="margin-bottom: 8px;">
                        <i class="fas fa-envelope" style="width: 20px;"></i> 
                        <strong>Email:</strong> <span style="font-size: 11px;"><?php echo htmlspecialchars($accountant['email']); ?></span>
                    </div>
                    <div style="margin-bottom: 8px;">
                        <i class="fas fa-user" style="width: 20px;"></i> 
                        <strong>Username:</strong> <?php echo htmlspecialchars($accountant['username']); ?>
                    </div>
                    <div>
                        <i class="fas fa-phone" style="width: 20px;"></i> 
                        <strong>Phone:</strong> <?php echo htmlspecialchars($accountant['phone'] ?: 'N/A'); ?>
                    </div>
                </div>
                
                <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-bottom: 12px; font-size: 12px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <strong><i class="fas fa-key"></i> Login Credentials</strong>
                        <button onclick="toggleCredentials(<?php echo $accountant['user_id']; ?>); return false;" type="button" class="btn btn-sm" style="padding: 4px 8px; background: var(--primary-blue); color: white; border: none; border-radius: 4px; cursor: pointer;">
                            <i class="fas fa-eye" id="eye-<?php echo $accountant['user_id']; ?>"></i>
                        </button>
                    </div>
                    <div id="cred-hidden-<?php echo $accountant['user_id']; ?>" style="font-family: monospace; color: var(--text-primary);">
                        ••••••••
                    </div>
                    <div id="cred-shown-<?php echo $accountant['user_id']; ?>" style="display: none; font-family: monospace; line-height: 1.6; color: var(--text-primary);">
                        <strong>Username:</strong> <?php echo htmlspecialchars($accountant['username']); ?><br>
                        <strong>Password:</strong> accountant123
                    </div>
                </div>
                
                <div style="text-align: center; margin-bottom: 12px;">
                    <span class="badge badge-<?php echo $accountant['status'] == 'active' ? 'success' : 'warning'; ?>">
                        <?php echo ucfirst($accountant['status']); ?>
                    </span>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px;">
                    <button class="btn btn-sm btn-info" onclick="editAccountant(<?php echo htmlspecialchars(json_encode($accountant)); ?>)">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-warning" onclick="openPasswordModal(<?php echo $accountant['user_id']; ?>, '<?php echo $accountant['first_name'] . ' ' . $accountant['last_name']; ?>')">
                        <i class="fas fa-key"></i>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteAccountant(<?php echo $accountant['user_id']; ?>, '<?php echo $accountant['first_name'] . ' ' . $accountant['last_name']; ?>')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Add/Edit Accountant Modal -->
    <div id="accountantModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 700px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Add Accountant</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="accountantForm">
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="user_id" id="userId">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label for="first_name">First Name *</label>
                        <input type="text" name="first_name" id="first_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name *</label>
                        <input type="text" name="last_name" id="last_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" name="email" id="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="username">Username *</label>
                        <input type="text" name="username" id="username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="tel" name="phone" id="phone">
                    </div>
                    
                    <div class="form-group" id="statusGroup" style="display: none;">
                        <label for="status">Status *</label>
                        <select name="status" id="status" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                
                <!-- Password Info for Add Mode -->
                <div id="passwordInfo" style="background: #E3F2FD; border-left: 4px solid #2196F3; padding: 12px; border-radius: 5px; margin-top: 15px; display: none;">
                    <p style="margin: 0; color: #1976D2; font-size: 14px;">
                        <i class="fas fa-info-circle"></i> <strong>Default Password:</strong> accountant123 (will be auto-generated)
                    </p>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> <span id="submitText">Save Accountant</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Reset Password Modal -->
    <div id="passwordModal" class="modal">
        <div class="modal-content" style="max-width: 400px;">
            <div class="modal-header">
                <h3><i class="fas fa-key"></i> Reset Password</h3>
                <span class="close" onclick="closePasswordModal()">&times;</span>
            </div>
            <form method="POST" id="passwordForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="user_id" id="password_user_id">
                
                <p id="password_user_name" style="margin-bottom: 20px; color: var(--text-secondary); font-weight: 500;"></p>
                
                <div class="form-group">
                    <label for="new_password">New Password *</label>
                    <input type="password" name="new_password" id="new_password" required minlength="6" class="form-control">
                    <small style="color: var(--text-secondary);">Minimum 6 characters</small>
                </div>
                
                <div class="modal-footer">
                    <button type="button" onclick="closePasswordModal()" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-key"></i> Reset Password
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Form -->
    <form method="POST" id="deleteForm" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="user_id" id="delete_user_id">
    </form>
    
    <script>
    // View Toggle Functions
    function setView(view) {
        const table = document.getElementById('accountantsTable');
        const grid = document.getElementById('accountantsGrid');
        const btnList = document.getElementById('btnListView');
        const btnGrid = document.getElementById('btnGridView');
        
        if (view === 'grid') {
            table.style.display = 'none';
            grid.style.display = 'grid';
            btnList.style.background = 'var(--bg-secondary)';
            btnList.style.color = 'var(--text-primary)';
            btnGrid.style.background = 'var(--primary-blue)';
            btnGrid.style.color = 'white';
            localStorage.setItem('accountantView', 'grid');
        } else {
            table.style.display = 'block';
            grid.style.display = 'none';
            btnList.style.background = 'var(--primary-blue)';
            btnList.style.color = 'white';
            btnGrid.style.background = 'var(--bg-secondary)';
            btnGrid.style.color = 'var(--text-primary)';
            localStorage.setItem('accountantView', 'list');
        }
    }
    
    // Toggle Credentials Visibility
    function toggleCredentials(userId) {
        const hidden = document.getElementById('cred-hidden-' + userId);
        const shown = document.getElementById('cred-shown-' + userId);
        const eyes = document.querySelectorAll('#eye-' + userId);
        
        if (hidden.style.display === 'none') {
            hidden.style.display = 'block';
            shown.style.display = 'none';
            eyes.forEach(eye => eye.className = 'fas fa-eye');
        } else {
            hidden.style.display = 'none';
            shown.style.display = 'block';
            eyes.forEach(eye => eye.className = 'fas fa-eye-slash');
        }
    }
    
    // Load saved view preference
    window.addEventListener('DOMContentLoaded', function() {
        const savedView = localStorage.getItem('accountantView') || 'list';
        setView(savedView);
    });
    
    function showAddModal() {
        document.getElementById('accountantModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Add Accountant';
        document.getElementById('formAction').value = 'add';
        document.getElementById('accountantForm').reset();
        document.getElementById('userId').value = '';
        document.getElementById('passwordInfo').style.display = 'block';
        document.getElementById('statusGroup').style.display = 'none';
        document.getElementById('submitText').textContent = 'Save Accountant';
    }
    
    function editAccountant(accountant) {
        document.getElementById('accountantModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Edit Accountant';
        document.getElementById('formAction').value = 'edit';
        document.getElementById('userId').value = accountant.user_id;
        document.getElementById('first_name').value = accountant.first_name;
        document.getElementById('last_name').value = accountant.last_name;
        document.getElementById('email').value = accountant.email;
        document.getElementById('username').value = accountant.username;
        document.getElementById('phone').value = accountant.phone || '';
        document.getElementById('status').value = accountant.status;
        document.getElementById('passwordInfo').style.display = 'none';
        document.getElementById('statusGroup').style.display = 'block';
        document.getElementById('submitText').textContent = 'Update Accountant';
    }
    
    function closeModal() {
        document.getElementById('accountantModal').style.display = 'none';
    }
    
    function openPasswordModal(userId, userName) {
        document.getElementById('password_user_id').value = userId;
        document.getElementById('password_user_name').textContent = 'Reset password for: ' + userName;
        document.getElementById('passwordModal').style.display = 'block';
    }
    
    function closePasswordModal() {
        document.getElementById('passwordModal').style.display = 'none';
    }
    
    function deleteAccountant(userId, userName) {
        if (confirm('Are you sure you want to delete ' + userName + '? This action cannot be undone.')) {
            document.getElementById('delete_user_id').value = userId;
            document.getElementById('deleteForm').submit();
        }
    }
    
    window.onclick = function(event) {
        if (event.target.id === 'accountantModal') {
            event.target.style.display = 'none';
        }
        if (event.target.id === 'passwordModal') {
            event.target.style.display = 'none';
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
