<?php
// admin/manage-hometowns.php - Manage Hometowns/Routes and Bus Fees
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Manage Hometowns & Routes';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action == 'add') {
            $hometown_name = sanitize_input($_POST['hometown_name']);
            $route_name = sanitize_input($_POST['route_name']);
            $bus_fee = floatval($_POST['bus_fee']);
            $distance_km = !empty($_POST['distance_km']) ? floatval($_POST['distance_km']) : null;
            $description = sanitize_input($_POST['description']);
            
            try {
                $stmt = $db->prepare("
                    INSERT INTO hometowns (school_id, hometown_name, route_name, bus_fee, distance_km, description, created_by)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$school_id, $hometown_name, $route_name, $bus_fee, $distance_km, $description, $current_user['user_id']]);
                set_message('success', 'Hometown/Route added successfully!');
            } catch (PDOException $e) {
                set_message('error', 'Error adding hometown: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/manage-hometowns.php');
        }
        
        if ($action == 'edit') {
            $hometown_id = intval($_POST['hometown_id']);
            $hometown_name = sanitize_input($_POST['hometown_name']);
            $route_name = sanitize_input($_POST['route_name']);
            $bus_fee = floatval($_POST['bus_fee']);
            $distance_km = !empty($_POST['distance_km']) ? floatval($_POST['distance_km']) : null;
            $description = sanitize_input($_POST['description']);
            $status = sanitize_input($_POST['status']);
            
            try {
                $stmt = $db->prepare("
                    UPDATE hometowns 
                    SET hometown_name = ?, route_name = ?, bus_fee = ?, distance_km = ?, description = ?, status = ?
                    WHERE hometown_id = ? AND school_id = ?
                ");
                $stmt->execute([$hometown_name, $route_name, $bus_fee, $distance_km, $description, $status, $hometown_id, $school_id]);
                set_message('success', 'Hometown/Route updated successfully!');
            } catch (PDOException $e) {
                set_message('error', 'Error updating hometown: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/manage-hometowns.php');
        }
        
        if ($action == 'delete') {
            $hometown_id = intval($_POST['hometown_id']);
            
            try {
                // Check if any students are assigned to this hometown
                $stmt = $db->prepare("SELECT COUNT(*) as student_count FROM students WHERE hometown_id = ?");
                $stmt->execute([$hometown_id]);
                $student_result = $stmt->fetch();
                $student_count = $student_result['student_count'];
                
                // Check if there are any bus payment records
                $stmt = $db->prepare("
                    SELECT COUNT(*) as payment_count
                    FROM daily_collections dc
                    INNER JOIN students s ON dc.student_id = s.student_id
                    WHERE s.hometown_id = ? AND dc.bus_paid = 1
                ");
                $stmt->execute([$hometown_id]);
                $payment_result = $stmt->fetch();
                $payment_count = $payment_result['payment_count'];
                
                if ($student_count > 0) {
                    set_message('error', "Cannot delete: $student_count student(s) are currently assigned to this hometown/route. Reassign students first or mark as inactive.");
                } elseif ($payment_count > 0) {
                    set_message('error', "Cannot delete: $payment_count bus payment record(s) exist for this route. Consider marking it as inactive instead.");
                } else {
                    // Safe to delete
                    $stmt = $db->prepare("DELETE FROM hometowns WHERE hometown_id = ? AND school_id = ?");
                    $stmt->execute([$hometown_id, $school_id]);
                    
                    log_activity($current_user['user_id'], "Deleted hometown/route ID: $hometown_id", 'hometowns', $hometown_id);
                    set_message('success', 'Hometown/Route deleted successfully!');
                }
            } catch (PDOException $e) {
                set_message('error', 'Error deleting hometown: ' . $e->getMessage());
            }
            redirect(APP_URL . '/admin/manage-hometowns.php');
        }
    }
}

// Get all hometowns for this school
$stmt = $db->prepare("
    SELECT 
        h.*,
        COUNT(s.student_id) as student_count,
        CONCAT(u.first_name, ' ', u.last_name) as created_by_name
    FROM hometowns h
    LEFT JOIN students s ON h.hometown_id = s.hometown_id
    LEFT JOIN users u ON h.created_by = u.user_id
    WHERE h.school_id = ?
    GROUP BY h.hometown_id
    ORDER BY h.hometown_name
");
$stmt->execute([$school_id]);
$hometowns = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .stats-summary {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-box {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        color: white;
        padding: 20px;
        border-radius: 10px;
        text-align: center;
    }
    
    .stat-box h3 {
        margin: 0;
        font-size: 32px;
    }
    
    .stat-box p {
        margin: 5px 0 0 0;
        opacity: 0.9;
    }
    
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        overflow-y: auto;
    }
    
    .modal-content {
        background: var(--card-bg);
        margin: 50px auto;
        padding: 30px;
        width: 90%;
        max-width: 600px;
        border-radius: 10px;
        box-shadow: 0 5px 30px rgba(0,0,0,0.3);
    }
    
    .modal-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        padding-bottom: 15px;
        border-bottom: 2px solid var(--border-color);
    }
    
    .close {
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
        color: var(--text-secondary);
    }
    
    .close:hover {
        color: var(--danger-red);
    }
    </style>
    
    <!-- Stats Summary -->
    <div class="stats-summary">
        <div class="stat-box">
            <h3><?php echo count($hometowns); ?></h3>
            <p>Total Routes</p>
        </div>
        <div class="stat-box">
            <h3><?php echo count(array_filter($hometowns, fn($h) => $h['status'] == 'active')); ?></h3>
            <p>Active Routes</p>
        </div>
        <div class="stat-box">
            <h3><?php echo array_sum(array_column($hometowns, 'student_count')); ?></h3>
            <p>Total Students</p>
        </div>
    </div>
    
    <!-- Main Card -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-map-marked-alt"></i> Hometowns & Bus Routes</h3>
            <button onclick="openAddModal()" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add Hometown/Route
            </button>
        </div>
        
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Hometown</th>
                        <th>Route</th>
                        <th>Bus Fee</th>
                        <th>Distance (km)</th>
                        <th>Students</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($hometowns) > 0): ?>
                        <?php foreach ($hometowns as $hometown): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($hometown['hometown_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($hometown['route_name']); ?></td>
                                <td><strong><?php echo format_currency($hometown['bus_fee']); ?></strong></td>
                                <td><?php echo $hometown['distance_km'] ? $hometown['distance_km'] . ' km' : '-'; ?></td>
                                <td>
                                    <span class="badge badge-info"><?php echo $hometown['student_count']; ?> students</span>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $hometown['status'] == 'active' ? 'success' : 'secondary'; ?>">
                                        <?php echo ucfirst($hometown['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button onclick='openEditModal(<?php echo json_encode($hometown); ?>)' class="btn btn-sm btn-info">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="confirmDelete(<?php echo $hometown['hometown_id']; ?>, '<?php echo htmlspecialchars($hometown['hometown_name']); ?>')" 
                                            class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 40px;">
                                <i class="fas fa-map-marked-alt" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 10px; display: block;"></i>
                                <h3>No Hometowns/Routes Added</h3>
                                <p style="color: var(--text-secondary);">Click "Add Hometown/Route" to get started</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-plus"></i> Add Hometown/Route</h3>
                <span class="close" onclick="closeAddModal()">&times;</span>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label>Hometown Name <span style="color: red;">*</span></label>
                    <input type="text" name="hometown_name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Route Name <span style="color: red;">*</span></label>
                    <input type="text" name="route_name" class="form-control" placeholder="e.g., Route A" required>
                </div>
                
                <div class="form-group">
                    <label>Daily Bus Fee (₵) <span style="color: red;">*</span></label>
                    <input type="number" step="0.01" name="bus_fee" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Distance (km)</label>
                    <input type="number" step="0.1" name="distance_km" class="form-control" placeholder="Optional">
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="Optional notes"></textarea>
                </div>
                
                <div style="text-align: right; margin-top: 20px;">
                    <button type="button" onclick="closeAddModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit Hometown/Route</h3>
                <span class="close" onclick="closeEditModal()">&times;</span>
            </div>
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="hometown_id" id="edit_hometown_id">
                
                <div class="form-group">
                    <label>Hometown Name <span style="color: red;">*</span></label>
                    <input type="text" name="hometown_name" id="edit_hometown_name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Route Name <span style="color: red;">*</span></label>
                    <input type="text" name="route_name" id="edit_route_name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Daily Bus Fee (₵) <span style="color: red;">*</span></label>
                    <input type="number" step="0.01" name="bus_fee" id="edit_bus_fee" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label>Distance (km)</label>
                    <input type="number" step="0.1" name="distance_km" id="edit_distance_km" class="form-control">
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" id="edit_status" class="form-control">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                
                <div style="text-align: right; margin-top: 20px;">
                    <button type="button" onclick="closeEditModal()" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Form -->
    <form method="POST" id="deleteForm" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="hometown_id" id="delete_hometown_id">
    </form>
    
    <script>
    function openAddModal() {
        document.getElementById('addModal').style.display = 'block';
    }
    
    function closeAddModal() {
        document.getElementById('addModal').style.display = 'none';
    }
    
    function openEditModal(hometown) {
        document.getElementById('edit_hometown_id').value = hometown.hometown_id;
        document.getElementById('edit_hometown_name').value = hometown.hometown_name;
        document.getElementById('edit_route_name').value = hometown.route_name;
        document.getElementById('edit_bus_fee').value = hometown.bus_fee;
        document.getElementById('edit_distance_km').value = hometown.distance_km || '';
        document.getElementById('edit_description').value = hometown.description || '';
        document.getElementById('edit_status').value = hometown.status;
        document.getElementById('editModal').style.display = 'block';
    }
    
    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
    }
    
    function confirmDelete(id, name) {
        if (confirm(`Are you sure you want to delete "${name}"?\n\nThis action cannot be undone.`)) {
            document.getElementById('delete_hometown_id').value = id;
            document.getElementById('deleteForm').submit();
        }
    }
    
    // Close modals when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
