<?php
// admin/system-health.php - System Health Monitoring
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'System Health';
$current_user = check_permission(['super-admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get database statistics
$stats = [];

// User statistics
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN role = 'teacher' THEN 1 ELSE 0 END) as teachers,
        SUM(CASE WHEN role = 'student' THEN 1 ELSE 0 END) as students,
        SUM(CASE WHEN role = 'parent' THEN 1 ELSE 0 END) as parents,
        SUM(CASE WHEN role = 'accountant' THEN 1 ELSE 0 END) as accountants,
        SUM(CASE WHEN role = 'librarian' THEN 1 ELSE 0 END) as librarians,
        SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admins
    FROM users
    WHERE school_id = ?
");
$stmt->execute([$school_id]);
$stats['users'] = $stmt->fetch();

// Class and enrollment
$stmt = $db->prepare("
    SELECT COUNT(*) as total_classes, SUM(student_count) as total_students
    FROM (SELECT COUNT(*) as student_count FROM students WHERE class_id = c.class_id) s,
    classes c
    WHERE c.school_id = ?
");
$stmt->execute([$school_id]);
$class_stats = $stmt->fetch();

$stmt = $db->prepare("SELECT COUNT(*) as total FROM classes WHERE school_id = ?");
$stmt->execute([$school_id]);
$stats['classes'] = $stmt->fetch()['total'];

// Payment and financial data
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_payments,
        SUM(amount) as total_amount,
        COUNT(DISTINCT student_id) as students_paid
    FROM payments
    WHERE school_id = ?
");
$stmt->execute([$school_id]);
$stats['payments'] = $stmt->fetch();

// Attendance data
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_records,
        SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present,
        SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) as absent
    FROM attendance
    WHERE school_id = ?
");
$stmt->execute([$school_id]);
$stats['attendance'] = $stmt->fetch();

// Exam and marks data
$stmt = $db->prepare("
    SELECT COUNT(DISTINCT exam_id) as total_exams FROM exams WHERE school_id = ?
");
$stmt->execute([$school_id]);
$stats['exams'] = $stmt->fetch();

// Book inventory
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_books,
        SUM(quantity) as total_copies,
        COUNT(DISTINCT CASE WHEN quantity = 0 THEN book_id END) as out_of_stock
    FROM books
    WHERE school_id = ?
");
$stmt->execute([$school_id]);
$stats['books'] = $stmt->fetch();

// Activity logs
$stmt = $db->prepare("
    SELECT COUNT(*) as total_logs FROM activity_logs WHERE school_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
");
$stmt->execute([$school_id]);
$stats['logs'] = $stmt->fetch();

// Database size estimation
$stmt = $db->prepare("
    SELECT 
        SUM(data_length + index_length) as db_size
    FROM information_schema.tables
    WHERE table_schema = (SELECT DATABASE())
");
$result = $stmt->execute();
$db_size = $stmt->fetch();

// System status indicators
$status_indicators = [
    'users_active' => $stats['users']['total'] > 10,
    'students_enrolled' => ($class_stats['total_students'] ?? 0) > 0,
    'payments_recorded' => $stats['payments']['total_payments'] > 0,
    'attendance_tracked' => $stats['attendance']['total_records'] > 0,
    'books_available' => $stats['books']['total_books'] > 0,
    'logs_healthy' => $stats['logs']['total_logs'] > 0
];

$system_health = (count(array_filter($status_indicators)) / count($status_indicators)) * 100;

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- System Health Overview -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-heartbeat"></i> Overall System Health</h3>
            </div>
            <div style="padding: 30px; text-align: center;">
                <div style="font-size: 3em; color: var(--success-green); font-weight: bold; margin-bottom: 10px;">
                    <?php echo round($system_health); ?>%
                </div>
                <div style="height: 10px; background: var(--bg-secondary); border-radius: 5px; overflow: hidden; margin-bottom: 20px;">
                    <div style="height: 100%; width: <?php echo $system_health; ?>%; background: linear-gradient(90deg, var(--success-green), var(--info-blue));"></div>
                </div>
                <p style="color: var(--text-secondary); margin: 0;">
                    <?php echo round($system_health) >= 80 ? '✓ System is running smoothly' : '⚠ Some components need attention'; ?>
                </p>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-info-circle"></i> Status Indicators</h3>
            </div>
            <div style="padding: 20px;">
                <div style="display: flex; flex-direction: column; gap: 10px;">
                    <?php foreach ($status_indicators as $indicator => $status): ?>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-<?php echo $status ? 'check-circle' : 'exclamation-circle'; ?>" 
                               style="color: <?php echo $status ? 'var(--success-green)' : 'var(--danger-red)'; ?>; font-size: 1.2em;"></i>
                            <span><?php echo str_replace('_', ' ', ucfirst($indicator)); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- User Statistics -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-users"></i> User Statistics</h3>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; padding: 20px;">
            <div style="text-align: center; padding: 15px;">
                <div style="font-size: 2em; color: var(--info-blue); font-weight: bold;"><?php echo $stats['users']['total']; ?></div>
                <div style="color: var(--text-secondary);">Total Users</div>
            </div>
            <div style="text-align: center; padding: 15px;">
                <div style="font-size: 2em; color: var(--success-green); font-weight: bold;"><?php echo $stats['users']['students']; ?></div>
                <div style="color: var(--text-secondary);">Students</div>
            </div>
            <div style="text-align: center; padding: 15px;">
                <div style="font-size: 2em; color: var(--warning-orange); font-weight: bold;"><?php echo $stats['users']['teachers']; ?></div>
                <div style="color: var(--text-secondary);">Teachers</div>
            </div>
            <div style="text-align: center; padding: 15px;">
                <div style="font-size: 2em; color: var(--purple-pink); font-weight: bold;"><?php echo $stats['users']['parents']; ?></div>
                <div style="color: var(--text-secondary);">Parents</div>
            </div>
            <div style="text-align: center; padding: 15px;">
                <div style="font-size: 2em; color: var(--teal-cyan); font-weight: bold;"><?php echo $stats['users']['accountants']; ?></div>
                <div style="color: var(--text-secondary);">Accountants</div>
            </div>
            <div style="text-align: center; padding: 15px;">
                <div style="font-size: 2em; color: var(--pink-coral); font-weight: bold;"><?php echo $stats['users']['librarians']; ?></div>
                <div style="color: var(--text-secondary);">Librarians</div>
            </div>
        </div>
    </div>
    
    <!-- Module Activity -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-graduation-cap"></i> Academic Data</h3>
            </div>
            <div style="padding: 20px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid var(--border-color);">
                    <span>Classes</span>
                    <strong><?php echo $stats['classes']; ?></strong>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid var(--border-color);">
                    <span>Exams Created</span>
                    <strong><?php echo $stats['exams']['total_exams']; ?></strong>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span>Attendance Records</span>
                    <strong><?php echo $stats['attendance']['total_records']; ?></strong>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-book"></i> Library Data</h3>
            </div>
            <div style="padding: 20px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid var(--border-color);">
                    <span>Total Books</span>
                    <strong><?php echo $stats['books']['total_books']; ?></strong>
                </div>
                <div style="display: flex; justify-content: space-between; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid var(--border-color);">
                    <span>Total Copies</span>
                    <strong><?php echo $stats['books']['total_copies']; ?></strong>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span>Out of Stock</span>
                    <strong style="color: var(--danger-red);"><?php echo $stats['books']['out_of_stock']; ?></strong>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Financial Data -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-money-bill-wave"></i> Financial Activity</h3>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; padding: 20px;">
            <div style="padding: 15px; background: var(--bg-secondary); border-radius: 8px;">
                <div style="color: var(--text-secondary); font-size: 0.9em; margin-bottom: 5px;">Total Payments</div>
                <div style="font-size: 1.5em; font-weight: bold; color: var(--success-green);">
                    <?php echo format_currency($stats['payments']['total_amount'] ?? 0); ?>
                </div>
                <small style="color: var(--text-secondary);">from <?php echo $stats['payments']['students_paid']; ?> students</small>
            </div>
            
            <div style="padding: 15px; background: var(--bg-secondary); border-radius: 8px;">
                <div style="color: var(--text-secondary); font-size: 0.9em; margin-bottom: 5px;">Transaction Count</div>
                <div style="font-size: 1.5em; font-weight: bold; color: var(--info-blue);">
                    <?php echo $stats['payments']['total_payments']; ?>
                </div>
                <small style="color: var(--text-secondary);">payment records</small>
            </div>
            
            <div style="padding: 15px; background: var(--bg-secondary); border-radius: 8px;">
                <div style="color: var(--text-secondary); font-size: 0.9em; margin-bottom: 5px;">Average Payment</div>
                <div style="font-size: 1.5em; font-weight: bold; color: var(--warning-orange);">
                    <?php 
                        $avg = ($stats['payments']['total_amount'] ?? 0) / max($stats['payments']['total_payments'] ?? 1, 1);
                        echo format_currency($avg);
                    ?>
                </div>
                <small style="color: var(--text-secondary);">per transaction</small>
            </div>
        </div>
    </div>
    
    <!-- System Information -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-server"></i> System Information</h3>
        </div>
        <div style="padding: 20px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
                <div>
                    <h4 style="color: var(--text-secondary); font-size: 0.9em; text-transform: uppercase; margin-bottom: 10px;">
                        <i class="fas fa-database"></i> Database
                    </h4>
                    <div style="border-left: 3px solid var(--info-blue); padding-left: 15px;">
                        <div style="margin-bottom: 8px;">
                            <small style="color: var(--text-secondary);">Database Size</small><br>
                            <strong><?php echo isset($db_size['db_size']) ? round($db_size['db_size'] / 1024 / 1024, 2) . ' MB' : 'N/A'; ?></strong>
                        </div>
                        <div>
                            <small style="color: var(--text-secondary);">Activity Logs (7 days)</small><br>
                            <strong><?php echo $stats['logs']['total_logs']; ?></strong>
                        </div>
                    </div>
                </div>
                
                <div>
                    <h4 style="color: var(--text-secondary); font-size: 0.9em; text-transform: uppercase; margin-bottom: 10px;">
                        <i class="fas fa-cog"></i> Server
                    </h4>
                    <div style="border-left: 3px solid var(--success-green); padding-left: 15px;">
                        <div style="margin-bottom: 8px;">
                            <small style="color: var(--text-secondary);">PHP Version</small><br>
                            <strong><?php echo phpversion(); ?></strong>
                        </div>
                        <div>
                            <small style="color: var(--text-secondary);">Current Time</small><br>
                            <strong><?php echo date('M d, Y - H:i:s'); ?></strong>
                        </div>
                    </div>
                </div>
                
                <div>
                    <h4 style="color: var(--text-secondary); font-size: 0.9em; text-transform: uppercase; margin-bottom: 10px;">
                        <i class="fas fa-shield-alt"></i> Status
                    </h4>
                    <div style="border-left: 3px solid var(--success-green); padding-left: 15px;">
                        <div style="margin-bottom: 8px;">
                            <small style="color: var(--text-secondary);">Database Connection</small><br>
                            <strong style="color: var(--success-green);">✓ Connected</strong>
                        </div>
                        <div>
                            <small style="color: var(--text-secondary);">System Status</small><br>
                            <strong style="color: var(--success-green);">✓ Operational</strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
