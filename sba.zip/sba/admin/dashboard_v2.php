<?php
/**
 * Modern School Management Dashboard v2
 * Features: Beautiful stats cards, charts, dark theme with colorful accents
 * Inspired by Donkomie dashboard design
 */

session_start();
require_once '../config.php';
require_once '../includes/header.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$school_id = $_SESSION['school_id'];

// Fetch dashboard statistics
try {
    // Student Stats
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM students WHERE school_id = ?");
    $stmt->execute([$school_id]);
    $student_count = $stmt->fetch()['total'] ?? 0;

    // Active Classes
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM classes WHERE school_id = ? AND status = 'active'");
    $stmt->execute([$school_id]);
    $class_count = $stmt->fetch()['total'] ?? 0;

    // Teachers
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM teachers WHERE school_id = ?");
    $stmt->execute([$school_id]);
    $teacher_count = $stmt->fetch()['total'] ?? 0;

    // Total Revenue
    $stmt = $db->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE school_id = ? AND status = 'approved'");
    $stmt->execute([$school_id]);
    $total_revenue = $stmt->fetch()['total'] ?? 0;

    // Pending Payments
    $stmt = $db->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE school_id = ? AND status = 'pending'");
    $stmt->execute([$school_id]);
    $pending_payments = $stmt->fetch()['total'] ?? 0;

    // Attendance Rate (last 30 days)
    $stmt = $db->prepare("
        SELECT ROUND(
            (SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) * 100,
            1
        ) as rate
        FROM attendance 
        WHERE school_id = ? AND date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    $stmt->execute([$school_id]);
    $attendance_rate = $stmt->fetch()['rate'] ?? 0;

} catch (Exception $e) {
    error_log("Dashboard stats error: " . $e->getMessage());
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - School Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0f1419 0%, #1a1f2e 100%);
            color: #e0e0e0;
            min-height: 100vh;
        }

        .dashboard-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .dashboard-header {
            margin-bottom: 40px;
        }

        .welcome-section {
            background: linear-gradient(135deg, rgba(255, 107, 107, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%);
            border: 1px solid rgba(255, 107, 107, 0.2);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 40px;
            backdrop-filter: blur(10px);
        }

        .welcome-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .welcome-header h1 {
            font-size: 28px;
            color: #fff;
            font-weight: 600;
        }

        .time-filters {
            display: flex;
            gap: 10px;
        }

        .filter-btn {
            padding: 10px 20px;
            border: 2px solid #ff6b6b;
            background: transparent;
            color: #ff6b6b;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .filter-btn.active {
            background: #ff6b6b;
            color: white;
        }

        .filter-btn:hover {
            transform: translateY(-2px);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: linear-gradient(135deg, rgba(30, 35, 50, 0.8) 0%, rgba(20, 25, 40, 0.8) 100%);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 25px;
            backdrop-filter: blur(10px);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #ff6b6b 0%, #ff6b6b 100%);
        }

        .stat-card:nth-child(2)::before {
            background: linear-gradient(90deg, #10b981 0%, #10b981 100%);
        }

        .stat-card:nth-child(3)::before {
            background: linear-gradient(90deg, #3b82f6 0%, #3b82f6 100%);
        }

        .stat-card:nth-child(4)::before {
            background: linear-gradient(90deg, #f59e0b 0%, #f59e0b 100%);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            border-color: rgba(255, 255, 255, 0.2);
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        }

        .stat-card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .stat-card-title {
            font-size: 14px;
            color: #a0a0a0;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 500;
        }

        .stat-card-change {
            font-size: 12px;
            padding: 4px 8px;
            border-radius: 6px;
            font-weight: 600;
        }

        .stat-card-change.positive {
            background: rgba(16, 185, 129, 0.2);
            color: #10b981;
        }

        .stat-card-change.negative {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
        }

        .stat-card-value {
            font-size: 32px;
            font-weight: 700;
            color: #fff;
            margin-bottom: 10px;
        }

        .stat-card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .stat-card-subtitle {
            font-size: 12px;
            color: #808080;
        }

        .stat-card-icon {
            font-size: 24px;
            color: rgba(255, 255, 255, 0.1);
        }

        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .chart-card {
            background: linear-gradient(135deg, rgba(30, 35, 50, 0.8) 0%, rgba(20, 25, 40, 0.8) 100%);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 25px;
            backdrop-filter: blur(10px);
        }

        .chart-card-title {
            font-size: 18px;
            font-weight: 600;
            color: #fff;
            margin-bottom: 20px;
        }

        .chart-container {
            position: relative;
            height: 300px;
        }

        .pie-chart-container {
            display: flex;
            align-items: center;
            justify-content: space-around;
            height: 300px;
        }

        .pie-chart {
            position: relative;
            width: 250px;
            height: 250px;
        }

        .chart-legend {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
        }

        .legend-color {
            width: 12px;
            height: 12px;
            border-radius: 3px;
        }

        .legend-label {
            flex: 1;
            color: #a0a0a0;
        }

        .legend-value {
            font-weight: 600;
            color: #fff;
            min-width: 70px;
            text-align: right;
        }

        .full-width {
            grid-column: 1 / -1;
        }

        .action-links {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }

        .action-link {
            color: #ff6b6b;
            text-decoration: none;
            font-weight: 500;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s ease;
        }

        .action-link:hover {
            color: #ff8787;
            gap: 10px;
        }

        .divider {
            height: 1px;
            background: rgba(255, 255, 255, 0.1);
            margin: 20px 0;
        }

        .grid-2 {
            grid-template-columns: repeat(2, 1fr);
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }

            .charts-grid {
                grid-template-columns: 1fr;
            }

            .grid-2 {
                grid-template-columns: 1fr;
            }

            .welcome-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .time-filters {
                margin-top: 15px;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .stat-card {
            animation: fadeIn 0.6s ease forwards;
        }

        .stat-card:nth-child(2) {
            animation-delay: 0.1s;
        }

        .stat-card:nth-child(3) {
            animation-delay: 0.2s;
        }

        .stat-card:nth-child(4) {
            animation-delay: 0.3s;
        }

        /* Responsive Chart Container */
        .chart-responsive {
            position: relative;
            height: 300px;
            width: 100%;
        }

    </style>
</head>
<body>

<div class="dashboard-container">
    <!-- Welcome Section -->
    <div class="welcome-section">
        <div class="welcome-header">
            <div>
                <h1>Welcome back, Administrator! 👋</h1>
                <p style="color: #a0a0a0; margin-top: 5px;">Last login was today • <a href="#" style="color: #ff6b6b; text-decoration: none;">View details</a></p>
            </div>
            <div class="time-filters">
                <button class="filter-btn active" onclick="filterTime('month')">Monthly</button>
                <button class="filter-btn" onclick="filterTime('quarter')">Quarterly</button>
                <button class="filter-btn" onclick="filterTime('year')">Yearly</button>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="stats-grid">
        <!-- Total Students -->
        <div class="stat-card">
            <div class="stat-card-header">
                <div>
                    <div class="stat-card-title">Total Students</div>
                    <div class="stat-card-change positive">📈 +12.5%</div>
                </div>
                <div class="stat-card-icon"><i class="fas fa-users"></i></div>
            </div>
            <div class="stat-card-value"><?php echo number_format($student_count); ?></div>
            <div class="stat-card-footer">
                <span class="stat-card-subtitle">This Academic Year</span>
            </div>
        </div>

        <!-- Revenue -->
        <div class="stat-card">
            <div class="stat-card-header">
                <div>
                    <div class="stat-card-title">Total Revenue</div>
                    <div class="stat-card-change positive">📈 +23.1%</div>
                </div>
                <div class="stat-card-icon"><i class="fas fa-money-bill-wave"></i></div>
            </div>
            <div class="stat-card-value">₵<?php echo number_format($total_revenue, 2); ?></div>
            <div class="stat-card-footer">
                <span class="stat-card-subtitle">From Fee Payments</span>
            </div>
        </div>

        <!-- Pending Payments -->
        <div class="stat-card">
            <div class="stat-card-header">
                <div>
                    <div class="stat-card-title">Pending Payments</div>
                    <div class="stat-card-change negative">📉 -8.2%</div>
                </div>
                <div class="stat-card-icon"><i class="fas fa-exclamation-circle"></i></div>
            </div>
            <div class="stat-card-value">₵<?php echo number_format($pending_payments, 2); ?></div>
            <div class="stat-card-footer">
                <span class="stat-card-subtitle">Awaiting Collection</span>
            </div>
        </div>

        <!-- Attendance Rate -->
        <div class="stat-card">
            <div class="stat-card-header">
                <div>
                    <div class="stat-card-title">Attendance Rate</div>
                    <div class="stat-card-change positive">📈 +5.3%</div>
                </div>
                <div class="stat-card-icon"><i class="fas fa-clipboard-check"></i></div>
            </div>
            <div class="stat-card-value"><?php echo number_format($attendance_rate, 1); ?>%</div>
            <div class="stat-card-footer">
                <span class="stat-card-subtitle">Last 30 Days</span>
            </div>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="charts-grid">
        <!-- Revenue Chart -->
        <div class="chart-card">
            <h3 class="chart-card-title">Revenue Trend</h3>
            <div class="chart-container">
                <canvas id="revenueChart"></canvas>
            </div>
            <div class="action-links">
                <a href="#" class="action-link">View detailed report <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

        <!-- Students by Class -->
        <div class="chart-card">
            <h3 class="chart-card-title">Students by Class</h3>
            <div class="chart-container">
                <canvas id="classChart"></canvas>
            </div>
            <div class="action-links">
                <a href="#" class="action-link">View all classes <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

        <!-- Attendance Chart -->
        <div class="chart-card">
            <h3 class="chart-card-title">Attendance Overview</h3>
            <div class="chart-container">
                <canvas id="attendanceChart"></canvas>
            </div>
            <div class="action-links">
                <a href="#" class="action-link">View attendance <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

        <!-- Payment Status (Pie Chart) -->
        <div class="chart-card full-width">
            <h3 class="chart-card-title">Payment Status Distribution</h3>
            <div class="pie-chart-container">
                <div class="pie-chart">
                    <canvas id="paymentStatusChart"></canvas>
                </div>
                <div class="chart-legend">
                    <div class="legend-item">
                        <div class="legend-color" style="background: #ff6b6b;"></div>
                        <span class="legend-label">Pending</span>
                        <span class="legend-value">₵<?php echo number_format($pending_payments, 0); ?></span>
                    </div>
                    <div class="legend-item">
                        <div class="legend-color" style="background: #10b981;"></div>
                        <span class="legend-label">Approved</span>
                        <span class="legend-value">₵<?php echo number_format($total_revenue, 0); ?></span>
                    </div>
                    <div class="legend-item">
                        <div class="legend-color" style="background: #3b82f6;"></div>
                        <span class="legend-label">Partial</span>
                        <span class="legend-value">₵<?php echo number_format($total_revenue * 0.15, 0); ?></span>
                    </div>
                    <div class="legend-item">
                        <div class="legend-color" style="background: #f59e0b;"></div>
                        <span class="legend-label">Overdue</span>
                        <span class="legend-value">₵<?php echo number_format($pending_payments * 0.3, 0); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Revenue Trend Chart
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Revenue (₵)',
                data: [45000, 52000, 48000, 61000, 55000, 67000],
                borderColor: '#ff6b6b',
                backgroundColor: 'rgba(255, 107, 107, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#ff6b6b',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#a0a0a0' },
                    grid: { color: 'rgba(255, 255, 255, 0.05)' }
                },
                x: {
                    ticks: { color: '#a0a0a0' },
                    grid: { display: false }
                }
            }
        }
    });

    // Students by Class Chart
    const classCtx = document.getElementById('classChart').getContext('2d');
    new Chart(classCtx, {
        type: 'bar',
        data: {
            labels: ['Form 1A', 'Form 1B', 'Form 2A', 'Form 2B', 'Form 3A', 'Form 3B'],
            datasets: [{
                label: 'Students',
                data: [45, 42, 48, 44, 40, 38],
                backgroundColor: ['#ff6b6b', '#10b981', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899'],
                borderRadius: 8,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { color: '#a0a0a0' },
                    grid: { color: 'rgba(255, 255, 255, 0.05)' }
                },
                x: {
                    ticks: { color: '#a0a0a0' },
                    grid: { display: false }
                }
            }
        }
    });

    // Attendance Chart
    const attendanceCtx = document.getElementById('attendanceChart').getContext('2d');
    new Chart(attendanceCtx, {
        type: 'bar',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
            datasets: [
                {
                    label: 'Present',
                    data: [320, 310, 325, 315, 300],
                    backgroundColor: '#10b981',
                    borderRadius: 8,
                    borderSkipped: false
                },
                {
                    label: 'Absent',
                    data: [45, 55, 40, 50, 65],
                    backgroundColor: '#ef4444',
                    borderRadius: 8,
                    borderSkipped: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: undefined,
            plugins: {
                legend: {
                    labels: { color: '#a0a0a0' },
                    position: 'bottom'
                }
            },
            scales: {
                y: {
                    stacked: false,
                    ticks: { color: '#a0a0a0' },
                    grid: { color: 'rgba(255, 255, 255, 0.05)' }
                },
                x: {
                    ticks: { color: '#a0a0a0' },
                    grid: { display: false }
                }
            }
        }
    });

    // Payment Status Pie Chart
    const paymentCtx = document.getElementById('paymentStatusChart').getContext('2d');
    new Chart(paymentCtx, {
        type: 'doughnut',
        data: {
            labels: ['Pending', 'Approved', 'Partial', 'Overdue'],
            datasets: [{
                data: [25, 55, 15, 5],
                backgroundColor: ['#ff6b6b', '#10b981', '#3b82f6', '#f59e0b'],
                borderColor: 'transparent',
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { display: false }
            }
        }
    });

    // Filter function
    function filterTime(period) {
        const buttons = document.querySelectorAll('.filter-btn');
        buttons.forEach(btn => btn.classList.remove('active'));
        event.target.classList.add('active');
        console.log('Filtered by:', period);
    }
</script>

</body>
</html>
