<?php
// admin/teacher_classes.php - Assign Classes to Teachers
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Assign Classes to Teachers';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        // Auto-create class_subjects table if it doesn't exist
        try {
            $db->query("SELECT 1 FROM class_subjects LIMIT 1");
        } catch (PDOException $e) {
            try {
                $sql = "CREATE TABLE IF NOT EXISTS `class_subjects` (
                  `class_subject_id` int(11) NOT NULL AUTO_INCREMENT,
                  `class_id` int(11) NOT NULL,
                  `subject_id` int(11) NOT NULL,
                  `teacher_id` int(11) NULL,
                  PRIMARY KEY (`class_subject_id`),
                  UNIQUE KEY `idx_class_subject` (`class_id`, `subject_id`),
                  KEY `idx_teacher` (`teacher_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
                $db->exec($sql);
            } catch (PDOException $e) {
                // Table creation failed, will handle in assignment
            }
        }
        
        // Auto-create teacher_classes table if it doesn't exist
        try {
            $db->query("SELECT 1 FROM teacher_classes LIMIT 1");
        } catch (PDOException $e) {
            try {
                $sql = "CREATE TABLE IF NOT EXISTS `teacher_classes` (
                  `id` int(11) NOT NULL AUTO_INCREMENT,
                  `school_id` int(11) NOT NULL,
                  `teacher_id` int(11) NOT NULL,
                  `class_id` int(11) NOT NULL,
                  `is_class_teacher` tinyint(1) DEFAULT 0,
                  `assigned_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  PRIMARY KEY (`id`),
                  KEY `school_id` (`school_id`),
                  KEY `teacher_id` (`teacher_id`),
                  KEY `class_id` (`class_id`),
                  KEY `is_class_teacher` (`is_class_teacher`),
                  UNIQUE KEY `unique_teacher_class` (`school_id`, `teacher_id`, `class_id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
                $db->exec($sql);
            } catch (PDOException $e) {
                // Table creation failed, will handle in assignment
            }
        }
        
        if ($_POST['action'] == 'assign') {
            $teacher_id = (int)$_POST['teacher_id'];
            $class_id = (int)$_POST['class_id'];
            $is_class_teacher = isset($_POST['is_class_teacher']) ? 1 : 0;
            
            try {
                $stmt = $db->prepare("
                    INSERT INTO teacher_classes (school_id, teacher_id, class_id, is_class_teacher, assigned_date)
                    VALUES (?, ?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE is_class_teacher = VALUES(is_class_teacher), assigned_date = NOW()
                ");
                $stmt->execute([$school_id, $teacher_id, $class_id, $is_class_teacher]);
                
                log_activity($current_user['user_id'], "Assigned teacher to class", 'teacher_classes', $teacher_id);
                
                set_message('success', 'Teacher assigned to class successfully!');
                redirect(APP_URL . '/admin/teacher_classes.php');
            } catch (PDOException $e) {
                set_message('error', 'Error assigning class: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'remove') {
            $assignment_id = (int)$_POST['assignment_id'];
            
            try {
                $stmt = $db->prepare("DELETE FROM teacher_classes WHERE id = ? AND school_id = ?");
                $stmt->execute([$assignment_id, $school_id]);
                
                log_activity($current_user['user_id'], "Removed teacher class assignment", 'teacher_classes', $assignment_id);
                
                set_message('success', 'Assignment removed successfully!');
                redirect(APP_URL . '/admin/teacher_classes.php');
            } catch (PDOException $e) {
                set_message('error', 'Error removing assignment: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'update') {
            $assignment_id = (int)$_POST['assignment_id'];
            $teacher_id = (int)$_POST['teacher_id'];
            $class_id = (int)$_POST['class_id'];
            $is_class_teacher = isset($_POST['is_class_teacher']) ? 1 : 0;
            
            try {
                $stmt = $db->prepare("
                    UPDATE teacher_classes 
                    SET teacher_id = ?, class_id = ?, is_class_teacher = ?, assigned_date = NOW()
                    WHERE id = ? AND school_id = ?
                ");
                $stmt->execute([$teacher_id, $class_id, $is_class_teacher, $assignment_id, $school_id]);
                
                log_activity($current_user['user_id'], "Updated teacher class assignment", 'teacher_classes', $assignment_id);
                
                set_message('success', 'Assignment updated successfully!');
                redirect(APP_URL . '/admin/teacher_classes.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating assignment: ' . $e->getMessage());
            }
        }
    }
}

// Get all teacher-class assignments
$assignments = [];
try {
    $stmt = $db->prepare("
        SELECT 
            tc.id,
            tc.teacher_id,
            tc.class_id,
            tc.is_class_teacher,
            tc.assigned_date,
            u.first_name as teacher_first,
            u.last_name as teacher_last,
            u.email as teacher_email,
            c.class_name
        FROM teacher_classes tc
        INNER JOIN users u ON tc.teacher_id = u.user_id
        INNER JOIN classes c ON tc.class_id = c.class_id
        WHERE tc.school_id = ?
        ORDER BY c.class_name, u.first_name
    ");
    $stmt->execute([$school_id]);
    $assignments = $stmt->fetchAll();
} catch (PDOException $e) {
    // teacher_classes table may not exist
    $assignments = [];
}

// Get all teachers
$stmt = $db->prepare("
    SELECT user_id, first_name, last_name, email 
    FROM users 
    WHERE school_id = ? AND role = 'teacher' AND status = 'active'
    ORDER BY first_name, last_name
");
$stmt->execute([$school_id]);
$teachers = $stmt->fetchAll();

// Get all classes
try {
    $stmt = $db->prepare("
        SELECT class_id, class_name 
        FROM classes 
        WHERE school_id = ?
        ORDER BY class_name
    ");
    $stmt->execute([$school_id]);
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $classes = [];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
            <button class="btn btn-primary" onclick="showAssignModal()">
                <i class="fas fa-plus"></i> Assign Teacher to Class
            </button>
        </div>
    </div>
    
    <!-- Assignments Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-link"></i> Teacher Class Assignments (<?php echo count($assignments); ?>)</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Teacher</th>
                        <th>Email</th>
                        <th>Class</th>
                        <th>Class Teacher</th>
                        <th>Assigned Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($assignments) > 0): ?>
                        <?php foreach ($assignments as $assignment): ?>
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 35px; height: 35px; border-radius: 8px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600;">
                                            <?php echo strtoupper(substr($assignment['teacher_first'], 0, 1) . substr($assignment['teacher_last'], 0, 1)); ?>
                                        </div>
                                        <span><?php echo $assignment['teacher_first'] . ' ' . $assignment['teacher_last']; ?></span>
                                    </div>
                                </td>
                                <td><?php echo $assignment['teacher_email']; ?></td>
                                <td><strong><?php echo $assignment['class_name']; ?></strong></td>
                                <td>
                                    <?php if ($assignment['is_class_teacher']): ?>
                                        <span class="badge badge-success"><i class="fas fa-check"></i> Yes</span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary"><i class="fas fa-times"></i> No</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $assignment['assigned_date'] ? date('M d, Y', strtotime($assignment['assigned_date'])) : 'Not set'; ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info" onclick="editAssignment(<?php echo json_encode($assignment); ?>)" title="Edit">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="removeAssignment(<?php echo $assignment['id']; ?>, '<?php echo addslashes($assignment['teacher_first'] . ' ' . $assignment['teacher_last'] . ' - ' . $assignment['class_name']); ?>')" title="Remove">
                                        <i class="fas fa-trash"></i> Remove
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 60px;">
                                <i class="fas fa-link" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                                <h3 style="margin-bottom: 10px;">No Assignments Yet</h3>
                                <p style="color: var(--text-secondary); margin-bottom: 20px;">Assign teachers to classes to get started</p>
                                <button class="btn btn-primary" onclick="showAssignModal()">
                                    <i class="fas fa-plus"></i> Make First Assignment
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Assign Teacher Modal -->
    <div id="assignModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Assign Teacher to Class</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="assign">
                
                <div class="form-group">
                    <label for="teacher_id">Select Teacher *</label>
                    <select name="teacher_id" id="teacher_id" required>
                        <option value="">-- Choose Teacher --</option>
                        <?php foreach ($teachers as $teacher): ?>
                            <option value="<?php echo $teacher['user_id']; ?>">
                                <?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name'] . ' (' . $teacher['email'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="class_id">Select Class *</label>
                    <select name="class_id" id="class_id" required>
                        <option value="">-- Choose Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>">
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="is_class_teacher" value="1">
                        <span>Make this teacher the class teacher (main instructor)</span>
                    </label>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Assign Teacher
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Teacher Assignment Modal -->
    <div id="editModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Edit Teacher Class Assignment</h2>
                <button onclick="closeEditModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="assignment_id" id="edit_assignment_id">
                
                <div class="form-group">
                    <label for="edit_teacher_id">Select Teacher *</label>
                    <select name="teacher_id" id="edit_teacher_id" required>
                        <option value="">-- Choose Teacher --</option>
                        <?php foreach ($teachers as $teacher): ?>
                            <option value="<?php echo $teacher['user_id']; ?>">
                                <?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name'] . ' (' . $teacher['email'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="edit_class_id">Select Class *</label>
                    <select name="class_id" id="edit_class_id" required>
                        <option value="">-- Choose Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>">
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="is_class_teacher" id="edit_is_class_teacher" value="1">
                        <span>Make this teacher the class teacher (main instructor)</span>
                    </label>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Assignment
                    </button>
                </div>
            </form>
        </div>
    </div>
    <script>
    function showAssignModal() {
        document.getElementById('assignModal').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('assignModal').style.display = 'none';
    }
    
    function editAssignment(assignment) {
        document.getElementById('editModal').style.display = 'block';
        document.getElementById('edit_assignment_id').value = assignment.id;
        document.getElementById('edit_teacher_id').value = assignment.teacher_id;
        document.getElementById('edit_class_id').value = assignment.class_id;
        document.getElementById('edit_is_class_teacher').checked = assignment.is_class_teacher == 1;
    }
    
    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
    }
    
    function removeAssignment(assignmentId, label) {
        if (confirm('Remove assignment: ' + label + '?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'remove';
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'assignment_id';
            idInput.value = assignmentId;
            
            form.appendChild(actionInput);
            form.appendChild(idInput);
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Close modals on outside click
    document.getElementById('assignModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    
    document.getElementById('editModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeEditModal();
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
