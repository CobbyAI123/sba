<?php
// admin/fix_exams_constraint.php - Fix exams foreign key constraint
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Fix Exams Foreign Key Constraint';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();

// Fix the exams foreign key constraint
try {
    // Drop the incorrect constraint
    $db->exec("ALTER TABLE exams DROP FOREIGN KEY exams_ibfk_2");
    
    // Add the correct constraint pointing to terms table
    $db->exec("ALTER TABLE exams ADD CONSTRAINT exams_ibfk_2 FOREIGN KEY (term_id) REFERENCES terms(term_id) ON DELETE CASCADE");
    
    log_activity($current_user['user_id'], "Fixed exams foreign key constraint from terms_backup to terms", 'exams', 0);
    
    echo "<div style='padding: 20px; background: #4CAF50; color: white; border-radius: 5px; margin-bottom: 20px;'>";
    echo "<i class='fas fa-check-circle'></i> <strong>Success!</strong><br>";
    echo "Fixed exams foreign key constraint. term_id now correctly references terms table instead of terms_backup.<br>";
    echo "<a href='" . APP_URL . "/admin/exams.php' style='color: white; text-decoration: underline;'>Go to Exams Management</a>";
    echo "</div>";
    
} catch (PDOException $e) {
    echo "<div style='padding: 20px; background: #f44336; color: white; border-radius: 5px; margin-bottom: 20px;'>";
    echo "<i class='fas fa-times-circle'></i> <strong>Error!</strong><br>";
    echo "Error fixing constraint: " . htmlspecialchars($e->getMessage());
    echo "</div>";
}
?>

<style>
body {
    font-family: Arial, sans-serif;
    padding: 20px;
    background: #f5f5f5;
}
</style>
