<?php
/**
 * Advanced Analytics Dashboard
 * Comprehensive reporting with regional breakdown, performance metrics, and detailed charts
 */

session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$school_id = $_SESSION['school_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics Dashboard - School Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0f1419 0%, #1a1f2e 100%);
            color: #e0e0e0;
            min-height: 100vh;
        }

        .analytics-container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .page-title {
            font-size: 32px;
            font-weight: 700;
            color: #fff;
            margin-bottom: 10px;
        }

        .page-subtitle {
            color: #a0a0a0;
            font-size: 14px;
            margin-bottom: 30px;
        }

        .filters-section {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .filter-btn, .filter-select {
            padding: 10px 16px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            background: rgba(30, 35, 50, 0.6);
            color: #fff;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.3s ease;
        }

        .filter-btn:hover, .filter-select:hover {
            border-color: rgba(255, 107, 107, 0.5);
            background: rgba(30, 35, 50, 0.8);
        }

        .filter-btn.active {
            background: #ff6b6b;
            border-color: #ff6b6b;
            color: white;
        }

        /* Regional Stats */
        .regional-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .regional-card {
            background: linear-gradient(135deg, rgba(30, 35, 50, 0.8) 0%, rgba(20, 25, 40, 0.8) 100%);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 20px;
            backdrop-filter: blur(10px);
        }

        .regional-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 15px;
        }

        .region-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
        }

        .regional-name {
            font-weight: 600;
            color: #fff;
        }

        .regional-value {
            font-size: 28px;
            font-weight: 700;
            color: #ff6b6b;
            margin-bottom: 10px;
        }

        .regional-percentage {
            font-size: 13px;
            color: #a0a0a0;
        }

        .progress-bar {
            width: 100%;
            height: 6px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 3px;
            overflow: hidden;
            margin-top: 10px;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #ff6b6b, #ff8787);
            border-radius: 3px;
            transition: width 0.3s ease;
        }

        /* Main Charts Grid */
        .charts-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .chart-card {
            background: linear-gradient(135deg, rgba(30, 35, 50, 0.8) 0%, rgba(20, 25, 40, 0.8) 100%);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 25px;
            backdrop-filter: blur(10px);
        }

        .chart-title {
            font-size: 16px;
            font-weight: 600;
            color: #fff;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .chart-controls {
            display: flex;
            gap: 8px;
        }

        .chart-control-btn {
            width: 28px;
            height: 28px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            color: #a0a0a0;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.3s ease;
        }

        .chart-control-btn:hover {
            background: rgba(255, 107, 107, 0.3);
            color: #ff6b6b;
        }

        .chart-container {
            position: relative;
            height: 350px;
        }

        .full-width {
            grid-column: 1 / -1;
        }

        /* Detailed Report Table */
        .report-table {
            background: linear-gradient(135deg, rgba(30, 35, 50, 0.8) 0%, rgba(20, 25, 40, 0.8) 100%);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            padding: 25px;
            backdrop-filter: blur(10px);
            overflow-x: auto;
        }

        .report-title {
            font-size: 16px;
            font-weight: 600;
            color: #fff;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: rgba(255, 255, 255, 0.05);
        }

        th {
            padding: 15px;
            text-align: left;
            font-size: 13px;
            font-weight: 600;
            color: #a0a0a0;
            text-transform: uppercase;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        td {
            padding: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            font-size: 13px;
        }

        tr:hover {
            background: rgba(255, 255, 255, 0.05);
        }

        .status-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
        }

        .status-success {
            background: rgba(16, 185, 129, 0.2);
            color: #10b981;
        }

        .status-warning {
            background: rgba(245, 158, 11, 0.2);
            color: #f59e0b;
        }

        .status-danger {
            background: rgba(239, 68, 68, 0.2);
            color: #ef4444;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .charts-section {
                grid-template-columns: 1fr;
            }

            .chart-container {
                height: 300px;
            }
        }

        @media (max-width: 768px) {
            .regional-stats {
                grid-template-columns: 1fr;
            }

            .analytics-container {
                padding: 20px 15px;
            }

            .page-title {
                font-size: 24px;
            }
        }

        /* Animations */
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .regional-card {
            animation: slideUp 0.5s ease forwards;
        }

        .regional-card:nth-child(1) { animation-delay: 0.1s; }
        .regional-card:nth-child(2) { animation-delay: 0.2s; }
        .regional-card:nth-child(3) { animation-delay: 0.3s; }
        .regional-card:nth-child(4) { animation-delay: 0.4s; }
        .regional-card:nth-child(5) { animation-delay: 0.5s; }

    </style>
</head>
<body>

<div class="analytics-container">
    <!-- Header -->
    <h1 class="page-title">Analytics & Reports</h1>
    <p class="page-subtitle">Comprehensive performance metrics and detailed analytics</p>

    <!-- Filters -->
    <div class="filters-section">
        <button class="filter-btn active">Last 30 Days</button>
        <button class="filter-btn">Last 90 Days</button>
        <button class="filter-btn">This Year</button>
        <button class="filter-btn">All Time</button>
    </div>

    <!-- Regional Performance -->
    <h2 style="font-size: 20px; color: #fff; margin: 40px 0 20px; font-weight: 600;">Regional Performance</h2>
    <div class="regional-stats">
        <div class="regional-card">
            <div class="regional-header">
                <div class="region-dot" style="background: #7c5cf1;"></div>
                <span class="regional-name">Greater Accra</span>
            </div>
            <div class="regional-value">₵845</div>
            <div class="regional-percentage">45% of total revenue</div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 45%; background: linear-gradient(90deg, #7c5cf1, #a78bfa);"></div>
            </div>
        </div>

        <div class="regional-card">
            <div class="regional-header">
                <div class="region-dot" style="background: #10b981;"></div>
                <span class="regional-name">Ashanti</span>
            </div>
            <div class="regional-value">₵548</div>
            <div class="regional-percentage">28% of total revenue</div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 28%; background: linear-gradient(90deg, #10b981, #34d399);"></div>
            </div>
        </div>

        <div class="regional-card">
            <div class="regional-header">
                <div class="region-dot" style="background: #f59e0b;"></div>
                <span class="regional-name">Northern</span>
            </div>
            <div class="regional-value">₵312</div>
            <div class="regional-percentage">16% of total revenue</div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 16%; background: linear-gradient(90deg, #f59e0b, #fbbf24);"></div>
            </div>
        </div>

        <div class="regional-card">
            <div class="regional-header">
                <div class="region-dot" style="background: #06b6d4;"></div>
                <span class="regional-name">Western</span>
            </div>
            <div class="regional-value">₵285</div>
            <div class="regional-percentage">15% of total revenue</div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 15%; background: linear-gradient(90deg, #06b6d4, #22d3ee);"></div>
            </div>
        </div>

        <div class="regional-card">
            <div class="regional-header">
                <div class="region-dot" style="background: #ec4899;"></div>
                <span class="regional-name">Central</span>
            </div>
            <div class="regional-value">₵198</div>
            <div class="regional-percentage">10% of total revenue</div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: 10%; background: linear-gradient(90deg, #ec4899, #f472b6);"></div>
            </div>
        </div>
    </div>

    <!-- Charts -->
    <h2 style="font-size: 20px; color: #fff; margin: 40px 0 20px; font-weight: 600;">Performance Charts</h2>
    <div class="charts-section">
        <!-- Monthly Revenue -->
        <div class="chart-card">
            <div class="chart-title">
                Monthly Revenue Trend
                <div class="chart-controls">
                    <button class="chart-control-btn" title="Download"><i class="fas fa-download"></i></button>
                    <button class="chart-control-btn" title="Export"><i class="fas fa-share"></i></button>
                </div>
            </div>
            <div class="chart-container">
                <canvas id="monthlyRevenueChart"></canvas>
            </div>
        </div>

        <!-- Student Enrollment -->
        <div class="chart-card">
            <div class="chart-title">
                Student Enrollment by Class
                <div class="chart-controls">
                    <button class="chart-control-btn" title="Download"><i class="fas fa-download"></i></button>
                </div>
            </div>
            <div class="chart-container">
                <canvas id="enrollmentChart"></canvas>
            </div>
        </div>

        <!-- Performance Metrics -->
        <div class="chart-card">
            <div class="chart-title">
                Performance Metrics
                <div class="chart-controls">
                    <button class="chart-control-btn" title="Download"><i class="fas fa-download"></i></button>
                </div>
            </div>
            <div class="chart-container">
                <canvas id="performanceChart"></canvas>
            </div>
        </div>

        <!-- Time Series Analytics -->
        <div class="chart-card">
            <div class="chart-title">
                Daily Sales Pattern
                <div class="chart-controls">
                    <button class="chart-control-btn" title="Download"><i class="fas fa-download"></i></button>
                </div>
            </div>
            <div class="chart-container">
                <canvas id="timeSeriesChart"></canvas>
            </div>
        </div>

        <!-- Detailed Report Table -->
        <div class="report-table full-width">
            <h3 class="report-title">Latest Transactions</h3>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Student Name</th>
                        <th>Amount</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Region</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>06 Jan 2025</td>
                        <td>John Adu</td>
                        <td>₵250.00</td>
                        <td>Tuition Fee</td>
                        <td><span class="status-badge status-success">✓ Approved</span></td>
                        <td>Greater Accra</td>
                        <td><a href="#" style="color: #ff6b6b; text-decoration: none;">View</a></td>
                    </tr>
                    <tr>
                        <td>05 Jan 2025</td>
                        <td>Mary Kwame</td>
                        <td>₵150.00</td>
                        <td>Activity Fee</td>
                        <td><span class="status-badge status-warning">⏱ Pending</span></td>
                        <td>Ashanti</td>
                        <td><a href="#" style="color: #ff6b6b; text-decoration: none;">View</a></td>
                    </tr>
                    <tr>
                        <td>04 Jan 2025</td>
                        <td>David Mensah</td>
                        <td>₵300.00</td>
                        <td>Tuition Fee</td>
                        <td><span class="status-badge status-success">✓ Approved</span></td>
                        <td>Northern</td>
                        <td><a href="#" style="color: #ff6b6b; text-decoration: none;">View</a></td>
                    </tr>
                    <tr>
                        <td>03 Jan 2025</td>
                        <td>Abigail Boateng</td>
                        <td>₵200.00</td>
                        <td>Exam Fee</td>
                        <td><span class="status-badge status-danger">✗ Failed</span></td>
                        <td>Western</td>
                        <td><a href="#" style="color: #ff6b6b; text-decoration: none;">View</a></td>
                    </tr>
                    <tr>
                        <td>02 Jan 2025</td>
                        <td>Samuel Osei</td>
                        <td>₵175.00</td>
                        <td>Library Fee</td>
                        <td><span class="status-badge status-success">✓ Approved</span></td>
                        <td>Central</td>
                        <td><a href="#" style="color: #ff6b6b; text-decoration: none;">View</a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // Monthly Revenue Chart
    const monthlyCtx = document.getElementById('monthlyRevenueChart').getContext('2d');
    new Chart(monthlyCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Revenue',
                data: [45000, 52000, 48000, 61000, 55000, 67000, 72000, 68000, 75000, 80000, 85000, 92000],
                borderColor: '#ff6b6b',
                backgroundColor: 'rgba(255, 107, 107, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#ff6b6b',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: {
                    ticks: { color: '#a0a0a0' },
                    grid: { color: 'rgba(255, 255, 255, 0.05)' }
                },
                x: {
                    ticks: { color: '#a0a0a0' },
                    grid: { display: false }
                }
            }
        }
    });

    // Enrollment Chart
    const enrollmentCtx = document.getElementById('enrollmentChart').getContext('2d');
    new Chart(enrollmentCtx, {
        type: 'bar',
        data: {
            labels: ['Form 1', 'Form 2', 'Form 3', 'Form 4', 'Form 5', 'Form 6'],
            datasets: [{
                label: 'Students',
                data: [150, 145, 140, 135, 128, 95],
                backgroundColor: ['#ff6b6b', '#10b981', '#3b82f6', '#f59e0b', '#8b5cf6', '#06b6d4'],
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: {
                    ticks: { color: '#a0a0a0' },
                    grid: { color: 'rgba(255, 255, 255, 0.05)' }
                },
                x: {
                    ticks: { color: '#a0a0a0' },
                    grid: { display: false }
                }
            }
        }
    });

    // Performance Chart
    const perfCtx = document.getElementById('performanceChart').getContext('2d');
    new Chart(perfCtx, {
        type: 'radar',
        data: {
            labels: ['Attendance', 'Academics', 'Discipline', 'Sports', 'Creativity'],
            datasets: [{
                label: 'Current Performance',
                data: [85, 78, 82, 76, 88],
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.15)',
                borderWidth: 2,
                pointBackgroundColor: '#10b981',
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#a0a0a0' }
                }
            },
            scales: {
                r: {
                    ticks: { color: '#a0a0a0' },
                    grid: { color: 'rgba(255, 255, 255, 0.1)' }
                }
            }
        }
    });

    // Time Series Chart
    const timeCtx = document.getElementById('timeSeriesChart').getContext('2d');
    new Chart(timeCtx, {
        type: 'line',
        data: {
            labels: ['00:00', '04:00', '08:00', '12:00', '16:00', '20:00', '24:00'],
            datasets: [
                {
                    label: 'Impression',
                    data: [20, 25, 30, 50, 45, 30, 20],
                    borderColor: '#ff6b6b',
                    backgroundColor: 'rgba(255, 107, 107, 0.05)',
                    fill: true,
                    tension: 0.4
                },
                {
                    label: 'Turnover',
                    data: [15, 20, 25, 45, 40, 25, 15],
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.05)',
                    fill: true,
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#a0a0a0' }
                }
            },
            scales: {
                y: {
                    ticks: { color: '#a0a0a0' },
                    grid: { color: 'rgba(255, 255, 255, 0.05)' }
                },
                x: {
                    ticks: { color: '#a0a0a0' },
                    grid: { display: false }
                }
            }
        }
    });
</script>

</body>
</html>
