<?php
// admin/generate-results.php - Generate Student Results
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Generate Results';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get active term
try {
    $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_active = 1");
    $stmt->execute([$school_id]);
    $active_term = $stmt->fetch();
} catch (PDOException $e) {
    try {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_current = 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    } catch (PDOException $e2) {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY start_date DESC LIMIT 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    }
}

// Get classes
$classes = [];
try {
    $has_school_id = count($db->query("SHOW COLUMNS FROM classes LIKE 'school_id'")->fetchAll()) > 0;
    if ($has_school_id) {
        $stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
        $stmt->execute([$school_id]);
    } else {
        $stmt = $db->prepare("SELECT * FROM classes ORDER BY class_name");
        $stmt->execute();
    }
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $classes = [];
}

// Get students for dropdown
$students = [];
if (isset($_GET['class'])) {
    $class_id = (int)$_GET['class'];
    // Check if school_id exists in students table
    $has_school_id = count($db->query("SHOW COLUMNS FROM students LIKE 'school_id'")->fetchAll()) > 0;
    
    if ($has_school_id) {
        $stmt = $db->prepare("SELECT * FROM students WHERE school_id = ? AND class_id = ? ORDER BY first_name, last_name");
        $stmt->execute([$school_id, $class_id]);
    } else {
        $stmt = $db->prepare("SELECT * FROM students WHERE class_id = ? ORDER BY first_name, last_name");
        $stmt->execute([$class_id]);
    }
    $students = $stmt->fetchAll();
}

// Handle result generation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action == 'calculate_positions' && $active_term) {
        try {
            // First, ensure position column exists
            try {
                $db->exec("ALTER TABLE student_assessments ADD COLUMN position INT(11) NULL AFTER total_score");
            } catch (PDOException $e) {
                // Column might already exist, ignore error
            }
            
            // Try using stored procedure first
            try {
                $stmt = $db->prepare("CALL calculate_class_positions(?, NULL)");
                $stmt->execute([$active_term['term_id']]);
            } catch (PDOException $e) {
                // If stored procedure fails, use direct SQL update
                $stmt = $db->prepare("
                    UPDATE student_assessments sa1
                    SET sa1.position = (
                        SELECT COUNT(*) + 1
                        FROM student_assessments sa2
                        WHERE sa2.term_id = sa1.term_id
                        AND sa2.class_id = sa1.class_id
                        AND sa2.subject_id = sa1.subject_id
                        AND sa2.total_score > sa1.total_score
                    )
                    WHERE sa1.term_id = ?
                    AND sa1.total_score IS NOT NULL
                ");
                $stmt->execute([$active_term['term_id']]);
            }
            
            set_message('success', 'Positions calculated successfully for all classes!');
            redirect(APP_URL . '/admin/generate-results.php');
        } catch (PDOException $e) {
            set_message('error', 'Error calculating positions: ' . $e->getMessage());
        }
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Active Term Banner -->
    <?php if ($active_term): ?>
        <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #4CAF50, #8BC34A); color: white;">
            <div style="padding: 20px;">
                <h3 style="margin: 0 0 5px 0; color: white;">
                    <i class="fas fa-file-pdf"></i> Generate Results For
                </h3>
                <h2 style="margin: 0; color: white;"><?php echo $active_term['term_name']; ?></h2>
                <p style="margin: 5px 0 0 0; opacity: 0.9;">
                    <?php echo isset($active_term['session_year']) ? $active_term['session_year'] : ''; ?>
                </p>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            <i class="fas fa-exclamation-triangle"></i>
            <strong>No Active Term!</strong> Please set an active term to generate results.
        </div>
    <?php endif; ?>
    
    <!-- Calculate Positions -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-calculator"></i> Step 1: Calculate Positions</h3>
        </div>
        <div style="padding: 20px;">
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i>
                <strong>Important:</strong> Before generating results, you must calculate student positions/rankings. This will rank students based on their total scores in each subject.
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="calculate_positions">
                <button type="submit" class="btn btn-primary" onclick="return confirm('Calculate positions for all students? This may take a moment.')">
                    <i class="fas fa-calculator"></i> Calculate All Positions
                </button>
            </form>
        </div>
    </div>
    
    <!-- Generate Options -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 30px;">
        
        <!-- Single Student Result -->
        <div class="card">
            <div class="card-header" style="background: linear-gradient(135deg, #2196F3, #03A9F4); color: white;">
                <h3 style="color: white; margin: 0;">
                    <i class="fas fa-user"></i> Single Student
                </h3>
            </div>
            <div style="padding: 20px;">
                <p style="color: var(--text-secondary); margin-bottom: 20px;">
                    Generate result sheet for one student across all subjects.
                </p>
                
                <form method="GET" action="print-result.php" target="_blank">
                    <div style="margin-bottom: 15px;">
                        <label>Select Class:</label>
                        <select name="class" class="form-control" required onchange="this.form.submit()">
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>" <?php echo (isset($_GET['class']) && $_GET['class'] == $class['class_id']) ? 'selected' : ''; ?>>
                                    <?php echo $class['class_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <?php if (count($students) > 0): ?>
                        <div style="margin-bottom: 15px;">
                            <label>Select Student:</label>
                            <select name="student" class="form-control" required>
                                <option value="">-- Select Student --</option>
                                <?php foreach ($students as $student): ?>
                                    <option value="<?php echo $student['student_id']; ?>">
                                        <?php echo $student['admission_number'] . ' - ' . $student['first_name'] . ' ' . $student['last_name']; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary" style="width: 100%;">
                            <i class="fas fa-file-pdf"></i> Generate Result
                        </button>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        
        <!-- Class Results -->
        <div class="card">
            <div class="card-header" style="background: linear-gradient(135deg, #9C27B0, #E91E63); color: white;">
                <h3 style="color: white; margin: 0;">
                    <i class="fas fa-users"></i> Class Results
                </h3>
            </div>
            <div style="padding: 20px;">
                <p style="color: var(--text-secondary); margin-bottom: 20px;">
                    Generate result sheets for all students in a class.
                </p>
                
                <form method="GET" action="print-class-results.php" target="_blank">
                    <div style="margin-bottom: 15px;">
                        <label>Select Class:</label>
                        <select name="class" class="form-control" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>">
                                    <?php echo $class['class_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-file-pdf"></i> Generate Class Results
                    </button>
                </form>
            </div>
        </div>
        
        <!-- All Students -->
        <div class="card">
            <div class="card-header" style="background: linear-gradient(135deg, #FF5722, #FF9800); color: white;">
                <h3 style="color: white; margin: 0;">
                    <i class="fas fa-school"></i> All Students
                </h3>
            </div>
            <div style="padding: 20px;">
                <p style="color: var(--text-secondary); margin-bottom: 20px;">
                    Generate result sheets for all students in the school.
                </p>
                
                <form method="GET" action="print-all-results.php" target="_blank">
                    <div class="alert alert-warning" style="font-size: 13px; margin-bottom: 15px;">
                        <i class="fas fa-exclamation-triangle"></i>
                        This may take several minutes depending on the number of students.
                    </div>
                    
                    <button type="submit" class="btn btn-warning" style="width: 100%;" onclick="return confirm('Generate results for ALL students? This may take a while.')">
                        <i class="fas fa-file-pdf"></i> Generate All Results
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Publish Results -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header" style="background: linear-gradient(135deg, #4CAF50, #8BC34A); color: white;">
            <h3 style="color: white; margin: 0;">
                <i class="fas fa-globe"></i> Publish Results
            </h3>
        </div>
        <div style="padding: 20px;">
            <div class="alert alert-info" style="margin-bottom: 20px;">
                <i class="fas fa-info-circle"></i>
                <strong>Control Visibility:</strong> Published results can be viewed by students and parents. Unpublished results are only visible to administrators and teachers.
            </div>
            
            <?php
            // Get all terms for this school
            $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY session_year DESC, term_name");
            $stmt->execute([$school_id]);
            $all_terms = $stmt->fetchAll();
            ?>
            
            <div class="table-responsive">
                <table class="table">
                    <thead style="background: var(--bg-secondary);">
                        <tr>
                            <th>Session Year</th>
                            <th>Term</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($all_terms as $term): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($term['session_year']); ?></strong></td>
                                <td><?php echo htmlspecialchars($term['term_name']); ?></td>
                                <td>
                                    <?php if ($term['results_published']): ?>
                                        <span class="badge badge-success">
                                            <i class="fas fa-check-circle"></i> Published
                                        </span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">
                                            <i class="fas fa-lock"></i> Not Published
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button onclick="togglePublish(<?php echo $term['term_id']; ?>, <?php echo $term['results_published'] ? 0 : 1; ?>)" 
                                            class="btn btn-sm <?php echo $term['results_published'] ? 'btn-warning' : 'btn-success'; ?>">
                                        <?php if ($term['results_published']): ?>
                                            <i class="fas fa-lock"></i> Unpublish
                                        <?php else: ?>
                                            <i class="fas fa-globe"></i> Publish
                                        <?php endif; ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Instructions -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-info-circle"></i> Instructions</h3>
        </div>
        <div style="padding: 20px;">
            <ol style="margin: 0; padding-left: 20px;">
                <li style="margin-bottom: 10px;">
                    <strong>Calculate Positions:</strong> Click "Calculate All Positions" to rank students based on their scores.
                </li>
                <li style="margin-bottom: 10px;">
                    <strong>Single Student:</strong> Select a class and student to generate an individual result sheet.
                </li>
                <li style="margin-bottom: 10px;">
                    <strong>Class Results:</strong> Select a class to generate results for all students in that class.
                </li>
                <li style="margin-bottom: 10px;">
                    <strong>All Students:</strong> Generate results for every student in the school (use with caution).
                </li>
                <li style="margin-bottom: 10px;">
                    <strong>Publish Results:</strong> Use the "Publish Results" section to make results visible to students and parents.
                </li>
                <li>
                    <strong>Print/Download:</strong> Results will open in a new window where you can print or save as PDF.
                </li>
            </ol>
        </div>
    </div>
    
    <script>
    function togglePublish(termId, publish) {
        const action = publish ? 'publish' : 'unpublish';
        const message = publish ? 
            'Publish results for this term? Students and parents will be able to view them.' :
            'Unpublish results? Students and parents will no longer see them.';
        
        if (confirm(message)) {
            fetch('<?php echo APP_URL; ?>/admin/ajax/toggle-publish-results.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    term_id: termId,
                    publish: publish
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                alert('Network error: ' + error);
            });
        }
    }
    </script>
    
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
