<?php
// admin/setup_missing_tables.php - Create Missing Database Tables
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['super_admin']);
$db = Database::getInstance()->getConnection();

$success_count = 0;
$error_messages = [];

// Create expenses table
try {
    $db->exec("
        CREATE TABLE IF NOT EXISTS expenses (
            expense_id INT PRIMARY KEY AUTO_INCREMENT,
            school_id INT NOT NULL,
            expense_type VARCHAR(100) NOT NULL,
            description TEXT,
            amount DECIMAL(10,2) NOT NULL,
            expense_date DATE NOT NULL,
            status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE
        )
    ");
    $success_count++;
    log_activity($current_user['user_id'], "Created expenses table", 'database');
} catch (PDOException $e) {
    $error_messages[] = "Expenses table: " . $e->getMessage();
}

// Create invoices table
try {
    $db->exec("
        CREATE TABLE IF NOT EXISTS invoices (
            invoice_id INT PRIMARY KEY AUTO_INCREMENT,
            school_id INT NOT NULL,
            student_id INT,
            invoice_number VARCHAR(50) UNIQUE NOT NULL,
            description TEXT,
            amount DECIMAL(10,2) NOT NULL,
            status ENUM('pending', 'paid', 'overdue', 'cancelled') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
            FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE SET NULL
        )
    ");
    $success_count++;
    log_activity($current_user['user_id'], "Created invoices table", 'database');
} catch (PDOException $e) {
    $error_messages[] = "Invoices table: " . $e->getMessage();
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-database"></i> Database Setup
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Create missing database tables
            </p>
        </div>
    </div>
    
    <?php if ($success_count > 0): ?>
        <div class="card" style="border-left: 4px solid #4CAF50; background: rgba(76, 175, 80, 0.05);">
            <div style="padding: 20px;">
                <h3 style="margin-top: 0; color: #4CAF50;">
                    <i class="fas fa-check-circle"></i> Success!
                </h3>
                <p><?php echo $success_count; ?> table(s) created successfully.</p>
                
                <?php if (count($error_messages) == 0): ?>
                    <p style="color: #4CAF50; font-weight: 600; margin-bottom: 20px;">
                        All missing tables have been created. You can now use the Accountant module features.
                    </p>
                    <a href="<?php echo APP_URL; ?>/accountant/expenses.php" class="btn btn-success" style="text-decoration: none; display: inline-block;">
                        <i class="fas fa-arrow-right"></i> Go to Expenses
                    </a>
                    <a href="<?php echo APP_URL; ?>/accountant/invoices.php" class="btn btn-success" style="text-decoration: none; display: inline-block;">
                        <i class="fas fa-arrow-right"></i> Go to Invoices
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
    
    <?php if (count($error_messages) > 0): ?>
        <div class="card" style="border-left: 4px solid #f44336; background: rgba(244, 67, 54, 0.05); margin-top: 20px;">
            <div style="padding: 20px;">
                <h3 style="margin-top: 0; color: #f44336;">
                    <i class="fas fa-exclamation-triangle"></i> Errors Occurred
                </h3>
                <ul style="color: #f44336;">
                    <?php foreach ($error_messages as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
                <p style="color: #f44336;">Some tables may already exist. If you see "Table already exists" errors, this is normal.</p>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="card" style="margin-top: 30px; background: rgba(33, 150, 243, 0.05);">
        <div style="padding: 20px;">
            <h3 style="margin-top: 0;">What was created?</h3>
            <ul style="color: var(--text-secondary);">
                <li><strong>expenses table</strong> - Track school expenses (utilities, salaries, supplies, etc.)</li>
                <li><strong>invoices table</strong> - Generate and manage invoices for students</li>
            </ul>
        </div>
    </div>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
