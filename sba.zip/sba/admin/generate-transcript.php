<?php
// admin/generate-transcript.php - Generate Single Student Transcript
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['admin']);
$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

$student_id = (int)($_GET['student_id'] ?? 0);
$class_id = (int)($_GET['class_id'] ?? 0);

// If student_id is not provided, show selection interface
if ($student_id == 0) {
    // Get all students or students from selected class
    if ($class_id > 0) {
        $stmt = $db->prepare("
            SELECT s.student_id, s.admission_number, 
                   COALESCE(u.first_name, 'Unknown') as first_name, 
                   COALESCE(u.last_name, '') as last_name,
                   c.class_name
            FROM students s
            LEFT JOIN users u ON s.user_id = u.user_id
            LEFT JOIN classes c ON s.class_id = c.class_id
            WHERE s.school_id = ? AND s.class_id = ? AND s.status = 'active'
            ORDER BY u.first_name, u.last_name
        ");
        $stmt->execute([$school_id, $class_id]);
    } else {
        $stmt = $db->prepare("
            SELECT s.student_id, s.admission_number, 
                   COALESCE(u.first_name, 'Unknown') as first_name, 
                   COALESCE(u.last_name, '') as last_name,
                   c.class_name
            FROM students s
            LEFT JOIN users u ON s.user_id = u.user_id
            LEFT JOIN classes c ON s.class_id = c.class_id
            WHERE s.school_id = ? AND s.status = 'active'
            ORDER BY c.class_name, u.first_name, u.last_name
        ");
        $stmt->execute([$school_id]);
    }
    $students = $stmt->fetchAll();
    
    // Get all classes for filter
    $stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
    $stmt->execute([$school_id]);
    $classes = $stmt->fetchAll();
    
    // Show selection interface
    require_once BASE_PATH . '/includes/header.php';
    ?>
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-file-alt"></i> Generate Student Transcript</h3>
        </div>
        <div style="padding: 25px;">
            <div class="form-group" style="margin-bottom: 20px;">
                <label>Filter by Class</label>
                <select class="form-control" onchange="filterByClass(this.value)" style="max-width: 300px;">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['class_id']; ?>" <?php echo $class_id == $class['class_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($class['class_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <?php if (count($students) > 0): ?>
                <div class="alert alert-info" style="margin-bottom: 20px;">
                    <i class="fas fa-info-circle"></i> Select a student to generate their transcript
                </div>
                
                <div style="overflow-x: auto;">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Admission No.</th>
                                <th>Student Name</th>
                                <th>Class</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($student['admission_number']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['class_name'] ?? 'N/A'); ?></td>
                                    <td>
                                        <a href="?student_id=<?php echo $student['student_id']; ?><?php echo $class_id ? '&class_id='.$class_id : ''; ?>" 
                                           class="btn btn-primary btn-sm">
                                            <i class="fas fa-file-alt"></i> Generate Transcript
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i> 
                    No students found<?php echo $class_id ? ' in the selected class' : ''; ?>.
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    function filterByClass(classId) {
        if (classId) {
            window.location.href = '?class_id=' + classId;
        } else {
            window.location.href = '?';
        }
    }
    </script>
    
    <?php
    require_once BASE_PATH . '/includes/footer.php';
    exit;
}

// Get student info
try {
    $stmt = $db->prepare("
        SELECT s.*, sc.school_name, sc.logo as school_logo, 
               c.class_name,
               COALESCE(u.first_name, '-') as first_name, 
               COALESCE(u.last_name, '') as last_name
        FROM students s
        JOIN schools sc ON s.school_id = sc.school_id
        LEFT JOIN classes c ON s.class_id = c.class_id
        LEFT JOIN users u ON s.user_id = u.user_id
        WHERE s.student_id = ? AND s.school_id = ?
    ");
    $stmt->execute([$student_id, $school_id]);
    $student = $stmt->fetch();
} catch (PDOException $e) {
    die('Error fetching student: ' . $e->getMessage());
}

if (!$student) {
    die('Student not found');
}

// Get all results grouped by class and term
$stmt = $db->prepare("
    SELECT 
        COALESCE(c.class_name, 'N/A') as class_name,
        t.term_name,
        t.start_date,
        subj.subject_name,
        sa.total_score,
        sa.grade,
        sa.remark,
        sa.ca_score,
        sa.midterm_score,
        sa.exam_score
    FROM student_assessments sa
    LEFT JOIN classes c ON sa.class_id = c.class_id
    JOIN terms t ON sa.term_id = t.term_id
    JOIN subjects subj ON sa.subject_id = subj.subject_id
    WHERE sa.student_id = ? AND sa.school_id = ?
    ORDER BY t.start_date, subj.subject_name
");
$stmt->execute([$student_id, $school_id]);
$all_results = $stmt->fetchAll();

// If class_id is NULL in student_assessments, get it from students table
if (count($all_results) > 0) {
    foreach ($all_results as &$result) {
        if ($result['class_name'] == 'N/A') {
            $result['class_name'] = $student['class_name'] ?? 'Unknown';
        }
        // Calculate total if missing
        if (($result['total_score'] == 0 || $result['total_score'] === null) && 
            ($result['ca_score'] > 0 || $result['midterm_score'] > 0 || $result['exam_score'] > 0)) {
            $result['total_score'] = calculate_total_score(
                $result['ca_score'] ?? 0,
                $result['midterm_score'] ?? 0,
                $result['exam_score'] ?? 0
            );
            if (empty($result['grade']) || empty($result['remark'])) {
                $grade_info = calculate_grade_new($result['total_score']);
                $result['grade'] = $grade_info['grade'];
                $result['remark'] = $grade_info['remark'];
            }
        }
    }
    unset($result);
}

// Group results by class and term
$transcript = [];
foreach ($all_results as $result) {
    $class = $result['class_name'];
    $term = $result['term_name'];
    
    if (!isset($transcript[$class])) {
        $transcript[$class] = [];
    }
    
    if (!isset($transcript[$class][$term])) {
        $transcript[$class][$term] = [];
    }
    
    $transcript[$class][$term][] = [
        'subject' => $result['subject_name'],
        'score' => $result['total_score'],
        'grade' => $result['grade'],
        'remark' => $result['remark']
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Official Transcript - <?php echo htmlspecialchars(($student['first_name'] ?? 'Student') . ' ' . ($student['last_name'] ?? '')); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            padding: 20px;
            background: white;
        }
        
        .transcript {
            max-width: 900px;
            margin: 0 auto;
            border: 3px solid #333;
            padding: 30px;
            background: white;
        }
        
        .header {
            text-align: center;
            border-bottom: 3px solid #333;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .school-logo {
            width: 100px;
            height: 100px;
            object-fit: contain;
            margin-bottom: 10px;
        }
        
        .school-name {
            font-size: 28px;
            font-weight: bold;
            color: #2196F3;
            margin-bottom: 5px;
        }
        
        .transcript-title {
            font-size: 24px;
            font-weight: bold;
            margin: 10px 0;
            text-transform: uppercase;
            color: #333;
        }
        
        .student-info {
            background: #f5f5f5;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        
        .student-info p {
            margin: 8px 0;
            font-size: 14px;
        }
        
        .student-info strong {
            display: inline-block;
            min-width: 150px;
        }
        
        .class-section {
            margin-bottom: 40px;
            page-break-inside: avoid;
        }
        
        .class-title {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 15px;
            padding: 10px;
            background: #2196F3;
            color: white;
            border-radius: 5px;
        }
        
        .term-section {
            margin-bottom: 25px;
            page-break-inside: avoid;
        }
        
        .term-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
            color: #2196F3;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }
        
        th {
            background: #f0f0f0;
            font-weight: bold;
            padding: 10px;
            text-align: left;
            border: 1px solid #333;
        }
        
        td {
            border: 1px solid #333;
            padding: 8px;
        }
        
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        
        .text-center {
            text-align: center;
        }
        
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #ddd;
            color: #666;
            font-size: 12px;
        }
        
        @media print {
            @page {
                size: A4;
                margin: 15mm;
            }
            
            body {
                padding: 0;
            }
            
            .no-print {
                display: none;
            }
            
            .transcript {
                border: none;
                padding: 0;
                max-width: 100%;
            }
            
            .class-section {
                page-break-inside: avoid;
            }
            
            .term-section {
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="transcript">
        <!-- Header -->
        <div class="header">
            <?php if (!empty($student['school_logo'])): ?>
                <img src="<?php echo APP_URL . '/uploads/logos/' . $student['school_logo']; ?>" 
                     alt="School Logo" class="school-logo">
            <?php endif; ?>
            <div class="school-name"><?php echo strtoupper($student['school_name']); ?></div>
            <div class="transcript-title">Official Transcript</div>
        </div>
        
        <!-- Student Information -->
        <div class="student-info">
            <p><strong>Student Name:</strong> <?php echo htmlspecialchars(($student['first_name'] ?? 'N/A') . ' ' . ($student['last_name'] ?? '')); ?></p>
            <p><strong>Admission Number:</strong> <?php echo htmlspecialchars($student['admission_number'] ?? 'N/A'); ?></p>
            <p><strong>Date Generated:</strong> <?php echo date('F d, Y'); ?></p>
        </div>
        
        <?php if (count($transcript) > 0): ?>
            <?php foreach ($transcript as $class_name => $terms): ?>
                <div class="class-section">
                    <div class="class-title"><?php echo strtoupper($class_name); ?></div>
                    
                    <?php foreach ($terms as $term_name => $subjects): ?>
                        <div class="term-section">
                            <div class="term-title"><?php echo $term_name; ?></div>
                            
                            <table>
                                <thead>
                                    <tr>
                                        <th>Subject</th>
                                        <th class="text-center">Score</th>
                                        <th class="text-center">Grade</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($subjects as $subject): ?>
                                        <tr>
                                            <td><?php echo $subject['subject']; ?></td>
                                            <td class="text-center"><?php echo number_format($subject['score'], 1); ?></td>
                                            <td class="text-center"><?php echo $subject['grade']; ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align: center; padding: 60px;">
                <p style="font-size: 18px; color: #666;">No assessment records found for this student.</p>
            </div>
        <?php endif; ?>
        
        <!-- Footer -->
        <div class="footer">
            <p>This is an official transcript generated on <?php echo date('F d, Y \a\t h:i A'); ?></p>
            <p><?php echo $student['school_name']; ?></p>
        </div>
    </div>
    
    <div class="no-print" style="text-align: center; margin-top: 30px;">
        <button onclick="window.print()" class="btn" style="padding: 12px 30px; background: #2196F3; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px;">
            <i class="fas fa-print"></i> Print Transcript
        </button>
        <button onclick="window.close()" class="btn" style="padding: 12px 30px; background: #666; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; margin-left: 10px;">
            Close
        </button>
    </div>
</body>
</html>
