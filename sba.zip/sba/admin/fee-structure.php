<?php
// admin/fee-structure.php - Fee Structure Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Fee Structure';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $class_id = sanitize_input($_POST['class_id']);
            $term_id = sanitize_input($_POST['term_id']);
            $fee_type = sanitize_input($_POST['fee_type']);
            $amount = sanitize_input($_POST['amount']);
            $description = sanitize_input($_POST['description']);
            
            try {
                // Insert fee structure
                $stmt = $db->prepare("
                    INSERT INTO fee_structure (school_id, class_id, term_id, fee_type, amount, description, status, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, 'active', NOW())
                ");
                $stmt->execute([$school_id, $class_id, $term_id, $fee_type, $amount, $description]);
                
                $new_fee_id = (int)$db->lastInsertId();
                
                // Automatically bill all students in this class
                // Get all active students in this class
                $stmt = $db->prepare("
                    SELECT DISTINCT s.student_id, s.user_id
                    FROM students s
                    WHERE s.class_id = ? AND s.school_id = ? AND s.status = 'active'
                ");
                $stmt->execute([$class_id, $school_id]);
                $students = $stmt->fetchAll();
                
                // Debug: Log how many students found
                error_log("Fee Structure: Found " . count($students) . " students in class_id=$class_id, school_id=$school_id");
                
                // Create fee payment records for each student
                $billed_count = 0;
                $error_count = 0;
                foreach ($students as $student) {
                    try {
                        // Check if fee_payments table exists and has required columns
                        // Check if this student already has a record for this fee in this term
                        $check_stmt = $db->prepare("
                            SELECT COUNT(*) as count FROM fee_payments
                            WHERE student_id = ? AND term_id = ? AND fee_type = ? AND school_id = ?
                        ");
                        $check_stmt->execute([$student['student_id'], $term_id, $fee_type, $school_id]);
                        $exists = $check_stmt->fetch()['count'] > 0;
                        
                        if (!$exists) {
                            // Create fee payment record
                            $insert_stmt = $db->prepare("
                                INSERT INTO fee_payments (school_id, student_id, term_id, fee_type, amount, status, due_date, created_at)
                                VALUES (?, ?, ?, ?, ?, 'pending', DATE_ADD(NOW(), INTERVAL 7 DAY), NOW())
                            ");
                            $insert_stmt->execute([$school_id, $student['student_id'], $term_id, $fee_type, $amount]);
                            $billed_count++;
                            error_log("Fee Structure: Billed student_id=" . $student['student_id'] . " for $fee_type");
                        } else {
                            error_log("Fee Structure: Skipped student_id=" . $student['student_id'] . " - already has $fee_type");
                        }
                    } catch (PDOException $e) {
                        $error_count++;
                        error_log("Fee Structure: Failed to bill student " . $student['student_id'] . ": " . $e->getMessage());
                    }
                }
                
                // Log activity
                if (isset($GLOBALS['audit_logger'])) {
                    $GLOBALS['audit_logger']->log(
                        "Added fee structure: $fee_type (Billed $billed_count students)",
                        'fee_structure',
                        $new_fee_id,
                        null,
                        ['fee_type' => $fee_type, 'amount' => $amount, 'students_billed' => $billed_count],
                        true
                    );
                } else {
                    log_activity($current_user['user_id'], "Added fee structure: $fee_type (Billed $billed_count students)", 'fee_structure', $new_fee_id);
                }
                
                // Show detailed message
                $total_students = count($students);
                if ($billed_count == 0 && $total_students > 0) {
                    set_message('warning', "Fee structure added but 0 students billed! Found $total_students students in class. Check error log for details.");
                } elseif ($billed_count > 0 && $error_count > 0) {
                    set_message('warning', "Fee structure added! Billed $billed_count students successfully, $error_count failed. Check error log.");
                } elseif ($billed_count == 0 && $total_students == 0) {
                    set_message('info', "Fee structure added! No active students found in this class to bill.");
                } else {
                    set_message('success', "Fee structure added successfully! Billed $billed_count students.");
                }
                redirect(APP_URL . '/admin/fee-structure.php');
            } catch (PDOException $e) {
                set_message('error', 'Error adding fee structure: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'edit') {
            $fee_id = sanitize_input($_POST['fee_id']);
            $class_id = sanitize_input($_POST['class_id']);
            $term_id = sanitize_input($_POST['term_id']);
            $fee_type = sanitize_input($_POST['fee_type']);
            $amount = sanitize_input($_POST['amount']);
            $description = sanitize_input($_POST['description']);
            
            try {
                // Try with fee_id column first
                try {
                    // Get old fee structure to track changes
                    $old_stmt = $db->prepare("SELECT * FROM fee_structure WHERE fee_id = ? AND school_id = ?");
                    $old_stmt->execute([$fee_id, $school_id]);
                    $old_fee = $old_stmt->fetch();
                    
                    // Update fee structure
                    $stmt = $db->prepare("
                        UPDATE fee_structure 
                        SET class_id = ?, term_id = ?, fee_type = ?, amount = ?, description = ?, updated_at = NOW()
                        WHERE fee_id = ? AND school_id = ?
                    ");
                    $stmt->execute([$class_id, $term_id, $fee_type, $amount, $description, $fee_id, $school_id]);
                } catch (PDOException $e) {
                    // Try with structure_id column
                    $old_stmt = $db->prepare("SELECT * FROM fee_structure WHERE structure_id = ? AND school_id = ?");
                    $old_stmt->execute([$fee_id, $school_id]);
                    $old_fee = $old_stmt->fetch();
                    
                    // Update fee structure
                    $stmt = $db->prepare("
                        UPDATE fee_structure 
                        SET class_id = ?, term_id = ?, fee_type = ?, amount = ?, description = ?, updated_at = NOW()
                        WHERE structure_id = ? AND school_id = ?
                    ");
                    $stmt->execute([$class_id, $term_id, $fee_type, $amount, $description, $fee_id, $school_id]);
                }
                
                // Update student bills if amount changed
                if ($old_fee && $old_fee['amount'] != $amount) {
                    try {
                        // Update fee payments for this fee type in this term
                        $update_stmt = $db->prepare("
                            UPDATE fee_payments
                            SET amount = ?, updated_at = NOW()
                            WHERE term_id = ? AND fee_type = ? AND school_id = ? AND status IN ('pending', 'partially_paid')
                        ");
                        $update_stmt->execute([$amount, $term_id, $fee_type, $school_id]);
                        
                        $updated_count = $update_stmt->rowCount();
                        set_message('success', "Fee structure updated successfully! Updated $updated_count student bills.");
                    } catch (PDOException $e) {
                        set_message('success', 'Fee structure updated successfully!');
                    }
                } else {
                    set_message('success', 'Fee structure updated successfully!');
                }
                
                // Log activity
                if (isset($GLOBALS['audit_logger'])) {
                    $GLOBALS['audit_logger']->log(
                        "Updated fee structure ID: $fee_id",
                        'fee_structure',
                        (int)$fee_id,
                        $old_fee,
                        compact('class_id', 'term_id', 'fee_type', 'amount'),
                        true
                    );
                } else {
                    log_activity($current_user['user_id'], "Updated fee structure ID: $fee_id", 'fee_structure', (int)$fee_id);
                }
                
                redirect(APP_URL . '/admin/fee-structure.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating fee structure: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            $fee_id = sanitize_input($_POST['fee_id']);
            
            try {
                // Try with fee_id column first (newer schema)
                try {
                    $get_stmt = $db->prepare("SELECT term_id, fee_type FROM fee_structure WHERE fee_id = ? AND school_id = ?");
                    $get_stmt->execute([$fee_id, $school_id]);
                    $fee_details = $get_stmt->fetch();
                    
                    if ($fee_details) {
                        // Delete fee structure
                        $stmt = $db->prepare("DELETE FROM fee_structure WHERE fee_id = ? AND school_id = ?");
                        $stmt->execute([$fee_id, $school_id]);
                    }
                } catch (PDOException $e) {
                    // Try with structure_id column (older schema)
                    $get_stmt = $db->prepare("SELECT term_id, fee_type FROM fee_structure WHERE structure_id = ? AND school_id = ?");
                    $get_stmt->execute([$fee_id, $school_id]);
                    $fee_details = $get_stmt->fetch();
                    
                    if ($fee_details) {
                        // Delete fee structure
                        $stmt = $db->prepare("DELETE FROM fee_structure WHERE structure_id = ? AND school_id = ?");
                        $stmt->execute([$fee_id, $school_id]);
                    }
                }
                
                // Also delete/cancel associated unpaid student bills
                if ($fee_details) {
                    try {
                        $delete_bills = $db->prepare("
                            DELETE FROM fee_payments
                            WHERE term_id = ? AND fee_type = ? AND school_id = ? AND status = 'pending'
                        ");
                        $delete_bills->execute([$fee_details['term_id'], $fee_details['fee_type'], $school_id]);
                        $deleted_bills = $delete_bills->rowCount();
                        
                        set_message('success', "Fee structure deleted! Removed $deleted_bills pending student bills.");
                    } catch (PDOException $e3) {
                        set_message('success', 'Fee structure deleted successfully!');
                    }
                } else {
                    set_message('success', 'Fee structure deleted successfully!');
                }
                
                // Log activity
                if (isset($GLOBALS['audit_logger'])) {
                    $GLOBALS['audit_logger']->log(
                        "Deleted fee structure ID: $fee_id",
                        'fee_structure',
                        (int)$fee_id,
                        null,
                        ['fee_type' => $fee_details['fee_type'] ?? ''],
                        true
                    );
                } else {
                    log_activity($current_user['user_id'], "Deleted fee structure ID: $fee_id", 'fee_structure', (int)$fee_id);
                }
                
                redirect(APP_URL . '/admin/fee-structure.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting fee structure: ' . $e->getMessage());
            }
        }
    }
}

// Get all fee structures
$stmt = $db->prepare("
    SELECT fs.fee_id, fs.school_id, fs.class_id, fs.term_id, fs.fee_type, fs.amount, fs.description, fs.created_at, fs.status, 
           c.class_name, t.term_name, t.session_year
    FROM fee_structure fs
    LEFT JOIN classes c ON fs.class_id = c.class_id
    LEFT JOIN terms t ON fs.term_id = t.term_id
    WHERE fs.school_id = ?
    ORDER BY c.class_name, t.start_date DESC, fs.fee_type
");
$stmt->execute([$school_id]);
$fee_structures = $stmt->fetchAll();

// Get classes for dropdown
$stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? AND status = 'active' ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get terms for dropdown
$terms = [];
try {
    // Check if session_year column exists
    $has_session_year = count($db->query("SHOW COLUMNS FROM terms LIKE 'session_year'")->fetchAll()) > 0;
    $has_school_id = count($db->query("SHOW COLUMNS FROM terms LIKE 'school_id'")->fetchAll()) > 0;
    
    $query = "SELECT ";
    if ($has_session_year) {
        $query .= "*, session_year";
    } else {
        $query .= "*";
    }
    $query .= " FROM terms WHERE ";
    
    if ($has_school_id) {
        $query .= "school_id = ? ";
        $stmt = $db->prepare($query . "ORDER BY start_date DESC");
        $stmt->execute([$school_id]);
    } else {
        $stmt = $db->prepare($query . "ORDER BY start_date DESC");
        $stmt->execute();
    }
    $terms = $stmt->fetchAll();
} catch (PDOException $e) {
    $terms = [];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
            <button class="btn btn-primary" onclick="showAddModal()">
                <i class="fas fa-plus"></i> Add Fee Structure
            </button>
        </div>
    </div>
    
    <!-- Fee Structure Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-money-bill-wave"></i> Fee Structure (<?php echo count($fee_structures); ?>)</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Class</th>
                        <th>Term</th>
                        <th>Fee Type</th>
                        <th>Amount</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($fee_structures) > 0): ?>
                        <?php foreach ($fee_structures as $fee): ?>
                            <tr>
                                <td><strong><?php echo $fee['class_name']; ?></strong></td>
                                <td>
                                    <span class="badge badge-info">
                                        <?php echo $fee['term_name'] . ' (' . $fee['session_year'] . ')'; ?>
                                    </span>
                                </td>
                                <td>
                                    <span style="text-transform: capitalize;">
                                        <?php echo str_replace('_', ' ', $fee['fee_type']); ?>
                                    </span>
                                </td>
                                <td>
                                    <strong style="color: var(--success-green); font-size: 16px;">
                                        <?php echo format_currency($fee['amount']); ?>
                                    </strong>
                                </td>
                                <td><?php echo $fee['description'] ?: 'N/A'; ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info" 
                                            data-fee='<?php echo htmlspecialchars(json_encode($fee, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT), ENT_QUOTES, 'UTF-8'); ?>'
                                            onclick="editFeeData(this)">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger" 
                                            data-fee-id="<?php echo htmlspecialchars($fee['fee_id'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                            data-fee-type="<?php echo htmlspecialchars($fee['fee_type'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                                            onclick="deleteFeeData(this)">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 60px;">
                                <i class="fas fa-money-bill-wave" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                                <h3 style="margin-bottom: 10px;">No Fee Structure Yet</h3>
                                <p style="color: var(--text-secondary); margin-bottom: 20px;">Set up fees for different classes and terms</p>
                                <button class="btn btn-primary" onclick="showAddModal()">
                                    <i class="fas fa-plus"></i> Add Fee Structure
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Add/Edit Fee Modal -->
    <div id="feeModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Add Fee Structure</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="feeForm">
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="fee_id" id="feeId">
                
                <div class="form-group">
                    <label for="class_id">Class *</label>
                    <select name="class_id" id="class_id" required>
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>"><?php echo $class['class_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="term_id">Term *</label>
                    <select name="term_id" id="term_id" required>
                        <option value="">-- Select Term --</option>
                        <?php foreach ($terms as $term): ?>
                            <option value="<?php echo $term['term_id']; ?>">
                                <?php echo $term['term_name'] . ' (' . $term['session_year'] . ')'; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="fee_type">Fee Type *</label>
                    <select name="fee_type" id="fee_type" required>
                        <option value="">-- Select Fee Type --</option>
                        <option value="tuition">Tuition Fee</option>
                        <option value="exam">Exam Fee</option>
                        <option value="library">Library Fee</option>
                        <option value="sports">Sports Fee</option>
                        <option value="lab">Laboratory Fee</option>
                        <option value="computer">Computer Fee</option>
                        <option value="transport">Transport Fee</option>
                        <option value="uniform">Uniform Fee</option>
                        <option value="development">Development Fee</option>
                        <option value="other">Other Fee</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="amount">Amount (₦) *</label>
                    <input type="number" name="amount" id="amount" step="0.01" min="0" placeholder="e.g., 50000" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" id="description" rows="2" placeholder="Optional description"></textarea>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Fee
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showAddModal() {
        document.getElementById('feeModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Add Fee Structure';
        document.getElementById('formAction').value = 'add';
        document.getElementById('feeForm').reset();
        document.getElementById('feeId').value = '';
    }
    
    function editFee(fee) {
        document.getElementById('feeModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Edit Fee Structure';
        document.getElementById('formAction').value = 'edit';
        document.getElementById('feeId').value = fee.fee_id;
        document.getElementById('class_id').value = fee.class_id;
        document.getElementById('term_id').value = fee.term_id;
        document.getElementById('fee_type').value = fee.fee_type;
        document.getElementById('amount').value = fee.amount;
        document.getElementById('description').value = fee.description || '';
    }
    
    function editFeeData(button) {
        try {
            const fee = JSON.parse(button.getAttribute('data-fee'));
            editFee(fee);
        } catch (e) {
            console.error('Error parsing fee data:', e);
            alert('Error loading fee data. Please refresh the page.');
        }
    }
    
    function closeModal() {
        document.getElementById('feeModal').style.display = 'none';
    }
    
    function deleteFee(feeId, feeType) {
        if (confirm('Are you sure you want to delete ' + feeType + ' fee?')) {
            const form = document.createElement('form');
            form.method = 'POST';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete';
            
            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'fee_id';
            idInput.value = feeId;
            
            form.appendChild(actionInput);
            form.appendChild(idInput);
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    function deleteFeeData(button) {
        const feeId = button.getAttribute('data-fee-id');
        const feeType = button.getAttribute('data-fee-type');
        deleteFee(feeId, feeType);
    }
    
    // Close modal on outside click
    document.getElementById('feeModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
