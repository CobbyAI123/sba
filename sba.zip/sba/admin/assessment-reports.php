<?php
// admin/assessment-reports.php - Assessment and Performance Reports
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Assessment Reports';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get filter parameters
$class_filter = isset($_GET['class_id']) ? (int)$_GET['class_id'] : null;
$term_filter = isset($_GET['term_id']) ? (int)$_GET['term_id'] : null;
$subject_filter = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : null;

// Get all classes
$stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get all terms
try {
    $stmt = $db->prepare("SELECT term_id, term_name, start_date, end_date, session_year FROM terms WHERE school_id = ? ORDER BY term_id DESC, term_name");
    $stmt->execute([$school_id]);
    $terms = $stmt->fetchAll();
} catch (PDOException $e) {
    // If school_id doesn't exist in terms, get all terms
    try {
        $stmt = $db->prepare("SELECT term_id, term_name, start_date, end_date, session_year FROM terms ORDER BY term_id DESC, term_name");
        $stmt->execute();
        $terms = $stmt->fetchAll();
    } catch (PDOException $e2) {
        // If columns don't exist, just get basic columns
        $stmt = $db->prepare("SELECT term_id, term_name FROM terms ORDER BY term_id DESC, term_name");
        $stmt->execute();
        $terms = $stmt->fetchAll();
    }
}

// Get all subjects
$stmt = $db->prepare("SELECT subject_id, subject_name FROM subjects WHERE school_id = ? ORDER BY subject_name");
$stmt->execute([$school_id]);
$subjects = $stmt->fetchAll();

// Build query for assessment data
// Try student_assessments table first (newer system), then marks table (older system)
$assessments = [];
try {
    $query = "
        SELECT 
            sa.assessment_id as mark_id,
            s.admission_number,
            COALESCE(u.first_name, 'Unknown') as first_name,
            COALESCE(u.last_name, '') as last_name,
            c.class_name,
            sub.subject_name,
            t.term_name,
            t.start_date,
            t.end_date,
            t.session_year,
            sa.ca_score,
            sa.midterm_score,
            sa.exam_score,
            sa.total_score,
            sa.grade,
            sa.remark,
            sa.position,
            sa.created_at,
            CONCAT(tu.first_name, ' ', tu.last_name) as teacher_name
        FROM student_assessments sa
        JOIN students s ON sa.student_id = s.student_id
        LEFT JOIN users u ON s.user_id = u.user_id
        JOIN classes c ON sa.class_id = c.class_id
        JOIN subjects sub ON sa.subject_id = sub.subject_id
        JOIN terms t ON sa.term_id = t.term_id
        LEFT JOIN users tu ON sa.teacher_id = tu.user_id
        WHERE 1=1
    ";
    
    $params = [];
    
    if ($class_filter) {
        $query .= " AND sa.class_id = ?";
        $params[] = $class_filter;
    }
    
    if ($term_filter) {
        $query .= " AND sa.term_id = ?";
        $params[] = $term_filter;
    }
    
    if ($subject_filter) {
        $query .= " AND sa.subject_id = ?";
        $params[] = $subject_filter;
    }
    
    $query .= " ORDER BY t.term_id DESC, t.term_name, c.class_name, sub.subject_name, sa.total_score DESC";
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $assessments = $stmt->fetchAll();
} catch (PDOException $e) {
    // Fallback to marks table if student_assessments doesn't exist
    try {
        $query = "
            SELECT 
                sa.assessment_id,
                s.admission_number,
                COALESCE(u.first_name, 'Unknown') as first_name,
                COALESCE(u.last_name, '') as last_name,
                c.class_name,
                sub.subject_name,
                t.term_name,
                t.start_date,
                t.end_date,
                t.session_year,
                sa.ca_score as ca_score,
                sa.midterm_score as midterm_score,
                sa.exam_score as exam_score,
                sa.total_score as total_score,
                sa.grade,
                sa.remark as remark,
                sa.position as position,
                sa.created_at,
                CONCAT(tu.first_name, ' ', tu.last_name) as teacher_name
            FROM student_assessments sa
            JOIN students s ON sa.student_id = s.student_id
            LEFT JOIN users u ON s.user_id = u.user_id
            JOIN classes c ON sa.class_id = c.class_id
            JOIN subjects sub ON sa.subject_id = sub.subject_id
            JOIN terms t ON sa.term_id = t.term_id
            LEFT JOIN users tu ON sa.teacher_id = tu.user_id
            WHERE 1=1
        ";
        
        $params = [];
        
        if ($class_filter) {
            $query .= " AND sa.class_id = ?";
            $params[] = $class_filter;
        }
        
        if ($term_filter) {
            $query .= " AND sa.term_id = ?";
            $params[] = $term_filter;
        }
        
        if ($subject_filter) {
            $query .= " AND sa.subject_id = ?";
            $params[] = $subject_filter;
        }
        
        $query .= " ORDER BY t.term_id DESC, t.term_name, c.class_name, sub.subject_name, sa.total_score DESC";
        
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $assessments = $stmt->fetchAll();
    } catch (PDOException $e2) {
        $assessments = [];
    }
}

// Calculate statistics
$total_assessments = count($assessments);
$average_score = 0;
$pass_count = 0;
$fail_count = 0;

if ($total_assessments > 0) {
    $total_sum = 0;
    foreach ($assessments as $assessment) {
        $total_sum += $assessment['total_score'];
        if ($assessment['total_score'] >= 50) {
            $pass_count++;
        } else {
            $fail_count++;
        }
    }
    $average_score = $total_sum / $total_assessments;
}

$pass_rate = $total_assessments > 0 ? ($pass_count / $total_assessments * 100) : 0;

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .report-filters {
        background: var(--card-bg);
        padding: 25px;
        border-radius: 12px;
        margin-bottom: 25px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    .filter-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        align-items: end;
    }
    
    .stats-summary {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .summary-card {
        background: var(--card-bg);
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        gap: 15px;
    }
    
    .summary-icon {
        width: 50px;
        height: 50px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
    }
    
    .summary-icon.blue { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
    .summary-icon.green { background: linear-gradient(135deg, #00d68f 0%, #00b074 100%); color: white; }
    .summary-icon.orange { background: linear-gradient(135deg, #ffa726 0%, #fb8c00 100%); color: white; }
    .summary-icon.red { background: linear-gradient(135deg, #ff3d71 0%, #c81e1e 100%); color: white; }
    
    .summary-details h3 {
        margin: 0;
        font-size: 28px;
        font-weight: 700;
    }
    
    .summary-details p {
        margin: 5px 0 0 0;
        color: var(--text-secondary);
        font-size: 14px;
    }
    
    .grade-badge {
        display: inline-block;
        padding: 5px 12px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 14px;
    }
    
    .grade-badge.hp { background: #00d68f; color: white; }
    .grade-badge.p { background: #2d5bff; color: white; }
    .grade-badge.ap { background: #ffa726; color: white; }
    .grade-badge.d { background: #ffd93d; color: #333; }
    .grade-badge.e { background: #ff3d71; color: white; }
    
    .score-cell {
        font-weight: 600;
        font-size: 15px;
    }
    
    .export-buttons {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
    }
    
    @media print {
        .report-filters, .export-buttons, .sidebar, .header, .btn {
            display: none !important;
        }
        .content {
            margin: 0 !important;
            padding: 20px !important;
        }
    }
    </style>
    
    <!-- Page Header -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
        <h2><i class="fas fa-chart-bar"></i> Assessment Reports</h2>
        <div class="export-buttons">
            <button onclick="window.print()" class="btn btn-secondary">
                <i class="fas fa-print"></i> Print
            </button>
            <button onclick="exportToCSV()" class="btn btn-primary">
                <i class="fas fa-download"></i> Export CSV
            </button>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="report-filters">
        <h3 style="margin-bottom: 20px;"><i class="fas fa-filter"></i> Filter Reports</h3>
        <form method="GET" class="filter-grid">
            <div class="form-group" style="margin: 0;">
                <label>Class</label>
                <select name="class_id" class="form-control">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['class_id']; ?>" <?php echo $class_filter == $class['class_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($class['class_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group" style="margin: 0;">
                <label>Term</label>
                <select name="term_id" class="form-control">
                    <option value="">All Terms</option>
                    <?php foreach ($terms as $term): ?>
                        <?php
                        // Generate session year from dates if not available
                        $session_year = isset($term['session_year']) && !empty($term['session_year']) 
                            ? $term['session_year']
                            : (isset($term['start_date']) && isset($term['end_date'])
                                ? date('Y', strtotime($term['start_date'])) . '/' . date('Y', strtotime($term['end_date']))
                                : 'N/A');
                        ?>
                        <option value="<?php echo $term['term_id']; ?>" <?php echo $term_filter == $term['term_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($term['term_name'] . ' - ' . $session_year); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group" style="margin: 0;">
                <label>Subject</label>
                <select name="subject_id" class="form-control">
                    <option value="">All Subjects</option>
                    <?php foreach ($subjects as $subject): ?>
                        <option value="<?php echo $subject['subject_id']; ?>" <?php echo $subject_filter == $subject['subject_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($subject['subject_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Filter
                </button>
                <a href="<?php echo APP_URL; ?>/admin/assessment-reports.php" class="btn btn-secondary">
                    <i class="fas fa-redo"></i> Reset
                </a>
            </div>
        </form>
    </div>
    
    <!-- Statistics Summary -->
    <div class="stats-summary">
        <div class="summary-card">
            <div class="summary-icon blue">
                <i class="fas fa-clipboard-list"></i>
            </div>
            <div class="summary-details">
                <h3><?php echo number_format($total_assessments); ?></h3>
                <p>Total Assessments</p>
            </div>
        </div>
        
        <div class="summary-card">
            <div class="summary-icon green">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="summary-details">
                <h3><?php echo number_format($average_score, 1); ?>%</h3>
                <p>Average Score</p>
            </div>
        </div>
        
        <div class="summary-card">
            <div class="summary-icon orange">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="summary-details">
                <h3><?php echo number_format($pass_rate, 1); ?>%</h3>
                <p>Pass Rate (≥50%)</p>
            </div>
        </div>
        
        <div class="summary-card">
            <div class="summary-icon <?php echo $fail_count > 0 ? 'red' : 'green'; ?>">
                <i class="fas fa-<?php echo $fail_count > 0 ? 'exclamation-triangle' : 'trophy'; ?>"></i>
            </div>
            <div class="summary-details">
                <h3><?php echo number_format($pass_count); ?> / <?php echo number_format($fail_count); ?></h3>
                <p>Passed / Failed</p>
            </div>
        </div>
    </div>
    
    <!-- Assessment Data Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-table"></i> Assessment Records</h3>
        </div>
        <div style="padding: 20px; overflow-x: auto;">
            <table class="data-table" id="assessmentTable">
                <thead>
                    <tr>
                        <th>Admission No.</th>
                        <th>Student Name</th>
                        <th>Class</th>
                        <th>Subject</th>
                        <th>Term</th>
                        <th>CA Score</th>
                        <th>Mid-Term</th>
                        <th>Exam</th>
                        <th>Total</th>
                        <th>Grade</th>
                        <th>Remark</th>
                        <th>Position</th>
                        <th>Teacher</th>
                        <th>Date Entered</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($assessments) > 0): ?>
                        <?php foreach ($assessments as $assessment): ?>
                            <?php
                            // Generate session year if not available
                            $session_year = isset($assessment['session_year']) && !empty($assessment['session_year'])
                                ? $assessment['session_year']
                                : 'N/A';
                            ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($assessment['admission_number']); ?></strong></td>
                                <td><?php echo htmlspecialchars($assessment['first_name'] . ' ' . $assessment['last_name']); ?></td>
                                <td><?php echo htmlspecialchars($assessment['class_name']); ?></td>
                                <td><?php echo htmlspecialchars($assessment['subject_name']); ?></td>
                                <td><?php echo htmlspecialchars($assessment['term_name'] . ' ' . $session_year); ?></td>
                                <td class="score-cell"><?php echo number_format($assessment['ca_score'], 1); ?></td>
                                <td class="score-cell"><?php echo number_format($assessment['midterm_score'], 1); ?></td>
                                <td class="score-cell"><?php echo number_format($assessment['exam_score'], 1); ?></td>
                                <td class="score-cell" style="font-size: 16px; color: var(--primary-color);">
                                    <?php echo number_format($assessment['total_score'], 1); ?>%
                                </td>
                                <td>
                                    <span class="grade-badge <?php echo strtolower($assessment['grade']); ?>">
                                        <?php echo htmlspecialchars($assessment['grade']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($assessment['remark']); ?></td>
                                <td style="text-align: center;">
                                    <?php echo $assessment['position'] ? '#' . $assessment['position'] : '-'; ?>
                                </td>
                                <td><?php echo htmlspecialchars($assessment['teacher_name'] ?? 'N/A'); ?></td>
                                <td><?php echo date('M j, Y', strtotime($assessment['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="14" style="text-align: center; padding: 40px;">
                                <i class="fas fa-clipboard-list" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 10px; display: block;"></i>
                                <h3>No Assessment Records Found</h3>
                                <p style="color: var(--text-secondary);">
                                    <?php if ($class_filter || $term_filter || $subject_filter): ?>
                                        Try adjusting your filters or check if assessments have been entered.
                                    <?php else: ?>
                                        No assessments have been entered yet. Teachers can enter marks in the Assessment Portal.
                                    <?php endif; ?>
                                </p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script>
    function exportToCSV() {
        const table = document.getElementById('assessmentTable');
        let csv = [];
        
        // Add title
        csv.push(['Assessment Reports']);
        csv.push(['Generated on: ' + new Date().toLocaleDateString()]);
        csv.push([]);
        
        // Add statistics
        csv.push(['Statistics Summary']);
        csv.push(['Total Assessments', <?php echo $total_assessments; ?>]);
        csv.push(['Average Score', '<?php echo number_format($average_score, 1); ?>%']);
        csv.push(['Pass Rate', '<?php echo number_format($pass_rate, 1); ?>%']);
        csv.push(['Passed', <?php echo $pass_count; ?>]);
        csv.push(['Failed', <?php echo $fail_count; ?>]);
        csv.push([]);
        
        // Add table headers
        const headers = [];
        table.querySelectorAll('thead th').forEach(th => {
            headers.push(th.textContent);
        });
        csv.push(headers);
        
        // Add table rows
        table.querySelectorAll('tbody tr').forEach(row => {
            const rowData = [];
            row.querySelectorAll('td').forEach(td => {
                rowData.push(td.textContent.trim());
            });
            if (rowData.length > 0 && !rowData[0].includes('No Assessment')) {
                csv.push(rowData);
            }
        });
        
        // Convert to CSV string
        const csvContent = csv.map(row => row.join(',')).join('\n');
        
        // Download
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'assessment-reports-' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
    }
    </script>
    
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
