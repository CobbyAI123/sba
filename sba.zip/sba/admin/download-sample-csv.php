<?php
// admin/download-sample-csv.php - Download Sample CSV Templates
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/csv-handler.php';

$current_user = check_permission(['admin']);

$type = $_GET['type'] ?? '';

switch ($type) {
    case 'students':
        $headers = [
            'first_name',
            'last_name',
            'email',
            'phone',
            'date_of_birth',
            'gender',
            'class_id',
            'guardian_name',
            'guardian_phone',
            'guardian_email',
            'address'
        ];
        
        $sample_data = [
            [
                'John',
                'Doe',
                'john.doe@example.com',
                '0241234567',
                '2010-05-15',
                'male',
                '1',
                'Jane Doe',
                '0241234568',
                'jane.doe@example.com',
                '123 Main Street, Accra'
            ],
            [
                'Mary',
                'Smith',
                'mary.smith@example.com',
                '0241234569',
                '2010-08-20',
                'female',
                '1',
                'Robert Smith',
                '0241234570',
                'robert.smith@example.com',
                '456 Oak Avenue, Kumasi'
            ]
        ];
        
        CSVHandler::generateCSV($sample_data, 'students_sample.csv', $headers);
        break;
        
    case 'teachers':
        $headers = [
            'first_name',
            'last_name',
            'email',
            'phone',
            'date_of_birth',
            'gender',
            'qualification',
            'subject_specialization',
            'address'
        ];
        
        $sample_data = [
            [
                'James',
                'Wilson',
                'james.wilson@example.com',
                '0241234571',
                '1985-03-10',
                'male',
                'B.Ed Mathematics',
                'Mathematics',
                '789 Pine Road, Accra'
            ],
            [
                'Sarah',
                'Johnson',
                'sarah.johnson@example.com',
                '0241234572',
                '1988-07-22',
                'female',
                'M.A English',
                'English Language',
                '321 Elm Street, Tema'
            ]
        ];
        
        CSVHandler::generateCSV($sample_data, 'teachers_sample.csv', $headers);
        break;
        
    case 'parents':
        $headers = [
            'first_name',
            'last_name',
            'email',
            'phone',
            'address',
            'student_admission_number'
        ];
        
        $sample_data = [
            [
                'Michael',
                'Brown',
                'michael.brown@example.com',
                '0241234573',
                '555 Cedar Lane, Accra',
                'SCH/2025/0001'
            ],
            [
                'Linda',
                'Davis',
                'linda.davis@example.com',
                '0241234574',
                '777 Birch Court, Kumasi',
                'SCH/2025/0002'
            ]
        ];
        
        CSVHandler::generateCSV($sample_data, 'parents_sample.csv', $headers);
        break;
        
    case 'accountants':
        $headers = [
            'first_name',
            'last_name',
            'email',
            'phone',
            'address'
        ];
        
        $sample_data = [
            [
                'David',
                'Miller',
                'david.miller@example.com',
                '0241234575',
                '888 Maple Drive, Accra'
            ]
        ];
        
        CSVHandler::generateCSV($sample_data, 'accountants_sample.csv', $headers);
        break;
        
    case 'librarians':
        $headers = [
            'first_name',
            'last_name',
            'email',
            'phone',
            'address'
        ];
        
        $sample_data = [
            [
                'Emily',
                'Taylor',
                'emily.taylor@example.com',
                '0241234576',
                '999 Willow Way, Tema'
            ]
        ];
        
        CSVHandler::generateCSV($sample_data, 'librarians_sample.csv', $headers);
        break;
        
    default:
        set_message('error', 'Invalid CSV type');
        redirect(APP_URL . '/admin/dashboard.php');
        break;
}
?>
