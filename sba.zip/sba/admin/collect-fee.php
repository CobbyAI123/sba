<?php
// admin/collect-fee.php - Collect Fee Payment
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Collect Payment';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$user_id = $current_user['user_id'];

// Handle payment collection
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('error', 'Invalid request');
        redirect(APP_URL . '/admin/collect-fee.php');
        exit;
    }
    
    if ($_POST['action'] == 'collect_payment') {
        $student_id = (int)$_POST['student_id'];
        $amount = (float)$_POST['amount'];
        $payment_method = sanitize_input($_POST['payment_method']);
        $payment_date = sanitize_input($_POST['payment_date']);
        $transaction_id = sanitize_input($_POST['transaction_id']);
        $remarks = sanitize_input($_POST['remarks']);
        
        try {
            // Generate receipt number
            $stmt = $db->prepare("SELECT generate_receipt_number(?) as receipt_number");
            $stmt->execute([$school_id]);
            $receipt = $stmt->fetch();
            $receipt_number = $receipt['receipt_number'];
            
            // Insert payment
            $stmt = $db->prepare("
                INSERT INTO fee_payments 
                (student_id, receipt_number, payment_date, amount, payment_method, transaction_id, remarks, collected_by, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'verified')
            ");
            $stmt->execute([$student_id, $receipt_number, $payment_date, $amount, $payment_method, $transaction_id, $remarks, $user_id]);
            
            log_activity($user_id, "Collected payment: $receipt_number - ₹$amount", 'fee_payments', $db->lastInsertId());
            set_message('success', "Payment collected successfully! Receipt: $receipt_number");
            redirect(APP_URL . '/admin/collect-fee.php?receipt=' . $receipt_number);
            
        } catch (PDOException $e) {
            set_message('error', 'Error collecting payment: ' . $e->getMessage());
        }
    }
}

// Search student
$student = null;
$student_fees = [];
if (isset($_GET['student_id'])) {
    $search_id = (int)$_GET['student_id'];
    
    $stmt = $db->prepare("
        SELECT s.*, c.class_name
        FROM students s
        INNER JOIN classes c ON s.class_id = c.class_id
        WHERE s.student_id = ? AND s.school_id = ?
    ");
    $stmt->execute([$search_id, $school_id]);
    $student = $stmt->fetch();
    
    if ($student) {
        // Get student's pending fees
        $stmt = $db->prepare("
            SELECT sf.*, fc.category_name
            FROM student_fees sf
            INNER JOIN fee_structure fs ON sf.structure_id = fs.structure_id
            INNER JOIN fee_categories fc ON fs.category_id = fc.category_id
            WHERE sf.student_id = ? AND sf.balance_amount > 0
            ORDER BY sf.due_date
        ");
        $stmt->execute([$search_id]);
        $student_fees = $stmt->fetchAll();
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .fee-item {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 10px;
    }
    
    .student-card {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        color: white;
        padding: 20px;
        border-radius: 12px;
        margin-bottom: 25px;
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-cash-register"></i> Collect Payment</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Collect fee payments from students
        </p>
    </div>
    
    <!-- Search Student -->
    <div style="background: var(--bg-card); padding: 20px; border-radius: 12px; margin-bottom: 25px;">
        <h3 style="margin: 0 0 15px 0;">Search Student</h3>
        <form method="GET" style="display: flex; gap: 10px;">
            <input type="number" name="student_id" placeholder="Enter Student ID" required 
                   style="flex: 1; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px;">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-search"></i> Search
            </button>
        </form>
    </div>
    
    <?php if ($student): ?>
        <!-- Student Info -->
        <div class="student-card">
            <h3 style="margin: 0 0 10px 0;">
                <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
            </h3>
            <p style="margin: 0; opacity: 0.9;">
                <strong>Student ID:</strong> <?php echo $student['student_id']; ?> | 
                <strong>Class:</strong> <?php echo htmlspecialchars($student['class_name']); ?>
            </p>
        </div>
        
        <?php if (count($student_fees) > 0): ?>
            <!-- Pending Fees -->
            <h3 style="margin: 0 0 15px 0;">Pending Fees</h3>
            
            <?php 
            $total_pending = array_sum(array_column($student_fees, 'balance_amount'));
            ?>
            
            <div style="background: rgba(255, 59, 48, 0.1); padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #FF3B30;">
                <strong>Total Pending:</strong> ₹<?php echo number_format($total_pending, 2); ?>
            </div>
            
            <?php foreach ($student_fees as $fee): ?>
                <div class="fee-item">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h4 style="margin: 0 0 5px 0;"><?php echo htmlspecialchars($fee['category_name']); ?></h4>
                            <p style="margin: 0; font-size: 13px; color: var(--text-secondary);">
                                Total: ₹<?php echo number_format($fee['total_amount'], 2); ?> | 
                                Paid: ₹<?php echo number_format($fee['paid_amount'], 2); ?> | 
                                Balance: ₹<?php echo number_format($fee['balance_amount'], 2); ?>
                            </p>
                        </div>
                        <div style="font-size: 20px; font-weight: 700; color: #FF3B30;">
                            ₹<?php echo number_format($fee['balance_amount'], 2); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            
            <!-- Payment Form -->
            <div style="background: var(--bg-card); padding: 25px; border-radius: 12px; margin-top: 25px;">
                <h3 style="margin: 0 0 20px 0;">Collect Payment</h3>
                
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="collect_payment">
                    <input type="hidden" name="student_id" value="<?php echo $student['student_id']; ?>">
                    
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label>Amount (₹) *</label>
                            <input type="number" name="amount" required min="0.01" step="0.01" 
                                   value="<?php echo $total_pending; ?>" placeholder="Enter amount">
                        </div>
                        
                        <div class="form-group">
                            <label>Payment Date *</label>
                            <input type="date" name="payment_date" required value="<?php echo date('Y-m-d'); ?>">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label>Payment Method *</label>
                            <select name="payment_method" required>
                                <option value="cash">Cash</option>
                                <option value="card">Card</option>
                                <option value="online">Online</option>
                                <option value="upi">UPI</option>
                                <option value="bank_transfer">Bank Transfer</option>
                                <option value="cheque">Cheque</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Transaction ID (Optional)</label>
                            <input type="text" name="transaction_id" placeholder="Enter transaction ID">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Remarks (Optional)</label>
                        <textarea name="remarks" rows="2" placeholder="Add any notes..."></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-success" style="width: 100%; font-size: 18px; padding: 15px;">
                        <i class="fas fa-check-circle"></i> Collect Payment
                    </button>
                </form>
            </div>
            
        <?php else: ?>
            <div style="text-align: center; padding: 40px; background: var(--bg-card); border-radius: 12px;">
                <i class="fas fa-check-circle" style="font-size: 48px; color: #34C759; margin-bottom: 15px;"></i>
                <h3 style="color: #34C759;">No Pending Fees</h3>
                <p style="color: var(--text-secondary);">This student has no pending fee payments</p>
            </div>
        <?php endif; ?>
        
    <?php elseif (isset($_GET['student_id'])): ?>
        <div style="text-align: center; padding: 40px; background: var(--bg-card); border-radius: 12px;">
            <i class="fas fa-user-times" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 15px;"></i>
            <h3 style="color: var(--text-secondary);">Student Not Found</h3>
            <p style="color: var(--text-secondary);">Please check the student ID and try again</p>
        </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
