<?php
// admin/settings.php - School Settings
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Settings';
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_profile'])) {
        $first_name = sanitize_input($_POST['first_name']);
        $last_name = sanitize_input($_POST['last_name']);
        $email = sanitize_input($_POST['email']);
        $phone = sanitize_input($_POST['phone']);
        
        try {
            $stmt = $db->prepare("
                UPDATE users 
                SET first_name = ?, last_name = ?, email = ?, phone = ?
                WHERE user_id = ?
            ");
            $stmt->execute([$first_name, $last_name, $email, $phone, $current_user['user_id']]);
            
            log_activity($current_user['user_id'], "Updated profile", 'users', $current_user['user_id']);
            
            set_message('success', 'Profile updated successfully!');
            redirect(APP_URL . '/admin/settings.php');
        } catch (PDOException $e) {
            set_message('error', 'Error updating profile: ' . $e->getMessage());
        }
    }
    
    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Verify current password
        $stmt = $db->prepare("SELECT password_hash FROM users WHERE user_id = ?");
        $stmt->execute([$current_user['user_id']]);
        $user = $stmt->fetch();
        
        if (!password_verify($current_password, $user['password_hash'])) {
            set_message('error', 'Current password is incorrect!');
        } elseif ($new_password !== $confirm_password) {
            set_message('error', 'New passwords do not match!');
        } elseif (strlen($new_password) < 6) {
            set_message('error', 'Password must be at least 6 characters!');
        } else {
            try {
                $new_hash = password_hash($new_password, PASSWORD_BCRYPT);
                $stmt = $db->prepare("UPDATE users SET password_hash = ? WHERE user_id = ?");
                $stmt->execute([$new_hash, $current_user['user_id']]);
                
                log_activity($current_user['user_id'], "Changed password", 'users', $current_user['user_id']);
                
                set_message('success', 'Password changed successfully!');
                redirect(APP_URL . '/admin/settings.php');
            } catch (PDOException $e) {
                set_message('error', 'Error changing password: ' . $e->getMessage());
            }
        }
    }
    
    if (isset($_POST['update_school'])) {
        $school_name = sanitize_input($_POST['school_name']);
        $address = sanitize_input($_POST['address']);
        $phone = sanitize_input($_POST['phone']);
        $email = sanitize_input($_POST['email']);
        $motto = sanitize_input($_POST['motto']);
        
        try {
            $stmt = $db->prepare("
                UPDATE schools 
                SET school_name = ?, address = ?, phone = ?, email = ?, motto = ?
                WHERE school_id = ?
            ");
            $stmt->execute([$school_name, $address, $phone, $email, $motto, $school_id]);
            
            log_activity($current_user['user_id'], "Updated school settings", 'schools', $school_id);
            
            set_message('success', 'School settings updated successfully!');
            redirect(APP_URL . '/admin/settings.php');
        } catch (PDOException $e) {
            set_message('error', 'Error updating school settings: ' . $e->getMessage());
        }
    }
}

// Get school info
$stmt = $db->prepare("SELECT * FROM schools WHERE school_id = ?");
$stmt->execute([$school_id]);
$school = $stmt->fetch();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div style="display: grid; grid-template-columns: 250px 1fr; gap: 20px;">
        <!-- Settings Menu -->
        <div class="card" style="height: fit-content;">
            <div style="padding: 20px;">
                <h3 style="margin-bottom: 20px; font-size: 16px;">Settings</h3>
                <div style="display: flex; flex-direction: column; gap: 5px;">
                    <a href="#profile" onclick="showTab('profile')" id="tab-profile" class="settings-tab active">
                        <i class="fas fa-user"></i> My Profile
                    </a>
                    <a href="#password" onclick="showTab('password')" id="tab-password" class="settings-tab">
                        <i class="fas fa-lock"></i> Change Password
                    </a>
                    <a href="#school" onclick="showTab('school')" id="tab-school" class="settings-tab">
                        <i class="fas fa-school"></i> School Info
                    </a>
                    <a href="#academic" onclick="showTab('academic')" id="tab-academic" class="settings-tab">
                        <i class="fas fa-calendar"></i> Academic Year
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Settings Content -->
        <div>
            <!-- Profile Settings -->
            <div id="content-profile" class="settings-content">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-user"></i> My Profile</h3>
                    </div>
                    <div style="padding: 30px;">
                        <form method="POST">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                                <div class="form-group">
                                    <label for="first_name">First Name *</label>
                                    <input type="text" name="first_name" id="first_name" value="<?php echo $current_user['first_name']; ?>" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="last_name">Last Name *</label>
                                    <input type="text" name="last_name" id="last_name" value="<?php echo $current_user['last_name']; ?>" required>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="email">Email *</label>
                                <input type="email" name="email" id="email" value="<?php echo $current_user['email']; ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="tel" name="phone" id="phone" value="<?php echo $current_user['phone']; ?>">
                            </div>
                            
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" value="<?php echo $current_user['username']; ?>" disabled style="background: var(--bg-secondary); cursor: not-allowed;">
                                <small style="color: var(--text-secondary); font-size: 12px;">Username cannot be changed</small>
                            </div>
                            
                            <div style="display: flex; justify-content: flex-end; margin-top: 20px;">
                                <button type="submit" name="update_profile" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Password Settings -->
            <div id="content-password" class="settings-content" style="display: none;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-lock"></i> Change Password</h3>
                    </div>
                    <div style="padding: 30px;">
                        <form method="POST" id="passwordForm">
                            <div class="form-group">
                                <label for="current_password">Current Password *</label>
                                <input type="password" name="current_password" id="current_password" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="new_password">New Password *</label>
                                <input type="password" name="new_password" id="new_password" minlength="6" required>
                                <small style="color: var(--text-secondary); font-size: 12px;">Minimum 6 characters</small>
                            </div>
                            
                            <div class="form-group">
                                <label for="confirm_password">Confirm New Password *</label>
                                <input type="password" name="confirm_password" id="confirm_password" minlength="6" required>
                            </div>
                            
                            <div style="display: flex; justify-content: flex-end; margin-top: 20px;">
                                <button type="submit" name="change_password" class="btn btn-primary">
                                    <i class="fas fa-key"></i> Change Password
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- School Settings -->
            <div id="content-school" class="settings-content" style="display: none;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-school"></i> School Information</h3>
                    </div>
                    <div style="padding: 30px;">
                        <form method="POST">
                            <div class="form-group">
                                <label for="school_name">School Name *</label>
                                <input type="text" name="school_name" id="school_name" value="<?php echo $school['school_name']; ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="address">Address</label>
                                <textarea name="address" id="address" rows="3"><?php echo $school['address']; ?></textarea>
                            </div>
                            
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                                <div class="form-group">
                                    <label for="phone">Phone</label>
                                    <input type="tel" name="phone" id="phone" value="<?php echo $school['phone']; ?>">
                                </div>
                                
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" name="email" id="email" value="<?php echo $school['email']; ?>">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="motto">School Motto</label>
                                <input type="text" name="motto" id="motto" value="<?php echo $school['motto']; ?>" placeholder="e.g., Knowledge is Power">
                            </div>
                            
                            <div class="form-group">
                                <label>School Code</label>
                                <input type="text" value="<?php echo $school['school_code']; ?>" disabled style="background: var(--bg-secondary); cursor: not-allowed;">
                                <small style="color: var(--text-secondary); font-size: 12px;">School code cannot be changed</small>
                            </div>
                            
                            <div style="display: flex; justify-content: flex-end; margin-top: 20px;">
                                <button type="submit" name="update_school" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Save Changes
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <!-- Academic Year Settings -->
            <div id="content-academic" class="settings-content" style="display: none;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-calendar"></i> Academic Year & Terms</h3>
                    </div>
                    <div style="padding: 30px;">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            Academic year and term management will be available in the next update.
                        </div>
                        
                        <p style="color: var(--text-secondary); margin-top: 20px;">
                            Current features:
                        </p>
                        <ul style="color: var(--text-secondary); margin-top: 10px;">
                            <li>View current academic year</li>
                            <li>View active terms</li>
                            <li>Set current term</li>
                            <li>Create new academic year</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <style>
    .settings-tab {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 15px;
        border-radius: 8px;
        color: var(--text-secondary);
        text-decoration: none;
        transition: all 0.3s ease;
        font-size: 14px;
    }
    
    .settings-tab:hover {
        background: var(--bg-secondary);
        color: var(--text-primary);
    }
    
    .settings-tab.active {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        color: white;
    }
    
    .settings-tab i {
        width: 20px;
    }
    </style>
    
    <script>
    function showTab(tabName) {
        // Hide all content
        document.querySelectorAll('.settings-content').forEach(content => {
            content.style.display = 'none';
        });
        
        // Remove active class from all tabs
        document.querySelectorAll('.settings-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        
        // Show selected content
        document.getElementById('content-' + tabName).style.display = 'block';
        
        // Add active class to selected tab
        document.getElementById('tab-' + tabName).classList.add('active');
        
        // Prevent default anchor behavior
        event.preventDefault();
    }
    
    // Password confirmation validation
    document.getElementById('passwordForm').addEventListener('submit', function(e) {
        const newPassword = document.getElementById('new_password').value;
        const confirmPassword = document.getElementById('confirm_password').value;
        
        if (newPassword !== confirmPassword) {
            e.preventDefault();
            alert('New passwords do not match!');
        }
    });
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
