<?php
// admin/marks.php - Manage Marks
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Manage Marks';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get filter parameters
$class_filter = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$exam_filter = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;
$subject_filter = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;
$term_filter = isset($_GET['term_id']) ? (int)$_GET['term_id'] : 0;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action']) && $_POST['action'] == 'save_marks') {
        $exam_id = (int)$_POST['exam_id'];
        $subject_id = (int)$_POST['subject_id'];
        $marks = $_POST['marks'];
        
        try {
            $db->beginTransaction();
            
            foreach ($marks as $student_id => $mark_data) {
                $ca_score = (float)($mark_data['ca_score'] ?? 0);
                $exam_score = (float)($mark_data['exam_score'] ?? 0);
                $remarks = sanitize_input($mark_data['remarks'] ?? '');
                
                // Check if mark exists
                $stmt = $db->prepare("
                    SELECT mark_id FROM marks 
                    WHERE exam_id = ? AND student_id = ? AND subject_id = ?
                ");
                $stmt->execute([$exam_id, $student_id, $subject_id]);
                $existing = $stmt->fetch();
                
                if ($existing) {
                    // Update
                    $stmt = $db->prepare("
                        UPDATE marks 
                        SET ca_score = ?, exam_score = ?, remarks = ?
                        WHERE mark_id = ?
                    ");
                    $stmt->execute([$ca_score, $exam_score, $remarks, $existing['mark_id']]);
                } else {
                    // Insert
                    $stmt = $db->prepare("
                        INSERT INTO marks (exam_id, student_id, subject_id, ca_score, exam_score, remarks)
                        VALUES (?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$exam_id, $student_id, $subject_id, $ca_score, $exam_score, $remarks]);
                }
            }
            
            $db->commit();
            
            log_activity($current_user['user_id'], "Saved marks for exam ID: $exam_id", 'marks', $exam_id);
            
            set_message('success', 'Marks saved successfully!');
            redirect(APP_URL . '/admin/marks.php?class_id=' . $class_filter . '&exam_id=' . $exam_id . '&subject_id=' . $subject_id);
        } catch (PDOException $e) {
            $db->rollBack();
            set_message('error', 'Error saving marks: ' . $e->getMessage());
        }
    }
}

// Get classes
$stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get exams
$stmt = $db->prepare("  
    SELECT e.*, t.term_name
    FROM exams e
    INNER JOIN terms t ON e.term_id = t.term_id
    WHERE e.school_id = ?
    " . ($term_filter > 0 ? "AND e.term_id = ?" : "") . "
    ORDER BY e.start_date DESC
");
if ($term_filter > 0) {
    $stmt->execute([$school_id, $term_filter]);
} else {
    $stmt->execute([$school_id]);
}
$exams = $stmt->fetchAll();

// Get subjects
$stmt = $db->prepare("SELECT * FROM subjects WHERE school_id = ? ORDER BY subject_name");
$stmt->execute([$school_id]);
$subjects = $stmt->fetchAll();

// Get students and marks if filters are set
$students_with_marks = [];
$exam_details = null;
$total_marks = 0;

if ($class_filter > 0 && $exam_filter > 0 && $subject_filter > 0) {
    // Get exam details
    $stmt = $db->prepare("
        SELECT e.*, t.term_name
        FROM exams e
        INNER JOIN terms t ON e.term_id = t.term_id
        WHERE e.exam_id = ?
    ");
    $stmt->execute([$exam_filter]);
    $exam_details = $stmt->fetch();
    $total_marks = 100;
    
    // Get students with their marks
    $stmt = $db->prepare("
        SELECT 
            s.student_id,
            u.first_name,
            u.last_name,
            s.admission_number,
            m.ca_score,
            m.exam_score,
            m.total_score,
            m.remarks
        FROM students s
        INNER JOIN users u ON s.user_id = u.user_id
        LEFT JOIN marks m ON s.student_id = m.student_id 
            AND m.exam_id = ? 
            AND m.subject_id = ?
        WHERE s.class_id = ? AND s.school_id = ?
        ORDER BY u.first_name, u.last_name
    ");
    $stmt->execute([$exam_filter, $subject_filter, $class_filter, $school_id]);
    $students_with_marks = $stmt->fetchAll();
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .filter-section {
        background: var(--card-bg);
        padding: 25px;
        border-radius: 15px;
        margin-bottom: 30px;
    }
    
    .filter-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }
    
    .marks-table {
        width: 100%;
        background: var(--card-bg);
        border-radius: 15px;
        overflow: hidden;
    }
    
    .marks-table table {
        width: 100%;
    }
    
    .marks-table th {
        background: linear-gradient(135deg, #2196F3, #1976D2);
        color: white;
        padding: 15px;
        text-align: left;
    }
    
    .marks-table td {
        padding: 15px;
        border-bottom: 1px solid var(--border-color);
    }
    
    .marks-input {
        width: 100px;
        padding: 8px;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        background: var(--bg-primary);
        color: var(--text-primary);
    }
    
    .remarks-input {
        width: 100%;
        padding: 8px;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        background: var(--bg-primary);
        color: var(--text-primary);
    }
    
    .grade-badge {
        padding: 4px 12px;
        border-radius: 12px;
        font-weight: 600;
        font-size: 12px;
    }
    
    .grade-a { background: rgba(76, 175, 80, 0.1); color: #4CAF50; }
    .grade-b { background: rgba(33, 150, 243, 0.1); color: #2196F3; }
    .grade-c { background: rgba(255, 152, 0, 0.1); color: #FF9800; }
    .grade-d { background: rgba(255, 87, 34, 0.1); color: #FF5722; }
    .grade-f { background: rgba(244, 67, 54, 0.1); color: #F44336; }
    </style>
    
    <!-- Page Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-chart-line"></i> Manage Marks
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Enter and manage student exam marks
            </p>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="filter-section">
        <h3 style="margin-bottom: 20px;"><i class="fas fa-filter"></i> Select Exam</h3>
        <form method="GET" class="filter-grid">
            <div class="form-group">
                <label>Class *</label>
                <select name="class_id" required onchange="this.form.submit()">
                    <option value="">-- Select Class --</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['class_id']; ?>" <?php echo $class_filter == $class['class_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($class['class_name']); ?>
                            <?php echo !empty($class['section']) ? ' - ' . htmlspecialchars($class['section']) : ''; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Exam *</label>
                <select name="exam_id" required onchange="this.form.submit()">
                    <option value="">-- Select Exam --</option>
                    <?php foreach ($exams as $exam): ?>
                        <?php if ($exam['class_id'] == $class_filter || $class_filter == 0): ?>
                            <option value="<?php echo $exam['exam_id']; ?>" <?php echo $exam_filter == $exam['exam_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($exam['exam_name'] . ' - ' . $exam['subject_name']); ?>
                            </option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Subject *</label>
                <select name="subject_id" required onchange="this.form.submit()">
                    <option value="">-- Select Subject --</option>
                    <?php foreach ($subjects as $subject): ?>
                        <option value="<?php echo $subject['subject_id']; ?>" <?php echo $subject_filter == $subject['subject_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($subject['subject_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>
    
    <?php if ($exam_details && count($students_with_marks) > 0): ?>
        <!-- Exam Info -->
        <div class="card" style="margin-bottom: 20px; background: linear-gradient(135deg, #4CAF50, #388E3C); color: white;">
            <div style="padding: 20px; display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h3 style="margin: 0 0 5px 0; color: white;"><?php echo htmlspecialchars($exam_details['exam_name']); ?></h3>
                    <p style="margin: 0; opacity: 0.9;">
                        <?php echo htmlspecialchars($exam_details['subject_name']); ?> | 
                        Total Marks: <?php echo $total_marks; ?> | 
                        Date: <?php echo date('M j, Y', strtotime($exam_details['exam_date'])); ?>
                    </p>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 14px; opacity: 0.9;">Students</div>
                    <div style="font-size: 32px; font-weight: 700;"><?php echo count($students_with_marks); ?></div>
                </div>
            </div>
        </div>
        
        <!-- Marks Entry Form -->
        <form method="POST">
            <input type="hidden" name="action" value="save_marks">
            <input type="hidden" name="exam_id" value="<?php echo $exam_filter; ?>">
            <input type="hidden" name="subject_id" value="<?php echo $subject_filter; ?>">
            
            <div class="marks-table">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th>Admission No.</th>
                            <th>Student Name</th>
                            <th style="width: 120px;">CA Score</th>
                            <th style="width: 120px;">Exam Score</th>
                            <th style="width: 100px;">Total</th>
                            <th style="width: 100px;">Grade</th>
                            <th style="width: 200px;">Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $count = 1;
                        foreach ($students_with_marks as $student): 
                            $ca_score = $student['ca_score'] ?? '';
                            $exam_score = $student['exam_score'] ?? '';
                            $total_score = ($ca_score !== '' && $exam_score !== '') ? ($ca_score + $exam_score) : '';
                            $percentage = $total_score !== '' ? ($total_score / 200) * 100 : 0;
                            
                            // Calculate grade
                            $grade = '';
                            $grade_class = '';
                            if ($percentage >= 80) { $grade = 'A'; $grade_class = 'grade-a'; }
                            elseif ($percentage >= 70) { $grade = 'B'; $grade_class = 'grade-b'; }
                            elseif ($percentage >= 60) { $grade = 'C'; $grade_class = 'grade-c'; }
                            elseif ($percentage >= 50) { $grade = 'D'; $grade_class = 'grade-d'; }
                            elseif ($total_score !== '') { $grade = 'F'; $grade_class = 'grade-f'; }
                        ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><?php echo htmlspecialchars($student['admission_number']); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></strong>
                                </td>
                                <td>
                                    <input type="number" 
                                           name="marks[<?php echo $student['student_id']; ?>][ca_score]" 
                                           class="marks-input"
                                           value="<?php echo $ca_score; ?>"
                                           min="0" 
                                           max="100" 
                                           step="0.5"
                                           placeholder="0">
                                </td>
                                <td>
                                    <input type="number" 
                                           name="marks[<?php echo $student['student_id']; ?>][exam_score]" 
                                           class="marks-input"
                                           value="<?php echo $exam_score; ?>"
                                           min="0" 
                                           max="100" 
                                           step="0.5"
                                           placeholder="0">
                                </td>
                                <td style="text-align: center; font-weight: 600;">
                                    <?php echo $total_score !== '' ? number_format($total_score, 2) : '-'; ?>
                                </td>
                                <td>
                                    <?php if ($grade): ?>
                                        <span class="grade-badge <?php echo $grade_class; ?>"><?php echo $grade; ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <input type="text" 
                                           name="marks[<?php echo $student['student_id']; ?>][remarks]" 
                                           class="remarks-input"
                                           value="<?php echo htmlspecialchars($student['remarks'] ?? ''); ?>"
                                           placeholder="Optional remarks">
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div style="margin-top: 20px; text-align: right;">
                <button type="submit" class="btn btn-primary" style="padding: 12px 30px;">
                    <i class="fas fa-save"></i> Save All Marks
                </button>
            </div>
        </form>
    <?php elseif ($class_filter > 0 && $exam_filter > 0 && $subject_filter > 0): ?>
        <div class="card">
            <div style="padding: 60px; text-align: center;">
                <i class="fas fa-users" style="font-size: 64px; color: var(--text-secondary); opacity: 0.3; margin-bottom: 20px;"></i>
                <h3 style="color: var(--text-secondary); margin-bottom: 10px;">No Students Found</h3>
                <p style="color: var(--text-secondary);">No students found in the selected class.</p>
            </div>
        </div>
    <?php else: ?>
        <div class="card">
            <div style="padding: 60px; text-align: center;">
                <i class="fas fa-filter" style="font-size: 64px; color: var(--text-secondary); opacity: 0.3; margin-bottom: 20px;"></i>
                <h3 style="color: var(--text-secondary); margin-bottom: 10px;">Select Filters</h3>
                <p style="color: var(--text-secondary);">Please select class, exam, and subject to enter marks.</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
