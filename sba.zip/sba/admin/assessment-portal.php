<?php
// admin/assessment-portal.php - Control Assessment Portal Access
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Assessment Portal Control';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Auto-create assessment_portal table if it doesn't exist
try {
    $db->query("SELECT 1 FROM assessment_portal LIMIT 1");
} catch (PDOException $e) {
    try {
        $sql = "CREATE TABLE IF NOT EXISTS `assessment_portal` (
          `portal_id` int(11) NOT NULL AUTO_INCREMENT,
          `school_id` int(11) NOT NULL,
          `term_id` int(11) NOT NULL,
          `portal_type` varchar(50) NOT NULL,
          `is_open` tinyint(1) DEFAULT 0,
          `opened_by` int(11),
          `opened_at` timestamp NULL,
          `closed_by` int(11),
          `closed_at` timestamp NULL,
          `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (`portal_id`),
          KEY `school_id` (`school_id`),
          KEY `term_id` (`term_id`),
          KEY `portal_type` (`portal_type`),
          KEY `is_open` (`is_open`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        $db->exec($sql);
    } catch (PDOException $e) {
        // Table creation failed, will handle error later
    }
}

// Auto-create assessment_submissions table if it doesn't exist
try {
    $db->query("SELECT 1 FROM assessment_submissions LIMIT 1");
} catch (PDOException $e) {
    try {
        $sql = "CREATE TABLE IF NOT EXISTS `assessment_submissions` (
          `submission_id` int(11) NOT NULL AUTO_INCREMENT,
          `school_id` int(11) NOT NULL,
          `term_id` int(11) NOT NULL,
          `teacher_id` int(11) NOT NULL,
          `assessment_type` varchar(50) NOT NULL,
          `students_count` int(11) DEFAULT 0,
          `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (`submission_id`),
          KEY `school_id` (`school_id`),
          KEY `term_id` (`term_id`),
          KEY `teacher_id` (`teacher_id`),
          KEY `assessment_type` (`assessment_type`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        $db->exec($sql);
    } catch (PDOException $e) {
        // Table creation failed, will handle error later
    }
}

// Auto-create notifications table if it doesn't exist
try {
    $db->query("SELECT 1 FROM notifications LIMIT 1");
} catch (PDOException $e) {
    try {
        $sql = "CREATE TABLE IF NOT EXISTS `notifications` (
          `notification_id` int(11) NOT NULL AUTO_INCREMENT,
          `user_id` int(11) NOT NULL,
          `title` varchar(255) NOT NULL,
          `message` text,
          `type` varchar(50) DEFAULT 'info',
          `link` varchar(255),
          `is_read` tinyint(1) DEFAULT 0,
          `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
          `read_at` timestamp NULL,
          PRIMARY KEY (`notification_id`),
          KEY `user_id` (`user_id`),
          KEY `is_read` (`is_read`),
          KEY `created_at` (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        $db->exec($sql);
    } catch (PDOException $e) {
        // Table creation failed, will handle error later
    }
}

// Handle portal control actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        // Ensure tables exist before processing
        try {
            $db->query("SELECT 1 FROM assessment_portal LIMIT 1");
        } catch (PDOException $e) {
            try {
                $sql = "CREATE TABLE IF NOT EXISTS `assessment_portal` (
                  `portal_id` int(11) NOT NULL AUTO_INCREMENT,
                  `school_id` int(11) NOT NULL,
                  `term_id` int(11) NOT NULL,
                  `portal_type` varchar(50) NOT NULL,
                  `is_open` tinyint(1) DEFAULT 0,
                  `opened_by` int(11),
                  `opened_at` timestamp NULL,
                  `closed_by` int(11),
                  `closed_at` timestamp NULL,
                  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                  PRIMARY KEY (`portal_id`),
                  KEY `school_id` (`school_id`),
                  KEY `term_id` (`term_id`),
                  KEY `portal_type` (`portal_type`),
                  KEY `is_open` (`is_open`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
                $db->exec($sql);
            } catch (PDOException $e) {
                set_message('error', 'Error creating assessment_portal table: ' . $e->getMessage());
                redirect(APP_URL . '/admin/assessment-portal.php');
            }
        }
        
        // Ensure notifications table exists
        try {
            $db->query("SELECT 1 FROM notifications LIMIT 1");
        } catch (PDOException $e) {
            try {
                $sql = "CREATE TABLE IF NOT EXISTS `notifications` (
                  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
                  `user_id` int(11) NOT NULL,
                  `title` varchar(255) NOT NULL,
                  `message` text,
                  `type` varchar(50) DEFAULT 'info',
                  `link` varchar(255),
                  `is_read` tinyint(1) DEFAULT 0,
                  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  `read_at` timestamp NULL,
                  PRIMARY KEY (`notification_id`),
                  KEY `user_id` (`user_id`),
                  KEY `is_read` (`is_read`),
                  KEY `created_at` (`created_at`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
                $db->exec($sql);
            } catch (PDOException $e) {
                // Notifications table creation failed, but continue - notifications are optional
            }
        }
        
        $term_id = (int)$_POST['term_id'];
        $portal_type = sanitize_input($_POST['portal_type']);
        
        if ($_POST['action'] == 'open_portal') {
            try {
                // Get active term details
                $term_stmt = $db->prepare("SELECT term_id, term_name FROM terms WHERE term_id = ?");
                $term_stmt->execute([$term_id]);
                $active_term = $term_stmt->fetch();
                
                // Check if portal exists
                $stmt = $db->prepare("
                    SELECT portal_id, is_open FROM assessment_portal 
                    WHERE school_id = ? AND term_id = ? AND portal_type = ?
                ");
                $stmt->execute([$school_id, $term_id, $portal_type]);
                $portal = $stmt->fetch();
                
                if ($portal) {
                    // Update existing portal
                    $stmt = $db->prepare("
                        UPDATE assessment_portal 
                        SET is_open = 1, opened_by = ?, opened_at = NOW()
                        WHERE portal_id = ?
                    ");
                    $stmt->execute([$current_user['user_id'], $portal['portal_id']]);
                } else {
                    // Create new portal
                    $stmt = $db->prepare("
                        INSERT INTO assessment_portal (school_id, term_id, portal_type, is_open, opened_by, opened_at)
                        VALUES (?, ?, ?, 1, ?, NOW())
                    ");
                    $stmt->execute([$school_id, $term_id, $portal_type, $current_user['user_id']]);
                }
                
                log_activity($current_user['user_id'], "Opened $portal_type portal for term $term_id", 'assessment_portal', $term_id);
                
                // Send notifications to teachers and proprietors
                $portal_name = ucfirst($portal_type);
                $notification_title = "$portal_name Portal Opened";
                $notification_message = "The $portal_name assessment portal has been opened. You can now enter scores for students.";
                
                // Get all teachers and proprietors for this school
                $stmt = $db->prepare("SELECT user_id, email, first_name FROM users WHERE school_id = ? AND role IN ('teacher', 'proprietor') AND status = 'active'");
                $stmt->execute([$school_id]);
                $recipients = $stmt->fetchAll();
                
                foreach ($recipients as $recipient) {
                    // Create in-app notification
                    create_notification(
                        $recipient['user_id'],
                        $notification_title,
                        $notification_message,
                        'info',
                        APP_URL . '/teacher/enter-scores.php'
                    );
                    
                    // Send email notification immediately (suppress errors)
                    try {
                        $email_message = "
                            <h2>$notification_title</h2>
                            <p>Dear {$recipient['first_name']},</p>
                            <p>$notification_message</p>
                            <p><strong>Portal Type:</strong> $portal_name</p>
                            <p><strong>Term:</strong> {$active_term['term_name']}</p>
                            <p>Please log in to the system to enter assessment scores.</p>
                            <p><a href='" . APP_URL . "' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 10px;'>Login to System</a></p>
                        ";
                        @send_email($recipient['email'], $notification_title, $email_message);
                    } catch (Exception $e) {
                        // Log error but don't stop execution
                        error_log("Email notification failed for {$recipient['email']}: " . $e->getMessage());
                    }
                }
                
                set_message('success', ucfirst($portal_type) . ' portal opened successfully! Notifications sent to ' . count($recipients) . ' teachers and proprietors.');
                redirect(APP_URL . '/admin/assessment-portal.php');
            } catch (PDOException $e) {
                set_message('error', 'Error opening portal: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'close_portal') {
            try {
                $stmt = $db->prepare("
                    UPDATE assessment_portal 
                    SET is_open = 0, closed_by = ?, closed_at = NOW()
                    WHERE school_id = ? AND term_id = ? AND portal_type = ?
                ");
                $stmt->execute([$current_user['user_id'], $school_id, $term_id, $portal_type]);
                
                log_activity($current_user['user_id'], "Closed $portal_type portal for term $term_id", 'assessment_portal', $term_id);
                
                set_message('success', ucfirst($portal_type) . ' portal closed successfully!');
                redirect(APP_URL . '/admin/assessment-portal.php');
            } catch (PDOException $e) {
                set_message('error', 'Error closing portal: ' . $e->getMessage());
            }
        }
    }
}

// Get active term (handle both is_active and is_current columns, and school_id existence)
$active_term = null;
try {
    // Check if school_id column exists in terms table
    $has_school_id = count($db->query("SHOW COLUMNS FROM terms LIKE 'school_id'")->fetchAll()) > 0;
    
    // Try is_active column first
    try {
        if ($has_school_id) {
            $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_active = 1");
            $stmt->execute([$school_id]);
        } else {
            $stmt = $db->prepare("SELECT * FROM terms WHERE is_active = 1 LIMIT 1");
            $stmt->execute();
        }
        $active_term = $stmt->fetch();
    } catch (PDOException $e) {
        // Try is_current column if is_active doesn't exist
        try {
            if ($has_school_id) {
                $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_current = 1");
                $stmt->execute([$school_id]);
            } else {
                $stmt = $db->prepare("SELECT * FROM terms WHERE is_current = 1 LIMIT 1");
                $stmt->execute();
            }
            $active_term = $stmt->fetch();
        } catch (PDOException $e2) {
            // Get the most recent term as fallback
            try {
                if ($has_school_id) {
                    $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY start_date DESC LIMIT 1");
                    $stmt->execute([$school_id]);
                } else {
                    $stmt = $db->prepare("SELECT * FROM terms ORDER BY start_date DESC LIMIT 1");
                    $stmt->execute();
                }
                $active_term = $stmt->fetch();
            } catch (PDOException $e3) {
                // terms table doesn't exist
                $active_term = null;
            }
        }
    }
} catch (PDOException $e) {
    $active_term = null;
}

// Get all terms
$terms = [];
try {
    // Check if school_id column exists (reuse from above if possible)
    if (!isset($has_school_id)) {
        $has_school_id = count($db->query("SHOW COLUMNS FROM terms LIKE 'school_id'")->fetchAll()) > 0;
    }
    
    if ($has_school_id) {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY start_date DESC");
        $stmt->execute([$school_id]);
    } else {
        $stmt = $db->prepare("SELECT * FROM terms ORDER BY start_date DESC");
        $stmt->execute();
    }
    $terms = $stmt->fetchAll();
} catch (PDOException $e) {
    $terms = [];
}

// Get portal status for active term
$portal_status = [];
if ($active_term) {
    try {
        $stmt = $db->prepare("
            SELECT portal_type, is_open, opened_at, closed_at,
                   u1.first_name as opened_by_name, u2.first_name as closed_by_name
            FROM assessment_portal ap
            LEFT JOIN users u1 ON ap.opened_by = u1.user_id
            LEFT JOIN users u2 ON ap.closed_by = u2.user_id
            WHERE ap.school_id = ? AND ap.term_id = ?
        ");
        $stmt->execute([$school_id, $active_term['term_id']]);
        while ($row = $stmt->fetch()) {
            $portal_status[$row['portal_type']] = $row;
        }
    } catch (PDOException $e) {
        // assessment_portal table may not exist
        $portal_status = [];
    }
}

// Get submission statistics
$submission_stats = [];
if ($active_term) {
    try {
        $stmt = $db->prepare("
            SELECT 
                assessment_type,
                COUNT(DISTINCT teacher_id) as teachers_submitted,
                COUNT(*) as total_submissions,
                SUM(students_count) as total_students
            FROM assessment_submissions
            WHERE school_id = ? AND term_id = ?
            GROUP BY assessment_type
        ");
        $stmt->execute([$school_id, $active_term['term_id']]);
        while ($row = $stmt->fetch()) {
            $submission_stats[$row['assessment_type']] = $row;
        }
    } catch (PDOException $e) {
        // assessment_submissions table may not exist
        $submission_stats = [];
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .portal-card {
        background: var(--card-bg);
        border-radius: 15px;
        padding: 30px;
        box-shadow: var(--shadow);
        border-left: 5px solid;
        transition: all 0.3s ease;
    }
    
    .portal-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }
    
    .portal-card.open {
        border-left-color: #4CAF50;
        background: linear-gradient(135deg, rgba(76, 175, 80, 0.05), transparent);
    }
    
    .portal-card.closed {
        border-left-color: #F44336;
        background: linear-gradient(135deg, rgba(244, 67, 54, 0.05), transparent);
    }
    
    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 16px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 14px;
    }
    
    .status-badge.open {
        background: #4CAF50;
        color: white;
    }
    
    .status-badge.closed {
        background: #F44336;
        color: white;
    }
    </style>
    
    <!-- Active Term Banner -->
    <?php if ($active_term): ?>
        <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white;">
            <div style="padding: 20px;">
                <h3 style="margin: 0 0 10px 0; color: white;">
                    <i class="fas fa-calendar-check"></i> Current Academic Term
                </h3>
                <h2 style="margin: 0; color: white;"><?php echo $active_term['term_name']; ?></h2>
                <p style="margin: 5px 0 0 0; opacity: 0.9;">
                    <?php echo isset($active_term['session_year']) ? $active_term['session_year'] : ''; ?>
                </p>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning" style="margin-bottom: 30px;">
            <i class="fas fa-exclamation-triangle"></i>
            <strong>No Active Term!</strong> Please set an active term before managing assessment portals.
        </div>
    <?php endif; ?>
    
    <!-- Portal Control Cards -->
    <?php if ($active_term): ?>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 25px; margin-bottom: 30px;">
            
            <!-- CA Portal -->
            <?php 
            $ca_portal = $portal_status['ca'] ?? null;
            $ca_open = $ca_portal && $ca_portal['is_open'];
            $ca_stats = $submission_stats['ca'] ?? null;
            ?>
            <div class="portal-card <?php echo $ca_open ? 'open' : 'closed'; ?>">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 20px;">
                    <div>
                        <h3 style="margin: 0 0 5px 0;">
                            <i class="fas fa-clipboard-check"></i> Continuous Assessment (CA)
                        </h3>
                        <span class="status-badge <?php echo $ca_open ? 'open' : 'closed'; ?>">
                            <i class="fas fa-<?php echo $ca_open ? 'lock-open' : 'lock'; ?>"></i>
                            <?php echo $ca_open ? 'OPEN' : 'CLOSED'; ?>
                        </span>
                    </div>
                </div>
                
                <?php if ($ca_portal): ?>
                    <div style="font-size: 13px; color: var(--text-secondary); margin-bottom: 15px;">
                        <?php if ($ca_open): ?>
                            <p><i class="fas fa-user"></i> Opened by: <?php echo $ca_portal['opened_by_name']; ?></p>
                            <p><i class="fas fa-clock"></i> <?php echo date('M d, Y h:i A', strtotime($ca_portal['opened_at'])); ?></p>
                        <?php else: ?>
                            <p><i class="fas fa-user"></i> Closed by: <?php echo $ca_portal['closed_by_name']; ?></p>
                            <p><i class="fas fa-clock"></i> <?php echo date('M d, Y h:i A', strtotime($ca_portal['closed_at'])); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($ca_stats): ?>
                    <div style="background: rgba(0,0,0,0.05); padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                        <p style="margin: 0 0 5px 0;"><strong>Submissions:</strong> <?php echo $ca_stats['total_submissions']; ?></p>
                        <p style="margin: 0 0 5px 0;"><strong>Teachers:</strong> <?php echo $ca_stats['teachers_submitted']; ?></p>
                        <p style="margin: 0;"><strong>Students:</strong> <?php echo $ca_stats['total_students']; ?></p>
                    </div>
                <?php endif; ?>
                
                <form method="POST" style="margin: 0;">
                    <input type="hidden" name="term_id" value="<?php echo $active_term['term_id']; ?>">
                    <input type="hidden" name="portal_type" value="ca">
                    <?php if ($ca_open): ?>
                        <button type="submit" name="action" value="close_portal" class="btn btn-danger" style="width: 100%;"
                                onclick="return confirm('Close CA portal? Teachers will no longer be able to enter CA scores.')">
                            <i class="fas fa-lock"></i> Close CA Portal
                        </button>
                    <?php else: ?>
                        <button type="submit" name="action" value="open_portal" class="btn btn-success" style="width: 100%;">
                            <i class="fas fa-lock-open"></i> Open CA Portal
                        </button>
                    <?php endif; ?>
                </form>
            </div>
            
            <!-- Midterm Portal -->
            <?php 
            $midterm_portal = $portal_status['midterm'] ?? null;
            $midterm_open = $midterm_portal && $midterm_portal['is_open'];
            $midterm_stats = $submission_stats['midterm'] ?? null;
            ?>
            <div class="portal-card <?php echo $midterm_open ? 'open' : 'closed'; ?>">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 20px;">
                    <div>
                        <h3 style="margin: 0 0 5px 0;">
                            <i class="fas fa-file-alt"></i> Midterm Examination
                        </h3>
                        <span class="status-badge <?php echo $midterm_open ? 'open' : 'closed'; ?>">
                            <i class="fas fa-<?php echo $midterm_open ? 'lock-open' : 'lock'; ?>"></i>
                            <?php echo $midterm_open ? 'OPEN' : 'CLOSED'; ?>
                        </span>
                    </div>
                </div>
                
                <?php if ($midterm_portal): ?>
                    <div style="font-size: 13px; color: var(--text-secondary); margin-bottom: 15px;">
                        <?php if ($midterm_open): ?>
                            <p><i class="fas fa-user"></i> Opened by: <?php echo $midterm_portal['opened_by_name']; ?></p>
                            <p><i class="fas fa-clock"></i> <?php echo date('M d, Y h:i A', strtotime($midterm_portal['opened_at'])); ?></p>
                        <?php else: ?>
                            <p><i class="fas fa-user"></i> Closed by: <?php echo $midterm_portal['closed_by_name']; ?></p>
                            <p><i class="fas fa-clock"></i> <?php echo date('M d, Y h:i A', strtotime($midterm_portal['closed_at'])); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($midterm_stats): ?>
                    <div style="background: rgba(0,0,0,0.05); padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                        <p style="margin: 0 0 5px 0;"><strong>Submissions:</strong> <?php echo $midterm_stats['total_submissions']; ?></p>
                        <p style="margin: 0 0 5px 0;"><strong>Teachers:</strong> <?php echo $midterm_stats['teachers_submitted']; ?></p>
                        <p style="margin: 0;"><strong>Students:</strong> <?php echo $midterm_stats['total_students']; ?></p>
                    </div>
                <?php endif; ?>
                
                <form method="POST" style="margin: 0;">
                    <input type="hidden" name="term_id" value="<?php echo $active_term['term_id']; ?>">
                    <input type="hidden" name="portal_type" value="midterm">
                    <?php if ($midterm_open): ?>
                        <button type="submit" name="action" value="close_portal" class="btn btn-danger" style="width: 100%;"
                                onclick="return confirm('Close Midterm portal? Teachers will no longer be able to enter midterm scores.')">
                            <i class="fas fa-lock"></i> Close Midterm Portal
                        </button>
                    <?php else: ?>
                        <button type="submit" name="action" value="open_portal" class="btn btn-success" style="width: 100%;">
                            <i class="fas fa-lock-open"></i> Open Midterm Portal
                        </button>
                    <?php endif; ?>
                </form>
            </div>
            
            <!-- Exam Portal -->
            <?php 
            $exam_portal = $portal_status['exam'] ?? null;
            $exam_open = $exam_portal && $exam_portal['is_open'];
            $exam_stats = $submission_stats['exam'] ?? null;
            ?>
            <div class="portal-card <?php echo $exam_open ? 'open' : 'closed'; ?>">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 20px;">
                    <div>
                        <h3 style="margin: 0 0 5px 0;">
                            <i class="fas fa-graduation-cap"></i> Final Examination
                        </h3>
                        <span class="status-badge <?php echo $exam_open ? 'open' : 'closed'; ?>">
                            <i class="fas fa-<?php echo $exam_open ? 'lock-open' : 'lock'; ?>"></i>
                            <?php echo $exam_open ? 'OPEN' : 'CLOSED'; ?>
                        </span>
                    </div>
                </div>
                
                <?php if ($exam_portal): ?>
                    <div style="font-size: 13px; color: var(--text-secondary); margin-bottom: 15px;">
                        <?php if ($exam_open): ?>
                            <p><i class="fas fa-user"></i> Opened by: <?php echo $exam_portal['opened_by_name']; ?></p>
                            <p><i class="fas fa-clock"></i> <?php echo date('M d, Y h:i A', strtotime($exam_portal['opened_at'])); ?></p>
                        <?php else: ?>
                            <p><i class="fas fa-user"></i> Closed by: <?php echo $exam_portal['closed_by_name']; ?></p>
                            <p><i class="fas fa-clock"></i> <?php echo date('M d, Y h:i A', strtotime($exam_portal['closed_at'])); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($exam_stats): ?>
                    <div style="background: rgba(0,0,0,0.05); padding: 15px; border-radius: 10px; margin-bottom: 15px;">
                        <p style="margin: 0 0 5px 0;"><strong>Submissions:</strong> <?php echo $exam_stats['total_submissions']; ?></p>
                        <p style="margin: 0 0 5px 0;"><strong>Teachers:</strong> <?php echo $exam_stats['teachers_submitted']; ?></p>
                        <p style="margin: 0;"><strong>Students:</strong> <?php echo $exam_stats['total_students']; ?></p>
                    </div>
                <?php endif; ?>
                
                <form method="POST" style="margin: 0;">
                    <input type="hidden" name="term_id" value="<?php echo $active_term['term_id']; ?>">
                    <input type="hidden" name="portal_type" value="exam">
                    <?php if ($exam_open): ?>
                        <button type="submit" name="action" value="close_portal" class="btn btn-danger" style="width: 100%;"
                                onclick="return confirm('Close Exam portal? Teachers will no longer be able to enter exam scores.')">
                            <i class="fas fa-lock"></i> Close Exam Portal
                        </button>
                    <?php else: ?>
                        <button type="submit" name="action" value="open_portal" class="btn btn-success" style="width: 100%;">
                            <i class="fas fa-lock-open"></i> Open Exam Portal
                        </button>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
            </div>
            <div style="padding: 20px; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                <a href="<?php echo APP_URL; ?>/admin/view-results.php" class="btn btn-primary">
                    <i class="fas fa-chart-bar"></i> View Results
                </a>
                <a href="<?php echo APP_URL; ?>/admin/generate-results.php" class="btn btn-success">
                    <i class="fas fa-file-pdf"></i> Generate Results
                </a>
                <a href="<?php echo APP_URL; ?>/admin/assessment-reports.php" class="btn btn-info">
                    <i class="fas fa-file-alt"></i> Assessment Reports
                </a>
            </div>
        </div>
    <?php endif; ?>
    
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
