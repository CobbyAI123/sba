<?php
// admin/school-settings.php - School Settings Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'School Settings';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get school details
$stmt = $db->prepare("SELECT * FROM schools WHERE school_id = ?");
$stmt->execute([$school_id]);
$school = $stmt->fetch();

if (!$school) {
    set_message('error', 'School not found!');
    redirect(APP_URL . '/admin/dashboard.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $school_name = sanitize_input($_POST['school_name']);
    $school_code = sanitize_input($_POST['school_code']);
    $address = sanitize_input($_POST['address']);
    $phone = sanitize_input($_POST['phone']);
    $email = sanitize_input($_POST['email']);
    $motto = sanitize_input($_POST['motto']);
    $established_date = sanitize_input($_POST['established_date']);
    $website = sanitize_input($_POST['website'] ?? '');
    
    // Handle logo upload
    $logo = $school['logo'];
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['logo']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            if ($_FILES['logo']['size'] <= 5000000) { // 5MB max
                $new_filename = 'school_' . $school_id . '_' . time() . '.' . $ext;
                $upload_path = SCHOOL_LOGO_PATH . $new_filename;
                
                if (move_uploaded_file($_FILES['logo']['tmp_name'], $upload_path)) {
                    // Delete old logo if exists
                    if ($school['logo'] && file_exists(SCHOOL_LOGO_PATH . $school['logo'])) {
                        unlink(SCHOOL_LOGO_PATH . $school['logo']);
                    }
                    $logo = $new_filename;
                } else {
                    set_message('error', 'Failed to upload logo!');
                }
            } else {
                set_message('error', 'Logo file size must be less than 5MB!');
            }
        } else {
            set_message('error', 'Invalid logo format! Only JPG, PNG, GIF allowed.');
        }
    }
    
    try {
        $stmt = $db->prepare("
            UPDATE schools 
            SET school_name = ?, 
                school_code = ?, 
                address = ?, 
                phone = ?, 
                email = ?, 
                motto = ?, 
                established_date = ?, 
                logo = ?,
                website = ?
            WHERE school_id = ?
        ");
        
        $stmt->execute([
            $school_name, 
            $school_code, 
            $address, 
            $phone, 
            $email, 
            $motto, 
            $established_date, 
            $logo,
            $website,
            $school_id
        ]);
        
        log_activity($current_user['user_id'], "Updated school settings", 'schools', $school_id);
        
        set_message('success', 'School settings updated successfully!');
        redirect(APP_URL . '/admin/school-settings.php');
    } catch (PDOException $e) {
        set_message('error', 'Error updating school settings: ' . $e->getMessage());
    }
}

// Refresh school data
$stmt = $db->prepare("SELECT * FROM schools WHERE school_id = ?");
$stmt->execute([$school_id]);
$school = $stmt->fetch();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .settings-container {
        max-width: 900px;
        margin: 0 auto;
    }
    
    .logo-preview {
        width: 150px;
        height: 150px;
        border-radius: 10px;
        object-fit: contain;
        border: 2px solid var(--border-color);
        padding: 10px;
        background: white;
    }
    
    .upload-area {
        border: 2px dashed var(--border-color);
        border-radius: 10px;
        padding: 20px;
        text-align: center;
        background: var(--card-bg);
        cursor: pointer;
        transition: all 0.3s ease;
        display: block;
        margin: 0 auto;
        max-width: 400px;
    }
    
    .upload-area:hover {
        border-color: var(--primary-blue);
        background: rgba(33, 150, 243, 0.05);
    }
    
    .upload-area i {
        font-size: 48px;
        color: var(--primary-blue);
        margin-bottom: 10px;
    }
    
    .current-logo {
        text-align: center;
        margin-bottom: 20px;
    }
    
    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .info-card {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        color: white;
        padding: 20px;
        border-radius: 10px;
        text-align: center;
    }
    
    .info-card h4 {
        margin: 0 0 10px 0;
        font-size: 14px;
        opacity: 0.9;
    }
    
    .info-card p {
        margin: 0;
        font-size: 20px;
        font-weight: 600;
    }
    </style>
    
    <div class="settings-container">
        <!-- Page Header -->
        <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white;">
            <div style="padding: 30px;">
                <h2 style="margin: 0 0 10px 0; color: white;">
                    <i class="fas fa-cog"></i> School Settings
                </h2>
                <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                    Manage your school information and branding
                </p>
            </div>
        </div>
    
        <!-- Current Info Cards -->
        <div class="info-grid">
            <div class="info-card">
                <h4><i class="fas fa-school"></i> School Code</h4>
                <p><?php echo $school['school_code']; ?></p>
            </div>
            <div class="info-card">
                <h4><i class="fas fa-calendar"></i> Established</h4>
                <p><?php echo $school['established_date'] ? date('Y', strtotime($school['established_date'])) : 'N/A'; ?></p>
            </div>
            <div class="info-card">
                <h4><i class="fas fa-check-circle"></i> Status</h4>
                <p><?php echo ucfirst($school['status']); ?></p>
            </div>
        </div>
    
        <!-- Settings Form -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-edit"></i> Update School Information</h3>
            </div>
            <div style="padding: 30px;">
                <form method="POST" enctype="multipart/form-data">
                    <!-- Logo Section -->
                    <div style="margin-bottom: 30px;">
                        <h4 style="margin-bottom: 20px;">
                            <i class="fas fa-image"></i> School Logo
                        </h4>
                        
                        <?php if ($school['logo']): ?>
                            <div class="current-logo">
                                <p style="margin-bottom: 10px; color: var(--text-secondary);">Current Logo:</p>
                                <img src="<?php echo APP_URL . '/uploads/logos/' . $school['logo']; ?>" 
                                     alt="School Logo" 
                                     class="logo-preview">
                            </div>
                        <?php endif; ?>
                        
                        <label class="upload-area" for="logo">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p style="margin: 10px 0 5px 0; font-weight: 600;">Click to upload new logo</p>
                            <p style="margin: 0; font-size: 14px; color: var(--text-secondary);">
                                JPG, PNG or GIF (Max 5MB)
                            </p>
                            <input type="file" 
                                   name="logo" 
                                   id="logo" 
                                   accept="image/*" 
                                   style="display: none;"
                                   onchange="previewLogo(this)">
                        </label>
                        
                        <div id="logoPreview" style="margin-top: 20px; text-align: center; display: none;">
                            <p style="margin-bottom: 10px; color: var(--text-secondary);">New Logo Preview:</p>
                            <img id="logoPreviewImg" class="logo-preview" alt="Preview">
                        </div>
                    </div>
    
                    <hr style="margin: 30px 0; border: none; border-top: 1px solid var(--border-color);">
    
                    <!-- Basic Information -->
                    <h4 style="margin-bottom: 20px;">
                        <i class="fas fa-info-circle"></i> Basic Information
                    </h4>
                    
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                        <div class="form-group">
                            <label for="school_name">School Name *</label>
                            <input type="text" 
                                   name="school_name" 
                                   id="school_name" 
                                   value="<?php echo htmlspecialchars($school['school_name']); ?>" 
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="school_code">School Code *</label>
                            <input type="text" 
                                   name="school_code" 
                                   id="school_code" 
                                   value="<?php echo htmlspecialchars($school['school_code']); ?>" 
                                   required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" 
                                   name="phone" 
                                   id="phone" 
                                   value="<?php echo htmlspecialchars($school['phone']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" 
                                   name="email" 
                                   id="email" 
                                   value="<?php echo htmlspecialchars($school['email']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label for="website">Website</label>
                            <input type="url" 
                                   name="website" 
                                   id="website" 
                                   value="<?php echo htmlspecialchars($school['website'] ?? ''); ?>"
                                   placeholder="https://www.example.com">
                        </div>
                        
                        <div class="form-group">
                            <label for="established_date">Established Date</label>
                            <input type="date" 
                                   name="established_date" 
                                   id="established_date" 
                                   value="<?php echo $school['established_date']; ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea name="address" 
                                  id="address" 
                                  rows="3"><?php echo htmlspecialchars($school['address']); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="motto">School Motto</label>
                        <input type="text" 
                               name="motto" 
                               id="motto" 
                               value="<?php echo htmlspecialchars($school['motto']); ?>"
                               placeholder="e.g., Excellence in Education">
                    </div>
    
                    <div style="margin-top: 30px; text-align: right;">
                        <button type="submit" class="btn btn-primary" style="padding: 12px 30px;">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
    function previewLogo(input) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                document.getElementById('logoPreview').style.display = 'block';
                document.getElementById('logoPreviewImg').src = e.target.result;
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
