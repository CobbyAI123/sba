<?php
// admin/students.php - Student Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/csv-handler.php';
require_once BASE_PATH . '/includes/default-passwords.php';

$page_title = 'Student Management';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle CSV template download
if (isset($_GET['action']) && $_GET['action'] == 'download_template') {
    // Get class list for reference
    $stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
    $stmt->execute([$school_id]);
    $classes = $stmt->fetchAll();
    
    // Create template with ONLY required headers
    $headers = ['first_name', 'last_name', 'class_id'];
    
    // Add sample rows - one per class to avoid duplicates
    $sample_data = [];
    $sample_first_names = ['John', 'Jane', 'Michael', 'Sarah', 'David', 'Emma', 'Daniel', 'Olivia', 'James', 'Sophia'];
    $sample_last_names = ['Doe', 'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez'];
    
    $index = 0;
    foreach ($classes as $class) {
        if ($index < count($sample_first_names)) {
            $sample_data[] = [
                $sample_first_names[$index],
                $sample_last_names[$index],
                $class['class_id']
            ];
            $index++;
        }
    }
    
    // If no classes or need more samples, add generic ones
    if (empty($sample_data)) {
        $sample_data = [
            ['John', 'Doe', '1'],
            ['Jane', 'Smith', '2'],
            ['Michael', 'Johnson', '3']
        ];
    }
    
    // Generate filename with school name and date
    $filename = 'students_import_template_' . date('Y-m-d') . '.csv';
    
    // Set headers for download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    
    $output = fopen('php://output', 'w');
    
    // Add BOM for Excel UTF-8 support
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Write column headers FIRST (no instruction rows to delete!)
    fputcsv($output, $headers);
    
    // Write sample data
    foreach ($sample_data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            // Add new student
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $middle_name = sanitize_input($_POST['middle_name']);
            $date_of_birth = sanitize_input($_POST['date_of_birth']);
            $gender = sanitize_input($_POST['gender']);
            $blood_group = sanitize_input($_POST['blood_group']);
            $address = sanitize_input($_POST['address']);
            $phone = sanitize_input($_POST['phone']);
            $email = sanitize_input($_POST['email']);
            $class_id = sanitize_input($_POST['class_id']);
            $admission_date = sanitize_input($_POST['admission_date']);
            $hometown_id = !empty($_POST['hometown_id']) ? intval($_POST['hometown_id']) : null;
            
            // Build fee exemptions array (new JSON-based system)
            $exemptions = [];
            if (isset($_POST['exempt_school'])) $exemptions[] = 'school';
            if (isset($_POST['exempt_canteen'])) $exemptions[] = 'canteen';
            if (isset($_POST['exempt_transport'])) $exemptions[] = 'transport';
            
            $fee_exemption = !empty($exemptions) ? json_encode($exemptions) : null;
            $exemption_reason = !empty($exemptions) ? sanitize_input($_POST['exemption_reason'] ?? '') : null;
            $exemption_date = !empty($exemptions) ? date('Y-m-d') : null;
            $exemption_approved_by = !empty($exemptions) ? $current_user['user_id'] : null;
            
            // Auto-generate unique admission number with class_id
            $admission_number = generate_admission_number($school_id, $class_id);
            
            try {
                $db->beginTransaction();
                
                // Check if email already exists (if provided)
                if (!empty($email)) {
                    $check_email = $db->prepare("SELECT COUNT(*) as count FROM users WHERE email = ? AND school_id = ?");
                    $check_email->execute([$email, $school_id]);
                    if ($check_email->fetch()['count'] > 0) {
                        $db->rollBack();
                        set_message('error', 'Error adding student: Email "' . htmlspecialchars($email) . '" is already in use by another user. Please use a different email.');
                        redirect(APP_URL . '/admin/students.php');
                        exit;
                    }
                }
                
                // Handle profile picture upload
                $profile_picture = null;
                if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
                    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
                    $max_size = 5 * 1024 * 1024; // 5MB
                    
                    if (in_array($_FILES['profile_picture']['type'], $allowed_types) && $_FILES['profile_picture']['size'] <= $max_size) {
                        // Create uploads directory if it doesn't exist
                        $upload_dir = BASE_PATH . '/uploads/avatars';
                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }
                        
                        $filename = 'student_' . time() . '_' . uniqid() . '.' . pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
                        $filepath = $upload_dir . '/' . $filename;
                        
                        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $filepath)) {
                            $profile_picture = $filename;
                        }
                    }
                }
                
                // Insert student record with hometown and new fee exemptions
                $stmt = $db->prepare("
                    INSERT INTO students (school_id, admission_number, class_id, hometown_id, 
                                         fee_exemption, exemption_reason, exemption_date, exemption_approved_by, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')
                ");
                $stmt->execute([$school_id, $admission_number, $class_id, $hometown_id, 
                               $fee_exemption, $exemption_reason, $exemption_date, $exemption_approved_by]);
                
                $student_id = $db->lastInsertId();
                
                // Create user account for student
                $username = strtolower($admission_number);
                $original_username = $username;
                // Use default password: student123
                $default_credentials = generate_default_credentials('student');
                $random_password = $default_credentials['password']; // student123
                $default_password = $default_credentials['hash'];
                $counter = 1;
                
                // Ensure unique username within school
                while (true) {
                    $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE username = ? AND school_id = ?");
                    $check_stmt->execute([$username, $school_id]);
                    if ($check_stmt->fetch()['count'] == 0) {
                        break;
                    }
                    $username = $original_username . '_' . $counter;
                    $counter++;
                }
                
                $stmt = $db->prepare("
                    INSERT INTO users (school_id, username, email, password_hash, role, status, first_name, last_name)
                    VALUES (?, ?, ?, ?, 'student', 'active', ?, ?)
                ");
                $stmt->execute([$school_id, $username, $email, $default_password, $first_name, $last_name]);
                
                $user_id = $db->lastInsertId();
                
                // Update student record with user_id
                $stmt = $db->prepare("UPDATE students SET user_id = ? WHERE student_id = ?");
                $stmt->execute([$user_id, $student_id]);
                
                $db->commit();
                
                // Send credentials email to student
                try {
                    $login_link = APP_URL . '/login.php';
                    $subject = "Your School Account Has Been Created";
                    $message = "
                        <h3>Welcome to School Management System!</h3>
                        <p>Dear " . htmlspecialchars($first_name) . ",</p>
                        <p>Your school account has been successfully created. You can now access the system using the credentials below.</p>
                        <hr style='margin: 20px 0;'>
                        <p><strong>Login Details:</strong></p>
                        <p><strong>Username:</strong> " . htmlspecialchars($username) . "</p>
                        <p><strong>Password:</strong> " . htmlspecialchars($random_password) . "</p>
                        <hr style='margin: 20px 0;'>
                        <p><a href='" . $login_link . "' style='background: #2D5BFF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;'>Login Now</a></p>
                        <p style='color: #999; font-size: 12px; margin-top: 20px;'>Please change your password immediately after your first login. Keep these credentials secure.</p>
                    ";
                    
                    send_email($email, $subject, $message, 'School Administration');
                } catch (Exception $e) {
                    // Email sending failed, but don't let it prevent account creation
                    error_log('Failed to send credentials email to ' . $email . ': ' . $e->getMessage());
                }
                
                log_activity($current_user['user_id'], "Added new student: $first_name $last_name with user account", 'students', $student_id);
                
                set_message('success', "Student added successfully! Credentials email sent to $email. Login - Username: $username, Password: $random_password");
                redirect(APP_URL . '/admin/students.php');
            } catch (PDOException $e) {
                $db->rollBack();
                set_message('error', 'Error adding student: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'edit') {
            // Edit student
            $student_id = sanitize_input($_POST['student_id']);
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $middle_name = sanitize_input($_POST['middle_name']);
            $date_of_birth = sanitize_input($_POST['date_of_birth']);
            $gender = sanitize_input($_POST['gender']);
            $blood_group = sanitize_input($_POST['blood_group']);
            $address = sanitize_input($_POST['address']);
            $phone = sanitize_input($_POST['phone']);
            $email = sanitize_input($_POST['email']);
            $class_id = sanitize_input($_POST['class_id']);
            $hometown_id = !empty($_POST['hometown_id']) ? intval($_POST['hometown_id']) : null;
            
            // Build fee exemptions array (new JSON-based system)
            $exemptions = [];
            if (isset($_POST['exempt_school'])) $exemptions[] = 'school';
            if (isset($_POST['exempt_canteen'])) $exemptions[] = 'canteen';
            if (isset($_POST['exempt_transport'])) $exemptions[] = 'transport';
            
            $fee_exemption = !empty($exemptions) ? json_encode($exemptions) : null;
            $exemption_reason = !empty($exemptions) ? sanitize_input($_POST['exemption_reason'] ?? '') : null;
            $exemption_date = !empty($exemptions) ? date('Y-m-d') : null;
            $exemption_approved_by = !empty($exemptions) ? $current_user['user_id'] : null;
            
            try {
                // Handle profile picture upload
                $profile_picture_clause = '';
                $profile_params = [];
                
                if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
                    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
                    $max_size = 5 * 1024 * 1024; // 5MB
                    
                    if (in_array($_FILES['profile_picture']['type'], $allowed_types) && $_FILES['profile_picture']['size'] <= $max_size) {
                        // Create uploads directory if it doesn't exist
                        $upload_dir = BASE_PATH . '/uploads/avatars';
                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }
                        
                        $ext = in_array($_FILES['profile_picture']['type'], ['image/jpeg']) ? '.jpg' : (in_array($_FILES['profile_picture']['type'], ['image/png']) ? '.png' : '.gif');
                        $filename = 'student_' . $student_id . $ext;
                        $filepath = $upload_dir . '/' . $filename;
                        
                        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $filepath)) {
                            // Success - file uploaded
                        }
                    }
                }
                
                // Update student class and user name info
                $stmt = $db->prepare("
                    UPDATE users 
                    SET first_name = ?, last_name = ?
                    WHERE user_id = (SELECT user_id FROM students WHERE student_id = ?)
                ");
                $stmt->execute([$first_name, $last_name, $student_id]);
                
                // Update student with hometown and new fee exemptions
                $stmt = $db->prepare("
                    UPDATE students 
                    SET class_id = ?, hometown_id = ?, 
                        fee_exemption = ?, exemption_reason = ?, exemption_date = ?, exemption_approved_by = ?
                    WHERE student_id = ? AND school_id = ?
                ");
                $stmt->execute([
                    $class_id, $hometown_id, 
                    $fee_exemption, $exemption_reason, $exemption_date, $exemption_approved_by,
                    $student_id, $school_id
                ]);
                
                log_activity($current_user['user_id'], "Updated student: $first_name $last_name", 'students', $student_id);
                
                set_message('success', 'Student updated successfully!');
                redirect(APP_URL . '/admin/students.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating student: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'import_csv') {
            // Import students from CSV
            if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] == 0) {
                $file_tmp = $_FILES['csv_file']['tmp_name'];
                $file_ext = strtolower(pathinfo($_FILES['csv_file']['name'], PATHINFO_EXTENSION));
                
                if ($file_ext != 'csv') {
                    set_message('error', 'Please upload a CSV file');
                    redirect(APP_URL . '/admin/students.php');
                    exit;
                }
                
                try {
                    // Parse CSV
                    $csv_data = CSVHandler::parseCSV($file_tmp, true);
                    
                    // Validate required fields - ONLY first_name, last_name, class_id
                    $required_fields = ['first_name', 'last_name', 'class_id'];
                    $errors = CSVHandler::validateCSV($csv_data, $required_fields);
                    
                    // Check for duplicate class_ids
                    $class_ids_used = [];
                    foreach ($csv_data as $index => $row) {
                        $class_id = $row['class_id'] ?? '';
                        if (in_array($class_id, $class_ids_used)) {
                            $errors[] = "Row " . ($index + 2) . ": Duplicate class_id '$class_id'. Each class can only appear once.";
                        }
                        $class_ids_used[] = $class_id;
                    }
                    
                    if (!empty($errors)) {
                        set_message('error', 'CSV Validation Errors: ' . implode(', ', $errors));
                        redirect(APP_URL . '/admin/students.php');
                        exit;
                    }
                    
                    // Sanitize data
                    $csv_data = CSVHandler::sanitizeData($csv_data);
                    
                    $db->beginTransaction();
                    $success_count = 0;
                    $error_count = 0;
                    
                    foreach ($csv_data as $row) {
                        try {
                            // Generate unique student_id: First 3 letters of first name + last letter of last name + random number (1-1000)
                            $first_name = $row['first_name'];
                            $last_name = $row['last_name'];
                            
                            $first_part = strtoupper(substr($first_name, 0, 3));
                            $last_part = strtoupper(substr($last_name, -1));
                            $random_num = rand(1, 1000);
                            $student_id = $first_part . $last_part . str_pad($random_num, 4, '0', STR_PAD_LEFT);
                            
                            // Check if student_id exists, regenerate if needed
                            $check_stmt = $db->prepare("SELECT COUNT(*) FROM students WHERE admission_number = ? AND school_id = ?");
                            $check_stmt->execute([$student_id, $school_id]);
                            
                            while ($check_stmt->fetchColumn() > 0) {
                                $random_num = rand(1, 1000);
                                $student_id = $first_part . $last_part . str_pad($random_num, 4, '0', STR_PAD_LEFT);
                                $check_stmt->execute([$student_id, $school_id]);
                            }
                            
                            // Auto-generate email
                            $email = strtolower($first_name . '.' . $last_name . '@student.school');
                            
                            // Insert student with minimal required data
                            $stmt = $db->prepare("
                                INSERT INTO students (school_id, admission_number, first_name, last_name, email, class_id, admission_date, status)
                                VALUES (?, ?, ?, ?, ?, ?, NOW(), 'active')
                            ");
                            $stmt->execute([
                                $school_id,
                                $student_id,
                                $first_name,
                                $last_name,
                                $email,
                                $row['class_id']
                            ]);
                            
                            $db_student_id = $db->lastInsertId();
                            
                            // Create user account with default password
                            $username = strtolower($student_id);
                            $original_username = $username;
                            // Use default password: student123
                            $default_credentials = generate_default_credentials('student');
                            $random_password = $default_credentials['password']; // student123
                            $default_password = $default_credentials['hash'];
                            $counter = 1;
                            
                            // Ensure unique username within school
                            while (true) {
                                $check_user = $db->prepare("SELECT COUNT(*) as count FROM users WHERE username = ? AND school_id = ?");
                                $check_user->execute([$username, $school_id]);
                                if ($check_user->fetch()['count'] == 0) {
                                    break;
                                }
                                $username = $original_username . '_' . $counter;
                                $counter++;
                            }
                            
                            $stmt = $db->prepare("
                                INSERT INTO users (school_id, username, email, password_hash, role, first_name, last_name, status)
                                VALUES (?, ?, ?, ?, 'student', ?, ?, 'active')
                            ");
                            $stmt->execute([
                                $school_id,
                                $username,
                                $email,
                                $default_password,
                                $first_name,
                                $last_name
                            ]);
                            
                            $success_count++;
                        } catch (PDOException $e) {
                            $error_count++;
                            // Continue with next row
                        }
                    }
                    
                    $db->commit();
                    
                    log_activity($current_user['user_id'], "Imported $success_count students from CSV", 'students', 0);
                    
                    set_message('success', "Successfully imported $success_count students! Errors: $error_count");
                    redirect(APP_URL . '/admin/students.php');
                } catch (Exception $e) {
                    $db->rollBack();
                    set_message('error', 'Error importing CSV: ' . $e->getMessage());
                    redirect(APP_URL . '/admin/students.php');
                }
            } else {
                set_message('error', 'Please select a CSV file to upload');
                redirect(APP_URL . '/admin/students.php');
            }
        } elseif ($_POST['action'] == 'delete') {
            $student_id = sanitize_input($_POST['student_id']);
            
            try {
                $stmt = $db->prepare("DELETE FROM students WHERE student_id = ? AND school_id = ?");
                $stmt->execute([$student_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted student ID: $student_id", 'students', (int)$student_id);
                
                set_message('success', 'Student deleted successfully!');
                redirect(APP_URL . '/admin/students.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting student: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete_by_class') {
            // Bulk delete students by class
            $class_id = sanitize_input($_POST['class_id']);
            
            if (empty($class_id)) {
                set_message('error', 'Please select a class to delete students');
                redirect(APP_URL . '/admin/students.php');
                exit;
            }
            
            try {
                $db->beginTransaction();
                
                // Get class name for logging
                $stmt = $db->prepare("SELECT class_name FROM classes WHERE class_id = ? AND school_id = ?");
                $stmt->execute([$class_id, $school_id]);
                $class = $stmt->fetch();
                $class_name = $class ? $class['class_name'] : 'Unknown Class';
                
                // Get count of students to be deleted
                $stmt = $db->prepare("SELECT COUNT(*) as count FROM students WHERE class_id = ? AND school_id = ?");
                $stmt->execute([$class_id, $school_id]);
                $count = $stmt->fetch()['count'];
                
                if ($count == 0) {
                    set_message('warning', 'No students found in the selected class');
                    redirect(APP_URL . '/admin/students.php');
                    exit;
                }
                
                // Get user_ids of students to delete their user accounts too
                $stmt = $db->prepare("SELECT user_id FROM students WHERE class_id = ? AND school_id = ? AND user_id IS NOT NULL");
                $stmt->execute([$class_id, $school_id]);
                $user_ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                // Delete students
                $stmt = $db->prepare("DELETE FROM students WHERE class_id = ? AND school_id = ?");
                $stmt->execute([$class_id, $school_id]);
                
                // Delete associated user accounts
                if (!empty($user_ids)) {
                    $placeholders = str_repeat('?,', count($user_ids) - 1) . '?';
                    $stmt = $db->prepare("DELETE FROM users WHERE user_id IN ($placeholders) AND school_id = ?");
                    $stmt->execute(array_merge($user_ids, [$school_id]));
                }
                
                $db->commit();
                
                log_activity($current_user['user_id'], "Deleted $count students from class: $class_name", 'students', 0);
                
                set_message('success', "Successfully deleted $count student(s) from class: $class_name");
                redirect(APP_URL . '/admin/students.php');
            } catch (PDOException $e) {
                $db->rollBack();
                set_message('error', 'Error deleting students: ' . $e->getMessage());
                redirect(APP_URL . '/admin/students.php');
            }
        }
    }
}

// Get filter parameters
$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$class_filter = isset($_GET['class']) ? sanitize_input($_GET['class']) : '';
$status_filter = isset($_GET['status']) ? sanitize_input($_GET['status']) : '';

// Build query with safe column selection
$query = "
    SELECT 
        s.student_id, 
        s.admission_number, 
        s.class_id, 
        s.status, 
        s.user_id, 
        s.school_id,
        -- Get names from users table first, fallback to students table
        COALESCE(NULLIF(u.first_name, ''), NULLIF(s.first_name, ''), 'Unknown') as first_name,
        COALESCE(NULLIF(u.last_name, ''), NULLIF(s.last_name, ''), '') as last_name,
        COALESCE(s.middle_name, '') as middle_name,
        s.date_of_birth,
        s.admission_date,
        s.gender,
        s.blood_group,
        s.address,
        s.phone,
        s.email,
        s.hometown_id,
        s.exempt_canteen,
        s.exempt_bus,
        s.canteen_fee_type,
        s.bus_fee_type,
        s.created_at,
        s.updated_at,
        c.class_name,
        u.username,
        u.email as user_email,
        COALESCE(h.hometown_name, '') as hometown_name,
        COALESCE(h.route_name, '') as route_name,
        COALESCE(h.bus_fee, 0) as bus_fee,
        COALESCE(s.fee_exemption, 'none') as fee_exemption,
        COALESCE(s.exemption_reason, '') as exemption_reason,
        s.exemption_date,
        s.exemption_approved_by,
        'student123' as temp_password
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.class_id
    LEFT JOIN users u ON s.user_id = u.user_id
    LEFT JOIN hometowns h ON s.hometown_id = h.hometown_id
    WHERE s.school_id = ?
";
$params = [$school_id];

if ($search) {
    $query .= " AND (COALESCE(u.first_name, s.first_name) LIKE ? OR COALESCE(u.last_name, s.last_name) LIKE ? OR s.admission_number LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

if ($class_filter) {
    $query .= " AND s.class_id = ?";
    $params[] = $class_filter;
}

if ($status_filter) {
    $query .= " AND s.status = ?";
    $params[] = $status_filter;
}

$query .= " ORDER BY s.created_at DESC";

try {
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $students = $stmt->fetchAll();
} catch (PDOException $e) {
    // If query fails due to missing columns, try simplified query
    $query = "
        SELECT 
            s.student_id,
            s.admission_number,
            s.class_id,
            s.status,
            s.user_id,
            s.school_id,
            -- Get names from users table first, fallback to students table
            COALESCE(NULLIF(u.first_name, ''), NULLIF(s.first_name, ''), 'Unknown') as first_name,
            COALESCE(NULLIF(u.last_name, ''), NULLIF(s.last_name, ''), '') as last_name,
            COALESCE(s.middle_name, '') as middle_name,
            s.date_of_birth,
            s.admission_date,
            COALESCE(s.gender, '') as gender,
            COALESCE(s.blood_group, '') as blood_group,
            COALESCE(s.address, '') as address,
            COALESCE(s.phone, '') as phone,
            COALESCE(s.email, '') as email,
            s.hometown_id,
            COALESCE(s.exempt_canteen, 0) as exempt_canteen,
            COALESCE(s.exempt_bus, 0) as exempt_bus,
            COALESCE(s.canteen_fee_type, 'daily') as canteen_fee_type,
            COALESCE(s.bus_fee_type, 'daily') as bus_fee_type,
            s.created_at,
            s.updated_at,
            c.class_name,
            u.username,
            u.email as user_email,
            '' as hometown_name,
            '' as route_name,
            0 as bus_fee,
            'none' as fee_exemption,
            '' as exemption_reason,
            NULL as exemption_date,
            NULL as exemption_approved_by,
            'student123' as temp_password
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.class_id
        LEFT JOIN users u ON s.user_id = u.user_id
        WHERE s.school_id = ?
    ";
    $params = [$school_id];
    
    if ($search) {
        $query .= " AND (COALESCE(u.first_name, s.first_name) LIKE ? OR COALESCE(u.last_name, s.last_name) LIKE ? OR s.admission_number LIKE ?)";
        $search_param = "%$search%";
        $params[] = $search_param;
        $params[] = $search_param;
        $params[] = $search_param;
    }
    
    if ($class_filter) {
        $query .= " AND s.class_id = ?";
        $params[] = $class_filter;
    }
    
    if ($status_filter) {
        $query .= " AND s.status = ?";
        $params[] = $status_filter;
    }
    
    $query .= " ORDER BY s.created_at DESC";
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $students = $stmt->fetchAll();
}

// Get all classes for dropdown
$classes = [];
try {
    $stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_id");
    $stmt->execute([$school_id]);
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $classes = [];
}

// Get all hometowns/routes for dropdown
$hometowns = [];
try {
    // Check if hometowns table exists
    $db->query("SELECT 1 FROM hometowns LIMIT 1");
    try {
        $has_school_id = count($db->query("SHOW COLUMNS FROM hometowns LIKE 'school_id'")->fetchAll()) > 0;
        if ($has_school_id) {
            $stmt = $db->prepare("SELECT * FROM hometowns WHERE school_id = ? AND status = 'active' ORDER BY hometown_name");
            $stmt->execute([$school_id]);
        } else {
            $stmt = $db->prepare("SELECT * FROM hometowns WHERE status = 'active' ORDER BY hometown_name");
            $stmt->execute();
        }
        $hometowns = $stmt->fetchAll();
    } catch (PDOException $e2) {
        $hometowns = [];
    }
} catch (PDOException $e) {
    // hometowns table doesn't exist
    $hometowns = [];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <button class="btn btn-primary" onclick="showAddModal()">
                <i class="fas fa-plus"></i> Add Student
            </button>
            
            <a href="<?php echo APP_URL; ?>/admin/bulk-import-students.php" class="btn btn-success">
                <i class="fas fa-file-import"></i> Bulk Import
            </a>
            
            <button class="btn btn-danger" onclick="showDeleteByClassModal()">
                <i class="fas fa-trash-alt"></i> Delete by Class
            </button>
            
            <!-- View Toggle -->
            <div class="btn-group" style="display: inline-flex; border: 2px solid var(--border-color); border-radius: 8px; overflow: hidden;">
                <button id="btnListView" onclick="setView('list')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--primary-blue); color: white;">
                    <i class="fas fa-list"></i> List
                </button>
                <button id="btnGridView" onclick="setView('grid')" class="btn btn-sm" style="border: none; border-radius: 0; background: var(--bg-secondary); color: var(--text-primary);">
                    <i class="fas fa-th"></i> Grid
                </button>
            </div>
        </div>
        <div style="display: flex; gap: 10px;">
            <form method="GET" style="display: flex; gap: 10px;">
                <input type="text" name="search" placeholder="Search students..." value="<?php echo $search; ?>" 
                       style="padding: 10px 15px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-secondary); color: var(--text-primary);">
                <select name="class" onchange="this.form.submit()"
                        style="padding: 10px 15px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-secondary); color: var(--text-primary);">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['class_id']; ?>" <?php echo $class_filter == $class['class_id'] ? 'selected' : ''; ?>>
                            <?php echo $class['class_name']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select name="status" onchange="this.form.submit()"
                        style="padding: 10px 15px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-secondary); color: var(--text-primary);">
                    <option value="">All Status</option>
                    <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="graduated" <?php echo $status_filter == 'graduated' ? 'selected' : ''; ?>>Graduated</option>
                    <option value="transferred" <?php echo $status_filter == 'transferred' ? 'selected' : ''; ?>>Transferred</option>
                </select>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i>
                </button>
            </form>
        </div>
    </div>
    
    
    <!-- Students Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-user-graduate"></i> Students (<?php echo count($students); ?>)</h3>
        </div>
        <div class="table-responsive">
            <table id="studentsTable">
                <thead>
                    <tr>
                        <th>Admission No.</th>
                        <th>Student Name</th>
                        <th>Class</th>
                        <th>Gender</th>
                        <th>Date of Birth</th>
                        <th>Contact</th>
                        <th>Login Credentials</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($students) > 0): ?>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><strong><?php echo $student['admission_number']; ?></strong></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <?php 
                                        $picture_file = BASE_PATH . '/uploads/avatars/student_' . $student['student_id'] . '.jpg';
                                        $has_picture = file_exists($picture_file) || file_exists(str_replace('.jpg', '.png', $picture_file));
                                        if ($has_picture) {
                                            $ext = file_exists($picture_file) ? '.jpg' : '.png';
                                            echo '<img src="' . APP_URL . '/uploads/avatars/student_' . htmlspecialchars($student['student_id']) . $ext . '" alt="Student" style="width: 35px; height: 35px; border-radius: 8px; object-fit: cover;">';
                                        } else {
                                            echo '<div style="width: 35px; height: 35px; border-radius: 8px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 12px;">' . strtoupper(substr($student['first_name'] ?? '', 0, 1) . substr($student['last_name'] ?? '', 0, 1)) . '</div>';
                                        }
                                        ?>
                                        <div>
                                            <?php 
                                            $full_name = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
                                            $display_name = !empty($full_name) ? $full_name : $student['admission_number'];
                                            $has_user_account = !empty($student['user_id']) && $student['user_id'] > 0;
                                            ?>
                                            <div style="font-weight: 600;"><?php echo htmlspecialchars($display_name); ?></div>
                                            <?php if ($has_user_account): ?>
                                                <div style="font-size: 12px; color: var(--text-secondary);"><?php echo htmlspecialchars($student['admission_number']); ?></div>
                                            <?php else: ?>
                                                <div style="font-size: 12px; color: #f44336;">⚠️ No user account linked</div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo $student['class_name'] ?? 'Not Assigned'; ?></td>
                                <td><?php echo ucfirst($student['gender'] ?? '-'); ?></td>
                                <td><?php echo (isset($student['date_of_birth']) && $student['date_of_birth'] ? date('M d, Y', strtotime($student['date_of_birth'])) : '-'); ?></td>
                                <td><?php echo $student['phone'] ?? '-'; ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <div id="cred-hidden-<?php echo $student['student_id']; ?>" style="font-family: monospace; font-size: 12px;">
                                            ••••••••
                                        </div>
                                        <div id="cred-shown-<?php echo $student['student_id']; ?>" style="display: none; font-family: monospace; font-size: 11px; line-height: 1.4;">
                                            <strong>User:</strong> <?php echo htmlspecialchars($student['username'] ?? 'N/A'); ?><br>
                                            <strong>Pass:</strong> <?php echo htmlspecialchars($student['temp_password'] ?? 'Not Set'); ?>
                                        </div>
                                        <button onclick="toggleCredentials(<?php echo $student['student_id']; ?>)" class="btn btn-sm btn-outline-secondary" style="padding: 4px 8px;">
                                            <i class="fas fa-eye" id="eye-<?php echo $student['student_id']; ?>"></i>
                                        </button>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $student['status'] == 'active' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($student['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-info" onclick="editStudent(this)" data-student="<?php echo htmlspecialchars(json_encode($student), ENT_QUOTES, 'UTF-8'); ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="deleteStudent(<?php echo $student['student_id']; ?>, '<?php echo htmlspecialchars(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? '')); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px;">
                                <div style="color: var(--text-secondary);">
                                    <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 20px; opacity: 0.5; display: block;"></i>
                                    <h3 style="margin: 0 0 10px 0; color: var(--text-secondary);">No Students Found</h3>
                                    <p style="margin: 0 0 20px 0;">Get started by adding your first student or importing from CSV.</p>
                                    <div style="display: flex; gap: 10px; justify-content: center; flex-wrap: wrap;">
                                        <button class="btn btn-primary" onclick="showAddModal()" style="text-decoration: none;">
                                            <i class="fas fa-plus"></i> Add Student
                                        </button>
                                        <a href="<?php echo APP_URL; ?>/admin/bulk-import-students.php" class="btn btn-success" style="text-decoration: none;">
                                            <i class="fas fa-file-import"></i> Bulk Import
                                        </a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Grid View -->
    <div id="studentsGrid" style="display: none; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;">
        <?php foreach ($students as $student): ?>
            <div class="card" style="padding: 20px;">
                <div style="text-align: center; margin-bottom: 15px;">
                    <?php 
                    // Check for profile picture - try multiple extensions
                    $picture_path = null;
                    $extensions = ['.jpg', '.jpeg', '.png', '.gif'];
                    foreach ($extensions as $ext) {
                        $test_path = BASE_PATH . '/uploads/avatars/student_' . $student['student_id'] . $ext;
                        if (file_exists($test_path)) {
                            $picture_path = APP_URL . '/uploads/avatars/student_' . $student['student_id'] . $ext;
                            break;
                        }
                    }
                    
                    if ($picture_path): ?>
                        <img src="<?php echo $picture_path; ?>" alt="Student" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid var(--primary-blue);">
                    <?php else: 
                        $initials = strtoupper(substr($student['first_name'] ?? 'U', 0, 1) . substr($student['last_name'] ?? 'N', 0, 1));
                    ?>
                        <div style="width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 28px; margin: 0 auto;">
                            <?php echo $initials; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <?php 
                $full_name = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
                $display_name = !empty($full_name) ? $full_name : $student['admission_number'];
                ?>
                <?php 
                $has_user_account = !empty($student['user_id']) && $student['user_id'] > 0;
                ?>
                <h4 style="text-align: center; margin: 0 0 5px 0;">
                    <?php echo htmlspecialchars($display_name); ?>
                </h4>
                <p style="text-align: center; color: var(--text-secondary); font-size: 12px; margin: 0 0 15px 0;">
                    <?php if ($has_user_account): ?>
                        <i class="fas fa-id-card"></i> <?php echo htmlspecialchars($student['admission_number']); ?>
                    <?php else: ?>
                        <i class="fas fa-exclamation-triangle" style="color: #f44336;"></i> <span style="color: #f44336;">No user account linked</span>
                    <?php endif; ?>
                </p>
                
                <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-bottom: 12px; font-size: 13px;">
                    <div style="margin-bottom: 8px;">
                        <i class="fas fa-chalkboard" style="width: 20px;"></i> 
                        <strong>Class:</strong> <?php echo htmlspecialchars($student['class_name'] ?? 'Not Assigned'); ?>
                    </div>
                    <div style="margin-bottom: 8px;">
                        <i class="fas fa-venus-mars" style="width: 20px;"></i> 
                        <strong>Gender:</strong> <?php echo ucfirst($student['gender'] ?? '-'); ?>
                    </div>
                    <div style="margin-bottom: 8px;">
                        <i class="fas fa-phone" style="width: 20px;"></i> 
                        <strong>Contact:</strong> <?php echo htmlspecialchars($student['phone'] ?? '-'); ?>
                    </div>
                    <div>
                        <i class="fas fa-calendar" style="width: 20px;"></i> 
                        <strong>DOB:</strong> <?php echo (isset($student['date_of_birth']) && $student['date_of_birth'] ? date('M d, Y', strtotime($student['date_of_birth'])) : '-'); ?>
                    </div>
                </div>
                
                <div style="background: var(--bg-secondary); padding: 12px; border-radius: 8px; margin-bottom: 12px; font-size: 12px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <strong><i class="fas fa-key"></i> Login Credentials</strong>
                        <button onclick="toggleCredentials(<?php echo $student['student_id']; ?>); return false;" type="button" class="btn btn-sm" style="padding: 4px 8px; background: var(--primary-blue); color: white; border: none; border-radius: 4px; cursor: pointer;">
                            <i class="fas fa-eye" id="eye-<?php echo $student['student_id']; ?>"></i>
                        </button>
                    </div>
                    <div id="cred-hidden-<?php echo $student['student_id']; ?>" style="font-family: monospace; color: var(--text-primary);">
                        ••••••••
                    </div>
                    <div id="cred-shown-<?php echo $student['student_id']; ?>" style="display: none; font-family: monospace; line-height: 1.6; color: var(--text-primary);">
                        <strong>Username:</strong> <?php echo htmlspecialchars($student['username'] ?? 'N/A'); ?><br>
                        <strong>Password:</strong> <?php echo htmlspecialchars($student['temp_password'] ?? 'Not Set'); ?>
                    </div>
                </div>
                
                <div style="text-align: center; margin-bottom: 12px;">
                    <span class="badge badge-<?php echo $student['status'] == 'active' ? 'success' : 'warning'; ?>">
                        <?php echo ucfirst($student['status']); ?>
                    </span>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">
                    <button class="btn btn-sm btn-info" onclick="editStudent(this)" data-student="<?php echo htmlspecialchars(json_encode($student), ENT_QUOTES, 'UTF-8'); ?>">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteStudent(<?php echo $student['student_id']; ?>, '<?php echo htmlspecialchars(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? '')); ?>')">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <!-- Add/Edit Student Modal -->
    <div id="studentModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 800px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Add Student</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="studentForm" enctype="multipart/form-data">
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="student_id" id="studentId">
                
                <div class="alert alert-info" style="margin-bottom: 20px;" id="alertBox">
                    <i class="fas fa-info-circle"></i>
                    <strong>Note:</strong> <span id="alertText">Admission number will be auto-generated (Format: SCHOOLCODE/YEAR/0001)</span>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label for="admission_date">Admission Date *</label>
                        <input type="date" name="admission_date" id="admission_date" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="first_name">First Name *</label>
                        <input type="text" name="first_name" id="first_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name *</label>
                        <input type="text" name="last_name" id="last_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="middle_name">Middle Name</label>
                        <input type="text" name="middle_name" id="middle_name">
                    </div>
                    
                    <div class="form-group">
                        <label for="date_of_birth">Date of Birth</label>
                        <input type="date" name="date_of_birth" id="date_of_birth">
                    </div>
                    
                    <div class="form-group">
                        <label for="gender">Gender</label>
                        <select name="gender" id="gender">
                            <option value="">Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="blood_group">Blood Group</label>
                        <select name="blood_group" id="blood_group">
                            <option value="">Select Blood Group</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="class_id">Class *</label>
                        <select name="class_id" id="class_id" required>
                            <option value="">Select Class</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>"><?php echo $class['class_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="tel" name="phone" id="phone">
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email">
                    </div>
                    
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label for="address">Address</label>
                        <textarea name="address" id="address" rows="3"></textarea>
                    </div>
                    
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label for="profile_picture">Student Picture</label>
                        <div style="display: flex; gap: 15px; align-items: flex-start;">
                            <div id="picturePreview" style="width: 80px; height: 80px; border-radius: 8px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; overflow: hidden;">
                                <span id="pictureInitials">--</span>
                                <img id="pictureImg" src="" alt="Preview" style="display: none; width: 100%; height: 100%; object-fit: cover;">
                            </div>
                            <div style="flex: 1;">
                                <input type="file" name="profile_picture" id="profile_picture" accept="image/*" onchange="previewPicture(event)" style="margin-bottom: 10px;">
                                <small style="color: var(--text-secondary); display: block;">Supported formats: JPG, PNG. Max size: 5MB</small>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Hometown/Route Selection -->
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label for="hometown_id">Hometown/Route (For Bus Fee Calculation)</label>
                        <select name="hometown_id" id="hometown_id">
                            <option value="">-- Select Hometown --</option>
                            <?php foreach ($hometowns as $ht): ?>
                                <option value="<?php echo $ht['hometown_id']; ?>" data-fee="<?php echo $ht['bus_fee']; ?>">
                                    <?php echo htmlspecialchars($ht['hometown_name']); ?> 
                                    (<?php echo htmlspecialchars($ht['route_name']); ?>) - 
                                    Bus Fee: <?php echo format_currency($ht['bus_fee']); ?>/day
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small style="color: var(--text-secondary); display: block; margin-top: 5px;">
                            Select the student's hometown to automatically calculate bus fees
                        </small>
                    </div>
                    
                    <!-- Fee Exemptions (New JSON-based System) -->
                    <div class="form-group" style="grid-column: 1 / -1;">
                        <label style="display: block; margin-bottom: 10px; font-weight: 700;">
                            <i class="fas fa-ban"></i> Fee Exemptions
                        </label>
                        <div style="background: var(--secondary-bg); padding: 15px; border-radius: 10px;">
                            <div style="display: flex; flex-direction: column; gap: 12px;">
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 12px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--card-bg); transition: all 0.3s;" onmouseover="this.style.borderColor='var(--active-pink)'" onmouseout="this.style.borderColor='var(--border-color)'">
                                    <input type="checkbox" name="exempt_school" id="exempt_school" value="1" 
                                           style="width: 20px; height: 20px; cursor: pointer;" onchange="updateExemptionReason()">
                                    <span style="font-weight: 600;"><i class="fas fa-graduation-cap" style="color: #2d5bff;"></i> Exempt from School Fees</span>
                                </label>
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 12px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--card-bg); transition: all 0.3s;" onmouseover="this.style.borderColor='var(--active-pink)'" onmouseout="this.style.borderColor='var(--border-color)'">
                                    <input type="checkbox" name="exempt_canteen" id="exempt_canteen" value="1" 
                                           style="width: 20px; height: 20px; cursor: pointer;" onchange="updateExemptionReason()">
                                    <span style="font-weight: 600;"><i class="fas fa-utensils" style="color: #ffa726;"></i> Exempt from Canteen Fees</span>
                                </label>
                                <label style="display: flex; align-items: center; gap: 12px; cursor: pointer; padding: 12px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--card-bg); transition: all 0.3s;" onmouseover="this.style.borderColor='var(--active-pink)'" onmouseout="this.style.borderColor='var(--border-color)'">
                                    <input type="checkbox" name="exempt_transport" id="exempt_transport" value="1" 
                                           style="width: 20px; height: 20px; cursor: pointer;" onchange="updateExemptionReason()">
                                    <span style="font-weight: 600;"><i class="fas fa-bus" style="color: #00d68f;"></i> Exempt from Transport/Bus Fees</span>
                                </label>
                            </div>
                        </div>
                        <small style="color: var(--text-secondary); display: block; margin-top: 8px;">
                            <i class="fas fa-info-circle"></i> Check the fees this student is exempt from paying
                        </small>
                    </div>
                    
                    <!-- Exemption Reason (Shows when any exemption is checked) -->
                    <div class="form-group" id="exemption_reason_group" style="grid-column: 1 / -1; display: none;">
                        <label style="font-weight: 700;">
                            <i class="fas fa-comment-alt"></i> Exemption Reason <span style="color: #ff3d71;">*</span>
                        </label>
                        <textarea name="exemption_reason" id="exemption_reason" 
                                  class="form-control" rows="3" 
                                  placeholder="Enter reason for fee exemption (e.g., Scholarship, Financial hardship, Staff child, Orphan, etc.)"
                                  style="padding: 12px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--secondary-bg); color: var(--text-primary); font-size: 14px;"></textarea>
                        <small style="color: var(--text-secondary); display: block; margin-top: 5px;">
                            <i class="fas fa-exclamation-triangle" style="color: #ffa726;"></i> Required when any fee exemption is selected
                        </small>
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Student
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete by Class Modal -->
    <div id="deleteByClassModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 500px; margin: 100px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="color: #f44336;"><i class="fas fa-exclamation-triangle"></i> Delete Students by Class</h2>
                <button onclick="closeDeleteByClassModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="alert alert-warning" style="margin-bottom: 20px;">
                <i class="fas fa-exclamation-circle"></i>
                <strong>Warning:</strong> This will permanently delete ALL students in the selected class, including their user accounts. This action cannot be undone!
            </div>
            
            <form method="POST" id="deleteByClassForm" onsubmit="return confirmDeleteByClass()">
                <input type="hidden" name="action" value="delete_by_class">
                
                <div class="form-group" style="margin-bottom: 20px;">
                    <label for="delete_class_id" style="display: block; margin-bottom: 10px; font-weight: 600;">
                        <i class="fas fa-chalkboard"></i> Select Class to Delete Students
                    </label>
                    <select name="class_id" id="delete_class_id" required style="width: 100%; padding: 12px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-secondary); color: var(--text-primary); font-size: 14px;">
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>">
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div id="studentCountDisplay" style="padding: 15px; background: var(--bg-light); border-radius: 8px; margin-bottom: 20px; display: none;">
                    <strong>Students in selected class:</strong> <span id="studentCount" style="color: #f44336; font-size: 18px; font-weight: 600;">0</span>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" class="btn btn-secondary" onclick="closeDeleteByClassModal()">Cancel</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash-alt"></i> Delete All Students
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    // View Toggle Functions
    function setView(view) {
        localStorage.setItem('studentView', view);
        const listView = document.querySelector('.card:has(#studentsTable)');
        const gridView = document.getElementById('studentsGrid');
        const btnList = document.getElementById('btnListView');
        const btnGrid = document.getElementById('btnGridView');
        
        if (view === 'grid') {
            listView.style.display = 'none';
            gridView.style.display = 'grid';
            btnGrid.style.background = 'var(--primary-blue)';
            btnGrid.style.color = 'white';
            btnList.style.background = 'var(--bg-secondary)';
            btnList.style.color = 'var(--text-primary)';
        } else {
            listView.style.display = 'block';
            gridView.style.display = 'none';
            btnList.style.background = 'var(--primary-blue)';
            btnList.style.color = 'white';
            btnGrid.style.background = 'var(--bg-secondary)';
            btnGrid.style.color = 'var(--text-primary)';
        }
    }
    
    // Toggle Credentials Visibility
    function toggleCredentials(studentId) {
        const hidden = document.getElementById('cred-hidden-' + studentId);
        const shown = document.getElementById('cred-shown-' + studentId);
        const eyes = document.querySelectorAll('#eye-' + studentId);
        
        if (hidden.style.display === 'none') {
            hidden.style.display = 'block';
            shown.style.display = 'none';
            eyes.forEach(eye => eye.className = 'fas fa-eye');
        } else {
            hidden.style.display = 'none';
            shown.style.display = 'block';
            eyes.forEach(eye => eye.className = 'fas fa-eye-slash');
        }
    }
    
    // Load saved view preference on page load
    window.addEventListener('DOMContentLoaded', function() {
        const savedView = localStorage.getItem('studentView') || 'list';
        setView(savedView);
    });
    
    function showAddModal() {
        document.getElementById('studentModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Add Student';
        document.getElementById('formAction').value = 'add';
        document.getElementById('alertText').textContent = 'Admission number will be auto-generated (Format: SCHOOLCODE/YEAR/0001)';
        document.getElementById('studentForm').reset();
        document.getElementById('studentId').value = '';
        
        // Reset picture preview
        document.getElementById('pictureInitials').textContent = '--';
        document.getElementById('pictureInitials').style.display = 'inline';
        document.getElementById('pictureImg').style.display = 'none';
    }
    
    function editStudent(button) {
        console.log('🔵 Edit button clicked!');
        
        try {
            const studentDataRaw = button.getAttribute('data-student');
            console.log('📝 Raw student data:', studentDataRaw);
            
            if (!studentDataRaw) {
                throw new Error('No student data found on button');
            }
            
            // Decode HTML entities
            const textarea = document.createElement('textarea');
            textarea.innerHTML = studentDataRaw;
            const studentDataDecoded = textarea.value;
            console.log('✏️ Decoded student data:', studentDataDecoded);
            
            const student = JSON.parse(studentDataDecoded);
            console.log('📊 Parsed student object:', student);
            console.log('🔍 Key fields check:');
            console.log('  - date_of_birth:', student.date_of_birth);
            console.log('  - admission_date:', student.admission_date);
            console.log('  - middle_name:', student.middle_name);
            console.log('  - address:', student.address);
            console.log('  - phone:', student.phone);
            console.log('  - blood_group:', student.blood_group);
            
            // Get modal
            const modal = document.getElementById('studentModal');
            console.log('🪟 Modal element:', modal);
            
            if (!modal) {
                throw new Error('Student modal not found in DOM');
            }
            
            // Show modal first
            modal.style.display = 'block';
            console.log('✅ Modal displayed');
            
            // Get form elements
            const modalTitle = document.getElementById('modalTitle');
            const formAction = document.getElementById('formAction');
            const alertText = document.getElementById('alertText');
            const studentId = document.getElementById('studentId');
            
            // Update modal title and form action
            if (modalTitle) modalTitle.textContent = 'Edit Student';
            if (formAction) formAction.value = 'edit';
            if (alertText) alertText.textContent = 'Update student information below';
            if (studentId) studentId.value = student.student_id || '';
            
            console.log('📋 Form action set to:', formAction ? formAction.value : 'NOT FOUND');
            
            // Populate form fields
            const setFieldValue = (id, value) => {
                const field = document.getElementById(id);
                if (field) {
                    field.value = value || '';
                    console.log(`✓ Set ${id} = ${value}`);
                } else {
                    console.warn(`⚠️ Field not found: ${id}`);
                }
            };
            
            setFieldValue('first_name', student.first_name);
            setFieldValue('last_name', student.last_name);
            setFieldValue('middle_name', student.middle_name);
            setFieldValue('date_of_birth', student.date_of_birth);
            setFieldValue('gender', student.gender);
            setFieldValue('blood_group', student.blood_group);
            setFieldValue('class_id', student.class_id);
            setFieldValue('phone', student.phone);
            setFieldValue('email', student.user_email || student.email);
            setFieldValue('address', student.address);
            setFieldValue('admission_date', student.admission_date);
            setFieldValue('hometown_id', student.hometown_id);
            
            // Set exemption checkboxes (new JSON-based system)
            let exemptions = [];
            try {
                if (student.fee_exemption && student.fee_exemption !== 'none' && student.fee_exemption !== 'null') {
                    exemptions = JSON.parse(student.fee_exemption);
                }
            } catch (e) {
                console.warn('Failed to parse fee_exemption:', student.fee_exemption, e);
                exemptions = [];
            }
            
            const exemptSchool = document.getElementById('exempt_school');
            const exemptCanteen = document.getElementById('exempt_canteen');
            const exemptTransport = document.getElementById('exempt_transport');
            const exemptionReason = document.getElementById('exemption_reason');
            
            if (exemptSchool) exemptSchool.checked = exemptions.includes('school');
            if (exemptCanteen) exemptCanteen.checked = exemptions.includes('canteen');
            if (exemptTransport) exemptTransport.checked = exemptions.includes('transport');
            if (exemptionReason) exemptionReason.value = student.exemption_reason || '';
            
            // Show/hide exemption reason field
            updateExemptionReason();
            
            // Update picture preview
            const pictureInitials = document.getElementById('pictureInitials');
            const pictureImg = document.getElementById('pictureImg');
            
            if (pictureInitials && pictureImg) {
                const fname = (student.first_name || '').substring(0, 1).toUpperCase();
                const lname = (student.last_name || '').substring(0, 1).toUpperCase();
                const initials = (fname + lname) || '--';
                
                pictureInitials.textContent = initials;
                pictureInitials.style.display = 'inline';
                pictureImg.style.display = 'none';
                
                // Try to load student image
                const imgSrc = '<?php echo APP_URL; ?>/uploads/avatars/student_' + student.student_id + '.jpg';
                pictureImg.src = imgSrc;
                
                const img = new Image();
                img.onload = function() {
                    pictureImg.style.display = 'block';
                    pictureInitials.style.display = 'none';
                };
                img.onerror = function() {
                    pictureInitials.style.display = 'inline';
                    pictureImg.style.display = 'none';
                };
                img.src = imgSrc;
            }
            
            console.log('✅✅✅ Student data loaded successfully!');
        } catch (error) {
            console.error('❌ Error in editStudent:', error);
            console.error('Stack:', error.stack);
            alert('ERROR: ' + error.message + '\n\nCheck browser console (F12) for details.');
        }
    }
    
    function closeModal() {
        document.getElementById('studentModal').style.display = 'none';
    }
    
    function showDeleteByClassModal() {
        document.getElementById('deleteByClassModal').style.display = 'block';
        document.getElementById('delete_class_id').value = '';
        document.getElementById('studentCountDisplay').style.display = 'none';
    }
    
    function closeDeleteByClassModal() {
        document.getElementById('deleteByClassModal').style.display = 'none';
    }
    
    function confirmDeleteByClass() {
        const classSelect = document.getElementById('delete_class_id');
        const selectedClass = classSelect.options[classSelect.selectedIndex].text;
        const studentCount = document.getElementById('studentCount').textContent;
        
        return confirm(
            `Are you absolutely sure you want to delete ALL ${studentCount} student(s) from ${selectedClass}?\n\n` +
            `This will:\n` +
            `• Delete all student records\n` +
            `• Delete all associated user accounts\n` +
            `• Remove all student data permanently\n\n` +
            `THIS ACTION CANNOT BE UNDONE!`
        );
    }
    
    // Get student count when class is selected
    document.addEventListener('DOMContentLoaded', function() {
        const deleteClassSelect = document.getElementById('delete_class_id');
        if (deleteClassSelect) {
            deleteClassSelect.addEventListener('change', function() {
                const classId = this.value;
                if (classId) {
                    // Count students in this class from the current page data
                    const students = <?php echo json_encode($students); ?>;
                    const count = students.filter(s => s.class_id == classId).length;
                    
                    document.getElementById('studentCount').textContent = count;
                    document.getElementById('studentCountDisplay').style.display = count > 0 ? 'block' : 'none';
                } else {
                    document.getElementById('studentCountDisplay').style.display = 'none';
                }
            });
        }
    });
    
    function previewPicture(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('pictureImg').src = e.target.result;
                document.getElementById('pictureImg').style.display = 'block';
                document.getElementById('pictureInitials').style.display = 'none';
            };
            reader.readAsDataURL(file);
        }
    }
    
    function deleteStudent(studentId, studentName) {
        if (confirm(`Are you sure you want to delete student: ${studentName}? This action cannot be undone.`)) {
            const form = document.createElement('form');
            form.method = 'POST';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'delete';
            form.appendChild(actionInput);
            
            const studentIdInput = document.createElement('input');
            studentIdInput.type = 'hidden';
            studentIdInput.name = 'student_id';
            studentIdInput.value = studentId;
            form.appendChild(studentIdInput);
            
            document.body.appendChild(form);
            form.submit();
        }
    }
    
    // Close modal on outside click
    document.getElementById('studentModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    
    // Close delete by class modal on outside click
    const deleteByClassModal = document.getElementById('deleteByClassModal');
    if (deleteByClassModal) {
        deleteByClassModal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeDeleteByClassModal();
            }
        });
    }
    
    // Show/hide exemption reason field based on checkbox selection
    function updateExemptionReason() {
        const schoolChecked = document.getElementById('exempt_school')?.checked || false;
        const canteenChecked = document.getElementById('exempt_canteen')?.checked || false;
        const transportChecked = document.getElementById('exempt_transport')?.checked || false;
        
        const reasonGroup = document.getElementById('exemption_reason_group');
        const reasonField = document.getElementById('exemption_reason');
        
        if (schoolChecked || canteenChecked || transportChecked) {
            reasonGroup.style.display = 'block';
            reasonField.required = true;
        } else {
            reasonGroup.style.display = 'none';
            reasonField.required = false;
            reasonField.value = '';
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
