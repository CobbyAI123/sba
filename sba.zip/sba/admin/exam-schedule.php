<?php
// admin/exam-schedule.php - Manage Exam Schedule
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Exam Schedule';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$user_id = $current_user['user_id'];

// Get exam_id from URL
$exam_id = isset($_GET['exam_id']) ? (int)$_GET['exam_id'] : 0;

if (!$exam_id) {
    set_message('error', 'Invalid exam');
    redirect(APP_URL . '/admin/manage-exams.php');
    exit;
}

// Get exam details
$stmt = $db->prepare("SELECT * FROM exams WHERE exam_id = ? AND school_id = ?");
$stmt->execute([$exam_id, $school_id]);
$exam = $stmt->fetch();

if (!$exam) {
    set_message('error', 'Exam not found');
    redirect(APP_URL . '/admin/manage-exams.php');
    exit;
}

// Handle schedule actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_message('error', 'Invalid request');
        redirect(APP_URL . '/admin/exam-schedule.php?exam_id=' . $exam_id);
        exit;
    }
    
    if ($_POST['action'] == 'add_schedule') {
        $class_id = (int)$_POST['class_id'];
        $subject_id = (int)$_POST['subject_id'];
        $exam_date = sanitize_input($_POST['exam_date']);
        $start_time = sanitize_input($_POST['start_time']);
        $end_time = sanitize_input($_POST['end_time']);
        $duration = (int)$_POST['duration_minutes'];
        $total_marks = (int)$_POST['total_marks'];
        $room_number = sanitize_input($_POST['room_number']);
        
        try {
            $stmt = $db->prepare("
                INSERT INTO exam_schedule 
                (exam_id, class_id, subject_id, exam_date, start_time, end_time, duration_minutes, total_marks, room_number, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'scheduled')
            ");
            $stmt->execute([$exam_id, $class_id, $subject_id, $exam_date, $start_time, $end_time, $duration, $total_marks, $room_number]);
            
            log_activity($user_id, "Added exam schedule", 'exam_schedule', $db->lastInsertId());
            set_message('success', 'Schedule added successfully!');
            
        } catch (PDOException $e) {
            set_message('error', 'Error adding schedule: ' . $e->getMessage());
        }
        redirect(APP_URL . '/admin/exam-schedule.php?exam_id=' . $exam_id);
    } elseif ($_POST['action'] == 'delete_schedule') {
        $schedule_id = (int)$_POST['schedule_id'];
        
        try {
            $stmt = $db->prepare("DELETE FROM exam_schedule WHERE schedule_id = ? AND exam_id = ?");
            $stmt->execute([$schedule_id, $exam_id]);
            
            log_activity($user_id, "Deleted exam schedule", 'exam_schedule', $schedule_id);
            set_message('success', 'Schedule deleted!');
            
        } catch (PDOException $e) {
            set_message('error', 'Error deleting: ' . $e->getMessage());
        }
        redirect(APP_URL . '/admin/exam-schedule.php?exam_id=' . $exam_id);
    }
}

// Get exam schedules
$stmt = $db->prepare("
    SELECT 
        es.*,
        c.class_name,
        s.subject_name,
        COUNT(DISTINCT st.student_id) as student_count
    FROM exam_schedule es
    INNER JOIN classes c ON es.class_id = c.class_id
    INNER JOIN subjects s ON es.subject_id = s.subject_id
    LEFT JOIN students st ON c.class_id = st.class_id AND st.status = 'active'
    WHERE es.exam_id = ?
    GROUP BY es.schedule_id
    ORDER BY es.exam_date, es.start_time
");
$stmt->execute([$exam_id]);
$schedules = $stmt->fetchAll();

// Get classes for dropdown
$stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get subjects for dropdown
$stmt = $db->prepare("SELECT subject_id, subject_name FROM subjects WHERE school_id = ? ORDER BY subject_name");
$stmt->execute([$school_id]);
$subjects = $stmt->fetchAll();

// Get exam rooms
$stmt = $db->prepare("SELECT room_number, room_name FROM exam_rooms WHERE school_id = ? AND status = 'active' ORDER BY room_number");
$stmt->execute([$school_id]);
$rooms = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .schedule-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 15px;
    }
    
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.7);
        z-index: 9999;
        overflow-y: auto;
    }
    
    .modal-content {
        max-width: 700px;
        margin: 30px auto;
        background: var(--bg-card);
        border-radius: 15px;
        padding: 30px;
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h2><i class="fas fa-calendar-alt"></i> Exam Schedule</h2>
                <p style="color: var(--text-secondary); margin-top: 8px;">
                    <?php echo htmlspecialchars($exam['exam_name']); ?> - 
                    <?php echo date('M d', strtotime($exam['start_date'])); ?> to 
                    <?php echo date('M d, Y', strtotime($exam['end_date'])); ?>
                </p>
            </div>
            <a href="<?php echo APP_URL; ?>/admin/manage-exams.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Exams
            </a>
        </div>
    </div>
    
    <!-- Actions -->
    <div style="margin-bottom: 20px;">
        <button onclick="showAddModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add Schedule
        </button>
        <a href="<?php echo APP_URL; ?>/admin/exam-rooms.php" class="btn btn-secondary">
            <i class="fas fa-door-open"></i> Manage Rooms
        </a>
    </div>
    
    <!-- Schedules -->
    <?php if (count($schedules) > 0): ?>
        <?php 
        $current_date = '';
        foreach ($schedules as $schedule): 
            $schedule_date = date('l, F d, Y', strtotime($schedule['exam_date']));
            if ($schedule_date != $current_date):
                if ($current_date != '') echo "</div>";
                $current_date = $schedule_date;
        ?>
            <h3 style="margin: 30px 0 15px 0; color: var(--primary-blue);">
                <i class="fas fa-calendar-day"></i> <?php echo $schedule_date; ?>
            </h3>
            <div style="margin-left: 20px;">
        <?php endif; ?>
        
            <div class="schedule-card">
                <div style="display: flex; justify-content: space-between; align-items: start;">
                    <div style="flex: 1;">
                        <h4 style="margin: 0 0 10px 0;">
                            <?php echo htmlspecialchars($schedule['subject_name']); ?>
                        </h4>
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin: 10px 0;">
                            <div>
                                <strong>Class:</strong> 
                                <?php echo htmlspecialchars($schedule['class_name']); ?>
                            </div>
                            <div>
                                <strong>Time:</strong> 
                                <?php echo date('g:i A', strtotime($schedule['start_time'])); ?> - 
                                <?php echo date('g:i A', strtotime($schedule['end_time'])); ?>
                            </div>
                            <div>
                                <strong>Duration:</strong> <?php echo $schedule['duration_minutes']; ?> mins
                            </div>
                            <div>
                                <strong>Marks:</strong> <?php echo $schedule['total_marks']; ?>
                            </div>
                            <div>
                                <strong>Room:</strong> <?php echo htmlspecialchars($schedule['room_number']); ?>
                            </div>
                            <div>
                                <strong>Students:</strong> <?php echo $schedule['student_count']; ?>
                            </div>
                        </div>
                    </div>
                    
                    <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this schedule?')">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="action" value="delete_schedule">
                        <input type="hidden" name="schedule_id" value="<?php echo $schedule['schedule_id']; ?>">
                        <button type="submit" class="btn btn-sm btn-danger">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                </div>
            </div>
        
        <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 60px; background: var(--bg-card); border-radius: 15px;">
            <i class="fas fa-calendar-times" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
            <h3 style="color: var(--text-secondary);">No Schedule Added Yet</h3>
            <p style="color: var(--text-secondary);">Add exam schedules for different classes and subjects</p>
        </div>
    <?php endif; ?>
    
    <!-- Add Schedule Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="margin: 0;"><i class="fas fa-plus"></i> Add Exam Schedule</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="add_schedule">
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <div class="form-group">
                        <label>Class *</label>
                        <select name="class_id" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>">
                                    <?php echo htmlspecialchars($class['class_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Subject *</label>
                        <select name="subject_id" required>
                            <option value="">-- Select Subject --</option>
                            <?php foreach ($subjects as $subject): ?>
                                <option value="<?php echo $subject['subject_id']; ?>">
                                    <?php echo htmlspecialchars($subject['subject_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Exam Date *</label>
                    <input type="date" name="exam_date" required 
                           min="<?php echo $exam['start_date']; ?>" 
                           max="<?php echo $exam['end_date']; ?>">
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                    <div class="form-group">
                        <label>Start Time *</label>
                        <input type="time" name="start_time" required>
                    </div>
                    
                    <div class="form-group">
                        <label>End Time *</label>
                        <input type="time" name="end_time" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Duration (mins) *</label>
                        <input type="number" name="duration_minutes" required min="15" step="15" value="60">
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                    <div class="form-group">
                        <label>Total Marks *</label>
                        <input type="number" name="total_marks" required min="1" value="100">
                    </div>
                    
                    <div class="form-group">
                        <label>Room *</label>
                        <select name="room_number" required>
                            <option value="">-- Select Room --</option>
                            <?php foreach ($rooms as $room): ?>
                                <option value="<?php echo htmlspecialchars($room['room_number']); ?>">
                                    <?php echo htmlspecialchars($room['room_number'] . ' - ' . $room['room_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check"></i> Add Schedule
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showAddModal() {
        document.getElementById('addModal').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('addModal').style.display = 'none';
    }
    
    window.onclick = function(event) {
        const modal = document.getElementById('addModal');
        if (event.target == modal) {
            closeModal();
        }
    }
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
