<?php
// admin/attendance-reports.php - Attendance Reports
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Attendance Reports';
$current_user = check_permission(['admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get filter parameters
$class_filter = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$month_filter = isset($_GET['month']) ? sanitize_input($_GET['month']) : date('Y-m');
$term_filter = isset($_GET['term_id']) ? (int)$_GET['term_id'] : 0;

// Get classes
$stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get terms
$stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY start_date DESC");
$stmt->execute([$school_id]);
$terms = $stmt->fetchAll();

// Get attendance data if class is selected
$attendance_data = [];
$class_info = null;

if ($class_filter > 0) {
    // Get class info
    $stmt = $db->prepare("SELECT * FROM classes WHERE class_id = ?");
    $stmt->execute([$class_filter]);
    $class_info = $stmt->fetch();
    
    // Get students with attendance
    $start_date = $month_filter . '-01';
    $end_date = date('Y-m-t', strtotime($start_date));
    
    // If term filter is set, use term dates instead
    if ($term_filter > 0) {
        $stmt = $db->prepare("SELECT * FROM terms WHERE term_id = ?");
        $stmt->execute([$term_filter]);
        $term_info = $stmt->fetch();
        if ($term_info) {
            $start_date = $term_info['start_date'];
            $end_date = $term_info['end_date'];
        }
    }
    
    $stmt = $db->prepare("
        SELECT 
            s.student_id,
            u.first_name,
            u.last_name,
            s.admission_number,
            COUNT(DISTINCT a.date) as total_days,
            SUM(CASE WHEN a.status = 'present' THEN 1 ELSE 0 END) as present_days,
            SUM(CASE WHEN a.status = 'absent' THEN 1 ELSE 0 END) as absent_days,
            SUM(CASE WHEN a.status = 'late' THEN 1 ELSE 0 END) as late_days
        FROM students s
        INNER JOIN users u ON s.user_id = u.user_id
        LEFT JOIN attendance a ON s.student_id = a.student_id 
            AND a.date BETWEEN ? AND ?
        WHERE s.class_id = ? AND s.school_id = ?
        GROUP BY s.student_id
        ORDER BY u.first_name, u.last_name
    ");
    $stmt->execute([$start_date, $end_date, $class_filter, $school_id]);
    $attendance_data = $stmt->fetchAll();
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .attendance-table {
        width: 100%;
        background: var(--card-bg);
        border-radius: 15px;
        overflow: hidden;
    }
    
    .attendance-table table {
        width: 100%;
    }
    
    .attendance-table th {
        background: linear-gradient(135deg, #2196F3, #1976D2);
        color: white;
        padding: 15px;
        text-align: left;
    }
    
    .attendance-table td {
        padding: 15px;
        border-bottom: 1px solid var(--border-color);
    }
    
    .percentage-bar {
        width: 100%;
        height: 8px;
        background: #e0e0e0;
        border-radius: 4px;
        overflow: hidden;
    }
    
    .percentage-fill {
        height: 100%;
        transition: width 0.3s ease;
    }
    
    .percentage-excellent { background: #4CAF50; }
    .percentage-good { background: #2196F3; }
    .percentage-average { background: #FF9800; }
    .percentage-poor { background: #F44336; }
    
    .status-badge {
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .status-excellent { background: rgba(76, 175, 80, 0.1); color: #4CAF50; }
    .status-good { background: rgba(33, 150, 243, 0.1); color: #2196F3; }
    .status-average { background: rgba(255, 152, 0, 0.1); color: #FF9800; }
    .status-poor { background: rgba(244, 67, 54, 0.1); color: #F44336; }
    </style>
    
    <!-- Page Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-chart-pie"></i> Attendance Reports
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                View and analyze student attendance
            </p>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card" style="margin-bottom: 30px;">
        <div style="padding: 25px;">
            <h3 style="margin-bottom: 20px;"><i class="fas fa-filter"></i> Select Class & Period</h3>
            <form method="GET">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                    <div class="form-group">
                        <label>Class *</label>
                        <select name="class_id" required onchange="this.form.submit()">
                            <option value="">-- Select Class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['class_id']; ?>" <?php echo $class_filter == $class['class_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($class['class_name']); ?>
                                    <?php echo !empty($class['section']) ? ' - ' . htmlspecialchars($class['section']) : ''; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Filter by Term (Optional)</label>
                        <select name="term_id" onchange="this.form.submit()">
                            <option value="">-- By Month --</option>
                            <?php foreach ($terms as $t): ?>
                                <option value="<?php echo $t['term_id']; ?>" <?php echo $term_filter == $t['term_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($t['term_name'] . ' (' . $t['session_year'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group" <?php echo $term_filter == 0 ? '' : 'style="display: none;"'; ?>>
                        <label>Month *</label>
                        <input type="month" name="month" value="<?php echo $month_filter; ?>" onchange="this.form.submit()" required>
                    </div>
                    
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <button type="button" onclick="window.print()" class="btn btn-primary" style="width: 100%;">
                            <i class="fas fa-print"></i> Print Report
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <?php if ($class_info && count($attendance_data) > 0): 
        // Calculate class statistics
        $total_students = count($attendance_data);
        $avg_attendance = 0;
        $excellent_count = 0;
        $good_count = 0;
        $average_count = 0;
        $poor_count = 0;
        
        foreach ($attendance_data as $student) {
            $percentage = $student['total_days'] > 0 ? ($student['present_days'] / $student['total_days']) * 100 : 0;
            $avg_attendance += $percentage;
            
            if ($percentage >= 90) $excellent_count++;
            elseif ($percentage >= 80) $good_count++;
            elseif ($percentage >= 70) $average_count++;
            else $poor_count++;
        }
        
        $avg_attendance = $total_students > 0 ? $avg_attendance / $total_students : 0;
    ?>
        <!-- Class Statistics -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
            <div class="stat-card" style="background: linear-gradient(135deg, #2196F3, #1976D2); color: white; padding: 25px; border-radius: 15px;">
                <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Average Attendance</div>
                <div style="font-size: 36px; font-weight: 700;"><?php echo number_format($avg_attendance, 1); ?>%</div>
            </div>
            <div class="stat-card" style="background: linear-gradient(135deg, #4CAF50, #388E3C); color: white; padding: 25px; border-radius: 15px;">
                <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Excellent (≥90%)</div>
                <div style="font-size: 36px; font-weight: 700;"><?php echo $excellent_count; ?></div>
            </div>
            <div class="stat-card" style="background: linear-gradient(135deg, #FF9800, #F57C00); color: white; padding: 25px; border-radius: 15px;">
                <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Good (≥80%)</div>
                <div style="font-size: 36px; font-weight: 700;"><?php echo $good_count; ?></div>
            </div>
            <div class="stat-card" style="background: linear-gradient(135deg, #F44336, #D32F2F); color: white; padding: 25px; border-radius: 15px;">
                <div style="font-size: 14px; opacity: 0.9; margin-bottom: 10px;">Poor (<70%)</div>
                <div style="font-size: 36px; font-weight: 700;"><?php echo $poor_count; ?></div>
            </div>
        </div>
        
        <!-- Attendance Table -->
        <div class="attendance-table">
            <table>
                <thead>
                    <tr>
                        <th style="width: 50px;">#</th>
                        <th>Admission No.</th>
                        <th>Student Name</th>
                        <th style="text-align: center;">Total Days</th>
                        <th style="text-align: center;">Present</th>
                        <th style="text-align: center;">Absent</th>
                        <th style="text-align: center;">Late</th>
                        <th style="width: 200px;">Attendance %</th>
                        <th style="text-align: center;">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $count = 1;
                    foreach ($attendance_data as $student): 
                        $percentage = $student['total_days'] > 0 ? ($student['present_days'] / $student['total_days']) * 100 : 0;
                        
                        if ($percentage >= 90) {
                            $status = 'Excellent';
                            $status_class = 'status-excellent';
                            $bar_class = 'percentage-excellent';
                        } elseif ($percentage >= 80) {
                            $status = 'Good';
                            $status_class = 'status-good';
                            $bar_class = 'percentage-good';
                        } elseif ($percentage >= 70) {
                            $status = 'Average';
                            $status_class = 'status-average';
                            $bar_class = 'percentage-average';
                        } else {
                            $status = 'Poor';
                            $status_class = 'status-poor';
                            $bar_class = 'percentage-poor';
                        }
                    ?>
                        <tr>
                            <td><?php echo $count++; ?></td>
                            <td><?php echo htmlspecialchars($student['admission_number']); ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></strong>
                            </td>
                            <td style="text-align: center;"><?php echo $student['total_days']; ?></td>
                            <td style="text-align: center; color: #4CAF50; font-weight: 600;"><?php echo $student['present_days']; ?></td>
                            <td style="text-align: center; color: #F44336; font-weight: 600;"><?php echo $student['absent_days']; ?></td>
                            <td style="text-align: center; color: #FF9800; font-weight: 600;"><?php echo $student['late_days']; ?></td>
                            <td>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div class="percentage-bar" style="flex: 1;">
                                        <div class="percentage-fill <?php echo $bar_class; ?>" style="width: <?php echo $percentage; ?>%;"></div>
                                    </div>
                                    <span style="font-weight: 600; min-width: 50px;"><?php echo number_format($percentage, 1); ?>%</span>
                                </div>
                            </td>
                            <td style="text-align: center;">
                                <span class="status-badge <?php echo $status_class; ?>"><?php echo $status; ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php elseif ($class_filter > 0): ?>
        <div class="card">
            <div style="padding: 60px; text-align: center;">
                <i class="fas fa-users" style="font-size: 64px; color: var(--text-secondary); opacity: 0.3; margin-bottom: 20px;"></i>
                <h3 style="color: var(--text-secondary); margin-bottom: 10px;">No Students Found</h3>
                <p style="color: var(--text-secondary);">No students found in the selected class.</p>
            </div>
        </div>
    <?php else: ?>
        <div class="card">
            <div style="padding: 60px; text-align: center;">
                <i class="fas fa-filter" style="font-size: 64px; color: var(--text-secondary); opacity: 0.3; margin-bottom: 20px;"></i>
                <h3 style="color: var(--text-secondary); margin-bottom: 10px;">Select Filters</h3>
                <p style="color: var(--text-secondary);">Please select class and month to view attendance report.</p>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
