<?php
// admin/print-terminal-report.php - Student Terminal Report
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['admin', 'teacher']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get student ID from URL
$student_id = (int)($_GET['student'] ?? 0);

if (!$student_id) {
    die('Student ID is required');
}

// Get active term
try {
    $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_active = 1");
    $stmt->execute([$school_id]);
    $active_term = $stmt->fetch();
} catch (PDOException $e) {
    try {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? AND is_current = 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    } catch (PDOException $e2) {
        $stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY start_date DESC LIMIT 1");
        $stmt->execute([$school_id]);
        $active_term = $stmt->fetch();
    }
}

if (!$active_term) {
    die('No active term found');
}

// Get student details with class and school info
$stmt = $db->prepare("
    SELECT s.*, c.class_name, sc.school_name, sc.logo, sc.address, sc.phone, sc.email, sc.motto,
           COALESCE(u.first_name, s.first_name, '-') as first_name,
           COALESCE(u.last_name, s.last_name, '') as last_name
    FROM students s
    INNER JOIN classes c ON s.class_id = c.class_id
    INNER JOIN schools sc ON s.school_id = sc.school_id
    LEFT JOIN users u ON s.user_id = u.user_id
    WHERE s.student_id = ? AND s.school_id = ?
");
$stmt->execute([$student_id, $school_id]);
$student = $stmt->fetch();

if (!$student) {
    die('Student not found');
}

// Check if this is a nursery/reception class - redirect to specialized format
$nursery_classes = [
    'CREACHE', 'NURSERY 1', 'NURSERY 1A', 'NURSERY 1B', 'NURSERY 2', 'NURSERY 2A', 'NURSERY 2B',
    'NURSERY 3', 'NURSERY 3A', 'NURSERY 3B', 'RECEPTION 1', 'RECEPTION 1A', 'RECEPTION 1B',
    'RECEPTION 2', 'RECEPTION 2A', 'RECEPTION 2B'
];

if (in_array(strtoupper($student['class_name']), $nursery_classes)) {
    // Redirect to nursery-specific format
    header('Location: ' . APP_URL . '/admin/print-nursery-terminal-report.php?student=' . $student_id);
    exit;
}

// Get results
$stmt = $db->prepare("
    SELECT 
        subj.subject_name,
        sa.ca_score,
        sa.midterm_score,
        sa.exam_score,
        sa.total_score,
        sa.grade,
        sa.remark,
        sa.position
    FROM student_assessments sa
    INNER JOIN subjects subj ON sa.subject_id = subj.subject_id
    WHERE sa.student_id = ? AND sa.term_id = ? AND sa.school_id = ?
    ORDER BY subj.subject_name
");
$stmt->execute([$student_id, $active_term['term_id'], $school_id]);
$results = $stmt->fetchAll();

// Calculate totals if missing
foreach ($results as &$result) {
    if (($result['total_score'] == 0 || $result['total_score'] === null) &&
        ($result['ca_score'] > 0 || $result['midterm_score'] > 0 || $result['exam_score'] > 0)) {
        $result['total_score'] = calculate_total_score(
            $result['ca_score'] ?? 0,
            $result['midterm_score'] ?? 0,
            $result['exam_score'] ?? 0
        );
        if (empty($result['grade']) || empty($result['remark'])) {
            $grade_info = calculate_grade_new($result['total_score']);
            $result['grade'] = $grade_info['grade'];
            $result['remark'] = $grade_info['remark'];
        }
    }
}
unset($result);

// Calculate statistics with fallback
$total_subjects = count($results);
$total_marks = 0;
foreach ($results as $result) {
    $score_total = $result['total_score'];
    if ($score_total == 0 || $score_total === null) {
        $score_total = calculate_total_score(
            $result['ca_score'] ?? 0,
            $result['midterm_score'] ?? 0,
            $result['exam_score'] ?? 0
        );
    }
    $total_marks += $score_total;
}
$overall_average = $total_subjects > 0 ? round($total_marks / $total_subjects, 2) : 0;

function getOverallGrade($avg) {
    if ($avg >= 90) return 'A+';
    if ($avg >= 80) return 'A';
    if ($avg >= 75) return 'B+';
    if ($avg >= 70) return 'B';
    if ($avg >= 65) return 'C+';
    if ($avg >= 60) return 'C';
    if ($avg >= 50) return 'D';
    return 'F';
}

$overall_grade = getOverallGrade($overall_average);

// Get attendance
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_days,
        SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_days
    FROM attendance 
    WHERE student_id = ? AND term_id = ?
");
$stmt->execute([$student_id, $active_term['term_id']]);
$attendance = $stmt->fetch();

$attendance_days = $attendance['present_days'] ?? 0;
$out_of_days = $attendance['total_days'] ?? 0;

// Calculate position (overall ranking)
$stmt = $db->prepare("
    SELECT COUNT(*) + 1 as position
    FROM (
        SELECT student_id, AVG(total_score) as avg_score
        FROM student_assessments
        WHERE term_id = ? AND class_id = ? AND school_id = ?
        GROUP BY student_id
        HAVING AVG(total_score) > ?
    ) as rankings
");
$stmt->execute([$active_term['term_id'], $student['class_id'], $school_id, $overall_average]);
$position_result = $stmt->fetch();
$overall_position = $position_result['position'] ?? 1;

// Get vacation and reopening dates
$vacation_date = isset($active_term['end_date']) ? date('d/m/Y', strtotime($active_term['end_date'])) : '';
$reopening_date = isset($active_term['next_term_start']) ? date('d/m/Y', strtotime($active_term['next_term_start'])) : '';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terminal Report - <?php echo $student['first_name'] . ' ' . $student['last_name']; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: white;
        }
        
        .report-container {
            max-width: 900px;
            margin: 0 auto;
            border: 3px solid #000;
            background: white;
        }
        
        /* Header */
        .header {
            display: grid;
            grid-template-columns: 120px 1fr 120px;
            gap: 15px;
            padding: 20px;
            border-bottom: 2px solid #000;
            align-items: center;
        }
        
        .logo {
            width: 100px;
            height: 100px;
            object-fit: contain;
        }
        
        .school-info {
            text-align: center;
        }
        
        .school-name {
            font-size: 22px;
            font-weight: bold;
            color: #1565C0;
            text-transform: uppercase;
            margin-bottom: 5px;
        }
        
        .school-motto {
            font-size: 14px;
            font-style: italic;
            color: #666;
            margin-bottom: 3px;
        }
        
        .school-location {
            font-size: 12px;
            color: #333;
        }
        
        .student-photo {
            width: 100px;
            height: 120px;
            border: 2px solid #1565C0;
            object-fit: cover;
        }
        
        .report-title {
            background: #1565C0;
            color: white;
            text-align: center;
            padding: 10px;
            font-size: 18px;
            font-weight: bold;
            letter-spacing: 2px;
        }
        
        /* Student Info */
        .student-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            padding: 15px 20px;
            gap: 10px;
            border-bottom: 2px solid #000;
        }
        
        .info-row {
            display: flex;
            gap: 10px;
            font-size: 13px;
        }
        
        .info-label {
            font-weight: bold;
            color: #1565C0;
            min-width: 120px;
        }
        
        .info-value {
            color: #333;
        }
        
        /* Results Table */
        .results-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .results-table th {
            background: #E3F2FD;
            color: #1565C0;
            font-weight: bold;
            padding: 10px 5px;
            text-align: center;
            border: 1px solid #1565C0;
            font-size: 11px;
        }
        
        .results-table td {
            padding: 8px 5px;
            text-align: center;
            border: 1px solid #1565C0;
            font-size: 12px;
        }
        
        .subject-name {
            text-align: left !important;
            font-weight: bold;
            padding-left: 10px !important;
        }
        
        .remark-cell {
            color: #1565C0;
            font-style: italic;
        }
        
        /* Grade Interpretation */
        .grade-interpretation {
            padding: 15px 20px;
            border-top: 2px solid #000;
            border-bottom: 2px solid #000;
        }
        
        .interpretation-box {
            border: 2px dashed #1565C0;
            padding: 10px;
            text-align: center;
            font-size: 12px;
            line-height: 1.6;
            color: #1565C0;
        }
        
        /* Footer Info */
        .footer-info {
            padding: 15px 20px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            border-bottom: 2px solid #000;
        }
        
        .footer-item {
            font-size: 12px;
            margin-bottom: 8px;
        }
        
        .footer-label {
            font-weight: bold;
            color: #1565C0;
            display: inline-block;
            min-width: 150px;
        }
        
        /* Signatures */
        .signatures {
            display: grid;
            grid-template-columns: 1fr 1fr;
            padding: 30px 20px 20px;
            gap: 40px;
        }
        
        .signature-block {
            text-align: center;
        }
        
        .signature-line {
            border-top: 2px solid #000;
            margin-bottom: 5px;
            padding-top: 5px;
        }
        
        .signature-title {
            font-weight: bold;
            color: #1565C0;
            font-size: 13px;
        }
        
        .print-info {
            text-align: center;
            padding: 10px;
            font-size: 10px;
            color: #999;
            font-style: italic;
        }
        
        @media print {
            body {
                padding: 0;
            }
            
            .report-container {
                border: 2px solid #000;
            }
            
            @page {
                margin: 0.5cm;
            }
        }
    </style>
</head>
<body>
    <div class="report-container">
        <!-- Header -->
        <div class="header">
            <div>
                <?php if (!empty($student['logo'])): ?>
                    <img src="<?php echo APP_URL . '/uploads/schools/' . $student['logo']; ?>" alt="School Logo" class="logo">
                <?php else: ?>
                    <div class="logo" style="border: 2px solid #1565C0; display: flex; align-items: center; justify-content: center; font-size: 40px; color: #1565C0; font-weight: bold;">
                        <?php echo strtoupper(substr($student['school_name'], 0, 1)); ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="school-info">
                <div class="school-name"><?php echo strtoupper($student['school_name']); ?></div>
                <div class="school-motto"><?php echo $student['motto'] ?? 'EQUIPPED FOR EXCELLENCE'; ?></div>
                <div class="school-location"><?php echo $student['address'] ?? ''; ?></div>
            </div>
            
            <div>
                <?php if (!empty($student['photo'])): ?>
                    <img src="<?php echo APP_URL . '/uploads/students/' . $student['photo']; ?>" alt="Student Photo" class="student-photo">
                <?php else: ?>
                    <div class="student-photo" style="display: flex; align-items: center; justify-content: center; background: #E3F2FD; color: #1565C0; font-size: 40px; font-weight: bold;">
                        <?php echo strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Report Title -->
        <div class="report-title">LEARNER'S TERMINAL REPORT</div>
        
        <!-- Student Info -->
        <div class="student-info">
            <div class="info-row">
                <span class="info-label">Learner's ID:</span>
                <span class="info-value"><?php echo $student['admission_number']; ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Roll:</span>
                <span class="info-value"><?php echo $overall_position; ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Learner's Name:</span>
                <span class="info-value"><?php echo strtoupper($student['first_name'] . ' ' . $student['last_name']); ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Class:</span>
                <span class="info-value"><?php echo $student['class_name']; ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Academic Year:</span>
                <span class="info-value"><?php echo isset($active_term['session_year']) ? $active_term['session_year'] : date('Y'); ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Term:</span>
                <span class="info-value"><?php echo $active_term['term_name']; ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Vacation Date:</span>
                <span class="info-value"><?php echo $vacation_date; ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Total Score:</span>
                <span class="info-value"><?php echo $overall_average; ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Re-Opening Date:</span>
                <span class="info-value"><?php echo $reopening_date; ?></span>
            </div>
            <div class="info-row">
                <span class="info-label">Position:</span>
                <span class="info-value"><?php echo $overall_position . getOrdinalSuffix($overall_position); ?></span>
            </div>
        </div>
        
        <!-- Results Table -->
        <table class="results-table">
            <thead>
                <tr>
                    <th rowspan="2">SUBJECTS</th>
                    <th>CLASS<br>SCORE (50%)</th>
                    <th>EXAMS<br>SCORE (50%)</th>
                    <th>TOTAL<br>SCORE (100%)</th>
                    <th rowspan="2">POSITION</th>
                    <th rowspan="2">GRADE</th>
                    <th rowspan="2">REMARKS</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($results) > 0): ?>
                    <?php foreach ($results as $result): ?>
                        <?php
                        // Calculate class score (CA + Midterm) * 0.5
                        $class_score = ($result['ca_score'] + $result['midterm_score']) * 0.5;
                        // Calculate exam score / 2
                        $exam_score = $result['exam_score'] / 2;
                        ?>
                        <tr>
                            <td class="subject-name"><?php echo $result['subject_name']; ?></td>
                            <td><?php echo number_format($class_score, 1); ?></td>
                            <td><?php echo number_format($exam_score, 1); ?></td>
                            <td><strong><?php echo number_format($result['total_score'], 1); ?></strong></td>
                            <td><?php echo $result['position'] ? $result['position'] . getOrdinalSuffix($result['position']) : '-'; ?></td>
                            <td><strong><?php echo $result['grade']; ?></strong></td>
                            <td class="remark-cell"><?php echo $result['remark']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 20px; color: #999;">No results available</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        
        <!-- Grade Interpretation -->
        <div class="grade-interpretation">
            <div class="interpretation-box">
                <strong>Interpretation of Grade:</strong> 
                100% - 80% = Highly Proficient, 68% - 79% = Proficient, 53% - 67% = Approaching Proficient, 40% - 52% = Developing, 0% - 39% = Emerging
            </div>
        </div>
        
        <!-- Footer Info -->
        <div class="footer-info">
            <div>
                <div class="footer-item">
                    <span class="footer-label">Attendance:</span>
                    <span><?php echo $attendance_days; ?></span>
                </div>
                <div class="footer-item">
                    <span class="footer-label">Conduct:</span>
                    <span>Always punctual</span>
                </div>
                <div class="footer-item">
                    <span class="footer-label">Attitude:</span>
                    <span>Hardwork</span>
                </div>
                <div class="footer-item">
                    <span class="footer-label">Interest:</span>
                    <span>Dancing</span>
                </div>
            </div>
            <div>
                <div class="footer-item">
                    <span class="footer-label">Out of:</span>
                    <span><?php echo $out_of_days; ?></span>
                </div>
                <div class="footer-item">
                    <span class="footer-label">Promoted To:</span>
                    <span>----------</span>
                </div>
                <div class="footer-item">
                    <span class="footer-label">Class Teacher's Remark:</span>
                    <span>Below average, must buck up!</span>
                </div>
                <div class="footer-item">
                    <span class="footer-label">Head Teacher's Remark:</span>
                    <span>You must work hard, there is need for parental support!</span>
                </div>
            </div>
        </div>
        
        <!-- Signatures -->
        <div class="signatures">
            <div class="signature-block">
                <div class="signature-line">_________________________</div>
                <div class="signature-title">Head Teacher</div>
            </div>
            <div class="signature-block">
                <div class="signature-line">_________________________</div>
                <div class="signature-title">Class Teacher</div>
            </div>
        </div>
        
        <!-- Print Info -->
        <div class="print-info">
            Printed On: <?php echo date('d/m/Y'); ?>
        </div>
    </div>
    
    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>

<?php
function getOrdinalSuffix($number) {
    $ends = array('th','st','nd','rd','th','th','th','th','th','th');
    if ((($number % 100) >= 11) && (($number % 100) <= 13))
        return 'th';
    else
        return $ends[$number % 10];
}
?>
