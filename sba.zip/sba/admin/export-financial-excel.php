<?php
// admin/export-financial-excel.php - Export Financial Reports to Excel
require_once '../config.php';

// Check authentication and permissions
$user = check_permission(['admin', 'proprietor', 'accountant']);
$school_id = $user['school_id'];

// Get filter parameters
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-d');
$type = $_GET['type'] ?? 'all';

// Get database connection
$db = Database::getInstance()->getConnection();

// Build query based on filters
$where_conditions = ["p.school_id = ?"];
$params = [$school_id];

if (!empty($start_date)) {
    $where_conditions[] = "p.payment_date >= ?";
    $params[] = $start_date;
}

if (!empty($end_date)) {
    $where_conditions[] = "p.payment_date <= ?";
    $params[] = $end_date;
}

if ($type !== 'all') {
    $where_conditions[] = "p.payment_method = ?";
    $params[] = $type;
}

$where_clause = implode(' AND ', $where_conditions);

// Fetch payment data
$query = "
    SELECT 
        p.payment_id,
        p.payment_reference,
        p.payment_date,
        CONCAT(s.first_name, ' ', s.last_name) as student_name,
        s.admission_number,
        c.class_name,
        p.amount,
        p.payment_method,
        p.payment_status,
        p.received_by,
        p.remarks,
        fs.fee_type,
        t.term_name,
        ay.year_name
    FROM payments p
    LEFT JOIN students s ON p.student_id = s.student_id
    LEFT JOIN classes c ON s.class_id = c.class_id
    LEFT JOIN fee_structure fs ON p.fee_structure_id = fs.fee_structure_id
    LEFT JOIN terms t ON p.term_id = t.term_id
    LEFT JOIN academic_years ay ON t.year_id = ay.year_id
    WHERE {$where_clause}
    ORDER BY p.payment_date DESC, p.payment_id DESC
";

$stmt = $db->prepare($query);
$stmt->execute($params);
$payments = $stmt->fetchAll();

// Calculate totals
$total_revenue = array_sum(array_column($payments, 'amount'));
$total_transactions = count($payments);

// Set headers for Excel download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="financial_report_' . date('Y-m-d_His') . '.xls"');
header('Cache-Control: max-age=0');

// Start output buffering
ob_start();

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #000; padding: 8px; text-align: left; }
        th { background-color: #4CAF50; color: white; font-weight: bold; }
        .total-row { background-color: #f0f0f0; font-weight: bold; }
        .header { font-size: 18px; font-weight: bold; margin-bottom: 20px; }
        .info { margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="header">Financial Report - School Management System</div>
    
    <div class="info">
        <p><strong>School:</strong> <?php echo htmlspecialchars($user['school_name'] ?? 'N/A'); ?></p>
        <p><strong>Report Date:</strong> <?php echo date('F j, Y g:i A'); ?></p>
        <p><strong>Period:</strong> <?php echo date('M j, Y', strtotime($start_date)); ?> to <?php echo date('M j, Y', strtotime($end_date)); ?></p>
        <p><strong>Payment Type:</strong> <?php echo ucfirst($type); ?></p>
        <p><strong>Total Transactions:</strong> <?php echo number_format($total_transactions); ?></p>
        <p><strong>Total Revenue:</strong> GH₵ <?php echo number_format($total_revenue, 2); ?></p>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Reference</th>
                <th>Student Name</th>
                <th>Admission No.</th>
                <th>Class</th>
                <th>Fee Type</th>
                <th>Term</th>
                <th>Academic Year</th>
                <th>Amount (₵)</th>
                <th>Payment Method</th>
                <th>Status</th>
                <th>Received By</th>
                <th>Remarks</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($payments)): ?>
                <tr>
                    <td colspan="13" style="text-align: center;">No transactions found for the selected period</td>
                </tr>
            <?php else: ?>
                <?php foreach ($payments as $payment): ?>
                    <tr>
                        <td><?php echo date('M j, Y', strtotime($payment['payment_date'])); ?></td>
                        <td><?php echo htmlspecialchars($payment['payment_reference']); ?></td>
                        <td><?php echo htmlspecialchars($payment['student_name']); ?></td>
                        <td><?php echo htmlspecialchars($payment['admission_number']); ?></td>
                        <td><?php echo htmlspecialchars($payment['class_name']); ?></td>
                        <td><?php echo htmlspecialchars($payment['fee_type']); ?></td>
                        <td><?php echo htmlspecialchars($payment['term_name']); ?></td>
                        <td><?php echo htmlspecialchars($payment['year_name']); ?></td>
                        <td><?php echo number_format($payment['amount'], 2); ?></td>
                        <td><?php echo ucfirst($payment['payment_method']); ?></td>
                        <td><?php echo ucfirst($payment['payment_status']); ?></td>
                        <td><?php echo htmlspecialchars($payment['received_by'] ?? 'System'); ?></td>
                        <td><?php echo htmlspecialchars($payment['remarks'] ?? '-'); ?></td>
                    </tr>
                <?php endforeach; ?>
                
                <!-- Total Row -->
                <tr class="total-row">
                    <td colspan="8" style="text-align: right;"><strong>TOTAL:</strong></td>
                    <td><strong><?php echo number_format($total_revenue, 2); ?></strong></td>
                    <td colspan="4"></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <div style="margin-top: 20px; font-size: 12px; color: #666;">
        <p>Generated by School Management System v1.9.0</p>
        <p>This report is computer-generated and requires no signature.</p>
    </div>
</body>
</html>

<?php
// Get the buffer content and clean
$content = ob_get_clean();
echo $content;
exit;
?>
