<?php
// includes/ajax/get-notifications.php - Fetch notifications for current user
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/NotificationManager.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit;
}

$user_id = $_SESSION['user_id'];
$school_id = $_SESSION['school_id'];
$role = $_SESSION['role'];

$action = $_GET['action'] ?? 'get_unread';

$notificationManager = new NotificationManager($school_id);

switch ($action) {
    case 'get_unread':
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $notifications = $notificationManager->getUnread($user_id, $role, $limit);
        $count = $notificationManager->getUnreadCount($user_id, $role);
        
        echo json_encode([
            'success' => true,
            'notifications' => $notifications,
            'unread_count' => $count,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
        break;
        
    case 'get_count':
        $count = $notificationManager->getUnreadCount($user_id, $role);
        echo json_encode([
            'success' => true,
            'count' => $count
        ]);
        break;
        
    case 'mark_read':
        if (!isset($_POST['notification_id'])) {
            echo json_encode(['success' => false, 'error' => 'Missing notification_id']);
            exit;
        }
        
        $result = $notificationManager->markAsRead((int)$_POST['notification_id']);
        echo json_encode([
            'success' => $result,
            'message' => $result ? 'Marked as read' : 'Failed to mark as read'
        ]);
        break;
        
    case 'mark_all_read':
        $result = $notificationManager->markAllAsRead($user_id, $role);
        echo json_encode([
            'success' => $result,
            'message' => $result ? 'All notifications marked as read' : 'Failed'
        ]);
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}
?>
