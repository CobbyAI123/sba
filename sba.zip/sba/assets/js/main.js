/**
 * School Management System - Main JavaScript
 * Common functions and utilities
 */

// Initialize theme on page load
document.addEventListener('DOMContentLoaded', function() {
    // Apply saved theme
    const savedTheme = localStorage.getItem('theme') || 'dark';
    document.body.setAttribute('data-theme', savedTheme);
    document.documentElement.setAttribute('data-theme', savedTheme);
    
    // Initialize theme toggle
    initThemeToggle();
    
    // Load notifications if on dashboard
    if (document.getElementById('notificationList')) {
        loadNotifications();
    }
});

// Initialize Theme Toggle
function initThemeToggle() {
    const themeToggle = document.getElementById('themeToggle');
    if (!themeToggle) return;
    
    // Set initial icon
    const savedTheme = localStorage.getItem('theme') || 'dark';
    updateThemeIcon(savedTheme);
    
    // Remove any existing listeners
    const newToggle = themeToggle.cloneNode(true);
    themeToggle.parentNode.replaceChild(newToggle, themeToggle);
    
    // Add click event
    newToggle.addEventListener('click', function() {
        const currentTheme = document.body.getAttribute('data-theme') || 'dark';
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        document.body.setAttribute('data-theme', newTheme);
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateThemeIcon(newTheme);
        
        console.log('Theme changed to:', newTheme);
    });
}

function updateThemeIcon(theme) {
    const themeToggle = document.getElementById('themeToggle');
    if (!themeToggle) return;
    
    const icon = themeToggle.querySelector('i');
    if (!icon) return;
    
    if (theme === 'dark') {
        icon.className = 'fas fa-sun';
        themeToggle.title = 'Switch to Light Mode';
    } else {
        icon.className = 'fas fa-moon';
        themeToggle.title = 'Switch to Dark Mode';
    }
}

// Toggle Sidebar (Mobile)
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}

// Toggle Notifications Dropdown
function toggleNotifications() {
    const dropdown = document.getElementById('notificationDropdown');
    const userMenu = document.getElementById('userMenuDropdown');
    
    if (userMenu) userMenu.style.display = 'none';
    
    if (dropdown.style.display === 'none' || dropdown.style.display === '') {
        dropdown.style.display = 'block';
        loadNotifications();
    } else {
        dropdown.style.display = 'none';
    }
}

// Toggle User Menu Dropdown
function toggleUserMenu() {
    const dropdown = document.getElementById('userMenuDropdown');
    const notifDropdown = document.getElementById('notificationDropdown');
    
    if (notifDropdown) notifDropdown.style.display = 'none';
    
    if (dropdown.style.display === 'none' || dropdown.style.display === '') {
        dropdown.style.display = 'block';
    } else {
        dropdown.style.display = 'none';
    }
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    const notifDropdown = document.getElementById('notificationDropdown');
    const userMenu = document.getElementById('userMenuDropdown');
    
    if (!event.target.closest('.header-icon') && !event.target.closest('#notificationDropdown')) {
        if (notifDropdown) notifDropdown.style.display = 'none';
    }
    
    if (!event.target.closest('.user-profile') && !event.target.closest('#userMenuDropdown')) {
        if (userMenu) userMenu.style.display = 'none';
    }
});

// Load Notifications via AJAX
function loadNotifications() {
    // Notifications disabled for now to prevent errors
    console.log('Notifications feature temporarily disabled');
    return;
    
    /*
    fetch('/msms/ajax/get-notifications.php')
        .then(response => response.json())
        .then(data => {
            const notificationList = document.getElementById('notificationList');
            if (!notificationList) return;
            
            if (data.success && data.notifications.length > 0) {
                let html = '';
                data.notifications.forEach(notif => {
                    const iconClass = getNotificationIcon(notif.type);
                    const timeAgo = formatTimeAgo(notif.created_at);
                    
                    html += `
                        <div class="notification-item ${notif.is_read ? '' : 'unread'}" 
                             onclick="markAsRead(${notif.notification_id})" 
                             style="padding: 15px; border-bottom: 1px solid var(--border-color); cursor: pointer; ${notif.is_read ? '' : 'background: rgba(45, 91, 255, 0.05);'}">
                            <div style="display: flex; gap: 12px;">
                                <div style="width: 40px; height: 40px; background: rgba(45, 91, 255, 0.1); border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                                    <i class="fas ${iconClass}" style="color: var(--primary-blue);"></i>
                                </div>
                                <div style="flex: 1;">
                                    <h5 style="font-size: 14px; margin-bottom: 5px;">${notif.title}</h5>
                                    <p style="font-size: 12px; color: var(--text-secondary); margin-bottom: 5px;">${notif.message}</p>
                                    <span style="font-size: 11px; color: var(--text-secondary);">${timeAgo}</span>
                                </div>
                            </div>
                        </div>
                    `;
                });
                notificationList.innerHTML = html;
            } else {
                notificationList.innerHTML = '<div style="padding: 30px; text-align: center; color: var(--text-secondary);">No notifications</div>';
            }
        })
        .catch(error => {
            console.error('Error loading notifications:', error);
        });
    */
}

// Mark notification as read
function markAsRead(notificationId) {
    fetch('/msms/ajax/mark-notification-read.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ notification_id: notificationId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadNotifications();
            updateNotificationBadge();
        }
    });
}

// Mark all notifications as read
function markAllAsRead() {
    fetch('/msms/ajax/mark-all-notifications-read.php', {
        method: 'POST'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadNotifications();
            updateNotificationBadge();
        }
    });
}

// Update notification badge count
function updateNotificationBadge() {
    fetch('/msms/ajax/get-notification-count.php')
        .then(response => response.json())
        .then(data => {
            const badge = document.querySelector('.notification-badge');
            if (data.count > 0) {
                if (badge) {
                    badge.textContent = data.count;
                } else {
                    const headerIcon = document.querySelector('.header-icon .fa-bell').parentElement;
                    headerIcon.innerHTML += `<span class="notification-badge">${data.count}</span>`;
                }
            } else {
                if (badge) badge.remove();
            }
        });
}

// Get notification icon based on type
function getNotificationIcon(type) {
    const icons = {
        'info': 'fa-info-circle',
        'success': 'fa-check-circle',
        'warning': 'fa-exclamation-triangle',
        'error': 'fa-exclamation-circle'
    };
    return icons[type] || 'fa-bell';
}

// Format time ago
function formatTimeAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);
    
    const intervals = {
        year: 31536000,
        month: 2592000,
        week: 604800,
        day: 86400,
        hour: 3600,
        minute: 60
    };
    
    for (const [unit, secondsInUnit] of Object.entries(intervals)) {
        const interval = Math.floor(seconds / secondsInUnit);
        if (interval >= 1) {
            return interval === 1 ? `1 ${unit} ago` : `${interval} ${unit}s ago`;
        }
    }
    
    return 'Just now';
}

// Confirm Delete
function confirmDelete(message = 'Are you sure you want to delete this item?') {
    return confirm(message);
}

// Show Loading Spinner
function showLoading() {
    const loader = document.createElement('div');
    loader.id = 'globalLoader';
    loader.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 9999;';
    loader.innerHTML = '<div class="spinner"></div>';
    document.body.appendChild(loader);
}

// Hide Loading Spinner
function hideLoading() {
    const loader = document.getElementById('globalLoader');
    if (loader) loader.remove();
}

// Format Currency
function formatCurrency(amount, currency = 'NGN') {
    const symbols = {
        'NGN': '₦',
        'USD': '$',
        'GBP': '£',
        'EUR': '€'
    };
    const symbol = symbols[currency] || currency;
    return symbol + parseFloat(amount).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}

// Validate Email
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Validate Phone
function validatePhone(phone) {
    const re = /^[\d\s\-\+\(\)]+$/;
    return re.test(phone) && phone.replace(/\D/g, '').length >= 10;
}

// Form Validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;
    
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.style.borderColor = 'var(--danger-red)';
            isValid = false;
        } else {
            input.style.borderColor = 'var(--border-color)';
        }
        
        // Email validation
        if (input.type === 'email' && input.value && !validateEmail(input.value)) {
            input.style.borderColor = 'var(--danger-red)';
            isValid = false;
        }
        
        // Phone validation
        if (input.type === 'tel' && input.value && !validatePhone(input.value)) {
            input.style.borderColor = 'var(--danger-red)';
            isValid = false;
        }
    });
    
    return isValid;
}

// Print Page
function printPage() {
    window.print();
}

// Export to CSV
function exportTableToCSV(tableId, filename = 'export.csv') {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    let csv = [];
    const rows = table.querySelectorAll('tr');
    
    rows.forEach(row => {
        const cols = row.querySelectorAll('td, th');
        const csvRow = [];
        cols.forEach(col => {
            csvRow.push('"' + col.textContent.trim().replace(/"/g, '""') + '"');
        });
        csv.push(csvRow.join(','));
    });
    
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

// Global Search
const globalSearch = document.getElementById('globalSearch');
if (globalSearch) {
    globalSearch.addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        // Implement search functionality based on current page
        console.log('Searching for:', searchTerm);
    });
}

// Auto-hide alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});
