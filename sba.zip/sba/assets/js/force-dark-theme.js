/**
 * Force Dark Theme - Immediate Application
 * This script applies dark theme styles immediately on page load
 */

(function() {
    'use strict';
    
    // Apply dark theme immediately to prevent flash
    const darkStyles = `
        body, html {
            background: #1a1d29 !important;
            color: #e4e7eb !important;
        }
        .dashboard-wrapper {
            background: #1a1d29 !important;
        }
        .sidebar, aside.sidebar {
            background: #1e2230 !important;
            border-right: 1px solid #2d3340 !important;
        }
        .main-content {
            background: #1a1d29 !important;
        }
        .content-wrapper {
            background: #1a1d29 !important;
        }
        .header {
            background: #1a1d29 !important;
            border-bottom: 1px solid #2d3340 !important;
        }
        .card {
            background: #252936 !important;
            border: 1px solid #2d3340 !important;
            color: #e4e7eb !important;
        }
        .stat-card {
            background: #2a2f3d !important;
            border: 1px solid #3d4555 !important;
            color: #e4e7eb !important;
        }
        table {
            color: #e4e7eb !important;
        }
        th {
            background: #232734 !important;
            color: #9ca3af !important;
        }
        td {
            color: #e4e7eb !important;
            border-bottom: 1px solid #2d3340 !important;
        }
        .form-control, input, select, textarea {
            background: #232734 !important;
            border: 1px solid #2d3340 !important;
            color: #e4e7eb !important;
        }
        .menu-item {
            color: #9ca3af !important;
        }
        .menu-item:hover {
            background: #2d3340 !important;
            color: #e4e7eb !important;
        }
        .menu-item.active {
            background: #4d7cfe !important;
            color: white !important;
        }
        h1, h2, h3, h4, h5, h6 {
            color: #e4e7eb !important;
        }
        p {
            color: #9ca3af !important;
        }
    `;
    
    // Create and inject style element
    const styleElement = document.createElement('style');
    styleElement.id = 'force-dark-theme';
    styleElement.innerHTML = darkStyles;
    
    // Insert at the beginning of head to ensure it loads first
    if (document.head) {
        document.head.insertBefore(styleElement, document.head.firstChild);
    } else {
        document.addEventListener('DOMContentLoaded', function() {
            document.head.insertBefore(styleElement, document.head.firstChild);
        });
    }
    
    // Set data-theme attribute
    document.documentElement.setAttribute('data-theme', 'dark');
    
    // Apply dark theme to body when DOM is ready
    if (document.body) {
        applyDarkTheme();
    } else {
        document.addEventListener('DOMContentLoaded', applyDarkTheme);
    }
    
    function applyDarkTheme() {
        document.body.classList.add('dark-theme');
        document.body.style.background = '#1a1d29';
        document.body.style.color = '#e4e7eb';
    }
    
    // Re-apply on window load to ensure everything is dark
    window.addEventListener('load', function() {
        applyDarkTheme();
        
        // Force update all elements
        setTimeout(function() {
            const elements = {
                '.sidebar': { background: '#1e2230' },
                '.main-content': { background: '#1a1d29' },
                '.header': { background: '#1a1d29' },
                '.card': { background: '#252936' },
                '.stat-card': { background: '#2a2f3d' }
            };
            
            for (const [selector, styles] of Object.entries(elements)) {
                const els = document.querySelectorAll(selector);
                els.forEach(el => {
                    for (const [prop, value] of Object.entries(styles)) {
                        el.style[prop] = value;
                    }
                });
            }
        }, 100);
    });
})();
