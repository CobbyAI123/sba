/**
 * Enhanced Responsive System - Device Auto-Detection
 * Automatically detects device type and applies appropriate classes
 * Prevents text overlapping and optimizes layout
 * Version: 2.0
 */

(function() {
    'use strict';

    const ResponsiveDetector = {
        // Device detection
        device: {
            isMobile: false,
            isTablet: false,
            isDesktop: false,
            isAndroid: false,
            isIOS: false,
            isTouch: false,
            orientation: 'portrait',
            screenSize: 'desktop',
            pixelRatio: window.devicePixelRatio || 1
        },

        /**
         * Initialize responsive detection
         */
        init: function() {
            this.detectDevice();
            this.applyDeviceClasses();
            this.setupListeners();
            this.enhanceTables();
            this.optimizeImages();
            this.preventTextOverflow();
            
            console.log('✅ Responsive System Initialized:', this.device);
        },

        /**
         * Detect device type and characteristics
         */
        detectDevice: function() {
            const ua = navigator.userAgent.toLowerCase();
            const width = window.innerWidth;
            const height = window.innerHeight;

            // Detect mobile/tablet/desktop
            this.device.isMobile = /mobile|android|iphone|ipod|blackberry|windows phone/i.test(ua) || width < 768;
            this.device.isTablet = /tablet|ipad|playbook|silk/i.test(ua) || (width >= 768 && width < 992);
            this.device.isDesktop = !this.device.isMobile && !this.device.isTablet;

            // Detect OS
            this.device.isAndroid = /android/i.test(ua);
            this.device.isIOS = /iphone|ipad|ipod/i.test(ua);

            // Detect touch capability
            this.device.isTouch = ('ontouchstart' in window) || 
                                  (navigator.maxTouchPoints > 0) || 
                                  (navigator.msMaxTouchPoints > 0);

            // Detect orientation
            this.device.orientation = (height > width) ? 'portrait' : 'landscape';

            // Determine screen size category
            if (width < 576) {
                this.device.screenSize = 'xs'; // Extra small mobile
            } else if (width < 768) {
                this.device.screenSize = 'sm'; // Small mobile
            } else if (width < 992) {
                this.device.screenSize = 'md'; // Tablet
            } else if (width < 1200) {
                this.device.screenSize = 'lg'; // Laptop
            } else if (width < 1920) {
                this.device.screenSize = 'xl'; // Desktop
            } else {
                this.device.screenSize = 'xxl'; // Large desktop
            }

            // Store in session for server-side detection (optional)
            if (typeof sessionStorage !== 'undefined') {
                sessionStorage.setItem('deviceType', JSON.stringify(this.device));
            }
        },

        /**
         * Apply device-specific classes to body
         */
        applyDeviceClasses: function() {
            const body = document.body;
            
            // Remove old classes
            body.classList.remove('mobile', 'tablet', 'desktop', 'android', 'ios', 
                                'touch', 'no-touch', 'portrait', 'landscape',
                                'screen-xs', 'screen-sm', 'screen-md', 'screen-lg', 'screen-xl', 'screen-xxl');

            // Add device type classes
            if (this.device.isMobile) body.classList.add('mobile');
            if (this.device.isTablet) body.classList.add('tablet');
            if (this.device.isDesktop) body.classList.add('desktop');
            if (this.device.isAndroid) body.classList.add('android');
            if (this.device.isIOS) body.classList.add('ios');
            
            // Add touch/no-touch class
            body.classList.add(this.device.isTouch ? 'touch' : 'no-touch');
            
            // Add orientation class
            body.classList.add(this.device.orientation);
            
            // Add screen size class
            body.classList.add('screen-' + this.device.screenSize);

            // Add pixel ratio class for high DPI displays
            if (this.device.pixelRatio >= 2) {
                body.classList.add('high-dpi');
            }
        },

        /**
         * Setup event listeners for responsive changes
         */
        setupListeners: function() {
            let resizeTimer;

            // Handle window resize
            window.addEventListener('resize', () => {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(() => {
                    this.detectDevice();
                    this.applyDeviceClasses();
                    this.enhanceTables();
                    this.preventTextOverflow();
                }, 250); // Debounce resize events
            });

            // Handle orientation change
            window.addEventListener('orientationchange', () => {
                setTimeout(() => {
                    this.detectDevice();
                    this.applyDeviceClasses();
                    this.enhanceTables();
                }, 200);
            });

            // Monitor viewport changes
            if ('visualViewport' in window) {
                window.visualViewport.addEventListener('resize', () => {
                    this.detectDevice();
                });
            }
        },

        /**
         * Enhance tables for mobile viewing
         */
        enhanceTables: function() {
            if (!this.device.isMobile) return;

            const tables = document.querySelectorAll('table:not(.enhanced)');
            
            tables.forEach(table => {
                // Add responsive wrapper if not exists
                if (!table.parentElement.classList.contains('table-responsive')) {
                    const wrapper = document.createElement('div');
                    wrapper.className = 'table-responsive table-mobile-stack';
                    table.parentNode.insertBefore(wrapper, table);
                    wrapper.appendChild(table);
                }

                // Add data-label attributes for mobile stacking
                const headers = table.querySelectorAll('thead th');
                const rows = table.querySelectorAll('tbody tr');

                rows.forEach(row => {
                    const cells = row.querySelectorAll('td');
                    cells.forEach((cell, index) => {
                        if (headers[index]) {
                            cell.setAttribute('data-label', headers[index].textContent);
                        }
                    });
                });

                table.classList.add('enhanced');
            });
        },

        /**
         * Prevent text overflow in all containers
         */
        preventTextOverflow: function() {
            // Add text-safe class to stat cards
            const statCards = document.querySelectorAll('.stat-card h3, .stat-card .value, .card-title');
            statCards.forEach(el => {
                if (!el.classList.contains('text-safe')) {
                    el.classList.add('text-safe');
                }
            });

            // Ensure all table cells have overflow protection
            const tableCells = document.querySelectorAll('table td, table th');
            tableCells.forEach(cell => {
                if (!cell.classList.contains('text-safe')) {
                    cell.classList.add('text-safe');
                }
            });

            // Monitor for dynamically added content
            if (typeof MutationObserver !== 'undefined') {
                const observer = new MutationObserver((mutations) => {
                    mutations.forEach((mutation) => {
                        if (mutation.addedNodes.length) {
                            this.preventTextOverflow();
                        }
                    });
                });

                observer.observe(document.body, {
                    childList: true,
                    subtree: true
                });
            }
        },

        /**
         * Optimize images for device
         */
        optimizeImages: function() {
            const images = document.querySelectorAll('img[data-src-mobile], img[data-src-tablet], img[data-src-desktop]');
            
            images.forEach(img => {
                let src;
                
                if (this.device.isMobile && img.dataset.srcMobile) {
                    src = img.dataset.srcMobile;
                } else if (this.device.isTablet && img.dataset.srcTablet) {
                    src = img.dataset.srcTablet;
                } else if (img.dataset.srcDesktop) {
                    src = img.dataset.srcDesktop;
                }

                if (src && img.src !== src) {
                    img.src = src;
                }
            });
        },

        /**
         * Get current device info (for debugging)
         */
        getDeviceInfo: function() {
            return {
                ...this.device,
                viewport: {
                    width: window.innerWidth,
                    height: window.innerHeight
                },
                userAgent: navigator.userAgent
            };
        },

        /**
         * Force specific layout mode (for testing)
         */
        setTestMode: function(mode) {
            const body = document.body;
            body.classList.remove('mobile', 'tablet', 'desktop');
            body.classList.add(mode);
            console.log('🧪 Test mode activated:', mode);
        }
    };

    /**
     * Enhanced Grid System Helper
     */
    const GridHelper = {
        /**
         * Auto-adjust grid columns based on content
         */
        autoAdjustGrids: function() {
            const grids = document.querySelectorAll('[class*="grid-"], .stats-grid');
            
            grids.forEach(grid => {
                const items = grid.children.length;
                const width = grid.offsetWidth;
                
                // Calculate optimal column count
                let cols = 4;
                if (width < 576) cols = 1;
                else if (width < 768) cols = 2;
                else if (width < 992) cols = 3;
                else if (items < 4) cols = items;
                
                grid.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
            });
        }
    };

    /**
     * Touch Optimization
     */
    const TouchOptimizer = {
        init: function() {
            if (!ResponsiveDetector.device.isTouch) return;

            // Make all clickable elements touch-friendly
            const clickables = document.querySelectorAll('a, button, .btn, .clickable');
            clickables.forEach(el => {
                if (!el.style.minHeight) {
                    el.style.minHeight = '44px';
                }
                if (!el.style.minWidth) {
                    el.style.minWidth = '44px';
                }
            });

            // Add touch event optimization
            document.addEventListener('touchstart', function() {}, { passive: true });
            document.addEventListener('touchmove', function() {}, { passive: true });
        }
    };

    /**
     * Viewport Meta Helper
     */
    const ViewportHelper = {
        /**
         * Ensure proper viewport meta tag
         */
        checkViewportMeta: function() {
            let viewport = document.querySelector('meta[name="viewport"]');
            
            if (!viewport) {
                viewport = document.createElement('meta');
                viewport.name = 'viewport';
                viewport.content = 'width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes';
                document.head.appendChild(viewport);
                console.log('✅ Viewport meta tag added');
            }
        }
    };

    /**
     * Initialize everything when DOM is ready
     */
    function initializeResponsiveSystem() {
        ResponsiveDetector.init();
        TouchOptimizer.init();
        ViewportHelper.checkViewportMeta();
        GridHelper.autoAdjustGrids();

        // Re-adjust grids on content changes
        window.addEventListener('load', () => {
            GridHelper.autoAdjustGrids();
        });

        // Make ResponsiveDetector globally accessible
        window.ResponsiveDetector = ResponsiveDetector;
        window.GridHelper = GridHelper;
    }

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeResponsiveSystem);
    } else {
        initializeResponsiveSystem();
    }

    // Log device info in console (for debugging)
    console.log('%c📱 Responsive System Loaded', 'color: #2D5BFF; font-weight: bold; font-size: 14px;');
    console.log('Device Info:', ResponsiveDetector.device);
    console.log('Use ResponsiveDetector.getDeviceInfo() for full details');

})();
