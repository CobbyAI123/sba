-- ============================================================================
-- FEE PAYMENTS TABLE - Automatic Student Billing System
-- ============================================================================

CREATE TABLE IF NOT EXISTS `fee_payments` (
    `fee_payment_id` INT AUTO_INCREMENT PRIMARY KEY,
    `school_id` INT NOT NULL,
    `student_id` INT NOT NULL,
    `term_id` INT,
    `fee_type` VARCHAR(100) NOT NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    `status` ENUM('pending', 'partially_paid', 'paid', 'cancelled', 'waived') DEFAULT 'pending',
    `due_date` DATE,
    `paid_date` DATE NULL,
    `paid_amount` DECIMAL(10, 2) DEFAULT 0,
    `payment_method` VARCHAR(50),
    `payment_reference` VARCHAR(100),
    `notes` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
    FOREIGN KEY (`term_id`) REFERENCES `terms`(`term_id`) ON DELETE SET NULL,
    INDEX `idx_school` (`school_id`),
    INDEX `idx_student` (`student_id`),
    INDEX `idx_term` (`term_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_due_date` (`due_date`),
    INDEX `idx_fee_type` (`fee_type`),
    INDEX `idx_student_term` (`student_id`, `term_id`),
    UNIQUE KEY `unique_fee_per_student` (`student_id`, `term_id`, `fee_type`, `school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Add columns to fee_structure if they don't exist
ALTER TABLE `fee_structure` ADD COLUMN IF NOT EXISTS `status` ENUM('active', 'inactive') DEFAULT 'active';
ALTER TABLE `fee_structure` ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE `fee_structure` ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT '✓ Fee payments table created successfully' as Status;
SELECT '✓ Fee structure table enhanced' as Status;

-- ============================================================================
-- SAMPLE DATA (Optional - for testing)
-- ============================================================================

-- View all student fees for current term
-- SELECT 
--     s.student_id,
--     CONCAT(u.first_name, ' ', u.last_name) as student_name,
--     c.class_name,
--     fp.fee_type,
--     fp.amount,
--     fp.paid_amount,
--     fp.status,
--     fp.due_date
-- FROM fee_payments fp
-- INNER JOIN students s ON fp.student_id = s.student_id
-- INNER JOIN users u ON s.user_id = u.user_id
-- LEFT JOIN classes c ON s.class_id = c.class_id
-- WHERE fp.status = 'pending'
-- ORDER BY fp.due_date;
