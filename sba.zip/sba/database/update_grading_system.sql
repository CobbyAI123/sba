-- Update Grading System with New Formula
-- CA = 60 marks, Midterm = 40 marks, Exam = 100 marks
-- Total = ((CA + Midterm) * 0.5) + (Exam / 2)
-- Maximum Total = 100 marks

-- Step 1: Add position column if it doesn't exist
ALTER TABLE student_assessments 
ADD COLUMN IF NOT EXISTS position INT NULL AFTER remark;

-- Step 2: Update max scores (only update existing columns)
UPDATE student_assessments 
SET ca_max = 60, 
    midterm_max = 40, 
    exam_max = 100
WHERE ca_max IS NULL OR ca_max != 60;

-- Step 3: Drop existing triggers
DROP TRIGGER IF EXISTS calculate_scores_before_insert;
DROP TRIGGER IF EXISTS calculate_scores_before_update;

-- Step 4: Create new triggers with updated formula
DELIMITER $$

CREATE TRIGGER calculate_scores_before_insert
BEFORE INSERT ON student_assessments
FOR EACH ROW
BEGIN
    -- Set max scores
    SET NEW.ca_max = 60;
    SET NEW.midterm_max = 40;
    SET NEW.exam_max = 100;
    
    -- Calculate total score using new formula
    -- Total = ((CA + Midterm) * 0.5) + (Exam / 2)
    SET NEW.total_score = (
        (COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5
    ) + (COALESCE(NEW.exam_score, 0) / 2);
    
    -- Round to 2 decimal places
    SET NEW.total_score = ROUND(NEW.total_score, 2);
    
    -- Calculate grade based on total (out of 100)
    SET NEW.grade = CASE
        WHEN NEW.total_score >= 90 THEN 'A+'
        WHEN NEW.total_score >= 80 THEN 'A'
        WHEN NEW.total_score >= 75 THEN 'B+'
        WHEN NEW.total_score >= 70 THEN 'B'
        WHEN NEW.total_score >= 65 THEN 'C+'
        WHEN NEW.total_score >= 60 THEN 'C'
        WHEN NEW.total_score >= 50 THEN 'D'
        ELSE 'F'
    END;
    
    -- Calculate remark based on total
    SET NEW.remark = CASE
        WHEN NEW.total_score >= 80 THEN 'Excellent'
        WHEN NEW.total_score >= 70 THEN 'Very Good'
        WHEN NEW.total_score >= 60 THEN 'Good'
        WHEN NEW.total_score >= 50 THEN 'Fair'
        ELSE 'Fail'
    END;
END$$

CREATE TRIGGER calculate_scores_before_update
BEFORE UPDATE ON student_assessments
FOR EACH ROW
BEGIN
    -- Set max scores
    SET NEW.ca_max = 60;
    SET NEW.midterm_max = 40;
    SET NEW.exam_max = 100;
    
    -- Calculate total score using new formula
    -- Total = ((CA + Midterm) * 0.5) + (Exam / 2)
    SET NEW.total_score = (
        (COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5
    ) + (COALESCE(NEW.exam_score, 0) / 2);
    
    -- Round to 2 decimal places
    SET NEW.total_score = ROUND(NEW.total_score, 2);
    
    -- Calculate grade based on total (out of 100)
    SET NEW.grade = CASE
        WHEN NEW.total_score >= 90 THEN 'A+'
        WHEN NEW.total_score >= 80 THEN 'A'
        WHEN NEW.total_score >= 75 THEN 'B+'
        WHEN NEW.total_score >= 70 THEN 'B'
        WHEN NEW.total_score >= 65 THEN 'C+'
        WHEN NEW.total_score >= 60 THEN 'C'
        WHEN NEW.total_score >= 50 THEN 'D'
        ELSE 'F'
    END;
    
    -- Calculate remark based on total
    SET NEW.remark = CASE
        WHEN NEW.total_score >= 80 THEN 'Excellent'
        WHEN NEW.total_score >= 70 THEN 'Very Good'
        WHEN NEW.total_score >= 60 THEN 'Good'
        WHEN NEW.total_score >= 50 THEN 'Fair'
        ELSE 'Fail'
    END;
END$$

DELIMITER ;

-- Step 5: Recalculate existing scores
UPDATE student_assessments
SET total_score = (
    (COALESCE(ca_score, 0) + COALESCE(midterm_score, 0)) * 0.5
) + (COALESCE(exam_score, 0) / 2);

UPDATE student_assessments
SET total_score = ROUND(total_score, 2);

UPDATE student_assessments
SET grade = CASE
    WHEN total_score >= 90 THEN 'A+'
    WHEN total_score >= 80 THEN 'A'
    WHEN total_score >= 75 THEN 'B+'
    WHEN total_score >= 70 THEN 'B'
    WHEN total_score >= 65 THEN 'C+'
    WHEN total_score >= 60 THEN 'C'
    WHEN total_score >= 50 THEN 'D'
    ELSE 'F'
END;

UPDATE student_assessments
SET remark = CASE
    WHEN total_score >= 80 THEN 'Excellent'
    WHEN total_score >= 70 THEN 'Very Good'
    WHEN total_score >= 60 THEN 'Good'
    WHEN total_score >= 50 THEN 'Fair'
    ELSE 'Fail'
END;

-- Success message
SELECT 'Grading system updated successfully!' as Result;
SELECT 'New formula: Total = ((CA + Midterm) * 0.5) + (Exam / 2)' as Formula;
SELECT 'CA max: 60, Midterm max: 40, Exam max: 100, Total max: 100' as MaxScores;
