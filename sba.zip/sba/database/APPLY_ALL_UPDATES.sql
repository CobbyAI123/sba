-- =====================================================
-- MASTER UPDATE SCRIPT
-- Apply ALL changes to existing system
-- =====================================================

-- Step 1: Backup existing data (IMPORTANT!)
CREATE TABLE IF NOT EXISTS students_backup_pre_update AS SELECT * FROM students;
CREATE TABLE IF NOT EXISTS subjects_backup_pre_update AS SELECT * FROM subjects;

-- Step 2: Add default subjects to all schools
-- =====================================================
INSERT IGNORE INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 
    s.school_id,
    subject_name,
    subject_code,
    NOW()
FROM schools s
CROSS JOIN (
    SELECT 'English Language' as subject_name, 'ENG' as subject_code UNION ALL
    SELECT 'Mathematics', 'MATH' UNION ALL
    SELECT 'Integrated Science', 'SCI' UNION ALL
    SELECT 'Religious and Moral Education', 'RME' UNION ALL
    SELECT 'Creative Arts', 'CA' UNION ALL
    SELECT 'History', 'HIST' UNION ALL
    SELECT 'Physical Education', 'PE' UNION ALL
    SELECT 'Ghanaian Language', 'GHL' UNION ALL
    SELECT 'UC Mathematics', 'UCMATH' UNION ALL
    SELECT 'French', 'FRE' UNION ALL
    SELECT 'Social Studies', 'SS' UNION ALL
    SELECT 'Computing', 'COMP' UNION ALL
    SELECT 'Career Technology', 'CT' UNION ALL
    SELECT 'Literacy', 'LIT' UNION ALL
    SELECT 'Numeracy', 'NUM' UNION ALL
    SELECT 'Coloring', 'COL' UNION ALL
    SELECT 'Phonics', 'PHO' UNION ALL
    SELECT 'Writing', 'WRI' UNION ALL
    SELECT 'Our World Our People', 'OWOP'
) AS default_subjects
WHERE NOT EXISTS (
    SELECT 1 
    FROM subjects sub 
    WHERE sub.school_id = s.school_id 
    AND sub.subject_name = default_subjects.subject_name
);

SELECT '✓ Step 1 Complete: Default subjects added to all schools' as Status;

-- Step 3: Update student admission numbers to new format
-- =====================================================

-- Add backup column
ALTER TABLE students ADD COLUMN IF NOT EXISTS old_admission_number VARCHAR(50);
UPDATE students SET old_admission_number = admission_number WHERE old_admission_number IS NULL;

-- Create temporary table for sequential numbering per school and class
DROP TEMPORARY TABLE IF EXISTS temp_admission_numbers;
CREATE TEMPORARY TABLE temp_admission_numbers AS
SELECT 
    s.student_id,
    CONCAT(
        UPPER(sc.school_code),
        '/',
        COALESCE(YEAR(s.admission_date), YEAR(CURDATE())),
        '/',
        LPAD(COALESCE(s.class_id, 0), 2, '0'),
        '/',
        LPAD(
            (@row_num := IF(
                @current_school = s.school_id AND @current_class = COALESCE(s.class_id, 0),
                @row_num + 1,
                IF(
                    (@current_school := s.school_id) IS NOT NULL AND (@current_class := COALESCE(s.class_id, 0)) IS NOT NULL,
                    1,
                    1
                )
            )),
            5,
            '0'
        )
    ) as new_admission_number
FROM students s
INNER JOIN schools sc ON s.school_id = sc.school_id
CROSS JOIN (SELECT @row_num := 0, @current_school := 0, @current_class := 0) AS vars
WHERE s.class_id IS NOT NULL AND s.class_id > 0
ORDER BY s.school_id, s.class_id, s.student_id;

-- Update admission numbers from temp table
UPDATE students s
INNER JOIN temp_admission_numbers t ON s.student_id = t.student_id
SET s.admission_number = t.new_admission_number;

-- Update students without class (use GEN)
UPDATE students s
INNER JOIN schools sc ON s.school_id = sc.school_id
SET s.admission_number = CONCAT(
    UPPER(sc.school_code),
    '/',
    COALESCE(YEAR(s.admission_date), YEAR(CURDATE())),
    '/GEN/',
    LPAD(s.student_id, 5, '0')
)
WHERE s.class_id IS NULL OR s.class_id = 0;

SELECT '✓ Step 2 Complete: Student admission numbers updated' as Status;

-- Step 4: Update usernames to match new admission numbers
-- =====================================================
UPDATE users u
INNER JOIN students s ON u.user_id = s.user_id
SET u.username = LOWER(REPLACE(s.admission_number, '/', ''))
WHERE u.role = 'student';

SELECT '✓ Step 3 Complete: Student usernames updated' as Status;

-- Step 5: Verification queries
-- =====================================================
SELECT 
    '===== VERIFICATION REPORT =====' as Report,
    '' as Details
UNION ALL
SELECT 
    'Total Schools:' as Report,
    COUNT(*) as Details
FROM schools
UNION ALL
SELECT 
    'Total Students:' as Report,
    COUNT(*) as Details
FROM students
UNION ALL
SELECT 
    'Students with New Admission Format:' as Report,
    COUNT(*) as Details
FROM students
WHERE admission_number LIKE '%/%/%/%'
UNION ALL
SELECT 
    'Total Subjects Across All Schools:' as Report,
    COUNT(*) as Details
FROM subjects;

-- Sample of updated students
SELECT 
    '===== SAMPLE UPDATED STUDENTS =====' as Title
UNION ALL
SELECT 
    CONCAT(
        sc.school_code, ' | ',
        s.old_admission_number, ' → ',
        s.admission_number, ' | ',
        s.first_name, ' ', s.last_name, ' | ',
        c.class_name
    ) as Title
FROM students s
LEFT JOIN classes c ON s.class_id = c.class_id
LEFT JOIN schools sc ON s.school_id = sc.school_id
WHERE s.old_admission_number IS NOT NULL
ORDER BY s.school_id, s.class_id, s.student_id
LIMIT 20;

-- Subjects per school summary
SELECT 
    sc.school_name,
    sc.school_code,
    COUNT(sub.subject_id) as Total_Subjects
FROM schools sc
LEFT JOIN subjects sub ON sc.school_id = sub.school_id
GROUP BY sc.school_id, sc.school_name, sc.school_code
ORDER BY sc.school_name;

SELECT '✓ ALL UPDATES COMPLETED SUCCESSFULLY!' as Status;

-- Optional: Cleanup backup column (ONLY after verification)
-- ALTER TABLE students DROP COLUMN old_admission_number;
