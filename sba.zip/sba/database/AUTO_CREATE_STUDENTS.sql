-- ============================================
-- AUTO CREATE MISSING STUDENT RECORDS
-- This will automatically create student records for all users with role='student' who don't have one
-- ============================================

USE school_management_system;

-- First, let's see what we're about to create
SELECT 
    u.user_id,
    u.username,
    u.first_name,
    u.last_name,
    u.email,
    u.school_id,
    'Will be created' as action
FROM users u
LEFT JOIN students s ON u.user_id = s.user_id
WHERE u.role = 'student' 
AND s.student_id IS NULL;

-- Now create the missing student records
INSERT INTO students (
    user_id,
    school_id,
    admission_number,
    class_id,
    status
)
SELECT 
    u.user_id,
    u.school_id,
    CONCAT('ADM', u.school_id, LPAD(u.user_id, 5, '0')) as admission_number,
    (SELECT class_id FROM classes WHERE school_id = u.school_id LIMIT 1) as class_id,
    'active' as status
FROM users u
LEFT JOIN students s ON u.user_id = s.user_id
WHERE u.role = 'student' 
AND s.student_id IS NULL;

-- Show what was created (recent student records)
SELECT 
    s.student_id,
    u.username,
    CONCAT(u.first_name, ' ', u.last_name) as name,
    s.admission_number,
    c.class_name,
    '✓ Created successfully' as status
FROM students s
INNER JOIN users u ON s.user_id = u.user_id
LEFT JOIN classes c ON s.class_id = c.class_id
ORDER BY s.student_id DESC
LIMIT 20;

-- Final verification
SELECT 
    COUNT(*) as total_student_users,
    SUM(CASE WHEN s.student_id IS NOT NULL THEN 1 ELSE 0 END) as with_student_record,
    SUM(CASE WHEN s.student_id IS NULL THEN 1 ELSE 0 END) as missing_student_record
FROM users u
LEFT JOIN students s ON u.user_id = s.user_id
WHERE u.role = 'student';

-- Success message
SELECT '✓ All student records created! Students can now login and see their data.' as Result;
