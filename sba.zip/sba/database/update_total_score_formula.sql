-- ================================================================================
-- UPDATE TOTAL_SCORE COLUMN WITH SIMPLIFIED FORMULA
-- Date: November 17, 2025
-- Formula: Total = [(CA + Mid-Term) × 0.5] + [Exam × 0.5]
-- ================================================================================

-- Step 1: Show current statistics
SELECT '==================== BEFORE UPDATE ====================' as '';
SELECT 
    COUNT(*) as total_records,
    COUNT(CASE WHEN total_score > 0 THEN 1 END) as records_with_scores,
    ROUND(AVG(total_score), 2) as avg_total_before
FROM student_assessments;

SELECT '==================== CURRENT FORMULA ====================' as '';
SELECT 'Old: (ca/60*100 + mt/40*100)/2*0.5 + exam/100*100*0.5' as old_formula;
SELECT 'New: (ca + mt)*0.5 + exam*0.5' as new_formula;

-- Step 2: Drop the generated column
ALTER TABLE student_assessments
DROP COLUMN total_score;

-- Step 3: Add total_score back with simplified formula
ALTER TABLE student_assessments
ADD COLUMN total_score DECIMAL(5,2) 
GENERATED ALWAYS AS (
    ROUND(
        ((COALESCE(ca_score, 0) + COALESCE(midterm_score, 0)) * 0.5) + 
        (COALESCE(exam_score, 0) * 0.5),
        2
    )
) STORED
AFTER exam_score;

-- Step 4: Update grades based on new totals (triggers will handle this for new data)
UPDATE student_assessments
SET grade = CASE
    WHEN total_score >= 90 THEN 'A+'
    WHEN total_score >= 80 THEN 'A'
    WHEN total_score >= 75 THEN 'B+'
    WHEN total_score >= 70 THEN 'B'
    WHEN total_score >= 65 THEN 'C+'
    WHEN total_score >= 60 THEN 'C'
    WHEN total_score >= 50 THEN 'D'
    ELSE 'F'
END
WHERE total_score IS NOT NULL;

-- Step 5: Update remarks
UPDATE student_assessments
SET remark = CASE
    WHEN total_score >= 80 THEN 'Excellent'
    WHEN total_score >= 70 THEN 'Very Good'
    WHEN total_score >= 60 THEN 'Good'
    WHEN total_score >= 50 THEN 'Fair'
    ELSE 'Fail'
END
WHERE total_score IS NOT NULL;

-- Step 6: Show statistics after update
SELECT '==================== AFTER UPDATE ====================' as '';
SELECT 
    COUNT(*) as total_records,
    COUNT(CASE WHEN total_score > 0 THEN 1 END) as records_with_scores,
    ROUND(AVG(total_score), 2) as avg_total_after
FROM student_assessments;

-- Step 7: Show grade distribution
SELECT '==================== GRADE DISTRIBUTION ====================' as '';
SELECT 
    grade,
    COUNT(*) as count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM student_assessments WHERE total_score > 0), 2) as percentage
FROM student_assessments
WHERE total_score > 0
GROUP BY grade
ORDER BY FIELD(grade, 'A+', 'A', 'B+', 'B', 'C+', 'C', 'D', 'F');

-- Step 8: Show sample recalculated results
SELECT '==================== SAMPLE RESULTS ====================' as '';
SELECT 
    assessment_id,
    ca_score,
    midterm_score,
    exam_score,
    total_score,
    grade,
    remark
FROM student_assessments
ORDER BY total_score DESC
LIMIT 10;

-- Step 9: Verify formula with examples
SELECT '==================== FORMULA VERIFICATION ====================' as '';
SELECT 
    'CA=60, MT=40, Exam=100' as test,
    ROUND(((60 + 40) * 0.5) + (100 * 0.5), 2) as expected,
    (SELECT total_score FROM student_assessments WHERE ca_score = 60 AND midterm_score = 40 AND exam_score = 100 LIMIT 1) as actual
UNION ALL
SELECT 
    'CA=48, MT=30, Exam=70',
    ROUND(((48 + 30) * 0.5) + (70 * 0.5), 2),
    (SELECT total_score FROM student_assessments WHERE ca_score = 48 AND midterm_score = 30 AND exam_score = 70 LIMIT 1)
UNION ALL
SELECT 
    'CA=30, MT=20, Exam=50',
    ROUND(((30 + 20) * 0.5) + (50 * 0.5), 2),
    (SELECT total_score FROM student_assessments WHERE ca_score = 30 AND midterm_score = 20 AND exam_score = 50 LIMIT 1);

-- Success message
SELECT '==================== SUCCESS! ====================' as '';
SELECT 'All results recalculated with simplified formula!' as Status;
SELECT 'Formula: Total = [(CA + Mid-Term) × 0.5] + [Exam × 0.5]' as Formula;
SELECT 'Column is now auto-calculated (GENERATED STORED)' as Type;
SELECT '==================== COMPLETE ====================' as '';
