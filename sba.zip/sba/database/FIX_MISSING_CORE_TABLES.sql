-- FIX: Rebuild Missing Core Tables
-- Run this if you get "Table doesn't exist" errors
-- This creates all essential tables that may have been skipped during import

-- ============================================
-- SECTION 1: CORE TABLES (if missing)
-- ============================================

-- Schools Table
CREATE TABLE IF NOT EXISTS `schools` (
  `school_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_name` VARCHAR(255) NOT NULL,
  `location` VARCHAR(255),
  `phone` VARCHAR(20),
  `email` VARCHAR(255),
  `logo_path` VARCHAR(255),
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_name` (`school_name`)
);

-- Users Table
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) UNIQUE,
  `username` VARCHAR(100) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('super_admin', 'admin', 'teacher', 'student', 'parent', 'accountant', 'librarian') DEFAULT 'student',
  `status` ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
  `profile_picture` VARCHAR(255),
  `phone` VARCHAR(20),
  `address` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_school_role` (`school_id`, `role`),
  INDEX `idx_username` (`username`),
  INDEX `idx_email` (`email`)
);

-- Insert default admin if not exists
INSERT IGNORE INTO `schools` (school_id, school_name, status) VALUES (1, 'Default School', 'active');
INSERT IGNORE INTO `users` (user_id, school_id, first_name, last_name, email, username, password, role, status)
VALUES (1, 1, 'Super', 'Admin', 'admin@school.com', 'superadmin', MD5('password'), 'super_admin', 'active');

-- Classes Table
CREATE TABLE IF NOT EXISTS `classes` (
  `class_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `class_name` VARCHAR(100) NOT NULL,
  `class_level` VARCHAR(50),
  `form_number` INT,
  `capacity` INT DEFAULT 50,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_school_status` (`school_id`, `status`)
);

-- Teachers Table
CREATE TABLE IF NOT EXISTS `teachers` (
  `teacher_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `user_id` INT,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255),
  `phone` VARCHAR(20),
  `date_of_birth` DATE,
  `gender` ENUM('male', 'female', 'other'),
  `qualifications` TEXT,
  `subject_specialty` VARCHAR(100),
  `employment_date` DATE,
  `status` ENUM('active', 'on_leave', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_status` (`school_id`, `status`),
  INDEX `idx_user_id` (`user_id`)
);

-- Students Table
CREATE TABLE IF NOT EXISTS `students` (
  `student_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `user_id` INT,
  `admission_id` VARCHAR(50) UNIQUE,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `middle_name` VARCHAR(100),
  `date_of_birth` DATE,
  `gender` ENUM('male', 'female', 'other'),
  `nationality` VARCHAR(100),
  `email` VARCHAR(255),
  `phone` VARCHAR(20),
  `address` TEXT,
  `guardian_name` VARCHAR(255),
  `guardian_phone` VARCHAR(20),
  `guardian_email` VARCHAR(255),
  `class_id` INT,
  `status` ENUM('active', 'graduated', 'suspended', 'withdrawn') DEFAULT 'active',
  `admission_date` DATE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  FOREIGN KEY (`class_id`) REFERENCES `classes`(`class_id`) ON DELETE SET NULL,
  INDEX `idx_school_status` (`school_id`, `status`),
  INDEX `idx_class_id` (`class_id`),
  INDEX `idx_user_id` (`user_id`)
);

-- Attendance Table
CREATE TABLE IF NOT EXISTS `attendance` (
  `attendance_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `student_id` INT NOT NULL,
  `class_id` INT,
  `date` DATE NOT NULL,
  `status` ENUM('present', 'absent', 'late', 'excused') DEFAULT 'absent',
  `remarks` TEXT,
  `recorded_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
  FOREIGN KEY (`class_id`) REFERENCES `classes`(`class_id`) ON DELETE SET NULL,
  FOREIGN KEY (`recorded_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_date` (`school_id`, `date`),
  INDEX `idx_student_date` (`student_id`, `date`),
  UNIQUE KEY `unique_attendance` (`student_id`, `class_id`, `date`)
);

-- Exams Table
CREATE TABLE IF NOT EXISTS `exams` (
  `exam_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `exam_name` VARCHAR(255) NOT NULL,
  `exam_type` VARCHAR(100),
  `class_id` INT,
  `subject` VARCHAR(100),
  `exam_date` DATE,
  `total_marks` INT DEFAULT 100,
  `pass_mark` INT DEFAULT 40,
  `status` ENUM('scheduled', 'ongoing', 'completed') DEFAULT 'scheduled',
  `created_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`class_id`) REFERENCES `classes`(`class_id`) ON DELETE SET NULL,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_status` (`school_id`, `status`)
);

-- Results Table
CREATE TABLE IF NOT EXISTS `results` (
  `result_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `student_id` INT NOT NULL,
  `exam_id` INT NOT NULL,
  `marks_obtained` INT,
  `grade` VARCHAR(5),
  `status` ENUM('pass', 'fail', 'incomplete') DEFAULT 'incomplete',
  `remarks` TEXT,
  `recorded_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
  FOREIGN KEY (`exam_id`) REFERENCES `exams`(`exam_id`) ON DELETE CASCADE,
  FOREIGN KEY (`recorded_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_student` (`school_id`, `student_id`),
  UNIQUE KEY `unique_result` (`student_id`, `exam_id`)
);

-- Fees Table
CREATE TABLE IF NOT EXISTS `fees` (
  `fee_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `class_id` INT,
  `fee_type` VARCHAR(100) NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `academic_year` INT,
  `term` INT,
  `due_date` DATE,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`class_id`) REFERENCES `classes`(`class_id`) ON DELETE SET NULL,
  INDEX `idx_school_year_term` (`school_id`, `academic_year`, `term`)
);

-- Payments Table
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `student_id` INT NOT NULL,
  `fee_id` INT,
  `amount` DECIMAL(10, 2) NOT NULL,
  `payment_date` DATE NOT NULL,
  `payment_method` ENUM('cash', 'bank_transfer', 'paystack', 'cheque') DEFAULT 'cash',
  `reference_number` VARCHAR(100),
  `status` ENUM('pending', 'approved', 'rejected', 'partial') DEFAULT 'pending',
  `remarks` TEXT,
  `processed_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
  FOREIGN KEY (`fee_id`) REFERENCES `fees`(`fee_id`) ON DELETE SET NULL,
  FOREIGN KEY (`processed_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_student_date` (`school_id`, `student_id`, `payment_date`),
  INDEX `idx_status` (`status`)
);

-- Expenses Table
CREATE TABLE IF NOT EXISTS `expenses` (
  `expense_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `expense_type` VARCHAR(100) NOT NULL,
  `amount` DECIMAL(10, 2) NOT NULL,
  `expense_date` DATE NOT NULL,
  `description` TEXT,
  `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  `approved_by` INT,
  `created_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_date_status` (`school_id`, `expense_date`, `status`)
);

-- ============================================
-- SECTION 2: VERIFY TABLES
-- ============================================

-- Check that all core tables were created
SELECT 'Core Tables Status' as Status;
SELECT CONCAT('✓ Schools: ', COUNT(*)) FROM information_schema.tables WHERE table_schema = 'school_management_system' AND table_name = 'schools';
SELECT CONCAT('✓ Users: ', COUNT(*)) FROM information_schema.tables WHERE table_schema = 'school_management_system' AND table_name = 'users';
SELECT CONCAT('✓ Teachers: ', COUNT(*)) FROM information_schema.tables WHERE table_schema = 'school_management_system' AND table_name = 'teachers';
SELECT CONCAT('✓ Students: ', COUNT(*)) FROM information_schema.tables WHERE table_schema = 'school_management_system' AND table_name = 'students';
SELECT CONCAT('✓ Classes: ', COUNT(*)) FROM information_schema.tables WHERE table_schema = 'school_management_system' AND table_name = 'classes';
SELECT CONCAT('✓ Attendance: ', COUNT(*)) FROM information_schema.tables WHERE table_schema = 'school_management_system' AND table_name = 'attendance';
SELECT CONCAT('✓ Exams: ', COUNT(*)) FROM information_schema.tables WHERE table_schema = 'school_management_system' AND table_name = 'exams';
SELECT CONCAT('✓ Results: ', COUNT(*)) FROM information_schema.tables WHERE table_schema = 'school_management_system' AND table_name = 'results';
SELECT CONCAT('✓ Fees: ', COUNT(*)) FROM information_schema.tables WHERE table_schema = 'school_management_system' AND table_name = 'fees';
SELECT CONCAT('✓ Payments: ', COUNT(*)) FROM information_schema.tables WHERE table_schema = 'school_management_system' AND table_name = 'payments';
SELECT CONCAT('✓ Expenses: ', COUNT(*)) FROM information_schema.tables WHERE table_schema = 'school_management_system' AND table_name = 'expenses';

-- Final status
SELECT '✓ All core tables created successfully!' as Final_Status;
