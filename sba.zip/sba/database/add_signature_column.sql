-- Add signature column to users table for proprietor signature/stamp
ALTER TABLE users ADD COLUMN IF NOT EXISTS signature VARCHAR(255) DEFAULT NULL AFTER avatar;
