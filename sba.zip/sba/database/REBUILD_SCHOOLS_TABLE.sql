-- REBUILD_SCHOOLS_TABLE.sql
-- This script rebuilds the corrupted schools table

-- Step 1: Set foreign key checks off
SET FOREIGN_KEY_CHECKS=0;

-- Step 2: Drop the corrupted schools table
DROP TABLE IF EXISTS schools;

-- Step 3: Create the schools table with correct structure
CREATE TABLE schools (
    school_id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    school_name VARCHAR(255) NOT NULL,
    school_code VARCHAR(50) UNIQUE NOT NULL,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100) UNIQUE,
    motto TEXT,
    established_date DATE,
    logo VARCHAR(255),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Step 4: Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS=1;

SELECT 'Schools table has been successfully rebuilt!' as Result;
