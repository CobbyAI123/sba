-- ============================================================================
-- INSERT SAMPLE MARKS DATA FOR TESTING PERFORMANCE ANALYTICS (FIXED VERSION)
-- ============================================================================
-- This script inserts sample student marks for testing the Performance Analytics
-- feature. It creates realistic test data across multiple students, subjects, and terms.
-- Fixed for MariaDB/MySQL compatibility
-- ============================================================================

-- First, let's check what data we have
SELECT '=== CURRENT DATABASE STATE ===' as info;

-- Schools check
SELECT 
    'Schools' as entity,
    COUNT(*) as count
FROM schools;

-- Students check
SELECT 
    'Students' as entity,
    COUNT(*) as count
FROM students;

-- Get first 10 student IDs
SELECT 
    student_id,
    admission_number
FROM students
ORDER BY student_id
LIMIT 10;

-- Subjects check
SELECT 
    'Subjects' as entity,
    COUNT(*) as count
FROM subjects;

-- Get first 10 subject IDs
SELECT 
    subject_id,
    subject_name
FROM subjects
ORDER BY subject_id
LIMIT 10;

-- Classes check
SELECT 
    'Classes' as entity,
    COUNT(*) as count
FROM classes;

-- Terms check
SELECT 
    'Terms' as entity,
    COUNT(*) as count
FROM terms;

-- Get available terms
SELECT 
    term_id,
    term_name,
    session_year
FROM terms
ORDER BY session_year DESC, term_name;

-- Existing marks check
SELECT 
    'Existing Marks' as entity,
    COUNT(*) as count
FROM marks;

-- ============================================================================
-- INSERT SAMPLE MARKS
-- ============================================================================
-- This will insert marks for the first 10 students across available subjects and terms

SELECT '=== INSERTING SAMPLE MARKS ===' as info;

-- Insert marks for multiple students
INSERT INTO marks (student_id, subject_id, class_id, term_id, ca_score, midterm_score, exam_score)
SELECT 
    s.student_id,
    sub.subject_id,
    s.class_id,
    t.term_id,
    -- CA Score (0-60) - random but realistic
    FLOOR(30 + (RAND() * 30)) as ca_score,
    -- Midterm Score (0-40) - random but realistic
    FLOOR(20 + (RAND() * 20)) as midterm_score,
    -- Exam Score (0-100) - random but realistic
    FLOOR(40 + (RAND() * 60)) as exam_score
FROM 
    (SELECT student_id, class_id, school_id FROM students ORDER BY student_id LIMIT 10) s
CROSS JOIN 
    (SELECT subject_id, school_id FROM subjects ORDER BY subject_id LIMIT 10) sub
CROSS JOIN 
    (SELECT term_id, school_id FROM terms ORDER BY term_id LIMIT 3) t
WHERE 
    s.school_id = sub.school_id
    AND s.school_id = t.school_id
    -- Don't insert if already exists
    AND NOT EXISTS (
        SELECT 1 FROM marks m 
        WHERE m.student_id = s.student_id 
        AND m.subject_id = sub.subject_id 
        AND m.term_id = t.term_id
    )
LIMIT 300;

SELECT 'Sample marks inserted successfully!' as status;

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

SELECT '=== MARKS INSERTION RESULTS ===' as info;

-- Count total marks inserted
SELECT 
    'Total Marks Records' as metric,
    COUNT(*) as count
FROM marks;

-- Marks by student (first 10)
SELECT 
    s.student_id,
    s.admission_number,
    CONCAT(COALESCE(u.first_name, 'Unknown'), ' ', COALESCE(u.last_name, '')) as student_name,
    COUNT(m.mark_id) as total_assessments,
    ROUND(AVG(m.total_score), 1) as average_score
FROM marks m
JOIN students s ON m.student_id = s.student_id
LEFT JOIN users u ON s.user_id = u.user_id
GROUP BY s.student_id, s.admission_number, u.first_name, u.last_name
ORDER BY s.student_id
LIMIT 10;

-- Marks by term
SELECT 
    t.term_id,
    t.term_name,
    t.session_year,
    COUNT(m.mark_id) as total_assessments,
    COUNT(DISTINCT m.student_id) as students_assessed,
    ROUND(AVG(m.total_score), 1) as average_score
FROM marks m
JOIN terms t ON m.term_id = t.term_id
GROUP BY t.term_id, t.term_name, t.session_year
ORDER BY t.session_year DESC, t.term_name;

-- Marks by subject (top 10)
SELECT 
    sub.subject_id,
    sub.subject_name,
    COUNT(m.mark_id) as total_assessments,
    ROUND(AVG(m.total_score), 1) as average_score,
    ROUND(MAX(m.total_score), 1) as highest_score,
    ROUND(MIN(m.total_score), 1) as lowest_score
FROM marks m
JOIN subjects sub ON m.subject_id = sub.subject_id
GROUP BY sub.subject_id, sub.subject_name
ORDER BY average_score DESC
LIMIT 10;

-- Grade distribution
SELECT 
    m.grade,
    COUNT(*) as count,
    ROUND((COUNT(*) * 100.0 / (SELECT COUNT(*) FROM marks)), 1) as percentage
FROM marks m
WHERE m.grade IS NOT NULL
GROUP BY m.grade
ORDER BY 
    CASE m.grade
        WHEN 'HP' THEN 1
        WHEN 'P' THEN 2
        WHEN 'AP' THEN 3
        WHEN 'D' THEN 4
        WHEN 'E' THEN 5
        ELSE 6
    END;

-- Sample marks data (first 20)
SELECT '=== SAMPLE MARKS DATA ===' as info;

SELECT 
    s.admission_number,
    CONCAT(COALESCE(u.first_name, 'Unknown'), ' ', COALESCE(u.last_name, '')) as student_name,
    sub.subject_name,
    t.term_name,
    t.session_year,
    m.ca_score,
    m.midterm_score,
    m.exam_score,
    m.total_score,
    m.grade,
    m.remark
FROM marks m
JOIN students s ON m.student_id = s.student_id
LEFT JOIN users u ON s.user_id = u.user_id
JOIN subjects sub ON m.subject_id = sub.subject_id
JOIN terms t ON m.term_id = t.term_id
ORDER BY s.admission_number, t.session_year, t.term_name, sub.subject_name
LIMIT 20;

-- ============================================================================
-- PERFORMANCE ANALYTICS TEST QUERIES
-- ============================================================================

SELECT '=== PERFORMANCE ANALYTICS READY ===' as status;

-- Check if data is ready for Performance Analytics
SELECT 
    CASE 
        WHEN (SELECT COUNT(*) FROM marks) > 0 THEN 'YES - Performance Analytics Ready!'
        ELSE 'NO - No marks data found'
    END as analytics_ready,
    (SELECT COUNT(*) FROM marks) as total_marks,
    (SELECT COUNT(DISTINCT student_id) FROM marks) as students_with_marks,
    (SELECT COUNT(DISTINCT term_id) FROM marks) as terms_with_marks,
    (SELECT COUNT(DISTINCT subject_id) FROM marks) as subjects_with_marks;

-- ============================================================================
-- COMPLETION MESSAGE
-- ============================================================================

SELECT '✅ SAMPLE MARKS IMPORTED SUCCESSFULLY!' as message;
SELECT '📊 Performance Analytics is now ready to use!' as next_step;
SELECT 'Go to: Proprietor → Academic Performance → Performance Analytics' as instruction;

-- ============================================================================
-- NOTES
-- ============================================================================
/*
USAGE INSTRUCTIONS:
1. Run this script in phpMyAdmin SQL tab
2. Check the verification results
3. Access Performance Analytics in Proprietor portal
4. Test all three analysis modes:
   - By Term
   - By Academic Year
   - By Student

WHAT THIS SCRIPT DOES:
- Inserts sample marks for first 10 students
- Covers first 10 subjects and first 3 terms
- Generates realistic random scores
- Auto-calculates total scores and grades via triggers
- Prevents duplicate entries

GRADING SYSTEM:
- HP (Highly Proficient): 80-100%
- P (Proficient): 68-79%
- AP (Approaching Proficient): 53-67%
- D (Developing): 40-52%
- E (Emerging): 0-39%

SCORE CALCULATION:
Total = [(CA + Midterm) × 0.5] + [Exam × 0.5]

TROUBLESHOOTING:
If you get errors:
1. Check that marks table exists (import CREATE_MARKS_PERFORMANCE_TABLE.sql)
2. Verify students, subjects, and terms exist
3. Ensure triggers are created
4. Check foreign key constraints

TO DELETE SAMPLE DATA:
DELETE FROM marks WHERE mark_id > 0;

TO CHECK SPECIFIC STUDENT MARKS:
SELECT * FROM marks WHERE student_id = YOUR_STUDENT_ID;

TO CHECK SPECIFIC TERM MARKS:
SELECT * FROM marks WHERE term_id = YOUR_TERM_ID;
*/

-- ============================================================================
-- END OF SCRIPT
-- ============================================================================
