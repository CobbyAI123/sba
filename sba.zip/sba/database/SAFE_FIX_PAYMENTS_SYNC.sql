-- =====================================================
-- SAFE PAYMENTS SYNCHRONIZATION FIX
-- Run this version if you got foreign key errors
-- =====================================================

USE school_management_system;

-- 1. Create student_fees table without foreign keys first
-- =====================================================
DROP TABLE IF EXISTS student_fees;

CREATE TABLE student_fees (
    fee_id INT AUTO_INCREMENT PRIMARY KEY,
    school_id INT NOT NULL,
    student_id INT NOT NULL,
    total_fees DECIMAL(10,2) DEFAULT 0.00,
    total_paid DECIMAL(10,2) DEFAULT 0.00,
    balance DECIMAL(10,2) DEFAULT 0.00,
    last_payment_date DATE DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_student_fee (school_id, student_id),
    INDEX idx_student_id (student_id),
    INDEX idx_school_id (school_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SELECT '✅ student_fees table created without foreign keys' as status;

-- 2. Add missing columns to payments table
-- =====================================================

-- Add payment_type column if missing
SET @col_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = 'school_management_system'
    AND TABLE_NAME = 'payments' 
    AND COLUMN_NAME = 'payment_type'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE payments ADD COLUMN payment_type VARCHAR(50) DEFAULT ''tuition'' AFTER amount',
    'SELECT ''payment_type column already exists'' as info'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add paid_by column if missing
SET @col_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = 'school_management_system'
    AND TABLE_NAME = 'payments' 
    AND COLUMN_NAME = 'paid_by'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE payments ADD COLUMN paid_by VARCHAR(255) DEFAULT NULL AFTER payment_reference',
    'SELECT ''paid_by column already exists'' as info'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add paid_by_phone column if missing
SET @col_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = 'school_management_system'
    AND TABLE_NAME = 'payments' 
    AND COLUMN_NAME = 'paid_by_phone'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE payments ADD COLUMN paid_by_phone VARCHAR(20) DEFAULT NULL AFTER paid_by',
    'SELECT ''paid_by_phone column already exists'' as info'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add remarks column if missing
SET @col_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = 'school_management_system'
    AND TABLE_NAME = 'payments' 
    AND COLUMN_NAME = 'remarks'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE payments ADD COLUMN remarks TEXT DEFAULT NULL',
    'SELECT ''remarks column already exists'' as info'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add updated_at column if missing
SET @col_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = 'school_management_system'
    AND TABLE_NAME = 'payments' 
    AND COLUMN_NAME = 'updated_at'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE payments ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
    'SELECT ''updated_at column already exists'' as info'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT '✅ Payments table columns updated' as status;

-- 3. Create indexes for better performance
-- =====================================================
CREATE INDEX IF NOT EXISTS idx_payments_student ON payments(student_id, status);
CREATE INDEX IF NOT EXISTS idx_payments_school ON payments(school_id, status);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_payments_created ON payments(created_at);

SELECT '✅ Performance indexes created' as status;

-- 4. Sync existing payment data (ONLY for existing students)
-- =====================================================
INSERT INTO student_fees (school_id, student_id, total_paid, last_payment_date, updated_at)
SELECT 
    p.school_id,
    p.student_id,
    COALESCE(SUM(CASE WHEN p.status IN ('paid', 'completed') THEN p.amount ELSE 0 END), 0) as total_paid,
    MAX(CASE WHEN p.status IN ('paid', 'completed') THEN p.payment_date END) as last_payment_date,
    NOW() as updated_at
FROM payments p
INNER JOIN students s ON p.student_id = s.student_id  -- Only sync existing students
WHERE p.status IN ('paid', 'completed')
GROUP BY p.school_id, p.student_id
ON DUPLICATE KEY UPDATE
    total_paid = VALUES(total_paid),
    last_payment_date = VALUES(last_payment_date),
    updated_at = NOW();

SELECT '✅ Payment data synced to student_fees' as status;

-- 5. Update balances based on fee structure
-- =====================================================
UPDATE student_fees sf
INNER JOIN students s ON sf.student_id = s.student_id
LEFT JOIN (
    SELECT 
        fs.school_id,
        fs.class_id,
        SUM(fs.amount) as total_fees
    FROM fee_structure fs
    GROUP BY fs.school_id, fs.class_id
) fs ON s.school_id = fs.school_id AND s.class_id = fs.class_id
SET 
    sf.total_fees = COALESCE(fs.total_fees, 0),
    sf.balance = COALESCE(fs.total_fees, 0) - sf.total_paid;

SELECT '✅ Student balances calculated' as status;

-- 6. Create trigger to auto-update student_fees on payment insert
-- =====================================================
DROP TRIGGER IF EXISTS after_payment_insert;

DELIMITER $$
CREATE TRIGGER after_payment_insert
AFTER INSERT ON payments
FOR EACH ROW
BEGIN
    DECLARE student_exists INT;
    
    -- Check if student exists
    SELECT COUNT(*) INTO student_exists 
    FROM students 
    WHERE student_id = NEW.student_id;
    
    -- Only update if student exists
    IF student_exists > 0 AND NEW.status IN ('paid', 'completed') THEN
        INSERT INTO student_fees (school_id, student_id, total_paid, last_payment_date, updated_at)
        VALUES (NEW.school_id, NEW.student_id, NEW.amount, NEW.payment_date, NOW())
        ON DUPLICATE KEY UPDATE
            total_paid = total_paid + NEW.amount,
            last_payment_date = NEW.payment_date,
            updated_at = NOW();
            
        -- Update balance
        UPDATE student_fees sf
        INNER JOIN students s ON sf.student_id = s.student_id
        LEFT JOIN (
            SELECT 
                fs.school_id,
                fs.class_id,
                SUM(fs.amount) as total_fees
            FROM fee_structure fs
            GROUP BY fs.school_id, fs.class_id
        ) fs ON s.school_id = fs.school_id AND s.class_id = fs.class_id
        SET sf.balance = COALESCE(fs.total_fees, 0) - sf.total_paid
        WHERE sf.student_id = NEW.student_id;
    END IF;
END$$
DELIMITER ;

SELECT '✅ Insert trigger created' as status;

-- 7. Create trigger to auto-update student_fees on payment update
-- =====================================================
DROP TRIGGER IF EXISTS after_payment_update;

DELIMITER $$
CREATE TRIGGER after_payment_update
AFTER UPDATE ON payments
FOR EACH ROW
BEGIN
    DECLARE student_exists INT;
    
    -- Check if student exists
    SELECT COUNT(*) INTO student_exists 
    FROM students 
    WHERE student_id = NEW.student_id;
    
    -- Only update if student exists
    IF student_exists > 0 THEN
        -- Recalculate total paid for this student
        UPDATE student_fees
        SET total_paid = (
            SELECT COALESCE(SUM(amount), 0)
            FROM payments
            WHERE student_id = NEW.student_id 
            AND status IN ('paid', 'completed')
        ),
        last_payment_date = (
            SELECT MAX(payment_date)
            FROM payments
            WHERE student_id = NEW.student_id 
            AND status IN ('paid', 'completed')
        ),
        updated_at = NOW()
        WHERE student_id = NEW.student_id;
        
        -- Update balance
        UPDATE student_fees sf
        INNER JOIN students s ON sf.student_id = s.student_id
        LEFT JOIN (
            SELECT 
                fs.school_id,
                fs.class_id,
                SUM(fs.amount) as total_fees
            FROM fee_structure fs
            GROUP BY fs.school_id, fs.class_id
        ) fs ON s.school_id = fs.school_id AND s.class_id = fs.class_id
        SET sf.balance = COALESCE(fs.total_fees, 0) - sf.total_paid
        WHERE sf.student_id = NEW.student_id;
    END IF;
END$$
DELIMITER ;

SELECT '✅ Update trigger created' as status;

-- 8. Create trigger to auto-update student_fees on payment delete
-- =====================================================
DROP TRIGGER IF EXISTS after_payment_delete;

DELIMITER $$
CREATE TRIGGER after_payment_delete
AFTER DELETE ON payments
FOR EACH ROW
BEGIN
    DECLARE student_exists INT;
    
    -- Check if student exists
    SELECT COUNT(*) INTO student_exists 
    FROM students 
    WHERE student_id = OLD.student_id;
    
    -- Only update if student exists
    IF student_exists > 0 THEN
        -- Recalculate total paid for this student
        UPDATE student_fees
        SET total_paid = (
            SELECT COALESCE(SUM(amount), 0)
            FROM payments
            WHERE student_id = OLD.student_id 
            AND status IN ('paid', 'completed')
        ),
        last_payment_date = (
            SELECT MAX(payment_date)
            FROM payments
            WHERE student_id = OLD.student_id 
            AND status IN ('paid', 'completed')
        ),
        updated_at = NOW()
        WHERE student_id = OLD.student_id;
        
        -- Update balance
        UPDATE student_fees sf
        INNER JOIN students s ON sf.student_id = s.student_id
        LEFT JOIN (
            SELECT 
                fs.school_id,
                fs.class_id,
                SUM(fs.amount) as total_fees
            FROM fee_structure fs
            GROUP BY fs.school_id, fs.class_id
        ) fs ON s.school_id = fs.school_id AND s.class_id = fs.class_id
        SET sf.balance = COALESCE(fs.total_fees, 0) - sf.total_paid
        WHERE sf.student_id = OLD.student_id;
    END IF;
END$$
DELIMITER ;

SELECT '✅ Delete trigger created' as status;

-- 9. Verification queries
-- =====================================================
SELECT '========== VERIFICATION RESULTS ==========' as '';

SELECT '✅ Payments table structure' as check_name;
SHOW COLUMNS FROM payments;

SELECT '✅ Student fees table structure' as check_name;
SHOW COLUMNS FROM student_fees;

SELECT '✅ Triggers created' as check_name;
SHOW TRIGGERS LIKE 'payments';

SELECT 'Payment Statistics' as check_name, 
    COUNT(*) as total_payments,
    SUM(amount) as total_amount,
    COUNT(DISTINCT student_id) as unique_students
FROM payments 
WHERE status IN ('paid', 'completed');

SELECT 'Student Fees Statistics' as check_name,
    COUNT(*) as total_records,
    SUM(total_paid) as total_collected,
    SUM(balance) as total_outstanding
FROM student_fees;

SELECT 'Orphaned Payments' as check_name,
    COUNT(*) as orphaned_count,
    COALESCE(SUM(amount), 0) as orphaned_amount
FROM payments p
LEFT JOIN students s ON p.student_id = s.student_id
WHERE s.student_id IS NULL;

-- Show recent payments
SELECT 'Recent Payments (Last 5)' as '';
SELECT 
    p.payment_id,
    s.admission_number,
    CONCAT(u.first_name, ' ', u.last_name) as student_name,
    p.amount,
    p.payment_method,
    p.payment_date,
    p.status
FROM payments p
LEFT JOIN students s ON p.student_id = s.student_id
LEFT JOIN users u ON s.user_id = u.user_id
ORDER BY p.created_at DESC
LIMIT 5;

SELECT '=========================================' as '';
SELECT '✅ PAYMENT SYNCHRONIZATION COMPLETE!' as final_status;
SELECT 'All payments will now sync automatically across all pages' as info;
