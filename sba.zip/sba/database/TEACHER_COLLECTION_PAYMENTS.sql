-- =====================================================
-- TEACHER COLLECTION PAYMENTS TABLE
-- Track teacher payments for daily collections
-- =====================================================

USE school_management_system;

-- Create teacher collection payments table
CREATE TABLE IF NOT EXISTS `teacher_collection_payments` (
  `payment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `teacher_id` INT(11) NOT NULL,
  `collection_date` DATE NOT NULL,
  `amount_paid` DECIMAL(10,2) NOT NULL,
  `payment_method` ENUM('cash', 'mobile_money', 'bank_transfer', 'cheque') DEFAULT 'cash',
  `notes` TEXT,
  `verified_by` INT(11) NOT NULL COMMENT 'Accountant/Admin who verified',
  `verified_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  KEY `idx_school_teacher` (`school_id`, `teacher_id`),
  KEY `idx_collection_date` (`collection_date`),
  KEY `idx_verified_by` (`verified_by`),
  UNIQUE KEY `unique_teacher_date` (`teacher_id`, `collection_date`, `school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Add indexes for performance
ALTER TABLE `teacher_collection_payments`
ADD INDEX IF NOT EXISTS `idx_school_date` (`school_id`, `collection_date`),
ADD INDEX IF NOT EXISTS `idx_teacher_date_range` (`teacher_id`, `collection_date`);

-- Success message
SELECT 
    '✅ TEACHER COLLECTION PAYMENTS TABLE CREATED!' as Status,
    'Table ready for tracking teacher payments' as Message,
    'Accountants can now verify daily collections' as Feature;
