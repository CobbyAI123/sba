-- ============================================
-- FORCE DELETE ALL PHANTOM ASSESSMENT ENTRIES
-- Removes ALL records where all scores are NULL
-- ============================================

-- STEP 1: Show what will be deleted
SELECT 
    sa.assessment_id,
    sa.student_id,
    c.class_name,
    s.subject_name,
    sa.ca_score,
    sa.midterm_score,
    sa.exam_score,
    sa.created_at
FROM student_assessments sa
LEFT JOIN classes c ON sa.class_id = c.class_id
LEFT JOIN subjects s ON sa.subject_id = s.subject_id
WHERE sa.ca_score IS NULL 
  AND sa.midterm_score IS NULL 
  AND sa.exam_score IS NULL
ORDER BY sa.created_at DESC;

-- STEP 2: Count how many will be deleted
SELECT 
    COUNT(*) as records_to_delete,
    'Records with all NULL scores (will be deleted)' as description
FROM student_assessments
WHERE ca_score IS NULL 
  AND midterm_score IS NULL 
  AND exam_score IS NULL;

-- STEP 3: DELETE THE PHANTOM RECORDS
DELETE FROM student_assessments
WHERE ca_score IS NULL 
  AND midterm_score IS NULL 
  AND exam_score IS NULL;

-- STEP 4: Verify deletion
SELECT 
    COUNT(*) as remaining_records,
    'Total assessment records remaining' as description
FROM student_assessments;

-- STEP 5: Show remaining assessments for Career Technology
SELECT 
    sa.assessment_id,
    c.class_name,
    s.subject_name,
    CONCAT(u.first_name, ' ', u.last_name) as student_name,
    sa.ca_score,
    sa.midterm_score,
    sa.exam_score
FROM student_assessments sa
LEFT JOIN classes c ON sa.class_id = c.class_id
LEFT JOIN subjects s ON sa.subject_id = s.subject_id
LEFT JOIN students st ON sa.student_id = st.student_id
LEFT JOIN users u ON st.user_id = u.user_id
WHERE s.subject_name LIKE '%Career%Technology%'
ORDER BY sa.created_at DESC;

SELECT '✓ SUCCESS: All phantom assessments deleted!' as Status;
