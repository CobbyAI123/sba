-- ============================================================================
-- CREATE MARKS TABLE FOR PERFORMANCE ANALYTICS
-- ============================================================================
-- This table stores student exam/assessment marks for performance tracking
-- Compatible with Performance Analytics module
-- ============================================================================

-- Drop table if exists (for fresh install)
DROP TABLE IF EXISTS `marks`;

-- Create marks table
CREATE TABLE `marks` (
  `mark_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) DEFAULT NULL,
  `term_id` int(11) NOT NULL,
  `exam_id` int(11) DEFAULT NULL,
  `exam_type` varchar(50) DEFAULT NULL COMMENT 'CA, Mid-Term, Exam',
  `ca_score` decimal(5,2) DEFAULT 0.00 COMMENT 'Class Assessment (max 60)',
  `midterm_score` decimal(5,2) DEFAULT 0.00 COMMENT 'Mid-Term (max 40)',
  `exam_score` decimal(5,2) DEFAULT 0.00 COMMENT 'Final Exam (max 100)',
  `total_score` decimal(5,2) DEFAULT 0.00 COMMENT 'Calculated total (max 100)',
  `grade` varchar(10) DEFAULT NULL COMMENT 'HP, P, AP, D, E',
  `remark` varchar(100) DEFAULT NULL,
  `position` int(11) DEFAULT NULL COMMENT 'Position in class',
  `teacher_id` int(11) DEFAULT NULL COMMENT 'Teacher who entered marks',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mark_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_exam` (`exam_id`),
  KEY `idx_total_score` (`total_score`),
  KEY `idx_student_term` (`student_id`, `term_id`),
  KEY `idx_student_subject` (`student_id`, `subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- TRIGGERS FOR AUTO-CALCULATION
-- ============================================================================

-- Trigger to auto-calculate total score and grade before insert
DELIMITER $$
CREATE TRIGGER `calculate_marks_before_insert` BEFORE INSERT ON `marks`
FOR EACH ROW
BEGIN
    -- Calculate total score: [(CA + Mid-Term) × 0.5] + [Exam × 0.5]
    SET NEW.total_score = (
        (COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5
    ) + (COALESCE(NEW.exam_score, 0) * 0.5);
    
    -- Auto-assign grade based on total score
    IF NEW.total_score >= 80 THEN
        SET NEW.grade = 'HP';
        SET NEW.remark = 'Highly Proficient';
    ELSEIF NEW.total_score >= 68 THEN
        SET NEW.grade = 'P';
        SET NEW.remark = 'Proficient';
    ELSEIF NEW.total_score >= 53 THEN
        SET NEW.grade = 'AP';
        SET NEW.remark = 'Approaching Proficient';
    ELSEIF NEW.total_score >= 40 THEN
        SET NEW.grade = 'D';
        SET NEW.remark = 'Developing';
    ELSE
        SET NEW.grade = 'E';
        SET NEW.remark = 'Emerging';
    END IF;
END$$
DELIMITER ;

-- Trigger to auto-calculate total score and grade before update
DELIMITER $$
CREATE TRIGGER `calculate_marks_before_update` BEFORE UPDATE ON `marks`
FOR EACH ROW
BEGIN
    -- Calculate total score: [(CA + Mid-Term) × 0.5] + [Exam × 0.5]
    SET NEW.total_score = (
        (COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5
    ) + (COALESCE(NEW.exam_score, 0) * 0.5);
    
    -- Auto-assign grade based on total score
    IF NEW.total_score >= 80 THEN
        SET NEW.grade = 'HP';
        SET NEW.remark = 'Highly Proficient';
    ELSEIF NEW.total_score >= 68 THEN
        SET NEW.grade = 'P';
        SET NEW.remark = 'Proficient';
    ELSEIF NEW.total_score >= 53 THEN
        SET NEW.grade = 'AP';
        SET NEW.remark = 'Approaching Proficient';
    ELSEIF NEW.total_score >= 40 THEN
        SET NEW.grade = 'D';
        SET NEW.remark = 'Developing';
    ELSE
        SET NEW.grade = 'E';
        SET NEW.remark = 'Emerging';
    END IF;
END$$
DELIMITER ;

-- ============================================================================
-- INSERT SAMPLE DATA (Optional - for testing)
-- ============================================================================
-- Uncomment below to insert sample marks data for testing
/*
-- Get IDs for sample data
SET @school_id = (SELECT school_id FROM schools LIMIT 1);
SET @student1_id = (SELECT student_id FROM students WHERE school_id = @school_id LIMIT 1);
SET @term1_id = (SELECT term_id FROM terms WHERE school_id = @school_id LIMIT 1);
SET @subject1_id = (SELECT subject_id FROM subjects WHERE school_id = @school_id LIMIT 1);
SET @class1_id = (SELECT class_id FROM classes WHERE school_id = @school_id LIMIT 1);

-- Insert sample marks
INSERT INTO marks (student_id, subject_id, class_id, term_id, ca_score, midterm_score, exam_score)
VALUES
(@student1_id, @subject1_id, @class1_id, @term1_id, 50, 35, 75),
(@student1_id, @subject1_id + 1, @class1_id, @term1_id, 55, 38, 80),
(@student1_id, @subject1_id + 2, @class1_id, @term1_id, 45, 30, 65);
*/

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Check if table was created successfully
SELECT 
    'marks table created successfully' as status,
    COUNT(*) as total_records
FROM marks;

-- Show table structure
DESCRIBE marks;

-- Show triggers
SHOW TRIGGERS WHERE `Table` = 'marks';

-- ============================================================================
-- USAGE NOTES
-- ============================================================================
/*
GRADING SYSTEM:
- HP (Highly Proficient): 80% - 100%
- P (Proficient): 68% - 79%
- AP (Approaching Proficient): 53% - 67%
- D (Developing): 40% - 52%
- E (Emerging): 0% - 39%

SCORE CALCULATION:
Total Score = [(CA + Mid-Term) × 0.5] + [Exam × 0.5]

MAXIMUM SCORES:
- CA Score: 60
- Mid-Term Score: 40
- Exam Score: 100
- Total Score: 100 (auto-calculated)

EXAMPLE INSERT:
INSERT INTO marks (student_id, subject_id, class_id, term_id, ca_score, midterm_score, exam_score)
VALUES (1, 1, 1, 1, 55, 35, 80);
-- This will auto-calculate: total_score = 72.5, grade = 'P', remark = 'Proficient'

PERFORMANCE ANALYTICS COMPATIBILITY:
This table structure is fully compatible with:
- Performance Analytics module
- Student performance reports
- Term-based analysis
- Academic year comparisons
- Subject-wise tracking
*/

-- ============================================================================
-- END OF SCRIPT
-- ============================================================================

SELECT '✅ Marks table created successfully!' as message;
SELECT '📊 Ready for Performance Analytics' as status;
