-- Update all existing student admission IDs to new format: SCHOOL_CODE/YEAR/CLASS_ID/00001
-- This script updates all students in the system with the new admission number format

-- Backup existing admission numbers first (optional)
ALTER TABLE students ADD COLUMN old_admission_number VARCHAR(50) AFTER admission_number;
UPDATE students SET old_admission_number = admission_number WHERE old_admission_number IS NULL;

-- Update admission numbers for all students with new format
SET @row_num = 0;
SET @current_school = 0;
SET @current_year = YEAR(CURDATE());
SET @current_class = 0;

UPDATE students s
INNER JOIN schools sc ON s.school_id = sc.school_id
SET s.admission_number = CONCAT(
    UPPER(sc.school_code),
    '/',
    COALESCE(YEAR(s.admission_date), @current_year),
    '/',
    LPAD(COALESCE(s.class_id, 0), 2, '0'),
    '/',
    LPAD(
        (@row_num := IF(
            @current_school = s.school_id AND @current_class = s.class_id,
            @row_num + 1,
            IF(
                (@current_school := s.school_id) OR (@current_class := s.class_id),
                1,
                1
            )
        )),
        5,
        '0'
    )
)
WHERE s.admission_number IS NOT NULL
ORDER BY s.school_id, COALESCE(s.class_id, 0), s.student_id;

-- For students without class_id, use 'GEN' (General)
UPDATE students s
INNER JOIN schools sc ON s.school_id = sc.school_id
SET s.admission_number = CONCAT(
    UPPER(sc.school_code),
    '/',
    COALESCE(YEAR(s.admission_date), YEAR(CURDATE())),
    '/GEN/',
    LPAD(s.student_id, 5, '0')
)
WHERE s.class_id IS NULL OR s.class_id = 0;

-- Update usernames to match new admission numbers
UPDATE users u
INNER JOIN students s ON u.user_id = s.user_id
SET u.username = LOWER(REPLACE(s.admission_number, '/', ''))
WHERE u.role = 'student';

-- Verification query
SELECT 
    s.student_id,
    s.old_admission_number as 'Old Admission #',
    s.admission_number as 'New Admission #',
    s.first_name,
    s.last_name,
    c.class_name,
    sc.school_code
FROM students s
LEFT JOIN classes c ON s.class_id = c.class_id
LEFT JOIN schools sc ON s.school_id = sc.school_id
ORDER BY s.school_id, s.class_id, s.student_id
LIMIT 50;

-- Optional: Remove backup column after verification
-- ALTER TABLE students DROP COLUMN old_admission_number;
