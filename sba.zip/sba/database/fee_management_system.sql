-- ============================================================================
-- FEE MANAGEMENT SYSTEM
-- Complete fee structure, payment tracking, and receipt generation
-- Date: November 12, 2025
-- ============================================================================

-- Fee Categories (Types of fees: Tuition, Transport, Library, etc.)
CREATE TABLE IF NOT EXISTS `fee_categories` (
  `category_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `category_name` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `is_mandatory` TINYINT(1) DEFAULT 1,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Fee Structure (Amount for each category per class)
CREATE TABLE IF NOT EXISTS `fee_structure` (
  `structure_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `category_id` INT(11) NOT NULL,
  `class_id` INT(11) NULL COMMENT 'NULL means applies to all classes',
  `academic_year` VARCHAR(20) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_frequency` ENUM('one_time', 'monthly', 'quarterly', 'annually') DEFAULT 'one_time',
  `due_date` DATE NULL,
  `late_fee_amount` DECIMAL(10,2) DEFAULT 0.00,
  `late_fee_after_days` INT(3) DEFAULT 0,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_by` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`structure_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_category` (`category_id`),
  KEY `idx_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Student Fee Assignments (What each student owes)
CREATE TABLE IF NOT EXISTS `student_fees` (
  `student_fee_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `structure_id` INT(11) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL,
  `total_amount` DECIMAL(10,2) NOT NULL,
  `paid_amount` DECIMAL(10,2) DEFAULT 0.00,
  `discount_amount` DECIMAL(10,2) DEFAULT 0.00,
  `late_fee_amount` DECIMAL(10,2) DEFAULT 0.00,
  `balance_amount` DECIMAL(10,2) GENERATED ALWAYS AS (total_amount - paid_amount + late_fee_amount - discount_amount) STORED,
  `due_date` DATE NULL,
  `status` ENUM('pending', 'partial', 'paid', 'overdue', 'waived') DEFAULT 'pending',
  `assigned_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`student_fee_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_structure` (`structure_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Fee Payments (Individual payment transactions)
CREATE TABLE IF NOT EXISTS `fee_payments` (
  `payment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `student_fee_id` INT(11) NULL COMMENT 'Link to specific fee',
  `receipt_number` VARCHAR(50) NOT NULL UNIQUE,
  `payment_date` DATE NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_method` ENUM('cash', 'card', 'bank_transfer', 'cheque', 'online', 'upi') DEFAULT 'cash',
  `transaction_id` VARCHAR(100) NULL,
  `cheque_number` VARCHAR(50) NULL,
  `bank_name` VARCHAR(100) NULL,
  `remarks` TEXT NULL,
  `payment_for` VARCHAR(255) NULL COMMENT 'Description of what this payment is for',
  `collected_by` INT(11) NOT NULL,
  `verified_by` INT(11) NULL,
  `verified_at` TIMESTAMP NULL,
  `status` ENUM('pending', 'verified', 'cancelled') DEFAULT 'verified',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  UNIQUE KEY `idx_receipt` (`receipt_number`),
  KEY `idx_student` (`student_id`),
  KEY `idx_date` (`payment_date`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Fee Discounts (Scholarships, sibling discounts, etc.)
CREATE TABLE IF NOT EXISTS `fee_discounts` (
  `discount_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `discount_name` VARCHAR(100) NOT NULL,
  `discount_type` ENUM('percentage', 'fixed') DEFAULT 'percentage',
  `discount_value` DECIMAL(10,2) NOT NULL,
  `applicable_categories` TEXT NULL COMMENT 'Comma-separated category IDs',
  `description` TEXT NULL,
  `valid_from` DATE NULL,
  `valid_to` DATE NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`discount_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Student Discount Assignments
CREATE TABLE IF NOT EXISTS `student_discounts` (
  `assignment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `discount_id` INT(11) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL,
  `discount_amount` DECIMAL(10,2) NOT NULL,
  `reason` TEXT NULL,
  `approved_by` INT(11) NOT NULL,
  `approved_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`assignment_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_discount` (`discount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Fee Reminders (Automatic reminders for due fees)
CREATE TABLE IF NOT EXISTS `fee_reminders` (
  `reminder_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_fee_id` INT(11) NOT NULL,
  `reminder_date` DATE NOT NULL,
  `reminder_type` ENUM('sms', 'email', 'notification') DEFAULT 'notification',
  `message` TEXT NOT NULL,
  `sent_at` TIMESTAMP NULL,
  `status` ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`reminder_id`),
  KEY `idx_fee` (`student_fee_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- INSERT DEFAULT FEE CATEGORIES
-- ============================================================================

INSERT INTO `fee_categories` (`school_id`, `category_name`, `description`, `is_mandatory`, `status`)
SELECT school_id, 'Tuition Fee', 'Regular tuition fees', 1, 'active'
FROM schools
WHERE NOT EXISTS (SELECT 1 FROM fee_categories WHERE school_id = schools.school_id AND category_name = 'Tuition Fee')
LIMIT 10;

INSERT INTO `fee_categories` (`school_id`, `category_name`, `description`, `is_mandatory`, `status`)
SELECT school_id, 'Admission Fee', 'One-time admission fee', 1, 'active'
FROM schools
WHERE NOT EXISTS (SELECT 1 FROM fee_categories WHERE school_id = schools.school_id AND category_name = 'Admission Fee')
LIMIT 10;

INSERT INTO `fee_categories` (`school_id`, `category_name`, `description`, `is_mandatory`, `status`)
SELECT school_id, 'Library Fee', 'Library maintenance and books', 0, 'active'
FROM schools
WHERE NOT EXISTS (SELECT 1 FROM fee_categories WHERE school_id = schools.school_id AND category_name = 'Library Fee')
LIMIT 10;

INSERT INTO `fee_categories` (`school_id`, `category_name`, `description`, `is_mandatory`, `status`)
SELECT school_id, 'Transport Fee', 'School bus transportation', 0, 'active'
FROM schools
WHERE NOT EXISTS (SELECT 1 FROM fee_categories WHERE school_id = schools.school_id AND category_name = 'Transport Fee')
LIMIT 10;

INSERT INTO `fee_categories` (`school_id`, `category_name`, `description`, `is_mandatory`, `status`)
SELECT school_id, 'Exam Fee', 'Examination fees', 1, 'active'
FROM schools
WHERE NOT EXISTS (SELECT 1 FROM fee_categories WHERE school_id = schools.school_id AND category_name = 'Exam Fee')
LIMIT 10;

-- ============================================================================
-- VIEWS FOR QUICK ACCESS
-- ============================================================================

-- Student fee summary view
CREATE OR REPLACE VIEW `student_fee_summary` AS
SELECT 
    s.student_id,
    s.first_name,
    s.last_name,
    c.class_name,
    sf.academic_year,
    SUM(sf.total_amount) as total_fees,
    SUM(sf.paid_amount) as total_paid,
    SUM(sf.discount_amount) as total_discounts,
    SUM(sf.late_fee_amount) as total_late_fees,
    SUM(sf.balance_amount) as total_balance,
    CASE 
        WHEN SUM(sf.balance_amount) = 0 THEN 'paid'
        WHEN SUM(sf.paid_amount) > 0 THEN 'partial'
        ELSE 'pending'
    END as payment_status
FROM students s
INNER JOIN classes c ON s.class_id = c.class_id
LEFT JOIN student_fees sf ON s.student_id = sf.student_id
WHERE s.status = 'active'
GROUP BY s.student_id, sf.academic_year;

-- Payment collection summary
CREATE OR REPLACE VIEW `daily_collection_summary` AS
SELECT 
    fp.payment_date,
    COUNT(DISTINCT fp.payment_id) as total_transactions,
    COUNT(DISTINCT fp.student_id) as students_paid,
    SUM(fp.amount) as total_collected,
    fp.payment_method,
    u.first_name as collected_by_name
FROM fee_payments fp
INNER JOIN users u ON fp.collected_by = u.user_id
WHERE fp.status = 'verified'
GROUP BY fp.payment_date, fp.payment_method, fp.collected_by
ORDER BY fp.payment_date DESC;

-- ============================================================================
-- STORED PROCEDURES
-- ============================================================================

DELIMITER //

-- Generate receipt number
DROP FUNCTION IF EXISTS generate_receipt_number//
CREATE FUNCTION generate_receipt_number(p_school_id INT)
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
    DECLARE v_year VARCHAR(4);
    DECLARE v_count INT;
    DECLARE v_receipt VARCHAR(50);
    
    SET v_year = YEAR(CURDATE());
    
    SELECT COUNT(*) + 1 INTO v_count
    FROM fee_payments
    WHERE YEAR(payment_date) = v_year;
    
    SET v_receipt = CONCAT('REC', p_school_id, '-', v_year, '-', LPAD(v_count, 6, '0'));
    
    RETURN v_receipt;
END//

-- Assign fees to student
DROP PROCEDURE IF EXISTS assign_fees_to_student//
CREATE PROCEDURE assign_fees_to_student(
    IN p_student_id INT,
    IN p_academic_year VARCHAR(20)
)
BEGIN
    DECLARE v_class_id INT;
    DECLARE v_school_id INT;
    
    -- Get student's class and school
    SELECT class_id, school_id INTO v_class_id, v_school_id
    FROM students WHERE student_id = p_student_id;
    
    -- Assign all active fee structures for this class
    INSERT INTO student_fees (student_id, structure_id, academic_year, total_amount, due_date, status)
    SELECT 
        p_student_id,
        fs.structure_id,
        p_academic_year,
        fs.amount,
        fs.due_date,
        'pending'
    FROM fee_structure fs
    WHERE fs.school_id = v_school_id
    AND fs.status = 'active'
    AND fs.academic_year = p_academic_year
    AND (fs.class_id = v_class_id OR fs.class_id IS NULL)
    AND NOT EXISTS (
        SELECT 1 FROM student_fees sf
        WHERE sf.student_id = p_student_id
        AND sf.structure_id = fs.structure_id
        AND sf.academic_year = p_academic_year
    );
    
    SELECT ROW_COUNT() as fees_assigned;
END//

-- Calculate late fees
DROP PROCEDURE IF EXISTS calculate_late_fees//
CREATE PROCEDURE calculate_late_fees()
BEGIN
    UPDATE student_fees sf
    INNER JOIN fee_structure fs ON sf.structure_id = fs.structure_id
    SET sf.late_fee_amount = CASE
        WHEN sf.due_date < CURDATE() 
        AND DATEDIFF(CURDATE(), sf.due_date) >= fs.late_fee_after_days
        AND sf.status IN ('pending', 'partial', 'overdue')
        THEN fs.late_fee_amount
        ELSE 0
    END,
    sf.status = CASE
        WHEN sf.due_date < CURDATE() AND sf.balance_amount > 0 THEN 'overdue'
        ELSE sf.status
    END
    WHERE sf.status IN ('pending', 'partial', 'overdue');
    
    SELECT ROW_COUNT() as records_updated;
END//

DELIMITER ;

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Update student fee status after payment
DELIMITER //

DROP TRIGGER IF EXISTS update_student_fee_after_payment//
CREATE TRIGGER update_student_fee_after_payment
AFTER INSERT ON fee_payments
FOR EACH ROW
BEGIN
    IF NEW.student_fee_id IS NOT NULL AND NEW.status = 'verified' THEN
        UPDATE student_fees
        SET 
            paid_amount = paid_amount + NEW.amount,
            status = CASE
                WHEN (paid_amount + NEW.amount) >= (total_amount + late_fee_amount - discount_amount) THEN 'paid'
                WHEN (paid_amount + NEW.amount) > 0 THEN 'partial'
                ELSE status
            END
        WHERE student_fee_id = NEW.student_fee_id;
    END IF;
END//

DELIMITER ;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT 'Fee management system created successfully!' as status;
SELECT 'Tables: fee_categories, fee_structure, student_fees, fee_payments, fee_discounts, student_discounts, fee_reminders' as tables_created;
SELECT 'Views: student_fee_summary, daily_collection_summary' as views_created;
SELECT 'Procedures: assign_fees_to_student, calculate_late_fees' as procedures_created;
SELECT 'Function: generate_receipt_number' as functions_created;
