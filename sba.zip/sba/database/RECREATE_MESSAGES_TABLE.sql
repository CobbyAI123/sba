-- ============================================================================
-- RECREATE MESSAGES TABLE WITH ALL COLUMNS
-- This will fix all missing column errors
-- ============================================================================

-- Step 1: Drop existing messages table (if you have no important messages)
-- WARNING: This deletes all existing messages!
DROP TABLE IF EXISTS `messages`;

-- Step 2: Create messages table with ALL columns
CREATE TABLE `messages` (
  `message_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `sender_id` INT(11) NOT NULL COMMENT 'User ID of sender',
  `recipient_id` INT(11) NULL COMMENT 'NULL for broadcast messages',
  `recipient_role` VARCHAR(50) NULL COMMENT 'For role-based broadcasts',
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `attachment` VARCHAR(255) NULL,
  `message_type` ENUM('personal', 'broadcast', 'announcement') DEFAULT 'personal',
  `priority` ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
  `read_status` ENUM('unread', 'read') DEFAULT 'unread',
  `replied_to` INT(11) NULL COMMENT 'If this is a reply, original message_id',
  `deleted_by_sender` TINYINT(1) DEFAULT 0,
  `deleted_by_recipient` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `read_at` TIMESTAMP NULL,
  PRIMARY KEY (`message_id`),
  KEY `idx_school_sender` (`school_id`, `sender_id`),
  KEY `idx_school_recipient` (`school_id`, `recipient_id`),
  KEY `idx_read_status` (`read_status`),
  KEY `idx_message_type` (`message_type`),
  KEY `idx_created_at` (`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Step 3: Create other supporting tables
CREATE TABLE IF NOT EXISTS `message_attachments` (
  `attachment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `message_id` INT(11) NOT NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_size` INT(11) NULL,
  `file_type` VARCHAR(50) NULL,
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attachment_id`),
  KEY `idx_message` (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `message_templates` (
  `template_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `created_by` INT(11) NOT NULL,
  `template_name` VARCHAR(100) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `category` VARCHAR(50) NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`template_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `sms_logs` (
  `sms_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NULL,
  `recipient_phone` VARCHAR(20) NOT NULL,
  `message` TEXT NOT NULL,
  `sms_type` VARCHAR(50) NULL,
  `status` ENUM('pending', 'sent', 'failed', 'delivered') DEFAULT 'pending',
  `gateway` VARCHAR(50) NULL,
  `gateway_response` TEXT NULL,
  `cost` DECIMAL(10,4) NULL,
  `sent_at` TIMESTAMP NULL,
  `delivered_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sms_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `email_logs` (
  `email_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NULL,
  `recipient_email` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `email_type` VARCHAR(50) NULL,
  `status` ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
  `sent_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`email_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Verification
SELECT '✅ Messages table recreated successfully!' as status;
SELECT 'All columns are now present!' as message;
DESCRIBE messages;
