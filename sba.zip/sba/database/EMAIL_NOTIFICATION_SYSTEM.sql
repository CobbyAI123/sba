-- =====================================================
-- EMAIL NOTIFICATION SYSTEM - DATABASE TABLES
-- Complete email management system
-- =====================================================

USE school_management_system;

-- =====================================================
-- TABLE 1: Email Queue
-- =====================================================

CREATE TABLE IF NOT EXISTS `email_queue` (
  `queue_id` INT(11) NOT NULL AUTO_INCREMENT,
  `to_email` VARCHAR(255) NOT NULL,
  `to_name` VARCHAR(255),
  `from_email` VARCHAR(255) NOT NULL,
  `from_name` VARCHAR(255),
  `subject` VARCHAR(500) NOT NULL,
  `body` TEXT NOT NULL,
  `is_html` TINYINT(1) DEFAULT 1,
  `attachments` TEXT COMMENT 'JSON array of attachments',
  `cc` TEXT COMMENT 'JSON array of CC emails',
  `bcc` TEXT COMMENT 'JSON array of BCC emails',
  `status` ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
  `retry_count` INT(11) DEFAULT 0,
  `error_message` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `sent_at` TIMESTAMP NULL,
  PRIMARY KEY (`queue_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE 2: Email Log
-- =====================================================

CREATE TABLE IF NOT EXISTS `email_log` (
  `log_id` INT(11) NOT NULL AUTO_INCREMENT,
  `to_email` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(500) NOT NULL,
  `status` ENUM('sent', 'failed', 'bounced') DEFAULT 'sent',
  `error_message` TEXT,
  `sent_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `idx_to_email` (`to_email`),
  KEY `idx_sent_at` (`sent_at`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE 3: Email Templates
-- =====================================================

CREATE TABLE IF NOT EXISTS `email_templates` (
  `template_id` INT(11) NOT NULL AUTO_INCREMENT,
  `template_name` VARCHAR(100) NOT NULL UNIQUE,
  `template_description` TEXT,
  `subject` VARCHAR(500) NOT NULL,
  `body` TEXT NOT NULL,
  `variables` TEXT COMMENT 'JSON array of available variables',
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `unique_name` (`template_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TABLE 4: SMTP Settings (extend settings table)
-- =====================================================

-- Add SMTP settings to existing settings table
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('smtp_host', 'smtp.gmail.com'),
('smtp_port', '587'),
('smtp_encryption', 'tls'),
('smtp_username', ''),
('smtp_password', ''),
('email_from', 'noreply@school.com'),
('email_from_name', 'School Management System')
ON DUPLICATE KEY UPDATE setting_key = setting_key;

-- =====================================================
-- DEFAULT EMAIL TEMPLATES
-- =====================================================

-- Template 1: Payment Confirmation
INSERT INTO `email_templates` 
(`template_name`, `template_description`, `subject`, `body`, `variables`) VALUES
('payment_confirmation', 
 'Sent after successful payment', 
 'Payment Confirmation - {{school_name}}',
 '<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #1E3A8A; color: white; padding: 20px; text-align: center; }
        .content { background: #F9FAFB; padding: 30px; }
        .amount { font-size: 32px; color: #059669; font-weight: bold; text-align: center; margin: 20px 0; }
        .details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .detail-row { display: flex; padding: 10px 0; border-bottom: 1px solid #E5E7EB; }
        .detail-label { width: 40%; font-weight: bold; }
        .detail-value { width: 60%; }
        .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        .button { display: inline-block; background: #1E3A8A; color: white; padding: 12px 30px; 
                 text-decoration: none; border-radius: 5px; margin: 20px 0; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Payment Received</h1>
        </div>
        <div class="content">
            <p>Dear Parent/Guardian,</p>
            <p>We have successfully received your payment for <strong>{{student_name}}</strong>.</p>
            
            <div class="amount">GH₵ {{amount}}</div>
            
            <div class="details">
                <div class="detail-row">
                    <div class="detail-label">Student Name:</div>
                    <div class="detail-value">{{student_name}}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">Admission Number:</div>
                    <div class="detail-value">{{admission_number}}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">Class:</div>
                    <div class="detail-value">{{class_name}}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">Amount:</div>
                    <div class="detail-value">{{amount}}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">Payment Date:</div>
                    <div class="detail-value">{{payment_date}}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">Payment Method:</div>
                    <div class="detail-value">{{payment_method}}</div>
                </div>
                <div class="detail-row">
                    <div class="detail-label">Reference:</div>
                    <div class="detail-value">{{reference}}</div>
                </div>
            </div>
            
            <div style="text-align: center;">
                <a href="{{receipt_link}}" class="button">Download Receipt</a>
            </div>
            
            <p>Thank you for your prompt payment!</p>
        </div>
        <div class="footer">
            <p>{{school_name}}<br>
            This is an automated email. Please do not reply.</p>
        </div>
    </div>
</body>
</html>',
 '["student_name", "admission_number", "class_name", "amount", "payment_date", "payment_method", "reference", "school_name", "receipt_link"]')
ON DUPLICATE KEY UPDATE template_name = template_name;

-- Template 2: Welcome Email
INSERT INTO `email_templates` 
(`template_name`, `template_description`, `subject`, `body`, `variables`) VALUES
('welcome_email', 
 'Sent to new users/parents',
 'Welcome to {{school_name}}',
 '<html>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: #1E3A8A; color: white; padding: 20px; text-align: center;">
            <h1>Welcome!</h1>
        </div>
        <div style="padding: 30px; background: #F9FAFB;">
            <p>Dear {{user_name}},</p>
            <p>Welcome to <strong>{{school_name}}</strong>!</p>
            <p>Your account has been created successfully.</p>
            <p><strong>Login Details:</strong><br>
            Username: {{username}}<br>
            Password: {{password}}</p>
            <p>Please login and change your password immediately.</p>
            <p><a href="{{login_url}}" style="background: #1E3A8A; color: white; padding: 12px 30px; 
               text-decoration: none; border-radius: 5px; display: inline-block;">Login Now</a></p>
        </div>
    </div>
</body>
</html>',
 '["user_name", "username", "password", "school_name", "login_url"]')
ON DUPLICATE KEY UPDATE template_name = template_name;

-- Template 3: Fee Reminder
INSERT INTO `email_templates` 
(`template_name`, `template_description`, `subject`, `body`, `variables`) VALUES
('fee_reminder', 
 'Reminder for pending fees',
 'Fee Payment Reminder - {{school_name}}',
 '<html>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2>Fee Payment Reminder</h2>
        <p>Dear Parent/Guardian,</p>
        <p>This is a friendly reminder that fees for <strong>{{student_name}}</strong> are pending.</p>
        <p><strong>Outstanding Amount:</strong> {{amount}}<br>
        <strong>Due Date:</strong> {{due_date}}</p>
        <p>Please make payment at your earliest convenience.</p>
        <p>Thank you for your cooperation.</p>
    </div>
</body>
</html>',
 '["student_name", "amount", "due_date", "school_name"]')
ON DUPLICATE KEY UPDATE template_name = template_name;

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

ALTER TABLE `email_queue` 
ADD INDEX IF NOT EXISTS `idx_status_created` (`status`, `created_at`);

ALTER TABLE `email_log` 
ADD INDEX IF NOT EXISTS `idx_to_status` (`to_email`, `status`);

-- =====================================================
-- SUCCESS MESSAGE
-- =====================================================

SELECT 
    '✅ EMAIL SYSTEM INSTALLED!' as Status,
    'Tables created successfully' as Message,
    '3 default templates added' as Templates,
    'SMTP settings ready for configuration' as SMTP,
    'Queue system ready' as Queue;

