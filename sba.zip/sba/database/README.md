# 📊 Database Documentation

## Overview

The SBA system uses MySQL database with **25+ normalized tables** for managing school operations.

---

## 🚀 Quick Start

### For Fresh Installation

1. **Create Database**
   ```sql
   CREATE DATABASE sba CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
   ```

2. **Import Main Schema**
   ```bash
   mysql -u root -p sba < schema.sql
   ```

3. **Optimize Performance (Optional but Recommended)**
   ```bash
   mysql -u root -p sba < optimize_indexes.sql
   ```

4. **Done!** Your database is ready.

---

## 📁 File Structure

```
database/
├── schema.sql              ⭐ Main database schema (IMPORT THIS)
├── optimize_indexes.sql    🚀 Performance indexes (Run after schema)
├── README.md               📖 This file
├── migrations/             📂 Future schema updates
│   └── (empty - for future use)
└── archive/                📂 Old migration files
    ├── fix_*.sql           (Historical fixes)
    ├── add_*.sql           (Historical additions)
    └── create_*.sql        (Historical table creations)
```

---

## 📋 Database Tables

### Core Tables (6)
| Table | Purpose | Records |
|-------|---------|---------|
| `schools` | School information | ~10-100 |
| `users` | All system users | ~100-10K |
| `classes` | Class definitions | ~10-50 |
| `subjects` | Subject catalog | ~20-100 |
| `academic_years` | Academic years | ~5-20 |
| `terms` | Academic terms | ~15-60 |

### Student Management (4)
| Table | Purpose | Records |
|-------|---------|---------|
| `students` | Student records | ~100-10K |
| `parents` | Parent information | ~100-10K |
| `student_parents` | Student-parent links | ~100-20K |
| `student_classes` | Class enrollment | ~100-10K |

### Academic Operations (5)
| Table | Purpose | Records |
|-------|---------|---------|
| `attendance` | Daily attendance | ~1K-1M |
| `exams` | Exam definitions | ~10-500 |
| `marks` | Student marks | ~1K-100K |
| `timetable` | Class schedules | ~50-1K |
| `class_subjects` | Subject assignments | ~50-500 |

### Financial Management (4)
| Table | Purpose | Records |
|-------|---------|---------|
| `fee_structure` | Fee configuration | ~10-200 |
| `payments` | Payment records | ~1K-100K |
| `transactions` | Financial transactions | ~1K-100K |
| `teacher_collections` | Teacher fee collections | ~1K-50K |

### Library System (3)
| Table | Purpose | Records |
|-------|---------|---------|
| `library_books` | Book catalog | ~100-10K |
| `library_transactions` | Book borrowing | ~1K-50K |
| `library_categories` | Book categories | ~10-50 |

### System Tables (4)
| Table | Purpose | Records |
|-------|---------|---------|
| `activity_logs` | Audit trail | ~1K-1M |
| `notifications` | User notifications | ~1K-100K |
| `settings` | System settings | ~10-100 |
| `login_attempts` | Security tracking | ~100-10K |

---

## 🔧 Maintenance Tasks

### Daily
```sql
-- Check database size
SELECT 
    table_schema as 'Database', 
    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as 'Size (MB)'
FROM information_schema.tables
WHERE table_schema = 'sba'
GROUP BY table_schema;
```

### Weekly
```sql
-- Backup database
-- Run from command line:
-- mysqldump -u root -p sba > backup_$(date +%Y%m%d).sql

-- Clear old login attempts (older than 30 days)
DELETE FROM login_attempts WHERE attempt_time < DATE_SUB(NOW(), INTERVAL 30 DAY);
```

### Monthly
```sql
-- Analyze tables for performance
ANALYZE TABLE students, attendance, payments, marks, exams;

-- Archive old activity logs (older than 6 months)
DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH);
```

### Yearly
```sql
-- Archive old academic year data
-- Create archive tables
CREATE TABLE students_archive_2025 LIKE students;
INSERT INTO students_archive_2025 SELECT * FROM students WHERE year_id = 5;

-- Archive completed terms
UPDATE terms SET status = 'archived' WHERE end_date < DATE_SUB(NOW(), INTERVAL 1 YEAR);
```

---

## 📊 Common Queries

### Student Queries
```sql
-- Get all active students in a class
SELECT * FROM students 
WHERE class_id = 5 AND status = 'active' 
ORDER BY first_name, last_name;

-- Count students by class
SELECT c.class_name, COUNT(s.student_id) as student_count
FROM classes c
LEFT JOIN students s ON c.class_id = s.class_id AND s.status = 'active'
WHERE c.school_id = 1
GROUP BY c.class_id;
```

### Attendance Queries
```sql
-- Today's attendance for a class
SELECT s.admission_number, s.first_name, s.last_name, a.status
FROM students s
LEFT JOIN attendance a ON s.student_id = a.student_id AND a.attendance_date = CURDATE()
WHERE s.class_id = 5;

-- Attendance percentage for a student
SELECT 
    COUNT(CASE WHEN status = 'present' THEN 1 END) * 100.0 / COUNT(*) as attendance_percentage
FROM attendance
WHERE student_id = 123
AND attendance_date BETWEEN '2026-01-01' AND '2026-03-31';
```

### Payment Queries
```sql
-- Total revenue for current month
SELECT SUM(amount) as monthly_revenue
FROM payments
WHERE school_id = 1
AND payment_date BETWEEN DATE_FORMAT(NOW(), '%Y-%m-01') AND LAST_DAY(NOW())
AND payment_status = 'completed';

-- Outstanding fees by student
SELECT 
    s.admission_number,
    CONCAT(s.first_name, ' ', s.last_name) as student_name,
    fs.amount as fee_amount,
    COALESCE(SUM(p.amount), 0) as paid_amount,
    fs.amount - COALESCE(SUM(p.amount), 0) as outstanding
FROM students s
JOIN fee_structure fs ON s.class_id = fs.class_id
LEFT JOIN payments p ON s.student_id = p.student_id AND p.fee_structure_id = fs.fee_structure_id
WHERE s.school_id = 1 AND s.status = 'active'
GROUP BY s.student_id, fs.fee_structure_id
HAVING outstanding > 0;
```

### Marks Queries
```sql
-- Student results for a term
SELECT 
    sub.subject_name,
    m.ca_score,
    m.midterm_score,
    m.exam_score,
    m.total_score,
    m.grade,
    m.remark
FROM marks m
JOIN subjects sub ON m.subject_id = sub.subject_id
WHERE m.student_id = 123 AND m.term_id = 1
ORDER BY sub.subject_name;

-- Class average by subject
SELECT 
    sub.subject_name,
    ROUND(AVG(m.total_score), 2) as class_average
FROM marks m
JOIN subjects sub ON m.subject_id = sub.subject_id
WHERE m.class_id = 5 AND m.term_id = 1
GROUP BY sub.subject_id
ORDER BY class_average DESC;
```

---

## 🚨 Troubleshooting

### Foreign Key Errors

**Problem:** Cannot insert/delete due to foreign key constraints

**Solution:**
```sql
-- Temporarily disable foreign key checks
SET FOREIGN_KEY_CHECKS=0;

-- Your operation here
-- ...

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS=1;
```

### Slow Queries

**Problem:** Queries taking too long

**Solutions:**
```sql
-- 1. Add missing indexes
-- Run optimize_indexes.sql

-- 2. Analyze tables
ANALYZE TABLE students, attendance, payments;

-- 3. Check query execution plan
EXPLAIN SELECT * FROM students WHERE school_id = 1 AND status = 'active';

-- 4. Enable query cache
SET GLOBAL query_cache_size = 1048576;
SET GLOBAL query_cache_type = ON;
```

### Database Connection Issues

**Problem:** Cannot connect to database

**Checklist:**
1. MySQL service is running
2. Correct host/username/password in `.env`
3. Database exists
4. User has privileges
5. Firewall allows connection

**Verify:**
```sql
-- Test connection
mysql -u root -p -h localhost

-- Show databases
SHOW DATABASES;

-- Check user privileges
SHOW GRANTS FOR 'your_user'@'localhost';
```

---

## 🔐 Security Best Practices

### User Privileges
```sql
-- Create limited database user (recommended for production)
CREATE USER 'sba_user'@'localhost' IDENTIFIED BY 'StrongPassword123!';
GRANT SELECT, INSERT, UPDATE, DELETE ON sba.* TO 'sba_user'@'localhost';
FLUSH PRIVILEGES;
```

### Backup Strategy
```bash
# Daily automated backup
0 2 * * * mysqldump -u root -p'password' sba | gzip > /backups/sba_$(date +\%Y\%m\%d).sql.gz

# Keep last 30 days of backups
find /backups -name "sba_*.sql.gz" -mtime +30 -delete
```

### Encryption
```sql
-- Enable SSL for MySQL connections (production)
-- Edit my.cnf:
[mysqld]
require_secure_transport=ON
ssl-ca=/path/to/ca.pem
ssl-cert=/path/to/server-cert.pem
ssl-key=/path/to/server-key.pem
```

---

## 📈 Performance Optimization

### Current Optimizations
✅ **Indexes on primary keys**
✅ **Indexes on foreign keys**
✅ **Indexes on frequently searched columns**
✅ **Composite indexes for complex queries**
✅ **Table analysis enabled**

### Additional Optimizations (Optional)

#### 1. Query Cache
```sql
-- Enable query cache (useful for read-heavy workloads)
SET GLOBAL query_cache_type = ON;
SET GLOBAL query_cache_size = 67108864; -- 64MB
```

#### 2. Connection Pooling
```ini
# In my.cnf
[mysqld]
max_connections = 200
thread_cache_size = 16
```

#### 3. InnoDB Optimization
```ini
# In my.cnf
[mysqld]
innodb_buffer_pool_size = 1G  # 70-80% of RAM
innodb_log_file_size = 256M
innodb_flush_log_at_trx_commit = 2
```

#### 4. Partitioning (For Large Tables)
```sql
-- Partition attendance table by year
ALTER TABLE attendance
PARTITION BY RANGE (YEAR(attendance_date)) (
    PARTITION p2024 VALUES LESS THAN (2025),
    PARTITION p2025 VALUES LESS THAN (2026),
    PARTITION p2026 VALUES LESS THAN (2027),
    PARTITION pmax VALUES LESS THAN MAXVALUE
);
```

---

## 📞 Support

For database-related issues:
1. Check this README
2. Review [TROUBLESHOOTING.md](../docs/TROUBLESHOOTING.md)
3. Check MySQL error logs
4. Open issue on GitHub

---

## 📝 Changelog

### v1.9.0 (January 2026)
- ✅ Consolidated schema.sql
- ✅ Added optimize_indexes.sql
- ✅ Created database README
- ✅ Archived old migrations
- ✅ Improved documentation

### v1.8.0 (December 2025)
- Enhanced payment tracking
- Added teacher collections
- Improved attendance system

### v1.7.0 (November 2025)
- Library system tables
- Communication system
- Audit logging enhancements

---

**Last Updated:** January 11, 2026  
**Database Version:** 1.9.0  
**Total Tables:** 25+  
**Status:** ✅ Production Ready
