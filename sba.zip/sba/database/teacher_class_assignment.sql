-- Teacher Class Assignment Table
-- This table tracks which teachers are assigned to which classes

CREATE TABLE IF NOT EXISTS `teacher_classes` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `school_id` INT NOT NULL,
    `teacher_id` INT NOT NULL,
    `class_id` INT NOT NULL,
    `is_class_teacher` BOOLEAN DEFAULT FALSE,
    `assigned_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_assignment` (`teacher_id`, `class_id`, `school_id`),
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`teacher_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
    FOREIGN KEY (`class_id`) REFERENCES `classes`(`class_id`) ON DELETE CASCADE
);

-- Add index for faster queries
CREATE INDEX idx_teacher_classes_school ON `teacher_classes`(`school_id`);
CREATE INDEX idx_teacher_classes_teacher ON `teacher_classes`(`teacher_id`);
CREATE INDEX idx_teacher_classes_class ON `teacher_classes`(`class_id`);
