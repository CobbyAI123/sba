-- Calculate Student Positions/Rankings
-- This procedure calculates position in class for each subject and overall position

DELIMITER $$

-- Drop if exists
DROP PROCEDURE IF EXISTS calculate_class_positions$$

-- Create procedure to calculate positions
CREATE PROCEDURE calculate_class_positions(
    IN p_school_id INT,
    IN p_term_id INT,
    IN p_class_id INT
)
BEGIN
    -- Calculate positions for each subject in the class
    UPDATE student_assessments sa1
    SET position = (
        SELECT COUNT(*) + 1
        FROM student_assessments sa2
        WHERE sa2.school_id = sa1.school_id
        AND sa2.term_id = sa1.term_id
        AND sa2.class_id = sa1.class_id
        AND sa2.subject_id = sa1.subject_id
        AND sa2.total_score > sa1.total_score
    )
    WHERE sa1.school_id = p_school_id
    AND sa1.term_id = p_term_id
    AND (p_class_id IS NULL OR sa1.class_id = p_class_id)
    AND sa1.total_score IS NOT NULL;
    
    SELECT CONCAT('Positions calculated for class_id: ', COALESCE(p_class_id, 'ALL')) as Result;
END$$

DELIMITER ;

-- Success message
SELECT 'Position calculation procedure created successfully!' as Result;

-- Example usage:
-- Calculate positions for all classes in term 1:
-- CALL calculate_class_positions(1, 1, NULL);

-- Calculate positions for specific class (class_id = 5) in term 1:
-- CALL calculate_class_positions(1, 1, 5);
