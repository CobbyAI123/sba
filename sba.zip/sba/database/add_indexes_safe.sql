-- Safe Index Creation Script
-- This script checks if indexes exist before creating them
-- Run this in phpMyAdmin SQL tab

-- For Students table
SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'students' 
               AND index_name = 'idx_school_class');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_school_class already exists''', 
                'ALTER TABLE students ADD INDEX idx_school_class (school_id, class_id)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'students' 
               AND index_name = 'idx_email');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_email already exists''', 
                'ALTER TABLE students ADD INDEX idx_email (email)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'students' 
               AND index_name = 'idx_admission');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_admission already exists''', 
                'ALTER TABLE students ADD INDEX idx_admission (admission_number)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

-- For Users table
SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'users' 
               AND index_name = 'idx_school_role');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_school_role already exists''', 
                'ALTER TABLE users ADD INDEX idx_school_role (school_id, role)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'users' 
               AND index_name = 'idx_email_users');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_email_users already exists''', 
                'ALTER TABLE users ADD INDEX idx_email_users (email)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'users' 
               AND index_name = 'idx_username');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_username already exists''', 
                'ALTER TABLE users ADD INDEX idx_username (username)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

-- For Classes table
SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'classes' 
               AND index_name = 'idx_school_status');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_school_status already exists''', 
                'ALTER TABLE classes ADD INDEX idx_school_status (school_id, status)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

-- For Subjects table
SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'subjects' 
               AND index_name = 'idx_school_status_subj');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_school_status_subj already exists''', 
                'ALTER TABLE subjects ADD INDEX idx_school_status_subj (school_id, status)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

-- For Attendance table
SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'attendance' 
               AND index_name = 'idx_student_date');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_student_date already exists''', 
                'ALTER TABLE attendance ADD INDEX idx_student_date (student_id, attendance_date)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'attendance' 
               AND index_name = 'idx_class_date');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_class_date already exists''', 
                'ALTER TABLE attendance ADD INDEX idx_class_date (class_id, attendance_date)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

-- For Class Subjects table
SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'class_subjects' 
               AND index_name = 'idx_class_subject');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_class_subject already exists''', 
                'ALTER TABLE class_subjects ADD INDEX idx_class_subject (class_id, subject_id)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'class_subjects' 
               AND index_name = 'idx_teacher');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_teacher already exists''', 
                'ALTER TABLE class_subjects ADD INDEX idx_teacher (teacher_id)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

-- For Activity Logs table
SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'activity_logs' 
               AND index_name = 'idx_user_date');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_user_date already exists''', 
                'ALTER TABLE activity_logs ADD INDEX idx_user_date (user_id, created_at)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'activity_logs' 
               AND index_name = 'idx_action');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_action already exists''', 
                'ALTER TABLE activity_logs ADD INDEX idx_action (action_type)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

-- For Notifications table
SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'notifications' 
               AND index_name = 'idx_user_read');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_user_read already exists''', 
                'ALTER TABLE notifications ADD INDEX idx_user_read (user_id, is_read)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

-- For Schools table
SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'schools' 
               AND index_name = 'idx_status_schools');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_status_schools already exists''', 
                'ALTER TABLE schools ADD INDEX idx_status_schools (status)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

SET @exist := (SELECT COUNT(*) FROM information_schema.statistics 
               WHERE table_schema = DATABASE() AND table_name = 'schools' 
               AND index_name = 'idx_code');
SET @sqlstmt := IF(@exist > 0, 'SELECT ''Index idx_code already exists''', 
                'ALTER TABLE schools ADD INDEX idx_code (school_code)');
PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;

SELECT 'Index creation completed! Check results above.' as Status;
