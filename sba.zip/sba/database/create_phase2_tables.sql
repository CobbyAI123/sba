-- ============================================================================
-- ANNOUNCEMENTS AND COMMUNICATION TABLES
-- ============================================================================

CREATE TABLE IF NOT EXISTS `announcements` (
    `announcement_id` INT AUTO_INCREMENT PRIMARY KEY,
    `school_id` INT NOT NULL,
    `class_id` INT,
    `title` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `sender_id` INT NOT NULL,
    `is_global` TINYINT DEFAULT 0,
    `priority` ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`class_id`) REFERENCES `classes`(`class_id`) ON DELETE CASCADE,
    FOREIGN KEY (`sender_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
    INDEX `idx_school` (`school_id`),
    INDEX `idx_class` (`class_id`),
    INDEX `idx_created` (`created_at`),
    INDEX `idx_priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Direct Messages Table
CREATE TABLE IF NOT EXISTS `direct_messages` (
    `message_id` INT AUTO_INCREMENT PRIMARY KEY,
    `school_id` INT NOT NULL,
    `from_user_id` INT NOT NULL,
    `to_user_id` INT NOT NULL,
    `subject` VARCHAR(255),
    `message` TEXT NOT NULL,
    `read_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`from_user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
    FOREIGN KEY (`to_user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
    INDEX `idx_school` (`school_id`),
    INDEX `idx_from` (`from_user_id`),
    INDEX `idx_to` (`to_user_id`),
    INDEX `idx_created` (`created_at`),
    INDEX `idx_read` (`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Newsletters Table
CREATE TABLE IF NOT EXISTS `newsletters` (
    `newsletter_id` INT AUTO_INCREMENT PRIMARY KEY,
    `school_id` INT NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `content` LONGTEXT NOT NULL,
    `sender_id` INT NOT NULL,
    `target_roles` JSON,
    `status` ENUM('draft', 'scheduled', 'sent', 'archived') DEFAULT 'draft',
    `scheduled_at` TIMESTAMP NULL,
    `sent_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`sender_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
    INDEX `idx_school` (`school_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_scheduled` (`scheduled_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- PREDICTIVE ANALYTICS TABLES
-- ============================================================================

CREATE TABLE IF NOT EXISTS `grade_predictions` (
    `prediction_id` INT AUTO_INCREMENT PRIMARY KEY,
    `school_id` INT NOT NULL,
    `student_id` INT NOT NULL,
    `subject_id` INT NOT NULL,
    `term_id` INT NOT NULL,
    `current_average` DECIMAL(5, 2),
    `predicted_final_grade` DECIMAL(5, 2),
    `confidence_level` DECIMAL(3, 1),
    `trend` ENUM('improving', 'stable', 'declining') DEFAULT 'stable',
    `risk_level` ENUM('low', 'medium', 'high') DEFAULT 'low',
    `recommendation` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
    FOREIGN KEY (`subject_id`) REFERENCES `subjects`(`subject_id`) ON DELETE CASCADE,
    FOREIGN KEY (`term_id`) REFERENCES `terms`(`term_id`) ON DELETE CASCADE,
    INDEX `idx_school` (`school_id`),
    INDEX `idx_student` (`student_id`),
    INDEX `idx_risk` (`risk_level`),
    INDEX `idx_trend` (`trend`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Performance History (for trend analysis)
CREATE TABLE IF NOT EXISTS `student_performance_history` (
    `history_id` INT AUTO_INCREMENT PRIMARY KEY,
    `school_id` INT NOT NULL,
    `student_id` INT NOT NULL,
    `term_id` INT NOT NULL,
    `overall_average` DECIMAL(5, 2),
    `subjects_count` INT,
    `grades_a_count` INT DEFAULT 0,
    `grades_b_count` INT DEFAULT 0,
    `grades_c_count` INT DEFAULT 0,
    `grades_d_count` INT DEFAULT 0,
    `grades_f_count` INT DEFAULT 0,
    `ranking` INT,
    `class_size` INT,
    `recorded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
    FOREIGN KEY (`term_id`) REFERENCES `terms`(`term_id`) ON DELETE CASCADE,
    INDEX `idx_school` (`school_id`),
    INDEX `idx_student` (`student_id`),
    INDEX `idx_term` (`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- DOCUMENT MANAGEMENT TABLES
-- ============================================================================

CREATE TABLE IF NOT EXISTS `documents` (
    `document_id` INT AUTO_INCREMENT PRIMARY KEY,
    `school_id` INT NOT NULL,
    `document_type` ENUM('transcript', 'certificate', 'admission_letter', 'report_card', 'custom') DEFAULT 'custom',
    `student_id` INT,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT,
    `file_path` VARCHAR(500),
    `file_name` VARCHAR(255),
    `file_size` INT,
    `mime_type` VARCHAR(100),
    `uploaded_by` INT,
    `issued_date` DATE,
    `expiry_date` DATE,
    `is_public` TINYINT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
    FOREIGN KEY (`uploaded_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
    INDEX `idx_school` (`school_id`),
    INDEX `idx_type` (`document_type`),
    INDEX `idx_student` (`student_id`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Document Access Log
CREATE TABLE IF NOT EXISTS `document_access_log` (
    `access_id` INT AUTO_INCREMENT PRIMARY KEY,
    `document_id` INT NOT NULL,
    `accessed_by` INT,
    `access_type` ENUM('view', 'download', 'share') DEFAULT 'view',
    `ip_address` VARCHAR(45),
    `accessed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`document_id`) REFERENCES `documents`(`document_id`) ON DELETE CASCADE,
    FOREIGN KEY (`accessed_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
    INDEX `idx_document` (`document_id`),
    INDEX `idx_accessed` (`accessed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- ALTER USERS TABLE TO SUPPORT 2FA
-- ============================================================================

ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `2fa_enabled` TINYINT DEFAULT 0;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `2fa_method` ENUM('email', 'sms') DEFAULT 'email';

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT '✓ Announcements and Communication tables created' as Status;
SELECT '✓ Predictive Analytics tables created' as Status;
SELECT '✓ Document Management tables created' as Status;
SELECT '✓ 2FA columns added to users table' as Status;
