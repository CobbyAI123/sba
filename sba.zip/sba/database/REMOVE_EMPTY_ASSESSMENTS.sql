-- ============================================
-- REMOVE EMPTY ASSESSMENT RECORDS
-- Deletes records where all scores are NULL
-- ============================================

-- First, check how many empty records exist
SELECT 
    COUNT(*) as empty_records,
    'Records with all NULL scores' as description
FROM student_assessments
WHERE ca_score IS NULL 
  AND midterm_score IS NULL 
  AND exam_score IS NULL;

-- Show the empty records before deletion
SELECT 
    assessment_id,
    student_id,
    subject_id,
    term_id,
    class_id,
    created_at
FROM student_assessments
WHERE ca_score IS NULL 
  AND midterm_score IS NULL 
  AND exam_score IS NULL
ORDER BY created_at DESC;

-- Delete empty records (all scores are NULL)
DELETE FROM student_assessments
WHERE ca_score IS NULL 
  AND midterm_score IS NULL 
  AND exam_score IS NULL;

-- Show confirmation
SELECT 
    COUNT(*) as remaining_records,
    'Total assessment records remaining' as description
FROM student_assessments;

SELECT 'SUCCESS: Empty assessment records removed!' as Status;
