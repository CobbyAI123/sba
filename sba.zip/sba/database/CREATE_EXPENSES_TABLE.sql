-- ============================================================================
-- CREATE expenses TABLE
-- For tracking school expenses and expenditures
-- Date: November 28, 2025
-- ============================================================================

CREATE TABLE IF NOT EXISTS `expenses` (
  `expense_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `expense_type` VARCHAR(100) NOT NULL COMMENT 'Staff Salary, Utilities, Maintenance, Supplies, Transport, Other',
  `description` TEXT NULL COMMENT 'Detailed description of the expense',
  `amount` DECIMAL(10,2) NOT NULL,
  `expense_date` DATE NOT NULL,
  `payment_method` ENUM('cash', 'bank_transfer', 'cheque', 'card', 'other') DEFAULT 'cash',
  `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  `vendor_name` VARCHAR(255) NULL COMMENT 'Supplier or service provider name',
  `invoice_number` VARCHAR(100) NULL COMMENT 'Invoice or receipt reference',
  `recorded_by` INT(11) NULL COMMENT 'User who recorded the expense',
  `approved_by` INT(11) NULL COMMENT 'User who approved the expense',
  `approved_at` TIMESTAMP NULL,
  `remarks` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`expense_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_expense_type` (`expense_type`),
  KEY `idx_status` (`status`),
  KEY `idx_expense_date` (`expense_date`),
  KEY `idx_recorded_by` (`recorded_by`),
  KEY `idx_approved_by` (`approved_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='School expenses and expenditures tracking';

-- ============================================================================
-- CREATE expense_categories TABLE (Optional - for managing expense types)
-- ============================================================================

CREATE TABLE IF NOT EXISTS `expense_categories` (
  `category_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `category_name` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`),
  KEY `idx_school` (`school_id`),
  UNIQUE KEY `unique_category` (`school_id`, `category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Expense categories for each school';

-- ============================================================================
-- INSERT DEFAULT EXPENSE CATEGORIES
-- ============================================================================

INSERT INTO `expense_categories` (`school_id`, `category_name`, `description`) 
SELECT DISTINCT school_id, 'Staff Salary', 'Salaries and wages for all staff members'
FROM schools 
WHERE NOT EXISTS (
  SELECT 1 FROM expense_categories 
  WHERE expense_categories.school_id = schools.school_id 
  AND category_name = 'Staff Salary'
);

INSERT INTO `expense_categories` (`school_id`, `category_name`, `description`) 
SELECT DISTINCT school_id, 'Utilities', 'Electricity, water, internet, phone bills'
FROM schools 
WHERE NOT EXISTS (
  SELECT 1 FROM expense_categories 
  WHERE expense_categories.school_id = schools.school_id 
  AND category_name = 'Utilities'
);

INSERT INTO `expense_categories` (`school_id`, `category_name`, `description`) 
SELECT DISTINCT school_id, 'Maintenance', 'Building repairs, equipment servicing'
FROM schools 
WHERE NOT EXISTS (
  SELECT 1 FROM expense_categories 
  WHERE expense_categories.school_id = schools.school_id 
  AND category_name = 'Maintenance'
);

INSERT INTO `expense_categories` (`school_id`, `category_name`, `description`) 
SELECT DISTINCT school_id, 'Supplies', 'Office supplies, cleaning materials, stationery'
FROM schools 
WHERE NOT EXISTS (
  SELECT 1 FROM expense_categories 
  WHERE expense_categories.school_id = schools.school_id 
  AND category_name = 'Supplies'
);

INSERT INTO `expense_categories` (`school_id`, `category_name`, `description`) 
SELECT DISTINCT school_id, 'Transport', 'Vehicle fuel, maintenance, school bus expenses'
FROM schools 
WHERE NOT EXISTS (
  SELECT 1 FROM expense_categories 
  WHERE expense_categories.school_id = schools.school_id 
  AND category_name = 'Transport'
);

INSERT INTO `expense_categories` (`school_id`, `category_name`, `description`) 
SELECT DISTINCT school_id, 'Food & Catering', 'Canteen supplies, student meals, events'
FROM schools 
WHERE NOT EXISTS (
  SELECT 1 FROM expense_categories 
  WHERE expense_categories.school_id = schools.school_id 
  AND category_name = 'Food & Catering'
);

INSERT INTO `expense_categories` (`school_id`, `category_name`, `description`) 
SELECT DISTINCT school_id, 'Insurance', 'Building insurance, liability insurance'
FROM schools 
WHERE NOT EXISTS (
  SELECT 1 FROM expense_categories 
  WHERE expense_categories.school_id = schools.school_id 
  AND category_name = 'Insurance'
);

INSERT INTO `expense_categories` (`school_id`, `category_name`, `description`) 
SELECT DISTINCT school_id, 'Other', 'Miscellaneous expenses not in other categories'
FROM schools 
WHERE NOT EXISTS (
  SELECT 1 FROM expense_categories 
  WHERE expense_categories.school_id = schools.school_id 
  AND category_name = 'Other'
);

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT '✅ expenses table created' AS status;

SELECT 
  'expenses' as table_name,
  COUNT(*) as record_count 
FROM expenses;

SELECT 
  'expense_categories' as table_name,
  COUNT(*) as record_count 
FROM expense_categories;

SELECT '
╔═══════════════════════════════════════════════════════════════╗
║         ✅ EXPENSES MANAGEMENT TABLES CREATED!                ║
╠═══════════════════════════════════════════════════════════════╣
║ • expenses table created with full tracking                  ║
║ • expense_categories table created                           ║
║ • Default categories added for all schools                   ║
║ • Ready for expense management                               ║
╠═══════════════════════════════════════════════════════════════╣
║ FEATURES:                                                     ║
║ • Track all school expenses                                  ║
║ • Categorize expenses by type                                ║
║ • Approval workflow (pending → approved/rejected)            ║
║ • Link to vendors and invoices                               ║
║ • Full audit trail                                           ║
║ • Date-based filtering                                       ║
╠═══════════════════════════════════════════════════════════════╣
║ NEXT STEPS:                                                   ║
║ • Go to: Accountant → Expenses Management                    ║
║ • Click "Record Expense"                                     ║
║ • Start tracking your school expenses!                       ║
╚═══════════════════════════════════════════════════════════════╝
' AS SUCCESS;
