-- ================================================================================
-- ADD MISSING COLUMNS TO ATTENDANCE_LOGS TABLE
-- Date: November 17, 2025
-- Purpose: Add notes, time_in, time_out and other missing columns for bulk attendance functionality
-- ================================================================================

-- Add time_in column (if not exists)
ALTER TABLE `attendance_logs` 
ADD COLUMN IF NOT EXISTS `time_in` TIME NULL 
COMMENT 'Time when student checked in'
AFTER `status`;

-- Add time_out column (if not exists)
ALTER TABLE `attendance_logs` 
ADD COLUMN IF NOT EXISTS `time_out` TIME NULL 
COMMENT 'Time when student checked out'
AFTER `time_in`;

-- Add marking_method column (if not exists)
ALTER TABLE `attendance_logs` 
ADD COLUMN IF NOT EXISTS `marking_method` VARCHAR(20) DEFAULT 'manual' 
COMMENT 'Method of attendance marking (manual, qr_scan, bulk)'
AFTER `time_out`;

-- Add notes column
ALTER TABLE `attendance_logs` 
ADD COLUMN IF NOT EXISTS `notes` TEXT NULL 
COMMENT 'Additional notes or comments about attendance'
AFTER `marking_method`;

-- Add parent_notified column (if not exists)
ALTER TABLE `attendance_logs` 
ADD COLUMN IF NOT EXISTS `parent_notified` TINYINT(1) DEFAULT 0 
COMMENT 'Whether parent has been notified'
AFTER `notes`;

-- Add notification_sent_at column (if not exists)
ALTER TABLE `attendance_logs` 
ADD COLUMN IF NOT EXISTS `notification_sent_at` TIMESTAMP NULL DEFAULT NULL
COMMENT 'When parent notification was sent'
AFTER `parent_notified`;

-- Success message
SELECT 'All missing columns added to attendance_logs table successfully!' as Result;
