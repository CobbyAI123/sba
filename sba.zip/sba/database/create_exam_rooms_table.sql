-- ================================================================================
-- CREATE EXAM_ROOMS TABLE
-- Date: November 17, 2025
-- ================================================================================

CREATE TABLE IF NOT EXISTS `exam_rooms` (
  `room_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `room_name` VARCHAR(100) NOT NULL,
  `room_number` VARCHAR(50) DEFAULT NULL,
  `building` VARCHAR(100) DEFAULT NULL,
  `capacity` INT(11) DEFAULT 0,
  `location` VARCHAR(255) DEFAULT NULL,
  `facilities` TEXT DEFAULT NULL,
  `status` ENUM('available', 'occupied', 'maintenance', 'inactive') DEFAULT 'available',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`room_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Success message
SELECT 'exam_rooms table created successfully!' as Result;
