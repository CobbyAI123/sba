-- ============================================
-- FIX ASSIGNMENT SUBMISSION FILE PATHS
-- Updates old file paths to include full path
-- ============================================

-- Fix file paths that are missing the /uploads/assignments/ prefix
-- This updates submissions where file_path is just a filename

UPDATE assignment_submissions 
SET file_path = CONCAT('/uploads/assignments/', file_path)
WHERE file_path IS NOT NULL 
  AND file_path NOT LIKE '/%'
  AND file_path != '';

-- Verify the update
SELECT 
    submission_id,
    student_id,
    file_path,
    submitted_at
FROM assignment_submissions
WHERE file_path IS NOT NULL
ORDER BY submission_id DESC
LIMIT 10;

SELECT 'SUCCESS: File paths updated!' as Status;
