-- ============================================================================
-- FIX SCHOOLS TABLE - Add Missing Columns
-- This fixes the "Unknown column 'motto' in 'field list'" error
-- Date: November 16, 2025
-- ============================================================================

USE school_management_system;

-- Add motto column (if not exists)
SET @sql = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE schools ADD COLUMN motto TEXT NULL AFTER country',
        'SELECT "Column motto already exists" AS message'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = 'school_management_system'
    AND TABLE_NAME = 'schools'
    AND COLUMN_NAME = 'motto'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add website column (if not exists)
SET @sql = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE schools ADD COLUMN website VARCHAR(255) NULL AFTER motto',
        'SELECT "Column website already exists" AS message'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = 'school_management_system'
    AND TABLE_NAME = 'schools'
    AND COLUMN_NAME = 'website'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add established_date column (if not exists)
SET @sql = (
    SELECT IF(
        COUNT(*) = 0,
        'ALTER TABLE schools ADD COLUMN established_date DATE NULL AFTER website',
        'SELECT "Column established_date already exists" AS message'
    )
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = 'school_management_system'
    AND TABLE_NAME = 'schools'
    AND COLUMN_NAME = 'established_date'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Verify columns were added
SELECT 
    COLUMN_NAME,
    COLUMN_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = 'school_management_system'
AND TABLE_NAME = 'schools'
AND COLUMN_NAME IN ('motto', 'established_date')
ORDER BY ORDINAL_POSITION;

SELECT 'Schools table fixed successfully! You can now add schools.' AS status;
