-- ============================================
-- FIX STUDENT RECORDS
-- Run this if students can't see their data
-- ============================================

USE school_management_system;

-- 1. Check which students are missing records
SELECT 
    u.user_id,
    u.username,
    u.first_name,
    u.last_name,
    u.email,
    CASE 
        WHEN s.student_id IS NULL THEN '❌ MISSING STUDENT RECORD'
        WHEN s.class_id IS NULL THEN '⚠️ NO CLASS ASSIGNED'
        WHEN s.admission_number IS NULL THEN '⚠️ NO ADMISSION NUMBER'
        ELSE '✓ OK'
    END as status
FROM users u
LEFT JOIN students s ON u.user_id = s.user_id
WHERE u.role = 'student'
ORDER BY status DESC, u.user_id;

-- 2. Check students without classes
SELECT 
    s.student_id,
    u.first_name,
    u.last_name,
    s.admission_number,
    s.class_id,
    '⚠️ No class assigned' as issue
FROM students s
INNER JOIN users u ON s.user_id = u.user_id
WHERE s.class_id IS NULL OR s.class_id = 0;

-- 3. Check students without admission numbers
SELECT 
    s.student_id,
    u.first_name,
    u.last_name,
    s.admission_number,
    '⚠️ No admission number' as issue
FROM students s
INNER JOIN users u ON s.user_id = u.user_id
WHERE s.admission_number IS NULL OR s.admission_number = '';

-- 4. Count issues
SELECT 
    COUNT(CASE WHEN s.student_id IS NULL THEN 1 END) as missing_student_records,
    COUNT(CASE WHEN s.class_id IS NULL THEN 1 END) as missing_class_assignment,
    COUNT(CASE WHEN s.admission_number IS NULL OR s.admission_number = '' THEN 1 END) as missing_admission_number
FROM users u
LEFT JOIN students s ON u.user_id = s.user_id
WHERE u.role = 'student';

-- ============================================
-- INSTRUCTIONS TO FIX
-- ============================================

-- If you see "MISSING STUDENT RECORD":
-- Go to Admin → Students → Add Student
-- Create student record for that user

-- If you see "NO CLASS ASSIGNED":
-- Go to Admin → Students → Edit Student
-- Assign a class to the student

-- If you see "NO ADMISSION NUMBER":
-- This should auto-generate, but you can manually set it:
-- UPDATE students SET admission_number = 'ADM001' WHERE student_id = X;

-- ============================================
