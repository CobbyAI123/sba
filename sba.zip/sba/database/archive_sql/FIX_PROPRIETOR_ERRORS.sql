-- ============================================
-- FIX PROPRIETOR PORTAL ERRORS
-- Adds missing columns to fix all errors
-- ============================================

-- 1. Add payment_method column to payments and transactions tables
ALTER TABLE `payments` 
ADD COLUMN IF NOT EXISTS `payment_method` enum('cash','bank_transfer','cheque','card','mobile_money','other') DEFAULT 'cash' AFTER `amount`;

ALTER TABLE `transactions` 
ADD COLUMN IF NOT EXISTS `payment_method` enum('cash','bank_transfer','cheque','card','mobile_money','other') DEFAULT 'cash' AFTER `amount`;

-- 2. Add photo column to students table
ALTER TABLE `students` 
ADD COLUMN IF NOT EXISTS `photo` varchar(255) DEFAULT NULL AFTER `status`;

-- 3. Check if attendance table exists and add status column
CREATE TABLE IF NOT EXISTS `attendance` (
  `attendance_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` enum('present','absent','late','excused') DEFAULT 'present',
  `remarks` text DEFAULT NULL,
  `marked_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attendance_id`),
  UNIQUE KEY `unique_attendance` (`student_id`,`date`),
  KEY `student_id` (`student_id`),
  KEY `class_id` (`class_id`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add status column if table exists but column doesn't
ALTER TABLE `attendance` 
ADD COLUMN IF NOT EXISTS `status` enum('present','absent','late','excused') DEFAULT 'present' AFTER `date`;

-- 4. Verify changes
SELECT 'Checking transactions table...' as Step;
SHOW COLUMNS FROM transactions LIKE 'payment_method';

SELECT 'Checking students table...' as Step;
SHOW COLUMNS FROM students LIKE 'photo';

SELECT 'Checking attendance table...' as Step;
SHOW COLUMNS FROM attendance LIKE 'status';

SELECT 'SUCCESS: All columns added!' as Status;
