-- =====================================================
-- FIX DELETED_PAYMENTS TABLE
-- Fixes the "original_created_at column not found" error
-- =====================================================

USE school_management_system;

-- Check if deleted_payments table exists, if not create it
CREATE TABLE IF NOT EXISTS `deleted_payments` (
  `deleted_payment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `payment_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_date` DATE NOT NULL,
  `payment_method` VARCHAR(50) DEFAULT NULL,
  `payment_reference` VARCHAR(100) DEFAULT NULL,
  `payment_type` VARCHAR(50) DEFAULT 'tuition' COMMENT 'tuition, canteen, bus, library, sports, etc',
  `term_id` INT(11) DEFAULT NULL,
  `status` VARCHAR(20) DEFAULT 'completed',
  `remarks` TEXT DEFAULT NULL,
  `deleted_by` INT(11) NOT NULL,
  `deleted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`deleted_payment_id`),
  KEY `school_id` (`school_id`),
  KEY `student_id` (`student_id`),
  KEY `deleted_by` (`deleted_by`),
  KEY `deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Success message
SELECT 'Deleted payments table structure fixed successfully!' AS Result;
