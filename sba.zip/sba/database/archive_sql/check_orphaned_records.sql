-- ============================================================================
-- CHECK FOR ORPHANED RECORDS
-- Run this BEFORE adding CASCADE DELETE to see if you have data issues
-- ============================================================================

-- This script checks for records that reference non-existent students
-- These orphaned records will prevent foreign key creation

-- ============================================================================
-- ORPHANED PAYMENTS
-- ============================================================================

SELECT 
    'Orphaned Payments' as record_type,
    COUNT(*) as orphaned_count
FROM payments p
LEFT JOIN students s ON p.student_id = s.student_id
WHERE s.student_id IS NULL;

-- Show details of orphaned payments
SELECT 
    p.payment_id,
    p.student_id,
    p.amount,
    p.payment_date,
    'Student does not exist' as issue
FROM payments p
LEFT JOIN students s ON p.student_id = s.student_id
WHERE s.student_id IS NULL
LIMIT 10;

-- ============================================================================
-- ORPHANED ASSESSMENTS
-- ============================================================================

SELECT 
    'Orphaned Assessments' as record_type,
    COUNT(*) as orphaned_count
FROM student_assessments sa
LEFT JOIN students s ON sa.student_id = s.student_id
WHERE s.student_id IS NULL;

-- Show details
SELECT 
    sa.assessment_id,
    sa.student_id,
    sa.total_score,
    'Student does not exist' as issue
FROM student_assessments sa
LEFT JOIN students s ON sa.student_id = s.student_id
WHERE s.student_id IS NULL
LIMIT 10;

-- ============================================================================
-- ORPHANED ATTENDANCE
-- ============================================================================

SELECT 
    'Orphaned Attendance' as record_type,
    COUNT(*) as orphaned_count
FROM attendance a
LEFT JOIN students s ON a.student_id = s.student_id
WHERE s.student_id IS NULL;

-- ============================================================================
-- ORPHANED PARENT LINKS
-- ============================================================================

SELECT 
    'Orphaned Parent Links' as record_type,
    COUNT(*) as orphaned_count
FROM student_parents sp
LEFT JOIN students s ON sp.student_id = s.student_id
WHERE s.student_id IS NULL;

-- ============================================================================
-- ORPHANED TRANSACTIONS
-- ============================================================================

SELECT 
    'Orphaned Transactions' as record_type,
    COUNT(*) as orphaned_count
FROM transactions t
LEFT JOIN students s ON t.student_id = s.student_id
WHERE s.student_id IS NULL;

-- ============================================================================
-- SUMMARY
-- ============================================================================

SELECT 
    'Total Orphaned Records' as summary,
    (
        (SELECT COUNT(*) FROM payments p LEFT JOIN students s ON p.student_id = s.student_id WHERE s.student_id IS NULL) +
        (SELECT COUNT(*) FROM student_assessments sa LEFT JOIN students s ON sa.student_id = s.student_id WHERE s.student_id IS NULL) +
        (SELECT COUNT(*) FROM attendance a LEFT JOIN students s ON a.student_id = s.student_id WHERE s.student_id IS NULL) +
        (SELECT COUNT(*) FROM student_parents sp LEFT JOIN students s ON sp.student_id = s.student_id WHERE s.student_id IS NULL) +
        (SELECT COUNT(*) FROM transactions t LEFT JOIN students s ON t.student_id = s.student_id WHERE s.student_id IS NULL)
    ) as total_orphaned;

-- ============================================================================
-- INTERPRETATION
-- ============================================================================

-- If total_orphaned = 0: ✅ Safe to add CASCADE DELETE constraints
-- If total_orphaned > 0: ⚠️ Clean up orphaned records first

-- To clean up orphaned records, run:
-- DELETE p FROM payments p LEFT JOIN students s ON p.student_id = s.student_id WHERE s.student_id IS NULL;
-- DELETE sa FROM student_assessments sa LEFT JOIN students s ON sa.student_id = s.student_id WHERE s.student_id IS NULL;
-- DELETE a FROM attendance a LEFT JOIN students s ON a.student_id = s.student_id WHERE s.student_id IS NULL;
-- DELETE sp FROM student_parents sp LEFT JOIN students s ON sp.student_id = s.student_id WHERE s.student_id IS NULL;
-- DELETE t FROM transactions t LEFT JOIN students s ON t.student_id = s.student_id WHERE s.student_id IS NULL;

-- ============================================================================
