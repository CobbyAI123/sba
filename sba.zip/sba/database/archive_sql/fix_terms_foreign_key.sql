-- Fix Terms Table Foreign Key Constraint
-- This removes the old foreign key and adds missing columns

-- Step 1: Drop the foreign key constraint
SET @constraint_name = (
    SELECT CONSTRAINT_NAME 
    FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'terms' 
    AND REFERENCED_TABLE_NAME = 'academic_years'
    LIMIT 1
);

SET @sql = IF(@constraint_name IS NOT NULL,
    CONCAT('ALTER TABLE `terms` DROP FOREIGN KEY `', @constraint_name, '`'),
    'SELECT "No foreign key constraint found"');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Step 2: Make year_id nullable (if it exists)
SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE table_schema = DATABASE() AND table_name = 'terms' AND column_name = 'year_id');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE `terms` MODIFY COLUMN `year_id` INT NULL',
    'SELECT "year_id column does not exist"');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Step 3: Make term_number nullable (if it exists)
SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE table_schema = DATABASE() AND table_name = 'terms' AND column_name = 'term_number');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE `terms` MODIFY COLUMN `term_number` INT NULL',
    'SELECT "term_number column does not exist"');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Step 4: Add session_year if missing
ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `session_year` VARCHAR(20) NULL AFTER `term_name`;

-- Step 5: Add is_active if missing (or rename is_current)
SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE table_schema = DATABASE() AND table_name = 'terms' AND column_name = 'is_current');
SET @sql = IF(@col_exists > 0,
    'ALTER TABLE `terms` CHANGE COLUMN `is_current` `is_active` TINYINT(1) DEFAULT 0',
    'SELECT "is_current does not exist"');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) DEFAULT 0;

-- Step 6: Update existing records
UPDATE `terms` SET `session_year` = '2024/2025' WHERE `session_year` IS NULL OR `session_year` = '';
UPDATE `terms` SET `is_active` = 0 WHERE `is_active` IS NULL;

-- Step 7: Add indexes
ALTER TABLE `terms` ADD INDEX IF NOT EXISTS `idx_school_active` (`school_id`, `is_active`);
ALTER TABLE `terms` ADD INDEX IF NOT EXISTS `idx_session` (`session_year`);

SELECT 'Terms table fixed successfully!' as Result;
