-- ============================================================================
-- FIXED ASSIGNMENT SYSTEM
-- Compatible with existing database structure
-- Date: November 11, 2025
-- ============================================================================

-- Assignments Table
CREATE TABLE IF NOT EXISTS `assignments` (
  `assignment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `teacher_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `assignment_type` ENUM('homework', 'project', 'classwork', 'research', 'quiz') DEFAULT 'homework',
  `total_marks` INT(3) DEFAULT 100,
  `due_date` DATE NOT NULL,
  `due_time` TIME NULL,
  `submission_type` ENUM('online', 'offline', 'both') DEFAULT 'online',
  `allow_late_submission` TINYINT(1) DEFAULT 0,
  `late_penalty_percentage` INT(3) DEFAULT 10,
  `attachment` VARCHAR(255) NULL,
  `status` ENUM('draft', 'published', 'closed') DEFAULT 'published',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`assignment_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_teacher` (`teacher_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_due_date` (`due_date`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Assignment Submissions Table
CREATE TABLE IF NOT EXISTS `assignment_submissions` (
  `submission_id` INT(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `submission_text` TEXT NULL,
  `attachment` VARCHAR(255) NULL,
  `submitted_at` TIMESTAMP NULL,
  `is_late` TINYINT(1) DEFAULT 0,
  `status` ENUM('not_submitted', 'submitted', 'graded', 'returned') DEFAULT 'not_submitted',
  `marks_obtained` INT(3) NULL,
  `feedback` TEXT NULL,
  `graded_by` INT(11) NULL,
  `graded_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`submission_id`),
  UNIQUE KEY `idx_assignment_student` (`assignment_id`, `student_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_status` (`status`),
  KEY `idx_submitted_at` (`submitted_at` DESC),
  KEY `idx_is_late` (`is_late`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Assignment Attachments Table
CREATE TABLE IF NOT EXISTS `assignment_attachments` (
  `attachment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` INT(11) NULL,
  `submission_id` INT(11) NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_size` INT(11) NULL,
  `file_type` VARCHAR(50) NULL,
  `uploaded_by` INT(11) NOT NULL,
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attachment_id`),
  KEY `idx_assignment` (`assignment_id`),
  KEY `idx_submission` (`submission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Assignment Comments Table
CREATE TABLE IF NOT EXISTS `assignment_comments` (
  `comment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` INT(11) NULL,
  `submission_id` INT(11) NULL,
  `user_id` INT(11) NOT NULL,
  `comment` TEXT NOT NULL,
  `is_private` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`),
  KEY `idx_assignment` (`assignment_id`),
  KEY `idx_submission` (`submission_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Assignment Reminders Table
CREATE TABLE IF NOT EXISTS `assignment_reminders` (
  `reminder_id` INT(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `reminder_type` ENUM('due_soon', 'overdue', 'graded', 'returned') NOT NULL,
  `sent_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `notification_method` ENUM('in_app', 'sms', 'email', 'all') DEFAULT 'in_app',
  PRIMARY KEY (`reminder_id`),
  KEY `idx_assignment` (`assignment_id`),
  KEY `idx_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT 'Assignment system tables created successfully!' as status;
SELECT 'Tables: assignments, assignment_submissions, assignment_attachments, assignment_comments, assignment_reminders' as info;
SELECT 'Note: Views and stored procedures skipped - will work without them' as note;
