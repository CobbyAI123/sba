-- Fix terms table - Add missing school_id column if it doesn't exist

-- First, check if the column exists and add it if missing
ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `school_id` int(11) NOT NULL AFTER `term_id`;

-- Add index for school_id if not exists
ALTER TABLE `terms` 
ADD INDEX IF NOT EXISTS `school_id` (`school_id`);

-- Now insert sample terms (will work after adding school_id)
INSERT INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) VALUES
(1, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1),
(1, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0),
(1, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0)
ON DUPLICATE KEY UPDATE term_name=term_name;
