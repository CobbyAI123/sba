-- ============================================
-- QUICK FIX - Essential Columns Only
-- Run this if the full migration fails
-- ============================================

USE school_management_system;

-- 1. Add results_published to terms (ESSENTIAL for publish feature)
ALTER TABLE terms ADD COLUMN results_published TINYINT(1) DEFAULT 0;

-- 2. Add class_teacher_id to classes (for class teacher feature)
ALTER TABLE classes ADD COLUMN class_teacher_id INT(11) DEFAULT NULL;

-- 3. Add temp_password to users (for show credentials feature)
ALTER TABLE users ADD COLUMN temp_password VARCHAR(255) DEFAULT NULL;

-- 4. Create student_results_view table (for hierarchical results)
CREATE TABLE IF NOT EXISTS student_results_view (
    view_id INT(11) AUTO_INCREMENT PRIMARY KEY,
    student_id INT(11) NOT NULL,
    term_id INT(11) NOT NULL,
    session_year VARCHAR(20),
    term_name VARCHAR(50),
    total_subjects INT(11) DEFAULT 0,
    average_score DECIMAL(5,2) DEFAULT 0,
    published TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Create assignment_files table (for file uploads)
CREATE TABLE IF NOT EXISTS assignment_files (
    file_id INT(11) AUTO_INCREMENT PRIMARY KEY,
    assignment_id INT(11) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(50),
    file_size INT(11),
    uploaded_by INT(11),
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Done!
SELECT 'Essential columns added successfully!' as Status;
