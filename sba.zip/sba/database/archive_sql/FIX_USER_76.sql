-- ============================================
-- FIX SPECIFIC USER 76
-- Quick fix for the reported issue
-- ============================================

USE school_management_system;

-- 1. Check current status of user 76
SELECT 
    u.user_id,
    u.username,
    u.first_name,
    u.last_name,
    u.email,
    u.school_id,
    u.role,
    s.student_id,
    s.admission_number,
    s.class_id,
    CASE 
        WHEN s.student_id IS NULL THEN '❌ Student record missing'
        WHEN s.class_id IS NULL THEN '⚠️ No class assigned'
        ELSE '✓ OK'
    END as status
FROM users u
LEFT JOIN students s ON u.user_id = s.user_id
WHERE u.user_id = 76;

-- 2. Get available classes for school 11
SELECT 
    class_id,
    class_name,
    'Available for assignment' as note
FROM classes 
WHERE school_id = 11
ORDER BY class_name;

-- 3. Create student record for user 76 (if missing)
INSERT INTO students (
    user_id,
    school_id,
    admission_number,
    class_id,
    status
)
SELECT 
    76 as user_id,
    11 as school_id,
    'ADM1100076' as admission_number,
    (SELECT class_id FROM classes WHERE school_id = 11 ORDER BY class_id LIMIT 1) as class_id,
    'active' as status
FROM DUAL
WHERE NOT EXISTS (
    SELECT 1 FROM students WHERE user_id = 76
);

-- 4. Verify the fix
SELECT 
    u.user_id,
    u.username,
    CONCAT(u.first_name, ' ', u.last_name) as name,
    s.student_id,
    s.admission_number,
    c.class_name,
    s.status,
    '✓ FIXED - Student can now login' as result
FROM users u
INNER JOIN students s ON u.user_id = s.user_id
LEFT JOIN classes c ON s.class_id = c.class_id
WHERE u.user_id = 76;

-- 5. If no classes exist for school 11, show this message
SELECT 
    CASE 
        WHEN COUNT(*) = 0 THEN '⚠️ WARNING: No classes found for school 11. Create classes first!'
        ELSE CONCAT('✓ ', COUNT(*), ' classes available for school 11')
    END as class_status
FROM classes 
WHERE school_id = 11;
