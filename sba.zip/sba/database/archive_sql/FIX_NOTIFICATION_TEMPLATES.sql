-- ============================================================================
-- FIX NOTIFICATION TEMPLATES
-- Insert templates for actual schools in database
-- ============================================================================

-- ============================================================================
-- INSERT DEFAULT TEMPLATES FOR ALL SCHOOLS
-- ============================================================================

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
SELECT 
    s.school_id,
    'Student Absence Alert',
    CONCAT('ABSENCE_ALERT_', s.school_id),
    'all',
    'Student Absent Today',
    'Dear Parent, {STUDENT_NAME} was marked absent on {DATE}. Please contact the school if this is incorrect.',
    'attendance',
    1
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM notification_templates 
    WHERE template_code = CONCAT('ABSENCE_ALERT_', s.school_id)
);

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
SELECT 
    s.school_id,
    'Late Arrival Notice',
    CONCAT('LATE_ARRIVAL_', s.school_id),
    'all',
    'Student Arrived Late',
    '{STUDENT_NAME} arrived late to school today at {TIME}. Please ensure timely arrival.',
    'attendance',
    1
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM notification_templates 
    WHERE template_code = CONCAT('LATE_ARRIVAL_', s.school_id)
);

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
SELECT 
    s.school_id,
    'Low Attendance Warning',
    CONCAT('LOW_ATTENDANCE_', s.school_id),
    'all',
    'Low Attendance Alert',
    'Dear Parent, {STUDENT_NAME} attendance is {PERCENTAGE}% which is below the required threshold. Please ensure regular attendance.',
    'attendance',
    1
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM notification_templates 
    WHERE template_code = CONCAT('LOW_ATTENDANCE_', s.school_id)
);

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
SELECT 
    s.school_id,
    'Fee Payment Reminder',
    CONCAT('FEE_REMINDER_', s.school_id),
    'all',
    'School Fee Payment Reminder',
    'Dear Parent, school fees for {STUDENT_NAME} are due. Outstanding amount: {AMOUNT}. Please make payment at your earliest convenience.',
    'finance',
    1
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM notification_templates 
    WHERE template_code = CONCAT('FEE_REMINDER_', s.school_id)
);

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
SELECT 
    s.school_id,
    'Fee Payment Confirmation',
    CONCAT('FEE_PAID_', s.school_id),
    'all',
    'Fee Payment Received',
    'Thank you for your payment of {AMOUNT} for {STUDENT_NAME}. Receipt number: {RECEIPT_NO}',
    'finance',
    1
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM notification_templates 
    WHERE template_code = CONCAT('FEE_PAID_', s.school_id)
);

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
SELECT 
    s.school_id,
    'Fee Overdue Notice',
    CONCAT('FEE_OVERDUE_', s.school_id),
    'all',
    'Overdue Fee Payment',
    'This is a reminder that school fees for {STUDENT_NAME} are overdue. Outstanding: {AMOUNT}. Please pay immediately.',
    'finance',
    1
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM notification_templates 
    WHERE template_code = CONCAT('FEE_OVERDUE_', s.school_id)
);

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
SELECT 
    s.school_id,
    'Exam Schedule Notice',
    CONCAT('EXAM_SCHEDULE_', s.school_id),
    'all',
    'Examination Schedule',
    'Dear Parent/Student, examinations for {TERM_NAME} will commence on {DATE}. Please prepare accordingly.',
    'academic',
    1
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM notification_templates 
    WHERE template_code = CONCAT('EXAM_SCHEDULE_', s.school_id)
);

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
SELECT 
    s.school_id,
    'Exam Results Ready',
    CONCAT('RESULTS_READY_', s.school_id),
    'all',
    'Examination Results Published',
    'Results for {TERM_NAME} are now available. Login to view {STUDENT_NAME} results.',
    'academic',
    1
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM notification_templates 
    WHERE template_code = CONCAT('RESULTS_READY_', s.school_id)
);

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
SELECT 
    s.school_id,
    'New Message Received',
    CONCAT('NEW_MESSAGE_', s.school_id),
    'in_app',
    'New Message',
    'You have received a new message from {SENDER_NAME}: {MESSAGE_SUBJECT}',
    'communication',
    1
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM notification_templates 
    WHERE template_code = CONCAT('NEW_MESSAGE_', s.school_id)
);

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
SELECT 
    s.school_id,
    'School Announcement',
    CONCAT('ANNOUNCEMENT_', s.school_id),
    'all',
    'Important Announcement',
    '{ANNOUNCEMENT_TEXT}',
    'general',
    1
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM notification_templates 
    WHERE template_code = CONCAT('ANNOUNCEMENT_', s.school_id)
);

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
SELECT 
    s.school_id,
    'Parent Meeting Notice',
    CONCAT('PARENT_MEETING_', s.school_id),
    'all',
    'Parent Meeting Scheduled',
    'Dear Parent, a meeting is scheduled for {DATE} at {TIME}. Topic: {TOPIC}. Your attendance is requested.',
    'general',
    1
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM notification_templates 
    WHERE template_code = CONCAT('PARENT_MEETING_', s.school_id)
);

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT 'Notification templates created successfully!' as status;
SELECT COUNT(*) as total_templates, school_id 
FROM notification_templates 
GROUP BY school_id;
