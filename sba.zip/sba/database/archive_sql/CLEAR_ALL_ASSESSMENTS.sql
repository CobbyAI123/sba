-- ============================================
-- CLEAR ALL CA, MID-TERM, AND EXAM DATA
-- ⚠️ WARNING: THIS WILL DELETE ALL ASSESSMENT RECORDS
-- Date: November 9, 2025
-- ============================================

USE school_management_system;

-- ============================================
-- SAFETY CHECK - SHOW WHAT WILL BE DELETED
-- ============================================

SELECT '========================================' as info;
SELECT 'BEFORE DELETION - Current Record Counts' as info;
SELECT '========================================' as info;

-- Count all CA records
SELECT 
    'CA Records' as assessment_type,
    COUNT(*) as total_records,
    COUNT(DISTINCT student_id) as total_students,
    COUNT(DISTINCT subject_id) as total_subjects,
    COUNT(DISTINCT term_id) as total_terms
FROM results
WHERE assessment_type = 'CA';

-- Count all Mid-Term records
SELECT 
    'Mid-Term Records' as assessment_type,
    COUNT(*) as total_records,
    COUNT(DISTINCT student_id) as total_students,
    COUNT(DISTINCT subject_id) as total_subjects,
    COUNT(DISTINCT term_id) as total_terms
FROM results
WHERE assessment_type = 'Mid-Term';

-- Count all Exam records
SELECT 
    'Exam Records' as assessment_type,
    COUNT(*) as total_records,
    COUNT(DISTINCT student_id) as total_students,
    COUNT(DISTINCT subject_id) as total_subjects,
    COUNT(DISTINCT term_id) as total_terms
FROM results
WHERE assessment_type = 'Exams';

-- Total count
SELECT 
    'TOTAL TO BE DELETED' as assessment_type,
    COUNT(*) as total_records
FROM results
WHERE assessment_type IN ('CA', 'Mid-Term', 'Exams');

-- Show sample records that will be deleted
SELECT '========================================' as info;
SELECT 'Sample Records (First 10)' as info;
SELECT '========================================' as info;

SELECT 
    r.result_id,
    CONCAT(u.first_name, ' ', u.last_name) as student_name,
    s.subject_name,
    t.term_name,
    r.assessment_type,
    r.score
FROM results r
INNER JOIN students st ON r.student_id = st.student_id
INNER JOIN users u ON st.user_id = u.user_id
INNER JOIN subjects s ON r.subject_id = s.subject_id
INNER JOIN terms t ON r.term_id = t.term_id
WHERE r.assessment_type IN ('CA', 'Mid-Term', 'Exams')
ORDER BY r.result_id DESC
LIMIT 10;

-- ============================================
-- PAUSE HERE!
-- ============================================
-- Review the counts above. If you want to proceed,
-- UNCOMMENT the DELETE statements below by removing the -- symbols
-- ============================================

-- STEP 1: Create backup table (OPTIONAL but RECOMMENDED)
-- Uncomment this to create a backup before deletion
/*
CREATE TABLE IF NOT EXISTS results_backup_nov_2025 AS
SELECT * FROM results
WHERE assessment_type IN ('CA', 'Mid-Term', 'Exams');

SELECT CONCAT('Backup created: ', COUNT(*), ' records saved') as backup_info
FROM results_backup_nov_2025;
*/

-- ============================================
-- STEP 2: DELETE ALL CA RECORDS
-- ============================================
-- ⚠️ UNCOMMENT THE LINE BELOW TO DELETE CA RECORDS
-- DELETE FROM results WHERE assessment_type = 'CA';

-- SELECT CONCAT('Deleted ', ROW_COUNT(), ' CA records') as result;

-- ============================================
-- STEP 3: DELETE ALL MID-TERM RECORDS
-- ============================================
-- ⚠️ UNCOMMENT THE LINE BELOW TO DELETE MID-TERM RECORDS
-- DELETE FROM results WHERE assessment_type = 'Mid-Term';

-- SELECT CONCAT('Deleted ', ROW_COUNT(), ' Mid-Term records') as result;

-- ============================================
-- STEP 4: DELETE ALL EXAM RECORDS
-- ============================================
-- ⚠️ UNCOMMENT THE LINE BELOW TO DELETE EXAM RECORDS
-- DELETE FROM results WHERE assessment_type = 'Exams';

-- SELECT CONCAT('Deleted ', ROW_COUNT(), ' Exam records') as result;

-- ============================================
-- STEP 5: VERIFY DELETION
-- ============================================

SELECT '========================================' as info;
SELECT 'AFTER DELETION - Remaining Record Counts' as info;
SELECT '========================================' as info;

-- Count remaining CA records
SELECT 
    'CA Records Remaining' as assessment_type,
    COUNT(*) as total_records
FROM results
WHERE assessment_type = 'CA';

-- Count remaining Mid-Term records
SELECT 
    'Mid-Term Records Remaining' as assessment_type,
    COUNT(*) as total_records
FROM results
WHERE assessment_type = 'Mid-Term';

-- Count remaining Exam records
SELECT 
    'Exam Records Remaining' as assessment_type,
    COUNT(*) as total_records
FROM results
WHERE assessment_type = 'Exams';

-- Total remaining
SELECT 
    'TOTAL ASSESSMENT RECORDS REMAINING' as assessment_type,
    COUNT(*) as total_records
FROM results
WHERE assessment_type IN ('CA', 'Mid-Term', 'Exams');

-- Check all assessment types remaining in system
SELECT 
    assessment_type,
    COUNT(*) as count
FROM results
GROUP BY assessment_type;

-- ============================================
-- SUCCESS VERIFICATION
-- ============================================

SELECT 
    CASE 
        WHEN (SELECT COUNT(*) FROM results WHERE assessment_type IN ('CA', 'Mid-Term', 'Exams')) = 0
        THEN '✓ SUCCESS! All CA, Mid-Term, and Exam records have been deleted.'
        ELSE CONCAT('⚠️ WARNING: ', (SELECT COUNT(*) FROM results WHERE assessment_type IN ('CA', 'Mid-Term', 'Exams')), ' assessment records still remain.')
    END as final_status;

-- ============================================
-- NOTES
-- ============================================
-- This script ONLY deletes records from the results table where:
-- - assessment_type = 'CA' (Continuous Assessment)
-- - assessment_type = 'Mid-Term' (Mid-Term Exams)
-- - assessment_type = 'Exams' (Final Exams)
--
-- What is NOT deleted:
-- - Student records
-- - Subject records
-- - Term records
-- - Class records
-- - Teacher records
-- - Assignment records
-- - Attendance records
--
-- To restore deleted data:
-- If you created a backup, run:
-- INSERT INTO results SELECT * FROM results_backup_nov_2025;
--
-- ============================================
