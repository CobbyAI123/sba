-- Fix User Roles After Adding Proprietor
-- This fixes login issues caused by role changes

-- IMPORTANT: Select your database first in phpMyAdmin!

-- Step 1: Update the role ENUM to include ALL roles (including super_admin)
ALTER TABLE users 
MODIFY COLUMN role ENUM('super_admin', 'admin', 'teacher', 'student', 'parent', 'accountant', 'librarian', 'bookstore', 'proprietor') NOT NULL;

-- Step 2: Verify all users have valid roles
-- Check current users and their roles
SELECT user_id, username, email, role, status FROM users;

-- Step 3: If any user has NULL or invalid role, fix them:
-- (Uncomment and run these if needed)

-- Fix super admin (if exists)
-- UPDATE users SET role = 'super_admin' WHERE username = 'superadmin' OR email LIKE '%superadmin%';

-- Fix regular admins
-- UPDATE users SET role = 'admin' WHERE role IS NULL AND (username LIKE '%admin%' OR email LIKE '%admin%');

-- Step 4: Make sure all users are active
UPDATE users SET status = 'active' WHERE status IS NULL;

-- Step 5: Verify the fix
SELECT 'Roles fixed successfully!' as Status;
SELECT user_id, username, email, role, status FROM users ORDER BY role;
