-- ============================================
-- FIX STUDENT-USER LINKS
-- Links existing student records to their user accounts
-- ============================================

USE school_management_system;

-- Step 1: Check current situation
SELECT 
    'BEFORE FIX' as step,
    COUNT(*) as total_students,
    SUM(CASE WHEN user_id IS NULL THEN 1 ELSE 0 END) as missing_user_id,
    SUM(CASE WHEN user_id IS NOT NULL THEN 1 ELSE 0 END) as has_user_id
FROM students;

-- Step 2: Show students with missing user_id
SELECT 
    s.student_id,
    s.admission_number,
    s.class_id,
    s.user_id,
    '❌ Missing user_id link' as issue
FROM students s
WHERE s.user_id IS NULL;

-- Step 3: Try to find matching users by admission number (username)
SELECT 
    s.student_id,
    s.admission_number,
    u.user_id,
    u.username,
    CONCAT(u.first_name, ' ', u.last_name) as name,
    'Can be linked' as action
FROM students s
INNER JOIN users u ON LOWER(u.username) = LOWER(s.admission_number)
WHERE s.user_id IS NULL AND u.role = 'student';

-- Step 4: Link students to users where username matches admission_number
UPDATE students s
INNER JOIN users u ON LOWER(u.username) = LOWER(s.admission_number)
SET s.user_id = u.user_id
WHERE s.user_id IS NULL 
AND u.role = 'student';

-- Step 5: Try to link by email match (if students table has email)
UPDATE students s
INNER JOIN users u ON s.email = u.email
SET s.user_id = u.user_id
WHERE s.user_id IS NULL 
AND u.role = 'student'
AND s.email IS NOT NULL
AND s.email != '';

-- Step 6: Show remaining students without links
SELECT 
    s.student_id,
    s.admission_number,
    s.class_id,
    '⚠️ Could not auto-link - manual intervention needed' as status
FROM students s
WHERE s.user_id IS NULL;

-- Step 7: For remaining unlinked students, create user accounts
INSERT INTO users (school_id, username, email, password_hash, role, status, first_name, last_name)
SELECT 
    s.school_id,
    LOWER(s.admission_number) as username,
    CONCAT(LOWER(REPLACE(s.admission_number, '/', '')), '@temp.school') as email,
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' as password_hash, -- password: 'password'
    'student' as role,
    'active' as status,
    COALESCE(s.first_name, 'Student') as first_name,
    COALESCE(s.last_name, s.admission_number) as last_name
FROM students s
WHERE s.user_id IS NULL
AND NOT EXISTS (
    SELECT 1 FROM users u 
    WHERE LOWER(u.username) = LOWER(s.admission_number)
);

-- Step 8: Link the newly created users
UPDATE students s
INNER JOIN users u ON LOWER(u.username) = LOWER(s.admission_number)
SET s.user_id = u.user_id
WHERE s.user_id IS NULL 
AND u.role = 'student';

-- Step 9: Verify the fix
SELECT 
    'AFTER FIX' as step,
    COUNT(*) as total_students,
    SUM(CASE WHEN user_id IS NULL THEN 1 ELSE 0 END) as missing_user_id,
    SUM(CASE WHEN user_id IS NOT NULL THEN 1 ELSE 0 END) as has_user_id
FROM students;

-- Step 10: Show all students with their user info
SELECT 
    s.student_id,
    s.admission_number,
    s.user_id,
    u.username,
    CONCAT(u.first_name, ' ', u.last_name) as name,
    c.class_name,
    CASE 
        WHEN s.user_id IS NULL THEN '❌ Still missing'
        WHEN u.user_id IS NULL THEN '⚠️ User not found'
        ELSE '✓ Linked correctly'
    END as status
FROM students s
LEFT JOIN users u ON s.user_id = u.user_id
LEFT JOIN classes c ON s.class_id = c.class_id
ORDER BY s.student_id DESC
LIMIT 20;

-- Step 11: Success message
SELECT 
    CASE 
        WHEN (SELECT COUNT(*) FROM students WHERE user_id IS NULL) = 0
        THEN '✓ SUCCESS! All students are now linked to user accounts and names will display correctly.'
        ELSE CONCAT('⚠️ WARNING: ', (SELECT COUNT(*) FROM students WHERE user_id IS NULL), ' students still need manual linking.')
    END as result;

-- ============================================
-- NOTES
-- ============================================
-- This script:
-- 1. Links existing students to users by matching username = admission_number
-- 2. Links by email if available
-- 3. Creates new user accounts for unlinked students
-- 4. Sets default password 'password' for auto-created accounts
-- 5. Updates students.user_id for all matches
-- 
-- After running this:
-- - Student names will display in the list
-- - Students can login with username = admission_number
-- - Default password is 'password' (should be changed)
-- ============================================
