-- ============================================================================
-- FIX: Three Database Schema Errors
-- 1. messages table - missing deleted_by_recipient and deleted_by_sender columns
-- 2. notification_settings table - doesn't exist
-- 3. fee_structure table - missing term_id column
-- Date: November 17, 2025
-- ============================================================================

-- ============================================================================
-- FIX 1: Messages Table - Add missing delete tracking columns
-- ============================================================================

-- Add deleted_by_recipient column if it doesn't exist
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'messages' 
AND COLUMN_NAME = 'deleted_by_recipient';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE messages ADD COLUMN deleted_by_recipient TINYINT(1) DEFAULT 0 AFTER is_read',
    'SELECT "Column deleted_by_recipient already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add deleted_by_sender column if it doesn't exist
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'messages' 
AND COLUMN_NAME = 'deleted_by_sender';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE messages ADD COLUMN deleted_by_sender TINYINT(1) DEFAULT 0 AFTER deleted_by_recipient',
    'SELECT "Column deleted_by_sender already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add read_status column if it doesn't exist
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'messages' 
AND COLUMN_NAME = 'read_status';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE messages ADD COLUMN read_status ENUM(''read'', ''unread'') DEFAULT ''unread'' AFTER is_read',
    'SELECT "Column read_status already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT '✅ Fix 1 Complete: messages table updated with delete tracking columns' AS status;

-- ============================================================================
-- FIX 2: Create notification_settings table
-- ============================================================================

CREATE TABLE IF NOT EXISTS `notification_settings` (
  `setting_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  
  -- SMS Settings
  `sms_enabled` TINYINT(1) DEFAULT 0,
  `sms_gateway` ENUM('twilio', 'africastalking', 'nexmo', 'custom') NULL,
  `sms_api_key` VARCHAR(255) NULL,
  `sms_api_secret` VARCHAR(255) NULL,
  `sms_sender_id` VARCHAR(50) NULL,
  `sms_balance` DECIMAL(10,2) DEFAULT 0.00,
  
  -- Email Settings
  `email_enabled` TINYINT(1) DEFAULT 1,
  `smtp_host` VARCHAR(255) NULL,
  `smtp_port` INT(5) DEFAULT 587,
  `smtp_username` VARCHAR(255) NULL,
  `smtp_password` VARCHAR(255) NULL,
  `smtp_encryption` ENUM('none', 'ssl', 'tls') DEFAULT 'tls',
  `email_from_address` VARCHAR(255) NULL,
  `email_from_name` VARCHAR(100) NULL,
  
  -- In-App Notifications
  `in_app_enabled` TINYINT(1) DEFAULT 1,
  
  -- Auto Notifications
  `auto_absence_notification` TINYINT(1) DEFAULT 1,
  `auto_fee_reminder` TINYINT(1) DEFAULT 1,
  `auto_result_notification` TINYINT(1) DEFAULT 1,
  `auto_exam_reminder` TINYINT(1) DEFAULT 1,
  
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create notification_history table if it doesn't exist
CREATE TABLE IF NOT EXISTS `notification_history` (
  `history_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NULL,
  `notification_type` ENUM('sms', 'email', 'in_app') NOT NULL,
  `recipient_phone` VARCHAR(20) NULL,
  `recipient_email` VARCHAR(255) NULL,
  `subject` VARCHAR(255) NULL,
  `message` TEXT NOT NULL,
  `template_code` VARCHAR(50) NULL,
  `status` ENUM('sent', 'failed', 'read', 'unread') DEFAULT 'sent',
  `cost` DECIMAL(10,4) NULL COMMENT 'Cost for SMS',
  `gateway_response` TEXT NULL,
  `read_at` TIMESTAMP NULL,
  `sent_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`history_id`),
  KEY `idx_school_user` (`school_id`, `user_id`),
  KEY `idx_type` (`notification_type`),
  KEY `idx_status` (`status`),
  KEY `idx_sent_at` (`sent_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert default settings for existing schools
INSERT INTO `notification_settings` 
(`school_id`, `email_enabled`, `in_app_enabled`)
SELECT school_id, 1, 1
FROM schools
WHERE school_id NOT IN (SELECT school_id FROM notification_settings)
ON DUPLICATE KEY UPDATE setting_id=setting_id;

SELECT '✅ Fix 2 Complete: notification_settings table created and initialized' AS status;

-- ============================================================================
-- FIX 3: fee_structure table - Add term_id, fee_type, and description columns
-- ============================================================================

-- Add term_id column if it doesn't exist
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'fee_structure' 
AND COLUMN_NAME = 'term_id';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE fee_structure ADD COLUMN term_id INT(11) NULL AFTER class_id, ADD KEY idx_term (term_id)',
    'SELECT "Column term_id already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add fee_type column if it doesn't exist (needed by accountant portal)
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'fee_structure' 
AND COLUMN_NAME = 'fee_type';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE fee_structure ADD COLUMN fee_type VARCHAR(100) NULL AFTER term_id',
    'SELECT "Column fee_type already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add description column if it doesn't exist
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'fee_structure' 
AND COLUMN_NAME = 'description';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE fee_structure ADD COLUMN description TEXT NULL AFTER fee_type',
    'SELECT "Column description already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT '✅ Fix 3 Complete: fee_structure table updated with term_id, fee_type, and description columns' AS status;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Verify messages table
SELECT 'messages table columns:' AS info;
SHOW COLUMNS FROM messages LIKE '%deleted%';
SHOW COLUMNS FROM messages LIKE '%read_status%';

-- Verify notification_settings table
SELECT 'notification_settings table:' AS info;
SELECT COUNT(*) as table_exists FROM information_schema.tables 
WHERE table_schema = DATABASE() AND table_name = 'notification_settings';

-- Verify fee_structure table
SELECT 'fee_structure table columns:' AS info;
SHOW COLUMNS FROM fee_structure LIKE '%term_id%';
SHOW COLUMNS FROM fee_structure LIKE '%fee_type%';
SHOW COLUMNS FROM fee_structure LIKE '%description%';

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

SELECT '
╔════════════════════════════════════════════════════════════════╗
║           ✅ ALL THREE SCHEMA ERRORS FIXED!                    ║
╠════════════════════════════════════════════════════════════════╣
║ 1. messages: deleted_by_recipient, deleted_by_sender added    ║
║ 2. notification_settings: table created with defaults         ║
║ 3. fee_structure: term_id, fee_type, description added        ║
╠════════════════════════════════════════════════════════════════╣
║ NEXT STEPS:                                                    ║
║ • Clear browser cache (Ctrl + Shift + Delete)                 ║
║ • Test messaging system                                        ║
║ • Test notification settings                                   ║
║ • Test accountant fee structure                                ║
╚════════════════════════════════════════════════════════════════╝
' AS STATUS;
