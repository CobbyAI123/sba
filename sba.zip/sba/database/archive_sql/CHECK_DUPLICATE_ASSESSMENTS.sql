-- ============================================
-- CHECK FOR DUPLICATE ASSESSMENT ENTRIES
-- Identifies duplicate student assessment records
-- ============================================

-- Check for duplicate entries (same student, subject, term)
SELECT 
    student_id,
    subject_id,
    term_id,
    COUNT(*) as duplicate_count,
    GROUP_CONCAT(assessment_id) as assessment_ids
FROM student_assessments
GROUP BY student_id, subject_id, term_id
HAVING COUNT(*) > 1
ORDER BY duplicate_count DESC;

-- If duplicates found, you can keep the latest one and delete others
-- CAUTION: Review the data before running DELETE!

-- To remove duplicates (keeps the one with highest assessment_id):
-- DELETE sa1 FROM student_assessments sa1
-- INNER JOIN student_assessments sa2 
-- WHERE sa1.student_id = sa2.student_id 
--   AND sa1.subject_id = sa2.subject_id 
--   AND sa1.term_id = sa2.term_id 
--   AND sa1.assessment_id < sa2.assessment_id;

SELECT 'Query complete. Check results above.' as Status;
