-- ============================================
-- CHECK WHAT EXISTS
-- Run this to see what's already in your database
-- ============================================

USE school_management_system;

-- Check if results_published exists in terms
SELECT 
    'results_published in terms' as Item,
    IF(COUNT(*) > 0, '✓ EXISTS', '✗ MISSING') as Status
FROM information_schema.columns 
WHERE table_schema = 'school_management_system' 
AND table_name = 'terms' 
AND column_name = 'results_published';

-- Check if class_teacher_id exists in classes
SELECT 
    'class_teacher_id in classes' as Item,
    IF(COUNT(*) > 0, '✓ EXISTS', '✗ MISSING') as Status
FROM information_schema.columns 
WHERE table_schema = 'school_management_system' 
AND table_name = 'classes' 
AND column_name = 'class_teacher_id';

-- Check if temp_password exists in users
SELECT 
    'temp_password in users' as Item,
    IF(COUNT(*) > 0, '✓ EXISTS', '✗ MISSING') as Status
FROM information_schema.columns 
WHERE table_schema = 'school_management_system' 
AND table_name = 'users' 
AND column_name = 'temp_password';

-- Check if student_results_view table exists
SELECT 
    'student_results_view table' as Item,
    IF(COUNT(*) > 0, '✓ EXISTS', '✗ MISSING') as Status
FROM information_schema.tables 
WHERE table_schema = 'school_management_system' 
AND table_name = 'student_results_view';

-- Check if assignment_files table exists
SELECT 
    'assignment_files table' as Item,
    IF(COUNT(*) > 0, '✓ EXISTS', '✗ MISSING') as Status
FROM information_schema.tables 
WHERE table_schema = 'school_management_system' 
AND table_name = 'assignment_files';

-- Summary
SELECT '=====================================' as '';
SELECT 'Run ADD_MISSING_ONLY.sql to add missing items' as 'Next Step';
