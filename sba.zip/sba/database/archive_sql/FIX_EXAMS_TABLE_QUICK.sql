-- ============================================================================
-- QUICK FIX: Add missing columns to exams table
-- Run this if you get "Unknown column 'academic_year'" error
-- ============================================================================

-- Add academic_year column if it doesn't exist
ALTER TABLE `exams` 
ADD COLUMN IF NOT EXISTS `academic_year` VARCHAR(20) NOT NULL DEFAULT '2025' AFTER `exam_type`;

-- Add other potentially missing columns
ALTER TABLE `exams` 
ADD COLUMN IF NOT EXISTS `instructions` TEXT NULL AFTER `status`;

ALTER TABLE `exams` 
ADD COLUMN IF NOT EXISTS `created_by` INT(11) NOT NULL DEFAULT 1 AFTER `instructions`;

-- Verify
SELECT 'Columns added successfully!' as status;
DESCRIBE exams;
