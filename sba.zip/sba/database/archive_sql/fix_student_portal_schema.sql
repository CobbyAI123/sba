-- ============================================================================
-- FIX: Student Portal Schema Errors  
-- Multiple missing tables and columns for student functionality
-- Date: November 17, 2025
-- ============================================================================

-- ============================================================================
-- FIX 1: terms table - Add results_published column
-- ============================================================================

SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'terms' 
AND COLUMN_NAME = 'results_published';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE terms ADD COLUMN results_published TINYINT(1) DEFAULT 0 AFTER is_current',
    'SELECT "Column results_published already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT '✅ Fix 1: terms.results_published column added' AS status;

-- ============================================================================
-- FIX 2: Create student_qr_codes table
-- ============================================================================

CREATE TABLE IF NOT EXISTS `student_qr_codes` (
  `qr_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `qr_code` VARCHAR(255) NOT NULL UNIQUE,
  `qr_image_path` VARCHAR(255) NULL,
  `generated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `last_used` TIMESTAMP NULL,
  `status` ENUM('active', 'inactive', 'expired') DEFAULT 'active',
  PRIMARY KEY (`qr_id`),
  UNIQUE KEY `idx_student` (`student_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_qr_code` (`qr_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SELECT '✅ Fix 2: student_qr_codes table created' AS status;

-- ============================================================================
-- FIX 3: Create exam_schedule table
-- ============================================================================

CREATE TABLE IF NOT EXISTS `exam_schedule` (
  `schedule_id` INT(11) NOT NULL AUTO_INCREMENT,
  `exam_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `exam_date` DATE NOT NULL,
  `start_time` TIME NOT NULL,
  `end_time` TIME NOT NULL,
  `duration_minutes` INT(3) NULL,
  `room_number` VARCHAR(50) NULL,
  `invigilator_id` INT(11) NULL,
  `max_marks` INT(3) DEFAULT 100,
  `instructions` TEXT NULL,
  `status` ENUM('scheduled', 'ongoing', 'completed', 'cancelled') DEFAULT 'scheduled',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`schedule_id`),
  KEY `idx_exam` (`exam_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_date` (`exam_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SELECT '✅ Fix 3: exam_schedule table created' AS status;

-- ============================================================================
-- FIX 4: Create hall_tickets table
-- ============================================================================

CREATE TABLE IF NOT EXISTS `hall_tickets` (
  `ticket_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `exam_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `ticket_number` VARCHAR(50) NOT NULL UNIQUE,
  `roll_number` VARCHAR(50) NULL,
  `issued_date` DATE NOT NULL,
  `exam_center` VARCHAR(255) NULL,
  `instructions` TEXT NULL,
  `photo_path` VARCHAR(255) NULL,
  `barcode` VARCHAR(255) NULL,
  `status` ENUM('active', 'used', 'cancelled') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ticket_id`),
  UNIQUE KEY `idx_student_exam` (`student_id`, `exam_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_exam` (`exam_id`),
  KEY `idx_ticket_number` (`ticket_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SELECT '✅ Fix 4: hall_tickets table created' AS status;

-- ============================================================================
-- FIX 5: assignment_submissions - Add submission_text column
-- ============================================================================

SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'assignment_submissions' 
AND COLUMN_NAME = 'submission_text';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE assignment_submissions ADD COLUMN submission_text TEXT NULL AFTER school_id',
    'SELECT "Column submission_text already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add is_late column
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'assignment_submissions' 
AND COLUMN_NAME = 'is_late';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE assignment_submissions ADD COLUMN is_late TINYINT(1) DEFAULT 0 AFTER submitted_at',
    'SELECT "Column is_late already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add status column
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'assignment_submissions' 
AND COLUMN_NAME = 'status';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE assignment_submissions ADD COLUMN status ENUM(''not_submitted'', ''submitted'', ''graded'', ''returned'') DEFAULT ''submitted'' AFTER is_late',
    'SELECT "Column status already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Rename marks to marks_obtained for consistency
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'assignment_submissions' 
AND COLUMN_NAME = 'marks_obtained';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE assignment_submissions CHANGE COLUMN marks marks_obtained DECIMAL(5,2) NULL',
    'SELECT "Column marks_obtained already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT '✅ Fix 5: assignment_submissions columns added' AS status;

-- ============================================================================
-- FIX 6: student_assessments - Add teacher_id column
-- ============================================================================

SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'student_assessments' 
AND COLUMN_NAME = 'teacher_id';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE student_assessments ADD COLUMN teacher_id INT(11) NULL AFTER term_id, ADD KEY idx_teacher (teacher_id)',
    'SELECT "Column teacher_id already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT '✅ Fix 6: student_assessments.teacher_id column added' AS status;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT '═══════════════════════════════════════' AS '';
SELECT 'VERIFICATION RESULTS' AS '';
SELECT '═══════════════════════════════════════' AS '';

-- Verify terms.results_published
SELECT 'terms.results_published:' AS Check_Item,
       IF(COUNT(*) > 0, '✅ EXISTS', '❌ MISSING') AS Status
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'terms' 
AND COLUMN_NAME = 'results_published';

-- Verify student_qr_codes table
SELECT 'student_qr_codes table:' AS Check_Item,
       IF(COUNT(*) > 0, '✅ EXISTS', '❌ MISSING') AS Status
FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'student_qr_codes';

-- Verify exam_schedule table
SELECT 'exam_schedule table:' AS Check_Item,
       IF(COUNT(*) > 0, '✅ EXISTS', '❌ MISSING') AS Status
FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'exam_schedule';

-- Verify hall_tickets table
SELECT 'hall_tickets table:' AS Check_Item,
       IF(COUNT(*) > 0, '✅ EXISTS', '❌ MISSING') AS Status
FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'hall_tickets';

-- Verify assignment_submissions.submission_text
SELECT 'assignment_submissions.submission_text:' AS Check_Item,
       IF(COUNT(*) > 0, '✅ EXISTS', '❌ MISSING') AS Status
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'assignment_submissions' 
AND COLUMN_NAME = 'submission_text';

-- Verify student_assessments.teacher_id
SELECT 'student_assessments.teacher_id:' AS Check_Item,
       IF(COUNT(*) > 0, '✅ EXISTS', '❌ MISSING') AS Status
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'student_assessments' 
AND COLUMN_NAME = 'teacher_id';

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

SELECT '
╔═══════════════════════════════════════════════════════════════╗
║      ✅ ALL STUDENT PORTAL SCHEMA ERRORS FIXED!               ║
╠═══════════════════════════════════════════════════════════════╣
║ 1. terms: results_published column added                     ║
║ 2. student_qr_codes: table created                           ║
║ 3. exam_schedule: table created                              ║
║ 4. hall_tickets: table created                               ║
║ 5. assignment_submissions: submission_text + status added    ║
║ 6. student_assessments: teacher_id added                     ║
╠═══════════════════════════════════════════════════════════════╣
║ NEXT STEPS:                                                   ║
║ • Clear browser cache                                         ║
║ • Test student portal pages                                   ║
║ • Test teacher assessment entry                               ║
╚═══════════════════════════════════════════════════════════════╝
' AS STATUS;
