-- Complete Fix for All Student Pages
-- Run this SQL in phpMyAdmin to fix: My Subjects, Exams, My Results, Fee Payments

-- 1. Create class_subjects table (for My Subjects page)
CREATE TABLE IF NOT EXISTS `class_subjects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_class_subject` (`class_id`,`subject_id`),
  KEY `class_id` (`class_id`),
  KEY `subject_id` (`subject_id`),
  KEY `teacher_id` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Ensure fee_types table exists (for Fee Payments page)
CREATE TABLE IF NOT EXISTS `fee_types` (
  `fee_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `fee_name` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `frequency` enum('one-time','monthly','termly','yearly') DEFAULT 'termly',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`fee_type_id`),
  KEY `school_id` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Ensure payments table exists (for Fee Payments page)
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `fee_type_id` int(11) DEFAULT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` enum('cash','bank_transfer','card','mobile_money') DEFAULT 'cash',
  `payment_status` enum('pending','completed','failed','refunded') DEFAULT 'completed',
  `transaction_id` varchar(100) DEFAULT NULL,
  `receipt_number` varchar(50) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  KEY `school_id` (`school_id`),
  KEY `student_id` (`student_id`),
  KEY `fee_type_id` (`fee_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Ensure marks table exists (for My Results page)
CREATE TABLE IF NOT EXISTS `marks` (
  `mark_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `marks_obtained` decimal(5,2) NOT NULL,
  `total_marks` decimal(5,2) NOT NULL DEFAULT 100.00,
  `grade` varchar(5) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mark_id`),
  UNIQUE KEY `unique_mark` (`student_id`,`exam_id`,`subject_id`),
  KEY `student_id` (`student_id`),
  KEY `exam_id` (`exam_id`),
  KEY `subject_id` (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Insert sample fee types (if not exists)
INSERT INTO `fee_types` (`school_id`, `fee_name`, `amount`, `description`, `frequency`, `status`) 
SELECT 1, 'Tuition Fee', 1500.00, 'Termly tuition fee', 'termly', 'active'
WHERE NOT EXISTS (SELECT 1 FROM `fee_types` WHERE `fee_name` = 'Tuition Fee' AND `school_id` = 1);

INSERT INTO `fee_types` (`school_id`, `fee_name`, `amount`, `description`, `frequency`, `status`) 
SELECT 1, 'Library Fee', 100.00, 'Library access fee', 'termly', 'active'
WHERE NOT EXISTS (SELECT 1 FROM `fee_types` WHERE `fee_name` = 'Library Fee' AND `school_id` = 1);

INSERT INTO `fee_types` (`school_id`, `fee_name`, `amount`, `description`, `frequency`, `status`) 
SELECT 1, 'Sports Fee', 150.00, 'Sports and games fee', 'termly', 'active'
WHERE NOT EXISTS (SELECT 1 FROM `fee_types` WHERE `fee_name` = 'Sports Fee' AND `school_id` = 1);

INSERT INTO `fee_types` (`school_id`, `fee_name`, `amount`, `description`, `frequency`, `status`) 
SELECT 1, 'Lab Fee', 200.00, 'Science laboratory fee', 'termly', 'active'
WHERE NOT EXISTS (SELECT 1 FROM `fee_types` WHERE `fee_name` = 'Lab Fee' AND `school_id` = 1);

INSERT INTO `fee_types` (`school_id`, `fee_name`, `amount`, `description`, `frequency`, `status`) 
SELECT 1, 'Transport Fee', 300.00, 'School transport fee', 'monthly', 'active'
WHERE NOT EXISTS (SELECT 1 FROM `fee_types` WHERE `fee_name` = 'Transport Fee' AND `school_id` = 1);

-- 6. Link subjects to classes (sample data - adjust class_id and subject_id as needed)
-- This assumes you have classes with IDs 1-5 and subjects with IDs 1-10
-- Adjust these based on your actual data

-- For Class 1 (example)
INSERT INTO `class_subjects` (`class_id`, `subject_id`, `teacher_id`)
SELECT 1, s.subject_id, NULL
FROM subjects s
WHERE s.school_id = 1 AND s.subject_id <= 5
ON DUPLICATE KEY UPDATE class_id=class_id;

-- For Class 2 (example)
INSERT INTO `class_subjects` (`class_id`, `subject_id`, `teacher_id`)
SELECT 2, s.subject_id, NULL
FROM subjects s
WHERE s.school_id = 1 AND s.subject_id <= 5
ON DUPLICATE KEY UPDATE class_id=class_id;

-- Note: You may need to manually assign subjects to your specific classes
-- Use this query to see your classes and subjects:
-- SELECT * FROM classes WHERE school_id = 1;
-- SELECT * FROM subjects WHERE school_id = 1;
