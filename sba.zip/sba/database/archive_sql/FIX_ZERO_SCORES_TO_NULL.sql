-- ============================================
-- CONVERT ZERO SCORES TO NULL
-- Fixes scores that are 0 to become NULL
-- This ensures progress bars show correctly
-- ============================================

-- Check current state: How many 0 scores exist
SELECT 
    'CA Scores' as assessment_type,
    COUNT(*) as zero_count
FROM student_assessments 
WHERE ca_score = 0
UNION ALL
SELECT 
    'Midterm Scores' as assessment_type,
    COUNT(*) as zero_count
FROM student_assessments 
WHERE midterm_score = 0
UNION ALL
SELECT 
    'Exam Scores' as assessment_type,
    COUNT(*) as zero_count
FROM student_assessments 
WHERE exam_score = 0;

-- Update CA scores: Set 0 to NULL
-- IMPORTANT: Only set to NULL if student has OTHER assessments entered
-- Don't touch if CA is actually 0 as the only score
UPDATE student_assessments
SET ca_score = NULL
WHERE ca_score = 0
  AND (midterm_score IS NOT NULL OR exam_score IS NOT NULL);

-- Update Midterm scores: Set 0 to NULL
UPDATE student_assessments
SET midterm_score = NULL
WHERE midterm_score = 0
  AND (ca_score IS NOT NULL OR exam_score IS NOT NULL);

-- Update Exam scores: Set 0 to NULL  
UPDATE student_assessments
SET exam_score = NULL
WHERE exam_score = 0
  AND (ca_score IS NOT NULL OR midterm_score IS NOT NULL);

-- Verify the changes
SELECT 
    'After Fix - CA Scores' as assessment_type,
    COUNT(*) as zero_count
FROM student_assessments 
WHERE ca_score = 0
UNION ALL
SELECT 
    'After Fix - Midterm Scores' as assessment_type,
    COUNT(*) as zero_count
FROM student_assessments 
WHERE midterm_score = 0
UNION ALL
SELECT 
    'After Fix - Exam Scores' as assessment_type,
    COUNT(*) as zero_count
FROM student_assessments 
WHERE exam_score = 0;

SELECT '✓ SUCCESS: Zero scores converted to NULL for accurate progress tracking!' as Status;
