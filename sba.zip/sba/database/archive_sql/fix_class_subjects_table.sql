-- ============================================================================
-- FIX: Class Subjects Table - Correct Primary Key Column Name
-- Error: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'id' in 'field list'
-- Date: November 17, 2025
-- ============================================================================

-- Drop the incorrect table if it exists
DROP TABLE IF EXISTS `class_subjects`;

-- Recreate with correct schema
CREATE TABLE `class_subjects` (
  `class_subject_id` INT(11) NOT NULL AUTO_INCREMENT,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `teacher_id` INT(11) NULL,
  PRIMARY KEY (`class_subject_id`),
  UNIQUE KEY `idx_class_subject` (`class_id`, `subject_id`),
  KEY `idx_teacher` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Verify table structure
DESCRIBE class_subjects;

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================
SELECT 'class_subjects table fixed successfully!' as status;
