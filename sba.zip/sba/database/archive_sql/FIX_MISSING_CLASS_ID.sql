-- ============================================================================
-- FIX MISSING CLASS_ID IN STUDENT_ASSESSMENTS
-- This script updates student_assessments records that don't have class_id set
-- by getting the class_id from the students table
-- ============================================================================

-- IMPORTANT: This is a SAFE script - it only updates records with missing class_id
-- It does NOT delete or overwrite existing valid class_id values

SET SQL_SAFE_UPDATES = 0;

-- ============================================================================
-- STEP 1: Preview what will be updated
-- ============================================================================

SELECT 
    'PREVIEW: Records that need class_id update' as action,
    COUNT(*) as total_records
FROM student_assessments sa
WHERE sa.class_id IS NULL OR sa.class_id = 0;

-- Show sample records that will be updated
SELECT 
    sa.assessment_id,
    sa.student_id,
    sa.subject_id,
    sa.class_id as current_class_id,
    s.class_id as student_class_id,
    c.class_name
FROM student_assessments sa
INNER JOIN students s ON sa.student_id = s.student_id
LEFT JOIN classes c ON s.class_id = c.class_id
WHERE sa.class_id IS NULL OR sa.class_id = 0
LIMIT 20;

-- ============================================================================
-- STEP 2: Update class_id from students table
-- ============================================================================

-- Update student_assessments with class_id from students table
UPDATE student_assessments sa
INNER JOIN students s ON sa.student_id = s.student_id
SET sa.class_id = s.class_id
WHERE (sa.class_id IS NULL OR sa.class_id = 0)
AND s.class_id IS NOT NULL;

SELECT 'Class IDs updated' as status, ROW_COUNT() as records_updated;

-- ============================================================================
-- STEP 3: Verification - Check results
-- ============================================================================

-- Count records with and without class_id
SELECT 
    'VERIFICATION: Class ID Status' as report,
    COUNT(*) as total_records,
    SUM(CASE WHEN class_id IS NOT NULL AND class_id > 0 THEN 1 ELSE 0 END) as has_class_id,
    SUM(CASE WHEN class_id IS NULL OR class_id = 0 THEN 1 ELSE 0 END) as missing_class_id
FROM student_assessments;

-- Show sample of updated records
SELECT 
    sa.assessment_id,
    sa.student_id,
    sa.class_id,
    c.class_name,
    subj.subject_name,
    sa.total_score
FROM student_assessments sa
LEFT JOIN classes c ON sa.class_id = c.class_id
LEFT JOIN subjects subj ON sa.subject_id = subj.subject_id
WHERE sa.class_id IS NOT NULL
ORDER BY sa.student_id, sa.class_id
LIMIT 20;

-- ============================================================================
-- STEP 4: Check for records that still need fixing
-- ============================================================================

-- Records that still don't have class_id (students might not have class assigned)
SELECT 
    'STILL MISSING CLASS_ID: Check these students' as warning,
    sa.student_id,
    COUNT(*) as record_count
FROM student_assessments sa
WHERE sa.class_id IS NULL OR sa.class_id = 0
GROUP BY sa.student_id;

-- ============================================================================
-- COMPLETION MESSAGE
-- ============================================================================

SELECT 
    'UPDATE COMPLETE' as status,
    'Student assessments now have class_id for proper transcript generation' as message,
    NOW() as timestamp;

SET SQL_SAFE_UPDATES = 1;

-- ============================================================================
-- NOTES
-- ============================================================================
-- 1. This script is SAFE - it only updates missing class_id
-- 2. Existing valid class_id values are NOT changed
-- 3. Gets class_id from students table
-- 4. Required for transcripts to work properly
-- 5. Run this script if transcripts show "No assessment records"
-- 
-- TO RUN THIS SCRIPT:
-- 1. Open phpMyAdmin
-- 2. Select your database
-- 3. Go to SQL tab
-- 4. Copy and paste this entire script
-- 5. Click "Go" button
-- 6. Check the results in each step
-- 
-- WHEN TO RUN:
-- - If transcripts show "No assessment records found"
-- - After updating the system
-- - For existing data before class_id was added to inserts
-- ============================================================================
