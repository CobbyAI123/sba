-- Complete Terms Table Fix
-- This adds all missing columns needed by admin/terms.php

-- Add session_year column if missing
ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `session_year` VARCHAR(20) NOT NULL DEFAULT '2024/2025' AFTER `term_name`;

-- Add is_active column if missing (or rename is_current to is_active)
-- First check if is_current exists and rename it
SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE table_schema = DATABASE() 
    AND table_name = 'terms' 
    AND column_name = 'is_current');

SET @sql = IF(@col_exists > 0,
    'ALTER TABLE `terms` CHANGE COLUMN `is_current` `is_active` TINYINT(1) DEFAULT 0',
    'SELECT "Column is_current does not exist"');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add is_active if it still doesn't exist
ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `is_active` TINYINT(1) DEFAULT 0 AFTER `end_date`;

-- Add created_at if missing
ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- Add updated_at if missing
ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Add indexes for better performance
ALTER TABLE `terms` 
ADD INDEX IF NOT EXISTS `idx_school_active` (`school_id`, `is_active`);

ALTER TABLE `terms` 
ADD INDEX IF NOT EXISTS `idx_session` (`session_year`);

-- Update any existing records
UPDATE `terms` 
SET `session_year` = '2024/2025' 
WHERE `session_year` = '' OR `session_year` IS NULL;

-- Ensure only one term is active per school
UPDATE `terms` t1
LEFT JOIN (
    SELECT school_id, MIN(term_id) as first_term
    FROM `terms`
    GROUP BY school_id
) t2 ON t1.school_id = t2.school_id AND t1.term_id = t2.first_term
SET t1.is_active = IF(t1.term_id = t2.first_term, 1, 0);
