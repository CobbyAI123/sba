-- ============================================
-- CLEAR ALL CA, MID-TERM, AND EXAM DATA (SAFE VERSION)
-- This version creates backup first, then deletes
-- Date: November 9, 2025
-- ============================================

USE school_management_system;

-- Step 1: Show current counts
SELECT 'STEP 1: Current Assessment Counts' as step;
SELECT '=======================================' as separator;

SELECT 
    assessment_type,
    COUNT(*) as record_count,
    COUNT(DISTINCT student_id) as students_affected,
    COUNT(DISTINCT subject_id) as subjects_affected
FROM results
WHERE assessment_type IN ('CA', 'Mid-Term', 'Exams')
GROUP BY assessment_type
ORDER BY assessment_type;

SELECT 
    'TOTAL' as assessment_type,
    COUNT(*) as record_count
FROM results
WHERE assessment_type IN ('CA', 'Mid-Term', 'Exams');

-- Step 2: Create backup table
SELECT 'STEP 2: Creating Backup' as step;
SELECT '=======================================' as separator;

DROP TABLE IF EXISTS results_backup_assessments;

CREATE TABLE results_backup_assessments AS
SELECT * FROM results
WHERE assessment_type IN ('CA', 'Mid-Term', 'Exams');

SELECT 
    CONCAT('✓ Backup created: ', COUNT(*), ' records saved to results_backup_assessments') as backup_status
FROM results_backup_assessments;

-- Step 3: Delete CA records
SELECT 'STEP 3: Deleting CA Records' as step;
SELECT '=======================================' as separator;

DELETE FROM results WHERE assessment_type = 'CA';

SELECT CONCAT('✓ Deleted ', ROW_COUNT(), ' CA records') as result;

-- Step 4: Delete Mid-Term records
SELECT 'STEP 4: Deleting Mid-Term Records' as step;
SELECT '=======================================' as separator;

DELETE FROM results WHERE assessment_type = 'Mid-Term';

SELECT CONCAT('✓ Deleted ', ROW_COUNT(), ' Mid-Term records') as result;

-- Step 5: Delete Exam records
SELECT 'STEP 5: Deleting Exam Records' as step;
SELECT '=======================================' as separator;

DELETE FROM results WHERE assessment_type = 'Exams';

SELECT CONCAT('✓ Deleted ', ROW_COUNT(), ' Exam records') as result;

-- Step 6: Verify deletion
SELECT 'STEP 6: Verification' as step;
SELECT '=======================================' as separator;

SELECT 
    'CA Records Remaining' as check_type,
    COUNT(*) as count
FROM results
WHERE assessment_type = 'CA'
UNION ALL
SELECT 
    'Mid-Term Records Remaining' as check_type,
    COUNT(*) as count
FROM results
WHERE assessment_type = 'Mid-Term'
UNION ALL
SELECT 
    'Exam Records Remaining' as check_type,
    COUNT(*) as count
FROM results
WHERE assessment_type = 'Exams'
UNION ALL
SELECT 
    'TOTAL Remaining' as check_type,
    COUNT(*) as count
FROM results
WHERE assessment_type IN ('CA', 'Mid-Term', 'Exams');

-- Step 7: Show remaining result types
SELECT 'STEP 7: Remaining Assessment Types' as step;
SELECT '=======================================' as separator;

SELECT 
    COALESCE(assessment_type, 'NULL') as assessment_type,
    COUNT(*) as count
FROM results
GROUP BY assessment_type
ORDER BY assessment_type;

-- Step 8: Final status
SELECT 'STEP 8: Final Status' as step;
SELECT '=======================================' as separator;

SELECT 
    CASE 
        WHEN (SELECT COUNT(*) FROM results WHERE assessment_type IN ('CA', 'Mid-Term', 'Exams')) = 0
        THEN '✓✓✓ SUCCESS! All CA, Mid-Term, and Exam records deleted successfully!'
        ELSE CONCAT('⚠️ WARNING: ', (SELECT COUNT(*) FROM results WHERE assessment_type IN ('CA', 'Mid-Term', 'Exams')), ' records still remain')
    END as final_status;

-- Backup information
SELECT 
    'BACKUP INFORMATION' as info,
    'Data backed up to: results_backup_assessments' as table_name,
    COUNT(*) as backup_record_count
FROM results_backup_assessments;

-- ============================================
-- TO RESTORE DATA (if needed):
-- ============================================
-- Run this command:
-- INSERT INTO results SELECT * FROM results_backup_assessments;
-- ============================================
