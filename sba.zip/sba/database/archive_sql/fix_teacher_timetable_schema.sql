-- ============================================================================
-- FIX: Teacher Classes and Timetable Schema Errors
-- 1. teacher_classes - missing school_id and assigned_date columns
-- 2. timetable - room vs room_number column mismatch
-- Date: November 17, 2025
-- ============================================================================

-- ============================================================================
-- FIX 1: teacher_classes table - Add missing columns
-- ============================================================================

-- Add school_id column if it doesn't exist
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'teacher_classes' 
AND COLUMN_NAME = 'school_id';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE teacher_classes ADD COLUMN school_id INT(11) NOT NULL AFTER id, ADD KEY idx_school (school_id)',
    'SELECT "Column school_id already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add assigned_date column if it doesn't exist
SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'teacher_classes' 
AND COLUMN_NAME = 'assigned_date';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE teacher_classes ADD COLUMN assigned_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER academic_year',
    'SELECT "Column assigned_date already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Update existing records with school_id from users table
UPDATE teacher_classes tc
INNER JOIN users u ON tc.teacher_id = u.user_id
SET tc.school_id = u.school_id
WHERE tc.school_id = 0 OR tc.school_id IS NULL;

SELECT '✅ Fix 1 Complete: teacher_classes table updated with school_id and assigned_date' AS status;

-- ============================================================================
-- FIX 2: timetable table - Rename room to room_number
-- ============================================================================

-- Check if room column exists and room_number doesn't
SET @has_room = 0;
SET @has_room_number = 0;

SELECT COUNT(*) INTO @has_room
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'timetable' 
AND COLUMN_NAME = 'room';

SELECT COUNT(*) INTO @has_room_number
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'timetable' 
AND COLUMN_NAME = 'room_number';

-- If room exists but room_number doesn't, rename it
SET @query = IF(@has_room = 1 AND @has_room_number = 0,
    'ALTER TABLE timetable CHANGE COLUMN room room_number VARCHAR(50) NULL',
    'SELECT "Column room_number already correct" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT '✅ Fix 2 Complete: timetable room column renamed to room_number' AS status;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Verify teacher_classes table
SELECT 'teacher_classes table columns:' AS info;
SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'teacher_classes'
AND COLUMN_NAME IN ('school_id', 'assigned_date');

-- Verify timetable table
SELECT 'timetable table columns:' AS info;
SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'timetable'
AND COLUMN_NAME = 'room_number';

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

SELECT '
╔════════════════════════════════════════════════════════════════╗
║         ✅ TEACHER & TIMETABLE SCHEMA ERRORS FIXED!            ║
╠════════════════════════════════════════════════════════════════╣
║ 1. teacher_classes: school_id and assigned_date added         ║
║ 2. timetable: room renamed to room_number                     ║
╠════════════════════════════════════════════════════════════════╣
║ NEXT STEPS:                                                    ║
║ • Test assigning teachers to classes                          ║
║ • Test creating timetable entries                             ║
║ • Clear browser cache if needed                               ║
╚════════════════════════════════════════════════════════════════╝
' AS STATUS;
