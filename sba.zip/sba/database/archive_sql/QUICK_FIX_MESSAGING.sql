-- ============================================================================
-- QUICK FIX FOR MESSAGING SYSTEM
-- Simple solution - just add missing column to notifications
-- ============================================================================

-- Add school_id column to existing notifications table
ALTER TABLE `notifications` 
ADD COLUMN `school_id` INT(11) NOT NULL DEFAULT 1 AFTER `notification_id`;

-- Add index
ALTER TABLE `notifications` 
ADD INDEX `idx_school_id` (`school_id`);

-- ============================================================================
-- Now the INSERT will work
-- ============================================================================

-- Sample notification
INSERT IGNORE INTO `notifications` 
(`school_id`, `user_id`, `type`, `title`, `message`, `link`, `icon`, `color`, `read_status`) 
VALUES 
(1, 1, 'system', 'Messaging System Activated', 'The internal messaging system is now active!', '/messages.php', 'fa-envelope', 'primary', 'unread');

-- ============================================================================
-- SUCCESS
-- ============================================================================

SELECT '✅ Fixed! Now run the main SQL file or just visit /admin/messages.php' as message;
