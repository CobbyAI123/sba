-- Fix password_resets table structure
-- This script updates the table to match the password reset system requirements

-- Drop the old table if it exists (preserving data if needed)
-- If you have important data, backup first!

DROP TABLE IF EXISTS `password_resets`;

-- Create the correct password_resets table structure
CREATE TABLE IF NOT EXISTS `password_resets` (
  `reset_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `token_hash` VARCHAR(64) NOT NULL,
  `expires_at` DATETIME NOT NULL,
  `used` TINYINT(1) DEFAULT 0,
  `used_at` DATETIME NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`reset_id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_expires_at` (`expires_at`),
  FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Success message
SELECT 'password_resets table fixed successfully! Token column renamed to token_hash.' AS message;
