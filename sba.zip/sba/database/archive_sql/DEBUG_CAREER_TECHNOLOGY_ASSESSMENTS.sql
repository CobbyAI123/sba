-- ============================================
-- DEBUG CAREER TECHNOLOGY ASSESSMENT ENTRIES
-- Check all assessment records for Career Technology
-- ============================================

-- Find Career Technology subject ID
SELECT subject_id, subject_name 
FROM subjects 
WHERE subject_name LIKE '%Career%' OR subject_name LIKE '%Technology%'
ORDER BY subject_id;

-- Find JHS 1 class ID
SELECT class_id, class_name 
FROM classes 
WHERE class_name LIKE '%JHS%1%'
ORDER BY class_id;

-- Check all assessment records for this subject (replace subject_id with actual ID)
-- Run the above queries first to get the correct subject_id
SELECT 
    sa.assessment_id,
    sa.student_id,
    sa.class_id,
    sa.subject_id,
    sa.term_id,
    sa.teacher_id,
    sa.ca_score,
    sa.midterm_score,
    sa.exam_score,
    sa.total_score,
    sa.created_at,
    s.subject_name,
    CONCAT(u.first_name, ' ', u.last_name) as student_name,
    c.class_name
FROM student_assessments sa
LEFT JOIN subjects s ON sa.subject_id = s.subject_id
LEFT JOIN students st ON sa.student_id = st.student_id
LEFT JOIN users u ON st.user_id = u.user_id
LEFT JOIN classes c ON sa.class_id = c.class_id
WHERE s.subject_name LIKE '%Career%Technology%'
ORDER BY sa.created_at DESC;

-- Check if there are any empty records
SELECT 
    COUNT(*) as count,
    'Empty assessment records (all NULL scores)' as description
FROM student_assessments sa
LEFT JOIN subjects s ON sa.subject_id = s.subject_id
WHERE s.subject_name LIKE '%Career%Technology%'
  AND sa.ca_score IS NULL 
  AND sa.midterm_score IS NULL 
  AND sa.exam_score IS NULL;

-- Show teacher assignment for Career Technology
SELECT 
    cs.class_id,
    cs.subject_id,
    cs.teacher_id,
    c.class_name,
    s.subject_name,
    CONCAT(u.first_name, ' ', u.last_name) as teacher_name
FROM class_subjects cs
INNER JOIN classes c ON cs.class_id = c.class_id
INNER JOIN subjects s ON cs.subject_id = s.subject_id
INNER JOIN users u ON cs.teacher_id = u.user_id
WHERE s.subject_name LIKE '%Career%Technology%'
  AND c.class_name LIKE '%JHS%1%';

SELECT 'DEBUG COMPLETE: Check results above' as Status;
