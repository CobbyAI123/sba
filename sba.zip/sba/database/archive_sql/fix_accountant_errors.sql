-- Fix Accountant Module Errors
-- Date: November 17, 2025
-- Issues: Missing term_id in payments table, missing teacher_collections table

-- =====================================================
-- 1. ADD MISSING COLUMNS TO payments TABLE
-- =====================================================
ALTER TABLE `payments` 
ADD COLUMN IF NOT EXISTS `term_id` INT(11) NULL AFTER `school_id`,
ADD INDEX IF NOT EXISTS `idx_term_id` (`term_id`);

ALTER TABLE `payments`
ADD COLUMN IF NOT EXISTS `payment_reference` VARCHAR(100) NULL AFTER `transaction_id`;

-- =====================================================
-- 2. CREATE deleted_payments TABLE IF NOT EXISTS
-- =====================================================
CREATE TABLE IF NOT EXISTS `deleted_payments` (
  `deleted_payment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `payment_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `term_id` INT(11) NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_date` DATE NOT NULL,
  `payment_method` ENUM('cash', 'card', 'bank_transfer', 'cheque', 'online') DEFAULT 'cash',
  `payment_type` VARCHAR(100) DEFAULT NULL,
  `transaction_id` VARCHAR(100) DEFAULT NULL,
  `payment_reference` VARCHAR(100) DEFAULT NULL,
  `reference` VARCHAR(100) DEFAULT NULL,
  `status` ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'completed',
  `remarks` TEXT DEFAULT NULL,
  `collected_by` INT(11) DEFAULT NULL,
  `deleted_by` INT(11) NOT NULL,
  `deleted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_reason` TEXT DEFAULT NULL,
  PRIMARY KEY (`deleted_payment_id`),
  INDEX `idx_school` (`school_id`),
  INDEX `idx_student` (`student_id`),
  INDEX `idx_term_id` (`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 3. CREATE teacher_collections TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `teacher_collections` (
  `collection_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `teacher_id` INT(11) NOT NULL,
  `collection_type` ENUM('canteen', 'bus', 'other') NOT NULL DEFAULT 'canteen',
  `amount` DECIMAL(10,2) NOT NULL,
  `collection_date` DATE NOT NULL,
  `payment_method` ENUM('cash', 'card', 'bank_transfer', 'cheque', 'mobile_money') DEFAULT 'cash',
  `reference` VARCHAR(100) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `remarks` TEXT DEFAULT NULL,
  `recorded_by` INT(11) NOT NULL,
  `status` ENUM('pending', 'verified', 'deposited') DEFAULT 'pending',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`collection_id`),
  INDEX `idx_school` (`school_id`),
  INDEX `idx_teacher` (`teacher_id`),
  INDEX `idx_collection_date` (`collection_date`),
  INDEX `idx_collection_type` (`collection_type`),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`teacher_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`recorded_by`) REFERENCES `users`(`user_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- SUCCESS MESSAGE
-- =====================================================
SELECT 'Accountant module errors fixed successfully!' AS Status;
