-- ============================================================================
-- FIXED LIBRARY MANAGEMENT SYSTEM
-- Compatible with existing database structure
-- Date: November 11, 2025
-- ============================================================================

-- Books Catalog Table
CREATE TABLE IF NOT EXISTS `library_books` (
  `book_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `isbn` VARCHAR(20) NULL,
  `title` VARCHAR(255) NOT NULL,
  `author` VARCHAR(255) NOT NULL,
  `publisher` VARCHAR(255) NULL,
  `category` VARCHAR(100) NULL,
  `edition` VARCHAR(50) NULL,
  `publication_year` INT(4) NULL,
  `total_copies` INT(3) DEFAULT 1,
  `available_copies` INT(3) DEFAULT 1,
  `book_location` VARCHAR(100) NULL COMMENT 'Shelf/Section',
  `description` TEXT NULL,
  `cover_image` VARCHAR(255) NULL,
  `price` DECIMAL(10,2) NULL,
  `status` ENUM('available', 'unavailable', 'damaged', 'lost') DEFAULT 'available',
  `added_by` INT(11) NOT NULL,
  `added_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`book_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_isbn` (`isbn`),
  KEY `idx_title` (`title`),
  KEY `idx_category` (`category`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Book Issues Table (Issue/Return tracking)
CREATE TABLE IF NOT EXISTS `library_issues` (
  `issue_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `book_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `issued_by` INT(11) NOT NULL COMMENT 'Librarian/Admin user_id',
  `issue_date` DATE NOT NULL,
  `due_date` DATE NOT NULL,
  `return_date` DATE NULL,
  `returned_by` INT(11) NULL COMMENT 'Librarian who processed return',
  `status` ENUM('issued', 'returned', 'overdue', 'lost') DEFAULT 'issued',
  `book_condition_on_issue` ENUM('excellent', 'good', 'fair', 'poor') DEFAULT 'good',
  `book_condition_on_return` ENUM('excellent', 'good', 'fair', 'poor') NULL,
  `fine_amount` DECIMAL(10,2) DEFAULT 0.00,
  `fine_paid` DECIMAL(10,2) DEFAULT 0.00,
  `fine_status` ENUM('none', 'pending', 'paid', 'waived') DEFAULT 'none',
  `notes` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`issue_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_book` (`book_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_status` (`status`),
  KEY `idx_issue_date` (`issue_date`),
  KEY `idx_due_date` (`due_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Library Settings Table
CREATE TABLE IF NOT EXISTS `library_settings` (
  `setting_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `max_books_per_student` INT(2) DEFAULT 3,
  `issue_duration_days` INT(3) DEFAULT 14,
  `fine_per_day` DECIMAL(10,2) DEFAULT 5.00,
  `renewal_allowed` TINYINT(1) DEFAULT 1,
  `max_renewals` INT(1) DEFAULT 2,
  `reminder_days_before_due` INT(2) DEFAULT 2,
  `auto_calculate_fines` TINYINT(1) DEFAULT 1,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Book Categories Table
CREATE TABLE IF NOT EXISTS `library_categories` (
  `category_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `category_name` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `idx_school_category` (`school_id`, `category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Book Requests Table
CREATE TABLE IF NOT EXISTS `library_book_requests` (
  `request_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `book_title` VARCHAR(255) NOT NULL,
  `author` VARCHAR(255) NULL,
  `reason` TEXT NULL,
  `status` ENUM('pending', 'approved', 'rejected', 'purchased') DEFAULT 'pending',
  `admin_notes` TEXT NULL,
  `requested_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` TIMESTAMP NULL,
  PRIMARY KEY (`request_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- INSERT DEFAULT SETTINGS
-- ============================================================================

INSERT INTO `library_settings` 
(`school_id`, `max_books_per_student`, `issue_duration_days`, `fine_per_day`, `renewal_allowed`, `max_renewals`)
SELECT school_id, 3, 14, 5.00, 1, 2
FROM schools
WHERE school_id NOT IN (SELECT school_id FROM library_settings)
ON DUPLICATE KEY UPDATE setting_id=setting_id;

-- ============================================================================
-- INSERT DEFAULT CATEGORIES
-- ============================================================================

INSERT INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Fiction', 'Fiction novels and stories'
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM library_categories 
    WHERE school_id = s.school_id AND category_name = 'Fiction'
);

INSERT INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Non-Fiction', 'Non-fiction books and references'
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM library_categories 
    WHERE school_id = s.school_id AND category_name = 'Non-Fiction'
);

INSERT INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Science', 'Science and technology books'
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM library_categories 
    WHERE school_id = s.school_id AND category_name = 'Science'
);

INSERT INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Mathematics', 'Mathematics and related books'
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM library_categories 
    WHERE school_id = s.school_id AND category_name = 'Mathematics'
);

INSERT INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Literature', 'Classic and modern literature'
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM library_categories 
    WHERE school_id = s.school_id AND category_name = 'Literature'
);

INSERT INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Reference', 'Dictionaries, encyclopedias, reference books'
FROM schools s
WHERE NOT EXISTS (
    SELECT 1 FROM library_categories 
    WHERE school_id = s.school_id AND category_name = 'Reference'
);

-- ============================================================================
-- TRIGGERS FOR AUTO-CALCULATIONS
-- ============================================================================

DELIMITER //

-- Trigger to update book availability when issued
DROP TRIGGER IF EXISTS after_book_issue//
CREATE TRIGGER after_book_issue
AFTER INSERT ON library_issues
FOR EACH ROW
BEGIN
    IF NEW.status = 'issued' THEN
        UPDATE library_books 
        SET available_copies = available_copies - 1
        WHERE book_id = NEW.book_id AND available_copies > 0;
    END IF;
END//

-- Trigger to update book availability when returned
DROP TRIGGER IF EXISTS after_book_return//
CREATE TRIGGER after_book_return
AFTER UPDATE ON library_issues
FOR EACH ROW
BEGIN
    IF OLD.status = 'issued' AND NEW.status = 'returned' THEN
        UPDATE library_books 
        SET available_copies = available_copies + 1
        WHERE book_id = NEW.book_id;
    END IF;
END//

DELIMITER ;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT 'Library system tables created successfully!' as status;
SELECT 'Tables: library_books, library_issues, library_settings, library_categories, library_book_requests' as tables_created;
SELECT 'Triggers: after_book_issue, after_book_return' as triggers_created;
SELECT 'Note: Views removed - PHP queries used instead for better compatibility' as note;
