USE `school_management_system`;

-- Fix payments table foreign key constraint
ALTER TABLE `payments` DROP FOREIGN KEY `payments_ibfk_3`;
ALTER TABLE `payments` ADD CONSTRAINT `payments_ibfk_3` 
FOREIGN KEY (`term_id`) REFERENCES `terms`(`term_id`) ON DELETE CASCADE;
