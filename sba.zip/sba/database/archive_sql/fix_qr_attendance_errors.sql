-- ============================================================================
-- FIX: QR Codes, Attendance, and Results Publishing Errors
-- 1. student_qr_codes - missing expires_at column
-- 2. student_assessments - missing published_to_parents column
-- 3. attendance_logs - table doesn't exist
-- Date: November 17, 2025
-- ============================================================================

-- ============================================================================
-- FIX 1: student_qr_codes - Add expires_at column
-- ============================================================================

SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'student_qr_codes' 
AND COLUMN_NAME = 'expires_at';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE student_qr_codes ADD COLUMN expires_at TIMESTAMP NULL AFTER last_used',
    'SELECT "Column expires_at already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT '✅ Fix 1: student_qr_codes.expires_at column added' AS status;

-- ============================================================================
-- FIX 2: student_assessments - Add published_to_parents column
-- ============================================================================

SET @col_exists = 0;
SELECT COUNT(*) INTO @col_exists 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'student_assessments' 
AND COLUMN_NAME = 'published_to_parents';

SET @query = IF(@col_exists = 0,
    'ALTER TABLE student_assessments ADD COLUMN published_to_parents TINYINT(1) DEFAULT 0 AFTER teacher_comment, ADD COLUMN published_at TIMESTAMP NULL AFTER published_to_parents, ADD COLUMN published_by INT(11) NULL AFTER published_at, ADD KEY idx_published (published_to_parents)',
    'SELECT "Column published_to_parents already exists" AS info');
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT '✅ Fix 2: student_assessments publishing columns added' AS status;

-- ============================================================================
-- FIX 3: Create attendance_logs table
-- ============================================================================

CREATE TABLE IF NOT EXISTS `attendance_logs` (
  `log_id` INT(11) NOT NULL AUTO_INCREMENT,
  `attendance_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `date` DATE NOT NULL,
  `status` ENUM('present', 'absent', 'late', 'excused', 'half_day') DEFAULT 'present',
  `check_in_time` TIME NULL,
  `check_out_time` TIME NULL,
  `qr_code_scanned` TINYINT(1) DEFAULT 0,
  `marked_by` INT(11) NULL,
  `marking_method` ENUM('manual', 'qr_scan', 'biometric', 'auto') DEFAULT 'manual',
  `remarks` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `idx_attendance` (`attendance_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_school_date` (`school_id`, `date`),
  KEY `idx_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SELECT '✅ Fix 3: attendance_logs table created' AS status;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT '═══════════════════════════════════════' AS '';
SELECT 'VERIFICATION RESULTS' AS '';
SELECT '═══════════════════════════════════════' AS '';

-- Verify student_qr_codes.expires_at
SELECT 'student_qr_codes.expires_at:' AS Check_Item,
       IF(COUNT(*) > 0, '✅ EXISTS', '❌ MISSING') AS Status
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'student_qr_codes' 
AND COLUMN_NAME = 'expires_at';

-- Verify student_assessments.published_to_parents
SELECT 'student_assessments.published_to_parents:' AS Check_Item,
       IF(COUNT(*) > 0, '✅ EXISTS', '❌ MISSING') AS Status
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'student_assessments' 
AND COLUMN_NAME = 'published_to_parents';

-- Verify attendance_logs table
SELECT 'attendance_logs table:' AS Check_Item,
       IF(COUNT(*) > 0, '✅ EXISTS', '❌ MISSING') AS Status
FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_SCHEMA = DATABASE() 
AND TABLE_NAME = 'attendance_logs';

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

SELECT '
╔═══════════════════════════════════════════════════════════════╗
║       ✅ QR & ATTENDANCE SCHEMA ERRORS FIXED!                 ║
╠═══════════════════════════════════════════════════════════════╣
║ 1. student_qr_codes: expires_at column added                 ║
║ 2. student_assessments: published_to_parents columns added   ║
║ 3. attendance_logs: table created                            ║
╠═══════════════════════════════════════════════════════════════╣
║ NEXT STEPS:                                                   ║
║ • Test QR code generation                                     ║
║ • Test results publishing to parents                          ║
║ • Test attendance analytics                                   ║
╚═══════════════════════════════════════════════════════════════╝
' AS STATUS;
