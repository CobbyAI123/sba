-- Fix Student Pages - Create Missing Tables
-- Run this in phpMyAdmin to fix: My Subjects, Exams, Results, Fee Payments

-- 1. Exam Results table (for My Results page)
CREATE TABLE IF NOT EXISTS `exam_results` (
  `result_id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `marks_obtained` decimal(5,2) NOT NULL,
  `total_marks` decimal(5,2) NOT NULL,
  `grade` varchar(5) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`result_id`),
  KEY `exam_id` (`exam_id`),
  KEY `student_id` (`student_id`),
  KEY `subject_id` (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Fee Types table (for Fee Payments page)
CREATE TABLE IF NOT EXISTS `fee_types` (
  `fee_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `fee_name` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `frequency` enum('one-time','monthly','termly','yearly') DEFAULT 'termly',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`fee_type_id`),
  KEY `school_id` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Payments table (for Fee Payments page)
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `fee_type_id` int(11) DEFAULT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_method` enum('cash','bank_transfer','card','mobile_money') DEFAULT 'cash',
  `payment_status` enum('pending','completed','failed','refunded') DEFAULT 'completed',
  `transaction_id` varchar(100) DEFAULT NULL,
  `receipt_number` varchar(50) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  KEY `school_id` (`school_id`),
  KEY `student_id` (`student_id`),
  KEY `fee_type_id` (`fee_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Insert sample fee types
INSERT INTO `fee_types` (`school_id`, `fee_name`, `amount`, `description`, `frequency`, `status`) VALUES
(1, 'Tuition Fee', 1500.00, 'Termly tuition fee', 'termly', 'active'),
(1, 'Library Fee', 100.00, 'Library access fee', 'termly', 'active'),
(1, 'Sports Fee', 150.00, 'Sports and games fee', 'termly', 'active'),
(1, 'Lab Fee', 200.00, 'Science laboratory fee', 'termly', 'active'),
(1, 'Transport Fee', 300.00, 'School transport fee', 'monthly', 'active')
ON DUPLICATE KEY UPDATE fee_name=fee_name;

-- Note: The following tables should already exist from previous setup:
-- - students
-- - classes  
-- - subjects
-- - class_subjects
-- - exams
-- - marks (used by Results page)

-- If marks table doesn't exist, create it:
CREATE TABLE IF NOT EXISTS `marks` (
  `mark_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `marks_obtained` decimal(5,2) NOT NULL,
  `total_marks` decimal(5,2) NOT NULL DEFAULT 100.00,
  `grade` varchar(5) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mark_id`),
  UNIQUE KEY `unique_mark` (`student_id`,`exam_id`,`subject_id`),
  KEY `student_id` (`student_id`),
  KEY `exam_id` (`exam_id`),
  KEY `subject_id` (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
