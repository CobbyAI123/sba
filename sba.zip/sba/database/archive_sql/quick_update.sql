-- Quick Update Script - Apply all changes NOW
USE school_management_system;

-- Step 1: Add missing subjects to all schools
INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'English Language', 'ENG', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='English Language');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Mathematics', 'MATH', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Mathematics');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Integrated Science', 'SCI', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Integrated Science');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Religious and Moral Education', 'RME', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Religious and Moral Education');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Creative Arts', 'CA', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Creative Arts');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'History', 'HIST', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='History');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Physical Education', 'PE', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Physical Education');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Ghanaian Language', 'GHL', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Ghanaian Language');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'UC Mathematics', 'UCMATH', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='UC Mathematics');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'French', 'FRE', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='French');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Social Studies', 'SS', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Social Studies');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Computing', 'COMP', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Computing');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Career Technology', 'CT', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Career Technology');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Literacy', 'LIT', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Literacy');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Numeracy', 'NUM', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Numeracy');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Coloring', 'COL', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Coloring');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Phonics', 'PHO', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Phonics');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Writing', 'WRI', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Writing');

INSERT INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 1, 'Our World Our People', 'OWOP', NOW()
WHERE NOT EXISTS (SELECT 1 FROM subjects WHERE school_id=1 AND subject_name='Our World Our People');

-- Step 2: Update student admission numbers with new format
UPDATE students s
INNER JOIN schools sc ON s.school_id = sc.school_id
SET s.admission_number = CONCAT(
    UPPER(sc.school_code),
    '/',
    YEAR(CURDATE()),
    '/',
    LPAD(s.class_id, 2, '0'),
    '/',
    LPAD(s.student_id, 5, '0')
)
WHERE s.class_id IS NOT NULL;

-- Step 3: Update usernames
UPDATE users u
INNER JOIN students s ON u.user_id = s.user_id
SET u.username = LOWER(REPLACE(s.admission_number, '/', ''))
WHERE u.role = 'student';

-- Verification
SELECT 'Subjects added successfully!' as Status;
SELECT COUNT(*) as TotalSubjects FROM subjects WHERE school_id=1;
SELECT student_id, admission_number, first_name, last_name FROM students LIMIT 5;
