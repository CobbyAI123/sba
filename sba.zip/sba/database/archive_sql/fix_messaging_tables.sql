-- ============================================================================
-- FIX MESSAGING SYSTEM TABLES
-- Resolve conflicts with existing tables
-- Date: November 11, 2025
-- ============================================================================

-- First, check existing notifications table structure
DESCRIBE notifications;

-- Option 1: Add school_id to existing notifications table if it doesn't exist
ALTER TABLE `notifications` 
ADD COLUMN IF NOT EXISTS `school_id` INT(11) NOT NULL AFTER `notification_id`,
ADD INDEX IF NOT EXISTS `idx_school_id` (`school_id`);

-- Add foreign key if it doesn't exist (may fail if already exists, that's okay)
SET @exist = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
              WHERE TABLE_SCHEMA = DATABASE() 
              AND TABLE_NAME = 'notifications' 
              AND CONSTRAINT_NAME = 'notifications_ibfk_1');

SET @sqlstmt = IF(@exist > 0, 
    'SELECT "Foreign key already exists" as status', 
    'ALTER TABLE `notifications` ADD FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE');

PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================================
-- Create Messages Table (with safety checks)
-- ============================================================================

CREATE TABLE IF NOT EXISTS `messages` (
  `message_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `sender_id` INT(11) NOT NULL COMMENT 'User ID of sender',
  `recipient_id` INT(11) NULL COMMENT 'NULL for broadcast messages',
  `recipient_role` VARCHAR(50) NULL COMMENT 'For role-based broadcasts',
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `attachment` VARCHAR(255) NULL,
  `message_type` ENUM('personal', 'broadcast', 'announcement') DEFAULT 'personal',
  `priority` ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
  `read_status` ENUM('unread', 'read') DEFAULT 'unread',
  `replied_to` INT(11) NULL COMMENT 'If this is a reply, original message_id',
  `deleted_by_sender` TINYINT(1) DEFAULT 0,
  `deleted_by_recipient` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `read_at` TIMESTAMP NULL,
  PRIMARY KEY (`message_id`),
  KEY `idx_school_sender` (`school_id`, `sender_id`),
  KEY `idx_school_recipient` (`school_id`, `recipient_id`),
  KEY `idx_read_status` (`read_status`),
  KEY `idx_message_type` (`message_type`),
  KEY `idx_created_at` (`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Add foreign keys to messages table if they don't exist
SET @exist_fk1 = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
                  WHERE TABLE_SCHEMA = DATABASE() 
                  AND TABLE_NAME = 'messages' 
                  AND CONSTRAINT_NAME = 'messages_ibfk_1');

SET @sqlstmt1 = IF(@exist_fk1 > 0, 
    'SELECT "FK1 exists" as status', 
    'ALTER TABLE `messages` ADD FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE');

PREPARE stmt1 FROM @sqlstmt1;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;

SET @exist_fk2 = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
                  WHERE TABLE_SCHEMA = DATABASE() 
                  AND TABLE_NAME = 'messages' 
                  AND CONSTRAINT_NAME = 'messages_ibfk_2');

SET @sqlstmt2 = IF(@exist_fk2 > 0, 
    'SELECT "FK2 exists" as status', 
    'ALTER TABLE `messages` ADD FOREIGN KEY (`sender_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE');

PREPARE stmt2 FROM @sqlstmt2;
EXECUTE stmt2;
DEALLOCATE PREPARE stmt2;

SET @exist_fk3 = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
                  WHERE TABLE_SCHEMA = DATABASE() 
                  AND TABLE_NAME = 'messages' 
                  AND CONSTRAINT_NAME = 'messages_ibfk_3');

SET @sqlstmt3 = IF(@exist_fk3 > 0, 
    'SELECT "FK3 exists" as status', 
    'ALTER TABLE `messages` ADD FOREIGN KEY (`recipient_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE');

PREPARE stmt3 FROM @sqlstmt3;
EXECUTE stmt3;
DEALLOCATE PREPARE stmt3;

-- ============================================================================
-- Create Message Attachments Table
-- ============================================================================

CREATE TABLE IF NOT EXISTS `message_attachments` (
  `attachment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `message_id` INT(11) NOT NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_size` INT(11) NULL COMMENT 'Size in bytes',
  `file_type` VARCHAR(50) NULL,
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attachment_id`),
  KEY `idx_message` (`message_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Add foreign key if doesn't exist
SET @exist_fk = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
                WHERE TABLE_SCHEMA = DATABASE() 
                AND TABLE_NAME = 'message_attachments' 
                AND CONSTRAINT_NAME = 'message_attachments_ibfk_1');

SET @sqlstmt = IF(@exist_fk > 0, 
    'SELECT "FK exists" as status', 
    'ALTER TABLE `message_attachments` ADD FOREIGN KEY (`message_id`) REFERENCES `messages`(`message_id`) ON DELETE CASCADE');

PREPARE stmt FROM @sqlstmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================================
-- Create Message Templates Table
-- ============================================================================

CREATE TABLE IF NOT EXISTS `message_templates` (
  `template_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `created_by` INT(11) NOT NULL,
  `template_name` VARCHAR(100) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `category` VARCHAR(50) NULL COMMENT 'fee_reminder, exam_notification, etc.',
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`template_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Add foreign keys if they don't exist
SET @exist_fk1 = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
                  WHERE TABLE_SCHEMA = DATABASE() 
                  AND TABLE_NAME = 'message_templates' 
                  AND CONSTRAINT_NAME = 'message_templates_ibfk_1');

SET @sqlstmt1 = IF(@exist_fk1 > 0, 
    'SELECT "FK1 exists" as status', 
    'ALTER TABLE `message_templates` ADD FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE');

PREPARE stmt1 FROM @sqlstmt1;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;

SET @exist_fk2 = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
                  WHERE TABLE_SCHEMA = DATABASE() 
                  AND TABLE_NAME = 'message_templates' 
                  AND CONSTRAINT_NAME = 'message_templates_ibfk_2');

SET @sqlstmt2 = IF(@exist_fk2 > 0, 
    'SELECT "FK2 exists" as status', 
    'ALTER TABLE `message_templates` ADD FOREIGN KEY (`created_by`) REFERENCES `users`(`user_id`) ON DELETE CASCADE');

PREPARE stmt2 FROM @sqlstmt2;
EXECUTE stmt2;
DEALLOCATE PREPARE stmt2;

-- ============================================================================
-- Create SMS Logs Table
-- ============================================================================

CREATE TABLE IF NOT EXISTS `sms_logs` (
  `sms_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NULL COMMENT 'Recipient user if applicable',
  `recipient_phone` VARCHAR(20) NOT NULL,
  `message` TEXT NOT NULL,
  `sms_type` VARCHAR(50) NULL COMMENT 'fee_reminder, result_notification, etc.',
  `status` ENUM('pending', 'sent', 'failed', 'delivered') DEFAULT 'pending',
  `gateway` VARCHAR(50) NULL COMMENT 'twilio, africastalking, etc.',
  `gateway_response` TEXT NULL,
  `cost` DECIMAL(10,4) NULL COMMENT 'Cost per SMS',
  `sent_at` TIMESTAMP NULL,
  `delivered_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sms_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Add foreign keys if they don't exist
SET @exist_fk1 = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
                  WHERE TABLE_SCHEMA = DATABASE() 
                  AND TABLE_NAME = 'sms_logs' 
                  AND CONSTRAINT_NAME = 'sms_logs_ibfk_1');

SET @sqlstmt1 = IF(@exist_fk1 > 0, 
    'SELECT "FK1 exists" as status', 
    'ALTER TABLE `sms_logs` ADD FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE');

PREPARE stmt1 FROM @sqlstmt1;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;

SET @exist_fk2 = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
                  WHERE TABLE_SCHEMA = DATABASE() 
                  AND TABLE_NAME = 'sms_logs' 
                  AND CONSTRAINT_NAME = 'sms_logs_ibfk_2');

SET @sqlstmt2 = IF(@exist_fk2 > 0, 
    'SELECT "FK2 exists" as status', 
    'ALTER TABLE `sms_logs` ADD FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL');

PREPARE stmt2 FROM @sqlstmt2;
EXECUTE stmt2;
DEALLOCATE PREPARE stmt2;

-- ============================================================================
-- Create Email Logs Table
-- ============================================================================

CREATE TABLE IF NOT EXISTS `email_logs` (
  `email_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NULL COMMENT 'Recipient user if applicable',
  `recipient_email` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `email_type` VARCHAR(50) NULL,
  `status` ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
  `sent_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`email_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Add foreign keys if they don't exist
SET @exist_fk1 = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
                  WHERE TABLE_SCHEMA = DATABASE() 
                  AND TABLE_NAME = 'email_logs' 
                  AND CONSTRAINT_NAME = 'email_logs_ibfk_1');

SET @sqlstmt1 = IF(@exist_fk1 > 0, 
    'SELECT "FK1 exists" as status', 
    'ALTER TABLE `email_logs` ADD FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE');

PREPARE stmt1 FROM @sqlstmt1;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;

SET @exist_fk2 = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
                  WHERE TABLE_SCHEMA = DATABASE() 
                  AND TABLE_NAME = 'email_logs' 
                  AND CONSTRAINT_NAME = 'email_logs_ibfk_2');

SET @sqlstmt2 = IF(@exist_fk2 > 0, 
    'SELECT "FK2 exists" as status', 
    'ALTER TABLE `email_logs` ADD FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL');

PREPARE stmt2 FROM @sqlstmt2;
EXECUTE stmt2;
DEALLOCATE PREPARE stmt2;

-- ============================================================================
-- INSERT SAMPLE DATA (with proper error handling)
-- ============================================================================

-- Sample notification (check if school_id column exists first)
INSERT INTO `notifications` 
(`school_id`, `user_id`, `type`, `title`, `message`, `link`, `icon`, `color`, `read_status`) 
SELECT 1, 1, 'system', 'Messaging System Activated', 
'The internal messaging system is now active. You can now send and receive messages!', 
'/messages.php', 'fa-envelope', 'primary', 'unread'
WHERE EXISTS (SELECT * FROM information_schema.COLUMNS 
              WHERE TABLE_SCHEMA = DATABASE() 
              AND TABLE_NAME = 'notifications' 
              AND COLUMN_NAME = 'school_id')
AND NOT EXISTS (SELECT * FROM notifications WHERE type = 'system' AND title = 'Messaging System Activated');

-- Sample message templates
INSERT INTO `message_templates`
(`school_id`, `created_by`, `template_name`, `subject`, `message`, `category`)
SELECT 1, 1, 'Fee Reminder', 'School Fee Payment Reminder', 
'Dear Parent,\n\nThis is a reminder that your child\'s school fees for the current term are due. Please make payment at your earliest convenience.\n\nThank you for your cooperation.', 
'fee_reminder'
WHERE NOT EXISTS (SELECT * FROM message_templates WHERE template_name = 'Fee Reminder' AND school_id = 1);

INSERT INTO `message_templates`
(`school_id`, `created_by`, `template_name`, `subject`, `message`, `category`)
SELECT 1, 1, 'Exam Notification', 'Upcoming Examination Notice', 
'Dear Student,\n\nThis is to inform you that examinations for the current term will commence on [DATE]. Please ensure you are well prepared.\n\nGood luck!', 
'exam'
WHERE NOT EXISTS (SELECT * FROM message_templates WHERE template_name = 'Exam Notification' AND school_id = 1);

INSERT INTO `message_templates`
(`school_id`, `created_by`, `template_name`, `subject`, `message`, `category`)
SELECT 1, 1, 'Result Release', 'Examination Results Released', 
'Dear Parent/Student,\n\nExamination results for the term have been released. Please login to your portal to view the results.\n\nThank you.', 
'result'
WHERE NOT EXISTS (SELECT * FROM message_templates WHERE template_name = 'Result Release' AND school_id = 1);

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Check if tables were created
SELECT 'Messages table exists' as status WHERE EXISTS 
(SELECT * FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'messages');

SELECT 'Notifications table has school_id' as status WHERE EXISTS 
(SELECT * FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'notifications' AND COLUMN_NAME = 'school_id');

SELECT 'Message templates exist' as status WHERE EXISTS 
(SELECT * FROM message_templates LIMIT 1);

-- Count records
SELECT 'Setup complete!' as status,
       (SELECT COUNT(*) FROM messages) as total_messages,
       (SELECT COUNT(*) FROM message_templates) as total_templates;

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

SELECT '✅ Messaging System tables fixed and created successfully!' as status;
SELECT 'You can now use the messaging features in the system.' as message;
SELECT 'Visit: /admin/messages.php to start messaging!' as next_step;
