-- Create missing student records for student users who don't have a student_id
USE `school_management_system`;

-- This script will create student records for users with role='student' that don't have entries in the students table

-- First, let's see which student users are missing student records:
-- SELECT u.user_id, u.username, u.first_name, u.last_name 
-- FROM users u
-- WHERE u.role = 'student' AND u.user_id NOT IN (SELECT user_id FROM students WHERE user_id IS NOT NULL);

-- Create student records for users who don't have them
INSERT INTO students (school_id, user_id, admission_number, first_name, last_name, date_of_birth, gender, address, phone, email, admission_date, status)
SELECT 
    u.school_id,
    u.user_id,
    CONCAT('STU-', u.user_id, '-', DATE_FORMAT(NOW(), '%Y%m%d')),
    u.first_name,
    u.last_name,
    CURDATE(),
    'male',
    '',
    u.phone,
    u.email,
    CURDATE(),
    'active'
FROM users u
WHERE u.role = 'student' 
AND u.user_id NOT IN (SELECT COALESCE(user_id, 0) FROM students WHERE user_id IS NOT NULL)
ON DUPLICATE KEY UPDATE admission_number = admission_number;
