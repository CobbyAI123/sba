-- =====================================================
-- CREATE STUDENT_FEES TABLE - IMMEDIATE FIX
-- This is why payments aren't showing!
-- =====================================================

USE school_management_system;

-- 1. Create the student_fees table
-- =====================================================
DROP TABLE IF EXISTS student_fees;

CREATE TABLE student_fees (
    fee_id INT AUTO_INCREMENT PRIMARY KEY,
    school_id INT NOT NULL,
    student_id INT NOT NULL,
    total_fees DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Total fees for the student',
    total_paid DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Total amount paid',
    balance DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Outstanding balance',
    last_payment_date DATE DEFAULT NULL COMMENT 'Date of last payment',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    UNIQUE KEY unique_student_fee (school_id, student_id),
    INDEX idx_student_id (student_id),
    INDEX idx_school_id (school_id),
    INDEX idx_balance (balance),
    INDEX idx_updated (updated_at)
    
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
COMMENT='Student fee summary table - tracks total paid and balances';

SELECT '✅ student_fees table created successfully!' as status;

-- 2. Sync ALL existing payments to the new table
-- =====================================================
INSERT INTO student_fees (school_id, student_id, total_paid, last_payment_date, updated_at)
SELECT 
    p.school_id,
    p.student_id,
    SUM(CASE WHEN p.status IN ('paid', 'completed') THEN p.amount ELSE 0 END) as total_paid,
    MAX(CASE WHEN p.status IN ('paid', 'completed') THEN p.payment_date END) as last_payment_date,
    NOW() as updated_at
FROM payments p
INNER JOIN students s ON p.student_id = s.student_id
WHERE p.status IN ('paid', 'completed')
GROUP BY p.school_id, p.student_id;

SELECT CONCAT('✅ Synced ', COUNT(*), ' student payment records!') as status
FROM student_fees;

-- 3. Calculate balances based on fee structure
-- =====================================================
UPDATE student_fees sf
INNER JOIN students s ON sf.student_id = s.student_id
LEFT JOIN (
    SELECT 
        fs.school_id,
        fs.class_id,
        SUM(fs.amount) as total_fees
    FROM fee_structure fs
    GROUP BY fs.school_id, fs.class_id
) fs ON s.school_id = fs.school_id AND s.class_id = fs.class_id
SET 
    sf.total_fees = COALESCE(fs.total_fees, 0),
    sf.balance = COALESCE(fs.total_fees, 0) - sf.total_paid;

SELECT '✅ Student balances calculated!' as status;

-- 4. Show the results
-- =====================================================
SELECT '========== VERIFICATION ==========' as '';

SELECT 
    'Total Students with Payments' as metric,
    COUNT(*) as count,
    CONCAT('₵', FORMAT(SUM(total_paid), 2)) as total_collected,
    CONCAT('₵', FORMAT(SUM(balance), 2)) as total_outstanding
FROM student_fees;

SELECT '========== RECENT STUDENT FEES (TOP 10) ==========' as '';

SELECT 
    sf.student_id,
    s.admission_number,
    CONCAT(u.first_name, ' ', u.last_name) as student_name,
    c.class_name,
    CONCAT('₵', FORMAT(sf.total_fees, 2)) as total_fees,
    CONCAT('₵', FORMAT(sf.total_paid, 2)) as total_paid,
    CONCAT('₵', FORMAT(sf.balance, 2)) as balance,
    sf.last_payment_date,
    sf.updated_at
FROM student_fees sf
INNER JOIN students s ON sf.student_id = s.student_id
INNER JOIN users u ON s.user_id = u.user_id
LEFT JOIN classes c ON s.class_id = c.class_id
ORDER BY sf.updated_at DESC
LIMIT 10;

-- 5. Verify payments are linked
-- =====================================================
SELECT '========== PAYMENT-STUDENT LINK VERIFICATION ==========' as '';

SELECT 
    'Payments in Database' as source,
    COUNT(DISTINCT student_id) as unique_students,
    COUNT(*) as total_records,
    CONCAT('₵', FORMAT(SUM(amount), 2)) as total_amount
FROM payments
WHERE status IN ('paid', 'completed')

UNION ALL

SELECT 
    'Student Fees Summary' as source,
    COUNT(DISTINCT student_id) as unique_students,
    COUNT(*) as total_records,
    CONCAT('₵', FORMAT(SUM(total_paid), 2)) as total_amount
FROM student_fees;

-- 6. Show today's payments (if any)
-- =====================================================
SELECT '========== TODAY\'S PAYMENTS ==========' as '';

SELECT 
    s.admission_number,
    CONCAT(u.first_name, ' ', u.last_name) as student_name,
    CONCAT('₵', FORMAT(p.amount, 2)) as amount,
    p.payment_method,
    p.payment_date,
    TIME(p.created_at) as time_collected
FROM payments p
INNER JOIN students s ON p.student_id = s.student_id
INNER JOIN users u ON s.user_id = u.user_id
WHERE DATE(p.created_at) = CURDATE()
AND p.status IN ('paid', 'completed')
ORDER BY p.created_at DESC;

-- 7. Final instructions
-- =====================================================
SELECT '==========================================' as '';
SELECT '✅ STUDENT_FEES TABLE CREATED & SYNCED!' as status;
SELECT '' as '';
SELECT 'NEXT STEPS:' as instruction;
SELECT '1. Clear your browser cache (Ctrl + Shift + Delete)' as step;
SELECT '2. Hard refresh the page (Ctrl + F5)' as step;
SELECT '3. Go to Student Payments page' as step;
SELECT '4. All payments should now be visible!' as step;
SELECT '' as '';
SELECT 'To prevent future issues, run: SAFE_FIX_PAYMENTS_SYNC.sql' as recommendation;
SELECT '(This will create automatic triggers)' as info;
