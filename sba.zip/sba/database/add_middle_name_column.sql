-- Add missing middle_name column to students table
USE school_management_system;

-- Check if column exists and add it if not
ALTER TABLE students 
ADD COLUMN IF NOT EXISTS middle_name VARCHAR(100) DEFAULT NULL AFTER last_name;

-- Verify the column was added
DESCRIBE students;

SELECT 'middle_name column added successfully!' as Status;
