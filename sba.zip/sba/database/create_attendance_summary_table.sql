-- ================================================================================
-- CREATE ATTENDANCE_SUMMARY TABLE
-- Date: November 17, 2025
-- Purpose: Store monthly attendance statistics for students
-- ================================================================================

CREATE TABLE IF NOT EXISTS `attendance_summary` (
  `summary_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `month` INT(2) NOT NULL,
  `year` INT(4) NOT NULL,
  `total_days` INT(11) DEFAULT 0,
  `present_days` INT(11) DEFAULT 0,
  `absent_days` INT(11) DEFAULT 0,
  `late_days` INT(11) DEFAULT 0,
  `excused_days` INT(11) DEFAULT 0,
  `attendance_percentage` DECIMAL(5,2) DEFAULT 0.00,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`summary_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_month_year` (`month`, `year`),
  UNIQUE KEY `unique_summary` (`student_id`, `month`, `year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create stored procedure to calculate attendance summary
DROP PROCEDURE IF EXISTS calculate_attendance_summary;

DELIMITER //
CREATE PROCEDURE calculate_attendance_summary(
    IN p_student_id INT,
    IN p_month INT,
    IN p_year INT
)
BEGIN
    DECLARE v_total_days INT DEFAULT 0;
    DECLARE v_present_days INT DEFAULT 0;
    DECLARE v_absent_days INT DEFAULT 0;
    DECLARE v_late_days INT DEFAULT 0;
    DECLARE v_excused_days INT DEFAULT 0;
    DECLARE v_percentage DECIMAL(5,2) DEFAULT 0.00;
    DECLARE v_school_id INT;
    
    -- Get school_id
    SELECT school_id INTO v_school_id 
    FROM students 
    WHERE student_id = p_student_id;
    
    -- Count attendance records for the month
    SELECT 
        COUNT(*) INTO v_total_days
    FROM attendance_logs
    WHERE student_id = p_student_id
      AND MONTH(date) = p_month
      AND YEAR(date) = p_year;
    
    -- Count present days
    SELECT COUNT(*) INTO v_present_days
    FROM attendance_logs
    WHERE student_id = p_student_id
      AND MONTH(date) = p_month
      AND YEAR(date) = p_year
      AND status = 'present';
    
    -- Count absent days
    SELECT COUNT(*) INTO v_absent_days
    FROM attendance_logs
    WHERE student_id = p_student_id
      AND MONTH(date) = p_month
      AND YEAR(date) = p_year
      AND status = 'absent';
    
    -- Count late days
    SELECT COUNT(*) INTO v_late_days
    FROM attendance_logs
    WHERE student_id = p_student_id
      AND MONTH(date) = p_month
      AND YEAR(date) = p_year
      AND status = 'late';
    
    -- Count excused days
    SELECT COUNT(*) INTO v_excused_days
    FROM attendance_logs
    WHERE student_id = p_student_id
      AND MONTH(date) = p_month
      AND YEAR(date) = p_year
      AND status = 'excused';
    
    -- Calculate percentage (present + late as attended)
    IF v_total_days > 0 THEN
        SET v_percentage = ((v_present_days + v_late_days + v_excused_days) / v_total_days) * 100;
    END IF;
    
    -- Insert or update summary
    INSERT INTO attendance_summary (
        student_id, school_id, month, year, 
        total_days, present_days, absent_days, late_days, excused_days,
        attendance_percentage
    ) VALUES (
        p_student_id, v_school_id, p_month, p_year,
        v_total_days, v_present_days, v_absent_days, v_late_days, v_excused_days,
        v_percentage
    )
    ON DUPLICATE KEY UPDATE
        total_days = v_total_days,
        present_days = v_present_days,
        absent_days = v_absent_days,
        late_days = v_late_days,
        excused_days = v_excused_days,
        attendance_percentage = v_percentage,
        updated_at = NOW();
END//
DELIMITER ;

-- Create stored procedure to check attendance alerts
DROP PROCEDURE IF EXISTS check_attendance_alerts;

DELIMITER //
CREATE PROCEDURE check_attendance_alerts(
    IN p_student_id INT
)
BEGIN
    -- This procedure can be used to create alerts for low attendance
    -- Currently just a placeholder for future implementation
    -- Can add logic to notify admin/parents when attendance falls below threshold
    SELECT 1;
END//
DELIMITER ;

-- Success message
SELECT 'attendance_summary table and stored procedures created successfully!' as Result;
