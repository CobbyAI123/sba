-- =====================================================
-- COMPREHENSIVE PROMOTION SYSTEM UPDATE
-- Implements entry-term based calculations
-- =====================================================

USE school_management_system;

-- Step 1: Update student_promotions table to include new columns
ALTER TABLE `student_promotions` 
ADD COLUMN IF NOT EXISTS `annual_average` DECIMAL(5,2) DEFAULT NULL COMMENT 'Annual average based on entry term' AFTER `promotion_date`,
ADD COLUMN IF NOT EXISTS `annual_total` DECIMAL(10,2) DEFAULT NULL COMMENT 'Total marks for the year' AFTER `annual_average`,
ADD COLUMN IF NOT EXISTS `entry_term` INT(1) DEFAULT 1 COMMENT 'Which term student was admitted: 1, 2, or 3' AFTER `terms_completed`;

-- Step 2: Rename old columns if they exist
ALTER TABLE `student_promotions`
CHANGE COLUMN `average_score` `annual_average_old` DECIMAL(5,2) DEFAULT NULL,
CHANGE COLUMN `total_marks` `annual_total_old` DECIMAL(10,2) DEFAULT NULL;

-- Step 3: Ensure students table has entry_term column with proper default
ALTER TABLE `students`
ADD COLUMN IF NOT EXISTS `entry_term` INT(1) DEFAULT 1 COMMENT 'Term of admission: 1, 2, or 3' AFTER `admission_date`;

-- Step 4: Update existing students without entry_term to default (Term 1)
UPDATE `students` 
SET `entry_term` = 1 
WHERE `entry_term` IS NULL OR `entry_term` = 0;

-- Step 5: Add index for better performance
ALTER TABLE `students` 
ADD INDEX IF NOT EXISTS `idx_entry_term` (`entry_term`);

ALTER TABLE `student_promotions`
ADD INDEX IF NOT EXISTS `idx_entry_term_promo` (`entry_term`);

-- Step 6: Create promotion_overrides table for manual overrides
CREATE TABLE IF NOT EXISTS `promotion_overrides` (
  `override_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL,
  `original_decision` ENUM('promoted', 'repeated', 'graduated') NOT NULL,
  `override_decision` ENUM('promoted', 'repeated', 'graduated') NOT NULL,
  `override_reason` TEXT,
  `overridden_by` INT(11) NOT NULL,
  `override_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`override_id`),
  KEY `idx_school_student` (`school_id`, `student_id`),
  KEY `idx_academic_year` (`academic_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Step 7: Create promotion_locks table to prevent post-approval modifications
CREATE TABLE IF NOT EXISTS `promotion_locks` (
  `lock_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `locked_by` INT(11) NOT NULL,
  `locked_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `lock_reason` VARCHAR(255) DEFAULT 'Results approved and locked',
  PRIMARY KEY (`lock_id`),
  UNIQUE KEY `unique_lock` (`school_id`, `academic_year`, `class_id`),
  KEY `idx_academic_year` (`academic_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Step 8: Verify structure
SELECT 
    'students table' as table_name,
    COLUMN_NAME,
    DATA_TYPE,
    COLUMN_DEFAULT,
    COLUMN_COMMENT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME = 'students'
AND COLUMN_NAME IN ('admission_number', 'entry_term', 'promotion_status')
ORDER BY ORDINAL_POSITION;

SELECT 
    'student_promotions table' as table_name,
    COLUMN_NAME,
    DATA_TYPE,
    COLUMN_DEFAULT,
    COLUMN_COMMENT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME = 'student_promotions'
AND COLUMN_NAME IN ('annual_average', 'annual_total', 'entry_term', 'pass_mark')
ORDER BY ORDINAL_POSITION;

-- Success message
SELECT 
    '✅ PROMOTION SYSTEM UPDATED SUCCESSFULLY!' as Result,
    'Entry-term based calculations now enabled' as Message,
    'Students can be admitted in Term 1, 2, or 3' as Feature1,
    'Admission numbers remain permanent' as Feature2,
    'Manual overrides and locks supported' as Feature3;
