-- ============================================================================
-- ADD MISSING COLUMNS TO MESSAGES TABLE
-- Fix: Column not found errors
-- ============================================================================

-- Add deleted_by_recipient column if it doesn't exist
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `deleted_by_recipient` TINYINT(1) DEFAULT 0;

-- Add deleted_by_sender column if it doesn't exist
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `deleted_by_sender` TINYINT(1) DEFAULT 0;

-- Add read_at column if it doesn't exist
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `read_at` TIMESTAMP NULL;

-- Add replied_to column if it doesn't exist
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `replied_to` INT(11) NULL COMMENT 'If this is a reply, original message_id';

-- Add recipient_role column if it doesn't exist
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `recipient_role` VARCHAR(50) NULL COMMENT 'For role-based broadcasts';

-- Add message_type column if it doesn't exist
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `message_type` ENUM('personal', 'broadcast', 'announcement') DEFAULT 'personal';

-- Add priority column if it doesn't exist
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `priority` ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal';

-- Add attachment column if it doesn't exist
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `attachment` VARCHAR(255) NULL;

-- Verify structure
SELECT '✅ All columns added successfully!' as status;
DESCRIBE messages;
