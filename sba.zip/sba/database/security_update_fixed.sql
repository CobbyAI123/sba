-- Security and Performance Updates for School Management System
-- This file adds indexes and optimizations safely

-- Drop indexes if they exist first, then recreate them
-- This prevents duplicate key errors

-- Students table indexes
DROP INDEX IF EXISTS idx_school_class ON students;
DROP INDEX IF EXISTS idx_email ON students;
DROP INDEX IF EXISTS idx_admission ON students;

ALTER TABLE students ADD INDEX idx_school_class (school_id, class_id);
ALTER TABLE students ADD INDEX idx_email (email);
ALTER TABLE students ADD INDEX idx_admission (admission_number);

-- Users table indexes
DROP INDEX IF EXISTS idx_school_role ON users;
DROP INDEX IF EXISTS idx_email_users ON users;
DROP INDEX IF EXISTS idx_username ON users;

ALTER TABLE users ADD INDEX idx_school_role (school_id, role);
ALTER TABLE users ADD INDEX idx_email_users (email);
ALTER TABLE users ADD INDEX idx_username (username);

-- Classes table indexes
DROP INDEX IF EXISTS idx_school_status ON classes;

ALTER TABLE classes ADD INDEX idx_school_status (school_id, status);

-- Subjects table indexes
DROP INDEX IF EXISTS idx_school_status_subj ON subjects;

ALTER TABLE subjects ADD INDEX idx_school_status_subj (school_id, status);

-- Attendance table indexes
DROP INDEX IF EXISTS idx_student_date ON attendance;
DROP INDEX IF EXISTS idx_class_date ON attendance;

ALTER TABLE attendance ADD INDEX idx_student_date (student_id, attendance_date);
ALTER TABLE attendance ADD INDEX idx_class_date (class_id, attendance_date);

-- Class subjects table indexes
DROP INDEX IF EXISTS idx_class_subject ON class_subjects;
DROP INDEX IF EXISTS idx_teacher ON class_subjects;

ALTER TABLE class_subjects ADD INDEX idx_class_subject (class_id, subject_id);
ALTER TABLE class_subjects ADD INDEX idx_teacher (teacher_id);

-- Activity logs table indexes
DROP INDEX IF EXISTS idx_user_date ON activity_logs;
DROP INDEX IF EXISTS idx_action ON activity_logs;

ALTER TABLE activity_logs ADD INDEX idx_user_date (user_id, created_at);
ALTER TABLE activity_logs ADD INDEX idx_action (action_type);

-- Notifications table indexes
DROP INDEX IF EXISTS idx_user_read ON notifications;

ALTER TABLE notifications ADD INDEX idx_user_read (user_id, is_read);

-- Schools table indexes
DROP INDEX IF EXISTS idx_status_schools ON schools;
DROP INDEX IF EXISTS idx_code ON schools;

ALTER TABLE schools ADD INDEX idx_status_schools (status);
ALTER TABLE schools ADD INDEX idx_code (school_code);

-- Payments table indexes (if table exists)
DROP INDEX IF EXISTS idx_student_status ON payments;
DROP INDEX IF EXISTS idx_payment_date ON payments;

ALTER TABLE payments ADD INDEX idx_student_status (student_id, status);
ALTER TABLE payments ADD INDEX idx_payment_date (payment_date);

-- Exams table indexes (if table exists)
DROP INDEX IF EXISTS idx_class_date_exam ON exams;

ALTER TABLE exams ADD INDEX idx_class_date_exam (class_id, exam_date);

-- Success message
SELECT 'All indexes created successfully!' as Status;
