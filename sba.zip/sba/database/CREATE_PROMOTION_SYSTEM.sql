-- =====================================================
-- STUDENT PROMOTION SYSTEM
-- Handles end-of-year promotions and repetitions
-- =====================================================

USE school_management_system;

-- =====================================================
-- 1. CREATE student_promotions TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `student_promotions` (
  `promotion_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL COMMENT '2024/2025',
  `from_class_id` INT(11) NOT NULL,
  `to_class_id` INT(11) NULL COMMENT 'NULL if repeated',
  `promotion_type` ENUM('promoted', 'repeated', 'graduated') NOT NULL DEFAULT 'promoted',
  `promotion_date` DATE NOT NULL,
  `average_score` DECIMAL(5,2) DEFAULT NULL COMMENT 'Overall average for the year',
  `total_marks` DECIMAL(10,2) DEFAULT NULL,
  `pass_mark` DECIMAL(5,2) DEFAULT 50.00,
  `decision_reason` TEXT DEFAULT NULL COMMENT 'Why promoted/repeated',
  `terms_completed` INT(1) DEFAULT 3 COMMENT '1, 2, or 3 terms',
  `promoted_by` INT(11) NOT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`promotion_id`),
  KEY `idx_school_student` (`school_id`, `student_id`),
  KEY `idx_academic_year` (`academic_year`),
  KEY `idx_from_class` (`from_class_id`),
  KEY `idx_to_class` (`to_class_id`),
  KEY `idx_promotion_type` (`promotion_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- 2. CREATE academic_years TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `academic_years` (
  `year_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `year_name` VARCHAR(20) NOT NULL COMMENT '2024/2025',
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `vacation_start` DATE DEFAULT NULL,
  `reopening_date` DATE DEFAULT NULL,
  `is_current` TINYINT(1) DEFAULT 0,
  `status` ENUM('active', 'completed', 'upcoming') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`year_id`),
  KEY `idx_school_year` (`school_id`, `year_name`),
  KEY `idx_is_current` (`is_current`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- 3. ADD promotion_status to students TABLE
-- =====================================================
ALTER TABLE `students` 
ADD COLUMN IF NOT EXISTS `promotion_status` ENUM('pending', 'promoted', 'repeated', 'graduated') DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS `current_academic_year` VARCHAR(20) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `entry_term` INT(1) DEFAULT 1 COMMENT 'Which term student started: 1, 2, or 3';

-- =====================================================
-- 4. ADD promotion fields to terms TABLE
-- =====================================================
ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `academic_year` VARCHAR(20) DEFAULT NULL COMMENT '2024/2025',
ADD COLUMN IF NOT EXISTS `vacation_date` DATE DEFAULT NULL,
ADD COLUMN IF NOT EXISTS `reopening_date` DATE DEFAULT NULL;

-- =====================================================
-- 5. CREATE class_progression TABLE (Class Hierarchy)
-- =====================================================
CREATE TABLE IF NOT EXISTS `class_progression` (
  `progression_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `current_class_id` INT(11) NOT NULL,
  `next_class_id` INT(11) NULL COMMENT 'NULL if final class (graduation)',
  `class_order` INT(3) NOT NULL COMMENT 'e.g., 1=Nursery, 2=KG1, 3=Class1, etc.',
  `is_final_class` TINYINT(1) DEFAULT 0,
  PRIMARY KEY (`progression_id`),
  UNIQUE KEY `idx_school_class` (`school_id`, `current_class_id`),
  KEY `idx_class_order` (`class_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =====================================================
-- 6. SUCCESS MESSAGE
-- =====================================================
SELECT 'Student Promotion System tables created successfully!' AS Result;
SELECT 'Next Step: Run admin/setup-promotion-system.php to configure class progression' AS NextStep;
