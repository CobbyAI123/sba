-- Assessment System Tables
-- This creates tables for CA, Midterm, and Exam management

-- Assessment Portal Control Table
CREATE TABLE IF NOT EXISTS `assessment_portal` (
  `portal_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `term_id` INT(11) NOT NULL,
  `portal_type` ENUM('ca', 'midterm', 'exam') NOT NULL,
  `is_open` TINYINT(1) DEFAULT 0,
  `opened_by` INT(11) NULL,
  `opened_at` TIMESTAMP NULL,
  `closed_by` INT(11) NULL,
  `closed_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`portal_id`),
  KEY `idx_school_term` (`school_id`, `term_id`),
  KEY `idx_portal_type` (`portal_type`, `is_open`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Student Assessments Table (CA, Midterm, Exam scores)
CREATE TABLE IF NOT EXISTS `student_assessments` (
  `assessment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `term_id` INT(11) NOT NULL,
  `teacher_id` INT(11) NOT NULL,
  `ca_score` DECIMAL(5,2) DEFAULT NULL,
  `ca_max` DECIMAL(5,2) DEFAULT 20.00,
  `midterm_score` DECIMAL(5,2) DEFAULT NULL,
  `midterm_max` DECIMAL(5,2) DEFAULT 20.00,
  `exam_score` DECIMAL(5,2) DEFAULT NULL,
  `exam_max` DECIMAL(5,2) DEFAULT 60.00,
  `total_score` DECIMAL(5,2) GENERATED ALWAYS AS (COALESCE(ca_score, 0) + COALESCE(midterm_score, 0) + COALESCE(exam_score, 0)) STORED,
  `grade` VARCHAR(2) NULL,
  `remark` VARCHAR(50) NULL,
  `submitted_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`assessment_id`),
  UNIQUE KEY `unique_assessment` (`student_id`, `subject_id`, `term_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_class_subject` (`class_id`, `subject_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_teacher` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Assessment Submission Log
CREATE TABLE IF NOT EXISTS `assessment_submissions` (
  `submission_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `teacher_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `term_id` INT(11) NOT NULL,
  `assessment_type` ENUM('ca', 'midterm', 'exam') NOT NULL,
  `students_count` INT(11) NOT NULL,
  `submitted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`submission_id`),
  KEY `idx_teacher_term` (`teacher_id`, `term_id`),
  KEY `idx_class_subject` (`class_id`, `subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Result Generation Log
CREATE TABLE IF NOT EXISTS `result_generations` (
  `generation_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `term_id` INT(11) NOT NULL,
  `generated_by` INT(11) NOT NULL,
  `generation_type` ENUM('single', 'class', 'bulk') NOT NULL,
  `student_id` INT(11) NULL,
  `class_id` INT(11) NULL,
  `students_count` INT(11) NOT NULL,
  `file_path` VARCHAR(255) NULL,
  `generated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`generation_id`),
  KEY `idx_school_term` (`school_id`, `term_id`),
  KEY `idx_generated_by` (`generated_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
