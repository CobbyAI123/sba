-- ============================================================================
-- FIX: CREATE MISSING TEACHERS TABLE
-- ============================================================================
-- This script creates the missing teachers table that wasn't in schema.sql
-- ============================================================================

-- Create teachers table
CREATE TABLE IF NOT EXISTS `teachers` (
  `teacher_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `employee_id` VARCHAR(50) NULL,
  `qualification` VARCHAR(255) NULL,
  `specialization` TEXT NULL,
  `date_of_joining` DATE NULL,
  `experience_years` INT(2) DEFAULT 0,
  `department` VARCHAR(100) NULL,
  `designation` VARCHAR(100) NULL,
  `phone` VARCHAR(20) NULL,
  `email` VARCHAR(255) NULL,
  `address` TEXT NULL,
  `status` ENUM('active', 'inactive', 'on_leave', 'retired') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`teacher_id`),
  UNIQUE KEY `idx_user_school` (`user_id`, `school_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create teacher_classes junction table (many-to-many relationship)
CREATE TABLE IF NOT EXISTS `teacher_classes` (
  `teacher_class_id` INT(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `subject_id` INT(11) NULL,
  `is_class_teacher` TINYINT(1) DEFAULT 0,
  `assigned_date` DATE DEFAULT CURRENT_DATE,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  PRIMARY KEY (`teacher_class_id`),
  UNIQUE KEY `idx_teacher_class` (`teacher_id`, `class_id`, `school_id`),
  KEY `idx_teacher` (`teacher_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_school` (`school_id`),
  FOREIGN KEY (`teacher_id`) REFERENCES `teachers`(`teacher_id`) ON DELETE CASCADE,
  FOREIGN KEY (`class_id`) REFERENCES `classes`(`class_id`) ON DELETE CASCADE,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create teacher_subjects junction table (many-to-many relationship)
CREATE TABLE IF NOT EXISTS `teacher_subjects` (
  `teacher_subject_id` INT(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `assigned_date` DATE DEFAULT CURRENT_DATE,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  PRIMARY KEY (`teacher_subject_id`),
  UNIQUE KEY `idx_teacher_subject` (`teacher_id`, `subject_id`, `school_id`),
  KEY `idx_teacher` (`teacher_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_school` (`school_id`),
  FOREIGN KEY (`teacher_id`) REFERENCES `teachers`(`teacher_id`) ON DELETE CASCADE,
  FOREIGN KEY (`subject_id`) REFERENCES `subjects`(`subject_id`) ON DELETE CASCADE,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Verify tables were created
SELECT '=== Teachers Table ===' as info;
DESCRIBE teachers;

SELECT '=== Teacher Classes Junction Table ===' as info;
DESCRIBE teacher_classes;

SELECT '=== Teacher Subjects Junction Table ===' as info;
DESCRIBE teacher_subjects;

-- Count records
SELECT 'Teachers Table' as Table_Name, COUNT(*) as Row_Count FROM teachers;
SELECT 'Teacher Classes' as Table_Name, COUNT(*) as Row_Count FROM teacher_classes;
SELECT 'Teacher Subjects' as Table_Name, COUNT(*) as Row_Count FROM teacher_subjects;

SELECT '✅ Missing Teachers Tables Created Successfully!' as status;
