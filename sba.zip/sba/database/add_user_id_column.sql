-- ============================================
-- Add user_id column to payments table
-- ============================================
-- This allows tracking payments from teachers/staff (canteen, transport)
-- while keeping student_id for student payments (school fees)
--
-- Date: November 4, 2025
-- Purpose: Support teacher-based canteen and transport fee collection
-- ============================================

-- Step 1: Add user_id column
-- Note: MySQL 5.7 doesn't support IF NOT EXISTS for ADD COLUMN
-- If column exists, you'll get an error - that's OK, just continue
ALTER TABLE payments 
ADD COLUMN user_id INT NULL AFTER student_id;

-- Step 2: Add foreign key constraint
-- This ensures data integrity - user_id must exist in users table
ALTER TABLE payments
ADD CONSTRAINT fk_payments_user 
FOREIGN KEY (user_id) REFERENCES users(user_id) 
ON DELETE CASCADE 
ON UPDATE CASCADE;

-- Step 3: Add index for better query performance
-- This speeds up queries that filter by user_id
CREATE INDEX idx_payments_user_id ON payments(user_id);

-- ============================================
-- Verification Queries
-- ============================================

-- Show the payments table structure
DESCRIBE payments;

-- Show payment statistics
SELECT 
    'Migration completed successfully!' as status,
    COUNT(*) as total_payments,
    SUM(CASE WHEN student_id IS NOT NULL THEN 1 ELSE 0 END) as student_payments,
    SUM(CASE WHEN user_id IS NOT NULL THEN 1 ELSE 0 END) as teacher_payments
FROM payments;

-- ============================================
-- Expected Result:
-- ============================================
-- You should see 'user_id' column in the DESCRIBE output
-- Type: int(11)
-- Null: YES
-- Key: MUL (Multiple - has index and foreign key)
-- Default: NULL
-- ============================================
