-- ============================================================================
-- ADD EXAM MANAGEMENT TABLES
-- Quick fix for missing exam tables
-- Date: November 12, 2025
-- ============================================================================

-- Exams Table
CREATE TABLE IF NOT EXISTS `exams` (
  `exam_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `term_id` INT(11) NULL,
  `exam_name` VARCHAR(255) NOT NULL,
  `exam_type` ENUM('mid_term', 'final', 'quarterly', 'monthly', 'unit_test', 'mock') DEFAULT 'mid_term',
  `academic_year` VARCHAR(20) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `status` ENUM('draft', 'scheduled', 'ongoing', 'completed', 'cancelled') DEFAULT 'draft',
  `instructions` TEXT NULL,
  `created_by` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`exam_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Exam Schedule Table
CREATE TABLE IF NOT EXISTS `exam_schedule` (
  `schedule_id` INT(11) NOT NULL AUTO_INCREMENT,
  `exam_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `exam_date` DATE NOT NULL,
  `start_time` TIME NOT NULL,
  `end_time` TIME NOT NULL,
  `duration_minutes` INT(3) NOT NULL,
  `total_marks` INT(3) DEFAULT 100,
  `room_number` VARCHAR(50) NULL,
  `supervisor_id` INT(11) NULL,
  `status` ENUM('scheduled', 'ongoing', 'completed', 'cancelled') DEFAULT 'scheduled',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`schedule_id`),
  KEY `idx_exam` (`exam_id`),
  KEY `idx_date` (`exam_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Hall Tickets Table
CREATE TABLE IF NOT EXISTS `hall_tickets` (
  `ticket_id` INT(11) NOT NULL AUTO_INCREMENT,
  `exam_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `ticket_number` VARCHAR(50) NOT NULL UNIQUE,
  `issued_date` DATE NOT NULL,
  `photo_url` VARCHAR(255) NULL,
  `status` ENUM('issued', 'downloaded', 'printed', 'cancelled') DEFAULT 'issued',
  `special_instructions` TEXT NULL,
  `generated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ticket_id`),
  UNIQUE KEY `idx_exam_student` (`exam_id`, `student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Exam Rooms Table
CREATE TABLE IF NOT EXISTS `exam_rooms` (
  `room_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `room_number` VARCHAR(50) NOT NULL,
  `room_name` VARCHAR(100) NULL,
  `capacity` INT(3) NOT NULL,
  `rows` INT(2) NULL,
  `columns` INT(2) NULL,
  `floor` VARCHAR(20) NULL,
  `building` VARCHAR(100) NULL,
  `facilities` TEXT NULL,
  `status` ENUM('active', 'maintenance', 'unavailable') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`room_id`),
  UNIQUE KEY `idx_school_room` (`school_id`, `room_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default rooms
INSERT INTO `exam_rooms` (`school_id`, `room_number`, `room_name`, `capacity`, `rows`, `columns`, `status`)
SELECT school_id, 'ROOM-001', 'Main Hall', 100, 10, 10, 'active'
FROM schools
WHERE school_id NOT IN (SELECT school_id FROM exam_rooms WHERE room_number = 'ROOM-001')
ON DUPLICATE KEY UPDATE room_id=room_id;

-- Stored Procedure: Generate Hall Tickets
DELIMITER //

DROP PROCEDURE IF EXISTS generate_hall_tickets//
CREATE PROCEDURE generate_hall_tickets(IN p_exam_id INT, IN p_school_id INT)
BEGIN
    INSERT INTO hall_tickets (exam_id, student_id, ticket_number, issued_date, status)
    SELECT DISTINCT
        p_exam_id,
        s.student_id,
        CONCAT('HT', p_school_id, '-', p_exam_id, '-', s.student_id),
        CURDATE(),
        'issued'
    FROM students s
    INNER JOIN classes c ON s.class_id = c.class_id
    INNER JOIN exam_schedule es ON c.class_id = es.class_id
    WHERE es.exam_id = p_exam_id 
    AND s.status = 'active'
    AND s.school_id = p_school_id
    AND NOT EXISTS (
        SELECT 1 FROM hall_tickets ht 
        WHERE ht.exam_id = p_exam_id AND ht.student_id = s.student_id
    );
    
    SELECT ROW_COUNT() as tickets_generated;
END//

DELIMITER ;

-- Verification
SELECT 'Exam tables created successfully!' as status;
