-- ============================================
-- ADD MISSING COLUMNS ONLY
-- This checks what exists and adds only what's missing
-- ============================================

USE school_management_system;

-- Check and add class_teacher_id to classes
SET @col_exists = (SELECT COUNT(*) FROM information_schema.columns 
    WHERE table_schema = 'school_management_system' 
    AND table_name = 'classes' 
    AND column_name = 'class_teacher_id');

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE classes ADD COLUMN class_teacher_id INT(11) DEFAULT NULL',
    'SELECT "class_teacher_id already exists, skipping..." as message'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check and add temp_password to users
SET @col_exists = (SELECT COUNT(*) FROM information_schema.columns 
    WHERE table_schema = 'school_management_system' 
    AND table_name = 'users' 
    AND column_name = 'temp_password');

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE users ADD COLUMN temp_password VARCHAR(255) DEFAULT NULL',
    'SELECT "temp_password already exists, skipping..." as message'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check and create student_results_view table
SET @table_exists = (SELECT COUNT(*) FROM information_schema.tables 
    WHERE table_schema = 'school_management_system' 
    AND table_name = 'student_results_view');

SET @sql = IF(@table_exists = 0,
    'CREATE TABLE student_results_view (
        view_id INT(11) AUTO_INCREMENT PRIMARY KEY,
        student_id INT(11) NOT NULL,
        term_id INT(11) NOT NULL,
        session_year VARCHAR(20),
        term_name VARCHAR(50),
        total_subjects INT(11) DEFAULT 0,
        average_score DECIMAL(5,2) DEFAULT 0,
        published TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )',
    'SELECT "student_results_view already exists, skipping..." as message'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Check and create assignment_files table
SET @table_exists = (SELECT COUNT(*) FROM information_schema.tables 
    WHERE table_schema = 'school_management_system' 
    AND table_name = 'assignment_files');

SET @sql = IF(@table_exists = 0,
    'CREATE TABLE assignment_files (
        file_id INT(11) AUTO_INCREMENT PRIMARY KEY,
        assignment_id INT(11) NOT NULL,
        file_name VARCHAR(255) NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        file_type VARCHAR(50),
        file_size INT(11),
        uploaded_by INT(11),
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )',
    'SELECT "assignment_files already exists, skipping..." as message'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Final status
SELECT '✓ Migration completed! Only missing items were added.' as Status;
SELECT 'Existing columns/tables were safely skipped.' as Note;
