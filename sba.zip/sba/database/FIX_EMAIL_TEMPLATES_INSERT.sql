-- FIX: Email Templates - Insert Default Templates
-- The table structure is correct, this just ensures the templates are inserted

-- Verify schools table has school_id = 1
INSERT IGNORE INTO `schools` (school_id, school_name, status) VALUES (1, 'Default School', 'active');

-- Clear existing templates for school 1 (optional, comment out if you want to keep existing ones)
DELETE FROM `email_templates` WHERE school_id = 1;

-- Insert default email templates
INSERT INTO `email_templates` (school_id, template_name, subject, body, description) VALUES
(1, 'payment_reminder', 'Payment Reminder - {{student_name}}', 
 '<h3>Payment Reminder</h3><p>Dear Parent/Guardian,</p><p>This is to remind you that payment of <strong>{{amount}}</strong> is due by <strong>{{due_date}}</strong> for <strong>{{student_name}}</strong>.</p><p>Please make payment at your earliest convenience.</p><p>Best regards,<br>{{school_name}}</p>',
 'Email reminder for upcoming school fees payment'),

(1, 'payment_received', 'Payment Received - {{student_name}}',
 '<h3>Payment Confirmation</h3><p>Dear Parent/Guardian,</p><p>We acknowledge receipt of your payment of <strong>{{amount}}</strong> on <strong>{{payment_date}}</strong> for <strong>{{student_name}}</strong>.</p><p>Reference Number: <strong>{{reference_number}}</strong></p><p>Thank you for your prompt payment.</p><p>Best regards,<br>{{school_name}}</p>',
 'Confirmation email when payment is received'),

(1, 'attendance_alert', 'Attendance Alert - {{student_name}}',
 '<h3>Attendance Alert</h3><p>Dear Parent/Guardian,</p><p>We write to inform you that <strong>{{student_name}}</strong> in <strong>{{class_name}}</strong> has been absent <strong>{{absent_count}}</strong> times this term.</p><p>We request your immediate attention to this matter.</p><p>Best regards,<br>{{school_name}}</p>',
 'Alert when student attendance is low'),

(1, 'results_published', 'Results Available - {{student_name}}',
 '<h3>Academic Results Published</h3><p>Dear Parent/Guardian,</p><p>The {{term}} results for <strong>{{student_name}}</strong> in <strong>{{class_name}}</strong> are now available.</p><p>Please log in to the portal to view the results.</p><p>Best regards,<br>{{school_name}}</p>',
 'Notification when exam results are published'),

(1, 'event_notification', 'Event Notification - {{event_name}}',
 '<h3>{{event_name}}</h3><p>Dear {{recipient_name}},</p><p><strong>Date:</strong> {{event_date}}<br><strong>Time:</strong> {{event_time}}<br><strong>Location:</strong> {{event_location}}</p><p>We look forward to your participation.</p><p>Best regards,<br>{{school_name}}</p>',
 'General event notification template');

-- Verify templates were inserted
SELECT CONCAT('✓ Templates inserted: ', COUNT(*)) as Status FROM email_templates WHERE school_id = 1;
