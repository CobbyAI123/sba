-- FIX: Email Templates Table - Missing school_id Column
-- Run this SQL script in phpMyAdmin if you get "Unknown column 'school_id'" error

-- Step 1: Drop the existing email_templates table if it exists with wrong structure
DROP TABLE IF EXISTS `email_templates`;

-- Step 2: Recreate the email_templates table with correct schema
CREATE TABLE IF NOT EXISTS `email_templates` (
  `template_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `template_name` VARCHAR(100) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `body` LONGTEXT NOT NULL,
  `description` TEXT,
  `is_active` BOOLEAN DEFAULT 1,
  `created_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_name` (`school_id`, `template_name`),
  INDEX `idx_is_active` (`is_active`),
  UNIQUE KEY `unique_school_template` (`school_id`, `template_name`)
);

-- Step 3: Verify schools table exists and has school_id = 1
INSERT IGNORE INTO `schools` (school_id, school_name, status) VALUES (1, 'Default School', 'active');

-- Step 4: Insert default email templates
INSERT INTO `email_templates` (school_id, template_name, subject, body, description) VALUES
(1, 'payment_reminder', 'Payment Reminder - {{student_name}}', 
 '<h3>Payment Reminder</h3><p>Dear Parent/Guardian,</p><p>This is to remind you that payment of <strong>{{amount}}</strong> is due by <strong>{{due_date}}</strong> for <strong>{{student_name}}</strong>.</p><p>Please make payment at your earliest convenience.</p><p>Best regards,<br>{{school_name}}</p>',
 'Email reminder for upcoming school fees payment'),

(1, 'payment_received', 'Payment Received - {{student_name}}',
 '<h3>Payment Confirmation</h3><p>Dear Parent/Guardian,</p><p>We acknowledge receipt of your payment of <strong>{{amount}}</strong> on <strong>{{payment_date}}</strong> for <strong>{{student_name}}</strong>.</p><p>Reference Number: <strong>{{reference_number}}</strong></p><p>Thank you for your prompt payment.</p><p>Best regards,<br>{{school_name}}</p>',
 'Confirmation email when payment is received'),

(1, 'attendance_alert', 'Attendance Alert - {{student_name}}',
 '<h3>Attendance Alert</h3><p>Dear Parent/Guardian,</p><p>We write to inform you that <strong>{{student_name}}</strong> in <strong>{{class_name}}</strong> has been absent <strong>{{absent_count}}</strong> times this term.</p><p>We request your immediate attention to this matter.</p><p>Best regards,<br>{{school_name}}</p>',
 'Alert when student attendance is low'),

(1, 'results_published', 'Results Available - {{student_name}}',
 '<h3>Academic Results Published</h3><p>Dear Parent/Guardian,</p><p>The {{term}} results for <strong>{{student_name}}</strong> in <strong>{{class_name}}</strong> are now available.</p><p>Please log in to the portal to view the results.</p><p>Best regards,<br>{{school_name}}</p>',
 'Notification when exam results are published'),

(1, 'event_notification', 'Event Notification - {{event_name}}',
 '<h3>{{event_name}}</h3><p>Dear {{recipient_name}},</p><p><strong>Date:</strong> {{event_date}}<br><strong>Time:</strong> {{event_time}}<br><strong>Location:</strong> {{event_location}}</p><p>We look forward to your participation.</p><p>Best regards,<br>{{school_name}}</p>',
 'General event notification template');

-- Verify: Check that tables were created correctly
SELECT 'Email Templates Table Created' as Status, COUNT(*) as Template_Count FROM email_templates;
SELECT 'Email Queue Table Status' as Status FROM email_queue LIMIT 1;
SELECT 'Email Settings Table Status' as Status FROM email_settings LIMIT 1;
SELECT 'Email Logs Table Status' as Status FROM email_logs LIMIT 1;
