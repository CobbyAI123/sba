-- ============================================
-- SIMPLE FIX FOR USER 76
-- Guaranteed to work - minimal columns
-- ============================================

USE school_management_system;

-- Step 1: Check if student record exists
SELECT 
    CASE 
        WHEN COUNT(*) > 0 THEN '✓ Student record already exists'
        ELSE '❌ Student record missing - will create'
    END as current_status
FROM students 
WHERE user_id = 76;

-- Step 2: Get first available class for school 11
SELECT 
    class_id,
    class_name,
    'Will assign this class' as note
FROM classes 
WHERE school_id = 11 
ORDER BY class_id 
LIMIT 1;

-- Step 3: Create student record (only if doesn't exist)
INSERT INTO students (user_id, school_id, admission_number, class_id, status)
SELECT 76, 11, 'ADM1100076', 
       (SELECT class_id FROM classes WHERE school_id = 11 ORDER BY class_id LIMIT 1),
       'active'
WHERE NOT EXISTS (SELECT 1 FROM students WHERE user_id = 76);

-- Step 4: Verify the fix
SELECT 
    s.student_id,
    s.user_id,
    s.admission_number,
    c.class_name,
    s.status,
    '✓ FIXED - Student can now login!' as result
FROM students s
LEFT JOIN classes c ON s.class_id = c.class_id
WHERE s.user_id = 76;

-- Step 5: Show user details
SELECT 
    u.user_id,
    u.username,
    u.first_name,
    u.last_name,
    u.email,
    u.role,
    s.student_id,
    s.admission_number,
    c.class_name
FROM users u
LEFT JOIN students s ON u.user_id = s.user_id
LEFT JOIN classes c ON s.class_id = c.class_id
WHERE u.user_id = 76;
