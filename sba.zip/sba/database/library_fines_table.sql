-- Library Fines Table Migration
-- Run this to add the library_fines table for complete fine management

CREATE TABLE IF NOT EXISTS library_fines (
    fine_id INT PRIMARY KEY AUTO_INCREMENT,
    school_id INT NOT NULL,
    student_id INT NOT NULL,
    book_id INT,
    transaction_id INT,
    reason ENUM('overdue', 'damage', 'lost', 'other') DEFAULT 'overdue',
    amount_due DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    amount_paid DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('unpaid', 'paid', 'waived', 'partial') DEFAULT 'unpaid',
    notes TEXT,
    paid_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES library_books(book_id) ON DELETE SET NULL,
    FOREIGN KEY (transaction_id) REFERENCES library_transactions(transaction_id) ON DELETE SET NULL,
    INDEX idx_school_status (school_id, status),
    INDEX idx_student (student_id),
    INDEX idx_book (book_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
