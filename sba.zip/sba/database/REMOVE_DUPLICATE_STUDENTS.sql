-- ============================================
-- REMOVE DUPLICATE STUDENTS IN CLASSES
-- Keeps only one record per student name per class
-- ============================================

USE school_management_system;

-- Step 1: Find duplicate students in each class
-- (Students with same first_name, last_name in the same class)
SELECT 
    s.student_id,
    s.class_id,
    c.class_name,
    u.first_name,
    u.last_name,
    s.admission_number,
    s.created_at,
    '⚠️ DUPLICATE' as status
FROM students s
INNER JOIN users u ON s.user_id = u.user_id
INNER JOIN classes c ON s.class_id = c.class_id
WHERE (u.first_name, u.last_name, s.class_id) IN (
    SELECT u2.first_name, u2.last_name, s2.class_id
    FROM students s2
    INNER JOIN users u2 ON s2.user_id = u2.user_id
    WHERE s2.school_id = s.school_id
    GROUP BY u2.first_name, u2.last_name, s2.class_id
    HAVING COUNT(*) > 1
)
ORDER BY s.class_id, u.first_name, u.last_name, s.created_at;

-- Step 2: Remove duplicates (keep oldest record based on created_at)
-- This creates a backup first, then deletes duplicates

-- Create backup table
CREATE TABLE IF NOT EXISTS students_backup_before_dedup AS 
SELECT * FROM students WHERE 1=0;

-- Backup students that will be deleted
INSERT INTO students_backup_before_dedup
SELECT s.*
FROM students s
INNER JOIN users u ON s.user_id = u.user_id
WHERE (u.first_name, u.last_name, s.class_id, s.student_id) IN (
    SELECT u2.first_name, u2.last_name, s2.class_id, s2.student_id
    FROM students s2
    INNER JOIN users u2 ON s2.user_id = u2.user_id
    WHERE s2.student_id NOT IN (
        -- Keep the oldest record (earliest created_at)
        SELECT MIN(s3.student_id)
        FROM students s3
        INNER JOIN users u3 ON s3.user_id = u3.user_id
        GROUP BY u3.first_name, u3.last_name, s3.class_id
    )
);

-- Delete duplicate students (keep oldest based on student_id which correlates with created_at)
-- Using a temporary table to avoid MySQL's "same table" error
DELETE s FROM students s
INNER JOIN users u ON s.user_id = u.user_id
WHERE s.student_id NOT IN (
    -- Keep the FIRST (lowest student_id = oldest) record per name per class
    -- Using subquery with alias to avoid table reference error
    SELECT keep_id FROM (
        SELECT MIN(s2.student_id) as keep_id
        FROM students s2
        INNER JOIN users u2 ON s2.user_id = u2.user_id
        GROUP BY u2.first_name, u2.last_name, s2.class_id, s2.school_id
    ) AS temp_keep
);

-- Step 3: Verify - should return 0 rows
SELECT 
    u.first_name,
    u.last_name,
    s.class_id,
    c.class_name,
    COUNT(*) as duplicate_count,
    '❌ STILL DUPLICATED' as status
FROM students s
INNER JOIN users u ON s.user_id = u.user_id
INNER JOIN classes c ON s.class_id = c.class_id
GROUP BY u.first_name, u.last_name, s.class_id, c.class_name
HAVING COUNT(*) > 1;

-- Step 4: Show summary
SELECT 
    COUNT(*) as total_students,
    COUNT(DISTINCT CONCAT(u.first_name, '-', u.last_name, '-', s.class_id)) as unique_name_class_combinations,
    '✅ Duplicates Removed' as status
FROM students s
INNER JOIN users u ON s.user_id = u.user_id;

-- Success message
SELECT 
    '✅ DUPLICATE REMOVAL COMPLETE!' as Result,
    'All duplicate students (same name in same class) have been removed.' as Message,
    'Kept the oldest record for each duplicate.' as Note;
