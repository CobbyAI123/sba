-- Add payment_type column to payments table
-- This allows tracking different types of payments (tuition, canteen, transport, etc.)

-- IMPORTANT: Select your database first in phpMyAdmin!

-- Add payment_type column
ALTER TABLE payments 
ADD COLUMN payment_type ENUM('tuition', 'canteen', 'transport', 'library', 'exam', 'uniform', 'other') 
DEFAULT 'tuition' 
AFTER amount;

-- Update existing payments to 'tuition' (default school fees)
UPDATE payments SET payment_type = 'tuition' WHERE payment_type IS NULL;

-- Verify the column was added
SHOW COLUMNS FROM payments LIKE 'payment_type';

-- Success message
SELECT 'Payment type column added successfully!' as Status;
