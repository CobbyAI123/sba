-- Verify Payment System Setup
-- Run this to check if everything is configured correctly

-- IMPORTANT: Select your database first in phpMyAdmin!

-- 1. Check if payment_type column exists and its structure
SHOW COLUMNS FROM payments LIKE 'payment_type';

-- 2. Check all columns in payments table
DESCRIBE payments;

-- 3. Check if there are any existing payments
SELECT COUNT(*) as total_payments FROM payments;

-- 4. Check payment types distribution (if any payments exist)
SELECT 
    CASE 
        WHEN payment_type IS NULL THEN 'NULL (needs update)'
        ELSE payment_type 
    END as payment_type,
    COUNT(*) as count
FROM payments
GROUP BY payment_type;

-- 5. Update NULL payment_type values to 'tuition' (if needed)
-- Uncomment the line below to run this update
-- UPDATE payments SET payment_type = 'tuition' WHERE payment_type IS NULL;

-- 6. Verify the update worked
SELECT 'Payment system is ready!' as Status;
