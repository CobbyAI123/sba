-- ============================================================================
-- CREATE PAYMENT RECYCLE BIN TABLE
-- This table stores deleted payments for recovery purposes
-- ============================================================================

-- Create deleted_payments table (recycle bin)
CREATE TABLE IF NOT EXISTS `deleted_payments` (
  `deleted_payment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `payment_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_date` DATE NOT NULL,
  `payment_method` VARCHAR(50) DEFAULT NULL,
  `payment_reference` VARCHAR(100) DEFAULT NULL,
  `payment_type` VARCHAR(50) DEFAULT 'tuition' COMMENT 'tuition, canteen, bus, library, sports, etc',
  `term_id` INT(11) DEFAULT NULL,
  `status` VARCHAR(20) DEFAULT 'completed',
  `remarks` TEXT DEFAULT NULL,
  `deleted_by` INT(11) NOT NULL,
  `deleted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `original_created_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (`deleted_payment_id`),
  KEY `school_id` (`school_id`),
  KEY `student_id` (`student_id`),
  KEY `deleted_by` (`deleted_by`),
  KEY `deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Add payment_type column to payments table if it doesn't exist
ALTER TABLE `payments` ADD COLUMN IF NOT EXISTS `payment_type` VARCHAR(50) DEFAULT 'tuition' COMMENT 'tuition, canteen, bus, library, sports, etc';

-- Add remarks column to payments table if it doesn't exist
ALTER TABLE `payments` ADD COLUMN IF NOT EXISTS `remarks` TEXT DEFAULT NULL;

-- ============================================================================
-- VERIFICATION QUERY
-- ============================================================================

-- Check if table was created successfully
SELECT 'Payment recycle bin table created successfully!' as status;

-- View table structure
DESCRIBE deleted_payments;

-- ============================================================================
-- INSTRUCTIONS
-- ============================================================================
-- 
-- HOW TO RUN THIS SCRIPT:
-- 
-- Method 1: phpMyAdmin
-- ---------------------
-- 1. Open: http://localhost/phpmyadmin
-- 2. Select: school_management_system database (left sidebar)
-- 3. Click: SQL tab (top menu)
-- 4. Copy & Paste: This entire script
-- 5. Click: Go button
-- 6. Verify: Success message appears
-- 
-- Method 2: MySQL Command Line
-- -----------------------------
-- 1. Open: Command Prompt
-- 2. Login: mysql -u root -p
-- 3. Use database: USE school_management_system;
-- 4. Source file: SOURCE C:/xampp/htdocs/msms/database/create_payment_recycle_bin.sql
-- 5. Verify: Table created
-- 
-- ============================================================================
