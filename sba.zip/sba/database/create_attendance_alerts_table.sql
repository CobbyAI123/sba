-- Create attendance_alerts table
-- This table tracks attendance alerts for students with poor attendance

CREATE TABLE IF NOT EXISTS `attendance_alerts` (
  `alert_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `alert_type` enum('warning','critical') NOT NULL DEFAULT 'warning',
  `alert_message` text NOT NULL,
  `attendance_percentage` decimal(5,2) DEFAULT NULL,
  `absent_days` int(11) DEFAULT 0,
  `late_days` int(11) DEFAULT 0,
  `is_resolved` tinyint(1) DEFAULT 0,
  `resolved_at` datetime DEFAULT NULL,
  `resolved_by` int(11) DEFAULT NULL,
  `resolution_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`alert_id`),
  KEY `school_id` (`school_id`),
  KEY `student_id` (`student_id`),
  KEY `is_resolved` (`is_resolved`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `attendance_alerts_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE,
  CONSTRAINT `attendance_alerts_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  CONSTRAINT `attendance_alerts_ibfk_3` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add some indexes for better performance
CREATE INDEX idx_alert_type ON attendance_alerts(alert_type);
CREATE INDEX idx_attendance_percentage ON attendance_alerts(attendance_percentage);
