-- SAFE: Users Table Schema Fix
-- This script safely fixes the users table by only adding missing columns

-- ============================================
-- SECTION 1: ADD MISSING COLUMNS SAFELY
-- ============================================

-- Add profile_picture column if it doesn't exist
ALTER TABLE `users` ADD COLUMN `profile_picture` VARCHAR(255) AFTER `password`;

-- Add phone column if it doesn't exist
ALTER TABLE `users` ADD COLUMN `phone` VARCHAR(20) AFTER `profile_picture`;

-- Add address column if it doesn't exist
ALTER TABLE `users` ADD COLUMN `address` TEXT AFTER `phone`;

-- Add updated_at column if it doesn't exist
ALTER TABLE `users` ADD COLUMN `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`;

-- ============================================
-- SECTION 2: INSERT DEFAULT ADMIN USER
-- ============================================

-- Ensure schools table has school_id = 1
INSERT IGNORE INTO `schools` (school_id, school_name, status) 
VALUES (1, 'Default School', 'active');

-- Insert or update the default admin user
INSERT INTO `users` (user_id, school_id, first_name, last_name, email, username, password, role, status)
VALUES (1, 1, 'Super', 'Admin', 'admin@school.com', 'superadmin', MD5('password'), 'super_admin', 'active')
ON DUPLICATE KEY UPDATE
  password = MD5('password'),
  status = 'active';

-- ============================================
-- SECTION 3: VERIFY
-- ============================================

-- Show the users table structure
DESCRIBE `users`;

-- Show the admin user was created
SELECT user_id, username, email, role, status FROM `users` WHERE username = 'superadmin';

-- Final confirmation
SELECT '✓ Users table fixed successfully!' as Status;
SELECT '✓ Default admin user created' as Message;
SELECT CONCAT('✓ Login with: superadmin / password') as Instructions;
