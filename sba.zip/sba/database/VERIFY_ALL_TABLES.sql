-- Comprehensive Database Verification Script
-- Run this to verify all 50+ tables are created correctly

-- ============================================
-- SECTION 1: VERIFY CORE TABLES (27 Original)
-- ============================================

-- Check Schools Table
SELECT 'Schools Table' as Table_Name, COUNT(*) as Row_Count FROM schools;

-- Check Users Table  
SELECT 'Users Table' as Table_Name, COUNT(*) as Row_Count FROM users;

-- Check Students Table
SELECT 'Students Table' as Table_Name, COUNT(*) as Row_Count FROM students;

-- Check Classes Table
SELECT 'Classes Table' as Table_Name, COUNT(*) as Row_Count FROM classes;

-- Check Teachers Table
SELECT 'Teachers Table' as Table_Name, COUNT(*) as Row_Count FROM teachers;

-- Check Attendance Table
SELECT 'Attendance Table' as Table_Name, COUNT(*) as Row_Count FROM attendance;

-- Check Exams Table
SELECT 'Exams Table' as Table_Name, COUNT(*) as Row_Count FROM exams;

-- Check Results Table
SELECT 'Results Table' as Table_Name, COUNT(*) as Row_Count FROM results;

-- ============================================
-- SECTION 2: VERIFY API TABLES
-- ============================================

-- Check API Tokens Table
SELECT 'API Tokens Table' as Table_Name, COUNT(*) as Row_Count FROM api_tokens;

-- Check API Logs Table
SELECT 'API Logs Table' as Table_Name, COUNT(*) as Row_Count FROM api_logs;

-- Check Audit Logs Table
SELECT 'Audit Logs Table' as Table_Name, COUNT(*) as Row_Count FROM audit_logs;

-- ============================================
-- SECTION 3: VERIFY ERROR LOGGING TABLES
-- ============================================

-- Check Error Logs Table
SELECT 'Error Logs Table' as Table_Name, COUNT(*) as Row_Count FROM error_logs;

-- Check System Logs Table
SELECT 'System Logs Table' as Table_Name, COUNT(*) as Row_Count FROM system_logs;

-- ============================================
-- SECTION 4: VERIFY SEARCH SYSTEM TABLES
-- ============================================

-- Check Saved Searches Table
SELECT 'Saved Searches Table' as Table_Name, COUNT(*) as Row_Count FROM saved_searches;

-- Check Search History Table
SELECT 'Search History Table' as Table_Name, COUNT(*) as Row_Count FROM search_history;

-- Check Search Filters Table
SELECT 'Search Filters Table' as Table_Name, COUNT(*) as Row_Count FROM search_filters;

-- ============================================
-- SECTION 5: VERIFY BULK OPERATIONS TABLES
-- ============================================

-- Check Bulk Operations Log Table
SELECT 'Bulk Operations Log' as Table_Name, COUNT(*) as Row_Count FROM bulk_operations_log;

-- Check Bulk Operations Queue Table
SELECT 'Bulk Operations Queue' as Table_Name, COUNT(*) as Row_Count FROM bulk_operations_queue;

-- Check Transcripts Table
SELECT 'Transcripts Table' as Table_Name, COUNT(*) as Row_Count FROM transcripts;

-- ============================================
-- SECTION 6: VERIFY EMAIL SYSTEM TABLES
-- ============================================

-- Check Email Queue Table
SELECT 'Email Queue Table' as Table_Name, COUNT(*) as Row_Count FROM email_queue;

-- Check Email Templates Table
SELECT 'Email Templates Table' as Table_Name, COUNT(*) as Row_Count FROM email_templates;

-- Check Email Logs Table
SELECT 'Email Logs Table' as Table_Name, COUNT(*) as Row_Count FROM email_logs;

-- Check Email Settings Table
SELECT 'Email Settings Table' as Table_Name, COUNT(*) as Row_Count FROM email_settings;

-- ============================================
-- SECTION 7: VERIFY BACKUP SYSTEM TABLES
-- ============================================

-- Check Backup Logs Table
SELECT 'Backup Logs Table' as Table_Name, COUNT(*) as Row_Count FROM backup_logs;

-- Check Restore Logs Table
SELECT 'Restore Logs Table' as Table_Name, COUNT(*) as Row_Count FROM restore_logs;

-- ============================================
-- SECTION 8: VERIFY DASHBOARD TABLES
-- ============================================

-- Check Dashboard Widgets Table
SELECT 'Dashboard Widgets Table' as Table_Name, COUNT(*) as Row_Count FROM dashboard_widgets;

-- Check Saved Reports Table
SELECT 'Saved Reports Table' as Table_Name, COUNT(*) as Row_Count FROM saved_reports;

-- Check Report Exports Table
SELECT 'Report Exports Table' as Table_Name, COUNT(*) as Row_Count FROM report_exports;

-- ============================================
-- SECTION 9: VERIFY LANGUAGE TABLES
-- ============================================

-- Check Language Settings Table
SELECT 'Language Settings Table' as Table_Name, COUNT(*) as Row_Count FROM language_settings;

-- Check Translation Strings Table
SELECT 'Translation Strings Table' as Table_Name, COUNT(*) as Row_Count FROM translation_strings;

-- Check User Language Preferences Table
SELECT 'User Language Preferences Table' as Table_Name, COUNT(*) as Row_Count FROM user_language_preferences;

-- ============================================
-- SECTION 10: VERIFY EMAIL TEMPLATES SETUP
-- ============================================

-- List all email templates
SELECT '=== EMAIL TEMPLATES ===' as Status;
SELECT template_id, template_name, subject, is_active FROM email_templates ORDER BY template_id;

-- ============================================
-- SECTION 11: SUMMARY
-- ============================================

-- Count total tables in database
SELECT CONCAT('✓ Total Tables Created: ', COUNT(*)) as Database_Summary 
FROM information_schema.tables 
WHERE table_schema = 'school_management_system';

-- Final verification message
SELECT '✓ VERIFICATION COMPLETE - All tables are ready for use!' as Final_Status;
