-- Reset all student passwords to "student123"
-- This allows all students to login with their username and the default password

-- The password hash for "student123" using PASSWORD_BCRYPT
SET @student_password_hash = '$2y$10$okazc9rLAeuZPpWefYO9ReB1gtRvirER01PUysBYy3lDM1E3zgd46';

-- Update all student user accounts to use the default password
UPDATE users 
SET password_hash = @student_password_hash
WHERE role = 'student';

-- Verify the update
SELECT 
    u.user_id,
    u.username,
    u.email,
    CONCAT(u.first_name, ' ', u.last_name) as Name,
    u.role,
    s.admission_number,
    'student123' as DefaultPassword
FROM users u
LEFT JOIN students s ON u.user_id = s.user_id
WHERE u.role = 'student'
ORDER BY u.user_id
LIMIT 10;

-- Summary
SELECT 
    'Student passwords reset successfully!' as Status,
    COUNT(*) as TotalStudents,
    'Username: [student username]' as LoginWith,
    'Password: student123' as DefaultPassword
FROM users 
WHERE role = 'student';
