-- ============================================================================
-- EXAM MANAGEMENT SYSTEM
-- Complete exam scheduling, hall tickets, and management
-- Date: November 12, 2025
-- ============================================================================

-- Exams Table (Main exam events like Mid-term, Final, etc.)
CREATE TABLE IF NOT EXISTS `exams` (
  `exam_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `term_id` INT(11) NULL,
  `exam_name` VARCHAR(255) NOT NULL,
  `exam_type` ENUM('mid_term', 'final', 'quarterly', 'monthly', 'unit_test', 'mock') DEFAULT 'mid_term',
  `academic_year` VARCHAR(20) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `status` ENUM('draft', 'scheduled', 'ongoing', 'completed', 'cancelled') DEFAULT 'draft',
  `instructions` TEXT NULL,
  `created_by` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`exam_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_status` (`status`),
  KEY `idx_dates` (`start_date`, `end_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Exam Schedule (Individual subject exams)
CREATE TABLE IF NOT EXISTS `exam_schedule` (
  `schedule_id` INT(11) NOT NULL AUTO_INCREMENT,
  `exam_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `exam_date` DATE NOT NULL,
  `start_time` TIME NOT NULL,
  `end_time` TIME NOT NULL,
  `duration_minutes` INT(3) NOT NULL,
  `total_marks` INT(3) DEFAULT 100,
  `room_number` VARCHAR(50) NULL,
  `supervisor_id` INT(11) NULL COMMENT 'Teacher supervising',
  `instructions` TEXT NULL,
  `status` ENUM('scheduled', 'ongoing', 'completed', 'cancelled') DEFAULT 'scheduled',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`schedule_id`),
  KEY `idx_exam` (`exam_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_date` (`exam_date`),
  KEY `idx_supervisor` (`supervisor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Hall Tickets
CREATE TABLE IF NOT EXISTS `hall_tickets` (
  `ticket_id` INT(11) NOT NULL AUTO_INCREMENT,
  `exam_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `ticket_number` VARCHAR(50) NOT NULL UNIQUE,
  `issued_date` DATE NOT NULL,
  `photo_url` VARCHAR(255) NULL,
  `qr_code` TEXT NULL COMMENT 'QR code for verification',
  `status` ENUM('issued', 'downloaded', 'printed', 'cancelled') DEFAULT 'issued',
  `special_instructions` TEXT NULL,
  `generated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ticket_id`),
  UNIQUE KEY `idx_exam_student` (`exam_id`, `student_id`),
  KEY `idx_ticket_number` (`ticket_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seating Arrangements
CREATE TABLE IF NOT EXISTS `exam_seating` (
  `seating_id` INT(11) NOT NULL AUTO_INCREMENT,
  `schedule_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `room_number` VARCHAR(50) NOT NULL,
  `seat_number` VARCHAR(20) NOT NULL,
  `row_number` INT(2) NULL,
  `column_number` INT(2) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`seating_id`),
  UNIQUE KEY `idx_schedule_student` (`schedule_id`, `student_id`),
  KEY `idx_room` (`room_number`),
  KEY `idx_seat` (`seat_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Exam Rooms
CREATE TABLE IF NOT EXISTS `exam_rooms` (
  `room_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `room_number` VARCHAR(50) NOT NULL,
  `room_name` VARCHAR(100) NULL,
  `capacity` INT(3) NOT NULL,
  `rows` INT(2) NULL,
  `columns` INT(2) NULL,
  `floor` VARCHAR(20) NULL,
  `building` VARCHAR(100) NULL,
  `facilities` TEXT NULL COMMENT 'AC, projector, etc.',
  `status` ENUM('active', 'maintenance', 'unavailable') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`room_id`),
  UNIQUE KEY `idx_school_room` (`school_id`, `room_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Exam Results (Quick entry, links to existing student_assessments)
CREATE TABLE IF NOT EXISTS `exam_results` (
  `result_id` INT(11) NOT NULL AUTO_INCREMENT,
  `schedule_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `marks_obtained` DECIMAL(5,2) NULL,
  `grade` VARCHAR(5) NULL,
  `remarks` VARCHAR(255) NULL,
  `absent` TINYINT(1) DEFAULT 0,
  `malpractice` TINYINT(1) DEFAULT 0,
  `entered_by` INT(11) NULL,
  `verified_by` INT(11) NULL,
  `entered_at` TIMESTAMP NULL,
  `verified_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`result_id`),
  UNIQUE KEY `idx_schedule_student` (`schedule_id`, `student_id`),
  KEY `idx_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Exam Attendance (Who appeared for each exam)
CREATE TABLE IF NOT EXISTS `exam_attendance` (
  `attendance_id` INT(11) NOT NULL AUTO_INCREMENT,
  `schedule_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `status` ENUM('present', 'absent', 'late') DEFAULT 'present',
  `arrival_time` TIME NULL,
  `left_time` TIME NULL,
  `marked_by` INT(11) NULL,
  `marked_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attendance_id`),
  UNIQUE KEY `idx_schedule_student` (`schedule_id`, `student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- INSERT DEFAULT EXAM ROOMS
-- ============================================================================

INSERT INTO `exam_rooms` (`school_id`, `room_number`, `room_name`, `capacity`, `rows`, `columns`, `status`)
SELECT school_id, 'ROOM-001', 'Main Hall', 100, 10, 10, 'active'
FROM schools
WHERE school_id NOT IN (SELECT school_id FROM exam_rooms WHERE room_number = 'ROOM-001')
ON DUPLICATE KEY UPDATE room_id=room_id;

INSERT INTO `exam_rooms` (`school_id`, `room_number`, `room_name`, `capacity`, `rows`, `columns`, `status`)
SELECT school_id, 'ROOM-002', 'Classroom A', 40, 8, 5, 'active'
FROM schools
WHERE school_id NOT IN (SELECT DISTINCT school_id FROM exam_rooms WHERE room_number = 'ROOM-002')
ON DUPLICATE KEY UPDATE room_id=room_id;

-- ============================================================================
-- VIEWS FOR QUICK ACCESS
-- ============================================================================

-- Upcoming exams view
CREATE OR REPLACE VIEW `upcoming_exams` AS
SELECT 
    e.exam_id,
    e.exam_name,
    e.exam_type,
    e.start_date,
    e.end_date,
    e.status,
    e.school_id,
    COUNT(DISTINCT es.schedule_id) as total_papers,
    COUNT(DISTINCT es.class_id) as classes_involved,
    DATEDIFF(e.start_date, CURDATE()) as days_until_exam
FROM exams e
LEFT JOIN exam_schedule es ON e.exam_id = es.exam_id
WHERE e.status IN ('scheduled', 'ongoing')
GROUP BY e.exam_id
ORDER BY e.start_date;

-- Student exam schedule view
CREATE OR REPLACE VIEW `student_exam_schedule` AS
SELECT 
    s.student_id,
    s.first_name,
    s.last_name,
    e.exam_id,
    e.exam_name,
    es.schedule_id,
    es.exam_date,
    es.start_time,
    es.end_time,
    subj.subject_name,
    es.room_number,
    es.total_marks,
    ht.ticket_number,
    CASE 
        WHEN es.exam_date < CURDATE() THEN 'completed'
        WHEN es.exam_date = CURDATE() THEN 'today'
        ELSE 'upcoming'
    END as exam_status
FROM students s
INNER JOIN classes c ON s.class_id = c.class_id
INNER JOIN exam_schedule es ON c.class_id = es.class_id
INNER JOIN exams e ON es.exam_id = e.exam_id
INNER JOIN subjects subj ON es.subject_id = subj.subject_id
LEFT JOIN hall_tickets ht ON e.exam_id = ht.exam_id AND s.student_id = ht.student_id
WHERE s.status = 'active' AND e.status IN ('scheduled', 'ongoing')
ORDER BY s.student_id, es.exam_date, es.start_time;

-- ============================================================================
-- STORED PROCEDURES
-- ============================================================================

DELIMITER //

-- Generate hall tickets for all students in an exam
DROP PROCEDURE IF EXISTS generate_hall_tickets//
CREATE PROCEDURE generate_hall_tickets(IN p_exam_id INT, IN p_school_id INT)
BEGIN
    DECLARE v_exam_name VARCHAR(255);
    DECLARE v_year VARCHAR(20);
    
    -- Get exam details
    SELECT exam_name, academic_year INTO v_exam_name, v_year
    FROM exams WHERE exam_id = p_exam_id;
    
    -- Generate tickets for all students in classes that have exam schedules
    INSERT INTO hall_tickets (exam_id, student_id, ticket_number, issued_date, status)
    SELECT DISTINCT
        p_exam_id,
        s.student_id,
        CONCAT('HT', p_school_id, '-', p_exam_id, '-', s.student_id),
        CURDATE(),
        'issued'
    FROM students s
    INNER JOIN classes c ON s.class_id = c.class_id
    INNER JOIN exam_schedule es ON c.class_id = es.class_id
    WHERE es.exam_id = p_exam_id 
    AND s.status = 'active'
    AND NOT EXISTS (
        SELECT 1 FROM hall_tickets ht 
        WHERE ht.exam_id = p_exam_id AND ht.student_id = s.student_id
    );
    
    SELECT ROW_COUNT() as tickets_generated;
END//

-- Auto-generate seating for an exam schedule
DROP PROCEDURE IF EXISTS auto_generate_seating//
CREATE PROCEDURE auto_generate_seating(IN p_schedule_id INT)
BEGIN
    DECLARE v_class_id INT;
    DECLARE v_room VARCHAR(50);
    DECLARE done INT DEFAULT 0;
    DECLARE v_student_id INT;
    DECLARE v_seat_counter INT DEFAULT 1;
    
    DECLARE student_cursor CURSOR FOR
        SELECT s.student_id
        FROM students s
        INNER JOIN exam_schedule es ON s.class_id = es.class_id
        WHERE es.schedule_id = p_schedule_id
        AND s.status = 'active'
        ORDER BY s.student_id;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    
    -- Get room and class
    SELECT class_id, room_number INTO v_class_id, v_room
    FROM exam_schedule WHERE schedule_id = p_schedule_id;
    
    -- Delete existing seating
    DELETE FROM exam_seating WHERE schedule_id = p_schedule_id;
    
    OPEN student_cursor;
    
    read_loop: LOOP
        FETCH student_cursor INTO v_student_id;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        INSERT INTO exam_seating (schedule_id, student_id, room_number, seat_number)
        VALUES (p_schedule_id, v_student_id, v_room, CONCAT('SEAT-', LPAD(v_seat_counter, 3, '0')));
        
        SET v_seat_counter = v_seat_counter + 1;
    END LOOP;
    
    CLOSE student_cursor;
    
    SELECT v_seat_counter - 1 as seats_assigned;
END//

DELIMITER ;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT 'Exam management system created successfully!' as status;
SELECT 'Tables: exams, exam_schedule, hall_tickets, exam_seating, exam_rooms, exam_results, exam_attendance' as tables_created;
SELECT 'Views: upcoming_exams, student_exam_schedule' as views_created;
SELECT 'Procedures: generate_hall_tickets, auto_generate_seating' as procedures_created;
