-- ================================================================================
-- RECALCULATE ALL RESULTS WITH SIMPLIFIED FORMULA
-- Date: November 17, 2025
-- Formula: Total = [(CA + Mid-Term) × 0.5] + [Exam × 0.5]
-- ================================================================================

-- Step 1: Show current statistics before update
SELECT '==================== BEFORE UPDATE ====================' as '';
SELECT 
    COUNT(*) as total_records,
    COUNT(CASE WHEN total_score > 0 THEN 1 END) as records_with_scores,
    COUNT(CASE WHEN total_score = 0 OR total_score IS NULL THEN 1 END) as records_without_scores,
    ROUND(AVG(total_score), 2) as avg_total_before
FROM student_assessments;

-- Step 2: Drop existing triggers to prevent interference
DROP TRIGGER IF EXISTS calculate_scores_before_insert;
DROP TRIGGER IF EXISTS calculate_scores_before_update;

-- Step 3: Recalculate ALL total scores using simplified formula
UPDATE student_assessments
SET total_score = ROUND(
    ((COALESCE(ca_score, 0) + COALESCE(midterm_score, 0)) * 0.5) + 
    (COALESCE(exam_score, 0) * 0.5),
    2
)
WHERE 1=1;

-- Step 4: Recalculate ALL grades based on new totals
UPDATE student_assessments
SET grade = CASE
    WHEN total_score >= 90 THEN 'A+'
    WHEN total_score >= 80 THEN 'A'
    WHEN total_score >= 75 THEN 'B+'
    WHEN total_score >= 70 THEN 'B'
    WHEN total_score >= 65 THEN 'C+'
    WHEN total_score >= 60 THEN 'C'
    WHEN total_score >= 50 THEN 'D'
    ELSE 'F'
END
WHERE total_score IS NOT NULL;

-- Step 5: Recalculate ALL remarks based on new totals
UPDATE student_assessments
SET remark = CASE
    WHEN total_score >= 80 THEN 'Excellent'
    WHEN total_score >= 70 THEN 'Very Good'
    WHEN total_score >= 60 THEN 'Good'
    WHEN total_score >= 50 THEN 'Fair'
    ELSE 'Fail'
END
WHERE total_score IS NOT NULL;

-- Step 6: Recreate triggers with simplified formula
DELIMITER $$

CREATE TRIGGER calculate_scores_before_insert
BEFORE INSERT ON student_assessments
FOR EACH ROW
BEGIN
    -- Set max scores
    SET NEW.ca_max = 60;
    SET NEW.midterm_max = 40;
    SET NEW.exam_max = 100;
    
    -- Calculate total: [(CA + MT) × 0.5] + [Exam × 0.5]
    SET NEW.total_score = ROUND(
        ((COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5) + 
        (COALESCE(NEW.exam_score, 0) * 0.5),
        2
    );
    
    -- Calculate grade
    SET NEW.grade = CASE
        WHEN NEW.total_score >= 90 THEN 'A+'
        WHEN NEW.total_score >= 80 THEN 'A'
        WHEN NEW.total_score >= 75 THEN 'B+'
        WHEN NEW.total_score >= 70 THEN 'B'
        WHEN NEW.total_score >= 65 THEN 'C+'
        WHEN NEW.total_score >= 60 THEN 'C'
        WHEN NEW.total_score >= 50 THEN 'D'
        ELSE 'F'
    END;
    
    -- Calculate remark
    SET NEW.remark = CASE
        WHEN NEW.total_score >= 80 THEN 'Excellent'
        WHEN NEW.total_score >= 70 THEN 'Very Good'
        WHEN NEW.total_score >= 60 THEN 'Good'
        WHEN NEW.total_score >= 50 THEN 'Fair'
        ELSE 'Fail'
    END;
END$$

CREATE TRIGGER calculate_scores_before_update
BEFORE UPDATE ON student_assessments
FOR EACH ROW
BEGIN
    -- Set max scores
    SET NEW.ca_max = 60;
    SET NEW.midterm_max = 40;
    SET NEW.exam_max = 100;
    
    -- Calculate total: [(CA + MT) × 0.5] + [Exam × 0.5]
    SET NEW.total_score = ROUND(
        ((COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5) + 
        (COALESCE(NEW.exam_score, 0) * 0.5),
        2
    );
    
    -- Calculate grade
    SET NEW.grade = CASE
        WHEN NEW.total_score >= 90 THEN 'A+'
        WHEN NEW.total_score >= 80 THEN 'A'
        WHEN NEW.total_score >= 75 THEN 'B+'
        WHEN NEW.total_score >= 70 THEN 'B'
        WHEN NEW.total_score >= 65 THEN 'C+'
        WHEN NEW.total_score >= 60 THEN 'C'
        WHEN NEW.total_score >= 50 THEN 'D'
        ELSE 'F'
    END;
    
    -- Calculate remark
    SET NEW.remark = CASE
        WHEN NEW.total_score >= 80 THEN 'Excellent'
        WHEN NEW.total_score >= 70 THEN 'Very Good'
        WHEN NEW.total_score >= 60 THEN 'Good'
        WHEN NEW.total_score >= 50 THEN 'Fair'
        ELSE 'Fail'
    END;
END$$

DELIMITER ;

-- Step 7: Show statistics after update
SELECT '==================== AFTER UPDATE ====================' as '';
SELECT 
    COUNT(*) as total_records,
    COUNT(CASE WHEN total_score > 0 THEN 1 END) as records_with_scores,
    COUNT(CASE WHEN total_score = 0 OR total_score IS NULL THEN 1 END) as records_without_scores,
    ROUND(AVG(total_score), 2) as avg_total_after
FROM student_assessments;

-- Step 8: Show grade distribution
SELECT '==================== GRADE DISTRIBUTION ====================' as '';
SELECT 
    grade,
    COUNT(*) as count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM student_assessments WHERE total_score > 0), 2) as percentage
FROM student_assessments
WHERE total_score > 0
GROUP BY grade
ORDER BY FIELD(grade, 'A+', 'A', 'B+', 'B', 'C+', 'C', 'D', 'F');

-- Step 9: Show sample results
SELECT '==================== SAMPLE RECALCULATED RESULTS ====================' as '';
SELECT 
    assessment_id,
    student_id,
    ca_score,
    midterm_score,
    exam_score,
    total_score,
    grade,
    remark
FROM student_assessments
WHERE total_score > 0
ORDER BY total_score DESC
LIMIT 10;

-- Step 10: Verify formula examples
SELECT '==================== FORMULA VERIFICATION ====================' as '';
SELECT 
    'Perfect Scores' as test_case,
    60 as ca,
    40 as midterm,
    100 as exam,
    ROUND(((60 + 40) * 0.5) + (100 * 0.5), 2) as expected_total,
    (SELECT total_score FROM student_assessments WHERE ca_score = 60 AND midterm_score = 40 AND exam_score = 100 LIMIT 1) as actual_total
UNION ALL
SELECT 
    'Half Scores',
    30,
    20,
    50,
    ROUND(((30 + 20) * 0.5) + (50 * 0.5), 2),
    (SELECT total_score FROM student_assessments WHERE ca_score = 30 AND midterm_score = 20 AND exam_score = 50 LIMIT 1)
UNION ALL
SELECT 
    'Zero Scores',
    0,
    0,
    0,
    ROUND(((0 + 0) * 0.5) + (0 * 0.5), 2),
    (SELECT total_score FROM student_assessments WHERE ca_score = 0 AND midterm_score = 0 AND exam_score = 0 LIMIT 1);

-- Success message
SELECT '==================== SUCCESS! ====================' as '';
SELECT 'All results recalculated with simplified formula!' as Status;
SELECT 'Formula: Total = [(CA + Mid-Term) × 0.5] + [Exam × 0.5]' as Formula;
SELECT 'Triggers updated and ready for new entries' as TriggerStatus;
SELECT '==================== COMPLETE ====================' as '';
