-- Add missing columns to schools table

-- Add website column if it doesn't exist
ALTER TABLE schools 
ADD COLUMN IF NOT EXISTS website VARCHAR(255) AFTER email;

-- Add principal_name column if it doesn't exist
ALTER TABLE schools 
ADD COLUMN IF NOT EXISTS principal_name VARCHAR(200) AFTER motto;

-- Update existing schools to have default values
UPDATE schools 
SET website = '' 
WHERE website IS NULL;

UPDATE schools 
SET principal_name = '' 
WHERE principal_name IS NULL;
