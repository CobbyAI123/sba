-- Academic Terms Table
CREATE TABLE IF NOT EXISTS terms (
    term_id INT PRIMARY KEY AUTO_INCREMENT,
    school_id INT NOT NULL,
    term_name VARCHAR(50) NOT NULL,
    session_year VARCHAR(20) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_active TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
    INDEX idx_school_active (school_id, is_active),
    INDEX idx_session (session_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample terms for existing schools (only if schools exist)
INSERT IGNORE INTO terms (school_id, term_name, session_year, start_date, end_date, is_active)
SELECT 
    s.school_id,
    'First Term',
    '2024/2025',
    '2024-09-01',
    '2024-12-20',
    1
FROM schools s
LEFT JOIN terms t ON s.school_id = t.school_id
WHERE t.term_id IS NULL;
