-- ============================================================================
-- INSERT SAMPLE MARKS DATA FOR TESTING PERFORMANCE ANALYTICS
-- ============================================================================
-- This script inserts sample student marks for testing the Performance Analytics
-- feature. It creates realistic test data across multiple students, subjects, and terms.
-- ============================================================================

-- First, let's check what data we have
SELECT '=== CURRENT DATABASE STATE ===' as info;

SELECT 
    'Schools' as entity,
    COUNT(*) as count,
    GROUP_CONCAT(school_id SEPARATOR ', ') as ids
FROM schools;

SELECT 
    'Students' as entity,
    COUNT(*) as count,
    GROUP_CONCAT(student_id ORDER BY student_id LIMIT 10 SEPARATOR ', ') as sample_ids
FROM students;

SELECT 
    'Subjects' as entity,
    COUNT(*) as count,
    GROUP_CONCAT(subject_id ORDER BY subject_id LIMIT 10 SEPARATOR ', ') as sample_ids
FROM subjects;

SELECT 
    'Classes' as entity,
    COUNT(*) as count,
    GROUP_CONCAT(class_id ORDER BY class_id LIMIT 10 SEPARATOR ', ') as sample_ids
FROM classes;

SELECT 
    'Terms' as entity,
    COUNT(*) as count,
    GROUP_CONCAT(CONCAT(term_id, ':', term_name, ' ', session_year) SEPARATOR ' | ') as terms
FROM terms;

SELECT 
    'Existing Marks' as entity,
    COUNT(*) as count
FROM marks;

-- ============================================================================
-- INSERT SAMPLE MARKS
-- ============================================================================
-- This will insert marks for the first 10 students across available subjects and terms

-- Delete existing sample marks (optional - comment out if you want to keep existing data)
-- DELETE FROM marks WHERE mark_id > 0;

-- Insert marks for multiple students
INSERT INTO marks (student_id, subject_id, class_id, term_id, ca_score, midterm_score, exam_score)
SELECT 
    s.student_id,
    sub.subject_id,
    s.class_id,
    t.term_id,
    -- CA Score (0-60) - random but realistic
    FLOOR(30 + (RAND() * 30)) as ca_score,
    -- Midterm Score (0-40) - random but realistic
    FLOOR(20 + (RAND() * 20)) as midterm_score,
    -- Exam Score (0-100) - random but realistic
    FLOOR(40 + (RAND() * 60)) as exam_score
FROM students s
CROSS JOIN subjects sub
CROSS JOIN terms t
WHERE 
    s.student_id <= 10  -- First 10 students
    AND sub.subject_id <= 10  -- First 10 subjects
    AND t.term_id <= 3  -- First 3 terms
    AND s.school_id = sub.school_id
    AND s.school_id = t.school_id
    -- Don't insert if already exists
    AND NOT EXISTS (
        SELECT 1 FROM marks m 
        WHERE m.student_id = s.student_id 
        AND m.subject_id = sub.subject_id 
        AND m.term_id = t.term_id
    )
LIMIT 300;  -- Limit to prevent too much data

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

SELECT '=== MARKS INSERTION RESULTS ===' as info;

-- Count total marks inserted
SELECT 
    'Total Marks Records' as metric,
    COUNT(*) as count
FROM marks;

-- Marks by student
SELECT 
    'Marks by Student' as info,
    s.admission_number,
    CONCAT(COALESCE(u.first_name, 'Unknown'), ' ', COALESCE(u.last_name, '')) as student_name,
    COUNT(m.mark_id) as total_assessments,
    ROUND(AVG(m.total_score), 1) as average_score
FROM marks m
JOIN students s ON m.student_id = s.student_id
LEFT JOIN users u ON s.user_id = u.user_id
GROUP BY s.student_id
ORDER BY s.student_id
LIMIT 10;

-- Marks by term
SELECT 
    'Marks by Term' as info,
    t.term_name,
    t.session_year,
    COUNT(m.mark_id) as total_assessments,
    COUNT(DISTINCT m.student_id) as students_assessed,
    ROUND(AVG(m.total_score), 1) as average_score
FROM marks m
JOIN terms t ON m.term_id = t.term_id
GROUP BY t.term_id
ORDER BY t.session_year, t.term_name;

-- Marks by subject
SELECT 
    'Marks by Subject' as info,
    sub.subject_name,
    COUNT(m.mark_id) as total_assessments,
    ROUND(AVG(m.total_score), 1) as average_score,
    ROUND(MAX(m.total_score), 1) as highest_score,
    ROUND(MIN(m.total_score), 1) as lowest_score
FROM marks m
JOIN subjects sub ON m.subject_id = sub.subject_id
GROUP BY sub.subject_id
ORDER BY average_score DESC
LIMIT 10;

-- Grade distribution
SELECT 
    'Grade Distribution' as info,
    m.grade,
    COUNT(*) as count,
    ROUND((COUNT(*) * 100.0 / (SELECT COUNT(*) FROM marks)), 1) as percentage
FROM marks m
GROUP BY m.grade
ORDER BY 
    CASE m.grade
        WHEN 'HP' THEN 1
        WHEN 'P' THEN 2
        WHEN 'AP' THEN 3
        WHEN 'D' THEN 4
        WHEN 'E' THEN 5
        ELSE 6
    END;

-- Sample marks data
SELECT 
    '=== SAMPLE MARKS DATA ===' as info;

SELECT 
    s.admission_number,
    CONCAT(COALESCE(u.first_name, 'Unknown'), ' ', COALESCE(u.last_name, '')) as student_name,
    sub.subject_name,
    t.term_name,
    t.session_year,
    m.ca_score,
    m.midterm_score,
    m.exam_score,
    m.total_score,
    m.grade,
    m.remark
FROM marks m
JOIN students s ON m.student_id = s.student_id
LEFT JOIN users u ON s.user_id = u.user_id
JOIN subjects sub ON m.subject_id = sub.subject_id
JOIN terms t ON m.term_id = t.term_id
ORDER BY s.admission_number, t.session_year, t.term_name, sub.subject_name
LIMIT 20;

-- ============================================================================
-- PERFORMANCE ANALYTICS TEST QUERIES
-- ============================================================================

SELECT '=== PERFORMANCE ANALYTICS READY ===' as status;

-- Check if data is ready for Performance Analytics
SELECT 
    CASE 
        WHEN (SELECT COUNT(*) FROM marks) > 0 THEN '✅ YES - Performance Analytics Ready!'
        ELSE '❌ NO - No marks data found'
    END as analytics_ready,
    (SELECT COUNT(*) FROM marks) as total_marks,
    (SELECT COUNT(DISTINCT student_id) FROM marks) as students_with_marks,
    (SELECT COUNT(DISTINCT term_id) FROM marks) as terms_with_marks,
    (SELECT COUNT(DISTINCT subject_id) FROM marks) as subjects_with_marks;

-- ============================================================================
-- NOTES
-- ============================================================================
/*
USAGE INSTRUCTIONS:
1. Run this script in phpMyAdmin SQL tab
2. Check the verification results
3. Access Performance Analytics in Proprietor portal
4. Test all three analysis modes:
   - By Term
   - By Academic Year
   - By Student

WHAT THIS SCRIPT DOES:
- Inserts sample marks for first 10 students
- Covers first 10 subjects and first 3 terms
- Generates realistic random scores
- Auto-calculates total scores and grades via triggers
- Prevents duplicate entries

GRADING SYSTEM:
- HP (Highly Proficient): 80-100%
- P (Proficient): 68-79%
- AP (Approaching Proficient): 53-67%
- D (Developing): 40-52%
- E (Emerging): 0-39%

SCORE CALCULATION:
Total = [(CA + Midterm) × 0.5] + [Exam × 0.5]

TROUBLESHOOTING:
If you get errors:
1. Check that marks table exists
2. Verify students, subjects, and terms exist
3. Ensure triggers are created
4. Check foreign key constraints

TO DELETE SAMPLE DATA:
DELETE FROM marks WHERE mark_id > 0;
*/

-- ============================================================================
-- END OF SCRIPT
-- ============================================================================
