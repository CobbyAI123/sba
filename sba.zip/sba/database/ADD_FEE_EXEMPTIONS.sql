-- ============================================================================
-- ADD FEE EXEMPTION SYSTEM TO STUDENTS TABLE
-- ============================================================================
-- This script adds columns for tracking fee exemptions for students
-- ============================================================================
-- Note: Database is already selected in phpMyAdmin - no need for USE statement

-- ... existing code ...
ALTER TABLE students 
ADD COLUMN IF NOT EXISTS fee_exemption JSON DEFAULT NULL COMMENT 'Array of exempted fee types: school, canteen, transport',
ADD COLUMN IF NOT EXISTS exemption_reason TEXT DEFAULT NULL COMMENT 'Reason for fee exemption',
ADD COLUMN IF NOT EXISTS exemption_approved_by INT DEFAULT NULL COMMENT 'User ID who approved the exemption',
ADD COLUMN IF NOT EXISTS exemption_date DATE DEFAULT NULL COMMENT 'Date when exemption was granted';

-- Add collection_period column to payments table for weekly/monthly tracking
ALTER TABLE payments
ADD COLUMN IF NOT EXISTS collection_period ENUM('weekly', 'monthly', 'termly', 'annual') DEFAULT NULL COMMENT 'Period for which fee was collected',
ADD COLUMN IF NOT EXISTS submitted_to INT DEFAULT NULL COMMENT 'Accountant ID to whom teacher submitted collection',
ADD COLUMN IF NOT EXISTS submitted_at DATETIME DEFAULT NULL COMMENT 'When teacher submitted to accountant',
ADD COLUMN IF NOT EXISTS verified_by INT DEFAULT NULL COMMENT 'Accountant who verified the collection',
ADD COLUMN IF NOT EXISTS verified_at DATETIME DEFAULT NULL COMMENT 'When collection was verified',
ADD COLUMN IF NOT EXISTS verification_notes TEXT DEFAULT NULL COMMENT 'Notes from verification process';

-- Update payment status enum to include new statuses
ALTER TABLE payments 
MODIFY COLUMN status ENUM('pending', 'completed', 'cancelled', 'refunded', 'pending_verification', 'submitted_to_accountant', 'rejected') DEFAULT 'completed';

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_payments_collection_period ON payments(collection_period);
CREATE INDEX IF NOT EXISTS idx_payments_submitted ON payments(submitted_to, submitted_at);
CREATE INDEX IF NOT EXISTS idx_payments_verified ON payments(verified_by, verified_at);
CREATE INDEX IF NOT EXISTS idx_students_exemption ON students(fee_exemption(255));

-- ============================================================================
-- SAMPLE DATA FOR TESTING (OPTIONAL)
-- ============================================================================

-- Example: Set fee exemption for a student (uncomment to use)
/*
UPDATE students 
SET 
    fee_exemption = JSON_ARRAY('school', 'canteen'),
    exemption_reason = 'Scholarship student - Full exemption',
    exemption_date = CURDATE(),
    exemption_approved_by = (SELECT user_id FROM users WHERE role = 'admin' LIMIT 1)
WHERE student_id = 1;
*/

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Check if columns were added successfully
SELECT '=== Verifying Students Table ===' as info;
DESCRIBE students;

SELECT '=== Verifying Payments Table ===' as info;
DESCRIBE payments;

-- Check exempted students
SELECT '=== Students with Fee Exemptions ===' as info;
SELECT 
    s.student_id,
    s.admission_number,
    CONCAT(u.first_name, ' ', u.last_name) as student_name,
    s.fee_exemption,
    s.exemption_reason,
    s.exemption_date
FROM students s
LEFT JOIN users u ON s.user_id = u.user_id
WHERE s.fee_exemption IS NOT NULL;

SELECT '✅ Fee Exemption System Installed Successfully!' as status;

-- ============================================================================
-- NOTES
-- ============================================================================
/*
FEE EXEMPTION USAGE:

1. To exempt a student from school fees:
   UPDATE students 
   SET fee_exemption = JSON_ARRAY('school')
   WHERE student_id = ?;

2. To exempt from multiple fees:
   UPDATE students 
   SET fee_exemption = JSON_ARRAY('school', 'canteen', 'transport')
   WHERE student_id = ?;

3. To check if student is exempted:
   SELECT 
       JSON_CONTAINS(fee_exemption, '"school"') as school_exempted,
       JSON_CONTAINS(fee_exemption, '"canteen"') as canteen_exempted,
       JSON_CONTAINS(fee_exemption, '"transport"') as transport_exempted
   FROM students 
   WHERE student_id = ?;

4. Exemption types:
   - 'school' - School fees
   - 'canteen' - Canteen fees
   - 'transport' - Transport/bus fees

COLLECTION PERIOD USAGE:

1. Teacher collects weekly fee:
   INSERT INTO payments (..., collection_period) 
   VALUES (..., 'weekly');

2. Find this week's collections:
   SELECT * FROM payments 
   WHERE collection_period = 'weekly' 
   AND WEEK(payment_date) = WEEK(CURDATE());

3. Find this month's collections:
   SELECT * FROM payments 
   WHERE collection_period = 'monthly' 
   AND MONTH(payment_date) = MONTH(CURDATE());
*/

-- ============================================================================
-- END OF SCRIPT
-- ============================================================================
