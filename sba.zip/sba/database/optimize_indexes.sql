-- ============================================================================
-- DATABASE OPTIMIZATION - Performance Indexes
-- Purpose: Add indexes to improve query performance
-- Version: 1.9.0
-- Date: January 2026
-- ============================================================================

-- This script adds essential indexes for frequently queried columns
-- Run this after importing schema.sql for production deployments

-- ============================================================================
-- STUDENTS TABLE OPTIMIZATION
-- ============================================================================

-- Index for student lookups by admission number
CREATE INDEX IF NOT EXISTS idx_students_admission ON students(admission_number);

-- Index for class-based queries
CREATE INDEX IF NOT EXISTS idx_students_class ON students(class_id, status);

-- Index for user account linking
CREATE INDEX IF NOT EXISTS idx_students_user ON students(user_id);

-- Composite index for active students in a school
CREATE INDEX IF NOT EXISTS idx_students_school_status ON students(school_id, status, class_id);

-- Index for name searches
CREATE INDEX IF NOT EXISTS idx_students_name ON students(first_name, last_name);

-- ============================================================================
-- ATTENDANCE TABLE OPTIMIZATION
-- ============================================================================

-- Index for attendance date queries
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(attendance_date, class_id);

-- Index for student attendance history
CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance(student_id, attendance_date);

-- Composite index for class attendance on specific dates
CREATE INDEX IF NOT EXISTS idx_attendance_class_date ON attendance(class_id, attendance_date, status);

-- Index for school-wide attendance reports
CREATE INDEX IF NOT EXISTS idx_attendance_school ON attendance(school_id, attendance_date);

-- ============================================================================
-- PAYMENTS TABLE OPTIMIZATION
-- ============================================================================

-- Index for payment date queries
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date, school_id);

-- Index for student payment history
CREATE INDEX IF NOT EXISTS idx_payments_student ON payments(student_id, payment_status);

-- Index for payment method analysis
CREATE INDEX IF NOT EXISTS idx_payments_method ON payments(payment_method, payment_status);

-- Index for payment reference lookups
CREATE INDEX IF NOT EXISTS idx_payments_reference ON payments(payment_reference);

-- Composite index for financial reporting
CREATE INDEX IF NOT EXISTS idx_payments_school_date_status ON payments(school_id, payment_date, payment_status);

-- Index for term-based fee tracking
CREATE INDEX IF NOT EXISTS idx_payments_term ON payments(term_id, student_id);

-- ============================================================================
-- MARKS TABLE OPTIMIZATION
-- ============================================================================

-- Index for student marks retrieval
CREATE INDEX IF NOT EXISTS idx_marks_student ON marks(student_id, term_id);

-- Index for exam-based queries
CREATE INDEX IF NOT EXISTS idx_marks_exam ON marks(exam_id, student_id);

-- Index for subject performance analysis
CREATE INDEX IF NOT EXISTS idx_marks_subject ON marks(subject_id, student_id);

-- Composite index for class results
CREATE INDEX IF NOT EXISTS idx_marks_class_exam ON marks(class_id, exam_id, total_score);

-- ============================================================================
-- EXAMS TABLE OPTIMIZATION
-- ============================================================================

-- Index for exam schedule queries
CREATE INDEX IF NOT EXISTS idx_exams_date ON exams(exam_date, class_id);

-- Index for term exams
CREATE INDEX IF NOT EXISTS idx_exams_term ON exams(term_id, class_id);

-- Index for exam type filtering
CREATE INDEX IF NOT EXISTS idx_exams_type ON exams(exam_type, term_id);

-- ============================================================================
-- FEE_STRUCTURE TABLE OPTIMIZATION
-- ============================================================================

-- Index for class fee lookups
CREATE INDEX IF NOT EXISTS idx_fee_structure_class ON fee_structure(class_id, term_id);

-- Index for fee type queries
CREATE INDEX IF NOT EXISTS idx_fee_structure_type ON fee_structure(fee_type, class_id);

-- Index for active fees
CREATE INDEX IF NOT EXISTS idx_fee_structure_status ON fee_structure(status, school_id);

-- ============================================================================
-- USERS TABLE OPTIMIZATION
-- ============================================================================

-- Index for email lookups (login)
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- Index for role-based queries
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role, school_id, status);

-- Index for username lookups (already exists but ensure)
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);

-- Index for last login tracking
CREATE INDEX IF NOT EXISTS idx_users_last_login ON users(last_login);

-- ============================================================================
-- ACTIVITY_LOGS TABLE OPTIMIZATION
-- ============================================================================

-- Index for user activity queries
CREATE INDEX IF NOT EXISTS idx_activity_logs_user ON activity_logs(user_id, created_at);

-- Index for time-based queries
CREATE INDEX IF NOT EXISTS idx_activity_logs_date ON activity_logs(created_at, school_id);

-- Index for action type filtering
CREATE INDEX IF NOT EXISTS idx_activity_logs_action ON activity_logs(action, created_at);

-- Index for table-specific logs
CREATE INDEX IF NOT EXISTS idx_activity_logs_table ON activity_logs(table_name, record_id);

-- ============================================================================
-- NOTIFICATIONS TABLE OPTIMIZATION
-- ============================================================================

-- Index for user notifications
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read, created_at);

-- Index for unread count queries
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(user_id, is_read);

-- Index for notification type
CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(type, created_at);

-- ============================================================================
-- CLASSES TABLE OPTIMIZATION
-- ============================================================================

-- Index for school classes
CREATE INDEX IF NOT EXISTS idx_classes_school ON classes(school_id, status);

-- Index for class level ordering
CREATE INDEX IF NOT EXISTS idx_classes_level ON classes(class_level, school_id);

-- ============================================================================
-- SUBJECTS TABLE OPTIMIZATION
-- ============================================================================

-- Index for school subjects
CREATE INDEX IF NOT EXISTS idx_subjects_school ON subjects(school_id, status);

-- Index for subject code lookups
CREATE INDEX IF NOT EXISTS idx_subjects_code ON subjects(subject_code);

-- ============================================================================
-- CLASS_SUBJECTS TABLE OPTIMIZATION
-- ============================================================================

-- Index for class-subject relationships
CREATE INDEX IF NOT EXISTS idx_class_subjects_class ON class_subjects(class_id);

-- Index for subject assignment
CREATE INDEX IF NOT EXISTS idx_class_subjects_subject ON class_subjects(subject_id);

-- Index for teacher assignments
CREATE INDEX IF NOT EXISTS idx_class_subjects_teacher ON class_subjects(teacher_id);

-- ============================================================================
-- TIMETABLE TABLE OPTIMIZATION
-- ============================================================================

-- Index for class timetable queries
CREATE INDEX IF NOT EXISTS idx_timetable_class ON timetable(class_id, day_of_week);

-- Index for teacher schedules
CREATE INDEX IF NOT EXISTS idx_timetable_teacher ON timetable(teacher_id, day_of_week);

-- Index for subject schedules
CREATE INDEX IF NOT EXISTS idx_timetable_subject ON timetable(subject_id, class_id);

-- ============================================================================
-- TERMS TABLE OPTIMIZATION
-- ============================================================================

-- Index for current term queries
CREATE INDEX IF NOT EXISTS idx_terms_current ON terms(is_current, school_id);

-- Index for academic year terms
CREATE INDEX IF NOT EXISTS idx_terms_year ON terms(year_id, school_id);

-- Index for term dates
CREATE INDEX IF NOT EXISTS idx_terms_dates ON terms(start_date, end_date);

-- ============================================================================
-- ACADEMIC_YEARS TABLE OPTIMIZATION
-- ============================================================================

-- Index for current academic year
CREATE INDEX IF NOT EXISTS idx_academic_years_current ON academic_years(is_current, school_id);

-- Index for year dates
CREATE INDEX IF NOT EXISTS idx_academic_years_dates ON academic_years(start_date, end_date);

-- ============================================================================
-- LIBRARY_BOOKS TABLE OPTIMIZATION
-- ============================================================================

-- Index for book searches
CREATE INDEX IF NOT EXISTS idx_library_books_title ON library_books(title);

-- Index for ISBN lookups
CREATE INDEX IF NOT EXISTS idx_library_books_isbn ON library_books(isbn);

-- Index for category filtering
CREATE INDEX IF NOT EXISTS idx_library_books_category ON library_books(category);

-- Index for availability status
CREATE INDEX IF NOT EXISTS idx_library_books_status ON library_books(status, school_id);

-- ============================================================================
-- LIBRARY_TRANSACTIONS TABLE OPTIMIZATION
-- ============================================================================

-- Index for student borrowing history
CREATE INDEX IF NOT EXISTS idx_library_trans_student ON library_transactions(student_id, return_date);

-- Index for book transaction history
CREATE INDEX IF NOT EXISTS idx_library_trans_book ON library_transactions(book_id, transaction_type);

-- Index for overdue books
CREATE INDEX IF NOT EXISTS idx_library_trans_overdue ON library_transactions(due_date, return_date);

-- ============================================================================
-- PARENTS TABLE OPTIMIZATION
-- ============================================================================

-- Index for parent user account
CREATE INDEX IF NOT EXISTS idx_parents_user ON parents(user_id);

-- Index for school parents
CREATE INDEX IF NOT EXISTS idx_parents_school ON parents(school_id);

-- ============================================================================
-- STUDENT_PARENTS TABLE OPTIMIZATION
-- ============================================================================

-- Index for student-parent relationships
CREATE INDEX IF NOT EXISTS idx_student_parents_student ON student_parents(student_id);

-- Index for parent's children
CREATE INDEX IF NOT EXISTS idx_student_parents_parent ON student_parents(parent_id);

-- Index for primary parent identification
CREATE INDEX IF NOT EXISTS idx_student_parents_primary ON student_parents(student_id, is_primary);

-- ============================================================================
-- NEWS TABLE OPTIMIZATION
-- ============================================================================

-- Index for published news
CREATE INDEX IF NOT EXISTS idx_news_status ON news(status, publish_date);

-- Index for school news
CREATE INDEX IF NOT EXISTS idx_news_school ON news(school_id, status);

-- Index for news category
CREATE INDEX IF NOT EXISTS idx_news_category ON news(category, publish_date);

-- ============================================================================
-- OPTIMIZE ALL TABLES
-- ============================================================================

-- Analyze and optimize all tables for better performance
ANALYZE TABLE students;
ANALYZE TABLE attendance;
ANALYZE TABLE payments;
ANALYZE TABLE marks;
ANALYZE TABLE exams;
ANALYZE TABLE fee_structure;
ANALYZE TABLE users;
ANALYZE TABLE activity_logs;
ANALYZE TABLE notifications;
ANALYZE TABLE classes;
ANALYZE TABLE subjects;
ANALYZE TABLE class_subjects;
ANALYZE TABLE timetable;
ANALYZE TABLE terms;
ANALYZE TABLE academic_years;

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Run these queries to verify indexes were created successfully

-- Show all indexes on students table
-- SHOW INDEX FROM students;

-- Show all indexes on payments table
-- SHOW INDEX FROM payments;

-- Show all indexes on attendance table
-- SHOW INDEX FROM attendance;

-- Check database size
-- SELECT 
--     table_schema as `Database`, 
--     ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as `Size (MB)`
-- FROM information_schema.tables
-- WHERE table_schema = 'sba'
-- GROUP BY table_schema;

-- ============================================================================
-- PERFORMANCE TESTING
-- ============================================================================

-- Test query performance with EXPLAIN
-- Examples:

-- Test student search performance
-- EXPLAIN SELECT * FROM students WHERE school_id = 1 AND status = 'active' AND class_id = 5;

-- Test attendance query performance
-- EXPLAIN SELECT * FROM attendance WHERE class_id = 5 AND attendance_date = '2026-01-11';

-- Test payment report performance
-- EXPLAIN SELECT * FROM payments WHERE school_id = 1 AND payment_date BETWEEN '2026-01-01' AND '2026-01-31';

-- ============================================================================
-- MAINTENANCE RECOMMENDATIONS
-- ============================================================================

/*
1. Run ANALYZE TABLE monthly to update statistics
2. Monitor slow query log for optimization opportunities
3. Consider partitioning large tables (attendance, payments, activity_logs)
4. Implement archiving strategy for old data
5. Regular backups before optimization

Monitoring Commands:
- SHOW PROCESSLIST; (Check running queries)
- SHOW STATUS LIKE 'Slow_queries'; (Monitor slow queries)
- SHOW TABLE STATUS FROM sba; (Check table statistics)
*/

-- ============================================================================
-- COMPLETION MESSAGE
-- ============================================================================

SELECT 'Database optimization completed successfully!' as Status,
       'All indexes have been created' as Message,
       NOW() as Completed_At;

-- ============================================================================
-- END OF OPTIMIZATION SCRIPT
-- ============================================================================
