-- =====================================================
-- CHECK PAYMENT SYNCHRONIZATION STATUS
-- Run this to diagnose why payments aren't showing
-- =====================================================

USE school_management_system;

-- 1. Check if payment was actually inserted
-- =====================================================
SELECT '========== RECENT PAYMENTS CHECK ==========' as '';

SELECT 
    'Last 10 Payments in Database' as check_name,
    COUNT(*) as total_count
FROM payments;

SELECT 
    p.payment_id,
    p.student_id,
    p.amount,
    p.payment_method,
    p.payment_date,
    p.status,
    p.created_at,
    s.admission_number,
    CONCAT(u.first_name, ' ', u.last_name) as student_name
FROM payments p
LEFT JOIN students s ON p.student_id = s.student_id
LEFT JOIN users u ON s.user_id = u.user_id
ORDER BY p.created_at DESC
LIMIT 10;

-- 2. Check payments table structure
-- =====================================================
SELECT '========== PAYMENTS TABLE STRUCTURE ==========' as '';
SHOW COLUMNS FROM payments;

-- 3. Check if student_fees table exists
-- =====================================================
SELECT '========== STUDENT FEES TABLE CHECK ==========' as '';

SELECT 
    CASE 
        WHEN COUNT(*) > 0 THEN '✅ student_fees table exists'
        ELSE '❌ student_fees table NOT FOUND - Run SAFE_FIX_PAYMENTS_SYNC.sql'
    END as status
FROM information_schema.tables 
WHERE table_schema = 'school_management_system' 
AND table_name = 'student_fees';

-- Show student_fees data if exists
SELECT * FROM student_fees LIMIT 10;

-- 4. Check if triggers exist
-- =====================================================
SELECT '========== TRIGGERS CHECK ==========' as '';

SHOW TRIGGERS WHERE `Table` = 'payments';

-- 5. Check for orphaned payments
-- =====================================================
SELECT '========== ORPHANED PAYMENTS CHECK ==========' as '';

SELECT 
    'Payments for Non-Existent Students' as check_name,
    COUNT(*) as orphaned_count,
    COALESCE(SUM(amount), 0) as orphaned_amount
FROM payments p
LEFT JOIN students s ON p.student_id = s.student_id
WHERE s.student_id IS NULL;

-- Show orphaned payments if any
SELECT 
    p.payment_id,
    p.student_id as 'student_id_not_found',
    p.amount,
    p.payment_date,
    p.status
FROM payments p
LEFT JOIN students s ON p.student_id = s.student_id
WHERE s.student_id IS NULL
LIMIT 10;

-- 6. Check payment status distribution
-- =====================================================
SELECT '========== PAYMENT STATUS BREAKDOWN ==========' as '';

SELECT 
    status,
    COUNT(*) as count,
    SUM(amount) as total_amount
FROM payments
GROUP BY status;

-- 7. Check if payment_type column exists
-- =====================================================
SELECT '========== PAYMENT_TYPE COLUMN CHECK ==========' as '';

SELECT 
    CASE 
        WHEN COUNT(*) > 0 THEN '✅ payment_type column exists'
        ELSE '❌ payment_type column missing - Need to add it'
    END as status
FROM information_schema.columns
WHERE table_schema = 'school_management_system'
AND table_name = 'payments'
AND column_name = 'payment_type';

-- 8. Verify student-payment relationship
-- =====================================================
SELECT '========== STUDENT-PAYMENT RELATIONSHIP ==========' as '';

SELECT 
    s.student_id,
    s.admission_number,
    CONCAT(u.first_name, ' ', u.last_name) as student_name,
    COUNT(p.payment_id) as payment_count,
    COALESCE(SUM(p.amount), 0) as total_paid
FROM students s
LEFT JOIN users u ON s.user_id = u.user_id
LEFT JOIN payments p ON s.student_id = p.student_id AND p.status IN ('paid', 'completed')
WHERE s.status = 'active'
GROUP BY s.student_id
ORDER BY payment_count DESC
LIMIT 10;

-- 9. Check today's payments
-- =====================================================
SELECT '========== TODAY\'S PAYMENTS ==========' as '';

SELECT 
    p.payment_id,
    s.admission_number,
    CONCAT(u.first_name, ' ', u.last_name) as student_name,
    p.amount,
    p.payment_method,
    p.status,
    p.created_at
FROM payments p
LEFT JOIN students s ON p.student_id = s.student_id
LEFT JOIN users u ON s.user_id = u.user_id
WHERE DATE(p.created_at) = CURDATE()
ORDER BY p.created_at DESC;

-- 10. Summary and recommendations
-- =====================================================
SELECT '========== DIAGNOSIS SUMMARY ==========' as '';

SELECT 
    'Total Payments' as metric,
    COUNT(*) as value
FROM payments
UNION ALL
SELECT 
    'Paid/Completed Payments',
    COUNT(*)
FROM payments
WHERE status IN ('paid', 'completed')
UNION ALL
SELECT 
    'Pending Payments',
    COUNT(*)
FROM payments
WHERE status = 'pending'
UNION ALL
SELECT 
    'Orphaned Payments',
    COUNT(*)
FROM payments p
LEFT JOIN students s ON p.student_id = s.student_id
WHERE s.student_id IS NULL
UNION ALL
SELECT 
    'Active Students',
    COUNT(*)
FROM students
WHERE status = 'active';

SELECT '=========================================' as '';
SELECT 'RECOMMENDATIONS:' as '';
SELECT '1. If student_fees table missing → Run SAFE_FIX_PAYMENTS_SYNC.sql' as action;
SELECT '2. If triggers missing → Run SAFE_FIX_PAYMENTS_SYNC.sql' as action;
SELECT '3. If orphaned payments found → They won\'t show in Student Payments' as action;
SELECT '4. If payment status is pending → Change to paid or completed' as action;
SELECT '5. If payment exists but not showing → Clear browser cache (Ctrl+Shift+Delete)' as action;
