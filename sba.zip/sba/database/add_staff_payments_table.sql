-- Add staff_payments table for teacher/staff canteen and transport fees
CREATE TABLE IF NOT EXISTS staff_payments (
    payment_id INT PRIMARY KEY AUTO_INCREMENT,
    school_id INT NOT NULL,
    user_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_type ENUM('canteen', 'transport', 'other') NOT NULL,
    payment_method ENUM('cash', 'bank_transfer', 'card') NOT NULL,
    payment_reference VARCHAR(100),
    payment_date DATE NOT NULL,
    status ENUM('pending', 'paid', 'failed') DEFAULT 'paid',
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);
