-- ============================================================================
-- UPDATE MISSING TOTAL SCORES, GRADES, AND REMARKS
-- This script calculates and updates all student assessments where
-- total_score is 0, NULL, or missing
-- ============================================================================

-- IMPORTANT: This is a SAFE script - it only updates records with missing data
-- It does NOT delete or overwrite existing valid calculations

SET SQL_SAFE_UPDATES = 0;

-- ============================================================================
-- STEP 1: Preview what will be updated
-- ============================================================================

SELECT 
    'PREVIEW: Records that will be updated' as action,
    COUNT(*) as total_records
FROM student_assessments
WHERE (total_score = 0 OR total_score IS NULL)
AND (ca_score > 0 OR midterm_score > 0 OR exam_score > 0);

-- Show sample records
SELECT 
    student_id,
    subject_id,
    ca_score,
    midterm_score,
    exam_score,
    total_score as current_total,
    grade as current_grade,
    remark as current_remark,
    ((COALESCE(ca_score, 0) + COALESCE(midterm_score, 0)) * 0.5 + COALESCE(exam_score, 0) * 0.5) as calculated_total
FROM student_assessments
WHERE (total_score = 0 OR total_score IS NULL)
AND (ca_score > 0 OR midterm_score > 0 OR exam_score > 0)
LIMIT 10;

-- ============================================================================
-- STEP 2: Update all missing total scores
-- ============================================================================

-- Calculate total_score using formula: [(CA + Mid-Term) × 0.5] + [Exam × 0.5]
UPDATE student_assessments
SET total_score = (
    (COALESCE(ca_score, 0) + COALESCE(midterm_score, 0)) * 0.5 + 
    COALESCE(exam_score, 0) * 0.5
)
WHERE (total_score = 0 OR total_score IS NULL)
AND (ca_score > 0 OR midterm_score > 0 OR exam_score > 0);

SELECT 'Total scores updated' as status, ROW_COUNT() as records_updated;

-- ============================================================================
-- STEP 3: Update grades based on total scores
-- ============================================================================

-- Ghana Education Service Grading Scale:
-- 90-100 = HP (Highly Proficient)
-- 80-89  = P  (Proficient)
-- 70-79  = P+ (Proficient Plus)
-- 55-69  = AP (Approaching Proficiency)
-- 40-54  = D  (Developing)
-- 0-39   = E  (Emerging)

UPDATE student_assessments
SET grade = CASE
    WHEN total_score >= 90 THEN 'HP'
    WHEN total_score >= 80 THEN 'P'
    WHEN total_score >= 70 THEN 'P+'
    WHEN total_score >= 55 THEN 'AP'
    WHEN total_score >= 40 THEN 'D'
    ELSE 'E'
END
WHERE (grade IS NULL OR grade = '')
AND total_score IS NOT NULL;

SELECT 'Grades updated' as status, ROW_COUNT() as records_updated;

-- ============================================================================
-- STEP 4: Update remarks based on grades
-- ============================================================================

UPDATE student_assessments
SET remark = CASE
    WHEN grade = 'HP' THEN 'Highly Proficient'
    WHEN grade = 'P' THEN 'Proficient'
    WHEN grade = 'P+' THEN 'Proficient Plus'
    WHEN grade = 'AP' THEN 'Approaching Proficiency'
    WHEN grade = 'D' THEN 'Developing'
    WHEN grade = 'E' THEN 'Emerging'
    ELSE 'No Remark'
END
WHERE (remark IS NULL OR remark = '')
AND grade IS NOT NULL;

SELECT 'Remarks updated' as status, ROW_COUNT() as records_updated;

-- ============================================================================
-- STEP 5: Verification - Check results
-- ============================================================================

-- Count records with complete data
SELECT 
    'VERIFICATION: Complete records' as status,
    COUNT(*) as total_records,
    COUNT(total_score) as has_total,
    COUNT(grade) as has_grade,
    COUNT(remark) as has_remark
FROM student_assessments
WHERE (ca_score > 0 OR midterm_score > 0 OR exam_score > 0);

-- Show sample of updated records
SELECT 
    student_id,
    subject_id,
    ca_score,
    midterm_score,
    exam_score,
    total_score,
    grade,
    remark
FROM student_assessments
WHERE total_score > 0
ORDER BY student_id, subject_id
LIMIT 20;

-- ============================================================================
-- STEP 6: Statistics
-- ============================================================================

SELECT 
    'STATISTICS: Grade Distribution' as report,
    grade,
    COUNT(*) as count,
    ROUND(AVG(total_score), 2) as avg_score,
    MIN(total_score) as min_score,
    MAX(total_score) as max_score
FROM student_assessments
WHERE total_score IS NOT NULL
GROUP BY grade
ORDER BY 
    CASE grade
        WHEN 'HP' THEN 1
        WHEN 'P' THEN 2
        WHEN 'P+' THEN 3
        WHEN 'AP' THEN 4
        WHEN 'D' THEN 5
        WHEN 'E' THEN 6
        ELSE 7
    END;

-- ============================================================================
-- COMPLETION MESSAGE
-- ============================================================================

SELECT 
    'UPDATE COMPLETE' as status,
    'All missing total scores, grades, and remarks have been calculated and updated' as message,
    NOW() as timestamp;

SET SQL_SAFE_UPDATES = 1;

-- ============================================================================
-- NOTES
-- ============================================================================
-- 1. This script is SAFE - it only updates missing data
-- 2. Existing valid calculations are NOT changed
-- 3. Formula used: [(CA + Mid-Term) × 0.5] + [Exam × 0.5]
-- 4. Grading scale: Ghana Education Service standards
-- 5. Run this script anytime you need to recalculate missing totals
-- 
-- TO RUN THIS SCRIPT:
-- 1. Open phpMyAdmin
-- 2. Select your database
-- 3. Go to SQL tab
-- 4. Copy and paste this entire script
-- 5. Click "Go" button
-- 6. Check the results in each step
-- ============================================================================
