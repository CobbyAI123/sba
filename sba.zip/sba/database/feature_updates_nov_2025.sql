-- ============================================
-- FEATURE UPDATES - November 2025
-- School Management System
-- ============================================
-- IMPORTANT: Backup your database before running this script!
-- ============================================

USE school_management_system;

-- 1. Add results_published column to terms table
ALTER TABLE terms 
ADD COLUMN IF NOT EXISTS results_published TINYINT(1) DEFAULT 0 COMMENT 'Whether results are visible to students/parents' AFTER is_active;

-- 2. Add class_teacher_id to classes table
ALTER TABLE classes 
ADD COLUMN IF NOT EXISTS class_teacher_id INT(11) DEFAULT NULL COMMENT 'Teacher assigned as class teacher' AFTER capacity;

ALTER TABLE classes
ADD KEY IF NOT EXISTS idx_class_teacher (class_teacher_id);

-- 3. Add temp_password column to users table (for showing credentials to admin)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS temp_password VARCHAR(255) DEFAULT NULL COMMENT 'Temporary password for display purposes' AFTER password_hash;

-- 4. Create student_results_view table for hierarchical results display
CREATE TABLE IF NOT EXISTS student_results_view (
    view_id INT(11) NOT NULL AUTO_INCREMENT,
    student_id INT(11) NOT NULL,
    term_id INT(11) NOT NULL,
    session_year VARCHAR(20) NOT NULL,
    term_name VARCHAR(50) NOT NULL,
    total_subjects INT(11) DEFAULT 0,
    average_score DECIMAL(5,2) DEFAULT 0,
    position INT(11) DEFAULT NULL,
    class_position INT(11) DEFAULT NULL,
    published TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (view_id),
    UNIQUE KEY unique_student_term (student_id, term_id),
    KEY idx_student_term (student_id, term_id),
    KEY idx_session (session_year),
    KEY idx_published (published)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 5. Create assignment_files table for multiple file uploads
CREATE TABLE IF NOT EXISTS assignment_files (
    file_id INT(11) NOT NULL AUTO_INCREMENT,
    assignment_id INT(11) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    file_size INT(11) NOT NULL,
    uploaded_by INT(11) NOT NULL,
    upload_type ENUM('teacher', 'student') DEFAULT 'teacher',
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (file_id),
    KEY idx_assignment (assignment_id),
    KEY idx_uploaded_by (uploaded_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 6. Update assessments table to include new grading fields
ALTER TABLE student_assessments
ADD COLUMN IF NOT EXISTS total_score DECIMAL(5,2) DEFAULT 0 COMMENT 'Calculated total score' AFTER exam_score,
ADD COLUMN IF NOT EXISTS grade VARCHAR(5) DEFAULT NULL COMMENT 'Grade (HP, P, AP, D, E)' AFTER total_score,
ADD COLUMN IF NOT EXISTS remark VARCHAR(50) DEFAULT NULL COMMENT 'Grade remark' AFTER grade;

-- 7. Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_students_class ON students(class_id, status);
CREATE INDEX IF NOT EXISTS idx_assessments_student_subject ON student_assessments(student_id, subject_id, term_id);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date, class_id);

-- 8. Update existing data - Calculate total scores for existing assessments
UPDATE student_assessments 
SET total_score = ROUND(((COALESCE(ca_score, 0) + COALESCE(midterm_score, 0)) * 0.5) + (COALESCE(exam_score, 0) * 0.5), 2)
WHERE total_score = 0 OR total_score IS NULL;

-- 9. Update grades based on new grading system
UPDATE student_assessments 
SET 
    grade = CASE 
        WHEN total_score >= 80 THEN 'HP'
        WHEN total_score >= 68 THEN 'P'
        WHEN total_score >= 53 THEN 'AP'
        WHEN total_score >= 40 THEN 'D'
        ELSE 'E'
    END,
    remark = CASE 
        WHEN total_score >= 80 THEN 'Highly Proficient'
        WHEN total_score >= 68 THEN 'Proficient'
        WHEN total_score >= 53 THEN 'Approaching Proficient'
        WHEN total_score >= 40 THEN 'Developing'
        ELSE 'Emerging'
    END
WHERE grade IS NULL OR grade = '';

-- 10. Create view for easy results access
CREATE OR REPLACE VIEW vw_student_results AS
SELECT 
    s.student_id,
    s.admission_number,
    u.first_name,
    u.last_name,
    c.class_name,
    t.term_name,
    t.session_year,
    t.results_published,
    sub.subject_name,
    sub.subject_code,
    sa.ca_score,
    sa.midterm_score,
    sa.exam_score,
    sa.total_score,
    sa.grade,
    sa.remark,
    sa.created_at
FROM students s
INNER JOIN users u ON s.user_id = u.user_id
INNER JOIN classes c ON s.class_id = c.class_id
INNER JOIN student_assessments sa ON s.student_id = sa.student_id
INNER JOIN subjects sub ON sa.subject_id = sub.subject_id
INNER JOIN terms t ON sa.term_id = t.term_id
WHERE s.status = 'active';

-- Success message
SELECT 'Database schema updated successfully! All tables and columns created.' as Status;
SELECT 'Please verify the changes in your database.' as Note;
