-- Add session_year column to terms table
-- Run this SQL in phpMyAdmin or MySQL client to fix the error

-- Add the session_year column if it doesn't exist
ALTER TABLE `terms` 
ADD COLUMN IF NOT EXISTS `session_year` VARCHAR(20) NOT NULL DEFAULT '2024/2025' AFTER `term_name`;

-- Add index for better performance
ALTER TABLE `terms` 
ADD INDEX IF NOT EXISTS `idx_session` (`session_year`);

-- Update any existing records to have a default session year
UPDATE `terms` 
SET `session_year` = '2024/2025' 
WHERE `session_year` = '' OR `session_year` IS NULL;
