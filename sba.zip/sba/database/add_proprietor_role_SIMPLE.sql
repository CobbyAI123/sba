-- Simple Proprietor Role Setup
-- This only updates the users table - NO new tables needed!

-- STEP 1: Make sure you're in the correct database
-- In phpMyAdmin: Click your database name in left sidebar FIRST
-- OR uncomment the line below and replace with your database name:
-- USE your_database_name_here;

-- STEP 2: Add 'proprietor' to the role options (includes super_admin!)
ALTER TABLE users 
MODIFY COLUMN role ENUM('super_admin', 'admin', 'teacher', 'student', 'parent', 'accountant', 'librarian', 'bookstore', 'proprietor') NOT NULL;

-- That's it! No other tables needed.
-- Now you can add proprietors like you add teachers.

-- Verify it worked:
SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'users' AND COLUMN_NAME = 'role';

-- You should see 'proprietor' in the list of roles
