# 🔧 Database Import Troubleshooting Guide

Quick solutions to common database import issues.

---

## 🚨 Common Errors & Solutions

### 1. "Access denied for user"

**Error Message:**
```
ERROR 1045 (28000): Access denied for user 'username'@'localhost'
```

**Solutions:**

**A. Check username and password:**
```bash
mysql -u username -p
# Enter password when prompted
```

**B. Grant privileges:**
```sql
GRANT ALL PRIVILEGES ON school_management_system.* TO 'username'@'localhost';
FLUSH PRIVILEGES;
```

**C. Create new user:**
```sql
CREATE USER 'school_user'@'localhost' IDENTIFIED BY 'strong_password';
GRANT ALL PRIVILEGES ON school_management_system.* TO 'school_user'@'localhost';
FLUSH PRIVILEGES;
```

---

### 2. "Database does not exist"

**Error Message:**
```
ERROR 1049 (42000): Unknown database 'school_management_system'
```

**Solution:**
```sql
CREATE DATABASE school_management_system 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_general_ci;
```

---

### 3. "Foreign key constraint fails"

**Error Message:**
```
ERROR 1215 (HY000): Cannot add foreign key constraint
```

**Solution:**

**This schema prevents this!** But if you still get errors:

```sql
-- Disable foreign key checks
SET FOREIGN_KEY_CHECKS=0;

-- Import your SQL file
SOURCE /path/to/LIVE_SERVER_COMPLETE_SCHEMA.sql;

-- Re-enable checks
SET FOREIGN_KEY_CHECKS=1;
```

---

### 4. "Packet too large"

**Error Message:**
```
ERROR 2006 (HY000): MySQL server has gone away
ERROR 1153 (08S01): Got a packet bigger than 'max_allowed_packet' bytes
```

**Solutions:**

**A. Temporary fix (Session):**
```sql
SET GLOBAL max_allowed_packet=67108864; -- 64MB
```

**B. Permanent fix (my.ini / my.cnf):**
```ini
[mysqld]
max_allowed_packet=64M
```

**Location of config file:**
- Windows: `C:\xampp\mysql\bin\my.ini`
- Linux: `/etc/mysql/my.cnf`
- Mac: `/usr/local/etc/my.cnf`

**C. Restart MySQL after editing:**
```bash
# Linux
sudo systemctl restart mysql

# Windows (XAMPP)
Stop and start MySQL from XAMPP Control Panel

# Mac
brew services restart mysql
```

---

### 5. "Table already exists"

**Error Message:**
```
ERROR 1050 (42S01): Table 'users' already exists
```

**This is SAFE!** The schema uses `CREATE TABLE IF NOT EXISTS`

**To start fresh:**
```sql
DROP DATABASE school_management_system;
CREATE DATABASE school_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
-- Then import again
```

---

### 6. "Import timeout" (phpMyAdmin)

**Error Message:**
```
Script timeout passed, if you want to finish import, please resubmit same file...
```

**Solutions:**

**A. Use command line instead:**
```bash
mysql -u username -p school_management_system < LIVE_SERVER_COMPLETE_SCHEMA.sql
```

**B. Increase PHP timeout (php.ini):**
```ini
max_execution_time = 600
max_input_time = 600
upload_max_filesize = 64M
post_max_size = 64M
```

**C. Increase phpMyAdmin timeout (config.inc.php):**
```php
$cfg['ExecTimeLimit'] = 600;
```

---

### 7. "Unknown column in students table"

**Error Message:**
```
ERROR 1054 (42S22): Unknown column 'fee_exemption' in 'students'
```

**Cause:** You have an old database schema

**Solution:**

**Option 1 - Fresh import:**
```sql
DROP DATABASE school_management_system;
CREATE DATABASE school_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
-- Import LIVE_SERVER_COMPLETE_SCHEMA.sql
```

**Option 2 - Add missing columns manually:**
```sql
ALTER TABLE students 
ADD COLUMN fee_exemption JSON DEFAULT NULL,
ADD COLUMN exemption_reason TEXT DEFAULT NULL,
ADD COLUMN middle_name VARCHAR(100) NULL,
ADD COLUMN hometown VARCHAR(100) NULL;
```

---

### 8. "Duplicate entry for key"

**Error Message:**
```
ERROR 1062 (23000): Duplicate entry '1' for key 'PRIMARY'
```

**Cause:** Table already has data

**Solutions:**

**A. Drop and recreate:**
```sql
DROP DATABASE school_management_system;
CREATE DATABASE school_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
-- Import schema
```

**B. Clear specific table:**
```sql
TRUNCATE TABLE table_name;
```

**C. Use REPLACE instead of INSERT:**
The schema uses `ON DUPLICATE KEY UPDATE` where appropriate

---

### 9. "Command line access denied"

**Windows XAMPP:**
```bash
cd C:\xampp\mysql\bin
mysql.exe -u root -p
```

**Linux:**
```bash
sudo mysql -u root -p
```

**Mac (Homebrew):**
```bash
/usr/local/mysql/bin/mysql -u root -p
```

---

### 10. "Character set mismatch"

**Error Message:**
```
ERROR 1253 (42000): COLLATION 'utf8mb4_general_ci' is not valid for CHARACTER SET 'latin1'
```

**Solution:**
```sql
ALTER DATABASE school_management_system 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_general_ci;
```

---

## 🔍 Diagnostic Commands

### Check Database Connection
```bash
mysql -u username -p -e "SELECT VERSION();"
```

### Check Database Exists
```bash
mysql -u username -p -e "SHOW DATABASES LIKE 'school_management_system';"
```

### Check Table Count
```sql
USE school_management_system;
SELECT COUNT(*) as total_tables 
FROM information_schema.tables 
WHERE table_schema = 'school_management_system';
```

### Check Table Structure
```sql
DESCRIBE table_name;
SHOW CREATE TABLE table_name;
```

### Check Foreign Keys
```sql
SELECT 
    TABLE_NAME,
    COLUMN_NAME,
    CONSTRAINT_NAME,
    REFERENCED_TABLE_NAME,
    REFERENCED_COLUMN_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = 'school_management_system';
```

### Check Indexes
```sql
SHOW INDEX FROM table_name;
```

### Check Character Set
```sql
SELECT DEFAULT_CHARACTER_SET_NAME, DEFAULT_COLLATION_NAME
FROM information_schema.SCHEMATA
WHERE SCHEMA_NAME = 'school_management_system';
```

### Check Database Size
```sql
SELECT 
    table_schema AS 'Database',
    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Size (MB)'
FROM information_schema.tables
WHERE table_schema = 'school_management_system'
GROUP BY table_schema;
```

---

## 🚑 Emergency Recovery

### Complete Fresh Start

```sql
-- 1. Drop existing database
DROP DATABASE IF EXISTS school_management_system;

-- 2. Create new database
CREATE DATABASE school_management_system 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_general_ci;

-- 3. Select database
USE school_management_system;

-- 4. Import schema
SOURCE /path/to/LIVE_SERVER_COMPLETE_SCHEMA.sql;

-- 5. Verify
SHOW TABLES;
```

### Via Command Line (One-liner)

```bash
mysql -u root -p -e "DROP DATABASE IF EXISTS school_management_system; CREATE DATABASE school_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;" && mysql -u root -p school_management_system < LIVE_SERVER_COMPLETE_SCHEMA.sql
```

---

## 🔐 Permission Issues

### Grant All Privileges
```sql
GRANT ALL PRIVILEGES ON school_management_system.* TO 'username'@'localhost';
FLUSH PRIVILEGES;
```

### Grant Specific Privileges
```sql
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER 
ON school_management_system.* 
TO 'username'@'localhost';
FLUSH PRIVILEGES;
```

### Check User Privileges
```sql
SHOW GRANTS FOR 'username'@'localhost';
```

### Create Super User
```sql
CREATE USER 'admin'@'localhost' IDENTIFIED BY 'strong_password';
GRANT ALL PRIVILEGES ON *.* TO 'admin'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;
```

---

## 🌐 Remote Database Issues

### Allow Remote Access
```sql
CREATE USER 'username'@'%' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON school_management_system.* TO 'username'@'%';
FLUSH PRIVILEGES;
```

### Bind Address (my.cnf)
```ini
[mysqld]
bind-address = 0.0.0.0  # Allow all IPs
```

### Firewall Rules (Linux)
```bash
sudo ufw allow 3306/tcp
```

---

## 📱 cPanel/Shared Hosting

### Database Name Prefix Issue

If your host adds prefix (e.g., `cpanel_school_management_system`):

**Update config.php:**
```php
define('DB_NAME', 'cpanel_school_management_system');
```

### Import via cPanel File Manager

1. Upload SQL file to `/tmp/`
2. Use phpMyAdmin import
3. Or use MySQL Database Wizard

### Import Size Limit

If file too large:
- Compress: `gzip LIVE_SERVER_COMPLETE_SCHEMA.sql`
- Upload: `LIVE_SERVER_COMPLETE_SCHEMA.sql.gz`
- phpMyAdmin can import .gz files directly

---

## 🔄 Verification After Fix

Run the verification script:
```bash
php database/verify-database-import.php
```

Or manually check:
```sql
-- Should return 50+
SELECT COUNT(*) FROM information_schema.tables 
WHERE table_schema = 'school_management_system';

-- Should return 7
SELECT COUNT(*) FROM email_templates;

-- Should show all tables
SHOW TABLES;
```

---

## 📞 Still Having Issues?

### 1. Enable Error Reporting
```php
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
```

### 2. Check MySQL Error Log

**Linux:**
```bash
sudo tail -f /var/log/mysql/error.log
```

**Windows XAMPP:**
```
C:\xampp\mysql\data\mysql_error.log
```

### 3. Check PHP Error Log
```
C:\xampp\php\logs\php_error_log  # Windows
/var/log/php/error.log           # Linux
```

### 4. Test Connection
```php
<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=school_management_system', 'username', 'password');
    echo "✅ Connected!";
} catch(PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>
```

---

## 💡 Best Practices

1. **Always backup before import**
   ```bash
   mysqldump -u root -p school_management_system > backup_before_import.sql
   ```

2. **Test on local first**
   - Import on localhost
   - Verify everything works
   - Then import on live server

3. **Check server requirements**
   - MySQL 5.7+ or MariaDB 10.3+
   - PHP 7.4+
   - InnoDB support enabled

4. **Monitor import progress**
   - Watch for errors in real-time
   - Check MySQL process list: `SHOW PROCESSLIST;`

5. **Verify after import**
   - Run verification script
   - Test database connection
   - Check critical tables exist

---

## ✅ Quick Checklist

- [ ] Database credentials correct
- [ ] Database exists
- [ ] User has privileges
- [ ] Character set is utf8mb4
- [ ] max_allowed_packet is 64M+
- [ ] PHP timeout is 600s+
- [ ] Foreign key checks handled
- [ ] No old data conflicts
- [ ] Import completed successfully
- [ ] Verification script passed
- [ ] config.php updated
- [ ] Test login works

---

**Need more help?** Check `LIVE_SERVER_IMPORT_GUIDE.md` for detailed instructions.
