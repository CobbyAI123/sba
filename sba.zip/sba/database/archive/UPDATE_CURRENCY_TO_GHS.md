# Update Currency from INR (₹) to GHS Across System

## Overview
This guide helps you replace all Indian Rupee (₹/INR) references with Ghana Cedis (GHS/₵) throughout the school management system.

---

## ✅ Already Updated

### 1. **config.php** - Core Currency Function
The `format_currency()` function already defaults to GHS:
```php
function format_currency(float $amount, string $currency = 'GHS'): string {
    $symbols = [
        'GHS' => '₵',  // Ghana Cedis
        'NGN' => '₦',  // Nigerian Naira
        'USD' => '$',
        'GBP' => '£',
        'EUR' => '€'
    ];
    
    $symbol = $symbols[$currency] ?? $currency;
    return $symbol . number_format($amount, 2);
}
```

**Usage**: `<?php echo format_currency($amount); ?>` will output: **₵1,234.56**

### 2. **all-transactions.php** - Updated ✅
- Summary statistics now show "GHS"
- Transaction amounts show "GHS"

---

## 🔄 Files That Need Manual Update

Use Find & Replace (Ctrl+H) in your code editor:

### **Find:** `₹`
### **Replace:** `GHS `

### Files to Update:

#### Accountant Module:
1. ✅ `accountant/all-transactions.php` - DONE
2. `accountant/all-schools.php`
3. `accountant/daily-collection.php`
4. `accountant/financial-reports.php`

#### Admin Module:
5. `admin/collect-fee.php`
6. `admin/fee-payments.php`
7. `admin/manage-fees.php`

---

## 📝 Recommended Approach

### Option 1: Use format_currency() Function (BEST PRACTICE)

**Instead of:**
```php
₹<?php echo number_format($amount, 2); ?>
```

**Use:**
```php
<?php echo format_currency($amount); ?>
```

**Benefits:**
- ✅ Centralized currency management
- ✅ Easy to change currency system-wide
- ✅ Consistent formatting
- ✅ Already configured for GHS

---

### Option 2: Direct Replacement

If you prefer hardcoded display:

**Find:**
```php
₹<?php echo number_format($amount, 2); ?>
```

**Replace with:**
```php
GHS <?php echo number_format($amount, 2); ?>
```

**OR use Ghana Cedis symbol (₵):**
```php
₵<?php echo number_format($amount, 2); ?>
```

---

## 🎯 Quick Fix Commands

### PowerShell (Windows)
```powershell
# Navigate to project root
cd C:\xampp\htdocs\msms

# Find all files with ₹ symbol
Get-ChildItem -Recurse -Include *.php | Select-String -Pattern "₹"

# Replace in specific file
(Get-Content accountant/all-schools.php) -replace '₹', 'GHS ' | Set-Content accountant/all-schools.php
```

### Linux/Mac
```bash
# Find all files
grep -r "₹" *.php

# Replace in specific file
sed -i 's/₹/GHS /g' accountant/all-schools.php
```

---

## 📋 Manual Update Checklist

- [x] `config.php` - format_currency() function (Already GHS)
- [x] `accountant/all-transactions.php` (Updated)
- [ ] `accountant/all-schools.php`
- [ ] `accountant/daily-collection.php`  
- [ ] `accountant/financial-reports.php`
- [ ] `admin/collect-fee.php`
- [ ] `admin/fee-payments.php`
- [ ] `admin/manage-fees.php`

---

## 🔍 Verification

After updates, search for any remaining ₹:

### VS Code / Notepad++:
1. Press `Ctrl + Shift + F` (Find in Files)
2. Search for: `₹`
3. Search in: `*.php`
4. Should return 0 results ✅

### Check Display:
1. Login as Accountant
2. Check **Online Transactions** page
3. Verify currency shows "GHS" not "₹"
4. Check Dashboard statistics
5. Verify all amounts show GHS

---

## 💡 Best Practice Going Forward

**Always use:**
```php
<?php echo format_currency($amount); ?>
```

**Instead of:**
```php
₹<?php echo number_format($amount, 2); ?>
```

This ensures:
- ✅ Consistent currency across system
- ✅ Easy global currency changes
- ✅ Proper formatting
- ✅ Support for multiple currencies

---

## 🌍 Multi-Currency Support

The system already supports multiple currencies in `format_currency()`:

```php
// Ghana Cedis (default)
echo format_currency(1000);  // ₵1,000.00

// Nigerian Naira
echo format_currency(1000, 'NGN');  // ₦1,000.00

// US Dollar
echo format_currency(1000, 'USD');  // $1,000.00
```

---

## 📊 Summary

### Current Status:
- ✅ Core function uses GHS by default
- ✅ `all-transactions.php` updated to GHS
- ⚠️ ~20 other files still use ₹ hardcoded

### Recommendation:
1. Replace all `₹` with `format_currency()` calls
2. Or replace `₹` with `GHS ` as temporary fix
3. Test all financial pages
4. Verify reports show correct currency

---

## 🎉 Final Result

After all updates, your system will display:
- **GHS 1,234.56** (with text)
- **₵1,234.56** (with symbol, if using format_currency)

Ghana Cedis throughout! 🇬🇭
