# 🚀 Live Server Database Import Guide

**MSMS - School Management System**  
**Version:** 3.0.0  
**Date:** December 2025

---

## 📋 Table of Contents

1. [Pre-Import Checklist](#pre-import-checklist)
2. [Import Methods](#import-methods)
3. [Step-by-Step Instructions](#step-by-step-instructions)
4. [Verification](#verification)
5. [Troubleshooting](#troubleshooting)
6. [Post-Import Configuration](#post-import-configuration)

---

## ✅ Pre-Import Checklist

### Before You Start

- [ ] **Backup existing database** (if any)
- [ ] **Verify database credentials** (username, password, host)
- [ ] **Check MySQL version** (Recommended: MySQL 5.7+ or MariaDB 10.3+)
- [ ] **Ensure sufficient disk space** (Minimum 500MB free)
- [ ] **Download the schema file:** `LIVE_SERVER_COMPLETE_SCHEMA.sql`
- [ ] **Close all applications** using the database

### Database Requirements

```
MySQL Version: 5.7 or higher
Character Set: utf8mb4
Collation: utf8mb4_general_ci
Max Packet Size: 64MB (recommended)
```

---

## 🔧 Import Methods

### Method 1: phpMyAdmin (Recommended - Easiest)

**Best for:** Most users, visual interface, no command line needed

### Method 2: MySQL Command Line

**Best for:** Advanced users, large databases, server access

### Method 3: cPanel Database Import

**Best for:** Shared hosting environments

---

## 📖 Step-by-Step Instructions

## Method 1: phpMyAdmin Import

### Step 1: Access phpMyAdmin

```
URL: https://yourdomain.com/phpmyadmin
OR
URL: https://yourdomain.com:2083/cpsess000000000/3rdparty/phpMyAdmin/
```

**Login with your database credentials**

### Step 2: Create Database (If Not Exists)

1. Click **"New"** in left sidebar
2. Database name: `school_management_system` (or your preferred name)
3. Collation: Select **`utf8mb4_general_ci`**
4. Click **"Create"**

![Create Database](https://via.placeholder.com/600x200/1a56db/ffffff?text=Create+Database)

### Step 3: Select Database

1. Click on your database name in the left sidebar
2. Ensure it's highlighted/selected

### Step 4: Import SQL File

1. Click **"Import"** tab at the top
2. Click **"Choose File"** button
3. Navigate to: `database/LIVE_SERVER_COMPLETE_SCHEMA.sql`
4. **Format:** Should auto-detect as SQL
5. **Character set:** `utf8mb4`
6. **Partial import:** Leave unchecked
7. Click **"Go"** button at the bottom

![Import Process](https://via.placeholder.com/600x300/28a745/ffffff?text=Click+Import+%3E+Choose+File+%3E+Go)

### Step 5: Wait for Completion

```
⏱️ Expected time: 1-3 minutes
📊 You'll see progress indicator
✅ Success message: "Import has been successfully finished"
```

### Step 6: Verify Tables

1. Click **"Structure"** tab
2. You should see **50+ tables** listed
3. Check that all tables show **"InnoDB"** engine

---

## Method 2: MySQL Command Line

### For Linux/Mac:

```bash
# Navigate to database folder
cd /path/to/msms/database

# Login and create database
mysql -u username -p -e "CREATE DATABASE IF NOT EXISTS school_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"

# Import schema
mysql -u username -p school_management_system < LIVE_SERVER_COMPLETE_SCHEMA.sql

# Verify import
mysql -u username -p school_management_system -e "SHOW TABLES;"
```

### For Windows:

```bash
# Open Command Prompt
cd C:\path\to\msms\database

# Create database
mysql -u username -p -e "CREATE DATABASE IF NOT EXISTS school_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"

# Import schema
mysql -u username -p school_management_system < LIVE_SERVER_COMPLETE_SCHEMA.sql

# Verify
mysql -u username -p school_management_system -e "SHOW TABLES;"
```

### Common MySQL Locations:

```bash
# cPanel/WHM
mysql -h localhost -u username -p

# AWS RDS
mysql -h your-rds-endpoint.amazonaws.com -u username -p

# DigitalOcean
mysql -h your-droplet-ip -u username -p
```

---

## Method 3: cPanel Import

### Step 1: Access cPanel

```
URL: https://yourdomain.com/cpanel
```

### Step 2: MySQL Databases

1. Find **"Databases"** section
2. Click **"MySQL Databases"**

### Step 3: Create Database

1. Under **"Create New Database"**
2. Database Name: `school_management_system`
3. Click **"Create Database"**

### Step 4: Create User (If Needed)

1. Under **"Add New User"**
2. Username: `school_user` (example)
3. Password: **Strong password**
4. Click **"Create User"**

### Step 5: Add User to Database

1. Under **"Add User to Database"**
2. Select: User and Database
3. Click **"Add"**
4. Grant **ALL PRIVILEGES**
5. Click **"Make Changes"**

### Step 6: Import via phpMyAdmin

1. Return to cPanel home
2. Click **"phpMyAdmin"** under Databases
3. Follow **Method 1** steps above

---

## ✅ Verification

### 1. Check Table Count

**Via phpMyAdmin:**
```sql
SELECT COUNT(*) as total_tables 
FROM information_schema.tables 
WHERE table_schema = 'school_management_system';
```

**Expected Result:** `50 or more tables`

### 2. Verify Key Tables

```sql
SHOW TABLES;
```

**Must-Have Tables:**
- ✅ schools
- ✅ users
- ✅ students
- ✅ teachers
- ✅ classes
- ✅ subjects
- ✅ attendance
- ✅ exams
- ✅ marks
- ✅ payments
- ✅ email_templates
- ✅ notifications

### 3. Check Email Templates

```sql
SELECT COUNT(*) FROM email_templates;
```

**Expected Result:** `7 templates`

### 4. Verify Foreign Keys

```sql
SELECT 
    COUNT(*) as foreign_keys
FROM 
    information_schema.KEY_COLUMN_USAGE 
WHERE 
    REFERENCED_TABLE_SCHEMA = 'school_management_system' 
    AND REFERENCED_TABLE_NAME IS NOT NULL;
```

**Expected Result:** `30+ foreign keys`

### 5. Test Database Connection

**Create test file:** `test_db_connection.php`

```php
<?php
$host = 'localhost';
$user = 'your_username';
$pass = 'your_password';
$db = 'school_management_system';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Count tables
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "✅ Database Connected Successfully!\n";
    echo "📊 Total Tables: " . count($tables) . "\n";
    echo "📧 Email Templates: " . $pdo->query("SELECT COUNT(*) FROM email_templates")->fetchColumn() . "\n";
    
} catch(PDOException $e) {
    echo "❌ Connection Failed: " . $e->getMessage();
}
?>
```

**Run:** `php test_db_connection.php`

---

## 🔧 Troubleshooting

### Issue 1: "Database does not exist"

**Solution:**
```sql
CREATE DATABASE school_management_system 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_general_ci;
```

### Issue 2: "Access denied for user"

**Solutions:**
1. Verify username and password
2. Check user has privileges:
```sql
GRANT ALL PRIVILEGES ON school_management_system.* TO 'username'@'localhost';
FLUSH PRIVILEGES;
```

### Issue 3: "Foreign key constraint fails"

**This schema handles this automatically!**

The file uses:
```sql
SET FOREIGN_KEY_CHECKS=0;  -- Disable checks
-- Create all tables
SET FOREIGN_KEY_CHECKS=1;  -- Re-enable
```

If you still get errors:
```sql
SET FOREIGN_KEY_CHECKS=0;
-- Import file
SET FOREIGN_KEY_CHECKS=1;
```

### Issue 4: "Packet too large"

**Solution - Update MySQL settings:**

**Via my.cnf / my.ini:**
```ini
[mysqld]
max_allowed_packet=64M
```

**Via phpMyAdmin:**
1. Variables tab
2. Find `max_allowed_packet`
3. Edit to `67108864` (64MB)

**Via SQL:**
```sql
SET GLOBAL max_allowed_packet=67108864;
```

### Issue 5: "Table already exists"

**This is SAFE!**

The schema uses: `CREATE TABLE IF NOT EXISTS`

Tables won't be duplicated. To start fresh:
```sql
DROP DATABASE school_management_system;
CREATE DATABASE school_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
-- Then import again
```

### Issue 6: "Unknown column in students table"

**Solution - Re-import the complete schema:**

This happens if you have an old database. The new schema includes all columns:
- `middle_name`
- `hometown`
- `fee_exemption`
- `exemption_reason`
- etc.

### Issue 7: Import Timeout

**Solutions:**

**A. Increase PHP timeout (php.ini):**
```ini
max_execution_time = 600
max_input_time = 600
```

**B. Import via command line instead**

**C. Split import (not recommended for this schema)**

---

## ⚙️ Post-Import Configuration

### 1. Update config.php

**File:** `c:\xampp\htdocs\msms\config.php`

```php
// Update database credentials
define('DB_HOST', 'localhost');  // Or your host
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_NAME', 'school_management_system');
```

### 2. Update .env File (If Using)

**File:** `c:\xampp\htdocs\msms\.env`

```env
DB_HOST=localhost
DB_USER=your_username
DB_PASS=your_password
DB_NAME=school_management_system
APP_ENV=production
APP_URL=https://yourdomain.com
```

### 3. Create Super Admin Account

**Via phpMyAdmin or SQL:**

```sql
-- Insert super admin user
INSERT INTO users (school_id, username, password_hash, email, first_name, last_name, role, status) 
VALUES (
    NULL, 
    'superadmin', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password: password
    'admin@yourschool.com',
    'Super',
    'Admin',
    'super_admin',
    'active'
);
```

**⚠️ IMPORTANT:** Change this password immediately after first login!

### 4. Test Login

```
URL: https://yourdomain.com/login.php
Username: superadmin
Password: password
```

### 5. Set Up SMTP (Email)

**Navigate to:** Admin → Settings → Email Settings

```
SMTP Host: smtp.gmail.com
SMTP Port: 587
Encryption: TLS
Username: your-email@gmail.com
Password: your-app-password
```

### 6. Configure School

**Navigate to:** Admin → School Settings

- Upload school logo
- Set school name, address
- Configure academic year/terms
- Set fee structure

### 7. Set Up Cron Jobs (Optional)

**Auto-backup cron:**
```bash
0 2 * * * php /path/to/msms/cron/auto-backup.php
```

**Email queue processing:**
```bash
*/5 * * * * php /path/to/msms/cron/process-email-queue.php
```

---

## 🎯 Quick Checklist After Import

- [ ] Database created successfully
- [ ] 50+ tables imported
- [ ] 7 email templates exist
- [ ] Foreign keys created
- [ ] config.php updated
- [ ] .env file configured (if using)
- [ ] Super admin account created
- [ ] Login tested successfully
- [ ] School settings configured
- [ ] Email settings configured
- [ ] Backup created
- [ ] Cron jobs set up (optional)

---

## 📊 What's Included in This Schema

### Core Tables (14)
- schools
- users
- login_attempts
- password_resets
- classes
- subjects
- class_subjects
- academic_years
- terms
- students
- parents
- student_parents
- teachers
- teacher_classes

### Academic Tables (5)
- attendance
- attendance_summary
- exams
- marks
- marks_performance

### Financial Tables (6)
- fee_categories
- fee_structure
- student_fees
- payments
- transactions
- expenses

### Library Tables (2)
- library_books
- library_issues

### Communication Tables (2)
- messages
- notifications

### Email System (4)
- email_queue
- email_templates
- email_logs
- email_settings

### System Tables (11)
- api_tokens
- api_logs
- error_logs
- system_logs
- bulk_operations_log
- search_history
- saved_reports
- backup_logs
- dashboard_widgets
- transcripts
- system_settings
- announcements

**Total:** 50+ tables

---

## 🔐 Security Notes

### 1. Change Default Passwords

```sql
-- Update super admin password
UPDATE users 
SET password_hash = PASSWORD('your_strong_password') 
WHERE username = 'superadmin';
```

### 2. Secure Database User

- Use strong passwords
- Grant minimal privileges
- Restrict to localhost if possible

### 3. Backup Regularly

```bash
# Daily backup
mysqldump -u username -p school_management_system > backup_$(date +%Y%m%d).sql
```

### 4. Enable SSL (Production)

```php
// In config.php
$pdo = new PDO(
    "mysql:host=$host;dbname=$db",
    $user,
    $pass,
    array(
        PDO::MYSQL_ATTR_SSL_CA => '/path/to/ca.pem'
    )
);
```

---

## 📞 Support & Help

### Common Issues

| Issue | Solution |
|-------|----------|
| Import timeout | Use command line or increase PHP timeout |
| Foreign key error | Schema handles this - re-import if needed |
| Connection refused | Check DB credentials and permissions |
| Table exists | Safe to ignore or drop DB and reimport |
| Missing columns | Import complete schema file |

### Useful Commands

```sql
-- Show all tables
SHOW TABLES;

-- Check table structure
DESCRIBE table_name;

-- Count records in table
SELECT COUNT(*) FROM table_name;

-- Show database size
SELECT 
    table_schema AS 'Database',
    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Size (MB)'
FROM information_schema.tables
WHERE table_schema = 'school_management_system'
GROUP BY table_schema;
```

---

## ✨ Next Steps

After successful import:

1. ✅ **Login** to the system
2. ✅ **Configure** school information
3. ✅ **Set up** academic terms
4. ✅ **Create** classes and subjects
5. ✅ **Add** teachers
6. ✅ **Enroll** students
7. ✅ **Configure** fee structure
8. ✅ **Test** all modules
9. ✅ **Train** administrators
10. ✅ **Go live!** 🚀

---

## 📄 Files Reference

| File | Purpose |
|------|---------|
| `LIVE_SERVER_COMPLETE_SCHEMA.sql` | Main database schema |
| `config.php` | Database configuration |
| `.env` | Environment variables |
| `test_db_connection.php` | Test script |

---

## 🎉 Success!

If you see this message in phpMyAdmin:

```
✅ Import has been successfully finished
   X queries executed
   X rows affected
```

**Congratulations!** Your database is ready for production! 🎊

---

**Document Version:** 1.0  
**Last Updated:** December 2025  
**Schema Version:** 3.0.0

---

**Need Help?** Check the troubleshooting section or review the main documentation files.
