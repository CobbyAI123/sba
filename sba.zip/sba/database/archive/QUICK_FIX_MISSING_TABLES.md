# ⚡ Quick Fix: Missing Database Tables

**Problem:** Getting error "Table 'school_management_system.teachers' doesn't exist"

**Cause:** The main `schema.sql` file wasn't imported, or the database is missing core tables.

---

## 🔧 Quick Fix (2 minutes)

### Option 1: Run Fix SQL Script (Easiest)

1. Open **phpMyAdmin**: `http://localhost/phpmyadmin`
2. Select database: `school_management_system`
3. Click **SQL** tab
4. Open file: `database/FIX_MISSING_CORE_TABLES.sql`
5. Copy entire content
6. Paste into SQL box
7. Click **Execute** ✅

**This creates:**
- ✅ Schools table
- ✅ Users table  
- ✅ Teachers table
- ✅ Students table
- ✅ Classes table
- ✅ Attendance table
- ✅ Exams table
- ✅ Results table
- ✅ Fees table
- ✅ Payments table
- ✅ Expenses table
- ✅ Default admin user (superadmin/password)

---

### Option 2: Using MySQL Command Line

```bash
cd c:\xampp\htdocs\msms\database

# Run the fix script
mysql -u root -p school_management_system < FIX_MISSING_CORE_TABLES.sql
```

---

### Option 3: Import schema.sql Properly

1. Delete current database:
   ```sql
   DROP DATABASE school_management_system;
   CREATE DATABASE school_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
   ```

2. Import **in this exact order**:
   - ✅ schema.sql (first - contains core tables)
   - ✅ api_tables.sql
   - ✅ error_logging_tables.sql
   - ✅ search_tables.sql
   - ✅ bulk_operations_tables.sql
   - ✅ email_tables.sql
   - ✅ backup_dashboard_language_tables.sql
   - ✅ FIX_EMAIL_TEMPLATES_SCHEMA.sql

---

## ✅ Verify It Worked

After running the fix, you should see:

```
✓ Schools: 1
✓ Users: 1
✓ Teachers: 1
✓ Students: 1
✓ Classes: 1
✓ Attendance: 1
✓ Exams: 1
✓ Results: 1
✓ Fees: 1
✓ Payments: 1
✓ Expenses: 1

✓ All core tables created successfully!
```

---

## 🧪 Test It

Run this query to verify:

```sql
SELECT 'Teachers Table' as Table_Name, COUNT(*) as Row_Count FROM teachers LIMIT 0, 25
```

**Should return:** `Teachers Table | 0` (empty but exists!)

---

## 🎯 What Gets Created

### Tables with Data:
- `schools` - 1 default school (ID: 1)
- `users` - 1 admin user (superadmin/password)

### Empty Tables Ready for Data:
- `classes` - Add your class levels
- `teachers` - Add your teachers
- `students` - Add your students
- `attendance` - Track attendance
- `exams` - Create exams
- `results` - Record results
- `fees` - Set fee amounts
- `payments` - Track payments
- `expenses` - Track expenses

---

## 🔑 Default Login

After fix, you can login with:

```
Username: superadmin
Password: password
```

⚠️ **CHANGE THIS IMMEDIATELY after login!**

---

## 🚀 Next Steps

1. ✅ Run the fix script
2. ✅ Verify tables exist
3. ✅ Test login
4. ✅ Verify dashboards work
5. ✅ Add your school data

---

## 💡 Why This Happened

Most likely causes:
1. `schema.sql` wasn't imported first
2. Database was reset but tables weren't recreated
3. Partial import (only newer files imported)

**The fix imports all core tables in one go!**

---

## 📞 Still Having Issues?

1. **Check database exists:**
   ```sql
   SHOW DATABASES;
   ```

2. **Check tables:**
   ```sql
   USE school_management_system;
   SHOW TABLES;
   ```

3. **Check specific table:**
   ```sql
   DESCRIBE teachers;
   ```

4. **See all errors:**
   - Check phpMyAdmin error message at bottom
   - Copy exact error
   - Google the error code

---

## ✨ Summary

| Step | Time | Action |
|------|------|--------|
| 1 | 1 min | Open phpMyAdmin |
| 2 | 1 min | Copy FIX_MISSING_CORE_TABLES.sql |
| 3 | 1 sec | Execute script |
| **Total** | **~3 min** | **All tables created!** |

**That's it! Your database is fixed!** ✅

---

**File:** `database/FIX_MISSING_CORE_TABLES.sql`  
**Lines:** 255  
**Creates:** 11 core tables + default data  
**Status:** Ready to use!
