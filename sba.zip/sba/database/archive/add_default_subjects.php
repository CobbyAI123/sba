<?php
// database/add_default_subjects.php - Add Default Subjects to All Schools
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

// Check if user is logged in as admin or super_admin
$current_user = check_permission(['admin', 'super_admin']);

$db = Database::getInstance()->getConnection();

// Get school_id
if ($current_user['role'] == 'super_admin') {
    // For super admin, ask which school or all schools
    $school_id = $_GET['school_id'] ?? 'all';
} else {
    $school_id = $current_user['school_id'];
}

// Default subjects list
$default_subjects = [
    // Primary/Basic School Subjects
    ['name' => 'English Language', 'code' => 'ENG'],
    ['name' => 'Mathematics', 'code' => 'MATH'],
    ['name' => 'Integrated Science', 'code' => 'SCI'],
    ['name' => 'Religious and Moral Education', 'code' => 'RME'],
    ['name' => 'Creative Arts', 'code' => 'CART'],
    ['name' => 'History', 'code' => 'HIST'],
    ['name' => 'Physical Education', 'code' => 'PE'],
    ['name' => 'Ghanaian Language', 'code' => 'GHLANG'],
    ['name' => 'French', 'code' => 'FRENCH'],
    ['name' => 'Social Studies', 'code' => 'SOCST'],
    ['name' => 'Computing', 'code' => 'COMP'],
    ['name' => 'Career Technology', 'code' => 'CARTECH'],
    
    // Early Childhood/KG Subjects
    ['name' => 'Literacy', 'code' => 'LIT'],
    ['name' => 'Numeracy', 'code' => 'NUM'],
    ['name' => 'Coloring', 'code' => 'COLOR'],
    ['name' => 'Phonics', 'code' => 'PHON'],
    ['name' => 'Writing', 'code' => 'WRITE'],
    ['name' => 'Our World Our People', 'code' => 'OWOP'],
    
    // Secondary School Subjects
    ['name' => 'UC Mathematics', 'code' => 'UCMATH']
];

$success_count = 0;
$skip_count = 0;
$error_count = 0;
$results = [];

try {
    // Get list of schools to process
    if ($school_id == 'all' && $current_user['role'] == 'super_admin') {
        $stmt = $db->prepare("SELECT school_id, school_name FROM schools WHERE status = 'active'");
        $stmt->execute();
        $schools = $stmt->fetchAll();
    } else {
        $stmt = $db->prepare("SELECT school_id, school_name FROM schools WHERE school_id = ?");
        $stmt->execute([$school_id]);
        $schools = $stmt->fetchAll();
    }
    
    foreach ($schools as $school) {
        $results[$school['school_name']] = [
            'added' => [],
            'skipped' => [],
            'errors' => []
        ];
        
        foreach ($default_subjects as $subject) {
            try {
                // Check if subject already exists for this school
                $stmt = $db->prepare("
                    SELECT subject_id 
                    FROM subjects 
                    WHERE school_id = ? AND subject_name = ?
                ");
                $stmt->execute([$school['school_id'], $subject['name']]);
                
                if ($stmt->fetch()) {
                    // Subject exists, skip
                    $skip_count++;
                    $results[$school['school_name']]['skipped'][] = $subject['name'];
                    continue;
                }
                
                // Add the subject
                $stmt = $db->prepare("
                    INSERT INTO subjects (school_id, subject_name, subject_code, status)
                    VALUES (?, ?, ?, 'active')
                ");
                $stmt->execute([$school['school_id'], $subject['name'], $subject['code']]);
                
                $success_count++;
                $results[$school['school_name']]['added'][] = $subject['name'];
                
            } catch (PDOException $e) {
                $error_count++;
                $results[$school['school_name']]['errors'][] = $subject['name'] . ': ' . $e->getMessage();
            }
        }
    }
    
} catch (PDOException $e) {
    echo "<h2>Error: " . $e->getMessage() . "</h2>";
    exit;
}

// Display results
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Default Subjects - Result</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 40px 20px;
            min-height: 100vh;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 {
            color: #667eea;
            margin-bottom: 30px;
            text-align: center;
            font-size: 32px;
        }
        .summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        .stat-box {
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            color: white;
        }
        .stat-box.success { background: linear-gradient(135deg, #11998e, #38ef7d); }
        .stat-box.skip { background: linear-gradient(135deg, #f093fb, #f5576c); }
        .stat-box.error { background: linear-gradient(135deg, #fa709a, #fee140); }
        .stat-box h2 { font-size: 48px; margin-bottom: 10px; }
        .stat-box p { font-size: 14px; opacity: 0.9; }
        .school-section {
            margin-bottom: 30px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            padding: 20px;
        }
        .school-section h3 {
            color: #667eea;
            margin-bottom: 15px;
            font-size: 20px;
        }
        .subject-list {
            list-style: none;
            padding: 0;
        }
        .subject-list li {
            padding: 8px 12px;
            margin-bottom: 5px;
            border-radius: 6px;
            font-size: 14px;
        }
        .subject-list.added li { background: #d4edda; color: #155724; }
        .subject-list.skipped li { background: #fff3cd; color: #856404; }
        .subject-list.errors li { background: #f8d7da; color: #721c24; }
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            margin-top: 20px;
            text-align: center;
        }
        .btn:hover { opacity: 0.9; }
    </style>
</head>
<body>
    <div class="container">
        <h1>✅ Default Subjects Import Complete</h1>
        
        <div class="summary">
            <div class="stat-box success">
                <h2><?php echo $success_count; ?></h2>
                <p>Added</p>
            </div>
            <div class="stat-box skip">
                <h2><?php echo $skip_count; ?></h2>
                <p>Skipped (Already Exists)</p>
            </div>
            <div class="stat-box error">
                <h2><?php echo $error_count; ?></h2>
                <p>Errors</p>
            </div>
        </div>
        
        <?php foreach ($results as $school_name => $result): ?>
            <div class="school-section">
                <h3>🏫 <?php echo htmlspecialchars($school_name); ?></h3>
                
                <?php if (count($result['added']) > 0): ?>
                    <h4 style="color: #28a745; margin-top: 15px;">✅ Added (<?php echo count($result['added']); ?>)</h4>
                    <ul class="subject-list added">
                        <?php foreach ($result['added'] as $subj): ?>
                            <li>✓ <?php echo htmlspecialchars($subj); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                
                <?php if (count($result['skipped']) > 0): ?>
                    <h4 style="color: #ffc107; margin-top: 15px;">⊘ Skipped (<?php echo count($result['skipped']); ?>)</h4>
                    <ul class="subject-list skipped">
                        <?php foreach ($result['skipped'] as $subj): ?>
                            <li>⊘ <?php echo htmlspecialchars($subj); ?> (already exists)</li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                
                <?php if (count($result['errors']) > 0): ?>
                    <h4 style="color: #dc3545; margin-top: 15px;">❌ Errors (<?php echo count($result['errors']); ?>)</h4>
                    <ul class="subject-list errors">
                        <?php foreach ($result['errors'] as $err): ?>
                            <li>❌ <?php echo htmlspecialchars($err); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        
        <div style="text-align: center;">
            <a href="<?php echo APP_URL; ?>/admin/subjects.php" class="btn">
                ← Back to Subjects
            </a>
        </div>
    </div>
</body>
</html>
