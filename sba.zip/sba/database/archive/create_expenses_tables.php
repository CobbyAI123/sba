<?php
// Create expenses table - Run this once
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

header('Content-Type: text/html; charset=utf-8');

echo '<!DOCTYPE html>
<html>
<head>
    <title>Create Expenses Table</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 { color: #333; margin-top: 0; }
        .success { 
            color: #4CAF50; 
            padding: 15px;
            background: #E8F5E9;
            border-left: 4px solid #4CAF50;
            margin: 10px 0;
        }
        .error { 
            color: #f44336; 
            padding: 15px;
            background: #FFEBEE;
            border-left: 4px solid #f44336;
            margin: 10px 0;
        }
        .info {
            color: #2196F3;
            padding: 15px;
            background: #E3F2FD;
            border-left: 4px solid #2196F3;
            margin: 10px 0;
        }
        .step {
            padding: 10px;
            margin: 10px 0;
            background: #f9f9f9;
            border-left: 3px solid #667eea;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 10px 5px;
            font-weight: bold;
        }
        .btn:hover {
            opacity: 0.9;
        }
        pre {
            background: #f5f5f5;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>🔧 Create Expenses Management Tables</h2>
';

try {
    $db = Database::getInstance()->getConnection();
    
    echo '<div class="step">Step 1: Creating expenses table...</div>';
    
    // Create expenses table
    $sql = "CREATE TABLE IF NOT EXISTS `expenses` (
      `expense_id` INT(11) NOT NULL AUTO_INCREMENT,
      `school_id` INT(11) NOT NULL,
      `expense_type` VARCHAR(100) NOT NULL COMMENT 'Staff Salary, Utilities, Maintenance, Supplies, Transport, Other',
      `description` TEXT NULL COMMENT 'Detailed description of the expense',
      `amount` DECIMAL(10,2) NOT NULL,
      `expense_date` DATE NOT NULL,
      `payment_method` ENUM('cash', 'bank_transfer', 'cheque', 'card', 'other') DEFAULT 'cash',
      `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
      `vendor_name` VARCHAR(255) NULL COMMENT 'Supplier or service provider name',
      `invoice_number` VARCHAR(100) NULL COMMENT 'Invoice or receipt reference',
      `recorded_by` INT(11) NULL COMMENT 'User who recorded the expense',
      `approved_by` INT(11) NULL COMMENT 'User who approved the expense',
      `approved_at` TIMESTAMP NULL,
      `remarks` TEXT NULL,
      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (`expense_id`),
      KEY `idx_school` (`school_id`),
      KEY `idx_expense_type` (`expense_type`),
      KEY `idx_status` (`status`),
      KEY `idx_expense_date` (`expense_date`),
      KEY `idx_recorded_by` (`recorded_by`),
      KEY `idx_approved_by` (`approved_by`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='School expenses and expenditures tracking'";
    
    $db->exec($sql);
    echo '<div class="success">✅ expenses table created successfully!</div>';
    
    echo '<div class="step">Step 2: Creating expense_categories table...</div>';
    
    // Create expense_categories table
    $sql = "CREATE TABLE IF NOT EXISTS `expense_categories` (
      `category_id` INT(11) NOT NULL AUTO_INCREMENT,
      `school_id` INT(11) NOT NULL,
      `category_name` VARCHAR(100) NOT NULL,
      `description` TEXT NULL,
      `is_active` TINYINT(1) DEFAULT 1,
      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (`category_id`),
      KEY `idx_school` (`school_id`),
      UNIQUE KEY `unique_category` (`school_id`, `category_name`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Expense categories for each school'";
    
    $db->exec($sql);
    echo '<div class="success">✅ expense_categories table created successfully!</div>';
    
    echo '<div class="step">Step 3: Adding default expense categories...</div>';
    
    // Get all schools
    $stmt = $db->query("SELECT school_id FROM schools");
    $schools = $stmt->fetchAll();
    
    $categories = [
        ['Staff Salary', 'Salaries and wages for all staff members'],
        ['Utilities', 'Electricity, water, internet, phone bills'],
        ['Maintenance', 'Building repairs, equipment servicing'],
        ['Supplies', 'Office supplies, cleaning materials, stationery'],
        ['Transport', 'Vehicle fuel, maintenance, school bus expenses'],
        ['Food & Catering', 'Canteen supplies, student meals, events'],
        ['Insurance', 'Building insurance, liability insurance'],
        ['Other', 'Miscellaneous expenses not in other categories']
    ];
    
    $inserted = 0;
    foreach ($schools as $school) {
        foreach ($categories as $category) {
            try {
                $stmt = $db->prepare("INSERT INTO expense_categories (school_id, category_name, description) VALUES (?, ?, ?)");
                $stmt->execute([$school['school_id'], $category[0], $category[1]]);
                $inserted++;
            } catch (PDOException $e) {
                // Category already exists for this school
                if ($e->getCode() != 23000) { // Not a duplicate error
                    throw $e;
                }
            }
        }
    }
    
    echo '<div class="success">✅ Added ' . $inserted . ' default expense categories!</div>';
    
    // Verify tables
    echo '<div class="step">Step 4: Verifying tables...</div>';
    
    $stmt = $db->query("DESCRIBE expenses");
    $columns = $stmt->fetchAll();
    
    echo '<div class="info">';
    echo '<strong>expenses table columns (' . count($columns) . '):</strong><br>';
    foreach ($columns as $col) {
        echo '• ' . $col['Field'] . ' (' . $col['Type'] . ')<br>';
    }
    echo '</div>';
    
    $stmt = $db->query("SELECT COUNT(*) as count FROM expense_categories");
    $count = $stmt->fetch()['count'];
    
    echo '<div class="info">';
    echo '<strong>Total expense categories:</strong> ' . $count;
    echo '</div>';
    
    echo '<div class="success" style="margin-top: 30px; font-size: 18px; text-align: center;">';
    echo '🎉 <strong>ALL TABLES CREATED SUCCESSFULLY!</strong><br><br>';
    echo 'You can now use the Expenses Management feature!';
    echo '</div>';
    
    echo '<div style="text-align: center; margin-top: 30px;">';
    echo '<a href="' . APP_URL . '/accountant/expenses.php" class="btn">📊 Go to Expenses Management</a>';
    echo '<a href="' . APP_URL . '/accountant/dashboard.php" class="btn">🏠 Go to Dashboard</a>';
    echo '</div>';
    
    echo '<div class="info" style="margin-top: 30px;">';
    echo '<strong>What you can do now:</strong><br>';
    echo '1. Record school expenses (utilities, salaries, maintenance, etc.)<br>';
    echo '2. Track expense categories<br>';
    echo '3. Approve/reject expenses<br>';
    echo '4. Generate expense reports<br>';
    echo '5. Monitor spending vs revenue';
    echo '</div>';
    
} catch (PDOException $e) {
    echo '<div class="error">';
    echo '<strong>❌ Error:</strong> ' . $e->getMessage() . '<br>';
    echo '<strong>Code:</strong> ' . $e->getCode();
    echo '</div>';
    
    echo '<div class="info" style="margin-top: 20px;">';
    echo '<strong>Troubleshooting:</strong><br>';
    echo '1. Make sure your database connection is working<br>';
    echo '2. Check if you have CREATE TABLE permissions<br>';
    echo '3. Verify the database name in config.php<br>';
    echo '4. Try running the SQL manually in phpMyAdmin';
    echo '</div>';
}

echo '
    </div>
</body>
</html>';
?>
