# 🔧 Database Schema Troubleshooting Guide

**Problem:** Getting errors like "Unknown column 'password'" or "Table doesn't exist"

**Cause:** Database tables are incomplete or missing columns

---

## 🚨 Common Errors & Fixes

### Error 1: "Unknown column 'password'"

**Problem:**
```
#1054 - Unknown column 'password' in 'field list'
```

**Solution:**

Run this script:
```
database/FIX_USERS_TABLE_SCHEMA.sql
```

**Steps:**
1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Select `school_management_system` database
3. Click **SQL** tab
4. Copy content from `FIX_USERS_TABLE_SCHEMA.sql`
5. Paste and **Execute**

✅ **What it does:**
- Adds missing `password` column
- Adds `profile_picture`, `phone`, `address` columns
- Creates default admin user
- Verifies the fix

---

### Error 2: "Table doesn't exist"

**Problem:**
```
#1146 - Table 'school_management_system.teachers' doesn't exist
```

**Solution:**

Run this script:
```
database/FIX_MISSING_CORE_TABLES.sql
```

**Steps:**
1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Select `school_management_system` database
3. Click **SQL** tab
4. Copy content from `FIX_MISSING_CORE_TABLES.sql`
5. Paste and **Execute**

✅ **What it does:**
- Creates all 11 core tables
- Adds default school and admin
- Verifies all tables exist

---

## 🔍 Diagnose Your Database

### Step 1: Check What Tables Exist

Run this query:
```sql
SHOW TABLES;
```

**Expected output (at minimum):**
```
schools
users
teachers
students
classes
attendance
exams
results
fees
payments
expenses
api_tokens
api_logs
audit_logs
error_logs
system_logs
saved_searches
search_history
search_filters
bulk_operations_log
bulk_operations_queue
transcripts
email_queue
email_templates
email_logs
email_settings
backup_logs
restore_logs
dashboard_widgets
saved_reports
report_exports
language_settings
translation_strings
user_language_preferences
```

### Step 2: Check Users Table Structure

Run this query:
```sql
DESCRIBE users;
```

**Expected columns:**
```
user_id              INT (Primary Key)
school_id            INT
first_name           VARCHAR(100)
last_name            VARCHAR(100)
email                VARCHAR(255)
username             VARCHAR(100)
password             VARCHAR(255)  ← Should exist!
role                 ENUM
status               ENUM
profile_picture      VARCHAR(255)
phone                VARCHAR(20)
address              TEXT
created_at           TIMESTAMP
updated_at           TIMESTAMP
```

### Step 3: Check Admin User Exists

Run this query:
```sql
SELECT * FROM users WHERE username = 'superadmin';
```

**Expected output:**
```
user_id: 1
username: superadmin
password: 5f4dcc3b5aa765d61d8327deb882cf99 (MD5 of 'password')
role: super_admin
status: active
```

---

## 🛠️ Complete Recovery Steps

### If You Have NO Tables at All

**Do this:**

1. Go to phpMyAdmin
2. Select database `school_management_system`
3. Delete the database:
   ```sql
   DROP DATABASE school_management_system;
   CREATE DATABASE school_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
   ```

4. Import SQL files **IN THIS ORDER**:
   - schema.sql (most important - has all core tables)
   - api_tables.sql
   - error_logging_tables.sql
   - search_tables.sql
   - bulk_operations_tables.sql
   - email_tables.sql
   - backup_dashboard_language_tables.sql
   - FIX_EMAIL_TEMPLATES_SCHEMA.sql
   - FIX_USERS_TABLE_SCHEMA.sql (if needed)
   - VERIFY_ALL_TABLES.sql

5. Test login with: superadmin/password

---

### If You Have SOME Tables but They're Incomplete

**Do this:**

1. Run: `FIX_MISSING_CORE_TABLES.sql`
2. Run: `FIX_USERS_TABLE_SCHEMA.sql`
3. Run: `FIX_EMAIL_TEMPLATES_SCHEMA.sql`
4. Run: `VERIFY_ALL_TABLES.sql`

---

### If You Have All Tables but Can't Login

**Check:**

1. Does the `superadmin` user exist?
   ```sql
   SELECT * FROM users WHERE username = 'superadmin';
   ```

2. If not, insert it:
   ```sql
   INSERT IGNORE INTO `users` 
   (user_id, school_id, first_name, last_name, email, username, password, role, status)
   VALUES (1, 1, 'Super', 'Admin', 'admin@school.com', 'superadmin', MD5('password'), 'super_admin', 'active');
   ```

3. Try login again

---

## 📊 Database Status Quick Check

Run all these queries to get a full picture:

```sql
-- Check how many tables exist
SELECT COUNT(*) as total_tables FROM information_schema.tables 
WHERE table_schema = 'school_management_system';

-- List all tables
SHOW TABLES;

-- Check core tables
SELECT 'Schools' as table_name, COUNT(*) as rows FROM schools
UNION
SELECT 'Users', COUNT(*) FROM users
UNION
SELECT 'Teachers', COUNT(*) FROM teachers
UNION
SELECT 'Students', COUNT(*) FROM students
UNION
SELECT 'Classes', COUNT(*) FROM classes;

-- Check admin user
SELECT 'Admin user exists?' as check_result, COUNT(*) as count FROM users WHERE username = 'superadmin';

-- Check school
SELECT 'Default school exists?' as check_result, COUNT(*) as count FROM schools WHERE school_id = 1;
```

---

## 🎯 What Each Fix Script Does

### FIX_MISSING_CORE_TABLES.sql
```
✓ Creates schools table
✓ Creates users table  
✓ Creates teachers table
✓ Creates students table
✓ Creates classes table
✓ Creates attendance table
✓ Creates exams table
✓ Creates results table
✓ Creates fees table
✓ Creates payments table
✓ Creates expenses table
✓ Inserts default school (ID: 1)
✓ Inserts admin user (superadmin/password)
```

### FIX_USERS_TABLE_SCHEMA.sql
```
✓ Adds missing password column to users
✓ Adds profile_picture column
✓ Adds phone column
✓ Adds address column
✓ Adds updated_at timestamp
✓ Inserts/updates admin user
```

### FIX_EMAIL_TEMPLATES_SCHEMA.sql
```
✓ Adds description column to email_templates
✓ Inserts 7 default email templates
✓ Creates school entry if missing
```

### VERIFY_ALL_TABLES.sql
```
✓ Checks all 50+ tables exist
✓ Shows row counts
✓ Lists all templates
✓ Confirms setup success
```

---

## 💡 Prevention Tips

### Always Import in This Order:
1. **schema.sql** - Core tables (MUST be first!)
2. api_tables.sql
3. error_logging_tables.sql
4. search_tables.sql
5. bulk_operations_tables.sql
6. email_tables.sql
7. backup_dashboard_language_tables.sql
8. Fix scripts (FIX_*.sql)
9. Verification scripts

### After Each Import:
- Check for errors at the bottom of phpMyAdmin
- Run a quick count: `SHOW TABLES;`
- Don't proceed until previous file imported successfully

### Backup Before Changes:
```bash
# Backup your database
mysqldump -u root -p school_management_system > backup.sql

# If something goes wrong, restore:
mysql -u root -p school_management_system < backup.sql
```

---

## 🚨 Emergency Recovery

If everything is broken:

### Option 1: Fresh Start (5 minutes)
```sql
-- Drop everything and restart
DROP DATABASE school_management_system;
CREATE DATABASE school_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
```

Then import **schema.sql** first, then all others in order.

### Option 2: Selective Fix (2 minutes)
```sql
-- Just run the specific fix for what's broken
-- FIX_MISSING_CORE_TABLES.sql for missing tables
-- FIX_USERS_TABLE_SCHEMA.sql for missing columns
```

### Option 3: Restore from Backup (1 minute)
```bash
mysql -u root -p school_management_system < backup.sql
```

---

## 📞 Still Not Working?

### Debug Checklist:

1. ✅ MySQL service is running
   ```bash
   # Check MySQL is running
   mysql -u root -p -e "SELECT VERSION();"
   ```

2. ✅ Database exists
   ```sql
   SHOW DATABASES;
   ```

3. ✅ Database is selected
   ```sql
   USE school_management_system;
   SELECT DATABASE();  -- Should show: school_management_system
   ```

4. ✅ Table exists
   ```sql
   SHOW TABLES LIKE 'users';
   ```

5. ✅ Column exists
   ```sql
   DESCRIBE users;  -- Check password column is listed
   ```

6. ✅ User exists
   ```sql
   SELECT * FROM users WHERE username = 'superadmin';
   ```

### If still stuck:

1. Take a screenshot of the error
2. Run: `SHOW TABLES;`
3. Run: `DESCRIBE users;`
4. Check what tables are missing
5. Run the appropriate FIX script

---

## 🎯 Success Indicators

✅ **You're good when:**

1. All tables show up: `SHOW TABLES;`
2. Admin user exists:
   ```sql
   SELECT username, role FROM users WHERE username = 'superadmin';
   -- Should show: superadmin | super_admin
   ```

3. Can login to dashboard with: superadmin/password

4. Dashboard loads without errors

5. No red error messages in phpMyAdmin

---

## 📝 Summary

| Issue | File to Run | Time |
|-------|------------|------|
| Table doesn't exist | FIX_MISSING_CORE_TABLES.sql | 1 min |
| Password column missing | FIX_USERS_TABLE_SCHEMA.sql | 30 sec |
| Email templates missing | FIX_EMAIL_TEMPLATES_SCHEMA.sql | 30 sec |
| Verify everything | VERIFY_ALL_TABLES.sql | 1 min |
| Everything broken | Drop & reimport schema.sql | 5 min |

---

**Version:** 1.0  
**Created:** November 30, 2024  
**Status:** Ready to use
