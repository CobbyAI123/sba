# 🚀 QUICK START - Database Import (2 Minutes!)

## ⚡ FASTEST METHOD (phpMyAdmin)

### 1️⃣ Login to phpMyAdmin
```
URL: https://yourdomain.com/phpmyadmin
```

### 2️⃣ Create Database
```sql
CREATE DATABASE school_management_system 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_general_ci;
```
**OR** Click: New → Database Name → Create

### 3️⃣ Import File
1. Select database: `school_management_system`
2. Click: **Import** tab
3. Choose file: `LIVE_SERVER_COMPLETE_SCHEMA.sql`
4. Click: **Go**
5. Wait 1-3 minutes ⏱️

### 4️⃣ Verify
```sql
SHOW TABLES;  -- Should show 50+ tables
SELECT COUNT(*) FROM email_templates;  -- Should show 7
```

### 5️⃣ Update config.php
```php
define('DB_NAME', 'school_management_system');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_HOST', 'localhost');
```

### ✅ DONE!
```
Login: http://yourdomain.com/login.php
Username: superadmin
Password: password (Change this immediately!)
```

---

## 💻 COMMAND LINE METHOD

```bash
# Create database
mysql -u username -p -e "CREATE DATABASE school_management_system CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"

# Import schema
mysql -u username -p school_management_system < LIVE_SERVER_COMPLETE_SCHEMA.sql

# Verify
mysql -u username -p school_management_system -e "SHOW TABLES;"
```

---

## 🔧 Troubleshooting

### ❌ "Access denied"
```sql
GRANT ALL PRIVILEGES ON school_management_system.* TO 'username'@'localhost';
FLUSH PRIVILEGES;
```

### ❌ "Packet too large"
```sql
SET GLOBAL max_allowed_packet=67108864;
```

### ❌ "Import timeout"
- Use command line instead
- OR increase PHP timeout: `max_execution_time = 600`

### ❌ "Foreign key error"
**Don't worry!** The schema handles this automatically with:
```sql
SET FOREIGN_KEY_CHECKS=0;  -- At start
SET FOREIGN_KEY_CHECKS=1;  -- At end
```

---

## 📊 What Gets Created

| Category | Tables |
|----------|--------|
| Core System | 14 tables |
| Academic | 5 tables |
| Financial | 6 tables |
| Library | 2 tables |
| Communication | 6 tables |
| Logs & Reports | 11 tables |
| Email System | 4 tables |
| Advanced | 6 tables |
| **TOTAL** | **50+ tables** |

---

## ✨ Key Features

✅ **No Foreign Key Errors** - Proper dependency order  
✅ **No Duplications** - Uses `IF NOT EXISTS`  
✅ **Safe to Re-import** - Idempotent operations  
✅ **All Indexes Created** - Optimized performance  
✅ **Email Templates Included** - 7 default templates  
✅ **UTF8MB4 Support** - Full Unicode (emojis, etc.)  

---

## 🎯 Post-Import Checklist

- [ ] Tables imported (50+)
- [ ] Email templates exist (7)
- [ ] config.php updated
- [ ] Test login works
- [ ] Create first school
- [ ] Set up academic year/term
- [ ] Add first users
- [ ] Configure SMTP email
- [ ] Create backup
- [ ] **GO LIVE!** 🚀

---

## 📁 Important Files

```
database/
  ├── LIVE_SERVER_COMPLETE_SCHEMA.sql  ← Import this
  └── LIVE_SERVER_IMPORT_GUIDE.md       ← Full guide

config.php                               ← Update this
.env                                     ← Configure this
```

---

## 🆘 Need Help?

See: `LIVE_SERVER_IMPORT_GUIDE.md` for detailed instructions

---

**Schema Version:** 3.0.0  
**Total Tables:** 50+  
**Import Time:** 1-3 minutes  
**Safe for Production:** ✅ YES
