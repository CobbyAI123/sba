# Database Migration System

## Overview
This directory contains the database schema and migration files for the School Management System.

## Current Schema Version
**Version:** 1.9.0 (Last Updated: 2025-11-30)

## Important Files

### Core Schema
- `schema.sql` - **MAIN FILE** - Contains the current complete database schema

### Migration Archives
- `migrations/` - Contains all historical migration scripts organized by date
- `archive/` - Contains deprecated/redundant migration files

## How to Use

### Fresh Installation
```sql
-- Import the main schema
SOURCE schema.sql;
```

### Running Migrations
Migrations are applied in chronological order. Use a migration runner or apply manually:
```sql
SOURCE migrations/001_base_schema.sql;
SOURCE migrations/002_add_fee_structure.sql;
-- etc.
```

## Important Notes

1. **Do NOT** apply all files in this directory - many are duplicates or test files
2. Always backup your database before running migrations
3. Test migrations in development first
4. The `archive/` folder contains deprecated files - do not use these

## File Organization

- `schema.sql` - Complete current schema (Use this for fresh installs)
- `COMPLETE_DATABASE_IMPORT.sql` - Full database import with sample data
- `migrations/` - Individual migration scripts (organized by version)
- `archive/` - Deprecated/test migration files

## Troubleshooting

If you encounter foreign key errors:
```sql
SET FOREIGN_KEY_CHECKS=0;
-- Run your migration
SET FOREIGN_KEY_CHECKS=1;
```

If tables already exist:
```sql
DROP TABLE IF EXISTS table_name;
-- Then re-run migration
```
