<?php
/**
 * Create attendance_alerts table
 * Run this file once: http://localhost/msms/database/create_attendance_alerts.php
 */

require_once dirname(__DIR__) . '/config.php';

$db = Database::getInstance()->getConnection();

try {
    // Create attendance_alerts table
    $sql = "CREATE TABLE IF NOT EXISTS `attendance_alerts` (
      `alert_id` int(11) NOT NULL AUTO_INCREMENT,
      `school_id` int(11) NOT NULL,
      `student_id` int(11) NOT NULL,
      `alert_type` enum('warning','critical') NOT NULL DEFAULT 'warning',
      `alert_message` text NOT NULL,
      `attendance_percentage` decimal(5,2) DEFAULT NULL,
      `absent_days` int(11) DEFAULT 0,
      `late_days` int(11) DEFAULT 0,
      `is_resolved` tinyint(1) DEFAULT 0,
      `resolved_at` datetime DEFAULT NULL,
      `resolved_by` int(11) DEFAULT NULL,
      `resolution_notes` text DEFAULT NULL,
      `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (`alert_id`),
      KEY `school_id` (`school_id`),
      KEY `student_id` (`student_id`),
      KEY `is_resolved` (`is_resolved`),
      KEY `created_at` (`created_at`),
      CONSTRAINT `attendance_alerts_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE,
      CONSTRAINT `attendance_alerts_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
      CONSTRAINT `attendance_alerts_ibfk_3` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $db->exec($sql);
    echo "✅ Table 'attendance_alerts' created successfully!<br>";
    
    // Add indexes for better performance
    try {
        $db->exec("CREATE INDEX idx_alert_type ON attendance_alerts(alert_type)");
        echo "✅ Index 'idx_alert_type' created successfully!<br>";
    } catch (PDOException $e) {
        echo "⚠️  Index 'idx_alert_type' may already exist<br>";
    }
    
    try {
        $db->exec("CREATE INDEX idx_attendance_percentage ON attendance_alerts(attendance_percentage)");
        echo "✅ Index 'idx_attendance_percentage' created successfully!<br>";
    } catch (PDOException $e) {
        echo "⚠️  Index 'idx_attendance_percentage' may already exist<br>";
    }
    
    echo "<br><h2 style='color: green;'>✅ Success!</h2>";
    echo "<p>The attendance_alerts table has been created.</p>";
    echo "<p><a href='../admin/attendance-analytics.php'>Go to Attendance Analytics</a></p>";
    
} catch (PDOException $e) {
    echo "<h2 style='color: red;'>❌ Error</h2>";
    echo "<p>Error creating table: " . $e->getMessage() . "</p>";
    echo "<p>Error Code: " . $e->getCode() . "</p>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Attendance Alerts Table</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 { margin-top: 0; }
        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        a:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Create Attendance Alerts Table</h1>
        <hr>
        <?php // Results displayed above ?>
    </div>
</body>
</html>
