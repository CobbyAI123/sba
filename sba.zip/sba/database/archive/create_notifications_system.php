<?php
// Create Smart Notifications System - Run this once
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

header('Content-Type: text/html; charset=utf-8');

echo '<!DOCTYPE html>
<html>
<head>
    <title>Create Smart Notifications System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 { color: #333; margin-top: 0; }
        .success { 
            color: #4CAF50; 
            padding: 15px;
            background: #E8F5E9;
            border-left: 4px solid #4CAF50;
            margin: 10px 0;
        }
        .error { 
            color: #f44336; 
            padding: 15px;
            background: #FFEBEE;
            border-left: 4px solid #f44336;
            margin: 10px 0;
        }
        .info {
            color: #2196F3;
            padding: 15px;
            background: #E3F2FD;
            border-left: 4px solid #2196F3;
            margin: 10px 0;
        }
        .step {
            padding: 10px;
            margin: 10px 0;
            background: #f9f9f9;
            border-left: 3px solid #667eea;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin: 10px 5px;
            font-weight: bold;
        }
        .btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>🔔 Create Smart Notifications System</h2>
';

try {
    $db = Database::getInstance()->getConnection();
    
    // Create notifications table
    echo '<div class="step">Step 1: Creating notifications table...</div>';
    $sql = "CREATE TABLE IF NOT EXISTS `notifications` (
      `notification_id` INT(11) NOT NULL AUTO_INCREMENT,
      `school_id` INT(11) NOT NULL,
      `user_id` INT(11) NULL,
      `target_role` VARCHAR(50) NULL,
      `notification_type` ENUM('payment', 'expense', 'overdue', 'low_balance', 'new_student', 'fee_reminder', 'system', 'custom') NOT NULL,
      `title` VARCHAR(255) NOT NULL,
      `message` TEXT NOT NULL,
      `action_url` VARCHAR(500) NULL,
      `priority` ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
      `is_read` TINYINT(1) DEFAULT 0,
      `read_at` TIMESTAMP NULL,
      `related_id` INT(11) NULL,
      `related_type` VARCHAR(50) NULL,
      `icon` VARCHAR(50) NULL,
      `color` VARCHAR(20) NULL,
      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      `expires_at` TIMESTAMP NULL,
      PRIMARY KEY (`notification_id`),
      KEY `idx_school_user` (`school_id`, `user_id`),
      KEY `idx_role` (`target_role`),
      KEY `idx_type` (`notification_type`),
      KEY `idx_read` (`is_read`),
      KEY `idx_created` (`created_at`),
      KEY `idx_expires` (`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
    
    $db->exec($sql);
    echo '<div class="success">✅ notifications table created!</div>';
    
    // Create notification_preferences table
    echo '<div class="step">Step 2: Creating notification_preferences table...</div>';
    $sql = "CREATE TABLE IF NOT EXISTS `notification_preferences` (
      `preference_id` INT(11) NOT NULL AUTO_INCREMENT,
      `user_id` INT(11) NOT NULL,
      `school_id` INT(11) NOT NULL,
      `notification_type` VARCHAR(50) NOT NULL,
      `enabled` TINYINT(1) DEFAULT 1,
      `email_enabled` TINYINT(1) DEFAULT 0,
      `sms_enabled` TINYINT(1) DEFAULT 0,
      `sound_enabled` TINYINT(1) DEFAULT 1,
      `desktop_enabled` TINYINT(1) DEFAULT 1,
      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (`preference_id`),
      UNIQUE KEY `unique_user_type` (`user_id`, `notification_type`),
      KEY `idx_user` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
    
    $db->exec($sql);
    echo '<div class="success">✅ notification_preferences table created!</div>';
    
    // Create notification_triggers table
    echo '<div class="step">Step 3: Creating notification_triggers table...</div>';
    $sql = "CREATE TABLE IF NOT EXISTS `notification_triggers` (
      `trigger_id` INT(11) NOT NULL AUTO_INCREMENT,
      `school_id` INT(11) NOT NULL,
      `trigger_name` VARCHAR(100) NOT NULL,
      `trigger_type` ENUM('payment_received', 'expense_added', 'overdue_fee', 'low_balance', 'daily_summary', 'weekly_report', 'monthly_report') NOT NULL,
      `is_active` TINYINT(1) DEFAULT 1,
      `conditions` TEXT NULL,
      `target_roles` VARCHAR(255) NULL,
      `template` TEXT NULL,
      `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (`trigger_id`),
      KEY `idx_school` (`school_id`),
      KEY `idx_type` (`trigger_type`),
      KEY `idx_active` (`is_active`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
    
    $db->exec($sql);
    echo '<div class="success">✅ notification_triggers table created!</div>';
    
    // Insert default triggers
    echo '<div class="step">Step 4: Adding default notification triggers...</div>';
    
    $stmt = $db->query("SELECT school_id FROM schools");
    $schools = $stmt->fetchAll();
    
    $inserted = 0;
    
    foreach ($schools as $school) {
        $triggers = [
            [
                'name' => 'Payment Received Alert',
                'type' => 'payment_received',
                'roles' => 'accountant,proprietor',
                'template' => 'New payment of {amount} received from {student_name} ({admission_number})',
                'conditions' => json_encode(['min_amount' => 0])
            ],
            [
                'name' => 'Expense Added Alert',
                'type' => 'expense_added',
                'roles' => 'proprietor,admin',
                'template' => 'New expense of {amount} added: {description} (Status: {status})',
                'conditions' => json_encode(['min_amount' => 0])
            ],
            [
                'name' => 'Overdue Fee Alert',
                'type' => 'overdue_fee',
                'roles' => 'accountant,proprietor',
                'template' => '{count} students have overdue fees totaling {amount}',
                'conditions' => json_encode(['days_overdue' => 7])
            ],
            [
                'name' => 'Low Balance Warning',
                'type' => 'low_balance',
                'roles' => 'proprietor,accountant',
                'template' => 'School balance is low: {balance}. Monthly expenses: {expenses}',
                'conditions' => json_encode(['threshold_days' => 30])
            ],
            [
                'name' => 'Daily Financial Summary',
                'type' => 'daily_summary',
                'roles' => 'proprietor,accountant',
                'template' => 'Today: {payments} payments ({amount}), {expenses} expenses ({expense_amount}). Net: {net}',
                'conditions' => json_encode(['send_time' => '17:00'])
            ]
        ];
        
        foreach ($triggers as $trigger) {
            try {
                $stmt = $db->prepare("
                    INSERT INTO notification_triggers 
                    (school_id, trigger_name, trigger_type, target_roles, template, conditions)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $school['school_id'],
                    $trigger['name'],
                    $trigger['type'],
                    $trigger['roles'],
                    $trigger['template'],
                    $trigger['conditions']
                ]);
                $inserted++;
            } catch (PDOException $e) {
                if ($e->getCode() != 23000) {
                    throw $e;
                }
            }
        }
    }
    
    echo '<div class="success">✅ Added ' . $inserted . ' notification triggers!</div>';
    
    // Verification
    echo '<div class="step">Step 5: Verifying installation...</div>';
    
    $stmt = $db->query("SELECT COUNT(*) as count FROM notification_triggers");
    $trigger_count = $stmt->fetch()['count'];
    
    echo '<div class="info">';
    echo '<strong>Total notification triggers:</strong> ' . $trigger_count;
    echo '</div>';
    
    echo '<div class="success" style="margin-top: 30px; font-size: 18px; text-align: center;">';
    echo '🎉 <strong>SMART NOTIFICATIONS SYSTEM READY!</strong><br><br>';
    echo 'Notifications will now appear in the bell icon in the header!';
    echo '</div>';
    
    echo '<div style="text-align: center; margin-top: 30px;">';
    echo '<a href="' . APP_URL . '/accountant/dashboard.php" class="btn">📊 Go to Dashboard</a>';
    echo '<a href="' . APP_URL . '/accountant/expenses.php" class="btn">🧾 Test: Add Expense</a>';
    echo '</div>';
    
    echo '<div class="info" style="margin-top: 30px;">';
    echo '<strong>Notification Types:</strong><br>';
    echo '• 💰 Payment Received - Real-time alerts when payments come in<br>';
    echo '• 🧾 Expense Added - Notifications when expenses are recorded<br>';
    echo '• ⚠️ Overdue Fees - Automatic alerts for overdue payments<br>';
    echo '• 💸 Low Balance - Cash flow warnings<br>';
    echo '• 📊 Daily Summary - End-of-day financial reports<br><br>';
    
    echo '<strong>Features:</strong><br>';
    echo '• Real-time notification bell in header<br>';
    echo '• Unread count badge<br>';
    echo '• Click to view dropdown<br>';
    echo '• Mark as read/Mark all as read<br>';
    echo '• Auto-refresh every 30 seconds<br>';
    echo '• Sound alerts (optional)<br>';
    echo '• Priority levels (low/medium/high/urgent)';
    echo '</div>';
    
} catch (PDOException $e) {
    echo '<div class="error">';
    echo '<strong>❌ Error:</strong> ' . $e->getMessage();
    echo '</div>';
}

echo '
    </div>
</body>
</html>';
?>
