<?php
// Generate password hash for "student123"
$password = 'student123';
$hash = password_hash($password, PASSWORD_BCRYPT);

echo "Password: $password\n";
echo "Hash: $hash\n";

// Verify it works
if (password_verify($password, $hash)) {
    echo "✓ Verification successful!\n";
} else {
    echo "✗ Verification failed!\n";
}
?>
