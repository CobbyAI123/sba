<?php
/**
 * Database Import Verification Script
 * 
 * Run this script after importing the database to verify
 * that all tables, foreign keys, and data are correctly set up
 * 
 * Usage: php verify-database-import.php
 * Or access via browser: http://yourdomain.com/database/verify-database-import.php
 */

// Database credentials
$db_host = 'localhost';
$db_user = 'root';  // Change this
$db_pass = '';      // Change this
$db_name = 'school_management_system';  // Change if different

// Styling for web output
if (php_sapi_name() !== 'cli') {
    echo '<style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #1a56db; border-bottom: 3px solid #1a56db; padding-bottom: 10px; }
        h2 { color: #333; margin-top: 30px; }
        .success { color: #28a745; font-weight: bold; }
        .error { color: #dc3545; font-weight: bold; }
        .warning { color: #ffc107; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #1a56db; color: white; }
        tr:hover { background: #f8f9fa; }
        .badge { padding: 5px 10px; border-radius: 5px; font-size: 12px; }
        .badge-success { background: #28a745; color: white; }
        .badge-danger { background: #dc3545; color: white; }
        .badge-warning { background: #ffc107; color: #333; }
        .summary { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin: 20px 0; }
        .summary-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; text-align: center; }
        .summary-card h3 { margin: 0; font-size: 36px; }
        .summary-card p { margin: 10px 0 0 0; opacity: 0.9; }
    </style><div class="container">';
}

echo "\n";
echo "========================================\n";
echo "Database Import Verification Script\n";
echo "========================================\n\n";

$errors = [];
$warnings = [];
$success = [];

try {
    // Connect to database
    echo "📡 Connecting to database...\n";
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4",
        $db_user,
        $db_pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
    echo "✅ Connected successfully!\n\n";
    $success[] = "Database connection established";
    
} catch(PDOException $e) {
    echo "❌ Connection failed: " . $e->getMessage() . "\n";
    $errors[] = "Database connection failed: " . $e->getMessage();
    exit(1);
}

// 1. Check Tables Count
echo "📊 Checking Tables...\n";
$stmt = $pdo->query("SHOW TABLES");
$tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
$table_count = count($tables);

if ($table_count >= 50) {
    echo "✅ Found $table_count tables\n";
    $success[] = "$table_count tables created";
} else {
    echo "⚠️  Found only $table_count tables (expected 50+)\n";
    $warnings[] = "Only $table_count tables found (expected 50+)";
}

// 2. Check Required Tables
echo "\n🔍 Verifying Required Tables...\n";
$required_tables = [
    'schools', 'users', 'students', 'teachers', 'parents',
    'classes', 'subjects', 'attendance', 'exams', 'marks',
    'payments', 'fee_structure', 'email_templates', 'notifications',
    'library_books', 'messages', 'transactions', 'api_tokens'
];

$missing_tables = [];
foreach ($required_tables as $table) {
    if (in_array($table, $tables)) {
        echo "  ✅ $table\n";
    } else {
        echo "  ❌ $table - MISSING!\n";
        $missing_tables[] = $table;
        $errors[] = "Table missing: $table";
    }
}

if (empty($missing_tables)) {
    $success[] = "All required tables exist";
}

// 3. Check Email Templates
echo "\n📧 Checking Email Templates...\n";
try {
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM email_templates");
    $template_count = $stmt->fetch()['count'];
    
    if ($template_count >= 7) {
        echo "✅ Found $template_count email templates\n";
        $success[] = "$template_count email templates installed";
    } else {
        echo "⚠️  Found only $template_count email templates (expected 7)\n";
        $warnings[] = "Only $template_count email templates (expected 7)";
    }
    
    // List templates
    $stmt = $pdo->query("SELECT template_name, template_type, status FROM email_templates");
    $templates = $stmt->fetchAll();
    
    if (php_sapi_name() !== 'cli') {
        echo '<table><tr><th>Template Name</th><th>Type</th><th>Status</th></tr>';
        foreach ($templates as $template) {
            $badge = $template['status'] === 'active' ? 'badge-success' : 'badge-danger';
            echo '<tr><td>' . htmlspecialchars($template['template_name']) . '</td>';
            echo '<td>' . htmlspecialchars($template['template_type']) . '</td>';
            echo '<td><span class="badge ' . $badge . '">' . $template['status'] . '</span></td></tr>';
        }
        echo '</table>';
    } else {
        foreach ($templates as $template) {
            echo "  - {$template['template_name']} ({$template['template_type']}) [{$template['status']}]\n";
        }
    }
    
} catch(PDOException $e) {
    echo "❌ Error checking email templates: " . $e->getMessage() . "\n";
    $errors[] = "Email templates check failed";
}

// 4. Check Foreign Keys
echo "\n🔗 Checking Foreign Keys...\n";
try {
    $stmt = $pdo->query("
        SELECT COUNT(*) as count
        FROM information_schema.KEY_COLUMN_USAGE
        WHERE REFERENCED_TABLE_SCHEMA = '$db_name'
        AND REFERENCED_TABLE_NAME IS NOT NULL
    ");
    $fk_count = $stmt->fetch()['count'];
    
    if ($fk_count > 0) {
        echo "✅ Found $fk_count foreign key constraints\n";
        $success[] = "$fk_count foreign keys created";
    } else {
        echo "⚠️  No foreign keys found\n";
        $warnings[] = "No foreign keys found";
    }
} catch(PDOException $e) {
    echo "⚠️  Could not check foreign keys\n";
}

// 5. Check Indexes
echo "\n📑 Checking Indexes...\n";
try {
    $stmt = $pdo->query("
        SELECT COUNT(*) as count
        FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = '$db_name'
        AND INDEX_NAME != 'PRIMARY'
    ");
    $index_count = $stmt->fetch()['count'];
    
    if ($index_count > 50) {
        echo "✅ Found $index_count indexes (excellent for performance)\n";
        $success[] = "$index_count performance indexes created";
    } else {
        echo "⚠️  Found only $index_count indexes\n";
        $warnings[] = "Only $index_count indexes found";
    }
} catch(PDOException $e) {
    echo "⚠️  Could not check indexes\n";
}

// 6. Check Table Engines
echo "\n⚙️  Checking Table Engines...\n";
try {
    $stmt = $pdo->query("
        SELECT TABLE_NAME, ENGINE
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = '$db_name'
        AND ENGINE != 'InnoDB'
    ");
    $non_innodb = $stmt->fetchAll();
    
    if (empty($non_innodb)) {
        echo "✅ All tables using InnoDB engine\n";
        $success[] = "All tables use InnoDB engine";
    } else {
        echo "⚠️  Some tables not using InnoDB:\n";
        foreach ($non_innodb as $table) {
            echo "  - {$table['TABLE_NAME']}: {$table['ENGINE']}\n";
            $warnings[] = "Table {$table['TABLE_NAME']} uses {$table['ENGINE']} instead of InnoDB";
        }
    }
} catch(PDOException $e) {
    echo "⚠️  Could not check table engines\n";
}

// 7. Check Character Set
echo "\n🔤 Checking Character Set...\n";
try {
    $stmt = $pdo->query("
        SELECT DEFAULT_CHARACTER_SET_NAME, DEFAULT_COLLATION_NAME
        FROM information_schema.SCHEMATA
        WHERE SCHEMA_NAME = '$db_name'
    ");
    $charset_info = $stmt->fetch();
    
    if ($charset_info['DEFAULT_CHARACTER_SET_NAME'] === 'utf8mb4') {
        echo "✅ Database using utf8mb4 character set\n";
        $success[] = "Correct character set (utf8mb4)";
    } else {
        echo "⚠️  Database using {$charset_info['DEFAULT_CHARACTER_SET_NAME']} (should be utf8mb4)\n";
        $warnings[] = "Character set is {$charset_info['DEFAULT_CHARACTER_SET_NAME']}, should be utf8mb4";
    }
} catch(PDOException $e) {
    echo "⚠️  Could not check character set\n";
}

// 8. Check Database Size
echo "\n💾 Checking Database Size...\n";
try {
    $stmt = $pdo->query("
        SELECT 
            ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size_mb
        FROM information_schema.tables
        WHERE table_schema = '$db_name'
    ");
    $size = $stmt->fetch()['size_mb'];
    
    echo "📊 Database size: {$size} MB\n";
    $success[] = "Database size: {$size} MB";
} catch(PDOException $e) {
    echo "⚠️  Could not calculate database size\n";
}

// 9. Check Critical Columns
echo "\n🔍 Checking Critical Columns...\n";
$critical_columns = [
    'students' => ['fee_exemption', 'exemption_reason', 'middle_name', 'hometown'],
    'payments' => ['collection_period', 'submitted_to', 'verified_by'],
    'classes' => ['class_teacher'],
    'users' => ['middle_name', 'role']
];

foreach ($critical_columns as $table => $columns) {
    if (in_array($table, $tables)) {
        $stmt = $pdo->query("DESCRIBE $table");
        $existing_columns = array_column($stmt->fetchAll(), 'Field');
        
        echo "  Table: $table\n";
        foreach ($columns as $column) {
            if (in_array($column, $existing_columns)) {
                echo "    ✅ $column\n";
            } else {
                echo "    ❌ $column - MISSING!\n";
                $errors[] = "Column $table.$column is missing";
            }
        }
    }
}

// 10. Sample Data Check
echo "\n📈 Checking Sample Data...\n";
$data_tables = [
    'email_templates' => 7,
    'users' => 0,
    'students' => 0,
    'schools' => 0
];

foreach ($data_tables as $table => $expected_min) {
    if (in_array($table, $tables)) {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM $table");
        $count = $stmt->fetch()['count'];
        
        if ($count >= $expected_min) {
            echo "  ✅ $table: $count records\n";
        } else {
            echo "  ℹ️  $table: $count records (expected $expected_min+)\n";
        }
    }
}

// Summary
echo "\n" . str_repeat("=", 60) . "\n";
echo "VERIFICATION SUMMARY\n";
echo str_repeat("=", 60) . "\n\n";

if (php_sapi_name() !== 'cli') {
    echo '<div class="summary">';
    echo '<div class="summary-card"><h3>' . $table_count . '</h3><p>Tables Created</p></div>';
    echo '<div class="summary-card"><h3>' . count($success) . '</h3><p>Checks Passed</p></div>';
    echo '<div class="summary-card"><h3>' . count($warnings) . '</h3><p>Warnings</p></div>';
    echo '<div class="summary-card"><h3>' . count($errors) . '</h3><p>Errors</p></div>';
    echo '</div>';
}

echo "✅ Success: " . count($success) . " checks passed\n";
if (!empty($success)) {
    foreach ($success as $msg) {
        echo "  • $msg\n";
    }
}

if (!empty($warnings)) {
    echo "\n⚠️  Warnings: " . count($warnings) . "\n";
    foreach ($warnings as $msg) {
        echo "  • $msg\n";
    }
}

if (!empty($errors)) {
    echo "\n❌ Errors: " . count($errors) . "\n";
    foreach ($errors as $msg) {
        echo "  • $msg\n";
    }
}

echo "\n" . str_repeat("=", 60) . "\n";

if (empty($errors)) {
    echo "🎉 DATABASE IMPORT SUCCESSFUL!\n";
    echo "Your database is ready for production use.\n\n";
    echo "Next Steps:\n";
    echo "1. Update config.php with database credentials\n";
    echo "2. Create super admin account\n";
    echo "3. Configure school settings\n";
    echo "4. Set up SMTP email\n";
    echo "5. Test login functionality\n";
} else {
    echo "⚠️  IMPORT COMPLETED WITH ERRORS\n";
    echo "Please review and fix the errors listed above.\n";
    echo "You may need to re-import the database schema.\n";
}

echo "\n" . str_repeat("=", 60) . "\n";

if (php_sapi_name() !== 'cli') {
    echo '</div>';
}
?>
