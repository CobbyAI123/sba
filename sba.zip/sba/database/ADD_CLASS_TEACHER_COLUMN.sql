-- ============================================================================
-- ADD CLASS TEACHER ID COLUMN (OPTIONAL)
-- ============================================================================
-- This script adds the class_teacher_id column to the classes table
-- This is useful if you want to assign a primary class teacher
-- ============================================================================

USE school_management_system;

-- Add class_teacher_id column to classes table (if not exists)
ALTER TABLE classes 
ADD COLUMN IF NOT EXISTS class_teacher_id INT DEFAULT NULL COMMENT 'Primary class teacher ID',
ADD CONSTRAINT IF NOT EXISTS fk_classes_teacher 
    FOREIGN KEY (class_teacher_id) REFERENCES users(user_id) ON DELETE SET NULL;

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_classes_teacher ON classes(class_teacher_id);

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Check if column was added
SELECT '=== Verifying classes table ===' as info;
DESCRIBE classes;

-- Show classes with assigned teachers
SELECT '=== Classes with Assigned Teachers ===' as info;
SELECT 
    c.class_id,
    c.class_name,
    c.class_teacher_id,
    CONCAT(u.first_name, ' ', u.last_name) as teacher_name
FROM classes c
LEFT JOIN users u ON c.class_teacher_id = u.user_id
ORDER BY c.class_name;

SELECT '✅ Class Teacher Column Added Successfully!' as status;

-- ============================================================================
-- NOTES
-- ============================================================================
/*
USAGE:

1. This column is OPTIONAL and adds a primary class teacher to each class
2. The teacher/collect-fees.php page uses teacher_classes table (many-to-many)
3. This column is useful for admin interfaces to show "Class Teacher"

DIFFERENCE:
- class_teacher_id: One primary teacher per class (e.g., form teacher)
- teacher_classes: Multiple teachers can teach multiple classes (subject teachers)

EXAMPLE:
Class: JHS 1
- class_teacher_id: Mr. Smith (Form Teacher)
- teacher_classes: Mr. Smith (Math), Mrs. Jones (English), Mr. Brown (Science)
*/

-- ============================================================================
-- END OF SCRIPT
-- ============================================================================
