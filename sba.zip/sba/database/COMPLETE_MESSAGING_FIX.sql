-- ============================================================================
-- COMPLETE MESSAGING SYSTEM FIX
-- Run this entire file in phpMyAdmin
-- ============================================================================

-- Disable foreign key checks temporarily
SET FOREIGN_KEY_CHECKS = 0;

-- Drop all messaging-related tables
DROP TABLE IF EXISTS `message_attachments`;
DROP TABLE IF EXISTS `messages`;
DROP TABLE IF EXISTS `message_templates`;
DROP TABLE IF EXISTS `sms_logs`;
DROP TABLE IF EXISTS `email_logs`;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================================
-- CREATE MESSAGES TABLE (Complete)
-- ============================================================================

CREATE TABLE `messages` (
  `message_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `sender_id` INT(11) NOT NULL,
  `recipient_id` INT(11) NULL,
  `recipient_role` VARCHAR(50) NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `attachment` VARCHAR(255) NULL,
  `message_type` ENUM('personal', 'broadcast', 'announcement') DEFAULT 'personal',
  `priority` ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
  `read_status` ENUM('unread', 'read') DEFAULT 'unread',
  `replied_to` INT(11) NULL,
  `deleted_by_sender` TINYINT(1) DEFAULT 0,
  `deleted_by_recipient` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `read_at` TIMESTAMP NULL,
  PRIMARY KEY (`message_id`),
  KEY `idx_school_sender` (`school_id`, `sender_id`),
  KEY `idx_school_recipient` (`school_id`, `recipient_id`),
  KEY `idx_read_status` (`read_status`),
  KEY `idx_message_type` (`message_type`),
  KEY `idx_created_at` (`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- CREATE MESSAGE ATTACHMENTS TABLE
-- ============================================================================

CREATE TABLE `message_attachments` (
  `attachment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `message_id` INT(11) NOT NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_size` INT(11) NULL,
  `file_type` VARCHAR(50) NULL,
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attachment_id`),
  KEY `idx_message` (`message_id`),
  FOREIGN KEY (`message_id`) REFERENCES `messages`(`message_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- CREATE MESSAGE TEMPLATES TABLE
-- ============================================================================

CREATE TABLE `message_templates` (
  `template_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `created_by` INT(11) NOT NULL,
  `template_name` VARCHAR(100) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `category` VARCHAR(50) NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`template_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- CREATE SMS LOGS TABLE
-- ============================================================================

CREATE TABLE `sms_logs` (
  `sms_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NULL,
  `recipient_phone` VARCHAR(20) NOT NULL,
  `message` TEXT NOT NULL,
  `sms_type` VARCHAR(50) NULL,
  `status` ENUM('pending', 'sent', 'failed', 'delivered') DEFAULT 'pending',
  `gateway` VARCHAR(50) NULL,
  `gateway_response` TEXT NULL,
  `cost` DECIMAL(10,4) NULL,
  `sent_at` TIMESTAMP NULL,
  `delivered_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sms_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- CREATE EMAIL LOGS TABLE
-- ============================================================================

CREATE TABLE `email_logs` (
  `email_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NULL,
  `recipient_email` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `email_type` VARCHAR(50) NULL,
  `status` ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
  `sent_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`email_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT '✅ SUCCESS! All messaging tables created!' as status;
SELECT 'Tables created: messages, message_attachments, message_templates, sms_logs, email_logs' as info;
SELECT 'Next step: Visit /admin/messages.php' as next_step;
