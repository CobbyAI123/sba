-- ============================================================================
-- MESSAGE TEMPLATES SYSTEM
-- Pre-written messages for common scenarios
-- Date: November 28, 2025
-- ============================================================================

CREATE TABLE IF NOT EXISTS `message_templates` (
  `template_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `category` ENUM('fee_reminder', 'payment_confirmation', 'overdue_notice', 'class_announcement', 'event_announcement', 'parent_update', 'student_message', 'custom') NOT NULL,
  `template_name` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message_body` LONGTEXT NOT NULL,
  `description` TEXT NULL,
  `variables` TEXT NULL COMMENT 'JSON array of available variables',
  `is_active` TINYINT(1) DEFAULT 1,
  `usage_count` INT(11) DEFAULT 0,
  `created_by` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`template_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_category` (`category`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Message templates for quick communication';

-- ============================================================================
-- INSERT DEFAULT MESSAGE TEMPLATES
-- ============================================================================

-- Fee Reminder Templates
INSERT INTO `message_templates` (`school_id`, `category`, `template_name`, `subject`, `message_body`, `variables`, `created_by`)
SELECT DISTINCT 
    school_id,
    'fee_reminder',
    'Basic Fee Reminder',
    'Fee Payment Reminder - {student_name}',
    'Dear {parent_name},\n\nThis is a friendly reminder that the fees for {student_name} ({admission_number}) for {term_name} are due on {due_date}.\n\nAmount Due: {amount}\n\nPlease arrange payment at your earliest convenience.\n\nThank you.',
    '["student_name", "parent_name", "admission_number", "term_name", "due_date", "amount"]',
    user_id
FROM users
WHERE role = 'admin'
LIMIT 1;

-- Payment Confirmation Templates
INSERT INTO `message_templates` (`school_id`, `category`, `template_name`, `subject`, `message_body`, `variables`, `created_by`)
SELECT DISTINCT 
    school_id,
    'payment_confirmation',
    'Payment Receipt',
    'Payment Received - {student_name}',
    'Dear {parent_name},\n\nWe confirm receipt of your payment for {student_name}.\n\nPayment Details:\nAmount: {amount}\nDate: {payment_date}\nReference: {reference_number}\n\nThank you for your prompt payment.',
    '["student_name", "parent_name", "amount", "payment_date", "reference_number"]',
    user_id
FROM users
WHERE role = 'admin'
LIMIT 1;

-- Overdue Notice Templates
INSERT INTO `message_templates` (`school_id`, `category`, `template_name`, `subject`, `message_body`, `variables`, `created_by`)
SELECT DISTINCT 
    school_id,
    'overdue_notice',
    'Overdue Payment Notice',
    'Outstanding Fees Notice - {student_name}',
    'Dear {parent_name},\n\nThe fees for {student_name} are now overdue.\n\nOutstanding Amount: {amount}\nOriginal Due Date: {due_date}\nDays Overdue: {days_overdue}\n\nPlease settle this outstanding balance immediately to avoid further action.\n\nFor payment arrangement, contact us at {school_phone}.',
    '["student_name", "parent_name", "amount", "due_date", "days_overdue", "school_phone"]',
    user_id
FROM users
WHERE role = 'admin'
LIMIT 1;

-- Class Announcement Templates
INSERT INTO `message_templates` (`school_id`, `category`, `template_name`, `subject`, `message_body`, `variables`, `created_by`)
SELECT DISTINCT 
    school_id,
    'class_announcement',
    'Class Activity Update',
    '{class_name} - Class Update',
    'Dear Parents/Guardians,\n\n{announcement}\n\nClass: {class_name}\nDate: {announcement_date}\nTeacher: {teacher_name}\n\nPlease contact us if you have any questions.',
    '["class_name", "announcement", "announcement_date", "teacher_name"]',
    user_id
FROM users
WHERE role = 'admin'
LIMIT 1;

-- Event Announcement Templates
INSERT INTO `message_templates` (`school_id`, `category`, `template_name`, `subject`, `message_body`, `variables`, `created_by`)
SELECT DISTINCT 
    school_id,
    'event_announcement',
    'School Event Notice',
    'Upcoming Event - {event_name}',
    'Dear {recipient_name},\n\nWe are pleased to announce the following event:\n\nEvent: {event_name}\nDate: {event_date}\nTime: {event_time}\nVenue: {event_venue}\n\n{event_description}\n\nWe look forward to your participation!',
    '["recipient_name", "event_name", "event_date", "event_time", "event_venue", "event_description"]',
    user_id
FROM users
WHERE role = 'admin'
LIMIT 1;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT '✅ message_templates table created' AS status;
SELECT COUNT(*) as template_count FROM message_templates;

SELECT '
╔═══════════════════════════════════════════════════════════════╗
║         ✅ MESSAGE TEMPLATES SYSTEM CREATED!                  ║
╠═══════════════════════════════════════════════════════════════╣
║ • message_templates table created                             ║
║ • Default templates added for all schools                     ║
║ • Categories: fee_reminder, payment_confirmation, etc.        ║
╠═══════════════════════════════════════════════════════════════╣
║ FEATURES:                                                     ║
║ • Quick message sending                                       ║
║ • Variable substitution                                       ║
║ • Category organization                                       ║
║ • Usage tracking                                              ║
║ • Easy customization                                          ║
║ • Reusable messages                                           ║
╚═══════════════════════════════════════════════════════════════╝
' AS SUCCESS;
