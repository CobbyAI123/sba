-- Bulk Operations Tables

CREATE TABLE IF NOT EXISTS `bulk_operations_log` (
  `log_id` INT PRIMARY KEY AUTO_INCREMENT,
  `batch_id` VARCHAR(50) NOT NULL,
  `user_id` INT NOT NULL,
  `school_id` INT NOT NULL,
  `operation_type` VARCHAR(100) NOT NULL,
  `record_id` INT,
  `record_type` VARCHAR(50),
  `action` VARCHAR(100),
  `success` BOOLEAN DEFAULT 1,
  `error_message` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_batch_id` (`batch_id`),
  INDEX `idx_user_school` (`user_id`, `school_id`),
  INDEX `idx_operation_type` (`operation_type`),
  INDEX `idx_created_at` (`created_at`)
);

CREATE TABLE IF NOT EXISTS `bulk_operations_queue` (
  `queue_id` INT PRIMARY KEY AUTO_INCREMENT,
  `batch_id` VARCHAR(50) NOT NULL UNIQUE,
  `user_id` INT NOT NULL,
  `school_id` INT NOT NULL,
  `operation_type` VARCHAR(100) NOT NULL,
  `parameters` JSON,
  `status` ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
  `progress_percentage` INT DEFAULT 0,
  `error_message` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `started_at` DATETIME,
  `completed_at` DATETIME,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_status` (`status`),
  INDEX `idx_user_school` (`user_id`, `school_id`),
  INDEX `idx_created_at` (`created_at`)
);

-- Transcripts table (if not exists)
CREATE TABLE IF NOT EXISTS `transcripts` (
  `transcript_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `student_id` INT NOT NULL,
  `generated_by` INT,
  `generated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `filename` VARCHAR(255),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
  FOREIGN KEY (`generated_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_student` (`school_id`, `student_id`),
  INDEX `idx_generated_at` (`generated_at`)
);
