-- ============================================================================
-- ENHANCED FEE COLLECTION SYSTEM
-- Features: Hometowns/Routes, Student Exemptions, Daily Collections, SMS Logs
-- Date: 2025-11-18
-- ============================================================================

-- ============================================================================
-- HOMETOWNS/ROUTES TABLE (for bus fee management)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `hometowns` (
  `hometown_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `hometown_name` VARCHAR(100) NOT NULL,
  `route_name` VARCHAR(100) NULL,
  `bus_fee` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `distance_km` DECIMAL(5,2) NULL,
  `description` TEXT NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_by` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`hometown_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- ALTER STUDENTS TABLE - Add exemption and hometown fields
-- ============================================================================
-- Check and add hometown_id column
SET @dbname = DATABASE();
SET @tablename = 'students';
SET @columnname = 'hometown_id';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE (table_name = @tablename)
    AND (table_schema = @dbname)
    AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD ', @columnname, ' INT(11) NULL AFTER address')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Check and add exempt_canteen column
SET @columnname = 'exempt_canteen';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE (table_name = @tablename)
    AND (table_schema = @dbname)
    AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD ', @columnname, ' TINYINT(1) DEFAULT 0 AFTER hometown_id')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Check and add exempt_bus column
SET @columnname = 'exempt_bus';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE (table_name = @tablename)
    AND (table_schema = @dbname)
    AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD ', @columnname, ' TINYINT(1) DEFAULT 0 AFTER exempt_canteen')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- ============================================================================
-- DAILY COLLECTIONS TABLE (for tracking canteen & bus payments)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `daily_collections` (
  `collection_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `collection_date` DATE NOT NULL,
  `collection_type` ENUM('canteen', 'bus', 'both') NOT NULL,
  `canteen_paid` TINYINT(1) DEFAULT 0,
  `bus_paid` TINYINT(1) DEFAULT 0,
  `canteen_amount` DECIMAL(10,2) DEFAULT 0.00,
  `bus_amount` DECIMAL(10,2) DEFAULT 0.00,
  `total_amount` DECIMAL(10,2) GENERATED ALWAYS AS (canteen_amount + bus_amount) STORED,
  `is_present` TINYINT(1) DEFAULT 1,
  `marked_by` INT(11) NOT NULL,
  `remarks` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`collection_id`),
  UNIQUE KEY `idx_student_date_type` (`student_id`, `collection_date`, `collection_type`),
  KEY `idx_school_date` (`school_id`, `collection_date`),
  KEY `idx_class_date` (`class_id`, `collection_date`),
  KEY `idx_marked_by` (`marked_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- CANTEEN FEE STRUCTURE (class-based canteen fees)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `canteen_fee_structure` (
  `canteen_fee_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `daily_fee` DECIMAL(10,2) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL,
  `term_id` INT(11) NULL,
  `description` TEXT NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_by` INT(11) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`canteen_fee_id`),
  UNIQUE KEY `idx_school_class_term` (`school_id`, `class_id`, `term_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- CLASS TEACHERS TABLE (for assigning class teachers)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `class_teachers` (
  `assignment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `teacher_id` INT(11) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL,
  `is_primary` TINYINT(1) DEFAULT 1,
  `assigned_date` DATE NOT NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`assignment_id`),
  UNIQUE KEY `idx_class_teacher_year` (`class_id`, `teacher_id`, `academic_year`),
  KEY `idx_teacher` (`teacher_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SMS LOGS TABLE (for tracking SMS notifications to parents)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `sms_logs` (
  `sms_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `recipient_phone` VARCHAR(20) NOT NULL,
  `recipient_name` VARCHAR(200) NULL,
  `student_id` INT(11) NULL,
  `parent_id` INT(11) NULL,
  `message` TEXT NOT NULL,
  `message_type` ENUM('attendance', 'payment', 'general', 'exam', 'announcement') DEFAULT 'general',
  `status` ENUM('pending', 'sent', 'failed', 'delivered') DEFAULT 'pending',
  `provider` VARCHAR(50) NULL,
  `cost` DECIMAL(10,2) DEFAULT 0.00,
  `error_message` TEXT NULL,
  `sent_at` TIMESTAMP NULL,
  `delivered_at` TIMESTAMP NULL,
  `created_by` INT(11) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sms_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_parent` (`parent_id`),
  KEY `idx_status` (`status`),
  KEY `idx_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- PAYMENT GATEWAY SETTINGS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS `payment_gateways` (
  `gateway_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `gateway_name` ENUM('paystack', 'mtn_momo', 'tigo_cash', 'vodafone_cash') NOT NULL,
  `is_active` TINYINT(1) DEFAULT 0,
  `api_key` VARCHAR(255) NULL,
  `api_secret` VARCHAR(255) NULL,
  `merchant_id` VARCHAR(100) NULL,
  `webhook_url` VARCHAR(255) NULL,
  `test_mode` TINYINT(1) DEFAULT 1,
  `settings` JSON NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`gateway_id`),
  UNIQUE KEY `idx_school_gateway` (`school_id`, `gateway_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- ALTER TRANSACTIONS TABLE - Add gateway reference
-- ============================================================================
SET @tablename = 'transactions';
SET @columnname = 'gateway_name';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
    WHERE (table_name = @tablename)
    AND (table_schema = @dbname)
    AND (column_name = @columnname)
  ) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD ', @columnname, ' VARCHAR(50) NULL AFTER payment_method')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- ============================================================================
-- INSERT SAMPLE DATA (Optional - for testing)
-- ============================================================================

-- Sample Hometowns/Routes
INSERT IGNORE INTO `hometowns` (`hometown_id`, `school_id`, `hometown_name`, `route_name`, `bus_fee`, `distance_km`, `created_by`) VALUES
(1, 1, 'Accra Central', 'Route A', 50.00, 5.0, 1),
(2, 1, 'Tema', 'Route B', 80.00, 15.0, 1),
(3, 1, 'Madina', 'Route C', 60.00, 10.0, 1),
(4, 1, 'Kasoa', 'Route D', 100.00, 25.0, 1),
(5, 1, 'Teshie', 'Route A', 50.00, 6.0, 1);

-- Sample Canteen Fee Structure
INSERT IGNORE INTO `canteen_fee_structure` (`school_id`, `class_id`, `daily_fee`, `academic_year`, `created_by`) VALUES
(1, 1, 5.00, '2024/2025', 1),
(1, 2, 5.00, '2024/2025', 1),
(1, 3, 7.00, '2024/2025', 1),
(1, 4, 7.00, '2024/2025', 1),
(1, 5, 10.00, '2024/2025', 1);

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================
SELECT 
    '✅ Database Schema Updated Successfully!' AS status,
    'Enhanced Fee Collection System is Ready' AS message;

SELECT 
    'hometowns' as table_name,
    COUNT(*) as sample_records 
FROM hometowns;

SELECT 
    'canteen_fee_structure' as table_name,
    COUNT(*) as sample_records 
FROM canteen_fee_structure;

-- Check if columns were added to students table
SELECT 
    'students table columns' as info,
    GROUP_CONCAT(COLUMN_NAME) as new_columns
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME = 'students'
AND COLUMN_NAME IN ('hometown_id', 'exempt_canteen', 'exempt_bus');

SELECT '
╔═══════════════════════════════════════════════════════════════╗
║       ✅ ENHANCED FEE SYSTEM SCHEMA CREATED!                  ║
╠═══════════════════════════════════════════════════════════════╣
║ Tables Created/Updated:                                       ║
║ • hometowns - Bus routes and fees                             ║
║ • canteen_fee_structure - Class-based canteen fees            ║
║ • daily_collections - Daily payment tracking                  ║
║ • class_teachers - Class teacher assignments                  ║
║ • sms_logs - SMS notification tracking                        ║
║ • payment_gateways - Payment gateway configuration            ║
║ • students - Added hometown_id, exemptions                    ║
║ • transactions - Added gateway_name column                    ║
╠═══════════════════════════════════════════════════════════════╣
║ NEXT STEPS:                                                   ║
║ 1. Create Admin Hometown Management Interface                ║
║ 2. Update Student Admission Form                             ║
║ 3. Create Teacher Daily Collection Interface                 ║
║ 4. Implement Payment Gateway Integration                     ║
║ 5. Set up SMS Notification System                            ║
╚═══════════════════════════════════════════════════════════════╝
' AS IMPLEMENTATION_STATUS;
