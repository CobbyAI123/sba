-- Financial System Tables for Accountant Module
-- Run this file in phpMyAdmin to add missing tables

USE `school_management_system`;

-- Invoices Table
CREATE TABLE IF NOT EXISTS `invoices` (
    `invoice_id` INT PRIMARY KEY AUTO_INCREMENT,
    `school_id` INT NOT NULL,
    `student_id` INT,
    `invoice_number` VARCHAR(100) UNIQUE,
    `description` TEXT,
    `amount` DECIMAL(10, 2),
    `status` ENUM('pending', 'paid', 'overdue', 'cancelled') DEFAULT 'pending',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `due_date` DATE,
    KEY `school_id` (`school_id`),
    KEY `student_id` (`student_id`),
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE SET NULL
);

-- Fee Structure Table
CREATE TABLE IF NOT EXISTS `fee_structure` (
    `fee_id` INT PRIMARY KEY AUTO_INCREMENT,
    `school_id` INT NOT NULL,
    `class_id` INT,
    `fee_type` VARCHAR(100),
    `amount` DECIMAL(10, 2) NOT NULL,
    `description` TEXT,
    `due_date` DATE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `school_id` (`school_id`),
    KEY `class_id` (`class_id`),
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`class_id`) REFERENCES `classes`(`class_id`) ON DELETE CASCADE
);

-- Expense Tracking Table
CREATE TABLE IF NOT EXISTS `expenses` (
    `expense_id` INT PRIMARY KEY AUTO_INCREMENT,
    `school_id` INT NOT NULL,
    `expense_type` VARCHAR(100),
    `description` TEXT,
    `amount` DECIMAL(10, 2) NOT NULL,
    `expense_date` DATE NOT NULL,
    `approved_by` INT,
    `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY `school_id` (`school_id`),
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
);

-- Update payments table if not exists specific fields
ALTER TABLE `payments` ADD COLUMN IF NOT EXISTS `invoice_id` INT;
ALTER TABLE `payments` ADD COLUMN IF NOT EXISTS `receipt_number` VARCHAR(100) UNIQUE;
ALTER TABLE `payments` ADD FOREIGN KEY (`invoice_id`) REFERENCES `invoices`(`invoice_id`);
