-- ============================================================================
-- CREATE ESSENTIAL TABLES FOR SCHOOL MANAGEMENT SYSTEM
-- ============================================================================
-- This creates the minimum required tables for the system to work
-- If you have the full schema.sql, import that instead
-- ============================================================================

-- Create database if not exists
CREATE DATABASE IF NOT EXISTS school_management_system 
DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE school_management_system;

-- ============================================================================
-- 1. SCHOOLS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS `schools` (
  `school_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_name` varchar(255) NOT NULL,
  `school_code` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text,
  `logo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- 2. USERS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` enum('admin','teacher','student','parent','accountant','librarian','bookstore','proprietor') NOT NULL,
  `school_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`),
  KEY `school_id` (`school_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- 3. CLASSES TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS `classes` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(100) NOT NULL,
  `school_id` int(11) NOT NULL,
  `capacity` int(11) DEFAULT 40,
  `class_teacher_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`class_id`),
  KEY `school_id` (`school_id`),
  KEY `class_teacher_id` (`class_teacher_id`),
  CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE,
  CONSTRAINT `classes_ibfk_2` FOREIGN KEY (`class_teacher_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- 4. STUDENTS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `admission_number` varchar(50) NOT NULL,
  `class_id` int(11) DEFAULT NULL,
  `canteen_fee` decimal(10,2) DEFAULT 0.00 COMMENT 'Monthly canteen fee',
  `transport_fee` decimal(10,2) DEFAULT 0.00 COMMENT 'Monthly transport fee',
  `school_id` int(11) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive','graduated','transferred') DEFAULT 'active',
  `enrollment_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `admission_number` (`admission_number`,`school_id`),
  KEY `user_id` (`user_id`),
  KEY `class_id` (`class_id`),
  KEY `school_id` (`school_id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  CONSTRAINT `students_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE SET NULL,
  CONSTRAINT `students_ibfk_3` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE,
  CONSTRAINT `students_ibfk_4` FOREIGN KEY (`parent_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- 5. SUBJECTS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS `subjects` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(100) NOT NULL,
  `subject_code` varchar(20) DEFAULT NULL,
  `school_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`subject_id`),
  KEY `school_id` (`school_id`),
  CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- 6. TERMS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS `terms` (
  `term_id` int(11) NOT NULL AUTO_INCREMENT,
  `term_name` varchar(50) NOT NULL,
  `session_year` varchar(20) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `school_id` int(11) NOT NULL,
  `is_current` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`term_id`),
  KEY `school_id` (`school_id`),
  CONSTRAINT `terms_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- 7. PAYMENTS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_type` varchar(50) NOT NULL COMMENT 'Tuition Fee, Canteen Fee, Transport Fee, etc',
  `payment_method` varchar(50) DEFAULT 'cash',
  `payment_date` date NOT NULL,
  `term_id` int(11) DEFAULT NULL,
  `collected_by` int(11) DEFAULT NULL COMMENT 'Teacher/staff who collected the payment',
  `notes` text COMMENT 'Additional payment notes',
  `school_id` int(11) NOT NULL,
  `status` enum('pending','completed','cancelled','refunded') DEFAULT 'completed',
  `receipt_number` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  KEY `student_id` (`student_id`),
  KEY `term_id` (`term_id`),
  KEY `school_id` (`school_id`),
  KEY `collected_by` (`collected_by`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`term_id`) REFERENCES `terms` (`term_id`) ON DELETE SET NULL,
  CONSTRAINT `payments_ibfk_3` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- 8. MARKS TABLE (for Performance Analytics)
-- ============================================================================
CREATE TABLE IF NOT EXISTS `marks` (
  `mark_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) DEFAULT NULL,
  `term_id` int(11) NOT NULL,
  `exam_id` int(11) DEFAULT NULL,
  `exam_type` varchar(50) DEFAULT NULL COMMENT 'CA, Mid-Term, Exam',
  `ca_score` decimal(5,2) DEFAULT 0.00 COMMENT 'Class Assessment (max 60)',
  `midterm_score` decimal(5,2) DEFAULT 0.00 COMMENT 'Mid-Term (max 40)',
  `exam_score` decimal(5,2) DEFAULT 0.00 COMMENT 'Final Exam (max 100)',
  `total_score` decimal(5,2) DEFAULT 0.00 COMMENT 'Calculated total (max 100)',
  `grade` varchar(10) DEFAULT NULL COMMENT 'HP, P, AP, D, E',
  `remark` varchar(100) DEFAULT NULL,
  `position` int(11) DEFAULT NULL COMMENT 'Position in class',
  `teacher_id` int(11) DEFAULT NULL COMMENT 'Teacher who entered marks',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mark_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_class` (`class_id`),
  CONSTRAINT `marks_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  CONSTRAINT `marks_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE,
  CONSTRAINT `marks_ibfk_3` FOREIGN KEY (`term_id`) REFERENCES `terms` (`term_id`) ON DELETE CASCADE,
  CONSTRAINT `marks_ibfk_4` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- AUTO-CALCULATION TRIGGERS FOR MARKS
-- ============================================================================
DELIMITER $$

DROP TRIGGER IF EXISTS `calculate_marks_before_insert`$$
CREATE TRIGGER `calculate_marks_before_insert` BEFORE INSERT ON `marks`
FOR EACH ROW
BEGIN
    SET NEW.total_score = (
        (COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5
    ) + (COALESCE(NEW.exam_score, 0) * 0.5);
    
    IF NEW.total_score >= 80 THEN
        SET NEW.grade = 'HP';
        SET NEW.remark = 'Highly Proficient';
    ELSEIF NEW.total_score >= 68 THEN
        SET NEW.grade = 'P';
        SET NEW.remark = 'Proficient';
    ELSEIF NEW.total_score >= 53 THEN
        SET NEW.grade = 'AP';
        SET NEW.remark = 'Approaching Proficient';
    ELSEIF NEW.total_score >= 40 THEN
        SET NEW.grade = 'D';
        SET NEW.remark = 'Developing';
    ELSE
        SET NEW.grade = 'E';
        SET NEW.remark = 'Emerging';
    END IF;
END$$

DROP TRIGGER IF EXISTS `calculate_marks_before_update`$$
CREATE TRIGGER `calculate_marks_before_update` BEFORE UPDATE ON `marks`
FOR EACH ROW
BEGIN
    SET NEW.total_score = (
        (COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5
    ) + (COALESCE(NEW.exam_score, 0) * 0.5);
    
    IF NEW.total_score >= 80 THEN
        SET NEW.grade = 'HP';
        SET NEW.remark = 'Highly Proficient';
    ELSEIF NEW.total_score >= 68 THEN
        SET NEW.grade = 'P';
        SET NEW.remark = 'Proficient';
    ELSEIF NEW.total_score >= 53 THEN
        SET NEW.grade = 'AP';
        SET NEW.remark = 'Approaching Proficient';
    ELSEIF NEW.total_score >= 40 THEN
        SET NEW.grade = 'D';
        SET NEW.remark = 'Developing';
    ELSE
        SET NEW.grade = 'E';
        SET NEW.remark = 'Emerging';
    END IF;
END$$

DELIMITER ;

-- ============================================================================
-- INSERT DEFAULT SCHOOL (if none exists)
-- ============================================================================
INSERT INTO schools (school_name, school_code, email, phone, address)
SELECT 'My School', 'MS001', 'admin@myschool.com', '0200000000', 'School Address'
WHERE NOT EXISTS (SELECT 1 FROM schools LIMIT 1);

-- ============================================================================
-- INSERT DEFAULT ADMIN USER (if none exists)
-- ============================================================================
-- Default password: admin123 (bcrypt hash)
INSERT INTO users (email, password, first_name, last_name, role, school_id, status)
SELECT 
    'admin@myschool.com',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    'System',
    'Administrator',
    'admin',
    1,
    'active'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'admin@myschool.com');

-- ============================================================================
-- VERIFICATION
-- ============================================================================
SELECT '=== TABLES CREATED SUCCESSFULLY ===' as status;

SELECT 
    TABLE_NAME,
    TABLE_ROWS,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS 'Size (MB)'
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'school_management_system'
ORDER BY TABLE_NAME;

SELECT '=== DEFAULT CREDENTIALS ===' as info;
SELECT 'Email: admin@myschool.com' as credential;
SELECT 'Password: admin123' as credential;
SELECT 'Please change this password after first login!' as warning;

-- ============================================================================
-- NOTES
-- ============================================================================
/*
IMPORTANT:
1. This creates ONLY the essential tables
2. If you have the full schema.sql file, import that instead
3. Default admin credentials:
   - Email: admin@myschool.com
   - Password: admin123
4. Change the default password immediately after login
5. Update school information in schools table

NEXT STEPS:
1. Login with admin credentials
2. Go to Admin → School Settings
3. Update school information
4. Add classes, subjects, and terms
5. Add students and staff
6. Start using the system

TO ADD MORE FEATURES:
- Import additional SQL files from database folder
- Follow the import order in COMPLETE_DATABASE_SETUP.md
*/

-- ============================================================================
-- END OF SCRIPT
-- ============================================================================
