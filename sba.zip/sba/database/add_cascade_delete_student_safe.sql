-- ============================================================================
-- ADD CASCADE DELETE FOR STUDENT RECORDS (SAFE VERSION)
-- Handles existing constraints and orphaned records
-- ============================================================================

-- ============================================================================
-- STEP 1: Clean up orphaned records first (IMPORTANT!)
-- ============================================================================

-- Find and display orphaned payment records (for review)
SELECT COUNT(*) as orphaned_payments
FROM payments p
LEFT JOIN students s ON p.student_id = s.student_id
WHERE s.student_id IS NULL;

-- Find and display orphaned assessment records
SELECT COUNT(*) as orphaned_assessments
FROM student_assessments sa
LEFT JOIN students s ON sa.student_id = s.student_id
WHERE s.student_id IS NULL;

-- Find and display orphaned attendance records
SELECT COUNT(*) as orphaned_attendance
FROM attendance a
LEFT JOIN students s ON a.student_id = s.student_id
WHERE s.student_id IS NULL;

-- OPTION 1: Delete orphaned records (uncomment if you want to clean them)
-- DELETE p FROM payments p
-- LEFT JOIN students s ON p.student_id = s.student_id
-- WHERE s.student_id IS NULL;

-- DELETE sa FROM student_assessments sa
-- LEFT JOIN students s ON sa.student_id = s.student_id
-- WHERE s.student_id IS NULL;

-- DELETE a FROM attendance a
-- LEFT JOIN students s ON a.student_id = s.student_id
-- WHERE s.student_id IS NULL;

-- ============================================================================
-- STEP 2: Drop existing foreign keys (if they exist)
-- ============================================================================

-- Get current foreign keys
SELECT 
    CONSTRAINT_NAME,
    TABLE_NAME,
    REFERENCED_TABLE_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = DATABASE()
AND REFERENCED_TABLE_NAME = 'students';

-- Payments table - drop existing FK
SET @drop_fk_payments = (
    SELECT CONCAT('ALTER TABLE `payments` DROP FOREIGN KEY `', CONSTRAINT_NAME, '`;')
    FROM information_schema.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'payments'
    AND REFERENCED_TABLE_NAME = 'students'
    LIMIT 1
);

SET @drop_fk_payments = IFNULL(@drop_fk_payments, 'SELECT "No FK to drop on payments" as info');
PREPARE stmt FROM @drop_fk_payments;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Student assessments table - drop existing FK
SET @drop_fk_assessments = (
    SELECT CONCAT('ALTER TABLE `student_assessments` DROP FOREIGN KEY `', CONSTRAINT_NAME, '`;')
    FROM information_schema.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'student_assessments'
    AND REFERENCED_TABLE_NAME = 'students'
    LIMIT 1
);

SET @drop_fk_assessments = IFNULL(@drop_fk_assessments, 'SELECT "No FK to drop on student_assessments" as info');
PREPARE stmt FROM @drop_fk_assessments;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Attendance table - drop existing FK
SET @drop_fk_attendance = (
    SELECT CONCAT('ALTER TABLE `attendance` DROP FOREIGN KEY `', CONSTRAINT_NAME, '`;')
    FROM information_schema.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'attendance'
    AND REFERENCED_TABLE_NAME = 'students'
    LIMIT 1
);

SET @drop_fk_attendance = IFNULL(@drop_fk_attendance, 'SELECT "No FK to drop on attendance" as info');
PREPARE stmt FROM @drop_fk_attendance;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Student_parents table - drop existing FK
SET @drop_fk_parents = (
    SELECT CONCAT('ALTER TABLE `student_parents` DROP FOREIGN KEY `', CONSTRAINT_NAME, '`;')
    FROM information_schema.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'student_parents'
    AND REFERENCED_TABLE_NAME = 'students'
    LIMIT 1
);

SET @drop_fk_parents = IFNULL(@drop_fk_parents, 'SELECT "No FK to drop on student_parents" as info');
PREPARE stmt FROM @drop_fk_parents;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Transactions table - drop existing FK
SET @drop_fk_transactions = (
    SELECT CONCAT('ALTER TABLE `transactions` DROP FOREIGN KEY `', CONSTRAINT_NAME, '`;')
    FROM information_schema.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'transactions'
    AND REFERENCED_TABLE_NAME = 'students'
    LIMIT 1
);

SET @drop_fk_transactions = IFNULL(@drop_fk_transactions, 'SELECT "No FK to drop on transactions" as info');
PREPARE stmt FROM @drop_fk_transactions;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================================
-- STEP 3: Add indexes if they don't exist (required for foreign keys)
-- ============================================================================

-- Add index on payments.student_id if not exists
SET @index_check = (
    SELECT COUNT(*)
    FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'payments'
    AND COLUMN_NAME = 'student_id'
);

SET @create_index = IF(@index_check = 0, 
    'ALTER TABLE `payments` ADD INDEX `idx_student_id` (`student_id`)',
    'SELECT "Index already exists on payments.student_id" as info'
);
PREPARE stmt FROM @create_index;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add index on student_assessments.student_id if not exists
SET @index_check = (
    SELECT COUNT(*)
    FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'student_assessments'
    AND COLUMN_NAME = 'student_id'
);

SET @create_index = IF(@index_check = 0, 
    'ALTER TABLE `student_assessments` ADD INDEX `idx_student_id` (`student_id`)',
    'SELECT "Index already exists on student_assessments.student_id" as info'
);
PREPARE stmt FROM @create_index;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================================
-- STEP 4: Add CASCADE DELETE foreign keys
-- ============================================================================

-- Payments table
ALTER TABLE `payments`
ADD CONSTRAINT `fk_payments_student_cascade` 
FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) 
ON DELETE CASCADE ON UPDATE CASCADE;

-- Student assessments table
ALTER TABLE `student_assessments`
ADD CONSTRAINT `fk_assessments_student_cascade` 
FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) 
ON DELETE CASCADE ON UPDATE CASCADE;

-- Attendance table
ALTER TABLE `attendance`
ADD CONSTRAINT `fk_attendance_student_cascade` 
FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) 
ON DELETE CASCADE ON UPDATE CASCADE;

-- Student_parents table
ALTER TABLE `student_parents`
ADD CONSTRAINT `fk_student_parents_student_cascade` 
FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) 
ON DELETE CASCADE ON UPDATE CASCADE;

-- Transactions table
ALTER TABLE `transactions`
ADD CONSTRAINT `fk_transactions_student_cascade` 
FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) 
ON DELETE CASCADE ON UPDATE CASCADE;

-- Marks table (if exists)
SET @marks_exists = (
    SELECT COUNT(*) 
    FROM information_schema.tables 
    WHERE table_schema = DATABASE() 
    AND table_name = 'marks'
);

SET @add_fk_marks = IF(@marks_exists > 0,
    'ALTER TABLE `marks` ADD CONSTRAINT `fk_marks_student_cascade` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE',
    'SELECT "Marks table does not exist" as info'
);
PREPARE stmt FROM @add_fk_marks;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Show all CASCADE DELETE constraints
SELECT 
    TABLE_NAME,
    CONSTRAINT_NAME,
    REFERENCED_TABLE_NAME,
    DELETE_RULE,
    UPDATE_RULE
FROM information_schema.REFERENTIAL_CONSTRAINTS
WHERE CONSTRAINT_SCHEMA = DATABASE()
AND REFERENCED_TABLE_NAME = 'students'
AND DELETE_RULE = 'CASCADE';

SELECT 'CASCADE DELETE constraints added successfully!' as status;
SELECT 'When you delete a student, all related records will be automatically deleted!' as warning;

-- ============================================================================
-- TEST QUERY (DO NOT RUN ON PRODUCTION!)
-- ============================================================================

-- To test cascade delete on a test student:
-- DELETE FROM students WHERE student_id = [TEST_ID];

-- ============================================================================
