-- Search and Filtering Tables

CREATE TABLE IF NOT EXISTS `saved_searches` (
  `search_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `school_id` INT NOT NULL,
  `search_name` VARCHAR(100) NOT NULL,
  `search_type` VARCHAR(50) NOT NULL,
  `filters` JSON,
  `is_public` BOOLEAN DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_user_school` (`user_id`, `school_id`),
  INDEX `idx_search_type` (`search_type`),
  INDEX `idx_created_at` (`created_at`)
);

CREATE TABLE IF NOT EXISTS `search_history` (
  `history_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `school_id` INT NOT NULL,
  `search_term` VARCHAR(255),
  `search_type` VARCHAR(50),
  `filters` JSON,
  `results_count` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_user_school` (`user_id`, `school_id`),
  INDEX `idx_created_at` (`created_at`)
);

CREATE TABLE IF NOT EXISTS `search_filters` (
  `filter_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `filter_name` VARCHAR(100) NOT NULL,
  `filter_type` VARCHAR(50) NOT NULL,
  `filter_config` JSON,
  `created_by` INT,
  `is_system` BOOLEAN DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_type` (`school_id`, `filter_type`),
  INDEX `idx_is_system` (`is_system`)
);
