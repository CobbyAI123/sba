-- Update Score Calculation Formula
-- New Formula: [(CA + Mid-Term) × 0.5] + [Exam × 0.5] = Total Score (Max 100%)
-- CA: 60 marks, Mid-Term: 40 marks, Exam: 100 marks
-- Date: November 5, 2024

-- Step 1: Ensure all required columns exist
ALTER TABLE student_assessments 
MODIFY COLUMN ca_max DECIMAL(5,2) DEFAULT 60.00;

ALTER TABLE student_assessments 
MODIFY COLUMN midterm_max DECIMAL(5,2) DEFAULT 40.00;

ALTER TABLE student_assessments 
MODIFY COLUMN exam_max DECIMAL(5,2) DEFAULT 100.00;

-- Step 2: Drop old total_score if it's a generated column
ALTER TABLE student_assessments 
DROP COLUMN IF EXISTS total_score;

-- Step 3: Add total_score as regular column
ALTER TABLE student_assessments 
ADD COLUMN total_score DECIMAL(5,2) DEFAULT NULL AFTER exam_max;

-- Step 4: Drop old triggers
DROP TRIGGER IF EXISTS calculate_scores_before_insert;
DROP TRIGGER IF EXISTS calculate_scores_before_update;

DELIMITER $$

-- Step 5: Create new INSERT trigger with updated formula
CREATE TRIGGER calculate_scores_before_insert
BEFORE INSERT ON student_assessments
FOR EACH ROW
BEGIN
    -- Set default max scores
    SET NEW.ca_max = 60;
    SET NEW.midterm_max = 40;
    SET NEW.exam_max = 100;
    
    -- Calculate total score: [(CA + Mid-Term) × 0.5] + [Exam × 0.5]
    -- Ensure it doesn't exceed 100
    SET NEW.total_score = LEAST(
        ROUND(
            ((COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5) + 
            (COALESCE(NEW.exam_score, 0) * 0.5),
            2
        ),
        100.00
    );
    
    -- Calculate grade based on total score
    SET NEW.grade = CASE
        WHEN NEW.total_score >= 90 THEN 'A+'
        WHEN NEW.total_score >= 80 THEN 'A'
        WHEN NEW.total_score >= 75 THEN 'B+'
        WHEN NEW.total_score >= 70 THEN 'B'
        WHEN NEW.total_score >= 65 THEN 'C+'
        WHEN NEW.total_score >= 60 THEN 'C'
        WHEN NEW.total_score >= 50 THEN 'D'
        ELSE 'F'
    END;
    
    -- Calculate remark based on total score
    SET NEW.remark = CASE
        WHEN NEW.total_score >= 80 THEN 'Excellent'
        WHEN NEW.total_score >= 70 THEN 'Very Good'
        WHEN NEW.total_score >= 60 THEN 'Good'
        WHEN NEW.total_score >= 50 THEN 'Fair'
        ELSE 'Fail'
    END;
END$$

-- Step 6: Create new UPDATE trigger with updated formula
CREATE TRIGGER calculate_scores_before_update
BEFORE UPDATE ON student_assessments
FOR EACH ROW
BEGIN
    -- Set default max scores
    SET NEW.ca_max = 60;
    SET NEW.midterm_max = 40;
    SET NEW.exam_max = 100;
    
    -- Calculate total score: [(CA + Mid-Term) × 0.5] + [Exam × 0.5]
    -- Ensure it doesn't exceed 100
    SET NEW.total_score = LEAST(
        ROUND(
            ((COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5) + 
            (COALESCE(NEW.exam_score, 0) * 0.5),
            2
        ),
        100.00
    );
    
    -- Calculate grade based on total score
    SET NEW.grade = CASE
        WHEN NEW.total_score >= 90 THEN 'A+'
        WHEN NEW.total_score >= 80 THEN 'A'
        WHEN NEW.total_score >= 75 THEN 'B+'
        WHEN NEW.total_score >= 70 THEN 'B'
        WHEN NEW.total_score >= 65 THEN 'C+'
        WHEN NEW.total_score >= 60 THEN 'C'
        WHEN NEW.total_score >= 50 THEN 'D'
        ELSE 'F'
    END;
    
    -- Calculate remark based on total score
    SET NEW.remark = CASE
        WHEN NEW.total_score >= 80 THEN 'Excellent'
        WHEN NEW.total_score >= 70 THEN 'Very Good'
        WHEN NEW.total_score >= 60 THEN 'Good'
        WHEN NEW.total_score >= 50 THEN 'Fair'
        ELSE 'Fail'
    END;
END$$

DELIMITER ;

-- Step 7: Recalculate existing scores with new formula
UPDATE student_assessments
SET total_score = LEAST(
    ROUND(
        ((COALESCE(ca_score, 0) + COALESCE(midterm_score, 0)) * 0.5) + 
        (COALESCE(exam_score, 0) * 0.5),
        2
    ),
    100.00
);

-- Step 8: Update grades and remarks for existing records
UPDATE student_assessments
SET grade = CASE
    WHEN total_score >= 90 THEN 'A+'
    WHEN total_score >= 80 THEN 'A'
    WHEN total_score >= 75 THEN 'B+'
    WHEN total_score >= 70 THEN 'B'
    WHEN total_score >= 65 THEN 'C+'
    WHEN total_score >= 60 THEN 'C'
    WHEN total_score >= 50 THEN 'D'
    ELSE 'F'
END,
remark = CASE
    WHEN total_score >= 80 THEN 'Excellent'
    WHEN total_score >= 70 THEN 'Very Good'
    WHEN total_score >= 60 THEN 'Good'
    WHEN total_score >= 50 THEN 'Fair'
    ELSE 'Fail'
END
WHERE total_score IS NOT NULL;

-- Success message
SELECT 'Score calculation updated successfully!' as Result;
SELECT 'New Formula: [(CA + Mid-Term) × 0.5] + [Exam × 0.5] = Total Score (Max 100%)' as Formula;

-- Test examples
SELECT '
CALCULATION EXAMPLES:
--------------------
CA: 60, Mid-Term: 40, Exam: 100
→ Total: [(60+40)×0.5] + [100×0.5] = 50 + 50 = 100%

CA: 50, Mid-Term: 30, Exam: 80
→ Total: [(50+30)×0.5] + [80×0.5] = 40 + 40 = 80%

CA: 40, Mid-Term: 25, Exam: 70
→ Total: [(40+25)×0.5] + [70×0.5] = 32.5 + 35 = 67.5%

WEIGHT DISTRIBUTION:
-------------------
Continuous Assessment (CA + Mid-Term): 50%
  - CA: 60 marks
  - Mid-Term: 40 marks
  - Combined: 100 marks × 0.5 = 50%

Final Exam: 50%
  - Exam: 100 marks × 0.5 = 50%

Total: 100%
' as Examples;
