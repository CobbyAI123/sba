-- Security Updates for School Management System
-- Run this after importing schema.sql

USE school_management_system;


-- Add indexes for better performance
ALTER TABLE students ADD INDEX idx_school_class (school_id, class_id);
ALTER TABLE students ADD INDEX idx_admission (admission_number);
ALTER TABLE attendance ADD INDEX idx_date (date);
ALTER TABLE attendance ADD INDEX idx_student (student_id);
ALTER TABLE payments ADD INDEX idx_status_date (status, payment_date);
ALTER TABLE payments ADD INDEX idx_student (student_id);
ALTER TABLE marks ADD INDEX idx_student_exam (student_id, exam_id);
ALTER TABLE notifications ADD INDEX idx_user_read (user_id, is_read);
ALTER TABLE activity_logs ADD INDEX idx_user_time (user_id, created_at);

-- Add first_login flag to users table for password change enforcement
ALTER TABLE users ADD COLUMN first_login BOOLEAN DEFAULT TRUE AFTER status;

-- Update existing users to not require password change
UPDATE users SET first_login = FALSE WHERE user_id IS NOT NULL;

-- Create logs directory structure (done via PHP, but documented here)
-- mkdir logs/
-- chmod 755 logs/

-- Success message
SELECT 'Security updates applied successfully!' as message;
