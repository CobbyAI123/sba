-- ============================================================================
-- ADD MISSING COLUMNS TO EXISTING LIBRARY TABLES
-- Run this if you have library tables but missing columns
-- Date: November 12, 2025
-- ============================================================================

-- Add missing columns to library_books
ALTER TABLE `library_books` 
ADD COLUMN IF NOT EXISTS `total_copies` INT(3) DEFAULT 1 AFTER `publication_year`;

ALTER TABLE `library_books` 
ADD COLUMN IF NOT EXISTS `available_copies` INT(3) DEFAULT 1 AFTER `total_copies`;

ALTER TABLE `library_books` 
ADD COLUMN IF NOT EXISTS `book_location` VARCHAR(100) NULL COMMENT 'Shelf/Section' AFTER `available_copies`;

ALTER TABLE `library_books` 
ADD COLUMN IF NOT EXISTS `description` TEXT NULL AFTER `book_location`;

ALTER TABLE `library_books` 
ADD COLUMN IF NOT EXISTS `cover_image` VARCHAR(255) NULL AFTER `description`;

ALTER TABLE `library_books` 
ADD COLUMN IF NOT EXISTS `price` DECIMAL(10,2) NULL AFTER `cover_image`;

ALTER TABLE `library_books` 
ADD COLUMN IF NOT EXISTS `edition` VARCHAR(50) NULL AFTER `category`;

-- Ensure status column has correct ENUM values
ALTER TABLE `library_books` 
MODIFY COLUMN `status` ENUM('available', 'unavailable', 'damaged', 'lost') DEFAULT 'available';

-- ============================================================================
-- Add missing columns to library_issues
-- ============================================================================

ALTER TABLE `library_issues` 
ADD COLUMN IF NOT EXISTS `book_condition_on_issue` ENUM('excellent', 'good', 'fair', 'poor') DEFAULT 'good' AFTER `status`;

ALTER TABLE `library_issues` 
ADD COLUMN IF NOT EXISTS `book_condition_on_return` ENUM('excellent', 'good', 'fair', 'poor') NULL AFTER `book_condition_on_issue`;

ALTER TABLE `library_issues` 
ADD COLUMN IF NOT EXISTS `fine_amount` DECIMAL(10,2) DEFAULT 0.00 AFTER `book_condition_on_return`;

ALTER TABLE `library_issues` 
ADD COLUMN IF NOT EXISTS `fine_paid` DECIMAL(10,2) DEFAULT 0.00 AFTER `fine_amount`;

ALTER TABLE `library_issues` 
ADD COLUMN IF NOT EXISTS `fine_status` ENUM('none', 'pending', 'paid', 'waived') DEFAULT 'none' AFTER `fine_paid`;

ALTER TABLE `library_issues` 
ADD COLUMN IF NOT EXISTS `notes` TEXT NULL AFTER `fine_status`;

-- Ensure status column has correct values
ALTER TABLE `library_issues` 
MODIFY COLUMN `status` ENUM('issued', 'returned', 'overdue', 'lost') DEFAULT 'issued';

-- ============================================================================
-- Create library_settings table if it doesn't exist
-- ============================================================================

CREATE TABLE IF NOT EXISTS `library_settings` (
  `setting_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `max_books_per_student` INT(2) DEFAULT 3,
  `issue_duration_days` INT(3) DEFAULT 14,
  `fine_per_day` DECIMAL(10,2) DEFAULT 5.00,
  `renewal_allowed` TINYINT(1) DEFAULT 1,
  `max_renewals` INT(1) DEFAULT 2,
  `reminder_days_before_due` INT(2) DEFAULT 2,
  `auto_calculate_fines` TINYINT(1) DEFAULT 1,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default settings for all schools
INSERT INTO `library_settings` 
(`school_id`, `max_books_per_student`, `issue_duration_days`, `fine_per_day`, `renewal_allowed`, `max_renewals`)
SELECT school_id, 3, 14, 5.00, 1, 2
FROM schools
WHERE school_id NOT IN (SELECT school_id FROM library_settings)
ON DUPLICATE KEY UPDATE setting_id=setting_id;

-- ============================================================================
-- Create library_categories table if it doesn't exist
-- ============================================================================

CREATE TABLE IF NOT EXISTS `library_categories` (
  `category_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `category_name` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `idx_school_category` (`school_id`, `category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default categories
INSERT IGNORE INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Fiction', 'Fiction novels and stories'
FROM schools s;

INSERT IGNORE INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Non-Fiction', 'Non-fiction books and references'
FROM schools s;

INSERT IGNORE INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Science', 'Science and technology books'
FROM schools s;

INSERT IGNORE INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Mathematics', 'Mathematics and related books'
FROM schools s;

INSERT IGNORE INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Literature', 'Classic and modern literature'
FROM schools s;

INSERT IGNORE INTO `library_categories` (`school_id`, `category_name`, `description`)
SELECT s.school_id, 'Reference', 'Dictionaries, encyclopedias, reference books'
FROM schools s;

-- ============================================================================
-- Create or update triggers
-- ============================================================================

DELIMITER //

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS after_book_issue//
DROP TRIGGER IF EXISTS after_book_return//

-- Trigger to update book availability when issued
CREATE TRIGGER after_book_issue
AFTER INSERT ON library_issues
FOR EACH ROW
BEGIN
    IF NEW.status = 'issued' THEN
        UPDATE library_books 
        SET available_copies = available_copies - 1
        WHERE book_id = NEW.book_id AND available_copies > 0;
    END IF;
END//

-- Trigger to update book availability when returned
CREATE TRIGGER after_book_return
AFTER UPDATE ON library_issues
FOR EACH ROW
BEGIN
    IF OLD.status = 'issued' AND NEW.status = 'returned' THEN
        UPDATE library_books 
        SET available_copies = available_copies + 1
        WHERE book_id = NEW.book_id;
    END IF;
END//

DELIMITER ;

-- ============================================================================
-- Update existing books to have proper copies count
-- ============================================================================

-- Set available_copies equal to total_copies for books with NULL available_copies
UPDATE library_books 
SET available_copies = total_copies 
WHERE available_copies IS NULL OR available_copies = 0;

-- ============================================================================
-- Add indexes for better performance
-- ============================================================================

-- Check and add indexes if they don't exist
ALTER TABLE `library_books` ADD INDEX IF NOT EXISTS `idx_school` (`school_id`);
ALTER TABLE `library_books` ADD INDEX IF NOT EXISTS `idx_title` (`title`);
ALTER TABLE `library_books` ADD INDEX IF NOT EXISTS `idx_category` (`category`);
ALTER TABLE `library_books` ADD INDEX IF NOT EXISTS `idx_status` (`status`);

ALTER TABLE `library_issues` ADD INDEX IF NOT EXISTS `idx_school` (`school_id`);
ALTER TABLE `library_issues` ADD INDEX IF NOT EXISTS `idx_book` (`book_id`);
ALTER TABLE `library_issues` ADD INDEX IF NOT EXISTS `idx_student` (`student_id`);
ALTER TABLE `library_issues` ADD INDEX IF NOT EXISTS `idx_status` (`status`);
ALTER TABLE `library_issues` ADD INDEX IF NOT EXISTS `idx_due_date` (`due_date`);

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT 'Library system columns added/updated successfully!' as status;
SELECT COUNT(*) as total_books FROM library_books;
SELECT COUNT(*) as total_issues FROM library_issues;
SELECT COUNT(*) as categories FROM library_categories;
