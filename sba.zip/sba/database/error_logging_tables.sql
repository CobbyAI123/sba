-- Error Logging Tables

CREATE TABLE IF NOT EXISTS `error_logs` (
  `log_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT,
  `message` VARCHAR(255),
  `level` VARCHAR(20) DEFAULT 'ERROR',
  `context` JSON,
  `ip_address` VARCHAR(45),
  `user_agent` VARCHAR(255),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_level` (`level`),
  INDEX `idx_created_at` (`created_at`),
  INDEX `idx_user_id` (`user_id`)
);

CREATE TABLE IF NOT EXISTS `activity_audit_log` (
  `audit_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT,
  `action` VARCHAR(255),
  `table_name` VARCHAR(50),
  `record_id` INT,
  `old_values` JSON,
  `new_values` JSON,
  `ip_address` VARCHAR(45),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_user_id` (`user_id`),
  INDEX `idx_table_name` (`table_name`),
  INDEX `idx_created_at` (`created_at`)
);
