-- Auto-Calculate Total Scores and Grades
-- This trigger automatically calculates total_score, grade, and remark when scores are inserted or updated

DELIMITER $$

-- Drop existing triggers if they exist
DROP TRIGGER IF EXISTS calculate_scores_before_insert$$
DROP TRIGGER IF EXISTS calculate_scores_before_update$$

-- Trigger for INSERT
CREATE TRIGGER calculate_scores_before_insert
BEFORE INSERT ON student_assessments
FOR EACH ROW
BEGIN
    -- Calculate total score (CA + Midterm + Exam)
    SET NEW.total_score = COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0) + COALESCE(NEW.exam_score, 0);
    
    -- Calculate grade based on total
    SET NEW.grade = CASE
        WHEN NEW.total_score >= 90 THEN 'A+'
        WHEN NEW.total_score >= 80 THEN 'A'
        WHEN NEW.total_score >= 75 THEN 'B+'
        WHEN NEW.total_score >= 70 THEN 'B'
        WHEN NEW.total_score >= 65 THEN 'C+'
        WHEN NEW.total_score >= 60 THEN 'C'
        WHEN NEW.total_score >= 50 THEN 'D'
        ELSE 'F'
    END;
    
    -- Calculate remark based on total
    SET NEW.remark = CASE
        WHEN NEW.total_score >= 80 THEN 'Excellent'
        WHEN NEW.total_score >= 70 THEN 'Very Good'
        WHEN NEW.total_score >= 60 THEN 'Good'
        WHEN NEW.total_score >= 50 THEN 'Fair'
        ELSE 'Fail'
    END;
    
    -- Set max scores
    SET NEW.ca_max = 20;
    SET NEW.midterm_max = 20;
    SET NEW.exam_max = 60;
    SET NEW.total_max = 100;
END$$

-- Trigger for UPDATE
CREATE TRIGGER calculate_scores_before_update
BEFORE UPDATE ON student_assessments
FOR EACH ROW
BEGIN
    -- Calculate total score (CA + Midterm + Exam)
    SET NEW.total_score = COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0) + COALESCE(NEW.exam_score, 0);
    
    -- Calculate grade based on total
    SET NEW.grade = CASE
        WHEN NEW.total_score >= 90 THEN 'A+'
        WHEN NEW.total_score >= 80 THEN 'A'
        WHEN NEW.total_score >= 75 THEN 'B+'
        WHEN NEW.total_score >= 70 THEN 'B'
        WHEN NEW.total_score >= 65 THEN 'C+'
        WHEN NEW.total_score >= 60 THEN 'C'
        WHEN NEW.total_score >= 50 THEN 'D'
        ELSE 'F'
    END;
    
    -- Calculate remark based on total
    SET NEW.remark = CASE
        WHEN NEW.total_score >= 80 THEN 'Excellent'
        WHEN NEW.total_score >= 70 THEN 'Very Good'
        WHEN NEW.total_score >= 60 THEN 'Good'
        WHEN NEW.total_score >= 50 THEN 'Fair'
        ELSE 'Fail'
    END;
    
    -- Set max scores
    SET NEW.ca_max = 20;
    SET NEW.midterm_max = 20;
    SET NEW.exam_max = 60;
    SET NEW.total_max = 100;
END$$

DELIMITER ;

-- Success message
SELECT 'Auto-calculation triggers created successfully!' as Result;

-- Test the triggers (optional)
-- You can uncomment these lines to test:
/*
-- Insert test record
INSERT INTO student_assessments (school_id, student_id, class_id, subject_id, term_id, teacher_id, ca_score, midterm_score, exam_score)
VALUES (1, 1, 1, 1, 1, 1, 18, 17, 55);

-- Check the result
SELECT student_id, ca_score, midterm_score, exam_score, total_score, grade, remark 
FROM student_assessments 
WHERE student_id = 1 AND subject_id = 1 AND term_id = 1;

-- Update test
UPDATE student_assessments 
SET exam_score = 60 
WHERE student_id = 1 AND subject_id = 1 AND term_id = 1;

-- Check updated result
SELECT student_id, ca_score, midterm_score, exam_score, total_score, grade, remark 
FROM student_assessments 
WHERE student_id = 1 AND subject_id = 1 AND term_id = 1;
*/
