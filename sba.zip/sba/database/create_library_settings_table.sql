-- ================================================================================
-- CREATE LIBRARY SETTINGS TABLE
-- Date: November 17, 2025
-- Purpose: Create library_settings table for library configuration
-- ================================================================================

-- Create library_settings table
CREATE TABLE IF NOT EXISTS `library_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `max_books_per_student` int(11) DEFAULT 3 COMMENT 'Maximum books a student can borrow at once',
  `max_borrow_days` int(11) DEFAULT 14 COMMENT 'Maximum days to borrow a book',
  `fine_per_day` decimal(10,2) DEFAULT 0.50 COMMENT 'Fine amount per day for overdue books',
  `allow_renewals` tinyint(1) DEFAULT 1 COMMENT 'Allow book renewals',
  `max_renewals` int(11) DEFAULT 2 COMMENT 'Maximum number of renewals allowed',
  `renewal_days` int(11) DEFAULT 7 COMMENT 'Additional days granted on renewal',
  `librarian_email` varchar(255) DEFAULT NULL COMMENT 'Librarian contact email',
  `library_phone` varchar(20) DEFAULT NULL COMMENT 'Library contact phone',
  `opening_time` time DEFAULT '08:00:00' COMMENT 'Library opening time',
  `closing_time` time DEFAULT '17:00:00' COMMENT 'Library closing time',
  `working_days` varchar(100) DEFAULT 'Monday,Tuesday,Wednesday,Thursday,Friday' COMMENT 'Library working days',
  `late_return_notification` tinyint(1) DEFAULT 1 COMMENT 'Send late return notifications',
  `notification_days_before` int(11) DEFAULT 2 COMMENT 'Days before due date to send reminder',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_id`),
  KEY `school_id` (`school_id`),
  CONSTRAINT `library_settings_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Library configuration settings';

-- Insert default settings for existing schools
INSERT INTO `library_settings` (
  `school_id`, 
  `max_books_per_student`, 
  `max_borrow_days`, 
  `fine_per_day`,
  `allow_renewals`,
  `max_renewals`,
  `renewal_days`,
  `opening_time`,
  `closing_time`,
  `working_days`,
  `late_return_notification`,
  `notification_days_before`
)
SELECT 
  school_id,
  3,
  14,
  0.50,
  1,
  2,
  7,
  '08:00:00',
  '17:00:00',
  'Monday,Tuesday,Wednesday,Thursday,Friday',
  1,
  2
FROM schools
WHERE school_id NOT IN (SELECT school_id FROM library_settings);

-- Success message
SELECT 'Library settings table created successfully!' as Result;
