-- ============================================
-- SIMPLE AUTO CREATE - ALL MISSING STUDENTS
-- Works with any students table structure
-- ============================================

USE school_management_system;

-- Step 1: Show students that need records
SELECT 
    u.user_id,
    u.username,
    u.first_name,
    u.last_name,
    u.school_id,
    '❌ Missing student record' as status
FROM users u
LEFT JOIN students s ON u.user_id = s.user_id
WHERE u.role = 'student' 
AND s.student_id IS NULL;

-- Step 2: Create all missing student records
INSERT INTO students (user_id, school_id, admission_number, class_id, status)
SELECT 
    u.user_id,
    u.school_id,
    CONCAT('ADM', u.school_id, LPAD(u.user_id, 5, '0')) as admission_number,
    (SELECT class_id FROM classes WHERE school_id = u.school_id ORDER BY class_id LIMIT 1) as class_id,
    'active' as status
FROM users u
LEFT JOIN students s ON u.user_id = s.user_id
WHERE u.role = 'student' 
AND s.student_id IS NULL;

-- Step 3: Show all students with their records
SELECT 
    u.user_id,
    u.username,
    CONCAT(u.first_name, ' ', u.last_name) as name,
    s.student_id,
    s.admission_number,
    c.class_name,
    s.status,
    '✓ Has student record' as result
FROM users u
INNER JOIN students s ON u.user_id = s.user_id
LEFT JOIN classes c ON s.class_id = c.class_id
WHERE u.role = 'student'
ORDER BY u.user_id;

-- Step 4: Final count
SELECT 
    COUNT(DISTINCT u.user_id) as total_student_users,
    COUNT(DISTINCT s.student_id) as with_student_record,
    COUNT(DISTINCT u.user_id) - COUNT(DISTINCT s.student_id) as still_missing
FROM users u
LEFT JOIN students s ON u.user_id = s.user_id
WHERE u.role = 'student';

-- Success message
SELECT 
    CASE 
        WHEN (SELECT COUNT(*) FROM users u LEFT JOIN students s ON u.user_id = s.user_id WHERE u.role = 'student' AND s.student_id IS NULL) = 0
        THEN '✓ SUCCESS! All students now have records. They can login and see their data.'
        ELSE '⚠️ Some students still missing records. Check if classes exist for their schools.'
    END as final_status;
