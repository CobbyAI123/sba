-- ============================================
-- CREATE EXAM SYSTEM TABLES
-- Creates all tables needed for exam/marks system
-- ============================================

-- 1. EXAMS TABLE
CREATE TABLE IF NOT EXISTS `exams` (
  `exam_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `term_id` int(11) NOT NULL,
  `exam_name` varchar(100) NOT NULL,
  `exam_type` enum('CA','Test','Mid-Term','End-of-Term','Final') DEFAULT 'Test',
  `exam_date` date DEFAULT NULL,
  `total_marks` decimal(5,2) DEFAULT 100.00,
  `description` text DEFAULT NULL,
  `status` enum('scheduled','ongoing','completed','cancelled') DEFAULT 'scheduled',
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`exam_id`),
  KEY `school_id` (`school_id`),
  KEY `term_id` (`term_id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Exam definitions';

-- 2. MARKS TABLE
CREATE TABLE IF NOT EXISTS `marks` (
  `mark_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `marks_obtained` decimal(5,2) NOT NULL,
  `total_marks` decimal(5,2) NOT NULL DEFAULT 100.00,
  `percentage` decimal(5,2) GENERATED ALWAYS AS ((`marks_obtained` / `total_marks`) * 100) STORED,
  `grade` varchar(5) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `entered_by` int(11) DEFAULT NULL COMMENT 'User ID of teacher who entered the marks',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mark_id`),
  UNIQUE KEY `unique_mark` (`student_id`,`exam_id`,`subject_id`),
  KEY `student_id` (`student_id`),
  KEY `exam_id` (`exam_id`),
  KEY `subject_id` (`subject_id`),
  KEY `entered_by` (`entered_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Student exam marks';

-- 3. Add foreign keys if tables exist
-- Note: These will only work if the referenced tables exist

SET FOREIGN_KEY_CHECKS = 0;

-- Marks foreign keys
ALTER TABLE `marks` 
  DROP FOREIGN KEY IF EXISTS `marks_student_fk`,
  DROP FOREIGN KEY IF EXISTS `marks_exam_fk`,
  DROP FOREIGN KEY IF EXISTS `marks_subject_fk`,
  DROP FOREIGN KEY IF EXISTS `marks_user_fk`;

ALTER TABLE `marks`
  ADD CONSTRAINT `marks_student_fk` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `marks_exam_fk` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`exam_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `marks_subject_fk` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `marks_user_fk` FOREIGN KEY (`entered_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

-- Exams foreign keys
ALTER TABLE `exams`
  DROP FOREIGN KEY IF EXISTS `exams_school_fk`,
  DROP FOREIGN KEY IF EXISTS `exams_term_fk`,
  DROP FOREIGN KEY IF EXISTS `exams_user_fk`;

ALTER TABLE `exams`
  ADD CONSTRAINT `exams_school_fk` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `exams_term_fk` FOREIGN KEY (`term_id`) REFERENCES `terms` (`term_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `exams_user_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

SET FOREIGN_KEY_CHECKS = 1;

-- Verify tables were created
SHOW TABLES LIKE '%exam%';
SHOW TABLES LIKE '%mark%';

SELECT 'SUCCESS: Exam system tables created!' as Status;
