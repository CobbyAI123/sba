-- ============================================================================
-- MESSAGING SYSTEM DATABASE TABLES
-- Create tables for internal school messaging system
-- Date: November 11, 2025
-- ============================================================================

-- Messages Table
CREATE TABLE IF NOT EXISTS `messages` (
  `message_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `sender_id` INT(11) NOT NULL COMMENT 'User ID of sender',
  `recipient_id` INT(11) NULL COMMENT 'NULL for broadcast messages',
  `recipient_role` VARCHAR(50) NULL COMMENT 'For role-based broadcasts: parent, teacher, student, etc.',
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `attachment` VARCHAR(255) NULL,
  `message_type` ENUM('personal', 'broadcast', 'announcement') DEFAULT 'personal',
  `priority` ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
  `read_status` ENUM('unread', 'read') DEFAULT 'unread',
  `replied_to` INT(11) NULL COMMENT 'If this is a reply, original message_id',
  `deleted_by_sender` TINYINT(1) DEFAULT 0,
  `deleted_by_recipient` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `read_at` TIMESTAMP NULL,
  PRIMARY KEY (`message_id`),
  KEY `idx_school_sender` (`school_id`, `sender_id`),
  KEY `idx_school_recipient` (`school_id`, `recipient_id`),
  KEY `idx_read_status` (`read_status`),
  KEY `idx_message_type` (`message_type`),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`sender_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`recipient_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Message Attachments Table (for multiple attachments)
CREATE TABLE IF NOT EXISTS `message_attachments` (
  `attachment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `message_id` INT(11) NOT NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_size` INT(11) NULL COMMENT 'Size in bytes',
  `file_type` VARCHAR(50) NULL,
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attachment_id`),
  KEY `idx_message` (`message_id`),
  FOREIGN KEY (`message_id`) REFERENCES `messages`(`message_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Message Templates Table
CREATE TABLE IF NOT EXISTS `message_templates` (
  `template_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `created_by` INT(11) NOT NULL,
  `template_name` VARCHAR(100) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `category` VARCHAR(50) NULL COMMENT 'fee_reminder, exam_notification, etc.',
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`template_id`),
  KEY `idx_school` (`school_id`),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Notification System Table
CREATE TABLE IF NOT EXISTS `notifications` (
  `notification_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `type` VARCHAR(50) NOT NULL COMMENT 'message, fee, exam, attendance, etc.',
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `link` VARCHAR(255) NULL COMMENT 'Link to related page',
  `icon` VARCHAR(50) NULL COMMENT 'Icon class name',
  `color` VARCHAR(20) NULL COMMENT 'Badge color',
  `read_status` ENUM('unread', 'read') DEFAULT 'unread',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `read_at` TIMESTAMP NULL,
  PRIMARY KEY (`notification_id`),
  KEY `idx_school_user` (`school_id`, `user_id`),
  KEY `idx_read_status` (`read_status`),
  KEY `idx_type` (`type`),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- SMS Logs Table
CREATE TABLE IF NOT EXISTS `sms_logs` (
  `sms_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NULL COMMENT 'Recipient user if applicable',
  `recipient_phone` VARCHAR(20) NOT NULL,
  `message` TEXT NOT NULL,
  `sms_type` VARCHAR(50) NULL COMMENT 'fee_reminder, result_notification, etc.',
  `status` ENUM('pending', 'sent', 'failed', 'delivered') DEFAULT 'pending',
  `gateway` VARCHAR(50) NULL COMMENT 'twilio, africastalking, etc.',
  `gateway_response` TEXT NULL,
  `cost` DECIMAL(10,4) NULL COMMENT 'Cost per SMS',
  `sent_at` TIMESTAMP NULL,
  `delivered_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sms_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Email Logs Table
CREATE TABLE IF NOT EXISTS `email_logs` (
  `email_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NULL COMMENT 'Recipient user if applicable',
  `recipient_email` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `email_type` VARCHAR(50) NULL,
  `status` ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
  `sent_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`email_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- INSERT SAMPLE DATA (Optional - for testing)
-- ============================================================================

-- Sample notification
INSERT INTO `notifications` 
(`school_id`, `user_id`, `type`, `title`, `message`, `link`, `icon`, `color`, `read_status`) 
VALUES 
(1, 1, 'system', 'Messaging System Activated', 'The internal messaging system is now active. You can now send and receive messages!', '/messages.php', 'fa-envelope', 'primary', 'unread')
ON DUPLICATE KEY UPDATE notification_id=notification_id;

-- Sample message template
INSERT INTO `message_templates`
(`school_id`, `created_by`, `template_name`, `subject`, `message`, `category`)
VALUES
(1, 1, 'Fee Reminder', 'School Fee Payment Reminder', 'Dear Parent,\n\nThis is a reminder that your child''s school fees for the current term are due. Please make payment at your earliest convenience.\n\nThank you for your cooperation.', 'fee_reminder'),
(1, 1, 'Exam Notification', 'Upcoming Examination Notice', 'Dear Student,\n\nThis is to inform you that examinations for the current term will commence on [DATE]. Please ensure you are well prepared.\n\nGood luck!', 'exam'),
(1, 1, 'Result Release', 'Examination Results Released', 'Dear Parent/Student,\n\nExamination results for the term have been released. Please login to your portal to view the results.\n\nThank you.', 'result')
ON DUPLICATE KEY UPDATE template_id=template_id;

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

-- Additional indexes for faster queries
ALTER TABLE `messages` ADD INDEX `idx_created_at` (`created_at` DESC);
ALTER TABLE `notifications` ADD INDEX `idx_created_at` (`created_at` DESC);
ALTER TABLE `sms_logs` ADD INDEX `idx_created_at` (`created_at` DESC);
ALTER TABLE `email_logs` ADD INDEX `idx_created_at` (`created_at` DESC);

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Check if tables were created
SHOW TABLES LIKE '%message%';
SHOW TABLES LIKE '%notification%';
SHOW TABLES LIKE '%sms%';
SHOW TABLES LIKE '%email%';

-- Count records
SELECT COUNT(*) as total_messages FROM messages;
SELECT COUNT(*) as total_notifications FROM notifications;
SELECT COUNT(*) as total_templates FROM message_templates;

-- ============================================================================
-- CLEANUP (Use only if you need to drop tables)
-- ============================================================================

-- DROP TABLE IF EXISTS message_attachments;
-- DROP TABLE IF EXISTS messages;
-- DROP TABLE IF EXISTS message_templates;
-- DROP TABLE IF EXISTS notifications;
-- DROP TABLE IF EXISTS sms_logs;
-- DROP TABLE IF EXISTS email_logs;

-- ============================================================================
-- SUCCESS MESSAGE
-- ============================================================================

SELECT 'Messaging System tables created successfully!' as status;
SELECT 'You can now use the messaging features in the system.' as message;
