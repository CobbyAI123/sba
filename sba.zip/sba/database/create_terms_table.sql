-- Create terms table for academic term management
CREATE TABLE IF NOT EXISTS `terms` (
  `term_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `term_name` varchar(100) NOT NULL,
  `session_year` varchar(20) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_active` tinyint(1) DEFAULT 0,
  `is_current` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`term_id`),
  KEY `school_id` (`school_id`),
  KEY `is_active` (`is_active`),
  KEY `is_current` (`is_current`),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert sample terms for testing (optional)
INSERT IGNORE INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) 
SELECT school_id, 'First Term', '2024/2025', '2024-09-01', '2024-12-15', 1 FROM schools LIMIT 1;

INSERT IGNORE INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) 
SELECT school_id, 'Second Term', '2024/2025', '2025-01-06', '2025-04-15', 0 FROM schools LIMIT 1;

INSERT IGNORE INTO `terms` (`school_id`, `term_name`, `session_year`, `start_date`, `end_date`, `is_active`) 
SELECT school_id, 'Third Term', '2024/2025', '2025-04-28', '2025-07-31', 0 FROM schools LIMIT 1;
