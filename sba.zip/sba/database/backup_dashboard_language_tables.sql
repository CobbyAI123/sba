-- Backup, Dashboard, and Language Support Tables

-- Backup logging tables
CREATE TABLE IF NOT EXISTS `backup_logs` (
  `log_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `filename` VARCHAR(255) NOT NULL,
  `file_size` BIGINT,
  `description` TEXT,
  `status` ENUM('success', 'failed', 'deleted') DEFAULT 'success',
  `error_message` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_school_id` (`school_id`),
  INDEX `idx_status` (`status`),
  INDEX `idx_created_at` (`created_at`)
);

CREATE TABLE IF NOT EXISTS `restore_logs` (
  `log_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `backup_filename` VARCHAR(255) NOT NULL,
  `status` ENUM('success', 'failed') DEFAULT 'success',
  `error_message` TEXT,
  `restored_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_school_id` (`school_id`),
  INDEX `idx_restored_at` (`restored_at`)
);

-- Dashboard and reporting tables
CREATE TABLE IF NOT EXISTS `dashboard_widgets` (
  `widget_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `user_id` INT,
  `widget_type` VARCHAR(50) NOT NULL,
  `widget_config` JSON,
  `position` INT,
  `is_visible` BOOLEAN DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_user` (`school_id`, `user_id`)
);

CREATE TABLE IF NOT EXISTS `saved_reports` (
  `report_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `created_by` INT,
  `report_name` VARCHAR(255) NOT NULL,
  `report_type` VARCHAR(50) NOT NULL,
  `filters` JSON,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_type` (`school_id`, `report_type`),
  INDEX `idx_created_at` (`created_at`)
);

CREATE TABLE IF NOT EXISTS `report_exports` (
  `export_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `exported_by` INT,
  `report_type` VARCHAR(50) NOT NULL,
  `filename` VARCHAR(255),
  `format` ENUM('csv', 'pdf', 'xlsx') DEFAULT 'csv',
  `file_path` VARCHAR(500),
  `exported_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`exported_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_id` (`school_id`),
  INDEX `idx_exported_at` (`exported_at`)
);

-- Language and localization tables
CREATE TABLE IF NOT EXISTS `language_settings` (
  `setting_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `user_id` INT,
  `preferred_language` VARCHAR(10) DEFAULT 'en',
  `timezone` VARCHAR(50) DEFAULT 'UTC',
  `date_format` VARCHAR(20) DEFAULT 'Y-m-d',
  `time_format` VARCHAR(20) DEFAULT 'H:i:s',
  `currency_code` VARCHAR(3) DEFAULT 'GHS',
  `currency_symbol` VARCHAR(5) DEFAULT '₵',
  `thousands_separator` VARCHAR(1) DEFAULT ',',
  `decimal_separator` VARCHAR(1) DEFAULT '.',
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_user` (`school_id`, `user_id`)
);

CREATE TABLE IF NOT EXISTS `translation_strings` (
  `string_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT,
  `language` VARCHAR(10) NOT NULL,
  `translation_key` VARCHAR(255) NOT NULL,
  `translation_value` LONGTEXT NOT NULL,
  `module` VARCHAR(100),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_language_key` (`language`, `translation_key`),
  INDEX `idx_school_module` (`school_id`, `module`),
  UNIQUE KEY `unique_translation` (`school_id`, `language`, `translation_key`)
);

CREATE TABLE IF NOT EXISTS `user_language_preferences` (
  `preference_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `school_id` INT NOT NULL,
  `language` VARCHAR(10) DEFAULT 'en',
  `date_format` VARCHAR(20),
  `time_format` VARCHAR(20),
  `timezone` VARCHAR(50),
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_user_school` (`user_id`, `school_id`),
  UNIQUE KEY `unique_user_school` (`user_id`, `school_id`)
);
