-- ============================================================================
-- SMS AND AUDIT LOGGING TABLES
-- ============================================================================

-- SMS Log Table
CREATE TABLE IF NOT EXISTS `sms_log` (
    `sms_log_id` INT AUTO_INCREMENT PRIMARY KEY,
    `phone` VARCHAR(20) NOT NULL,
    `message` TEXT,
    `sms_type` ENUM('attendance', 'fee', 'alert', 'general') DEFAULT 'general',
    `status` ENUM('pending', 'sent', 'failed', 'queued') DEFAULT 'pending',
    `sms_id` VARCHAR(100),
    `sent_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_phone` (`phone`),
    INDEX `idx_status` (`status`),
    INDEX `idx_sms_type` (`sms_type`),
    INDEX `idx_sent_at` (`sent_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- SMS Queue Table (for local SMS processing)
CREATE TABLE IF NOT EXISTS `sms_queue` (
    `queue_id` INT AUTO_INCREMENT PRIMARY KEY,
    `phone` VARCHAR(20) NOT NULL,
    `message` TEXT,
    `sms_type` VARCHAR(50),
    `status` ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
    `retry_count` INT DEFAULT 0,
    `last_retry` TIMESTAMP NULL,
    `error_message` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `processed_at` TIMESTAMP NULL,
    INDEX `idx_status` (`status`),
    INDEX `idx_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Audit Log Table (tracks all user actions)
CREATE TABLE IF NOT EXISTS `audit_logs` (
    `audit_id` INT AUTO_INCREMENT PRIMARY KEY,
    `school_id` INT,
    `user_id` INT,
    `username` VARCHAR(100),
    `action` VARCHAR(255),
    `table_name` VARCHAR(100),
    `record_id` INT,
    `old_values` JSON,
    `new_values` JSON,
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `status` ENUM('success', 'failed') DEFAULT 'success',
    `error_message` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
    INDEX `idx_school` (`school_id`),
    INDEX `idx_user` (`user_id`),
    INDEX `idx_action` (`action`),
    INDEX `idx_table` (`table_name`),
    INDEX `idx_created` (`created_at`),
    INDEX `idx_record` (`table_name`, `record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Login Attempts Log (for 2FA and security)
CREATE TABLE IF NOT EXISTS `login_attempts` (
    `attempt_id` INT AUTO_INCREMENT PRIMARY KEY,
    `school_id` INT,
    `username` VARCHAR(100),
    `email` VARCHAR(255),
    `ip_address` VARCHAR(45),
    `user_agent` TEXT,
    `attempt_type` ENUM('login', '2fa_otp', 'password_reset') DEFAULT 'login',
    `status` ENUM('success', 'failed') DEFAULT 'failed',
    `failure_reason` VARCHAR(255),
    `otp_sent` TINYINT DEFAULT 0,
    `otp_verified` TINYINT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    INDEX `idx_username` (`username`),
    INDEX `idx_ip` (`ip_address`),
    INDEX `idx_created` (`created_at`),
    INDEX `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Two-Factor Authentication OTP Table
CREATE TABLE IF NOT EXISTS `otp_codes` (
    `otp_id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT,
    `email` VARCHAR(255),
    `phone` VARCHAR(20),
    `otp_code` VARCHAR(6),
    `otp_type` ENUM('email', 'sms') DEFAULT 'email',
    `is_used` TINYINT DEFAULT 0,
    `attempts` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `expires_at` TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
    INDEX `idx_user` (`user_id`),
    INDEX `idx_email` (`email`),
    INDEX `idx_otp` (`otp_code`),
    INDEX `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Payment Plans Table
CREATE TABLE IF NOT EXISTS `payment_plans` (
    `plan_id` INT AUTO_INCREMENT PRIMARY KEY,
    `school_id` INT,
    `student_id` INT,
    `plan_name` VARCHAR(100),
    `total_amount` DECIMAL(10, 2),
    `number_of_installments` INT,
    `installment_amount` DECIMAL(10, 2),
    `first_due_date` DATE,
    `frequency` ENUM('monthly', 'bi-weekly', 'weekly') DEFAULT 'monthly',
    `created_by` INT,
    `status` ENUM('active', 'completed', 'cancelled', 'defaulted') DEFAULT 'active',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
    FOREIGN KEY (`created_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
    INDEX `idx_school` (`school_id`),
    INDEX `idx_student` (`student_id`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Installment Schedule Table
CREATE TABLE IF NOT EXISTS `installment_schedule` (
    `installment_id` INT AUTO_INCREMENT PRIMARY KEY,
    `plan_id` INT,
    `installment_number` INT,
    `amount` DECIMAL(10, 2),
    `due_date` DATE,
    `paid_date` DATE NULL,
    `paid_amount` DECIMAL(10, 2) DEFAULT 0,
    `payment_id` INT,
    `status` ENUM('pending', 'paid', 'overdue', 'partially_paid') DEFAULT 'pending',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`plan_id`) REFERENCES `payment_plans`(`plan_id`) ON DELETE CASCADE,
    FOREIGN KEY (`payment_id`) REFERENCES `payments`(`payment_id`) ON DELETE SET NULL,
    INDEX `idx_plan` (`plan_id`),
    INDEX `idx_due_date` (`due_date`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Student Discipline Table
CREATE TABLE IF NOT EXISTS `student_discipline` (
    `discipline_id` INT AUTO_INCREMENT PRIMARY KEY,
    `school_id` INT,
    `student_id` INT,
    `incident_date` DATE,
    `incident_type` VARCHAR(100),
    `description` TEXT,
    `severity` ENUM('minor', 'moderate', 'major') DEFAULT 'minor',
    `action_taken` VARCHAR(255),
    `recorded_by` INT,
    `parent_notified` TINYINT DEFAULT 0,
    `parent_notified_date` DATETIME NULL,
    `appeal_status` ENUM('none', 'pending', 'approved', 'rejected') DEFAULT 'none',
    `appeal_reason` TEXT,
    `appeal_decision` TEXT,
    `status` ENUM('reported', 'investigated', 'resolved', 'appealed') DEFAULT 'reported',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
    FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
    FOREIGN KEY (`recorded_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
    INDEX `idx_school` (`school_id`),
    INDEX `idx_student` (`student_id`),
    INDEX `idx_incident_date` (`incident_date`),
    INDEX `idx_severity` (`severity`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- UPDATE EXISTING SETTINGS TABLE WITH SMS CONFIGURATION
-- ============================================================================

INSERT IGNORE INTO `settings` (`school_id`, `setting_key`, `setting_value`) VALUES
(1, 'sms_provider', 'twilio'),
(1, 'sms_twilio_sid', ''),
(1, 'sms_twilio_token', ''),
(1, 'sms_twilio_phone', ''),
(1, 'sms_from_name', 'School'),
(1, 'sms_enabled', '0'),
(1, 'sms_attendance_alerts', '1'),
(1, 'sms_fee_reminders', '1'),
(1, 'sms_2fa_enabled', '0'),
(1, '2fa_method', 'email'),
(1, 'audit_logging_enabled', '1'),
(1, 'audit_log_retention_days', '90');

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT '✓ SMS and Audit logging tables created successfully' as Status;
SELECT '✓ Payment Plans and Discipline tables created' as Status;
SELECT '✓ OTP and Login Attempts tables created' as Status;
