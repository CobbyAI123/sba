-- ============================================================================
-- Add class_number column to classes table
-- This allows proper ordering/sorting of classes
-- ============================================================================

USE school_management_system;

-- Add class_number column if it doesn't exist
ALTER TABLE classes 
ADD COLUMN IF NOT EXISTS class_number INT(2) NULL AFTER class_level;

-- Add index for better sorting performance
ALTER TABLE classes 
ADD INDEX IF NOT EXISTS idx_class_number (class_number);

-- Verify the change
DESCRIBE classes;

SELECT 'class_number column added successfully!' AS Status;
