-- ============================================================================
-- ADD MISSING COLUMNS TO PAYMENTS TABLE
-- Fixes: Column not found errors for payment_method, payment_type, etc.
-- ============================================================================

-- Check current table structure
DESCRIBE payments;

-- Add payment_method column if it doesn't exist
ALTER TABLE `payments` 
ADD COLUMN IF NOT EXISTS `payment_method` VARCHAR(50) DEFAULT 'cash' 
COMMENT 'Payment method: cash, bank_transfer, mobile_money, cheque' 
AFTER `amount`;

-- Add payment_type column if it doesn't exist
ALTER TABLE `payments` 
ADD COLUMN IF NOT EXISTS `payment_type` VARCHAR(20) DEFAULT 'tuition' 
COMMENT 'Type: tuition, canteen, bus, library, sports, exam, other' 
AFTER `payment_method`;

-- Add payment_reference column if it doesn't exist
ALTER TABLE `payments` 
ADD COLUMN IF NOT EXISTS `payment_reference` VARCHAR(100) DEFAULT NULL 
COMMENT 'Receipt number, cheque number, or transaction ID' 
AFTER `payment_type`;

-- Add remarks column if it doesn't exist
ALTER TABLE `payments` 
ADD COLUMN IF NOT EXISTS `remarks` TEXT DEFAULT NULL 
COMMENT 'Additional notes about the payment' 
AFTER `payment_reference`;

-- Add payment_date column if it doesn't exist (should already exist)
ALTER TABLE `payments` 
ADD COLUMN IF NOT EXISTS `payment_date` DATE NOT NULL DEFAULT (CURRENT_DATE) 
AFTER `amount`;

-- Add status column if it doesn't exist (should already exist)
ALTER TABLE `payments` 
ADD COLUMN IF NOT EXISTS `status` VARCHAR(20) DEFAULT 'completed' 
COMMENT 'Status: completed, pending, paid, failed, refunded' 
AFTER `remarks`;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_payment_method ON payments(payment_method);
CREATE INDEX IF NOT EXISTS idx_payment_type ON payments(payment_type);
CREATE INDEX IF NOT EXISTS idx_payment_date ON payments(payment_date);
CREATE INDEX IF NOT EXISTS idx_status ON payments(status);

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Show updated table structure
DESCRIBE payments;

SELECT 'Missing columns added successfully!' as status;

-- ============================================================================
-- WHAT WAS ADDED
-- ============================================================================
-- 
-- 1. payment_method - How payment was made (cash, bank transfer, etc.)
-- 2. payment_type - What the payment is for (tuition, canteen, bus, etc.)
-- 3. payment_reference - Receipt/transaction number
-- 4. remarks - Additional notes
-- 5. payment_date - Date of payment (if missing)
-- 6. status - Payment status (if missing)
-- 
-- ============================================================================
