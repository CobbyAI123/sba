-- ============================================================================
-- MSMS - COMPLETE DATABASE SCHEMA FOR LIVE SERVER DEPLOYMENT
-- School Management System - Production Ready
-- Version: 3.0.0
-- Date: December 2025
-- ============================================================================
-- 
-- DEPLOYMENT INSTRUCTIONS:
-- 1. Create database: CREATE DATABASE IF NOT EXISTS school_management_system;
-- 2. Import this file via phpMyAdmin or MySQL command line
-- 3. This schema handles all dependencies, prevents duplications, and avoids foreign key errors
-- 4. Safe to re-run - uses IF NOT EXISTS and DROP IF EXISTS where appropriate
--
-- IMPORT METHOD 1 (phpMyAdmin):
--   - Login to phpMyAdmin
--   - Select database or create new one
--   - Click Import tab
--   - Choose this file
--   - Click Go
--
-- IMPORT METHOD 2 (Command Line):
--   mysql -u username -p database_name < LIVE_SERVER_COMPLETE_SCHEMA.sql
--
-- ============================================================================

-- Disable foreign key checks temporarily for clean import
SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
SET NAMES utf8mb4;

-- ============================================================================
-- SECTION 1: CORE TABLES (No Dependencies)
-- ============================================================================

-- Schools Table
CREATE TABLE IF NOT EXISTS `schools` (
  `school_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_name` VARCHAR(255) NOT NULL,
  `school_code` VARCHAR(50) NOT NULL,
  `email` VARCHAR(255) NULL,
  `phone` VARCHAR(20) NULL,
  `address` TEXT NULL,
  `city` VARCHAR(100) NULL,
  `state` VARCHAR(100) NULL,
  `country` VARCHAR(100) DEFAULT 'Ghana',
  `motto` TEXT NULL,
  `website` VARCHAR(255) NULL,
  `established_date` DATE NULL,
  `logo` VARCHAR(255) NULL,
  `status` ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
  `subscription_expiry` DATE NULL,
  `theme_color` VARCHAR(7) DEFAULT '#1a56db',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`school_id`),
  UNIQUE KEY `idx_school_code` (`school_code`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Users Table (Central authentication)
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NULL,
  `username` VARCHAR(100) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `first_name` VARCHAR(100) NOT NULL,
  `middle_name` VARCHAR(100) NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(20) NULL,
  `gender` ENUM('male', 'female', 'other') NULL,
  `date_of_birth` DATE NULL,
  `address` TEXT NULL,
  `avatar` VARCHAR(255) NULL,
  `role` ENUM('super_admin', 'proprietor', 'admin', 'teacher', 'student', 'parent', 'accountant', 'librarian', 'bookstore') NOT NULL,
  `status` ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
  `last_login` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `idx_username_school` (`username`, `school_id`),
  KEY `idx_email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Login Attempts (Security)
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `attempt_id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(100) NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `attempt_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `user_agent` TEXT NULL,
  PRIMARY KEY (`attempt_id`),
  KEY `idx_username` (`username`),
  KEY `idx_time` (`attempt_time`),
  KEY `idx_ip` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Password Resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `reset_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `token` VARCHAR(255) NOT NULL,
  `expires_at` TIMESTAMP NOT NULL,
  `used` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`reset_id`),
  UNIQUE KEY `idx_token` (`token`),
  KEY `idx_user` (`user_id`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SECTION 2: ACADEMIC STRUCTURE
-- ============================================================================

-- Classes/Grades
CREATE TABLE IF NOT EXISTS `classes` (
  `class_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `class_name` VARCHAR(100) NOT NULL,
  `class_level` INT(2) NULL,
  `class_teacher` INT(11) NULL COMMENT 'Teacher user_id',
  `capacity` INT(3) DEFAULT 40,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`class_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_teacher` (`class_teacher`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Subjects
CREATE TABLE IF NOT EXISTS `subjects` (
  `subject_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `subject_name` VARCHAR(100) NOT NULL,
  `subject_code` VARCHAR(20) NULL,
  `description` TEXT NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`subject_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_code` (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Class-Subject Assignment
CREATE TABLE IF NOT EXISTS `class_subjects` (
  `class_subject_id` INT(11) NOT NULL AUTO_INCREMENT,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `teacher_id` INT(11) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`class_subject_id`),
  UNIQUE KEY `idx_class_subject` (`class_id`, `subject_id`),
  KEY `idx_teacher` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Academic Years
CREATE TABLE IF NOT EXISTS `academic_years` (
  `year_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `year_name` VARCHAR(20) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `is_current` TINYINT(1) DEFAULT 0,
  `status` ENUM('active', 'completed', 'archived') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`year_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_current` (`is_current`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Terms/Semesters
CREATE TABLE IF NOT EXISTS `terms` (
  `term_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `year_id` INT(11) NULL,
  `term_name` VARCHAR(50) NOT NULL,
  `session_year` VARCHAR(20) NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `is_current` TINYINT(1) DEFAULT 0,
  `status` ENUM('active', 'completed', 'archived') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`term_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_year` (`year_id`),
  KEY `idx_current` (`is_current`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SECTION 3: STUDENTS & PARENTS
-- ============================================================================

-- Students
CREATE TABLE IF NOT EXISTS `students` (
  `student_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `class_id` INT(11) NULL,
  `admission_number` VARCHAR(50) NOT NULL,
  `roll_number` VARCHAR(50) NULL,
  `first_name` VARCHAR(100) NOT NULL,
  `middle_name` VARCHAR(100) NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `gender` ENUM('male', 'female', 'other') NOT NULL,
  `date_of_birth` DATE NOT NULL,
  `blood_group` VARCHAR(5) NULL,
  `religion` VARCHAR(50) NULL,
  `nationality` VARCHAR(50) DEFAULT 'Ghanaian',
  `hometown` VARCHAR(100) NULL,
  `email` VARCHAR(255) NULL,
  `phone` VARCHAR(20) NULL,
  `address` TEXT NULL,
  `photo` VARCHAR(255) NULL,
  `admission_date` DATE NOT NULL,
  `student_code` VARCHAR(50) NULL,
  `status` ENUM('active', 'graduated', 'transferred', 'suspended', 'expelled') DEFAULT 'active',
  `fee_exemption` JSON DEFAULT NULL COMMENT 'Array of exempted fee types',
  `exemption_reason` TEXT DEFAULT NULL,
  `exemption_approved_by` INT DEFAULT NULL,
  `exemption_date` DATE DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `idx_admission` (`admission_number`, `school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Parents/Guardians
CREATE TABLE IF NOT EXISTS `parents` (
  `parent_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) NULL,
  `phone` VARCHAR(20) NOT NULL,
  `occupation` VARCHAR(100) NULL,
  `address` TEXT NULL,
  `relationship` ENUM('father', 'mother', 'guardian', 'other') DEFAULT 'guardian',
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`parent_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Student-Parent Relationship
CREATE TABLE IF NOT EXISTS `student_parents` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `parent_id` INT(11) NOT NULL,
  `is_primary` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_student_parent` (`student_id`, `parent_id`),
  KEY `idx_parent` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SECTION 4: TEACHERS & STAFF
-- ============================================================================

-- Teachers
CREATE TABLE IF NOT EXISTS `teachers` (
  `teacher_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `employee_id` VARCHAR(50) NULL,
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(20) NULL,
  `gender` ENUM('male', 'female', 'other') NULL,
  `date_of_birth` DATE NULL,
  `qualification` VARCHAR(100) NULL,
  `specialization` VARCHAR(100) NULL,
  `hire_date` DATE NULL,
  `salary` DECIMAL(10,2) NULL,
  `address` TEXT NULL,
  `photo` VARCHAR(255) NULL,
  `status` ENUM('active', 'on_leave', 'resigned', 'terminated') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`teacher_id`),
  UNIQUE KEY `idx_employee_school` (`employee_id`, `school_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Teacher-Class Assignment
CREATE TABLE IF NOT EXISTS `teacher_classes` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `is_class_teacher` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_teacher_class` (`teacher_id`, `class_id`),
  KEY `idx_class` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SECTION 5: ATTENDANCE SYSTEM
-- ============================================================================

-- Attendance Records
CREATE TABLE IF NOT EXISTS `attendance` (
  `attendance_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `date` DATE NOT NULL,
  `status` ENUM('present', 'absent', 'late', 'excused') NOT NULL,
  `notes` TEXT NULL,
  `marked_by` INT(11) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attendance_id`),
  UNIQUE KEY `idx_student_date` (`student_id`, `date`),
  KEY `idx_class_date` (`class_id`, `date`),
  KEY `idx_school_date` (`school_id`, `date`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Attendance Summary
CREATE TABLE IF NOT EXISTS `attendance_summary` (
  `summary_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `term_id` INT(11) NULL,
  `month` VARCHAR(7) NULL COMMENT 'Format: YYYY-MM',
  `total_days` INT DEFAULT 0,
  `present_days` INT DEFAULT 0,
  `absent_days` INT DEFAULT 0,
  `late_days` INT DEFAULT 0,
  `excused_days` INT DEFAULT 0,
  `attendance_percentage` DECIMAL(5,2) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`summary_id`),
  UNIQUE KEY `idx_student_term` (`student_id`, `term_id`),
  KEY `idx_month` (`month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SECTION 6: EXAMINATION SYSTEM
-- ============================================================================

-- Exams
CREATE TABLE IF NOT EXISTS `exams` (
  `exam_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `term_id` INT(11) NULL,
  `exam_name` VARCHAR(100) NOT NULL,
  `exam_type` ENUM('mid_term', 'end_term', 'class_test', 'quiz', 'final', 'mock') DEFAULT 'end_term',
  `start_date` DATE NULL,
  `end_date` DATE NULL,
  `status` ENUM('scheduled', 'ongoing', 'completed', 'cancelled') DEFAULT 'scheduled',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`exam_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Marks/Results
CREATE TABLE IF NOT EXISTS `marks` (
  `mark_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `exam_id` INT(11) NOT NULL,
  `term_id` INT(11) NULL,
  `school_id` INT(11) NOT NULL,
  `class_score` DECIMAL(5,2) DEFAULT 0,
  `exam_score` DECIMAL(5,2) DEFAULT 0,
  `total_score` DECIMAL(5,2) GENERATED ALWAYS AS (`class_score` + `exam_score`) STORED,
  `grade` VARCHAR(5) NULL,
  `remarks` TEXT NULL,
  `position` INT NULL,
  `teacher_id` INT(11) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mark_id`),
  UNIQUE KEY `idx_student_subject_exam` (`student_id`, `subject_id`, `exam_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_exam` (`exam_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Results Performance
CREATE TABLE IF NOT EXISTS `marks_performance` (
  `performance_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `term_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `total_subjects` INT DEFAULT 0,
  `total_marks` DECIMAL(10,2) DEFAULT 0,
  `average_score` DECIMAL(5,2) DEFAULT 0,
  `overall_position` INT NULL,
  `class_average` DECIMAL(5,2) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`performance_id`),
  UNIQUE KEY `idx_student_term` (`student_id`, `term_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SECTION 7: FEE MANAGEMENT
-- ============================================================================

-- Fee Categories
CREATE TABLE IF NOT EXISTS `fee_categories` (
  `category_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `category_name` VARCHAR(100) NOT NULL,
  `category_type` ENUM('school_fees', 'canteen', 'transport', 'library', 'exam', 'other') DEFAULT 'school_fees',
  `description` TEXT NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_type` (`category_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Fee Structure
CREATE TABLE IF NOT EXISTS `fee_structure` (
  `fee_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `class_id` INT(11) NULL,
  `category_id` INT(11) NOT NULL,
  `fee_name` VARCHAR(100) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `frequency` ENUM('one_time', 'weekly', 'monthly', 'termly', 'annual') DEFAULT 'termly',
  `term_id` INT(11) NULL,
  `due_date` DATE NULL,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`fee_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_category` (`category_id`),
  KEY `idx_term` (`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Student Fees
CREATE TABLE IF NOT EXISTS `student_fees` (
  `student_fee_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `fee_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `term_id` INT(11) NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `paid_amount` DECIMAL(10,2) DEFAULT 0,
  `balance` DECIMAL(10,2) GENERATED ALWAYS AS (`amount` - `paid_amount`) STORED,
  `due_date` DATE NULL,
  `status` ENUM('pending', 'partial', 'paid', 'overdue', 'exempted') DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`student_fee_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_fee` (`fee_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Payments
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `term_id` INT(11) NULL,
  `fee_id` INT(11) NULL,
  `payment_type` ENUM('school_fees', 'canteen', 'transport', 'library', 'exam', 'other') DEFAULT 'school_fees',
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_method` ENUM('cash', 'mobile_money', 'bank_transfer', 'cheque', 'online') DEFAULT 'cash',
  `payment_reference` VARCHAR(100) NULL,
  `transaction_id` VARCHAR(100) NULL,
  `payment_date` DATE NOT NULL,
  `collection_period` ENUM('weekly', 'monthly', 'termly', 'annual') DEFAULT NULL,
  `collected_by` INT(11) NULL COMMENT 'User ID who collected',
  `submitted_to` INT(11) DEFAULT NULL COMMENT 'Accountant ID',
  `submitted_at` DATETIME DEFAULT NULL,
  `verified_by` INT(11) DEFAULT NULL,
  `verified_at` DATETIME DEFAULT NULL,
  `verification_notes` TEXT DEFAULT NULL,
  `status` ENUM('pending', 'completed', 'cancelled', 'refunded', 'pending_verification', 'submitted_to_accountant', 'rejected') DEFAULT 'completed',
  `notes` TEXT NULL,
  `receipt_number` VARCHAR(50) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  UNIQUE KEY `idx_receipt` (`receipt_number`),
  KEY `idx_student` (`student_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_date` (`payment_date`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Transactions
CREATE TABLE IF NOT EXISTS `transactions` (
  `transaction_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `transaction_type` ENUM('income', 'expense', 'refund', 'adjustment') NOT NULL,
  `category` VARCHAR(100) NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_id` INT(11) NULL,
  `reference_number` VARCHAR(100) NULL,
  `description` TEXT NULL,
  `transaction_date` DATE NOT NULL,
  `created_by` INT(11) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`transaction_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_type` (`transaction_type`),
  KEY `idx_date` (`transaction_date`),
  KEY `idx_payment` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Expenses
CREATE TABLE IF NOT EXISTS `expenses` (
  `expense_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `description` TEXT NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `expense_date` DATE NOT NULL,
  `payment_method` ENUM('cash', 'bank_transfer', 'cheque', 'mobile_money') DEFAULT 'cash',
  `reference_number` VARCHAR(100) NULL,
  `receipt` VARCHAR(255) NULL,
  `approved_by` INT(11) NULL,
  `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  `notes` TEXT NULL,
  `created_by` INT(11) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`expense_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_date` (`expense_date`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SECTION 8: LIBRARY SYSTEM
-- ============================================================================

-- Library Books
CREATE TABLE IF NOT EXISTS `library_books` (
  `book_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `author` VARCHAR(255) NULL,
  `isbn` VARCHAR(20) NULL,
  `publisher` VARCHAR(255) NULL,
  `category` VARCHAR(100) NULL,
  `quantity` INT DEFAULT 1,
  `available` INT DEFAULT 1,
  `rack_number` VARCHAR(50) NULL,
  `price` DECIMAL(10,2) NULL,
  `status` ENUM('available', 'issued', 'damaged', 'lost') DEFAULT 'available',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`book_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_isbn` (`isbn`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Library Issues
CREATE TABLE IF NOT EXISTS `library_issues` (
  `issue_id` INT(11) NOT NULL AUTO_INCREMENT,
  `book_id` INT(11) NOT NULL,
  `student_id` INT(11) NULL,
  `teacher_id` INT(11) NULL,
  `school_id` INT(11) NOT NULL,
  `issue_date` DATE NOT NULL,
  `due_date` DATE NOT NULL,
  `return_date` DATE NULL,
  `fine_amount` DECIMAL(10,2) DEFAULT 0,
  `fine_paid` TINYINT(1) DEFAULT 0,
  `status` ENUM('issued', 'returned', 'overdue', 'lost') DEFAULT 'issued',
  `issued_by` INT(11) NULL,
  `notes` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`issue_id`),
  KEY `idx_book` (`book_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_teacher` (`teacher_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SECTION 9: MESSAGING & NOTIFICATIONS
-- ============================================================================

-- Messages
CREATE TABLE IF NOT EXISTS `messages` (
  `message_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `sender_id` INT(11) NOT NULL,
  `recipient_id` INT(11) NULL,
  `recipient_type` ENUM('individual', 'class', 'role', 'all') DEFAULT 'individual',
  `class_id` INT(11) NULL,
  `role` VARCHAR(50) NULL,
  `subject` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `message_type` ENUM('general', 'urgent', 'announcement', 'reminder') DEFAULT 'general',
  `is_read` TINYINT(1) DEFAULT 0,
  `read_at` TIMESTAMP NULL,
  `priority` ENUM('low', 'normal', 'high') DEFAULT 'normal',
  `attachment` VARCHAR(255) NULL,
  `sent_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`message_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_sender` (`sender_id`),
  KEY `idx_recipient` (`recipient_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Notifications
CREATE TABLE IF NOT EXISTS `notifications` (
  `notification_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `link` VARCHAR(255) NULL,
  `icon` VARCHAR(50) NULL,
  `is_read` TINYINT(1) DEFAULT 0,
  `read_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notification_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_read` (`is_read`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SECTION 10: EMAIL SYSTEM
-- ============================================================================

-- Email Queue
CREATE TABLE IF NOT EXISTS `email_queue` (
  `queue_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NULL,
  `to_email` VARCHAR(255) NOT NULL,
  `to_name` VARCHAR(255) NULL,
  `from_email` VARCHAR(255) NULL,
  `from_name` VARCHAR(255) NULL,
  `subject` VARCHAR(255) NOT NULL,
  `body` TEXT NOT NULL,
  `template_id` INT(11) NULL,
  `priority` ENUM('low', 'normal', 'high') DEFAULT 'normal',
  `status` ENUM('pending', 'sending', 'sent', 'failed') DEFAULT 'pending',
  `attempts` INT DEFAULT 0,
  `last_error` TEXT NULL,
  `scheduled_at` TIMESTAMP NULL,
  `sent_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`queue_id`),
  KEY `idx_status` (`status`),
  KEY `idx_scheduled` (`scheduled_at`),
  KEY `idx_priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Email Templates
CREATE TABLE IF NOT EXISTS `email_templates` (
  `template_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NULL,
  `template_name` VARCHAR(100) NOT NULL,
  `template_type` VARCHAR(50) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `body` TEXT NOT NULL,
  `variables` TEXT NULL COMMENT 'JSON array of available variables',
  `is_system` TINYINT(1) DEFAULT 0,
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`template_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_type` (`template_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Email Logs
CREATE TABLE IF NOT EXISTS `email_logs` (
  `log_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NULL,
  `queue_id` INT(11) NULL,
  `to_email` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `status` ENUM('sent', 'failed', 'bounced') NOT NULL,
  `error_message` TEXT NULL,
  `sent_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `idx_queue` (`queue_id`),
  KEY `idx_status` (`status`),
  KEY `idx_sent` (`sent_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Email Settings
CREATE TABLE IF NOT EXISTS `email_settings` (
  `setting_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NULL,
  `smtp_host` VARCHAR(255) NOT NULL,
  `smtp_port` INT NOT NULL DEFAULT 587,
  `smtp_username` VARCHAR(255) NOT NULL,
  `smtp_password` VARCHAR(255) NOT NULL,
  `encryption` ENUM('none', 'tls', 'ssl') DEFAULT 'tls',
  `from_email` VARCHAR(255) NOT NULL,
  `from_name` VARCHAR(255) NOT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SECTION 11: API & LOGGING
-- ============================================================================

-- API Tokens
CREATE TABLE IF NOT EXISTS `api_tokens` (
  `token_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `school_id` INT(11) NULL,
  `token` VARCHAR(255) NOT NULL,
  `name` VARCHAR(100) NULL,
  `abilities` TEXT NULL COMMENT 'JSON array of permissions',
  `last_used_at` TIMESTAMP NULL,
  `expires_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`token_id`),
  UNIQUE KEY `idx_token` (`token`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- API Logs
CREATE TABLE IF NOT EXISTS `api_logs` (
  `log_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NULL,
  `endpoint` VARCHAR(255) NOT NULL,
  `method` VARCHAR(10) NOT NULL,
  `request_data` TEXT NULL,
  `response_code` INT NULL,
  `response_data` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_endpoint` (`endpoint`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Error Logs
CREATE TABLE IF NOT EXISTS `error_logs` (
  `error_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NULL,
  `user_id` INT(11) NULL,
  `error_type` VARCHAR(50) NOT NULL,
  `error_message` TEXT NOT NULL,
  `error_file` VARCHAR(255) NULL,
  `error_line` INT NULL,
  `stack_trace` TEXT NULL,
  `request_url` VARCHAR(255) NULL,
  `request_data` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` TEXT NULL,
  `severity` ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
  `status` ENUM('new', 'in_progress', 'resolved', 'ignored') DEFAULT 'new',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`error_id`),
  KEY `idx_type` (`error_type`),
  KEY `idx_severity` (`severity`),
  KEY `idx_status` (`status`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- System Logs
CREATE TABLE IF NOT EXISTS `system_logs` (
  `log_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NULL,
  `user_id` INT(11) NULL,
  `action` VARCHAR(100) NOT NULL,
  `module` VARCHAR(50) NOT NULL,
  `description` TEXT NULL,
  `old_value` TEXT NULL,
  `new_value` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_module` (`module`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- SECTION 12: ADVANCED FEATURES
-- ============================================================================

-- Bulk Operations
CREATE TABLE IF NOT EXISTS `bulk_operations_log` (
  `operation_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `operation_type` VARCHAR(50) NOT NULL,
  `status` ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
  `total_records` INT DEFAULT 0,
  `processed_records` INT DEFAULT 0,
  `failed_records` INT DEFAULT 0,
  `error_details` TEXT NULL,
  `started_by` INT(11) NULL,
  `started_at` TIMESTAMP NULL,
  `completed_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`operation_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Search History
CREATE TABLE IF NOT EXISTS `search_history` (
  `search_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `search_query` VARCHAR(255) NOT NULL,
  `search_module` VARCHAR(50) NULL,
  `results_count` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`search_id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_query` (`search_query`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Saved Reports
CREATE TABLE IF NOT EXISTS `saved_reports` (
  `report_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NOT NULL,
  `report_name` VARCHAR(255) NOT NULL,
  `report_type` VARCHAR(50) NOT NULL,
  `filters` TEXT NULL COMMENT 'JSON filters',
  `schedule` VARCHAR(50) NULL,
  `last_generated` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`report_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Backup Logs
CREATE TABLE IF NOT EXISTS `backup_logs` (
  `backup_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NULL,
  `backup_type` ENUM('full', 'incremental', 'manual') DEFAULT 'manual',
  `file_name` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_size` BIGINT NULL,
  `status` ENUM('pending', 'in_progress', 'completed', 'failed') DEFAULT 'completed',
  `error_message` TEXT NULL,
  `created_by` INT(11) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`backup_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dashboard Widgets
CREATE TABLE IF NOT EXISTS `dashboard_widgets` (
  `widget_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `widget_type` VARCHAR(50) NOT NULL,
  `position` INT DEFAULT 0,
  `size` VARCHAR(20) DEFAULT 'medium',
  `is_visible` TINYINT(1) DEFAULT 1,
  `settings` TEXT NULL COMMENT 'JSON settings',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`widget_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Transcripts
CREATE TABLE IF NOT EXISTS `transcripts` (
  `transcript_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL,
  `generated_by` INT(11) NULL,
  `file_path` VARCHAR(255) NULL,
  `status` ENUM('draft', 'final', 'issued') DEFAULT 'draft',
  `issued_date` DATE NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`transcript_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- System Settings
CREATE TABLE IF NOT EXISTS `system_settings` (
  `setting_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NULL,
  `setting_key` VARCHAR(100) NOT NULL,
  `setting_value` TEXT NULL,
  `setting_type` VARCHAR(50) NULL,
  `category` VARCHAR(50) NULL,
  `is_public` TINYINT(1) DEFAULT 0,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `idx_school_key` (`school_id`, `setting_key`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Announcements
CREATE TABLE IF NOT EXISTS `announcements` (
  `announcement_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `content` TEXT NOT NULL,
  `target_audience` ENUM('all', 'students', 'teachers', 'parents', 'staff') DEFAULT 'all',
  `priority` ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
  `publish_date` DATE NULL,
  `expiry_date` DATE NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_by` INT(11) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`announcement_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_active` (`is_active`),
  KEY `idx_dates` (`publish_date`, `expiry_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- DEFAULT DATA INSERTION
-- ============================================================================

-- Email Templates
INSERT INTO `email_templates` (`template_id`, `school_id`, `template_name`, `template_type`, `subject`, `body`, `variables`, `is_system`, `status`) VALUES
(1, NULL, 'Welcome Email', 'welcome', 'Welcome to {{school_name}}', '<p>Dear {{user_name}},</p><p>Welcome to {{school_name}}!</p><p>Username: {{username}}<br>Password: {{password}}</p>', '["school_name","user_name","username","password"]', 1, 'active'),
(2, NULL, 'Password Reset', 'password_reset', 'Password Reset Request', '<p>Dear {{user_name}},</p><p>Reset link: {{reset_link}}</p>', '["user_name","reset_link"]', 1, 'active'),
(3, NULL, 'Payment Receipt', 'payment_receipt', 'Payment Receipt - {{receipt_number}}', '<p>Dear {{parent_name}},</p><p>Payment for {{student_name}}: {{currency}}{{amount}}</p>', '["parent_name","student_name","amount","currency","receipt_number"]', 1, 'active'),
(4, NULL, 'Exam Results', 'exam_results', 'Results - {{exam_name}}', '<p>Dear {{parent_name}},</p><p>Results available for {{student_name}}.</p>', '["parent_name","student_name","exam_name"]', 1, 'active'),
(5, NULL, 'Attendance Alert', 'attendance_alert', 'Attendance - {{student_name}}', '<p>Dear {{parent_name}},</p><p>{{student_name}} was {{status}} on {{date}}.</p>', '["parent_name","student_name","status","date"]', 1, 'active'),
(6, NULL, 'Fee Reminder', 'fee_reminder', 'Fee Payment Reminder', '<p>Dear {{parent_name}},</p><p>Fee due for {{student_name}}: {{currency}}{{amount}}</p>', '["parent_name","student_name","amount","currency","due_date"]', 1, 'active'),
(7, NULL, 'Announcement', 'announcement', '{{announcement_title}}', '<p>{{announcement_content}}</p>', '["announcement_title","announcement_content","school_name"]', 1, 'active')
ON DUPLICATE KEY UPDATE template_id=template_id;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

-- ============================================================================
-- IMPORT COMPLETE
-- Total Tables: 50+
-- Safe for re-import - No duplication or foreign key errors
-- ============================================================================
