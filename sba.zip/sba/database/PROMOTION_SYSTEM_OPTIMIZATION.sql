-- =====================================================
-- STUDENT PROMOTION SYSTEM - DATABASE OPTIMIZATION
-- Performance indexes, constraints, and optimizations
-- =====================================================

USE school_management_system;

-- =====================================================
-- PART 1: PERFORMANCE INDEXES
-- =====================================================

-- Indexes for student_promotions table
ALTER TABLE `student_promotions`
ADD INDEX IF NOT EXISTS `idx_school_year` (`school_id`, `academic_year`),
ADD INDEX IF NOT EXISTS `idx_school_year_class` (`school_id`, `academic_year`, `from_class_id`),
ADD INDEX IF NOT EXISTS `idx_student_year` (`student_id`, `academic_year`),
ADD INDEX IF NOT EXISTS `idx_promotion_type` (`promotion_type`),
ADD INDEX IF NOT EXISTS `idx_promotion_date` (`promotion_date`),
ADD INDEX IF NOT EXISTS `idx_created_at` (`created_at`),
ADD INDEX IF NOT EXISTS `idx_entry_term` (`entry_term`),
ADD INDEX IF NOT EXISTS `idx_promoted_by` (`promoted_by`);

-- Composite index for most common query pattern
ALTER TABLE `student_promotions`
ADD INDEX IF NOT EXISTS `idx_query_optimization` (`school_id`, `academic_year`, `promotion_type`, `created_at`);

-- Indexes for students table (promotion-related)
ALTER TABLE `students`
ADD INDEX IF NOT EXISTS `idx_entry_term` (`entry_term`),
ADD INDEX IF NOT EXISTS `idx_promotion_status` (`promotion_status`),
ADD INDEX IF NOT EXISTS `idx_current_academic_year` (`current_academic_year`),
ADD INDEX IF NOT EXISTS `idx_school_class_status` (`school_id`, `class_id`, `status`),
ADD INDEX IF NOT EXISTS `idx_entry_term_class` (`entry_term`, `class_id`);

-- Indexes for student_assessments (used in calculations)
ALTER TABLE `student_assessments`
ADD INDEX IF NOT EXISTS `idx_student_term` (`student_id`, `term_id`),
ADD INDEX IF NOT EXISTS `idx_term_subject` (`term_id`, `subject_id`),
ADD INDEX IF NOT EXISTS `idx_student_subject` (`student_id`, `subject_id`);

-- Indexes for terms table
ALTER TABLE `terms`
ADD INDEX IF NOT EXISTS `idx_school_session` (`school_id`, `session_year`),
ADD INDEX IF NOT EXISTS `idx_school_current` (`school_id`, `is_current`),
ADD INDEX IF NOT EXISTS `idx_session_year` (`session_year`);

-- Indexes for classes table
ALTER TABLE `classes`
ADD INDEX IF NOT EXISTS `idx_school_class` (`school_id`, `class_id`);

-- Indexes for class_progression table
ALTER TABLE `class_progression`
ADD INDEX IF NOT EXISTS `idx_school_current` (`school_id`, `current_class_id`),
ADD INDEX IF NOT EXISTS `idx_school_next` (`school_id`, `next_class_id`),
ADD INDEX IF NOT EXISTS `idx_class_order` (`class_order`);

-- =====================================================
-- PART 2: FOREIGN KEY CONSTRAINTS
-- =====================================================

-- Add foreign keys for data integrity
-- Note: MySQL/MariaDB doesn't support IF NOT EXISTS for constraints
-- So we use a safer approach: drop if exists, then add

-- student_promotions foreign keys
SET @sql = (
    SELECT IF(COUNT(*) > 0, 
        'ALTER TABLE student_promotions DROP FOREIGN KEY fk_promo_school', 
        'SELECT 1')
    FROM information_schema.TABLE_CONSTRAINTS 
    WHERE CONSTRAINT_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'student_promotions' 
    AND CONSTRAINT_NAME = 'fk_promo_school'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE `student_promotions`
ADD CONSTRAINT `fk_promo_school` 
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE;

SET @sql = (
    SELECT IF(COUNT(*) > 0, 
        'ALTER TABLE student_promotions DROP FOREIGN KEY fk_promo_student', 
        'SELECT 1')
    FROM information_schema.TABLE_CONSTRAINTS 
    WHERE CONSTRAINT_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'student_promotions' 
    AND CONSTRAINT_NAME = 'fk_promo_student'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE `student_promotions`
ADD CONSTRAINT `fk_promo_student` 
    FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE;

SET @sql = (
    SELECT IF(COUNT(*) > 0, 
        'ALTER TABLE student_promotions DROP FOREIGN KEY fk_promo_from_class', 
        'SELECT 1')
    FROM information_schema.TABLE_CONSTRAINTS 
    WHERE CONSTRAINT_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'student_promotions' 
    AND CONSTRAINT_NAME = 'fk_promo_from_class'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE `student_promotions`
ADD CONSTRAINT `fk_promo_from_class` 
    FOREIGN KEY (`from_class_id`) REFERENCES `classes`(`class_id`) ON DELETE CASCADE;

SET @sql = (
    SELECT IF(COUNT(*) > 0, 
        'ALTER TABLE student_promotions DROP FOREIGN KEY fk_promo_promoted_by', 
        'SELECT 1')
    FROM information_schema.TABLE_CONSTRAINTS 
    WHERE CONSTRAINT_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'student_promotions' 
    AND CONSTRAINT_NAME = 'fk_promo_promoted_by'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE `student_promotions`
ADD CONSTRAINT `fk_promo_promoted_by` 
    FOREIGN KEY (`promoted_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL;

-- promotion_overrides foreign keys
SET @sql = (
    SELECT IF(COUNT(*) > 0, 
        'ALTER TABLE promotion_overrides DROP FOREIGN KEY fk_override_student', 
        'SELECT 1')
    FROM information_schema.TABLE_CONSTRAINTS 
    WHERE CONSTRAINT_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'promotion_overrides' 
    AND CONSTRAINT_NAME = 'fk_override_student'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE `promotion_overrides`
ADD CONSTRAINT `fk_override_student` 
    FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE;

SET @sql = (
    SELECT IF(COUNT(*) > 0, 
        'ALTER TABLE promotion_overrides DROP FOREIGN KEY fk_override_by', 
        'SELECT 1')
    FROM information_schema.TABLE_CONSTRAINTS 
    WHERE CONSTRAINT_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'promotion_overrides' 
    AND CONSTRAINT_NAME = 'fk_override_by'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE `promotion_overrides`
ADD CONSTRAINT `fk_override_by` 
    FOREIGN KEY (`overridden_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL;

-- promotion_locks foreign keys
SET @sql = (
    SELECT IF(COUNT(*) > 0, 
        'ALTER TABLE promotion_locks DROP FOREIGN KEY fk_lock_school', 
        'SELECT 1')
    FROM information_schema.TABLE_CONSTRAINTS 
    WHERE CONSTRAINT_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'promotion_locks' 
    AND CONSTRAINT_NAME = 'fk_lock_school'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE `promotion_locks`
ADD CONSTRAINT `fk_lock_school` 
    FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE;

SET @sql = (
    SELECT IF(COUNT(*) > 0, 
        'ALTER TABLE promotion_locks DROP FOREIGN KEY fk_lock_class', 
        'SELECT 1')
    FROM information_schema.TABLE_CONSTRAINTS 
    WHERE CONSTRAINT_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'promotion_locks' 
    AND CONSTRAINT_NAME = 'fk_lock_class'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE `promotion_locks`
ADD CONSTRAINT `fk_lock_class` 
    FOREIGN KEY (`class_id`) REFERENCES `classes`(`class_id`) ON DELETE CASCADE;

SET @sql = (
    SELECT IF(COUNT(*) > 0, 
        'ALTER TABLE promotion_locks DROP FOREIGN KEY fk_lock_by', 
        'SELECT 1')
    FROM information_schema.TABLE_CONSTRAINTS 
    WHERE CONSTRAINT_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'promotion_locks' 
    AND CONSTRAINT_NAME = 'fk_lock_by'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

ALTER TABLE `promotion_locks`
ADD CONSTRAINT `fk_lock_by` 
    FOREIGN KEY (`locked_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL;

-- =====================================================
-- PART 3: TABLE OPTIMIZATION
-- =====================================================

-- Optimize tables for better performance
OPTIMIZE TABLE `student_promotions`;
OPTIMIZE TABLE `students`;
OPTIMIZE TABLE `student_assessments`;
OPTIMIZE TABLE `terms`;
OPTIMIZE TABLE `classes`;
OPTIMIZE TABLE `class_progression`;

-- Analyze tables for query optimizer
ANALYZE TABLE `student_promotions`;
ANALYZE TABLE `students`;
ANALYZE TABLE `student_assessments`;
ANALYZE TABLE `terms`;

-- =====================================================
-- PART 4: DATA VALIDATION & CLEANUP
-- =====================================================

-- Remove any orphaned promotion records (students that don't exist)
DELETE FROM student_promotions
WHERE student_id NOT IN (SELECT student_id FROM students);

-- Set default entry_term for students without one
UPDATE students
SET entry_term = 1
WHERE entry_term IS NULL OR entry_term NOT IN (1, 2, 3);

-- Clean up invalid promotion_type values
UPDATE student_promotions
SET promotion_type = 'promoted'
WHERE promotion_type NOT IN ('promoted', 'repeated', 'graduated');

-- =====================================================
-- PART 5: QUERY OPTIMIZATION HINTS
-- =====================================================

-- Create materialized view for statistics (if supported)
-- Note: MySQL doesn't support materialized views, but we can create a summary table

CREATE TABLE IF NOT EXISTS `promotion_statistics_cache` (
  `cache_id` INT(11) PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL,
  `class_id` INT(11),
  `total_students` INT(11) DEFAULT 0,
  `promoted_count` INT(11) DEFAULT 0,
  `repeated_count` INT(11) DEFAULT 0,
  `graduated_count` INT(11) DEFAULT 0,
  `average_score` DECIMAL(5,2),
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_cache` (`school_id`, `academic_year`, `class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Trigger to update cache automatically
DELIMITER //

CREATE TRIGGER IF NOT EXISTS `trg_update_promo_cache_after_insert`
AFTER INSERT ON `student_promotions`
FOR EACH ROW
BEGIN
    -- Update overall statistics
    INSERT INTO promotion_statistics_cache 
        (school_id, academic_year, class_id, total_students, promoted_count, repeated_count, graduated_count, average_score)
    SELECT 
        NEW.school_id,
        NEW.academic_year,
        NEW.from_class_id,
        COUNT(*),
        SUM(CASE WHEN promotion_type = 'promoted' THEN 1 ELSE 0 END),
        SUM(CASE WHEN promotion_type = 'repeated' THEN 1 ELSE 0 END),
        SUM(CASE WHEN promotion_type = 'graduated' THEN 1 ELSE 0 END),
        AVG(annual_average)
    FROM student_promotions
    WHERE school_id = NEW.school_id
    AND academic_year = NEW.academic_year
    AND from_class_id = NEW.from_class_id
    GROUP BY school_id, academic_year, from_class_id
    ON DUPLICATE KEY UPDATE
        total_students = VALUES(total_students),
        promoted_count = VALUES(promoted_count),
        repeated_count = VALUES(repeated_count),
        graduated_count = VALUES(graduated_count),
        average_score = VALUES(average_score),
        last_updated = CURRENT_TIMESTAMP;
END//

DELIMITER ;

-- =====================================================
-- PART 6: ARCHIVING OLD DATA
-- =====================================================

-- Create archive table for old promotions
CREATE TABLE IF NOT EXISTS `student_promotions_archive` LIKE `student_promotions`;

-- Stored procedure to archive old promotions (older than 5 years)
DELIMITER //

CREATE PROCEDURE IF NOT EXISTS `sp_ArchiveOldPromotions`(
    IN p_years_old INT
)
BEGIN
    DECLARE v_cutoff_date DATE;
    
    -- Calculate cutoff date
    SET v_cutoff_date = DATE_SUB(CURDATE(), INTERVAL p_years_old YEAR);
    
    -- Insert old records into archive
    INSERT INTO student_promotions_archive
    SELECT * FROM student_promotions
    WHERE promotion_date < v_cutoff_date;
    
    -- Delete from main table
    DELETE FROM student_promotions
    WHERE promotion_date < v_cutoff_date;
    
    -- Return summary
    SELECT 
        COUNT(*) as archived_count,
        v_cutoff_date as cutoff_date
    FROM student_promotions_archive
    WHERE promotion_date < v_cutoff_date;
END//

DELIMITER ;

-- =====================================================
-- PART 7: MONITORING & MAINTENANCE
-- =====================================================

-- Create monitoring table for performance tracking
CREATE TABLE IF NOT EXISTS `promotion_performance_log` (
  `log_id` INT(11) PRIMARY KEY AUTO_INCREMENT,
  `operation_type` VARCHAR(50) NOT NULL,
  `records_affected` INT(11),
  `execution_time_ms` INT(11),
  `query_details` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY `idx_operation` (`operation_type`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- PART 8: BACKUP & RECOVERY
-- =====================================================

-- Stored procedure for quick backup of promotion data
DELIMITER //

CREATE PROCEDURE IF NOT EXISTS `sp_BackupPromotionData`(
    IN p_academic_year VARCHAR(20)
)
BEGIN
    DECLARE backup_table_name VARCHAR(100);
    
    SET backup_table_name = CONCAT('student_promotions_backup_', REPLACE(p_academic_year, '/', '_'));
    
    -- Create backup table
    SET @sql = CONCAT('CREATE TABLE IF NOT EXISTS ', backup_table_name, ' SELECT * FROM student_promotions WHERE academic_year = "', p_academic_year, '"');
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
    SELECT CONCAT('Backup created: ', backup_table_name) as result;
END//

DELIMITER ;

-- =====================================================
-- PART 9: PERFORMANCE TESTING QUERIES
-- =====================================================

-- Test query performance (run these to benchmark)

-- Query 1: Get class promotion stats (should use idx_school_year_class)
EXPLAIN SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN promotion_type = 'promoted' THEN 1 ELSE 0 END) as promoted
FROM student_promotions
WHERE school_id = 1
AND academic_year = '2024/2025'
AND from_class_id = 10;

-- Query 2: Student promotion history (should use idx_student_year)
EXPLAIN SELECT *
FROM student_promotions
WHERE student_id = 100
ORDER BY academic_year DESC;

-- Query 3: Recent promotions (should use idx_created_at)
EXPLAIN SELECT *
FROM student_promotions
WHERE school_id = 1
AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
ORDER BY created_at DESC;

-- =====================================================
-- PART 10: VERIFICATION
-- =====================================================

-- Verify all indexes are created
SELECT 
    TABLE_NAME,
    INDEX_NAME,
    SEQ_IN_INDEX,
    COLUMN_NAME,
    INDEX_TYPE
FROM INFORMATION_SCHEMA.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME IN ('student_promotions', 'students', 'student_assessments', 'terms')
ORDER BY TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX;

-- Check table sizes and row counts
SELECT 
    TABLE_NAME,
    TABLE_ROWS,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) as 'Data Size (MB)',
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) as 'Index Size (MB)',
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) as 'Total Size (MB)'
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME IN ('student_promotions', 'students', 'student_assessments', 'terms')
ORDER BY (DATA_LENGTH + INDEX_LENGTH) DESC;

-- =====================================================
-- SUCCESS MESSAGE
-- =====================================================

SELECT 
    '✅ OPTIMIZATION COMPLETE!' as Status,
    'Performance indexes created' as Step1,
    'Foreign keys added' as Step2,
    'Tables optimized' as Step3,
    'Cache tables created' as Step4,
    'Monitoring enabled' as Step5,
    'Backup procedures ready' as Step6,
    'Run performance tests to verify' as NextStep;

