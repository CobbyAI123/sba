-- ============================================================================
-- SMART NOTIFICATIONS SYSTEM
-- Real-time alerts for payments, expenses, low balances, overdue fees
-- Date: November 28, 2025
-- ============================================================================

-- ============================================================================
-- 1. NOTIFICATIONS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS `notifications` (
  `notification_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NULL COMMENT 'Target user (NULL = all users with role)',
  `target_role` VARCHAR(50) NULL COMMENT 'accountant, proprietor, admin, teacher, etc.',
  `notification_type` ENUM('payment', 'expense', 'overdue', 'low_balance', 'new_student', 'fee_reminder', 'system', 'custom') NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `action_url` VARCHAR(500) NULL COMMENT 'Link to relevant page',
  `priority` ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
  `is_read` TINYINT(1) DEFAULT 0,
  `read_at` TIMESTAMP NULL,
  `related_id` INT(11) NULL COMMENT 'Related payment_id, expense_id, student_id, etc.',
  `related_type` VARCHAR(50) NULL COMMENT 'payment, expense, student, etc.',
  `icon` VARCHAR(50) NULL COMMENT 'Font Awesome icon class',
  `color` VARCHAR(20) NULL COMMENT 'Notification color (success, warning, danger, info)',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `expires_at` TIMESTAMP NULL COMMENT 'Auto-delete after this date',
  PRIMARY KEY (`notification_id`),
  KEY `idx_school_user` (`school_id`, `user_id`),
  KEY `idx_role` (`target_role`),
  KEY `idx_type` (`notification_type`),
  KEY `idx_read` (`is_read`),
  KEY `idx_created` (`created_at`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Real-time notification system';

-- ============================================================================
-- 2. NOTIFICATION PREFERENCES TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS `notification_preferences` (
  `preference_id` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `notification_type` VARCHAR(50) NOT NULL,
  `enabled` TINYINT(1) DEFAULT 1,
  `email_enabled` TINYINT(1) DEFAULT 0,
  `sms_enabled` TINYINT(1) DEFAULT 0,
  `sound_enabled` TINYINT(1) DEFAULT 1,
  `desktop_enabled` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`preference_id`),
  UNIQUE KEY `unique_user_type` (`user_id`, `notification_type`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='User notification preferences';

-- ============================================================================
-- 3. NOTIFICATION TRIGGERS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS `notification_triggers` (
  `trigger_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `trigger_name` VARCHAR(100) NOT NULL,
  `trigger_type` ENUM('payment_received', 'expense_added', 'overdue_fee', 'low_balance', 'daily_summary', 'weekly_report', 'monthly_report') NOT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `conditions` TEXT NULL COMMENT 'JSON conditions for trigger',
  `target_roles` VARCHAR(255) NULL COMMENT 'Comma-separated roles',
  `template` TEXT NULL COMMENT 'Notification message template',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`trigger_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_type` (`trigger_type`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Automated notification triggers';

-- ============================================================================
-- 4. INSERT DEFAULT NOTIFICATION TRIGGERS
-- ============================================================================

-- Payment Received Trigger
INSERT INTO `notification_triggers` (`school_id`, `trigger_name`, `trigger_type`, `target_roles`, `template`, `conditions`)
SELECT DISTINCT 
    school_id,
    'Payment Received Alert',
    'payment_received',
    'accountant,proprietor',
    'New payment of {amount} received from {student_name} ({admission_number})',
    '{"min_amount": 0}'
FROM schools
WHERE NOT EXISTS (
    SELECT 1 FROM notification_triggers 
    WHERE notification_triggers.school_id = schools.school_id 
    AND trigger_type = 'payment_received'
);

-- Expense Added Trigger
INSERT INTO `notification_triggers` (`school_id`, `trigger_name`, `trigger_type`, `target_roles`, `template`, `conditions`)
SELECT DISTINCT 
    school_id,
    'Expense Added Alert',
    'expense_added',
    'proprietor,admin',
    'New expense of {amount} added: {description} (Status: {status})',
    '{"min_amount": 0}'
FROM schools
WHERE NOT EXISTS (
    SELECT 1 FROM notification_triggers 
    WHERE notification_triggers.school_id = schools.school_id 
    AND trigger_type = 'expense_added'
);

-- Overdue Fee Trigger
INSERT INTO `notification_triggers` (`school_id`, `trigger_name`, `trigger_type`, `target_roles`, `template`, `conditions`)
SELECT DISTINCT 
    school_id,
    'Overdue Fee Alert',
    'overdue_fee',
    'accountant,proprietor',
    '{count} students have overdue fees totaling {amount}',
    '{"days_overdue": 7}'
FROM schools
WHERE NOT EXISTS (
    SELECT 1 FROM notification_triggers 
    WHERE notification_triggers.school_id = schools.school_id 
    AND trigger_type = 'overdue_fee'
);

-- Low Balance Trigger
INSERT INTO `notification_triggers` (`school_id`, `trigger_name`, `trigger_type`, `target_roles`, `template`, `conditions`)
SELECT DISTINCT 
    school_id,
    'Low Balance Warning',
    'low_balance',
    'proprietor,accountant',
    'School balance is low: {balance}. Monthly expenses: {expenses}',
    '{"threshold_days": 30}'
FROM schools
WHERE NOT EXISTS (
    SELECT 1 FROM notification_triggers 
    WHERE notification_triggers.school_id = schools.school_id 
    AND trigger_type = 'low_balance'
);

-- Daily Summary Trigger
INSERT INTO `notification_triggers` (`school_id`, `trigger_name`, `trigger_type`, `target_roles`, `template`, `conditions`)
SELECT DISTINCT 
    school_id,
    'Daily Financial Summary',
    'daily_summary',
    'proprietor,accountant',
    'Today: {payments} payments ({amount}), {expenses} expenses ({expense_amount}). Net: {net}',
    '{"send_time": "17:00"}'
FROM schools
WHERE NOT EXISTS (
    SELECT 1 FROM notification_triggers 
    WHERE notification_triggers.school_id = schools.school_id 
    AND trigger_type = 'daily_summary'
);

-- ============================================================================
-- 5. VERIFICATION QUERIES
-- ============================================================================

SELECT '✅ notifications table created' AS status;
SELECT '✅ notification_preferences table created' AS status;
SELECT '✅ notification_triggers table created' AS status;

SELECT 
    'notification_triggers' as table_name,
    COUNT(*) as trigger_count 
FROM notification_triggers;

SELECT '
╔═══════════════════════════════════════════════════════════════╗
║         ✅ SMART NOTIFICATIONS SYSTEM CREATED!                ║
╠═══════════════════════════════════════════════════════════════╣
║ • notifications table created                                 ║
║ • notification_preferences table created                      ║
║ • notification_triggers table created                         ║
║ • Default triggers added for all schools                      ║
╠═══════════════════════════════════════════════════════════════╣
║ NOTIFICATION TYPES:                                           ║
║ • Payment Received - Real-time payment alerts                 ║
║ • Expense Added - Expense tracking notifications              ║
║ • Overdue Fees - Automatic overdue reminders                  ║
║ • Low Balance - Cash flow warnings                            ║
║ • Daily Summary - End-of-day financial report                 ║
║ • Weekly/Monthly Reports - Scheduled summaries                ║
╠═══════════════════════════════════════════════════════════════╣
║ FEATURES:                                                     ║
║ • Real-time notifications                                     ║
║ • User-specific alerts                                        ║
║ • Role-based notifications                                    ║
║ • Customizable preferences                                    ║
║ • Sound, email, SMS options                                   ║
║ • Auto-expire old notifications                               ║
║ • Priority levels (low/medium/high/urgent)                    ║
╚═══════════════════════════════════════════════════════════════╝
' AS SUCCESS;
