-- ============================================================================
-- CREATE FEE STRUCTURE TABLE
-- This table stores fee structures for different classes and terms
-- ============================================================================

-- Create fee_structure table
CREATE TABLE IF NOT EXISTS `fee_structure` (
  `fee_id` int(11) NOT NULL AUTO_INCREMENT,
  `school_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `term_id` int(11) DEFAULT NULL,
  `fee_type` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`fee_id`),
  KEY `school_id` (`school_id`),
  KEY `class_id` (`class_id`),
  KEY `term_id` (`term_id`),
  KEY `fee_type` (`fee_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Add foreign key constraints (optional, if you want referential integrity)
-- ALTER TABLE `fee_structure` 
--   ADD CONSTRAINT `fk_fee_school` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE,
--   ADD CONSTRAINT `fk_fee_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE CASCADE,
--   ADD CONSTRAINT `fk_fee_term` FOREIGN KEY (`term_id`) REFERENCES `terms` (`term_id`) ON DELETE SET NULL;

-- ============================================================================
-- SAMPLE DATA (Optional - Remove if not needed)
-- ============================================================================

-- You can insert sample fee structures here for testing
-- Example:
-- INSERT INTO `fee_structure` (`school_id`, `class_id`, `term_id`, `fee_type`, `amount`, `description`)
-- VALUES 
--   (1, 1, 1, 'Tuition', 1500.00, 'First term tuition fees'),
--   (1, 1, 1, 'Facility', 200.00, 'Library and sports facility fees'),
--   (1, 1, 1, 'Exam', 100.00, 'Mid-term and final exam fees'),
--   (1, 2, 1, 'Tuition', 1800.00, 'First term tuition fees'),
--   (1, 2, NULL, 'Transport', 300.00, 'Monthly bus transportation fee');

-- ============================================================================
-- VERIFICATION QUERY
-- ============================================================================

-- Check if table was created successfully
SELECT 'Table created successfully!' as status;

-- View table structure
DESCRIBE fee_structure;

-- Count existing records
SELECT COUNT(*) as total_fees FROM fee_structure;

-- ============================================================================
-- INSTRUCTIONS
-- ============================================================================
-- 
-- HOW TO RUN THIS SCRIPT:
-- 
-- Method 1: phpMyAdmin
-- ---------------------
-- 1. Open: http://localhost/phpmyadmin
-- 2. Select: school_management_system database (left sidebar)
-- 3. Click: SQL tab (top menu)
-- 4. Copy & Paste: This entire script
-- 5. Click: Go button
-- 6. Verify: Success message appears
-- 
-- Method 2: MySQL Command Line
-- -----------------------------
-- 1. Open: Command Prompt
-- 2. Login: mysql -u root -p
-- 3. Use database: USE school_management_system;
-- 4. Source file: SOURCE C:/xampp/htdocs/msms/database/CREATE_FEE_STRUCTURE_TABLE.sql
-- 5. Verify: Table created
-- 
-- Method 3: Import via phpMyAdmin
-- --------------------------------
-- 1. Open: http://localhost/phpmyadmin
-- 2. Select: school_management_system database
-- 3. Click: Import tab
-- 4. Choose file: This SQL file
-- 5. Click: Go
-- 6. Verify: Success
-- 
-- ============================================================================
-- TROUBLESHOOTING
-- ============================================================================
-- 
-- Error: Table already exists
-- Solution: Table is already created! You're good to go.
-- 
-- Error: Access denied
-- Solution: Use root user or user with CREATE TABLE permission
-- 
-- Error: Unknown database
-- Solution: Ensure school_management_system database exists first
-- 
-- Error: Foreign key constraint fails
-- Solution: Comment out the ALTER TABLE section (lines with --)
-- 
-- ============================================================================
