-- Add fee payment frequency columns to students table
-- This allows tracking whether students pay canteen and bus fees daily, weekly, or monthly

USE school_management_system;

ALTER TABLE students 
ADD COLUMN IF NOT EXISTS canteen_fee_type ENUM('daily', 'weekly', 'monthly') DEFAULT 'daily' COMMENT 'Canteen fee payment frequency',
ADD COLUMN IF NOT EXISTS bus_fee_type ENUM('daily', 'weekly', 'monthly') DEFAULT 'daily' COMMENT 'Bus fee payment frequency';

-- Update existing students with exempt status to have NULL fee type (they don't pay)
UPDATE students SET canteen_fee_type = NULL WHERE exempt_canteen = 1;
UPDATE students SET bus_fee_type = NULL WHERE exempt_bus = 1;
