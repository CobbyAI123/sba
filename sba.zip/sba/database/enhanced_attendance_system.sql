-- ============================================================================
-- ENHANCED ATTENDANCE SYSTEM
-- Modern attendance tracking with QR codes, analytics, and notifications
-- Date: November 11, 2025
-- ============================================================================

-- Create QR Codes table for students
CREATE TABLE IF NOT EXISTS `student_qr_codes` (
  `qr_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `qr_code` VARCHAR(255) NOT NULL UNIQUE,
  `qr_image_path` VARCHAR(255) NULL,
  `generated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `expires_at` TIMESTAMP NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  PRIMARY KEY (`qr_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_qr_code` (`qr_code`),
  FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create Attendance Logs table (detailed tracking)
CREATE TABLE IF NOT EXISTS `attendance_logs` (
  `log_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `date` DATE NOT NULL,
  `time_in` TIME NULL,
  `time_out` TIME NULL,
  `status` ENUM('present', 'absent', 'late', 'excused', 'half_day') DEFAULT 'present',
  `check_in_method` ENUM('manual', 'qr_code', 'biometric', 'bulk') DEFAULT 'manual',
  `marked_by` INT(11) NOT NULL,
  `notes` TEXT NULL,
  `parent_notified` TINYINT(1) DEFAULT 0,
  `notification_sent_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `idx_student_date` (`student_id`, `date`),
  KEY `idx_school_date` (`school_id`, `date`),
  KEY `idx_class_date` (`class_id`, `date`),
  KEY `idx_status` (`status`),
  FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`class_id`) REFERENCES `classes`(`class_id`) ON DELETE CASCADE,
  FOREIGN KEY (`marked_by`) REFERENCES `users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create Attendance Summary table (for quick stats)
CREATE TABLE IF NOT EXISTS `attendance_summary` (
  `summary_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `term_id` INT(11) NULL,
  `month` INT(2) NOT NULL,
  `year` INT(4) NOT NULL,
  `total_days` INT(3) DEFAULT 0,
  `present_days` INT(3) DEFAULT 0,
  `absent_days` INT(3) DEFAULT 0,
  `late_days` INT(3) DEFAULT 0,
  `excused_days` INT(3) DEFAULT 0,
  `attendance_percentage` DECIMAL(5,2) DEFAULT 0.00,
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`summary_id`),
  UNIQUE KEY `idx_student_month_year` (`student_id`, `month`, `year`),
  KEY `idx_school` (`school_id`),
  KEY `idx_term` (`term_id`),
  FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create Absence Reasons table
CREATE TABLE IF NOT EXISTS `absence_reasons` (
  `reason_id` INT(11) NOT NULL AUTO_INCREMENT,
  `log_id` INT(11) NOT NULL,
  `reason` TEXT NOT NULL,
  `supporting_document` VARCHAR(255) NULL,
  `submitted_by` INT(11) NOT NULL COMMENT 'Parent or guardian user_id',
  `approved_by` INT(11) NULL COMMENT 'Teacher or admin who approved',
  `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  `submitted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` TIMESTAMP NULL,
  PRIMARY KEY (`reason_id`),
  KEY `idx_log` (`log_id`),
  KEY `idx_status` (`status`),
  FOREIGN KEY (`log_id`) REFERENCES `attendance_logs`(`log_id`) ON DELETE CASCADE,
  FOREIGN KEY (`submitted_by`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  FOREIGN KEY (`approved_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create Attendance Alerts table
CREATE TABLE IF NOT EXISTS `attendance_alerts` (
  `alert_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `school_id` INT(11) NOT NULL,
  `alert_type` ENUM('consecutive_absence', 'low_percentage', 'late_pattern', 'improvement_needed') NOT NULL,
  `message` TEXT NOT NULL,
  `threshold_value` DECIMAL(5,2) NULL,
  `current_value` DECIMAL(5,2) NULL,
  `is_resolved` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `resolved_at` TIMESTAMP NULL,
  PRIMARY KEY (`alert_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_alert_type` (`alert_type`),
  FOREIGN KEY (`student_id`) REFERENCES `students`(`student_id`) ON DELETE CASCADE,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create Attendance Settings table
CREATE TABLE IF NOT EXISTS `attendance_settings` (
  `setting_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `late_threshold_minutes` INT(3) DEFAULT 15,
  `half_day_threshold_minutes` INT(3) DEFAULT 240,
  `alert_consecutive_absence_days` INT(2) DEFAULT 3,
  `alert_low_percentage` DECIMAL(5,2) DEFAULT 75.00,
  `auto_notify_parents` TINYINT(1) DEFAULT 1,
  `allow_qr_checkin` TINYINT(1) DEFAULT 1,
  `require_checkout` TINYINT(1) DEFAULT 0,
  `grace_period_minutes` INT(3) DEFAULT 5,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `idx_school` (`school_id`),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

ALTER TABLE `attendance_logs` ADD INDEX `idx_created_at` (`created_at` DESC);
ALTER TABLE `attendance_summary` ADD INDEX `idx_percentage` (`attendance_percentage`);
ALTER TABLE `attendance_alerts` ADD INDEX `idx_is_resolved` (`is_resolved`);

-- ============================================================================
-- INSERT DEFAULT SETTINGS FOR EXISTING SCHOOLS
-- ============================================================================

INSERT INTO `attendance_settings` 
(`school_id`, `late_threshold_minutes`, `alert_consecutive_absence_days`, `alert_low_percentage`, `auto_notify_parents`)
SELECT school_id, 15, 3, 75.00, 1
FROM schools
WHERE school_id NOT IN (SELECT school_id FROM attendance_settings)
ON DUPLICATE KEY UPDATE setting_id=setting_id;

-- ============================================================================
-- USEFUL VIEWS
-- ============================================================================

-- View for today's attendance
CREATE OR REPLACE VIEW `todays_attendance` AS
SELECT 
    al.log_id,
    al.student_id,
    CONCAT(s.first_name, ' ', s.last_name) as student_name,
    c.class_name,
    al.status,
    al.time_in,
    al.time_out,
    al.check_in_method,
    al.notes,
    al.parent_notified
FROM attendance_logs al
INNER JOIN students s ON al.student_id = s.student_id
INNER JOIN classes c ON al.class_id = c.class_id
WHERE al.date = CURDATE();

-- View for attendance percentage by student
CREATE OR REPLACE VIEW `student_attendance_stats` AS
SELECT 
    s.student_id,
    CONCAT(s.first_name, ' ', s.last_name) as student_name,
    s.school_id,
    COUNT(CASE WHEN al.status = 'present' THEN 1 END) as present_count,
    COUNT(CASE WHEN al.status = 'absent' THEN 1 END) as absent_count,
    COUNT(CASE WHEN al.status = 'late' THEN 1 END) as late_count,
    COUNT(al.log_id) as total_days,
    ROUND((COUNT(CASE WHEN al.status = 'present' THEN 1 END) * 100.0 / NULLIF(COUNT(al.log_id), 0)), 2) as attendance_percentage
FROM students s
LEFT JOIN attendance_logs al ON s.student_id = al.student_id
GROUP BY s.student_id, s.first_name, s.last_name, s.school_id;

-- ============================================================================
-- STORED PROCEDURES
-- ============================================================================

DELIMITER //

-- Procedure to calculate attendance summary
CREATE PROCEDURE IF NOT EXISTS `calculate_attendance_summary`(
    IN p_student_id INT,
    IN p_month INT,
    IN p_year INT
)
BEGIN
    DECLARE v_total_days INT DEFAULT 0;
    DECLARE v_present_days INT DEFAULT 0;
    DECLARE v_absent_days INT DEFAULT 0;
    DECLARE v_late_days INT DEFAULT 0;
    DECLARE v_excused_days INT DEFAULT 0;
    DECLARE v_percentage DECIMAL(5,2) DEFAULT 0.00;
    DECLARE v_school_id INT;
    
    -- Get school_id
    SELECT school_id INTO v_school_id FROM students WHERE student_id = p_student_id;
    
    -- Calculate totals
    SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'present' THEN 1 END) as present,
        COUNT(CASE WHEN status = 'absent' THEN 1 END) as absent,
        COUNT(CASE WHEN status = 'late' THEN 1 END) as late,
        COUNT(CASE WHEN status = 'excused' THEN 1 END) as excused
    INTO v_total_days, v_present_days, v_absent_days, v_late_days, v_excused_days
    FROM attendance_logs
    WHERE student_id = p_student_id
    AND MONTH(date) = p_month
    AND YEAR(date) = p_year;
    
    -- Calculate percentage
    IF v_total_days > 0 THEN
        SET v_percentage = (v_present_days * 100.0 / v_total_days);
    END IF;
    
    -- Insert or update summary
    INSERT INTO attendance_summary 
    (student_id, school_id, month, year, total_days, present_days, absent_days, late_days, excused_days, attendance_percentage)
    VALUES 
    (p_student_id, v_school_id, p_month, p_year, v_total_days, v_present_days, v_absent_days, v_late_days, v_excused_days, v_percentage)
    ON DUPLICATE KEY UPDATE
    total_days = v_total_days,
    present_days = v_present_days,
    absent_days = v_absent_days,
    late_days = v_late_days,
    excused_days = v_excused_days,
    attendance_percentage = v_percentage;
END //

-- Procedure to check attendance alerts
CREATE PROCEDURE IF NOT EXISTS `check_attendance_alerts`(
    IN p_student_id INT
)
BEGIN
    DECLARE v_school_id INT;
    DECLARE v_consecutive_absences INT DEFAULT 0;
    DECLARE v_attendance_percentage DECIMAL(5,2) DEFAULT 0;
    DECLARE v_alert_threshold INT DEFAULT 3;
    DECLARE v_percentage_threshold DECIMAL(5,2) DEFAULT 75.00;
    
    -- Get school settings
    SELECT 
        s.school_id,
        COALESCE(ats.alert_consecutive_absence_days, 3),
        COALESCE(ats.alert_low_percentage, 75.00)
    INTO v_school_id, v_alert_threshold, v_percentage_threshold
    FROM students s
    LEFT JOIN attendance_settings ats ON s.school_id = ats.school_id
    WHERE s.student_id = p_student_id;
    
    -- Check consecutive absences
    SELECT COUNT(*) INTO v_consecutive_absences
    FROM (
        SELECT date, status,
        @row_num := IF(@prev_status = status, @row_num + 1, 1) as consecutive,
        @prev_status := status
        FROM attendance_logs, (SELECT @row_num := 0, @prev_status := '') as vars
        WHERE student_id = p_student_id
        ORDER BY date DESC
        LIMIT 10
    ) as sub
    WHERE status = 'absent' AND consecutive >= v_alert_threshold;
    
    -- Create alert if needed
    IF v_consecutive_absences >= v_alert_threshold THEN
        INSERT INTO attendance_alerts 
        (student_id, school_id, alert_type, message, threshold_value, current_value, is_resolved)
        VALUES 
        (p_student_id, v_school_id, 'consecutive_absence', 
         CONCAT('Student has been absent for ', v_consecutive_absences, ' consecutive days'),
         v_alert_threshold, v_consecutive_absences, 0)
        ON DUPLICATE KEY UPDATE current_value = v_consecutive_absences, is_resolved = 0;
    END IF;
    
    -- Check attendance percentage
    SELECT attendance_percentage INTO v_attendance_percentage
    FROM student_attendance_stats
    WHERE student_id = p_student_id;
    
    IF v_attendance_percentage < v_percentage_threshold THEN
        INSERT INTO attendance_alerts 
        (student_id, school_id, alert_type, message, threshold_value, current_value, is_resolved)
        VALUES 
        (p_student_id, v_school_id, 'low_percentage',
         CONCAT('Student attendance percentage (', v_attendance_percentage, '%) is below threshold'),
         v_percentage_threshold, v_attendance_percentage, 0)
        ON DUPLICATE KEY UPDATE current_value = v_attendance_percentage, is_resolved = 0;
    END IF;
END //

DELIMITER ;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT 'Enhanced Attendance System tables created successfully!' as status;
SELECT 'Tables: student_qr_codes, attendance_logs, attendance_summary, absence_reasons, attendance_alerts, attendance_settings' as info;
SELECT 'Views: todays_attendance, student_attendance_stats' as views_created;
SELECT 'Procedures: calculate_attendance_summary, check_attendance_alerts' as procedures_created;
