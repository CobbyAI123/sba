-- Email Notification System Tables

CREATE TABLE IF NOT EXISTS `email_queue` (
  `email_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `to_email` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `body` LONGTEXT NOT NULL,
  `status` ENUM('pending', 'sent', 'failed', 'bounced') DEFAULT 'pending',
  `retry_count` INT DEFAULT 0,
  `last_error` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `sent_at` DATETIME,
  `scheduled_for` DATETIME,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_school_status` (`school_id`, `status`),
  INDEX `idx_created_at` (`created_at`),
  INDEX `idx_scheduled_for` (`scheduled_for`)
);

CREATE TABLE IF NOT EXISTS `email_templates` (
  `template_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `template_name` VARCHAR(100) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `body` LONGTEXT NOT NULL,
  `description` TEXT,
  `is_active` BOOLEAN DEFAULT 1,
  `created_by` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_school_name` (`school_id`, `template_name`),
  INDEX `idx_is_active` (`is_active`),
  UNIQUE KEY `unique_school_template` (`school_id`, `template_name`)
);

CREATE TABLE IF NOT EXISTS `email_logs` (
  `log_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `to_email` VARCHAR(255) NOT NULL,
  `subject` VARCHAR(255),
  `status` ENUM('sent', 'failed', 'pending', 'bounced') DEFAULT 'pending',
  `error_message` TEXT,
  `recipient_name` VARCHAR(100),
  `email_type` VARCHAR(50),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_school_status` (`school_id`, `status`),
  INDEX `idx_email` (`to_email`),
  INDEX `idx_created_at` (`created_at`),
  INDEX `idx_email_type` (`email_type`)
);

CREATE TABLE IF NOT EXISTS `email_settings` (
  `setting_id` INT PRIMARY KEY AUTO_INCREMENT,
  `school_id` INT NOT NULL,
  `smtp_host` VARCHAR(255),
  `smtp_port` INT DEFAULT 587,
  `smtp_secure` ENUM('none', 'tls', 'ssl') DEFAULT 'tls',
  `smtp_username` VARCHAR(255),
  `smtp_password` VARCHAR(255),
  `from_email` VARCHAR(255) NOT NULL,
  `from_name` VARCHAR(255),
  `reply_to_email` VARCHAR(255),
  `max_retries` INT DEFAULT 3,
  `is_enabled` BOOLEAN DEFAULT 1,
  `queue_enabled` BOOLEAN DEFAULT 1,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE,
  INDEX `idx_school_id` (`school_id`),
  UNIQUE KEY `unique_school` (`school_id`)
);

-- Insert default templates
-- Verify schools table has school_id = 1
INSERT IGNORE INTO `schools` (school_id, school_name, status) VALUES (1, 'Default School', 'active');

-- Note: description column already exists in email_templates table definition
-- No need to add it separately

-- Clear existing templates if any
DELETE FROM `email_templates` WHERE school_id = 1;

-- Insert default templates
INSERT INTO `email_templates` (school_id, template_name, subject, body, description) VALUES
(1, 'payment_reminder', 'Payment Reminder - {{student_name}}', 
 '<h3>Payment Reminder</h3><p>Dear Parent/Guardian,</p><p>This is to remind you that payment of <strong>{{amount}}</strong> is due by <strong>{{due_date}}</strong> for <strong>{{student_name}}</strong>.</p><p>Please make payment at your earliest convenience.</p><p>Best regards,<br>{{school_name}}</p>',
 'Email reminder for upcoming school fees payment'),

(1, 'payment_received', 'Payment Received - {{student_name}}',
 '<h3>Payment Confirmation</h3><p>Dear Parent/Guardian,</p><p>We acknowledge receipt of your payment of <strong>{{amount}}</strong> on <strong>{{payment_date}}</strong> for <strong>{{student_name}}</strong>.</p><p>Reference Number: <strong>{{reference_number}}</strong></p><p>Thank you for your prompt payment.</p><p>Best regards,<br>{{school_name}}</p>',
 'Confirmation email when payment is received'),

(1, 'attendance_alert', 'Attendance Alert - {{student_name}}',
 '<h3>Attendance Alert</h3><p>Dear Parent/Guardian,</p><p>We write to inform you that <strong>{{student_name}}</strong> in <strong>{{class_name}}</strong> has been absent <strong>{{absent_count}}</strong> times this term.</p><p>We request your immediate attention to this matter.</p><p>Best regards,<br>{{school_name}}</p>',
 'Alert when student attendance is low'),

(1, 'results_published', 'Results Available - {{student_name}}',
 '<h3>Academic Results Published</h3><p>Dear Parent/Guardian,</p><p>The {{term}} results for <strong>{{student_name}}</strong> in <strong>{{class_name}}</strong> are now available.</p><p>Please log in to the portal to view the results.</p><p>Best regards,<br>{{school_name}}</p>',
 'Notification when exam results are published'),

(1, 'event_notification', 'Event Notification - {{event_name}}',
 '<h3>{{event_name}}</h3><p>Dear {{recipient_name}},</p><p><strong>Date:</strong> {{event_date}}<br><strong>Time:</strong> {{event_time}}<br><strong>Location:</strong> {{event_location}}</p><p>We look forward to your participation.</p><p>Best regards,<br>{{school_name}}</p>',
 'General event notification template'),

(1, 'account_notification', 'Account Update - {{user_name}}',
 '<h3>Account Notification</h3><p>Dear {{user_name}},</p><p>This is to notify you of the following account update:</p><p><strong>Action:</strong> {{action}}<br><strong>Date:</strong> {{update_date}}</p><p>If you did not make this change, please contact the administrator immediately.</p><p>Best regards,<br>{{school_name}}</p>',
 'Notification for account-related updates'),

(1, 'system_alert', 'System Alert - {{alert_type}}',
 '<h3>System Alert</h3><p>Dear Administrator,</p><p>A system alert has been triggered:</p><p><strong>Type:</strong> {{alert_type}}<br><strong>Message:</strong> {{alert_message}}<br><strong>Time:</strong> {{alert_time}}</p><p>Please review and take appropriate action.</p><p>Best regards,<br>System Administrator</p>',
 'System notifications for administrators');
