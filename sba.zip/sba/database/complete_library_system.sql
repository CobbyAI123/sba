-- Complete Library System Database Schema
-- Run this file to set up the complete library management system
-- Last Updated: November 5, 2024

-- ============================================
-- Library Books Table
-- ============================================
CREATE TABLE IF NOT EXISTS library_books (
    book_id INT PRIMARY KEY AUTO_INCREMENT,
    school_id INT NOT NULL,
    isbn VARCHAR(20),
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    publisher VARCHAR(255),
    publication_year YEAR,
    category VARCHAR(100),
    quantity INT DEFAULT 1,
    available_quantity INT DEFAULT 1,
    status ENUM('available', 'borrowed', 'maintenance', 'lost') DEFAULT 'available',
    shelf_location VARCHAR(50),
    description TEXT,
    cover_image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
    INDEX idx_school_status (school_id, status),
    INDEX idx_isbn (isbn),
    INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Library Transactions Table
-- ============================================
CREATE TABLE IF NOT EXISTS library_transactions (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    school_id INT NOT NULL,
    book_id INT NOT NULL,
    student_id INT NOT NULL,
    borrow_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE,
    status ENUM('borrowed', 'returned', 'overdue') DEFAULT 'borrowed',
    fine_amount DECIMAL(10,2) DEFAULT 0.00,
    fine_paid ENUM('yes', 'no') DEFAULT 'no',
    notes TEXT,
    issued_by INT,
    returned_to INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES library_books(book_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (issued_by) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (returned_to) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_school_status (school_id, status),
    INDEX idx_student (student_id),
    INDEX idx_book (book_id),
    INDEX idx_due_date (due_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Library Fines Table
-- ============================================
CREATE TABLE IF NOT EXISTS library_fines (
    fine_id INT PRIMARY KEY AUTO_INCREMENT,
    school_id INT NOT NULL,
    student_id INT NOT NULL,
    book_id INT,
    transaction_id INT,
    reason ENUM('overdue', 'damage', 'lost', 'other') DEFAULT 'overdue',
    amount_due DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    amount_paid DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('unpaid', 'paid', 'waived', 'partial') DEFAULT 'unpaid',
    notes TEXT,
    paid_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES library_books(book_id) ON DELETE SET NULL,
    FOREIGN KEY (transaction_id) REFERENCES library_transactions(transaction_id) ON DELETE SET NULL,
    INDEX idx_school_status (school_id, status),
    INDEX idx_student (student_id),
    INDEX idx_book (book_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Library Categories Table
-- ============================================
CREATE TABLE IF NOT EXISTS library_categories (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    school_id INT NOT NULL,
    category_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
    UNIQUE KEY unique_category (school_id, category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Insert Default Categories
-- ============================================
INSERT IGNORE INTO library_categories (school_id, category_name, description) 
SELECT school_id, 'Fiction', 'Fictional literature and novels' FROM schools
UNION ALL
SELECT school_id, 'Non-Fiction', 'Factual books and references' FROM schools
UNION ALL
SELECT school_id, 'Science', 'Science and technology books' FROM schools
UNION ALL
SELECT school_id, 'Mathematics', 'Mathematics textbooks and references' FROM schools
UNION ALL
SELECT school_id, 'History', 'Historical books and references' FROM schools
UNION ALL
SELECT school_id, 'Biography', 'Biographies and autobiographies' FROM schools
UNION ALL
SELECT school_id, 'Reference', 'Dictionaries, encyclopedias, etc.' FROM schools
UNION ALL
SELECT school_id, 'Children', 'Children\'s books' FROM schools;

-- ============================================
-- Sample Data (Optional - for testing)
-- ============================================
-- Uncomment to add sample books for testing

/*
INSERT INTO library_books (school_id, title, author, isbn, publisher, publication_year, category, quantity, available_quantity, shelf_location, description)
SELECT 
    school_id,
    'Things Fall Apart',
    'Chinua Achebe',
    '978-0385474542',
    'Anchor Books',
    1958,
    'Fiction',
    5,
    5,
    'A-12',
    'A classic African novel about pre-colonial life in Nigeria'
FROM schools
LIMIT 1;

INSERT INTO library_books (school_id, title, author, isbn, publisher, publication_year, category, quantity, available_quantity, shelf_location, description)
SELECT 
    school_id,
    'Introduction to Algorithms',
    'Thomas H. Cormen',
    '978-0262033848',
    'MIT Press',
    2009,
    'Science',
    3,
    3,
    'B-05',
    'Comprehensive guide to algorithms and data structures'
FROM schools
LIMIT 1;
*/

-- ============================================
-- Verification Queries
-- ============================================
-- Run these to verify the tables were created successfully

-- SELECT 'Library Books Table' as Table_Name, COUNT(*) as Record_Count FROM library_books;
-- SELECT 'Library Transactions Table' as Table_Name, COUNT(*) as Record_Count FROM library_transactions;
-- SELECT 'Library Fines Table' as Table_Name, COUNT(*) as Record_Count FROM library_fines;
-- SELECT 'Library Categories Table' as Table_Name, COUNT(*) as Record_Count FROM library_categories;

-- ============================================
-- Completion Message
-- ============================================
SELECT 'Library System Database Setup Complete!' as Status;
