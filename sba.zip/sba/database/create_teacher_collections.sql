-- ============================================================================
-- CREATE TEACHER COLLECTIONS TABLE
-- Track money collected from canteen and bus teachers
-- ============================================================================

CREATE TABLE IF NOT EXISTS `teacher_collections` (
  `collection_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `teacher_id` INT(11) NOT NULL COMMENT 'Teacher assigned to canteen/bus',
  `collection_type` VARCHAR(20) NOT NULL COMMENT 'canteen or bus',
  `amount` DECIMAL(10,2) NOT NULL,
  `collection_date` DATE NOT NULL,
  `payment_method` VARCHAR(50) NOT NULL COMMENT 'cash, bank_transfer, mobile_money, cheque',
  `reference` VARCHAR(100) DEFAULT NULL COMMENT 'Receipt or cheque number',
  `remarks` TEXT DEFAULT NULL,
  `recorded_by` INT(11) NOT NULL COMMENT 'Accountant who recorded',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`collection_id`),
  KEY `idx_school_id` (`school_id`),
  KEY `idx_teacher_id` (`teacher_id`),
  KEY `idx_collection_type` (`collection_type`),
  KEY `idx_collection_date` (`collection_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ============================================================================
-- ADD INDEXES FOR BETTER PERFORMANCE
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_teacher_type ON teacher_collections(teacher_id, collection_type);
CREATE INDEX IF NOT EXISTS idx_school_date ON teacher_collections(school_id, collection_date);

-- ============================================================================
-- SAMPLE DATA (OPTIONAL - FOR TESTING)
-- ============================================================================

-- Insert sample collection records
-- Note: Adjust teacher_id and school_id values based on your data

-- INSERT INTO teacher_collections 
-- (school_id, teacher_id, collection_type, amount, collection_date, payment_method, reference, remarks, recorded_by)
-- VALUES 
-- (1, 5, 'canteen', 500.00, '2025-01-01', 'cash', 'REC001', 'Weekly canteen collection', 3),
-- (1, 6, 'bus', 1000.00, '2025-01-01', 'bank_transfer', 'TRF001', 'Monthly bus collection', 3);

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Check if table was created
SHOW TABLES LIKE 'teacher_collections';

-- View table structure
DESCRIBE teacher_collections;

SELECT 'Teacher collections table created successfully!' as status;

-- ============================================================================
-- USAGE NOTES
-- ============================================================================
-- 
-- This table tracks:
-- 1. Money collected from teachers assigned to canteen services
-- 2. Money collected from teachers assigned to bus/transport services
-- 3. Payment method, reference, and dates
-- 4. Who recorded the collection (accountant)
-- 
-- Collection types:
-- - 'canteen' - Collections from canteen teachers
-- - 'bus' - Collections from bus/transport teachers
-- 
-- Payment methods:
-- - 'cash' - Cash payment
-- - 'bank_transfer' - Bank transfer
-- - 'mobile_money' - Mobile money (MTN, Vodafone, etc.)
-- - 'cheque' - Cheque payment
-- 
-- ============================================================================
