-- ============================================
-- SIMPLE FIX FOR USERS TABLE
-- Run this in phpMyAdmin SQL tab
-- ============================================

-- Check if columns exist first
SHOW COLUMNS FROM users;

-- Add first_name column (safe - won't fail if exists)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS first_name VARCHAR(100) NULL AFTER email;

-- Add last_name column (safe - won't fail if exists)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS last_name VARCHAR(100) NULL AFTER first_name;

-- Add phone column (safe - won't fail if exists)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS phone VARCHAR(20) NULL AFTER last_name;

-- Verify columns were added
SHOW COLUMNS FROM users;

SELECT 'SUCCESS: Users table has been fixed!' as Message;
