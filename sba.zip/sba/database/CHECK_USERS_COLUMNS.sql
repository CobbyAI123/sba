-- Check what columns currently exist in the users table
DESCRIBE `users`;
