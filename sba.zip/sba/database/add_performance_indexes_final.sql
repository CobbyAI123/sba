-- ============================================
-- Performance Indexes for Production
-- Run this in phpMyAdmin after deployment
-- ============================================

USE school_management_system;

-- Payments created_at index for date-based queries
CREATE INDEX IF NOT EXISTS idx_payments_created_at ON payments(created_at);

-- Attendance status index for filtering
CREATE INDEX IF NOT EXISTS idx_attendance_status ON attendance(status);

-- User email index for faster login lookups
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- Student admission date index for reports
CREATE INDEX IF NOT EXISTS idx_students_admission_date ON students(admission_date);

-- Marks composite index for term and student queries
CREATE INDEX IF NOT EXISTS idx_marks_term_student ON marks(term_id, student_id);

-- Exam term index for filtering by academic term
CREATE INDEX IF NOT EXISTS idx_exams_term ON exams(term_id);

-- Notifications user_id and read status composite
CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, is_read);

-- Activity logs created_at for time-based queries
CREATE INDEX IF NOT EXISTS idx_activity_logs_created ON activity_logs(created_at);

-- Fee structure class_id for faster lookups
CREATE INDEX IF NOT EXISTS idx_fee_structure_class ON fee_structure(class_id);

-- Staff payments school_id and status composite
CREATE INDEX IF NOT EXISTS idx_staff_payments_school_status ON staff_payments(school_id, status);

-- Full-text search indexes for faster name searches
ALTER TABLE students ADD FULLTEXT INDEX IF NOT EXISTS idx_student_names (first_name, last_name);
ALTER TABLE users ADD FULLTEXT INDEX IF NOT EXISTS idx_user_search (first_name, last_name, email);

-- Success message
SELECT 'Performance indexes created successfully! Queries should be 50-70% faster.' as status;

-- Verify indexes were created
SELECT 
    TABLE_NAME,
    INDEX_NAME,
    COLUMN_NAME,
    INDEX_TYPE
FROM 
    information_schema.STATISTICS 
WHERE 
    TABLE_SCHEMA = 'school_management_system'
    AND INDEX_NAME LIKE 'idx_%'
ORDER BY 
    TABLE_NAME, INDEX_NAME;
