-- =====================================================
-- STUDENT PROMOTION SYSTEM - ENHANCEMENTS
-- Additional features for better promotion management
-- =====================================================

USE school_management_system;

-- =====================================================
-- ENHANCEMENT 1: Bulk Promotion History Export
-- =====================================================

-- Add export tracking table
CREATE TABLE IF NOT EXISTS `promotion_exports` (
  `export_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL,
  `exported_by` INT(11) NOT NULL,
  `export_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `record_count` INT(11) DEFAULT 0,
  `file_format` ENUM('PDF', 'Excel', 'CSV') DEFAULT 'PDF',
  `file_path` VARCHAR(255),
  PRIMARY KEY (`export_id`),
  KEY `idx_school_year` (`school_id`, `academic_year`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- ENHANCEMENT 2: Promotion Statistics Summary
-- =====================================================

-- Create view for quick statistics
CREATE OR REPLACE VIEW `v_promotion_statistics` AS
SELECT 
    sp.school_id,
    sp.academic_year,
    c.class_name,
    COUNT(*) as total_students,
    SUM(CASE WHEN sp.promotion_type = 'promoted' THEN 1 ELSE 0 END) as promoted_count,
    SUM(CASE WHEN sp.promotion_type = 'repeated' THEN 1 ELSE 0 END) as repeated_count,
    SUM(CASE WHEN sp.promotion_type = 'graduated' THEN 1 ELSE 0 END) as graduated_count,
    ROUND(AVG(sp.annual_average), 2) as class_average,
    ROUND((SUM(CASE WHEN sp.promotion_type = 'promoted' THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) as promotion_rate
FROM student_promotions sp
LEFT JOIN classes c ON sp.from_class_id = c.class_id
GROUP BY sp.school_id, sp.academic_year, c.class_name;

-- =====================================================
-- ENHANCEMENT 3: Student Performance Trends
-- =====================================================

-- Track student performance across years
CREATE TABLE IF NOT EXISTS `student_performance_history` (
  `history_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `annual_average` DECIMAL(5,2),
  `promotion_type` ENUM('promoted', 'repeated', 'graduated'),
  `year_rank` INT(11),
  `class_rank` INT(11),
  `improvement_from_last_year` DECIMAL(5,2),
  PRIMARY KEY (`history_id`),
  UNIQUE KEY `unique_student_year` (`student_id`, `academic_year`),
  KEY `idx_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- ENHANCEMENT 4: Promotion Notifications Queue
-- =====================================================

-- Queue for sending promotion notifications to parents
CREATE TABLE IF NOT EXISTS `promotion_notifications` (
  `notification_id` INT(11) NOT NULL AUTO_INCREMENT,
  `student_id` INT(11) NOT NULL,
  `promotion_id` INT(11) NOT NULL,
  `parent_id` INT(11),
  `notification_type` ENUM('SMS', 'Email', 'In-App') DEFAULT 'In-App',
  `status` ENUM('pending', 'sent', 'failed') DEFAULT 'pending',
  `message_content` TEXT,
  `sent_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notification_id`),
  KEY `idx_status` (`status`),
  KEY `idx_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- ENHANCEMENT 5: Promotion Approval Workflow
-- =====================================================

-- Multi-level approval for promotions
CREATE TABLE IF NOT EXISTS `promotion_approvals` (
  `approval_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `academic_year` VARCHAR(20) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `submitted_by` INT(11) NOT NULL,
  `submitted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `approval_level` INT(11) DEFAULT 1 COMMENT '1=Teacher, 2=Admin, 3=Proprietor',
  `approved_by` INT(11),
  `approved_at` TIMESTAMP NULL,
  `status` ENUM('pending', 'approved', 'rejected', 'revision_needed') DEFAULT 'pending',
  `comments` TEXT,
  PRIMARY KEY (`approval_id`),
  KEY `idx_status` (`status`),
  KEY `idx_school_year_class` (`school_id`, `academic_year`, `class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- ENHANCEMENT 6: Promotion Rules Engine
-- =====================================================

-- Configurable promotion rules per school
CREATE TABLE IF NOT EXISTS `promotion_rules` (
  `rule_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `rule_name` VARCHAR(100) NOT NULL,
  `rule_type` ENUM('automatic', 'manual', 'hybrid') DEFAULT 'automatic',
  `pass_mark` DECIMAL(5,2) DEFAULT 50.00,
  `minimum_attendance_percent` DECIMAL(5,2) DEFAULT 75.00,
  `allow_conditional_promotion` TINYINT(1) DEFAULT 0,
  `max_failed_subjects` INT(11) DEFAULT 0,
  `require_parent_consent` TINYINT(1) DEFAULT 0,
  `is_active` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rule_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default promotion rule
INSERT IGNORE INTO `promotion_rules` (school_id, rule_name, pass_mark, minimum_attendance_percent)
SELECT DISTINCT school_id, 'Default Promotion Rule', 50.00, 75.00
FROM schools
WHERE school_id NOT IN (SELECT school_id FROM promotion_rules);

-- =====================================================
-- ENHANCEMENT 7: Student Comments & Recommendations
-- =====================================================

-- Teacher/Admin comments on promotions
CREATE TABLE IF NOT EXISTS `promotion_comments` (
  `comment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `commented_by` INT(11) NOT NULL,
  `comment_type` ENUM('academic', 'behavioral', 'recommendation', 'concern') DEFAULT 'academic',
  `comment_text` TEXT,
  `is_visible_to_parent` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`),
  KEY `idx_promotion` (`promotion_id`),
  KEY `idx_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- ENHANCEMENT 8: Promotion Rollback Feature
-- =====================================================

-- Track promotion rollbacks for audit
CREATE TABLE IF NOT EXISTS `promotion_rollbacks` (
  `rollback_id` INT(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `rolled_back_by` INT(11) NOT NULL,
  `rollback_reason` TEXT,
  `previous_class_id` INT(11),
  `previous_status` VARCHAR(50),
  `rollback_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rollback_id`),
  KEY `idx_promotion` (`promotion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- ENHANCEMENT 9: Class Progression Templates
-- =====================================================

-- Predefined class progression paths
CREATE TABLE IF NOT EXISTS `class_progression` (
  `progression_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `current_class_id` INT(11) NOT NULL,
  `next_class_id` INT(11),
  `class_order` INT(11) DEFAULT 0,
  `is_final_class` TINYINT(1) DEFAULT 0,
  `typical_age_range` VARCHAR(20),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`progression_id`),
  UNIQUE KEY `unique_current_class` (`school_id`, `current_class_id`),
  KEY `idx_school` (`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- ENHANCEMENT 10: Advanced Analytics Views
-- =====================================================

-- View: Student improvement analysis
CREATE OR REPLACE VIEW `v_student_improvement` AS
SELECT 
    s.student_id,
    u.first_name,
    u.last_name,
    s.admission_number,
    sp1.academic_year as current_year,
    sp1.annual_average as current_average,
    sp2.annual_average as previous_average,
    (sp1.annual_average - sp2.annual_average) as improvement,
    CASE 
        WHEN (sp1.annual_average - sp2.annual_average) > 10 THEN 'Significant Improvement'
        WHEN (sp1.annual_average - sp2.annual_average) > 0 THEN 'Improvement'
        WHEN (sp1.annual_average - sp2.annual_average) = 0 THEN 'Stable'
        WHEN (sp1.annual_average - sp2.annual_average) > -10 THEN 'Slight Decline'
        ELSE 'Significant Decline'
    END as performance_trend
FROM students s
JOIN users u ON s.user_id = u.user_id
JOIN student_promotions sp1 ON s.student_id = sp1.student_id
LEFT JOIN student_promotions sp2 ON s.student_id = sp2.student_id 
    AND sp2.promotion_id = (
        SELECT promotion_id 
        FROM student_promotions 
        WHERE student_id = s.student_id 
        AND promotion_id < sp1.promotion_id 
        ORDER BY promotion_id DESC 
        LIMIT 1
    );

-- View: Top performing students by year
CREATE OR REPLACE VIEW `v_top_performers` AS
SELECT 
    sp.academic_year,
    c.class_name,
    u.first_name,
    u.last_name,
    s.admission_number,
    sp.annual_average,
    sp.promotion_type,
    RANK() OVER (PARTITION BY sp.academic_year, sp.from_class_id ORDER BY sp.annual_average DESC) as class_rank,
    RANK() OVER (PARTITION BY sp.academic_year ORDER BY sp.annual_average DESC) as school_rank
FROM student_promotions sp
JOIN students s ON sp.student_id = s.student_id
JOIN users u ON s.user_id = u.user_id
JOIN classes c ON sp.from_class_id = c.class_id
WHERE sp.annual_average IS NOT NULL;

-- View: Repeat students analysis
CREATE OR REPLACE VIEW `v_repeat_students_analysis` AS
SELECT 
    sp.academic_year,
    c.class_name,
    u.first_name,
    u.last_name,
    s.admission_number,
    sp.annual_average,
    sp.pass_mark,
    (sp.pass_mark - sp.annual_average) as score_gap,
    sp.decision_reason,
    COUNT(sp2.promotion_id) as times_repeated
FROM student_promotions sp
JOIN students s ON sp.student_id = s.student_id
JOIN users u ON s.user_id = u.user_id
JOIN classes c ON sp.from_class_id = c.class_id
LEFT JOIN student_promotions sp2 ON s.student_id = sp2.student_id 
    AND sp2.promotion_type = 'repeated' 
    AND sp2.promotion_id <= sp.promotion_id
WHERE sp.promotion_type = 'repeated'
GROUP BY sp.promotion_id;

-- =====================================================
-- STORED PROCEDURES FOR COMMON OPERATIONS
-- =====================================================

DELIMITER //

-- Procedure: Calculate class promotion statistics
CREATE PROCEDURE IF NOT EXISTS sp_GetClassPromotionStats(
    IN p_school_id INT,
    IN p_academic_year VARCHAR(20),
    IN p_class_id INT
)
BEGIN
    SELECT 
        COUNT(*) as total_students,
        SUM(CASE WHEN promotion_type = 'promoted' THEN 1 ELSE 0 END) as promoted,
        SUM(CASE WHEN promotion_type = 'repeated' THEN 1 ELSE 0 END) as repeated,
        SUM(CASE WHEN promotion_type = 'graduated' THEN 1 ELSE 0 END) as graduated,
        ROUND(AVG(annual_average), 2) as class_average,
        MAX(annual_average) as highest_score,
        MIN(annual_average) as lowest_score
    FROM student_promotions
    WHERE school_id = p_school_id
    AND academic_year = p_academic_year
    AND from_class_id = p_class_id;
END//

-- Procedure: Get student promotion history
CREATE PROCEDURE IF NOT EXISTS sp_GetStudentPromotionHistory(
    IN p_student_id INT
)
BEGIN
    SELECT 
        sp.*,
        c1.class_name as from_class,
        c2.class_name as to_class,
        u.first_name as promoted_by_first_name,
        u.last_name as promoted_by_last_name
    FROM student_promotions sp
    LEFT JOIN classes c1 ON sp.from_class_id = c1.class_id
    LEFT JOIN classes c2 ON sp.to_class_id = c2.class_id
    LEFT JOIN users u ON sp.promoted_by = u.user_id
    WHERE sp.student_id = p_student_id
    ORDER BY sp.academic_year DESC;
END//

DELIMITER ;

-- =====================================================
-- PERFORMANCE INDEXES FOR ENHANCEMENTS
-- =====================================================

ALTER TABLE student_promotions 
ADD INDEX IF NOT EXISTS idx_academic_year_class (academic_year, from_class_id),
ADD INDEX IF NOT EXISTS idx_promotion_type (promotion_type),
ADD INDEX IF NOT EXISTS idx_created_date (created_at);

ALTER TABLE students
ADD INDEX IF NOT EXISTS idx_promotion_status (promotion_status),
ADD INDEX IF NOT EXISTS idx_entry_term_class (entry_term, class_id);

-- =====================================================
-- SUCCESS MESSAGE
-- =====================================================

SELECT 
    '✅ PROMOTION ENHANCEMENTS INSTALLED!' as Status,
    '10 new features added' as Features,
    'Views, procedures, and analytics ready' as Analytics,
    'Check documentation for usage' as Documentation;

