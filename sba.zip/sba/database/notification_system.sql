-- ============================================================================
-- NOTIFICATION SYSTEM DATABASE
-- SMS, Email, and In-App notification management
-- Date: November 11, 2025
-- ============================================================================

-- Notification Templates Table (enhanced)
CREATE TABLE IF NOT EXISTS `notification_templates` (
  `template_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `template_name` VARCHAR(100) NOT NULL,
  `template_code` VARCHAR(50) NOT NULL UNIQUE COMMENT 'e.g., ABSENCE_ALERT, FEE_REMINDER',
  `notification_type` ENUM('sms', 'email', 'in_app', 'all') DEFAULT 'all',
  `subject` VARCHAR(255) NULL COMMENT 'For email',
  `message_template` TEXT NOT NULL COMMENT 'Use {STUDENT_NAME}, {DATE}, etc. for variables',
  `category` VARCHAR(50) NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `is_system` TINYINT(1) DEFAULT 0 COMMENT 'System templates cannot be deleted',
  `created_by` INT(11) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `idx_template_code` (`template_code`),
  KEY `idx_school` (`school_id`),
  KEY `idx_type` (`notification_type`),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Notification Settings Table
CREATE TABLE IF NOT EXISTS `notification_settings` (
  `setting_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  
  -- SMS Settings
  `sms_enabled` TINYINT(1) DEFAULT 0,
  `sms_gateway` ENUM('twilio', 'africastalking', 'nexmo', 'custom') NULL,
  `sms_api_key` VARCHAR(255) NULL,
  `sms_api_secret` VARCHAR(255) NULL,
  `sms_sender_id` VARCHAR(50) NULL,
  `sms_balance` DECIMAL(10,2) DEFAULT 0.00,
  
  -- Email Settings
  `email_enabled` TINYINT(1) DEFAULT 1,
  `smtp_host` VARCHAR(255) NULL,
  `smtp_port` INT(5) DEFAULT 587,
  `smtp_username` VARCHAR(255) NULL,
  `smtp_password` VARCHAR(255) NULL,
  `smtp_encryption` ENUM('none', 'ssl', 'tls') DEFAULT 'tls',
  `email_from_address` VARCHAR(255) NULL,
  `email_from_name` VARCHAR(100) NULL,
  
  -- In-App Notifications
  `in_app_enabled` TINYINT(1) DEFAULT 1,
  
  -- Auto Notifications
  `auto_absence_notification` TINYINT(1) DEFAULT 1,
  `auto_fee_reminder` TINYINT(1) DEFAULT 1,
  `auto_result_notification` TINYINT(1) DEFAULT 1,
  `auto_exam_reminder` TINYINT(1) DEFAULT 1,
  
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `idx_school` (`school_id`),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Notification Queue Table
CREATE TABLE IF NOT EXISTS `notification_queue` (
  `queue_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `notification_type` ENUM('sms', 'email', 'in_app') NOT NULL,
  `recipient_user_id` INT(11) NULL,
  `recipient_phone` VARCHAR(20) NULL,
  `recipient_email` VARCHAR(255) NULL,
  `subject` VARCHAR(255) NULL,
  `message` TEXT NOT NULL,
  `template_code` VARCHAR(50) NULL,
  `priority` ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal',
  `status` ENUM('pending', 'processing', 'sent', 'failed', 'cancelled') DEFAULT 'pending',
  `retry_count` INT(2) DEFAULT 0,
  `max_retries` INT(2) DEFAULT 3,
  `scheduled_at` TIMESTAMP NULL,
  `sent_at` TIMESTAMP NULL,
  `failed_at` TIMESTAMP NULL,
  `error_message` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`queue_id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`notification_type`),
  KEY `idx_scheduled` (`scheduled_at`),
  KEY `idx_school` (`school_id`),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Notification History Table (consolidated)
CREATE TABLE IF NOT EXISTS `notification_history` (
  `history_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `user_id` INT(11) NULL,
  `notification_type` ENUM('sms', 'email', 'in_app') NOT NULL,
  `recipient_phone` VARCHAR(20) NULL,
  `recipient_email` VARCHAR(255) NULL,
  `subject` VARCHAR(255) NULL,
  `message` TEXT NOT NULL,
  `template_code` VARCHAR(50) NULL,
  `status` ENUM('sent', 'failed', 'read', 'unread') DEFAULT 'sent',
  `cost` DECIMAL(10,4) NULL COMMENT 'Cost for SMS',
  `gateway_response` TEXT NULL,
  `read_at` TIMESTAMP NULL,
  `sent_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`history_id`),
  KEY `idx_school_user` (`school_id`, `user_id`),
  KEY `idx_type` (`notification_type`),
  KEY `idx_status` (`status`),
  KEY `idx_sent_at` (`sent_at` DESC),
  FOREIGN KEY (`school_id`) REFERENCES `schools`(`school_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- INSERT DEFAULT TEMPLATES
-- ============================================================================

INSERT INTO `notification_templates` 
(`school_id`, `template_name`, `template_code`, `notification_type`, `subject`, `message_template`, `category`, `is_system`)
VALUES
-- Attendance Templates
(1, 'Student Absence Alert', 'ABSENCE_ALERT', 'all', 'Student Absent Today', 'Dear Parent, {STUDENT_NAME} was marked absent on {DATE}. Please contact the school if this is incorrect.', 'attendance', 1),
(1, 'Late Arrival Notice', 'LATE_ARRIVAL', 'all', 'Student Arrived Late', '{STUDENT_NAME} arrived late to school today at {TIME}. Please ensure timely arrival.', 'attendance', 1),
(1, 'Low Attendance Warning', 'LOW_ATTENDANCE', 'all', 'Low Attendance Alert', 'Dear Parent, {STUDENT_NAME} attendance is {PERCENTAGE}% which is below the required threshold. Please ensure regular attendance.', 'attendance', 1),

-- Fee Templates
(1, 'Fee Payment Reminder', 'FEE_REMINDER', 'all', 'School Fee Payment Reminder', 'Dear Parent, school fees for {STUDENT_NAME} are due. Outstanding amount: {AMOUNT}. Please make payment at your earliest convenience.', 'finance', 1),
(1, 'Fee Payment Confirmation', 'FEE_PAID', 'all', 'Fee Payment Received', 'Thank you for your payment of {AMOUNT} for {STUDENT_NAME}. Receipt number: {RECEIPT_NO}', 'finance', 1),
(1, 'Fee Overdue Notice', 'FEE_OVERDUE', 'all', 'Overdue Fee Payment', 'This is a reminder that school fees for {STUDENT_NAME} are overdue. Outstanding: {AMOUNT}. Please pay immediately.', 'finance', 1),

-- Exam Templates
(1, 'Exam Schedule Notice', 'EXAM_SCHEDULE', 'all', 'Examination Schedule', 'Dear Parent/Student, examinations for {TERM_NAME} will commence on {DATE}. Please prepare accordingly.', 'academic', 1),
(1, 'Exam Results Ready', 'RESULTS_READY', 'all', 'Examination Results Published', 'Results for {TERM_NAME} are now available. Login to view {STUDENT_NAME} results.', 'academic', 1),

-- General Templates
(1, 'New Message Received', 'NEW_MESSAGE', 'in_app', 'New Message', 'You have received a new message from {SENDER_NAME}: {MESSAGE_SUBJECT}', 'communication', 1),
(1, 'School Announcement', 'ANNOUNCEMENT', 'all', 'Important Announcement', '{ANNOUNCEMENT_TEXT}', 'general', 1),
(1, 'Parent Meeting Notice', 'PARENT_MEETING', 'all', 'Parent Meeting Scheduled', 'Dear Parent, a meeting is scheduled for {DATE} at {TIME}. Topic: {TOPIC}. Your attendance is requested.', 'general', 1)

ON DUPLICATE KEY UPDATE message_template=message_template;

-- ============================================================================
-- INSERT DEFAULT SETTINGS FOR SCHOOLS
-- ============================================================================

INSERT INTO `notification_settings` 
(`school_id`, `email_enabled`, `in_app_enabled`, `email_from_address`, `email_from_name`)
SELECT 
    school_id, 
    1, 
    1, 
    CONCAT('noreply@', LOWER(REPLACE(school_name, ' ', '')), '.com'),
    school_name
FROM schools
WHERE school_id NOT IN (SELECT school_id FROM notification_settings)
ON DUPLICATE KEY UPDATE setting_id=setting_id;

-- ============================================================================
-- STORED PROCEDURES
-- ============================================================================

DELIMITER //

-- Procedure to queue notification
DROP PROCEDURE IF EXISTS queue_notification//
CREATE PROCEDURE queue_notification(
    IN p_school_id INT,
    IN p_type ENUM('sms', 'email', 'in_app'),
    IN p_user_id INT,
    IN p_subject VARCHAR(255),
    IN p_message TEXT,
    IN p_template_code VARCHAR(50),
    IN p_priority VARCHAR(20)
)
BEGIN
    DECLARE v_phone VARCHAR(20);
    DECLARE v_email VARCHAR(255);
    DECLARE v_enabled TINYINT(1) DEFAULT 0;
    
    -- Get user contact info
    SELECT phone, email INTO v_phone, v_email
    FROM users WHERE user_id = p_user_id;
    
    -- Check if notification type is enabled
    IF p_type = 'sms' THEN
        SELECT sms_enabled INTO v_enabled FROM notification_settings WHERE school_id = p_school_id;
    ELSEIF p_type = 'email' THEN
        SELECT email_enabled INTO v_enabled FROM notification_settings WHERE school_id = p_school_id;
    ELSE
        SET v_enabled = 1; -- In-app always enabled
    END IF;
    
    -- Queue if enabled
    IF v_enabled = 1 THEN
        INSERT INTO notification_queue 
        (school_id, notification_type, recipient_user_id, recipient_phone, recipient_email, subject, message, template_code, priority, status)
        VALUES 
        (p_school_id, p_type, p_user_id, v_phone, v_email, p_subject, p_message, p_template_code, p_priority, 'pending');
    END IF;
END//

-- Procedure to process queue
DROP PROCEDURE IF EXISTS process_notification_queue//
CREATE PROCEDURE process_notification_queue(
    IN p_limit INT
)
BEGIN
    -- This would be called by a cron job or background process
    -- Mark pending items as processing
    UPDATE notification_queue 
    SET status = 'processing' 
    WHERE status = 'pending' 
    AND (scheduled_at IS NULL OR scheduled_at <= NOW())
    LIMIT p_limit;
    
    -- Return items to process
    SELECT * FROM notification_queue 
    WHERE status = 'processing' 
    LIMIT p_limit;
END//

DELIMITER ;

-- ============================================================================
-- VIEWS
-- ============================================================================

-- Pending notifications count by school
CREATE OR REPLACE VIEW `pending_notifications_summary` AS
SELECT 
    school_id,
    notification_type,
    COUNT(*) as pending_count,
    SUM(CASE WHEN priority = 'urgent' THEN 1 ELSE 0 END) as urgent_count
FROM notification_queue
WHERE status = 'pending'
GROUP BY school_id, notification_type;

-- Notification stats
CREATE OR REPLACE VIEW `notification_stats` AS
SELECT 
    school_id,
    notification_type,
    COUNT(*) as total_sent,
    COUNT(CASE WHEN status = 'sent' THEN 1 END) as successful,
    COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed,
    SUM(COALESCE(cost, 0)) as total_cost,
    DATE(sent_at) as sent_date
FROM notification_history
GROUP BY school_id, notification_type, DATE(sent_at);

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT 'Notification system tables created successfully!' as status;
SELECT 'Tables: notification_templates, notification_settings, notification_queue, notification_history' as info;
SELECT 'Stored Procedures: queue_notification, process_notification_queue' as procedures;
SELECT 'Views: pending_notifications_summary, notification_stats' as views;
