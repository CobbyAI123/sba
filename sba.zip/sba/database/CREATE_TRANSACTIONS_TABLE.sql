-- ============================================================================
-- CREATE transactions TABLE
-- The parent dashboard expects a transactions table for payment tracking
-- Date: November 17, 2025
-- ============================================================================

CREATE TABLE IF NOT EXISTS `transactions` (
  `transaction_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `term_id` INT(11) NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_date` DATE NOT NULL,
  `payment_method` ENUM('cash','card','bank_transfer','cheque','online','paystack') DEFAULT 'cash',
  `transaction_type` VARCHAR(50) DEFAULT 'fee_payment',
  `reference` VARCHAR(100) NULL,
  `status` ENUM('pending','completed','failed','refunded','cancelled') DEFAULT 'completed',
  `description` TEXT NULL,
  `collected_by` INT(11) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`transaction_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_term` (`term_id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`transaction_type`),
  KEY `idx_date` (`payment_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Copy existing payments data to transactions table
INSERT INTO transactions 
(school_id, student_id, amount, payment_date, payment_method, transaction_type, reference, status, collected_by, created_at)
SELECT 
  school_id,
  student_id,
  amount,
  payment_date,
  payment_method,
  COALESCE(payment_type, 'fee_payment') as transaction_type,
  reference,
  status,
  collected_by,
  created_at
FROM payments
WHERE NOT EXISTS (
  SELECT 1 FROM transactions t 
  WHERE t.student_id = payments.student_id 
  AND t.payment_date = payments.payment_date 
  AND t.amount = payments.amount
);

-- Verification
SELECT '✅ transactions table created' AS status;

SELECT 
  'transactions' as table_name,
  COUNT(*) as record_count 
FROM transactions;

SELECT 'Transaction types:' as info, transaction_type, COUNT(*) as count
FROM transactions
GROUP BY transaction_type;

-- Success message
SELECT '
╔═══════════════════════════════════════════════════════════════╗
║       ✅ TRANSACTIONS TABLE CREATED SUCCESSFULLY!             ║
╠═══════════════════════════════════════════════════════════════╣
║ • transactions table created                                  ║
║ • Data migrated from payments table                           ║
║ • Parent dashboard will now work                              ║
╠═══════════════════════════════════════════════════════════════╣
║ NEXT STEPS:                                                   ║
║ • Test parent dashboard                                       ║
║ • Verify fee statistics display                               ║
║ • Check payment history                                       ║
╚═══════════════════════════════════════════════════════════════╝
' AS STATUS;
