-- URGENT FIX: Remove foreign key constraint from terms table
-- Run this in phpMyAdmin to fix the "Cannot add or update a child row" error

-- Drop the foreign key constraint
ALTER TABLE `terms` DROP FOREIGN KEY `terms_ibfk_1`;

-- Make year_id nullable (optional instead of required)
ALTER TABLE `terms` MODIFY COLUMN `year_id` INT NULL;

-- Make term_number nullable (optional instead of required)  
ALTER TABLE `terms` MODIFY COLUMN `term_number` INT NULL;

-- Success message
SELECT 'Foreign key removed successfully! You can now add terms.' AS Result;
