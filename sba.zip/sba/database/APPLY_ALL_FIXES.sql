-- ========================================
-- APPLY ALL FIXES - Run this file once
-- ========================================
-- This file applies all necessary fixes to the assessment system:
-- 1. Updates grading formula (CA=60, Midterm=40, Exam=100)
-- 2. Adds position column
-- 3. Recreates triggers with new formula
-- 4. Recreates stored procedure
-- ========================================

-- Step 1: Add position column if it doesn't exist
ALTER TABLE student_assessments 
ADD COLUMN IF NOT EXISTS position INT NULL AFTER remark;

-- Step 2: Update max scores (only update existing columns)
UPDATE student_assessments 
SET ca_max = 60, 
    midterm_max = 40, 
    exam_max = 100;

-- Step 3: Drop existing triggers
DROP TRIGGER IF EXISTS calculate_scores_before_insert;
DROP TRIGGER IF EXISTS calculate_scores_before_update;

-- Step 4: Create new triggers with updated formula
-- Formula: Total = ((CA + Midterm) * 0.5) + (Exam / 2)

DELIMITER $$

CREATE TRIGGER calculate_scores_before_insert
BEFORE INSERT ON student_assessments
FOR EACH ROW
BEGIN
    -- Set max scores
    SET NEW.ca_max = 60;
    SET NEW.midterm_max = 40;
    SET NEW.exam_max = 100;
    
    -- Calculate total score using new formula
    -- Total = ((CA + Midterm) * 0.5) + (Exam / 2)
    SET NEW.total_score = (
        (COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5
    ) + (COALESCE(NEW.exam_score, 0) / 2);
    
    -- Round to 2 decimal places
    SET NEW.total_score = ROUND(NEW.total_score, 2);
    
    -- Calculate grade based on total (out of 100)
    SET NEW.grade = CASE
        WHEN NEW.total_score >= 90 THEN 'A+'
        WHEN NEW.total_score >= 80 THEN 'A'
        WHEN NEW.total_score >= 75 THEN 'B+'
        WHEN NEW.total_score >= 70 THEN 'B'
        WHEN NEW.total_score >= 65 THEN 'C+'
        WHEN NEW.total_score >= 60 THEN 'C'
        WHEN NEW.total_score >= 50 THEN 'D'
        ELSE 'F'
    END;
    
    -- Calculate remark based on total
    SET NEW.remark = CASE
        WHEN NEW.total_score >= 80 THEN 'Excellent'
        WHEN NEW.total_score >= 70 THEN 'Very Good'
        WHEN NEW.total_score >= 60 THEN 'Good'
        WHEN NEW.total_score >= 50 THEN 'Fair'
        ELSE 'Fail'
    END;
END$$

CREATE TRIGGER calculate_scores_before_update
BEFORE UPDATE ON student_assessments
FOR EACH ROW
BEGIN
    -- Set max scores
    SET NEW.ca_max = 60;
    SET NEW.midterm_max = 40;
    SET NEW.exam_max = 100;
    
    -- Calculate total score using new formula
    -- Total = ((CA + Midterm) * 0.5) + (Exam / 2)
    SET NEW.total_score = (
        (COALESCE(NEW.ca_score, 0) + COALESCE(NEW.midterm_score, 0)) * 0.5
    ) + (COALESCE(NEW.exam_score, 0) / 2);
    
    -- Round to 2 decimal places
    SET NEW.total_score = ROUND(NEW.total_score, 2);
    
    -- Calculate grade based on total (out of 100)
    SET NEW.grade = CASE
        WHEN NEW.total_score >= 90 THEN 'A+'
        WHEN NEW.total_score >= 80 THEN 'A'
        WHEN NEW.total_score >= 75 THEN 'B+'
        WHEN NEW.total_score >= 70 THEN 'B'
        WHEN NEW.total_score >= 65 THEN 'C+'
        WHEN NEW.total_score >= 60 THEN 'C'
        WHEN NEW.total_score >= 50 THEN 'D'
        ELSE 'F'
    END;
    
    -- Calculate remark based on total
    SET NEW.remark = CASE
        WHEN NEW.total_score >= 80 THEN 'Excellent'
        WHEN NEW.total_score >= 70 THEN 'Very Good'
        WHEN NEW.total_score >= 60 THEN 'Good'
        WHEN NEW.total_score >= 50 THEN 'Fair'
        ELSE 'Fail'
    END;
END$$

DELIMITER ;

-- Step 5: Recreate stored procedure for position calculation
DROP PROCEDURE IF EXISTS calculate_class_positions;

DELIMITER $$

CREATE PROCEDURE calculate_class_positions(
    IN p_school_id INT,
    IN p_term_id INT,
    IN p_class_id INT
)
BEGIN
    -- Calculate positions for each subject in the class
    UPDATE student_assessments sa1
    SET position = (
        SELECT COUNT(*) + 1
        FROM student_assessments sa2
        WHERE sa2.school_id = sa1.school_id
        AND sa2.term_id = sa1.term_id
        AND sa2.class_id = sa1.class_id
        AND sa2.subject_id = sa1.subject_id
        AND sa2.total_score > sa1.total_score
    )
    WHERE sa1.school_id = p_school_id
    AND sa1.term_id = p_term_id
    AND (p_class_id IS NULL OR sa1.class_id = p_class_id)
    AND sa1.total_score IS NOT NULL;
    
    SELECT CONCAT('Positions calculated for class_id: ', COALESCE(p_class_id, 'ALL')) as Result;
END$$

DELIMITER ;

-- Step 6: Recalculate existing scores with new formula
UPDATE student_assessments
SET total_score = ROUND(
    ((COALESCE(ca_score, 0) + COALESCE(midterm_score, 0)) * 0.5) + (COALESCE(exam_score, 0) / 2),
    2
);

-- Step 7: Recalculate grades
UPDATE student_assessments
SET grade = CASE
    WHEN total_score >= 90 THEN 'A+'
    WHEN total_score >= 80 THEN 'A'
    WHEN total_score >= 75 THEN 'B+'
    WHEN total_score >= 70 THEN 'B'
    WHEN total_score >= 65 THEN 'C+'
    WHEN total_score >= 60 THEN 'C'
    WHEN total_score >= 50 THEN 'D'
    ELSE 'F'
END;

-- Step 8: Recalculate remarks
UPDATE student_assessments
SET remark = CASE
    WHEN total_score >= 80 THEN 'Excellent'
    WHEN total_score >= 70 THEN 'Very Good'
    WHEN total_score >= 60 THEN 'Good'
    WHEN total_score >= 50 THEN 'Fair'
    ELSE 'Fail'
END;

-- Success messages
SELECT '========================================' as '';
SELECT 'ALL FIXES APPLIED SUCCESSFULLY!' as Result;
SELECT '========================================' as '';
SELECT 'New Grading Formula:' as '';
SELECT 'Total = ((CA + Midterm) * 0.5) + (Exam / 2)' as Formula;
SELECT '========================================' as '';
SELECT 'Max Scores:' as '';
SELECT 'CA: 60 marks' as '';
SELECT 'Midterm: 40 marks' as '';
SELECT 'Exam: 100 marks' as '';
SELECT 'Total: 100 marks' as '';
SELECT '========================================' as '';
SELECT 'Features Added:' as '';
SELECT '1. Position column added' as '';
SELECT '2. Triggers updated with new formula' as '';
SELECT '3. Stored procedure recreated' as '';
SELECT '4. Existing scores recalculated' as '';
SELECT '========================================' as '';
