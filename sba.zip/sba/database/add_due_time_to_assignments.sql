-- ================================================================================
-- ADD MISSING COLUMNS TO ASSIGNMENTS TABLE
-- Date: November 17, 2025
-- Purpose: Add missing columns for assignment functionality
-- ================================================================================

-- Add due_time column to assignments table
ALTER TABLE `assignments` 
ADD COLUMN IF NOT EXISTS `due_time` TIME NULL DEFAULT '23:59:59'
COMMENT 'Time when assignment is due'
AFTER `due_date`;

-- Add submission_type column
ALTER TABLE `assignments` 
ADD COLUMN IF NOT EXISTS `submission_type` ENUM('file_upload', 'text', 'link', 'quiz') DEFAULT 'file_upload'
COMMENT 'Type of submission allowed'
AFTER `assignment_type`;

-- Add allow_late_submission column
ALTER TABLE `assignments` 
ADD COLUMN IF NOT EXISTS `allow_late_submission` TINYINT(1) DEFAULT 0
COMMENT 'Whether to accept late submissions'
AFTER `due_time`;

-- Add late_penalty column
ALTER TABLE `assignments` 
ADD COLUMN IF NOT EXISTS `late_penalty` DECIMAL(5,2) DEFAULT 0.00
COMMENT 'Penalty percentage for late submission'
AFTER `allow_late_submission`;

-- Add late_penalty_percentage as alias (for compatibility)
ALTER TABLE `assignments` 
ADD COLUMN IF NOT EXISTS `late_penalty_percentage` INT(3) DEFAULT 0
COMMENT 'Late penalty percentage (deprecated - use late_penalty)'
AFTER `late_penalty`;

-- Add status column if not exists
ALTER TABLE `assignments` 
ADD COLUMN IF NOT EXISTS `status` ENUM('active', 'closed', 'draft') DEFAULT 'active'
COMMENT 'Assignment status'
AFTER `total_marks`;

-- Add attachments column if not exists
ALTER TABLE `assignments` 
ADD COLUMN IF NOT EXISTS `attachments` TEXT NULL
COMMENT 'JSON array of attachment file paths'
AFTER `description`;

-- Add max_file_size column
ALTER TABLE `assignments` 
ADD COLUMN IF NOT EXISTS `max_file_size` INT(11) DEFAULT 5120
COMMENT 'Maximum file size in KB (default 5MB)'
AFTER `submission_type`;

-- Add allowed_extensions column
ALTER TABLE `assignments` 
ADD COLUMN IF NOT EXISTS `allowed_extensions` VARCHAR(255) DEFAULT 'pdf,doc,docx,txt,jpg,png'
COMMENT 'Allowed file extensions for submission'
AFTER `max_file_size`;

-- Success message
SELECT 'All missing columns added to assignments table successfully!' as Result;
