-- =====================================================
-- SYNC CANTEEN & BUS COLLECTIONS
-- Fix mismatches between daily_collections and teacher_collections
-- =====================================================

USE school_management_system;

-- =====================================================
-- STEP 1: DATA VALIDATION
-- =====================================================

SELECT '🔍 VALIDATING DATA INTEGRITY...' AS status;

-- Check for invalid school_ids in daily_collections
SELECT 
    'Invalid school_id in daily_collections' as issue,
    COUNT(*) as problem_records
FROM daily_collections dc
LEFT JOIN schools s ON dc.school_id = s.school_id
WHERE s.school_id IS NULL;

-- Check for invalid teacher_ids in daily_collections
SELECT 
    'Invalid teacher_id (marked_by) in daily_collections' as issue,
    COUNT(*) as problem_records
FROM daily_collections dc
LEFT JOIN users u ON dc.marked_by = u.user_id
WHERE u.user_id IS NULL;

-- Fix invalid school_ids if any (set to first available school)
UPDATE daily_collections dc
LEFT JOIN schools s ON dc.school_id = s.school_id
SET dc.school_id = (SELECT school_id FROM schools LIMIT 1)
WHERE s.school_id IS NULL
AND EXISTS (SELECT 1 FROM schools LIMIT 1);

SELECT '✅ Data validation complete' AS status;

-- =====================================================
-- STEP 2: IDENTIFY MISMATCHES
-- =====================================================

SELECT '🔍 IDENTIFYING MISMATCHES...' AS status;

-- Find dates with collection discrepancies
SELECT 
    dc.collection_date,
    dc.marked_by as teacher_id,
    u.first_name, u.last_name,
    'canteen' as type,
    SUM(dc.canteen_amount) as daily_recorded,
    COALESCE(tc.amount, 0) as accountant_verified,
    SUM(dc.canteen_amount) - COALESCE(tc.amount, 0) as difference
FROM daily_collections dc
INNER JOIN users u ON dc.marked_by = u.user_id
LEFT JOIN teacher_collections tc ON dc.marked_by = tc.teacher_id 
    AND dc.collection_date = tc.collection_date
    AND tc.collection_type = 'canteen'
WHERE dc.canteen_paid = 1
GROUP BY dc.collection_date, dc.marked_by, tc.amount
HAVING ABS(difference) > 0.01

UNION ALL

SELECT 
    dc.collection_date,
    dc.marked_by as teacher_id,
    u.first_name, u.last_name,
    'bus' as type,
    SUM(dc.bus_amount) as daily_recorded,
    COALESCE(tc.amount, 0) as accountant_verified,
    SUM(dc.bus_amount) - COALESCE(tc.amount, 0) as difference
FROM daily_collections dc
INNER JOIN users u ON dc.marked_by = u.user_id
LEFT JOIN teacher_collections tc ON dc.marked_by = tc.teacher_id 
    AND dc.collection_date = tc.collection_date
    AND tc.collection_type = 'bus'
WHERE dc.bus_paid = 1
GROUP BY dc.collection_date, dc.marked_by, tc.amount
HAVING ABS(difference) > 0.01
ORDER BY collection_date DESC, teacher_id, type;

-- =====================================================
-- STEP 2: CREATE BACKUP
-- =====================================================

SELECT '💾 CREATING BACKUP...' AS status;

-- Backup teacher_collections before sync
CREATE TABLE IF NOT EXISTS teacher_collections_backup_20251128 AS
SELECT * FROM teacher_collections;

SELECT 
    '✅ Backup created' as status,
    COUNT(*) as records_backed_up
FROM teacher_collections_backup_20251128;

-- =====================================================
-- STEP 3: SYNC CANTEEN COLLECTIONS
-- =====================================================

SELECT '🔄 SYNCING CANTEEN COLLECTIONS...' AS status;

-- Update existing teacher_collections records for canteen
UPDATE teacher_collections tc
INNER JOIN (
    SELECT 
        dc.marked_by as teacher_id,
        dc.collection_date,
        dc.school_id,
        SUM(dc.canteen_amount) as correct_amount,
        COUNT(DISTINCT dc.student_id) as student_count
    FROM daily_collections dc
    WHERE dc.canteen_paid = 1
    GROUP BY dc.marked_by, dc.collection_date, dc.school_id
) dc ON tc.teacher_id = dc.teacher_id 
    AND tc.collection_date = dc.collection_date
    AND tc.school_id = dc.school_id
SET 
    tc.amount = dc.correct_amount,
    tc.remarks = CONCAT(
        COALESCE(tc.remarks, ''), 
        ' [Auto-synced from daily collections: ', 
        dc.student_count, ' students]'
    )
WHERE tc.collection_type = 'canteen'
  AND ABS(tc.amount - dc.correct_amount) > 0.01;

-- Insert missing teacher_collections records for canteen
INSERT INTO teacher_collections 
(school_id, teacher_id, collection_type, amount, collection_date, 
 payment_method, remarks, recorded_by)
SELECT 
    dc.school_id,
    dc.marked_by as teacher_id,
    'canteen' as collection_type,
    SUM(dc.canteen_amount) as amount,
    dc.collection_date,
    'cash' as payment_method,
    CONCAT('Auto-created from daily collections (', 
           COUNT(DISTINCT dc.student_id), ' students)') as remarks,
    1 as recorded_by
FROM daily_collections dc
LEFT JOIN teacher_collections tc ON dc.marked_by = tc.teacher_id
    AND dc.collection_date = tc.collection_date
    AND tc.collection_type = 'canteen'
    AND dc.school_id = tc.school_id
INNER JOIN schools s ON dc.school_id = s.school_id -- Ensure school exists
INNER JOIN users u ON dc.marked_by = u.user_id -- Ensure teacher exists
WHERE dc.canteen_paid = 1
  AND tc.collection_id IS NULL
GROUP BY dc.school_id, dc.marked_by, dc.collection_date;

SELECT 
    '✅ Canteen sync complete' as status,
    ROW_COUNT() as records_created;

-- =====================================================
-- STEP 4: SYNC BUS COLLECTIONS
-- =====================================================

SELECT '🔄 SYNCING BUS COLLECTIONS...' AS status;

-- Update existing teacher_collections records for bus
UPDATE teacher_collections tc
INNER JOIN (
    SELECT 
        dc.marked_by as teacher_id,
        dc.collection_date,
        dc.school_id,
        SUM(dc.bus_amount) as correct_amount,
        COUNT(DISTINCT dc.student_id) as student_count
    FROM daily_collections dc
    WHERE dc.bus_paid = 1
    GROUP BY dc.marked_by, dc.collection_date, dc.school_id
) dc ON tc.teacher_id = dc.teacher_id 
    AND tc.collection_date = dc.collection_date
    AND tc.school_id = dc.school_id
SET 
    tc.amount = dc.correct_amount,
    tc.remarks = CONCAT(
        COALESCE(tc.remarks, ''), 
        ' [Auto-synced from daily collections: ', 
        dc.student_count, ' students]'
    )
WHERE tc.collection_type = 'bus'
  AND ABS(tc.amount - dc.correct_amount) > 0.01;

-- Insert missing teacher_collections records for bus
INSERT INTO teacher_collections 
(school_id, teacher_id, collection_type, amount, collection_date, 
 payment_method, remarks, recorded_by)
SELECT 
    dc.school_id,
    dc.marked_by as teacher_id,
    'bus' as collection_type,
    SUM(dc.bus_amount) as amount,
    dc.collection_date,
    'cash' as payment_method,
    CONCAT('Auto-created from daily collections (', 
           COUNT(DISTINCT dc.student_id), ' students)') as remarks,
    1 as recorded_by
FROM daily_collections dc
LEFT JOIN teacher_collections tc ON dc.marked_by = tc.teacher_id
    AND dc.collection_date = tc.collection_date
    AND tc.collection_type = 'bus'
    AND dc.school_id = tc.school_id
INNER JOIN schools s ON dc.school_id = s.school_id -- Ensure school exists
INNER JOIN users u ON dc.marked_by = u.user_id -- Ensure teacher exists
WHERE dc.bus_paid = 1
  AND tc.collection_id IS NULL
GROUP BY dc.school_id, dc.marked_by, dc.collection_date;

SELECT 
    '✅ Bus sync complete' as status,
    ROW_COUNT() as records_created;

-- =====================================================
-- STEP 5: VERIFICATION
-- =====================================================

SELECT '✔️ VERIFYING SYNC RESULTS...' AS status;

-- Check if all matches now
SELECT 
    'CANTEEN' as collection_type,
    COUNT(*) as total_mismatches,
    SUM(ABS(difference)) as total_difference
FROM (
    SELECT 
        dc.collection_date,
        dc.marked_by,
        SUM(dc.canteen_amount) as daily_amount,
        COALESCE(tc.amount, 0) as verified_amount,
        SUM(dc.canteen_amount) - COALESCE(tc.amount, 0) as difference
    FROM daily_collections dc
    LEFT JOIN teacher_collections tc ON dc.marked_by = tc.teacher_id 
        AND dc.collection_date = tc.collection_date
        AND tc.collection_type = 'canteen'
    WHERE dc.canteen_paid = 1
    GROUP BY dc.collection_date, dc.marked_by, tc.amount
    HAVING ABS(difference) > 0.01
) mismatches;

SELECT 
    'BUS' as collection_type,
    COUNT(*) as total_mismatches,
    SUM(ABS(difference)) as total_difference
FROM (
    SELECT 
        dc.collection_date,
        dc.marked_by,
        SUM(dc.bus_amount) as daily_amount,
        COALESCE(tc.amount, 0) as verified_amount,
        SUM(dc.bus_amount) - COALESCE(tc.amount, 0) as difference
    FROM daily_collections dc
    LEFT JOIN teacher_collections tc ON dc.marked_by = tc.teacher_id 
        AND dc.collection_date = tc.collection_date
        AND tc.collection_type = 'bus'
    WHERE dc.bus_paid = 1
    GROUP BY dc.collection_date, dc.marked_by, tc.amount
    HAVING ABS(difference) > 0.01
) mismatches;

-- =====================================================
-- STEP 6: SUMMARY REPORT
-- =====================================================

SELECT '📊 SYNC SUMMARY' AS status;

-- Total canteen collections
SELECT 
    'Total Canteen Collections' as metric,
    COUNT(*) as transaction_count,
    SUM(amount) as total_amount
FROM teacher_collections
WHERE collection_type = 'canteen';

-- Total bus collections
SELECT 
    'Total Bus Collections' as metric,
    COUNT(*) as transaction_count,
    SUM(amount) as total_amount
FROM teacher_collections
WHERE collection_type = 'bus';

-- Daily collections that match
SELECT 
    'Verified vs Daily Collections' as status,
    'CANTEEN' as type,
    SUM(dc.canteen_amount) as daily_total,
    SUM(tc.amount) as verified_total,
    SUM(dc.canteen_amount) - SUM(tc.amount) as difference
FROM daily_collections dc
INNER JOIN teacher_collections tc ON dc.marked_by = tc.teacher_id
    AND dc.collection_date = tc.collection_date
    AND tc.collection_type = 'canteen'
WHERE dc.canteen_paid = 1

UNION ALL

SELECT 
    'Verified vs Daily Collections' as status,
    'BUS' as type,
    SUM(dc.bus_amount) as daily_total,
    SUM(tc.amount) as verified_total,
    SUM(dc.bus_amount) - SUM(tc.amount) as difference
FROM daily_collections dc
INNER JOIN teacher_collections tc ON dc.marked_by = tc.teacher_id
    AND dc.collection_date = tc.collection_date
    AND tc.collection_type = 'bus'
WHERE dc.bus_paid = 1;

-- =====================================================
-- FINAL MESSAGE
-- =====================================================

SELECT '
╔═══════════════════════════════════════════════════════════════╗
║       ✅ CANTEEN & BUS COLLECTIONS SYNC COMPLETE!             ║
╠═══════════════════════════════════════════════════════════════╣
║ Actions Performed:                                            ║
║ ✓ Identified mismatches between daily & verified collections ║
║ ✓ Created backup of teacher_collections table                ║
║ ✓ Synced canteen collections                                 ║
║ ✓ Synced bus collections                                     ║
║ ✓ Created missing verification records                       ║
║ ✓ Updated amounts to match daily collections                 ║
╠═══════════════════════════════════════════════════════════════╣
║ NEXT STEPS:                                                   ║
║ 1. Refresh proprietor dashboard                              ║
║ 2. Verify all figures match                                  ║
║ 3. Check auto-update is working (30 sec refresh)             ║
║ 4. Monitor for future discrepancies                          ║
╠═══════════════════════════════════════════════════════════════╣
║ BACKUP:                                                       ║
║ • teacher_collections_backup_20251128                        ║
║ • Can be restored if needed                                  ║
╚═══════════════════════════════════════════════════════════════╝
' AS SYNC_COMPLETE;
