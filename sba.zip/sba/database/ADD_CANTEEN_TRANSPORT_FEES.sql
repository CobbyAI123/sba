-- ============================================================================
-- ADD CANTEEN AND TRANSPORT FEE COLUMNS TO STUDENTS TABLE
-- ============================================================================
-- This script adds the necessary columns for tracking canteen and bus fees
-- Compatible with the Canteen & Bus Payment Tracking system
-- ============================================================================

-- Check current table structure
SELECT '=== CURRENT STUDENTS TABLE STRUCTURE ===' as info;
DESCRIBE students;

-- Add canteen_fee column if it doesn't exist
SELECT '=== ADDING CANTEEN_FEE COLUMN ===' as info;

SET @column_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'students' 
    AND COLUMN_NAME = 'canteen_fee'
);

SET @sql = IF(@column_exists = 0,
    'ALTER TABLE students ADD COLUMN canteen_fee DECIMAL(10,2) DEFAULT 0.00 COMMENT ''Monthly canteen fee amount'' AFTER class_id',
    'SELECT ''canteen_fee column already exists'' as status'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add transport_fee column if it doesn't exist
SELECT '=== ADDING TRANSPORT_FEE COLUMN ===' as info;

SET @column_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'students' 
    AND COLUMN_NAME = 'transport_fee'
);

SET @sql = IF(@column_exists = 0,
    'ALTER TABLE students ADD COLUMN transport_fee DECIMAL(10,2) DEFAULT 0.00 COMMENT ''Monthly transport/bus fee amount'' AFTER canteen_fee',
    'SELECT ''transport_fee column already exists'' as status'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add collected_by column to payments table if it doesn't exist
SELECT '=== ADDING COLLECTED_BY COLUMN TO PAYMENTS ===' as info;

SET @column_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'payments' 
    AND COLUMN_NAME = 'collected_by'
);

SET @sql = IF(@column_exists = 0,
    'ALTER TABLE payments ADD COLUMN collected_by INT NULL COMMENT ''Teacher/staff who collected the payment'' AFTER term_id',
    'SELECT ''collected_by column already exists'' as status'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add notes column to payments table if it doesn't exist
SELECT '=== ADDING NOTES COLUMN TO PAYMENTS ===' as info;

SET @column_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'payments' 
    AND COLUMN_NAME = 'notes'
);

SET @sql = IF(@column_exists = 0,
    'ALTER TABLE payments ADD COLUMN notes TEXT NULL COMMENT ''Additional payment notes'' AFTER payment_method',
    'SELECT ''notes column already exists'' as status'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Verify columns were added
SELECT '=== VERIFICATION ===' as info;

SELECT 
    COLUMN_NAME,
    COLUMN_TYPE,
    COLUMN_DEFAULT,
    COLUMN_COMMENT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'students'
    AND COLUMN_NAME IN ('canteen_fee', 'transport_fee');

SELECT 
    COLUMN_NAME,
    COLUMN_TYPE,
    COLUMN_DEFAULT,
    COLUMN_COMMENT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'payments'
    AND COLUMN_NAME IN ('collected_by', 'notes');

-- Show updated students table structure
SELECT '=== UPDATED STUDENTS TABLE STRUCTURE ===' as info;
DESCRIBE students;

-- ============================================================================
-- OPTIONAL: SET DEFAULT FEES FOR EXISTING STUDENTS
-- ============================================================================
-- Uncomment the lines below to set default fees for all active students

/*
SELECT '=== SETTING DEFAULT FEES ===' as info;

-- Set default canteen fee (GH₵ 300.00)
UPDATE students 
SET canteen_fee = 300.00 
WHERE status = 'active' AND canteen_fee = 0;

-- Set default transport fee (GH₵ 400.00)
UPDATE students 
SET transport_fee = 400.00 
WHERE status = 'active' AND transport_fee = 0;

SELECT 
    'Default fees set' as status,
    COUNT(*) as students_updated
FROM students 
WHERE status = 'active';
*/

-- ============================================================================
-- SAMPLE DATA CHECK
-- ============================================================================
SELECT '=== SAMPLE STUDENTS WITH FEES ===' as info;

SELECT 
    student_id,
    admission_number,
    canteen_fee,
    transport_fee,
    status
FROM students
LIMIT 10;

-- ============================================================================
-- COMPLETION MESSAGE
-- ============================================================================
SELECT '✅ COLUMNS ADDED SUCCESSFULLY!' as message;
SELECT '📊 Canteen & Bus Payment Tracking is now ready!' as status;
SELECT 'You can now set individual student fees via Admin → Students' as next_step;

-- ============================================================================
-- NOTES
-- ============================================================================
/*
USAGE INSTRUCTIONS:
1. Run this script in phpMyAdmin SQL tab
2. Check verification results
3. Optionally uncomment the default fees section to set bulk fees
4. Set individual student fees via Admin portal or SQL updates

SETTING INDIVIDUAL FEES:
Via Admin Portal:
- Go to Admin → Students → Edit Student
- Set canteen_fee and transport_fee amounts
- Save

Via SQL:
UPDATE students 
SET canteen_fee = 300.00, transport_fee = 400.00 
WHERE student_id = YOUR_STUDENT_ID;

BULK UPDATE EXAMPLES:
-- Set fees by class
UPDATE students s
JOIN classes c ON s.class_id = c.class_id
SET s.canteen_fee = 300.00, s.transport_fee = 400.00
WHERE c.class_name LIKE 'JHS%';

-- Set different fees by grade
UPDATE students s
JOIN classes c ON s.class_id = c.class_id
SET s.canteen_fee = 
    CASE 
        WHEN c.class_name LIKE 'JHS 1%' THEN 250.00
        WHEN c.class_name LIKE 'JHS 2%' THEN 300.00
        WHEN c.class_name LIKE 'JHS 3%' THEN 350.00
        ELSE 300.00
    END,
    s.transport_fee = 
    CASE 
        WHEN c.class_name LIKE 'JHS 1%' THEN 350.00
        WHEN c.class_name LIKE 'JHS 2%' THEN 400.00
        WHEN c.class_name LIKE 'JHS 3%' THEN 450.00
        ELSE 400.00
    END
WHERE s.status = 'active';

VERIFY FEES WERE SET:
SELECT 
    c.class_name,
    COUNT(*) as student_count,
    AVG(s.canteen_fee) as avg_canteen_fee,
    AVG(s.transport_fee) as avg_transport_fee
FROM students s
JOIN classes c ON s.class_id = c.class_id
WHERE s.status = 'active'
GROUP BY c.class_id, c.class_name
ORDER BY c.class_name;

TROUBLESHOOTING:
If you still get errors after running this script:
1. Check that the script completed successfully
2. Verify columns exist with DESCRIBE students;
3. Check for typos in column names
4. Ensure you're using the correct database
*/

-- ============================================================================
-- END OF SCRIPT
-- ============================================================================
