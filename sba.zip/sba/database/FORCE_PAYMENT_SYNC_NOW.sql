-- =====================================================
-- QUICK FIX - FORCE PAYMENT SYNC NOW
-- Run this to immediately sync the latest payment
-- =====================================================

USE school_management_system;

-- 1. Show the latest payment
-- =====================================================
SELECT 'Latest Payment Details:' as '';
SELECT 
    p.payment_id,
    p.student_id,
    p.amount,
    p.payment_method,
    p.payment_date,
    p.status,
    p.created_at,
    s.admission_number,
    CONCAT(u.first_name, ' ', u.last_name) as student_name
FROM payments p
LEFT JOIN students s ON p.student_id = s.student_id
LEFT JOIN users u ON s.user_id = u.user_id
ORDER BY p.created_at DESC
LIMIT 1;

-- 2. Create student_fees table if missing
-- =====================================================
CREATE TABLE IF NOT EXISTS student_fees (
    fee_id INT AUTO_INCREMENT PRIMARY KEY,
    school_id INT NOT NULL,
    student_id INT NOT NULL,
    total_fees DECIMAL(10,2) DEFAULT 0.00,
    total_paid DECIMAL(10,2) DEFAULT 0.00,
    balance DECIMAL(10,2) DEFAULT 0.00,
    last_payment_date DATE DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_student_fee (school_id, student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT '✅ student_fees table ready' as status;

-- 3. Force sync ALL existing payments
-- =====================================================
INSERT INTO student_fees (school_id, student_id, total_paid, last_payment_date, updated_at)
SELECT 
    p.school_id,
    p.student_id,
    SUM(CASE WHEN p.status IN ('paid', 'completed') THEN p.amount ELSE 0 END) as total_paid,
    MAX(CASE WHEN p.status IN ('paid', 'completed') THEN p.payment_date END) as last_payment_date,
    NOW() as updated_at
FROM payments p
INNER JOIN students s ON p.student_id = s.student_id
WHERE p.status IN ('paid', 'completed')
GROUP BY p.school_id, p.student_id
ON DUPLICATE KEY UPDATE
    total_paid = VALUES(total_paid),
    last_payment_date = VALUES(last_payment_date),
    updated_at = NOW();

SELECT '✅ All payments synced to student_fees' as status;

-- 4. Update balances
-- =====================================================
UPDATE student_fees sf
INNER JOIN students s ON sf.student_id = s.student_id
LEFT JOIN (
    SELECT 
        fs.school_id,
        fs.class_id,
        SUM(fs.amount) as total_fees
    FROM fee_structure fs
    GROUP BY fs.school_id, fs.class_id
) fs ON s.school_id = fs.school_id AND s.class_id = fs.class_id
SET 
    sf.total_fees = COALESCE(fs.total_fees, 0),
    sf.balance = COALESCE(fs.total_fees, 0) - sf.total_paid;

SELECT '✅ Student balances updated' as status;

-- 5. Verify the sync worked
-- =====================================================
SELECT 'Verification - Latest Payment Sync:' as '';

-- Get the latest payment details
SET @latest_student_id = (
    SELECT student_id 
    FROM payments 
    ORDER BY created_at DESC 
    LIMIT 1
);

-- Show student's payment summary
SELECT 
    sf.student_id,
    s.admission_number,
    CONCAT(u.first_name, ' ', u.last_name) as student_name,
    sf.total_fees,
    sf.total_paid,
    sf.balance,
    sf.last_payment_date,
    sf.updated_at
FROM student_fees sf
INNER JOIN students s ON sf.student_id = s.student_id
INNER JOIN users u ON s.user_id = u.user_id
WHERE sf.student_id = @latest_student_id;

-- Show all payments for this student
SELECT 'All Payments for This Student:' as '';
SELECT 
    payment_id,
    amount,
    payment_method,
    payment_date,
    status,
    created_at
FROM payments
WHERE student_id = @latest_student_id
ORDER BY created_at DESC;

-- 6. Show recent synced records
-- =====================================================
SELECT 'Recently Updated Student Fees (Last 10):' as '';
SELECT 
    sf.student_id,
    s.admission_number,
    CONCAT(u.first_name, ' ', u.last_name) as student_name,
    sf.total_paid,
    sf.balance,
    sf.last_payment_date,
    sf.updated_at
FROM student_fees sf
INNER JOIN students s ON sf.student_id = s.student_id
INNER JOIN users u ON s.user_id = u.user_id
ORDER BY sf.updated_at DESC
LIMIT 10;

-- 7. Final status
-- =====================================================
SELECT '=========================================' as '';
SELECT '✅ MANUAL SYNC COMPLETE!' as status;
SELECT 'Payment should now appear on Student Payments page' as info;
SELECT 'If still not showing:' as '';
SELECT '  1. Clear browser cache (Ctrl + Shift + Delete)' as step;
SELECT '  2. Hard refresh page (Ctrl + F5)' as step;
SELECT '  3. Check that payment status is "paid" or "completed"' as step;
SELECT '  4. Verify student exists in students table' as step;
