-- ============================================================
-- SCHOOL MANAGEMENT SYSTEM v3.0.0 - COMPLETE DATABASE SETUP
-- ============================================================
-- This script sets up the complete system with all 50+ tables
-- Execute the SQL files in this order via phpMyAdmin:
--
-- 1. schema.sql                              (27 core tables)
-- 2. api_tables.sql                          (API authentication & logging)
-- 3. error_logging_tables.sql                (Error tracking)
-- 4. search_tables.sql                       (Search functionality)
-- 5. bulk_operations_tables.sql              (Bulk processing)
-- 6. email_tables.sql                        (Email system)
-- 7. backup_dashboard_language_tables.sql    (Backups, Dashboard, Language)
--
-- Then run:
-- 8. FIX_EMAIL_TEMPLATES_SCHEMA.sql          (Add templates)
-- 9. VERIFY_ALL_TABLES.sql                   (Verification)
--
-- Total execution time: ~2 minutes
-- ============================================================

-- STEP 1: Verify MySQL Version
SELECT VERSION() as MySQL_Version, '✓ Ready to deploy' as Status;

-- STEP 2: Create database if not exists
CREATE DATABASE IF NOT EXISTS `school_management_system` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_general_ci;

USE `school_management_system`;

-- STEP 3: Display setup status
SELECT CONCAT('Database: ', @@database) as Current_Database;
SELECT CONCAT('Total tables after setup: 50+') as Expected_Tables;
SELECT CONCAT('Total SQL files to import: 9') as Total_Files;

-- STEP 4: Setup instructions
SELECT '
╔════════════════════════════════════════════════════════════╗
║  SCHOOL MANAGEMENT SYSTEM v3.0.0 - DATABASE SETUP          ║
╚════════════════════════════════════════════════════════════╝

IMPORTANT: Execute SQL files in phpMyAdmin in this order:

1. schema.sql
   └─ Core tables (students, classes, teachers, etc.)

2. api_tables.sql  
   └─ API tokens, logs

3. error_logging_tables.sql
   └─ Error and system logging

4. search_tables.sql
   └─ Search functionality

5. bulk_operations_tables.sql
   └─ Bulk operations and transcripts

6. email_tables.sql
   └─ Email queue, templates, settings

7. backup_dashboard_language_tables.sql
   └─ Backups, dashboards, multi-language

8. FIX_EMAIL_TEMPLATES_SCHEMA.sql
   └─ Add missing columns and insert templates

9. VERIFY_ALL_TABLES.sql
   └─ Verification (run to confirm all tables exist)

═══════════════════════════════════════════════════════════

After setup:
✓ 50+ database tables created
✓ 7 default email templates inserted
✓ All API infrastructure ready
✓ Multi-language support configured
✓ Backup system ready

═══════════════════════════════════════════════════════════
' as Setup_Instructions;

-- STEP 5: Default login credentials
SELECT '
╔════════════════════════════════════════════════════════════╗
║  DEFAULT CREDENTIALS                                       ║
╚════════════════════════════════════════════════════════════╝

URL: http://localhost/msms
Username: superadmin
Password: password

⚠️  CHANGE PASSWORD IMMEDIATELY AFTER FIRST LOGIN!

═══════════════════════════════════════════════════════════
' as Login_Info;

-- STEP 6: Next steps
SELECT '
╔════════════════════════════════════════════════════════════╗
║  NEXT STEPS                                                ║
╚════════════════════════════════════════════════════════════╝

1. Import all SQL files (in order listed above)
2. Run VERIFY_ALL_TABLES.sql to confirm setup
3. Login to admin dashboard
4. Configure:
   - School information
   - Academic terms
   - Payment gateways
   - Email settings
   - SMS providers (optional)
5. Add users, students, classes
6. Test all features
7. Set up cron jobs for:
   - Email queue processing
   - Automated backups
   - Cleanup tasks

═══════════════════════════════════════════════════════════
' as Next_Steps;

-- STEP 7: Documentation reference
SELECT '
╔════════════════════════════════════════════════════════════╗
║  DOCUMENTATION                                             ║
╚════════════════════════════════════════════════════════════╝

START_HERE.md                    - Overview and quick start
QUICK_DEPLOYMENT_GUIDE.md        - 30-minute setup guide
FINAL_SYSTEM_COMPLETION_REPORT.md - Complete feature list
api/README.md                     - API documentation
api/QUICK_START.md               - API code examples
SEARCH_SYSTEM_GUIDE.md           - Search functionality
BULK_OPERATIONS_GUIDE.md         - Bulk operations
EMAIL_NOTIFICATION_GUIDE.md      - Email system

═══════════════════════════════════════════════════════════
' as Documentation;

-- STEP 8: Final message
SELECT '
┌────────────────────────────────────────────────────────────┐
│  ✓ DATABASE SETUP SCRIPT CREATED                           │
│  Ready to deploy School Management System v3.0.0           │
│                                                             │
│  Start with: schema.sql                                    │
│  End with: VERIFY_ALL_TABLES.sql                           │
└────────────────────────────────────────────────────────────┘
' as Final_Status;
