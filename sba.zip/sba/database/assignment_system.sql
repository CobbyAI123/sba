-- ============================================================================
-- ASSIGNMENT & HOMEWORK MANAGEMENT SYSTEM
-- Complete assignment workflow for teachers, students, and parents
-- Date: November 11, 2025
-- ============================================================================

-- Assignments Table
CREATE TABLE IF NOT EXISTS `assignments` (
  `assignment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `school_id` INT(11) NOT NULL,
  `teacher_id` INT(11) NOT NULL,
  `class_id` INT(11) NOT NULL,
  `subject_id` INT(11) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NOT NULL,
  `assignment_type` ENUM('homework', 'project', 'classwork', 'research', 'quiz') DEFAULT 'homework',
  `total_marks` INT(3) DEFAULT 100,
  `due_date` DATE NOT NULL,
  `due_time` TIME NULL,
  `submission_type` ENUM('online', 'offline', 'both') DEFAULT 'online',
  `allow_late_submission` TINYINT(1) DEFAULT 0,
  `late_penalty_percentage` INT(3) DEFAULT 10,
  `attachment` VARCHAR(255) NULL,
  `status` ENUM('draft', 'published', 'closed') DEFAULT 'published',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`assignment_id`),
  KEY `idx_school` (`school_id`),
  KEY `idx_teacher` (`teacher_id`),
  KEY `idx_class` (`class_id`),
  KEY `idx_subject` (`subject_id`),
  KEY `idx_due_date` (`due_date`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Assignment Submissions Table
CREATE TABLE IF NOT EXISTS `assignment_submissions` (
  `submission_id` INT(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `submission_text` TEXT NULL,
  `attachment` VARCHAR(255) NULL,
  `submitted_at` TIMESTAMP NULL,
  `is_late` TINYINT(1) DEFAULT 0,
  `status` ENUM('not_submitted', 'submitted', 'graded', 'returned') DEFAULT 'not_submitted',
  `marks_obtained` INT(3) NULL,
  `feedback` TEXT NULL,
  `graded_by` INT(11) NULL,
  `graded_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`submission_id`),
  UNIQUE KEY `idx_assignment_student` (`assignment_id`, `student_id`),
  KEY `idx_student` (`student_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Assignment Attachments Table
CREATE TABLE IF NOT EXISTS `assignment_attachments` (
  `attachment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` INT(11) NULL,
  `submission_id` INT(11) NULL,
  `file_name` VARCHAR(255) NOT NULL,
  `file_path` VARCHAR(255) NOT NULL,
  `file_size` INT(11) NULL,
  `file_type` VARCHAR(50) NULL,
  `uploaded_by` INT(11) NOT NULL,
  `uploaded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attachment_id`),
  KEY `idx_assignment` (`assignment_id`),
  KEY `idx_submission` (`submission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Assignment Comments Table
CREATE TABLE IF NOT EXISTS `assignment_comments` (
  `comment_id` INT(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` INT(11) NULL,
  `submission_id` INT(11) NULL,
  `user_id` INT(11) NOT NULL,
  `comment` TEXT NOT NULL,
  `is_private` TINYINT(1) DEFAULT 0 COMMENT 'Private comments only visible to teacher and student',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`),
  KEY `idx_assignment` (`assignment_id`),
  KEY `idx_submission` (`submission_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Assignment Reminders Table
CREATE TABLE IF NOT EXISTS `assignment_reminders` (
  `reminder_id` INT(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` INT(11) NOT NULL,
  `student_id` INT(11) NOT NULL,
  `reminder_type` ENUM('due_soon', 'overdue', 'graded', 'returned') NOT NULL,
  `sent_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `notification_method` ENUM('in_app', 'sms', 'email', 'all') DEFAULT 'in_app',
  PRIMARY KEY (`reminder_id`),
  KEY `idx_assignment` (`assignment_id`),
  KEY `idx_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- VIEWS FOR QUICK ACCESS
-- ============================================================================

-- View for pending assignments per student
CREATE OR REPLACE VIEW `student_pending_assignments` AS
SELECT 
    s.student_id,
    a.assignment_id,
    a.title,
    a.assignment_type,
    a.due_date,
    a.due_time,
    a.total_marks,
    c.class_name,
    subj.subject_name,
    CONCAT(t.first_name, ' ', t.last_name) as teacher_name,
    COALESCE(sub.status, 'not_submitted') as submission_status,
    DATEDIFF(a.due_date, CURDATE()) as days_remaining,
    CASE 
        WHEN a.due_date < CURDATE() THEN 1
        ELSE 0
    END as is_overdue
FROM students s
INNER JOIN student_classes sc ON s.student_id = sc.student_id
INNER JOIN assignments a ON sc.class_id = a.class_id
INNER JOIN classes c ON a.class_id = c.class_id
INNER JOIN subjects subj ON a.subject_id = subj.subject_id
INNER JOIN users t ON a.teacher_id = t.user_id
LEFT JOIN assignment_submissions sub ON a.assignment_id = sub.assignment_id AND s.student_id = sub.student_id
WHERE a.status = 'published'
AND (sub.status IS NULL OR sub.status IN ('not_submitted', 'submitted'));

-- View for assignment statistics per class
CREATE OR REPLACE VIEW `assignment_class_stats` AS
SELECT 
    a.assignment_id,
    a.class_id,
    a.title,
    a.due_date,
    COUNT(DISTINCT s.student_id) as total_students,
    COUNT(DISTINCT sub.submission_id) as submitted_count,
    COUNT(DISTINCT CASE WHEN sub.status = 'graded' THEN sub.submission_id END) as graded_count,
    COUNT(DISTINCT CASE WHEN sub.is_late = 1 THEN sub.submission_id END) as late_submissions,
    AVG(CASE WHEN sub.marks_obtained IS NOT NULL THEN sub.marks_obtained END) as average_marks,
    (COUNT(DISTINCT sub.submission_id) * 100.0 / COUNT(DISTINCT s.student_id)) as submission_percentage
FROM assignments a
INNER JOIN classes c ON a.class_id = c.class_id
INNER JOIN student_classes sc ON c.class_id = sc.class_id
INNER JOIN students s ON sc.student_id = s.student_id
LEFT JOIN assignment_submissions sub ON a.assignment_id = sub.assignment_id AND s.student_id = sub.student_id
WHERE a.status = 'published'
GROUP BY a.assignment_id, a.class_id, a.title, a.due_date;

-- ============================================================================
-- STORED PROCEDURES
-- ============================================================================

DELIMITER //

-- Procedure to check and create overdue reminders
DROP PROCEDURE IF EXISTS check_overdue_assignments//
CREATE PROCEDURE check_overdue_assignments()
BEGIN
    -- Create reminders for overdue assignments that haven't been submitted
    INSERT INTO assignment_reminders (assignment_id, student_id, reminder_type, notification_method)
    SELECT 
        a.assignment_id,
        s.student_id,
        'overdue',
        'all'
    FROM assignments a
    INNER JOIN student_classes sc ON a.class_id = sc.class_id
    INNER JOIN students s ON sc.student_id = s.student_id
    LEFT JOIN assignment_submissions sub ON a.assignment_id = sub.assignment_id AND s.student_id = sub.student_id
    WHERE a.status = 'published'
    AND a.due_date < CURDATE()
    AND (sub.status IS NULL OR sub.status = 'not_submitted')
    AND NOT EXISTS (
        SELECT 1 FROM assignment_reminders ar 
        WHERE ar.assignment_id = a.assignment_id 
        AND ar.student_id = s.student_id 
        AND ar.reminder_type = 'overdue'
        AND DATE(ar.sent_at) = CURDATE()
    );
END//

-- Procedure to calculate student assignment performance
DROP PROCEDURE IF EXISTS calculate_student_assignment_performance//
CREATE PROCEDURE calculate_student_assignment_performance(
    IN p_student_id INT,
    IN p_term_id INT
)
BEGIN
    SELECT 
        COUNT(*) as total_assignments,
        COUNT(CASE WHEN sub.status IN ('submitted', 'graded', 'returned') THEN 1 END) as submitted_count,
        COUNT(CASE WHEN sub.status = 'graded' THEN 1 END) as graded_count,
        COUNT(CASE WHEN sub.is_late = 1 THEN 1 END) as late_count,
        AVG(CASE WHEN sub.marks_obtained IS NOT NULL THEN (sub.marks_obtained * 100.0 / a.total_marks) END) as average_percentage,
        (COUNT(CASE WHEN sub.status IN ('submitted', 'graded', 'returned') THEN 1 END) * 100.0 / COUNT(*)) as submission_rate
    FROM assignments a
    INNER JOIN student_classes sc ON a.class_id = sc.class_id
    LEFT JOIN assignment_submissions sub ON a.assignment_id = sub.assignment_id AND sc.student_id = sub.student_id
    WHERE sc.student_id = p_student_id
    AND a.status = 'published'
    AND a.created_at >= (SELECT start_date FROM terms WHERE term_id = p_term_id)
    AND a.created_at <= (SELECT end_date FROM terms WHERE term_id = p_term_id);
END//

DELIMITER ;

-- ============================================================================
-- INSERT SAMPLE ASSIGNMENT TYPES (FOR REFERENCE)
-- ============================================================================

-- This is just for documentation - assignment types are in ENUM

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

ALTER TABLE `assignments` ADD INDEX `idx_created_at` (`created_at` DESC);
ALTER TABLE `assignment_submissions` ADD INDEX `idx_submitted_at` (`submitted_at` DESC);
ALTER TABLE `assignment_submissions` ADD INDEX `idx_is_late` (`is_late`);

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT 'Assignment system tables created successfully!' as status;
SELECT 'Tables: assignments, assignment_submissions, assignment_attachments, assignment_comments, assignment_reminders' as tables_created;
SELECT 'Views: student_pending_assignments, assignment_class_stats' as views_created;
SELECT 'Procedures: check_overdue_assignments, calculate_student_assignment_performance' as procedures_created;
