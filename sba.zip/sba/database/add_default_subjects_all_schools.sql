-- Add complete default subjects to ALL schools in the system
-- This ensures all schools have the complete 19-subject list

-- Complete list of 19 default subjects
INSERT IGNORE INTO subjects (school_id, subject_name, subject_code, created_at)
SELECT 
    s.school_id,
    subject_name,
    subject_code,
    NOW()
FROM schools s
CROSS JOIN (
    SELECT 'English Language' as subject_name, 'ENG' as subject_code UNION ALL
    SELECT 'Mathematics', 'MATH' UNION ALL
    SELECT 'Integrated Science', 'SCI' UNION ALL
    SELECT 'Religious and Moral Education', 'RME' UNION ALL
    SELECT 'Creative Arts', 'CA' UNION ALL
    SELECT 'History', 'HIST' UNION ALL
    SELECT 'Physical Education', 'PE' UNION ALL
    SELECT 'Ghanaian Language', 'GHL' UNION ALL
    SELECT 'UC Mathematics', 'UCMATH' UNION ALL
    SELECT 'French', 'FRE' UNION ALL
    SELECT 'Social Studies', 'SS' UNION ALL
    SELECT 'Computing', 'COMP' UNION ALL
    SELECT 'Career Technology', 'CT' UNION ALL
    SELECT 'Literacy', 'LIT' UNION ALL
    SELECT 'Numeracy', 'NUM' UNION ALL
    SELECT 'Coloring', 'COL' UNION ALL
    SELECT 'Phonics', 'PHO' UNION ALL
    SELECT 'Writing', 'WRI' UNION ALL
    SELECT 'Our World Our People', 'OWOP'
) AS default_subjects
WHERE NOT EXISTS (
    SELECT 1 
    FROM subjects sub 
    WHERE sub.school_id = s.school_id 
    AND sub.subject_name = default_subjects.subject_name
);

-- Verification query
SELECT 
    sc.school_name,
    sc.school_code,
    COUNT(sub.subject_id) as 'Total Subjects'
FROM schools sc
LEFT JOIN subjects sub ON sc.school_id = sub.school_id
GROUP BY sc.school_id, sc.school_name, sc.school_code
ORDER BY sc.school_name;

-- Detailed view of subjects per school
SELECT 
    sc.school_name,
    sub.subject_name,
    sub.subject_code
FROM schools sc
INNER JOIN subjects sub ON sc.school_id = sub.school_id
ORDER BY sc.school_name, sub.subject_name;
