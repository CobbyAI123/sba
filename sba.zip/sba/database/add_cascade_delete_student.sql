-- ============================================================================
-- ADD CASCADE DELETE FOR STUDENT RECORDS
-- When a student is deleted, all related records are also deleted
-- ============================================================================

-- Drop existing foreign keys if they exist (to recreate with CASCADE)
-- This ensures clean deletion of student records

-- Payments table
ALTER TABLE `payments` 
DROP FOREIGN KEY IF EXISTS `fk_payments_student`;

ALTER TABLE `payments`
ADD CONSTRAINT `fk_payments_student` 
FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) 
ON DELETE CASCADE ON UPDATE CASCADE;

-- Student assessments table
ALTER TABLE `student_assessments` 
DROP FOREIGN KEY IF EXISTS `fk_assessments_student`;

ALTER TABLE `student_assessments`
ADD CONSTRAINT `fk_assessments_student` 
FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) 
ON DELETE CASCADE ON UPDATE CASCADE;

-- Attendance table
ALTER TABLE `attendance` 
DROP FOREIGN KEY IF EXISTS `fk_attendance_student`;

ALTER TABLE `attendance`
ADD CONSTRAINT `fk_attendance_student` 
FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) 
ON DELETE CASCADE ON UPDATE CASCADE;

-- Student_parents table
ALTER TABLE `student_parents` 
DROP FOREIGN KEY IF EXISTS `fk_student_parents_student`;

ALTER TABLE `student_parents`
ADD CONSTRAINT `fk_student_parents_student` 
FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) 
ON DELETE CASCADE ON UPDATE CASCADE;

-- Marks table (if exists)
SET @marks_table_exists = (
    SELECT COUNT(*) 
    FROM information_schema.tables 
    WHERE table_schema = DATABASE() 
    AND table_name = 'marks'
);

SET @sql_marks = IF(
    @marks_table_exists > 0,
    'ALTER TABLE `marks` DROP FOREIGN KEY IF EXISTS `fk_marks_student`',
    'SELECT "marks table does not exist" as info'
);
PREPARE stmt FROM @sql_marks;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql_marks2 = IF(
    @marks_table_exists > 0,
    'ALTER TABLE `marks` ADD CONSTRAINT `fk_marks_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE',
    'SELECT "marks table does not exist" as info'
);
PREPARE stmt FROM @sql_marks2;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Transactions table
ALTER TABLE `transactions` 
DROP FOREIGN KEY IF EXISTS `fk_transactions_student`;

ALTER TABLE `transactions`
ADD CONSTRAINT `fk_transactions_student` 
FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) 
ON DELETE CASCADE ON UPDATE CASCADE;

-- Assignment submissions (if exists)
SET @assignment_table_exists = (
    SELECT COUNT(*) 
    FROM information_schema.tables 
    WHERE table_schema = DATABASE() 
    AND table_name = 'assignment_submissions'
);

SET @sql_assignment = IF(
    @assignment_table_exists > 0,
    'ALTER TABLE `assignment_submissions` DROP FOREIGN KEY IF EXISTS `fk_assignment_submissions_student`',
    'SELECT "assignment_submissions table does not exist" as info'
);
PREPARE stmt FROM @sql_assignment;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql_assignment2 = IF(
    @assignment_table_exists > 0,
    'ALTER TABLE `assignment_submissions` ADD CONSTRAINT `fk_assignment_submissions_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE',
    'SELECT "assignment_submissions table does not exist" as info'
);
PREPARE stmt FROM @sql_assignment2;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Show all foreign keys on students table
SELECT 
    TABLE_NAME,
    CONSTRAINT_NAME,
    REFERENCED_TABLE_NAME,
    DELETE_RULE,
    UPDATE_RULE
FROM information_schema.REFERENTIAL_CONSTRAINTS
WHERE CONSTRAINT_SCHEMA = DATABASE()
AND REFERENCED_TABLE_NAME = 'students';

SELECT 'CASCADE DELETE constraints added successfully!' as status;

-- ============================================================================
-- WHAT THIS DOES
-- ============================================================================
-- 
-- When an admin deletes a student, the following will be AUTOMATICALLY deleted:
-- 
-- 1. All payment records (payments table)
-- 2. All assessment/results records (student_assessments table)
-- 3. All attendance records (attendance table)
-- 4. All parent-student links (student_parents table)
-- 5. All marks/grades (marks table)
-- 6. All transactions (transactions table)
-- 7. All assignment submissions (assignment_submissions table)
-- 
-- This ensures NO orphaned records remain in the database
-- 
-- ============================================================================
-- IMPORTANT NOTES
-- ============================================================================
-- 
-- - This is PERMANENT deletion - data cannot be recovered
-- - Consider adding a student "archive" or "soft delete" feature instead
-- - Always backup database before running this script
-- - Test on a development database first
-- 
-- ============================================================================
