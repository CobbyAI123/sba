-- Add Proprietor Role to School Management System
-- Date: November 3, 2025

-- IMPORTANT: Make sure you select your database first!
-- In phpMyAdmin, click on your database name (e.g., 'school_management_system') in the left sidebar
-- OR uncomment and update the line below with your database name:
-- USE school_management_system;

-- Step 1: Update users table to allow proprietor role
ALTER TABLE users 
MODIFY COLUMN role ENUM('admin', 'teacher', 'student', 'parent', 'accountant', 'librarian', 'bookstore', 'proprietor') NOT NULL;

-- Step 2: Create proprietors table for additional proprietor-specific data
CREATE TABLE IF NOT EXISTS proprietors (
    proprietor_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    school_id INT NOT NULL,
    designation VARCHAR(100) DEFAULT 'Proprietor',
    joining_date DATE,
    phone VARCHAR(20),
    address TEXT,
    emergency_contact VARCHAR(20),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_school (user_id, school_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Step 3: Create proprietor_permissions table for granular access control
CREATE TABLE IF NOT EXISTS proprietor_permissions (
    permission_id INT PRIMARY KEY AUTO_INCREMENT,
    proprietor_id INT NOT NULL,
    -- Dashboard & Overview
    view_dashboard BOOLEAN DEFAULT TRUE,
    view_statistics BOOLEAN DEFAULT TRUE,
    view_analytics BOOLEAN DEFAULT TRUE,
    
    -- Student Management (View Only)
    view_students BOOLEAN DEFAULT TRUE,
    view_student_details BOOLEAN DEFAULT TRUE,
    
    -- Staff Management (View Only)
    view_teachers BOOLEAN DEFAULT TRUE,
    view_staff BOOLEAN DEFAULT TRUE,
    
    -- Financial Management
    view_fees BOOLEAN DEFAULT TRUE,
    view_payments BOOLEAN DEFAULT TRUE,
    view_expenses BOOLEAN DEFAULT TRUE,
    view_financial_reports BOOLEAN DEFAULT TRUE,
    
    -- Communication
    send_messages BOOLEAN DEFAULT TRUE,
    send_notifications BOOLEAN DEFAULT TRUE,
    view_messages BOOLEAN DEFAULT TRUE,
    
    -- Reports (View Only)
    view_reports BOOLEAN DEFAULT TRUE,
    download_reports BOOLEAN DEFAULT TRUE,
    
    -- Profile Management
    update_own_profile BOOLEAN DEFAULT TRUE,
    change_own_password BOOLEAN DEFAULT TRUE,
    
    -- Restricted Permissions (FALSE by default)
    add_users BOOLEAN DEFAULT FALSE,
    edit_users BOOLEAN DEFAULT FALSE,
    delete_users BOOLEAN DEFAULT FALSE,
    assign_classes BOOLEAN DEFAULT FALSE,
    assign_teachers BOOLEAN DEFAULT FALSE,
    manage_timetable BOOLEAN DEFAULT FALSE,
    manage_academic_terms BOOLEAN DEFAULT FALSE,
    access_assessment_portal BOOLEAN DEFAULT FALSE,
    generate_results BOOLEAN DEFAULT FALSE,
    mark_attendance BOOLEAN DEFAULT FALSE,
    school_settings BOOLEAN DEFAULT FALSE,
    system_settings BOOLEAN DEFAULT FALSE,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (proprietor_id) REFERENCES proprietors(proprietor_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Step 4: Insert sample proprietor permissions template
-- This will be used when creating new proprietors
INSERT INTO proprietor_permissions (
    proprietor_id,
    view_dashboard, view_statistics, view_analytics,
    view_students, view_student_details,
    view_teachers, view_staff,
    view_fees, view_payments, view_expenses, view_financial_reports,
    send_messages, send_notifications, view_messages,
    view_reports, download_reports,
    update_own_profile, change_own_password,
    add_users, edit_users, delete_users,
    assign_classes, assign_teachers, manage_timetable, manage_academic_terms,
    access_assessment_portal, generate_results, mark_attendance,
    school_settings, system_settings
) VALUES (
    0, -- Template (proprietor_id = 0 means template)
    TRUE, TRUE, TRUE,  -- Dashboard
    TRUE, TRUE,        -- Students
    TRUE, TRUE,        -- Staff
    TRUE, TRUE, TRUE, TRUE,  -- Financial
    TRUE, TRUE, TRUE,  -- Communication
    TRUE, TRUE,        -- Reports
    TRUE, TRUE,        -- Profile
    FALSE, FALSE, FALSE,  -- User Management
    FALSE, FALSE, FALSE, FALSE,  -- Academic Management
    FALSE, FALSE, FALSE,  -- Assessment & Attendance
    FALSE, FALSE       -- Settings
) ON DUPLICATE KEY UPDATE proprietor_id = 0;

-- Step 5: Create activity log for proprietor actions
CREATE TABLE IF NOT EXISTS proprietor_activity_log (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    proprietor_id INT NOT NULL,
    action VARCHAR(255) NOT NULL,
    description TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (proprietor_id) REFERENCES proprietors(proprietor_id) ON DELETE CASCADE,
    INDEX idx_proprietor (proprietor_id),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Verification queries
SELECT 'Proprietor role added successfully!' as Status;
SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'users' AND COLUMN_NAME = 'role';
