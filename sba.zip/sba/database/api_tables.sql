-- API Tables for School Management System

-- API Tokens Table
CREATE TABLE IF NOT EXISTS `api_tokens` (
  `token_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `token` VARCHAR(255) NOT NULL UNIQUE,
  `expires_at` DATETIME NOT NULL,
  `is_revoked` BOOLEAN DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  INDEX `idx_token` (`token`),
  INDEX `idx_user_id` (`user_id`),
  INDEX `idx_expires_at` (`expires_at`)
);

-- API Keys Table (for API key authentication)
CREATE TABLE IF NOT EXISTS `api_keys` (
  `key_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT NOT NULL,
  `key_name` VARCHAR(100) NOT NULL,
  `key_value` VARCHAR(255) NOT NULL UNIQUE,
  `permissions` JSON,
  `rate_limit` INT DEFAULT 100,
  `is_active` BOOLEAN DEFAULT 1,
  `last_used_at` DATETIME,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `expires_at` DATETIME,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE CASCADE,
  INDEX `idx_key_value` (`key_value`),
  INDEX `idx_user_id` (`user_id`)
);

-- API Request Logs
CREATE TABLE IF NOT EXISTS `api_logs` (
  `log_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT,
  `endpoint` VARCHAR(255),
  `method` VARCHAR(10),
  `status_code` INT,
  `ip_address` VARCHAR(45),
  `request_body` JSON,
  `response_body` JSON,
  `execution_time_ms` INT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`) ON DELETE SET NULL,
  INDEX `idx_user_id` (`user_id`),
  INDEX `idx_endpoint` (`endpoint`),
  INDEX `idx_created_at` (`created_at`)
);

-- API Rate Limit
CREATE TABLE IF NOT EXISTS `api_rate_limits` (
  `limit_id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT,
  `ip_address` VARCHAR(45),
  `requests_count` INT DEFAULT 0,
  `reset_at` DATETIME,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_user_ip` (`user_id`, `ip_address`),
  INDEX `idx_reset_at` (`reset_at`)
);
