-- Fix for fee_structure foreign key constraint
-- This script fixes the broken foreign key constraint that references terms_backup instead of terms

USE `sba`;

-- Drop the incorrect foreign key constraint
ALTER TABLE `fee_structure` DROP FOREIGN KEY `fee_structure_ibfk_3`;

-- Add the correct foreign key constraint
ALTER TABLE `fee_structure` ADD CONSTRAINT `fee_structure_ibfk_3` 
FOREIGN KEY (`term_id`) REFERENCES `terms`(`term_id`) ON DELETE CASCADE;

-- Verify the fix
SELECT CONSTRAINT_NAME, TABLE_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME 
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
WHERE TABLE_NAME = 'fee_structure' AND COLUMN_NAME = 'term_id';
