-- ================================================================================
-- ADD MISSING COLUMNS TO MESSAGES TABLE
-- Date: November 17, 2025
-- Purpose: Add missing columns for messaging functionality
-- ================================================================================

-- Add message_type column
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `message_type` ENUM('inbox', 'sent', 'draft') DEFAULT 'inbox'
COMMENT 'Type of message (inbox/sent/draft)'
AFTER `subject`;

-- Add priority column
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `priority` ENUM('low', 'normal', 'high', 'urgent') DEFAULT 'normal'
COMMENT 'Message priority level'
AFTER `message_type`;

-- Add attachment column
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `attachment` VARCHAR(255) NULL
COMMENT 'Attachment file path'
AFTER `message`;

-- Add read_at timestamp
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `read_at` TIMESTAMP NULL DEFAULT NULL
COMMENT 'When message was read'
AFTER `is_read`;

-- Add deleted_by_sender column
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `deleted_by_sender` TINYINT(1) DEFAULT 0
COMMENT 'Whether sender deleted the message'
AFTER `read_at`;

-- Add deleted_by_receiver column
ALTER TABLE `messages` 
ADD COLUMN IF NOT EXISTS `deleted_by_receiver` TINYINT(1) DEFAULT 0
COMMENT 'Whether receiver deleted the message'
AFTER `deleted_by_sender`;

-- Success message
SELECT 'All missing columns added to messages table successfully!' as Result;
