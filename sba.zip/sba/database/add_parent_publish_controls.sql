-- ============================================================================
-- ADD PARENT PUBLISH CONTROLS FOR RESULTS
-- This allows admin to control which results parents can see
-- ============================================================================

-- Add published_to_parents column to student_assessments table
ALTER TABLE `student_assessments` 
ADD COLUMN IF NOT EXISTS `published_to_parents` TINYINT(1) DEFAULT 0 
COMMENT 'Whether results are visible to parents (0=No, 1=Yes)';

-- Add index for faster queries
CREATE INDEX IF NOT EXISTS idx_published_to_parents 
ON student_assessments(published_to_parents);

-- Add published_at column to track when results were published
ALTER TABLE `student_assessments` 
ADD COLUMN IF NOT EXISTS `published_at` TIMESTAMP NULL DEFAULT NULL
COMMENT 'When results were published to parents';

-- Add published_by column to track who published the results
ALTER TABLE `student_assessments` 
ADD COLUMN IF NOT EXISTS `published_by` INT(11) NULL DEFAULT NULL
COMMENT 'User ID of admin who published results';

-- ============================================================================
-- VERIFICATION QUERY
-- ============================================================================

-- Check if columns were added successfully
SHOW COLUMNS FROM student_assessments LIKE 'published_to_parents';
SHOW COLUMNS FROM student_assessments LIKE 'published_at';
SHOW COLUMNS FROM student_assessments LIKE 'published_by';

SELECT 'Parent publish controls added successfully!' as status;

-- ============================================================================
-- INSTRUCTIONS
-- ============================================================================
-- 
-- HOW TO RUN THIS SCRIPT:
-- 
-- Method 1: phpMyAdmin
-- ---------------------
-- 1. Open: http://localhost/phpmyadmin
-- 2. Select: school_management_system database
-- 3. Click: SQL tab
-- 4. Copy & Paste: This entire script
-- 5. Click: Go button
-- 6. Verify: Success message appears
-- 
-- Method 2: MySQL Command Line
-- -----------------------------
-- 1. Open: Command Prompt
-- 2. Login: mysql -u root -p
-- 3. Use database: USE school_management_system;
-- 4. Source file: SOURCE C:/xampp/htdocs/msms/database/add_parent_publish_controls.sql
-- 5. Verify: Columns added
-- 
-- ============================================================================
