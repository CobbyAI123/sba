-- Performance Optimization: Add Missing Indexes
-- This will significantly improve query performance

-- Users table indexes
ALTER TABLE users ADD INDEX idx_school_username (school_id, username);
ALTER TABLE users ADD INDEX idx_school_email (school_id, email);
ALTER TABLE users ADD INDEX idx_role_school (role, school_id);
ALTER TABLE users ADD INDEX idx_username (username);

-- Students table indexes
ALTER TABLE students ADD INDEX idx_school_user (school_id, user_id);
ALTER TABLE students ADD INDEX idx_class_school (class_id, school_id);
ALTER TABLE students ADD INDEX idx_admission_school (admission_number, school_id);

-- Classes table indexes
ALTER TABLE classes ADD INDEX idx_school_id (school_id);
ALTER TABLE classes ADD INDEX idx_section (section);

-- Subjects table indexes
ALTER TABLE subjects ADD INDEX idx_school_id (school_id);
ALTER TABLE subjects ADD INDEX idx_code (subject_code);

-- Attendance table indexes
ALTER TABLE attendance ADD INDEX idx_student_date (student_id, attendance_date);
ALTER TABLE attendance ADD INDEX idx_school_date (school_id, attendance_date);
ALTER TABLE attendance ADD INDEX idx_class_date (class_id, attendance_date);

-- Marks table indexes
ALTER TABLE marks ADD INDEX idx_exam_subject (exam_id, subject_id);
ALTER TABLE marks ADD INDEX idx_student_exam (student_id, exam_id);

-- Payments table indexes
ALTER TABLE payments ADD INDEX idx_student_school (student_id, school_id);
ALTER TABLE payments ADD INDEX idx_payment_date (payment_date);
ALTER TABLE payments ADD INDEX idx_status (status);

-- Exams table indexes
ALTER TABLE exams ADD INDEX idx_term_school (term_id, school_id);
ALTER TABLE exams ADD INDEX idx_class_school (class_id, school_id);

-- Terms table indexes
ALTER TABLE terms ADD INDEX idx_school_active (school_id, is_active);
ALTER TABLE terms ADD INDEX idx_session_year (session_year);

-- Fee structure indexes
ALTER TABLE fee_structure ADD INDEX idx_class_term (class_id, term_id);
ALTER TABLE fee_structure ADD INDEX idx_school_id (school_id);

-- Activity logs indexes  
ALTER TABLE activity_logs ADD INDEX idx_user_date (user_id, created_at);
ALTER TABLE activity_logs ADD INDEX idx_school_date (school_id, created_at);

-- Timetable indexes
ALTER TABLE timetable ADD INDEX idx_class_day (class_id, day_of_week);
ALTER TABLE timetable ADD INDEX idx_teacher_day (teacher_id, day_of_week);

-- News indexes
ALTER TABLE news ADD INDEX idx_school_date (school_id, created_at);
ALTER TABLE news ADD INDEX idx_status (status);

-- Notifications indexes
ALTER TABLE notifications ADD INDEX idx_user_read (user_id, is_read);
ALTER TABLE notifications ADD INDEX idx_school_user (school_id, user_id);

-- Transport routes indexes
ALTER TABLE transport_routes ADD INDEX idx_school_id (school_id);

-- Schools table indexes
ALTER TABLE schools ADD INDEX idx_code (school_code);
ALTER TABLE schools ADD INDEX idx_status (status);

-- Settings indexes
ALTER TABLE settings ADD INDEX idx_school_key (school_id, setting_key);

-- Bookstore indexes
ALTER TABLE bookstore_inventory ADD INDEX idx_school_id (school_id);
ALTER TABLE bookstore_inventory ADD INDEX idx_status (status);
ALTER TABLE bookstore_sales ADD INDEX idx_school_date (school_id, sale_date);

-- Library indexes
ALTER TABLE library_books ADD INDEX idx_school_id (school_id);
ALTER TABLE library_books ADD INDEX idx_category (category);
ALTER TABLE library_issues ADD INDEX idx_student_return (student_id, return_date);
ALTER TABLE library_issues ADD INDEX idx_issue_date (issue_date);

-- This completes the comprehensive indexing strategy for optimal performance
