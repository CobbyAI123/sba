-- Make date_of_birth and gender nullable (optional fields)
USE school_management_system;

-- Modify date_of_birth to allow NULL
ALTER TABLE students 
MODIFY COLUMN date_of_birth DATE NULL DEFAULT NULL;

-- Modify gender to allow NULL
ALTER TABLE students 
MODIFY COLUMN gender ENUM('male','female','Male','Female','other') NULL DEFAULT NULL;

-- Verify changes
DESCRIBE students;

SELECT 'date_of_birth and gender are now optional!' as Status;
