<?php
// accountant/verify-daily-collections.php - Verify Daily Collections from Teachers
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Verify Daily Collections';
$current_user = check_permission(['accountant', 'admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get filter parameters
$filter_date = isset($_GET['date']) ? sanitize_input($_GET['date']) : date('Y-m-d');
$filter_class = isset($_GET['class_id']) ? (int)$_GET['class_id'] : '';
$filter_teacher = isset($_GET['teacher_id']) ? (int)$_GET['teacher_id'] : '';

// Handle verification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'verify_collection') {
        $collection_id = (int)$_POST['collection_id'];
        $verified_amount = (float)$_POST['verified_amount'];
        $remarks = sanitize_input($_POST['remarks'] ?? '');
        
        try {
            $db->beginTransaction();
            
            // Update daily collection with verification
            $stmt = $db->prepare("
                UPDATE daily_collections 
                SET verified_amount = ?, verified_by = ?, verified_at = NOW(), remarks = ?
                WHERE collection_id = ? AND school_id = ?
            ");
            $stmt->execute([$verified_amount, $current_user['user_id'], $remarks, $collection_id, $school_id]);
            
            $db->commit();
            
            set_message('success', 'Collection verified successfully!');
            redirect(APP_URL . '/accountant/verify-daily-collections.php?date=' . $filter_date);
        } catch (PDOException $e) {
            $db->rollBack();
            set_message('error', 'Error verifying collection: ' . $e->getMessage());
        }
    }
}

// Get all classes
$stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get all teachers
$stmt = $db->prepare("SELECT DISTINCT u.user_id, u.first_name, u.last_name FROM users u 
                      INNER JOIN daily_collections dc ON u.user_id = dc.marked_by 
                      WHERE dc.school_id = ? ORDER BY u.first_name, u.last_name");
$stmt->execute([$school_id]);
$teachers = $stmt->fetchAll();

// Get daily collections for verification
$query = "
    SELECT 
        dc.collection_id,
        dc.collection_date,
        dc.canteen_paid,
        dc.bus_paid,
        dc.canteen_amount,
        dc.bus_amount,
        dc.total_amount,
        dc.verified_amount,
        dc.verified_by,
        dc.verified_at,
        dc.remarks,
        c.class_name,
        s.admission_number,
        CONCAT(u.first_name, ' ', u.last_name) as student_name,
        CONCAT(tu.first_name, ' ', tu.last_name) as teacher_name
    FROM daily_collections dc
    INNER JOIN classes c ON dc.class_id = c.class_id
    INNER JOIN students s ON dc.student_id = s.student_id
    INNER JOIN users u ON s.user_id = u.user_id
    INNER JOIN users tu ON dc.marked_by = tu.user_id
    WHERE dc.school_id = ? AND dc.collection_date = ?
";

$params = [$school_id, $filter_date];

if ($filter_class) {
    $query .= " AND dc.class_id = ?";
    $params[] = $filter_class;
}

if ($filter_teacher) {
    $query .= " AND dc.marked_by = ?";
    $params[] = $filter_teacher;
}

$query .= " ORDER BY c.class_name, u.first_name, u.last_name";

$stmt = $db->prepare($query);
$stmt->execute($params);
$collections = $stmt->fetchAll();

// Calculate summary
$summary = [
    'total_records' => 0,
    'verified_records' => 0,
    'pending_records' => 0,
    'total_canteen' => 0,
    'total_bus' => 0,
    'verified_canteen' => 0,
    'verified_bus' => 0,
    'pending_canteen' => 0,
    'pending_bus' => 0
];

$by_class = [];
$by_teacher = [];

foreach ($collections as $collection) {
    $summary['total_records']++;
    $summary['total_canteen'] += $collection['canteen_amount'];
    $summary['total_bus'] += $collection['bus_amount'];
    
    if ($collection['verified_by']) {
        $summary['verified_records']++;
        $summary['verified_canteen'] += $collection['canteen_amount'];
        $summary['verified_bus'] += $collection['bus_amount'];
    } else {
        $summary['pending_records']++;
        $summary['pending_canteen'] += $collection['canteen_amount'];
        $summary['pending_bus'] += $collection['bus_amount'];
    }
    
    // Group by class
    if (!isset($by_class[$collection['class_name']])) {
        $by_class[$collection['class_name']] = [
            'total' => 0,
            'canteen' => 0,
            'bus' => 0,
            'verified' => 0,
            'count' => 0
        ];
    }
    $by_class[$collection['class_name']]['total']++;
    $by_class[$collection['class_name']]['canteen'] += $collection['canteen_amount'];
    $by_class[$collection['class_name']]['bus'] += $collection['bus_amount'];
    $by_class[$collection['class_name']]['count']++;
    if ($collection['verified_by']) $by_class[$collection['class_name']]['verified']++;
    
    // Group by teacher
    if (!isset($by_teacher[$collection['teacher_name']])) {
        $by_teacher[$collection['teacher_name']] = [
            'total' => 0,
            'canteen' => 0,
            'bus' => 0,
            'verified' => 0,
            'count' => 0
        ];
    }
    $by_teacher[$collection['teacher_name']]['total']++;
    $by_teacher[$collection['teacher_name']]['canteen'] += $collection['canteen_amount'];
    $by_teacher[$collection['teacher_name']]['bus'] += $collection['bus_amount'];
    $by_teacher[$collection['teacher_name']]['count']++;
    if ($collection['verified_by']) $by_teacher[$collection['teacher_name']]['verified']++;
}

include BASE_PATH . '/includes/header.php';
?>

<style>
.summary-card {
    background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
    color: white;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.summary-card .number {
    font-size: 32px;
    font-weight: bold;
}

.summary-card .label {
    font-size: 14px;
    opacity: 0.9;
}

.filter-section {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-bottom: 20px;
}

.collection-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    background: var(--card-bg);
    border: 1px solid var(--border-color);
    border-radius: 8px;
    margin-bottom: 10px;
}

.collection-item.verified {
    border-left: 5px solid #10B981;
}

.collection-item.pending {
    border-left: 5px solid #FF9800;
}

.verification-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

.verification-badge.verified {
    background: #10B981;
    color: white;
}

.verification-badge.pending {
    background: #FF9800;
    color: white;
}

.amount-col {
    text-align: right;
    font-weight: 600;
}

.btn-verify {
    background: #2196F3;
    color: white;
    padding: 6px 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 12px;
    transition: all 0.3s;
}

.btn-verify:hover {
    background: #1976D2;
    transform: translateY(-2px);
}

.verification-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    z-index: 1000;
    align-items: center;
    justify-content: center;
}

.verification-modal.active {
    display: flex;
}

.modal-content {
    background: white;
    padding: 30px;
    border-radius: 10px;
    max-width: 500px;
    width: 90%;
}

.modal-content h3 {
    margin-top: 0;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    font-weight: 600;
    margin-bottom: 5px;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid var(--border-color);
    border-radius: 6px;
    font-family: inherit;
}

.form-group textarea {
    resize: vertical;
    min-height: 80px;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin-bottom: 25px;
}

.stat-box {
    background: var(--card-bg);
    padding: 15px;
    border-radius: 8px;
    border-top: 3px solid var(--primary-blue);
}

.stat-box h4 {
    margin: 0 0 10px 0;
    font-size: 14px;
    color: var(--text-secondary);
    text-transform: uppercase;
}

.stat-box .number {
    font-size: 28px;
    font-weight: bold;
    color: var(--primary-blue);
}

.stat-box.pending {
    border-top-color: #FF9800;
}

.stat-box.verified {
    border-top-color: #10B981;
}

.stat-box.pending .number {
    color: #FF9800;
}

.stat-box.verified .number {
    color: #10B981;
}

@media (max-width: 768px) {
    .filter-section {
        grid-template-columns: 1fr;
    }
    
    .collection-item {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .amount-col {
        text-align: left;
        margin-top: 10px;
    }
    
    .summary-card {
        flex-direction: column;
        text-align: center;
    }
}
</style>

<div class="content-wrapper">
    <h2><i class="fas fa-check-circle"></i> Verify Daily Collections</h2>
    <p style="color: var(--text-secondary);">Review and verify canteen & bus fee collections from teachers</p>
    
    <!-- Summary Statistics -->
    <div class="stats-grid">
        <div class="stat-box">
            <h4>Total Records</h4>
            <div class="number"><?php echo $summary['total_records']; ?></div>
        </div>
        <div class="stat-box verified">
            <h4>Verified</h4>
            <div class="number"><?php echo $summary['verified_records']; ?></div>
        </div>
        <div class="stat-box pending">
            <h4>Pending</h4>
            <div class="number"><?php echo $summary['pending_records']; ?></div>
        </div>
        <div class="stat-box">
            <h4>Total Amount</h4>
            <div class="number"><?php echo format_currency($summary['total_canteen'] + $summary['total_bus']); ?></div>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card" style="margin-bottom: 20px;">
        <div class="card-header">
            <h3>Filter Collections</h3>
        </div>
        <div style="padding: 20px;">
            <form method="GET" class="filter-section">
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" name="date" value="<?php echo $filter_date; ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label>Class</label>
                    <select name="class_id" class="form-control">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>" <?php echo $filter_class == $class['class_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Teacher</label>
                    <select name="teacher_id" class="form-control">
                        <option value="">All Teachers</option>
                        <?php foreach ($teachers as $teacher): ?>
                            <option value="<?php echo $teacher['user_id']; ?>" <?php echo $filter_teacher == $teacher['user_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="align-self: flex-end;">
                    <i class="fas fa-search"></i> Filter
                </button>
            </form>
        </div>
    </div>
    
    <!-- Collections List -->
    <div class="card">
        <div class="card-header">
            <h3>Collections on <?php echo date('F d, Y', strtotime($filter_date)); ?></h3>
        </div>
        <div style="padding: 20px;">
            <?php if (!empty($collections)): ?>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: var(--bg-secondary);">
                                <th style="padding: 12px; text-align: left; font-weight: 600;">Student</th>
                                <th style="padding: 12px; text-align: left; font-weight: 600;">Class</th>
                                <th style="padding: 12px; text-align: left; font-weight: 600;">Teacher</th>
                                <th style="padding: 12px; text-align: right; font-weight: 600;">Canteen</th>
                                <th style="padding: 12px; text-align: right; font-weight: 600;">Bus</th>
                                <th style="padding: 12px; text-align: right; font-weight: 600;">Total</th>
                                <th style="padding: 12px; text-align: center; font-weight: 600;">Status</th>
                                <th style="padding: 12px; text-align: center; font-weight: 600;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($collections as $collection): ?>
                                <tr style="border-bottom: 1px solid var(--border-color);">
                                    <td style="padding: 12px;"><?php echo htmlspecialchars($collection['student_name']); ?></td>
                                    <td style="padding: 12px;"><?php echo htmlspecialchars($collection['class_name']); ?></td>
                                    <td style="padding: 12px;"><?php echo htmlspecialchars($collection['teacher_name']); ?></td>
                                    <td style="padding: 12px; text-align: right; font-weight: 600;">
                                        <?php echo $collection['canteen_paid'] ? format_currency($collection['canteen_amount']) : '-'; ?>
                                    </td>
                                    <td style="padding: 12px; text-align: right; font-weight: 600;">
                                        <?php echo $collection['bus_paid'] ? format_currency($collection['bus_amount']) : '-'; ?>
                                    </td>
                                    <td style="padding: 12px; text-align: right; font-weight: 600; color: #10B981;">
                                        <?php echo format_currency($collection['total_amount']); ?>
                                    </td>
                                    <td style="padding: 12px; text-align: center;">
                                        <?php if ($collection['verified_by']): ?>
                                            <span class="verification-badge verified">
                                                <i class="fas fa-check"></i> Verified
                                            </span>
                                        <?php else: ?>
                                            <span class="verification-badge pending">
                                                <i class="fas fa-clock"></i> Pending
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding: 12px; text-align: center;">
                                        <?php if (!$collection['verified_by']): ?>
                                            <button type="button" class="btn-verify" onclick="showVerifyModal(<?php echo $collection['collection_id']; ?>, '<?php echo htmlspecialchars($collection['student_name']); ?>', <?php echo $collection['total_amount']; ?>)">
                                                <i class="fas fa-check"></i> Verify
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 40px;">
                    <i class="fas fa-inbox" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 15px; display: block;"></i>
                    <h3 style="color: var(--text-secondary);">No Collections Found</h3>
                    <p style="color: var(--text-secondary);">No daily collections to verify for <?php echo date('F d, Y', strtotime($filter_date)); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Summary by Class -->
    <?php if (!empty($by_class)): ?>
    <div class="card" style="margin-top: 25px;">
        <div class="card-header">
            <h3>Summary by Class</h3>
        </div>
        <div style="overflow-x: auto; padding: 20px;">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: var(--bg-secondary);">
                        <th style="padding: 12px; text-align: left; font-weight: 600;">Class</th>
                        <th style="padding: 12px; text-align: right; font-weight: 600;">Records</th>
                        <th style="padding: 12px; text-align: right; font-weight: 600;">Canteen</th>
                        <th style="padding: 12px; text-align: right; font-weight: 600;">Bus</th>
                        <th style="padding: 12px; text-align: right; font-weight: 600;">Total</th>
                        <th style="padding: 12px; text-align: center; font-weight: 600;">Verified %</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($by_class as $class_name => $data): ?>
                        <tr style="border-bottom: 1px solid var(--border-color);">
                            <td style="padding: 12px;"><?php echo htmlspecialchars($class_name); ?></td>
                            <td style="padding: 12px; text-align: right;"><?php echo $data['count']; ?></td>
                            <td style="padding: 12px; text-align: right; font-weight: 600;"><?php echo format_currency($data['canteen']); ?></td>
                            <td style="padding: 12px; text-align: right; font-weight: 600;"><?php echo format_currency($data['bus']); ?></td>
                            <td style="padding: 12px; text-align: right; font-weight: 600; color: #10B981;"><?php echo format_currency($data['total']); ?></td>
                            <td style="padding: 12px; text-align: center;">
                                <strong><?php echo round(($data['verified'] / $data['count']) * 100); ?>%</strong>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Verification Modal -->
<div id="verifyModal" class="verification-modal">
    <div class="modal-content">
        <h3><i class="fas fa-check-circle"></i> Verify Collection</h3>
        <form method="POST">
            <input type="hidden" name="action" value="verify_collection">
            <input type="hidden" name="collection_id" id="collection_id">
            
            <div class="form-group">
                <label>Student Name</label>
                <div id="student_name_display" style="padding: 10px; background: var(--bg-secondary); border-radius: 6px; font-weight: 600;"></div>
            </div>
            
            <div class="form-group">
                <label>Amount to Verify</label>
                <input type="number" name="verified_amount" id="verified_amount" step="0.01" required>
            </div>
            
            <div class="form-group">
                <label>Remarks/Notes</label>
                <textarea name="remarks" placeholder="Add any notes about this collection (optional)"></textarea>
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                <button type="button" class="btn btn-secondary" onclick="closeVerifyModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-check"></i> Verify & Save
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function showVerifyModal(collectionId, studentName, amount) {
    document.getElementById('collection_id').value = collectionId;
    document.getElementById('student_name_display').textContent = studentName;
    document.getElementById('verified_amount').value = amount;
    document.getElementById('verifyModal').classList.add('active');
    document.getElementById('verified_amount').focus();
}

function closeVerifyModal() {
    document.getElementById('verifyModal').classList.remove('active');
}

// Close modal when clicking outside
document.getElementById('verifyModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeVerifyModal();
    }
});
</script>

<?php include BASE_PATH . '/includes/footer.php'; ?>
