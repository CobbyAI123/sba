<?php
// accountant/collect-canteen-fees-teachers.php - Collect Canteen Fees from Teachers (Daily/Weekly)
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Collect Canteen Fees';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle payment submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'record_payment') {
    $user_id = (int)$_POST['user_id'];
    $amount = (float)$_POST['amount'];
    $payment_method = sanitize_input($_POST['payment_method']);
    $payment_date = sanitize_input($_POST['payment_date']);
    $period_type = sanitize_input($_POST['period_type']); // daily or weekly
    $notes = sanitize_input($_POST['notes'] ?? '');
    
    try {
        // Check if staff_payments table exists, create if not
        $stmt = $db->query("SHOW TABLES LIKE 'staff_payments'");
        if ($stmt->rowCount() == 0) {
            // Create staff_payments table
            $db->exec("
                CREATE TABLE staff_payments (
                    payment_id INT PRIMARY KEY AUTO_INCREMENT,
                    school_id INT NOT NULL,
                    user_id INT NOT NULL,
                    amount DECIMAL(10,2) NOT NULL,
                    payment_type ENUM('canteen', 'transport', 'other') NOT NULL,
                    payment_method ENUM('cash', 'bank_transfer', 'card') NOT NULL,
                    payment_reference VARCHAR(100),
                    payment_date DATE NOT NULL,
                    status ENUM('pending', 'paid', 'failed') DEFAULT 'paid',
                    remarks TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (school_id) REFERENCES schools(school_id) ON DELETE CASCADE,
                    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
                )
            ");
        }
        
        $payment_reference = $period_type . '_canteen_' . date('Ymd') . '_' . $user_id;
        
        // Insert into staff_payments table (not payments table)
        $stmt = $db->prepare("
            INSERT INTO staff_payments (school_id, user_id, amount, payment_type, payment_method, payment_reference, payment_date, status, remarks, created_at)
            VALUES (?, ?, ?, 'canteen', ?, ?, ?, 'paid', ?, NOW())
        ");
        $stmt->execute([$school_id, $user_id, $amount, $payment_method, $payment_reference, $payment_date, $notes]);
        
        log_activity($current_user['user_id'], "Recorded canteen fee ($period_type) from teacher/staff ID: $user_id", 'payments', $db->lastInsertId());
        set_message('success', 'Canteen payment recorded successfully!');
        redirect(APP_URL . '/accountant/collect-canteen-fees-teachers.php');
    } catch (PDOException $e) {
        set_message('error', 'Error recording payment: ' . $e->getMessage());
    }
}

// Get collection period
$period = isset($_GET['period']) ? $_GET['period'] : 'daily';

// Get all active teachers and staff
$stmt = $db->prepare("
    SELECT 
        u.user_id,
        u.first_name,
        u.last_name,
        u.email,
        u.role,
        COALESCE(SUM(CASE WHEN DATE(p.payment_date) = CURDATE() THEN p.amount ELSE 0 END), 0) as paid_today,
        COALESCE(SUM(CASE WHEN YEARWEEK(p.payment_date) = YEARWEEK(CURDATE()) THEN p.amount ELSE 0 END), 0) as paid_this_week
    FROM users u
    LEFT JOIN payments p ON u.user_id = p.user_id AND (p.payment_reference LIKE '%canteen%' OR p.payment_type = 'canteen')
    WHERE u.school_id = ? 
    AND u.role IN ('teacher', 'admin', 'accountant', 'librarian', 'proprietor')
    AND u.status = 'active'
    GROUP BY u.user_id
    ORDER BY u.first_name, u.last_name
");
$stmt->execute([$school_id]);
$staff = $stmt->fetchAll();

// Get today's canteen collection
$stmt = $db->prepare("
    SELECT COALESCE(SUM(amount), 0) as total
    FROM payments
    WHERE DATE(payment_date) = CURDATE()
    AND (payment_reference LIKE '%canteen%' OR payment_type = 'canteen')
    AND school_id = ?
");
$stmt->execute([$school_id]);
$today_total = $stmt->fetch()['total'] ?? 0;

// Get this week's canteen collection
$stmt = $db->prepare("
    SELECT COALESCE(SUM(amount), 0) as total
    FROM payments
    WHERE YEARWEEK(payment_date) = YEARWEEK(CURDATE())
    AND (payment_reference LIKE '%canteen%' OR payment_type = 'canteen')
    AND school_id = ?
");
$stmt->execute([$school_id]);
$week_total = $stmt->fetch()['total'] ?? 0;

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .period-toggle {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
    }
    
    .period-btn {
        flex: 1;
        padding: 15px;
        background: white;
        border: 2px solid var(--border-color);
        border-radius: 8px;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s;
        text-decoration: none;
        color: var(--text-primary);
    }
    
    .period-btn:hover {
        border-color: var(--primary-blue);
        background: var(--bg-secondary);
    }
    
    .period-btn.active {
        background: var(--primary-blue);
        color: white;
        border-color: var(--primary-blue);
    }
    
    .quick-amount-btn {
        padding: 10px 15px;
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        border-radius: 6px;
        cursor: pointer;
        transition: all 0.3s;
    }
    
    .quick-amount-btn:hover {
        background: var(--primary-blue);
        color: white;
        border-color: var(--primary-blue);
    }
    </style>
    
    <!-- Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #f093fb, #f5576c); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-utensils"></i> Collect Canteen Fees (Teachers & Staff)
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Daily and weekly canteen fee collection from teachers and staff
            </p>
        </div>
    </div>
    
    <!-- Collection Stats -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">
        <div class="card">
            <div style="padding: 25px; text-align: center; background: linear-gradient(135deg, #4CAF50, #8BC34A); color: white; border-radius: 8px;">
                <h2 style="margin: 0 0 5px 0; color: white; font-size: 36px;"><?php echo format_currency($today_total); ?></h2>
                <p style="margin: 0; opacity: 0.9;"><i class="fas fa-calendar-day"></i> Collected Today</p>
            </div>
        </div>
        <div class="card">
            <div style="padding: 25px; text-align: center; background: linear-gradient(135deg, #667eea, #764ba2); color: white; border-radius: 8px;">
                <h2 style="margin: 0 0 5px 0; color: white; font-size: 36px;"><?php echo format_currency($week_total); ?></h2>
                <p style="margin: 0; opacity: 0.9;"><i class="fas fa-calendar-week"></i> Collected This Week</p>
            </div>
        </div>
    </div>
    
    <!-- Period Selection -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-calendar-alt"></i> Collection Period</h3>
        </div>
        <div style="padding: 20px;">
            <div class="period-toggle">
                <a href="?period=daily" class="period-btn <?php echo $period == 'daily' ? 'active' : ''; ?>">
                    <i class="fas fa-calendar-day" style="font-size: 24px; display: block; margin-bottom: 10px;"></i>
                    <strong>Daily Collection</strong>
                    <p style="margin: 5px 0 0 0; font-size: 12px; opacity: 0.8;">Collect daily canteen fees</p>
                </a>
                <a href="?period=weekly" class="period-btn <?php echo $period == 'weekly' ? 'active' : ''; ?>">
                    <i class="fas fa-calendar-week" style="font-size: 24px; display: block; margin-bottom: 10px;"></i>
                    <strong>Weekly Collection</strong>
                    <p style="margin: 5px 0 0 0; font-size: 12px; opacity: 0.8;">Collect weekly canteen fees</p>
                </a>
            </div>
        </div>
    </div>
    
    <!-- Teachers & Staff List -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-users"></i> Teachers & Staff (<?php echo count($staff); ?>)</h3>
            <div>
                <input type="text" id="searchStaff" placeholder="Search by name..." 
                       style="padding: 8px 12px; border: 1px solid var(--border-color); border-radius: 6px;">
            </div>
        </div>
        <div>
            <!-- Header Row -->
            <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr auto; gap: 15px; padding: 15px; background: var(--bg-secondary); font-weight: 600; border-bottom: 2px solid var(--border-color);">
                <div>Name & Role</div>
                <div>Email</div>
                <div>Paid Today</div>
                <div>Paid This Week</div>
                <div>Action</div>
            </div>
            
            <!-- Staff Rows -->
            <div id="staffList">
                <?php foreach ($staff as $person): ?>
                    <div class="staff-item" style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr auto; gap: 15px; padding: 15px; border-bottom: 1px solid var(--border-color); align-items: center;"
                         data-search="<?php echo strtolower($person['first_name'] . ' ' . $person['last_name'] . ' ' . $person['email']); ?>">
                        <div>
                            <strong><?php echo $person['first_name'] . ' ' . $person['last_name']; ?></strong>
                            <br>
                            <small style="color: var(--text-secondary);">
                                <span class="badge badge-info"><?php echo ucfirst($person['role']); ?></span>
                            </small>
                        </div>
                        <div>
                            <small><?php echo $person['email']; ?></small>
                        </div>
                        <div>
                            <strong style="color: <?php echo $person['paid_today'] > 0 ? 'var(--success-green)' : 'var(--text-secondary)'; ?>">
                                <?php echo format_currency($person['paid_today']); ?>
                            </strong>
                        </div>
                        <div>
                            <strong style="color: <?php echo $person['paid_this_week'] > 0 ? 'var(--success-green)' : 'var(--text-secondary)'; ?>">
                                <?php echo format_currency($person['paid_this_week']); ?>
                            </strong>
                        </div>
                        <div>
                            <button onclick="openPaymentModal(<?php echo htmlspecialchars(json_encode($person)); ?>, '<?php echo $period; ?>')" 
                                    class="btn btn-primary btn-sm">
                                <i class="fas fa-plus"></i> Collect
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- Payment Modal -->
    <div id="paymentModal" class="payment-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
        <div class="modal-content" style="background: white; padding: 30px; border-radius: 12px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h3 style="margin: 0;"><i class="fas fa-utensils"></i> Record Canteen Payment</h3>
                <button onclick="closePaymentModal()" class="btn btn-outline" style="padding: 5px 10px;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="paymentForm">
                <input type="hidden" name="action" value="record_payment">
                <input type="hidden" name="user_id" id="modal_user_id">
                <input type="hidden" name="period_type" id="modal_period_type">
                
                <div id="staffInfo" style="background: var(--bg-secondary); padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <!-- Staff info will be inserted here -->
                </div>
                
                <div class="form-group">
                    <label>Amount <span style="color: red;">*</span></label>
                    <input type="number" name="amount" id="amount_input" step="0.01" required class="form-control" placeholder="Enter amount">
                    <div style="display: flex; gap: 8px; margin-top: 10px; flex-wrap: wrap;">
                        <button type="button" class="quick-amount-btn" onclick="setAmount(50)">₦50</button>
                        <button type="button" class="quick-amount-btn" onclick="setAmount(100)">₦100</button>
                        <button type="button" class="quick-amount-btn" onclick="setAmount(200)">₦200</button>
                        <button type="button" class="quick-amount-btn" onclick="setAmount(500)">₦500</button>
                        <button type="button" class="quick-amount-btn" onclick="setAmount(1000)">₦1,000</button>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Payment Method <span style="color: red;">*</span></label>
                    <select name="payment_method" required class="form-control">
                        <option value="">Select method</option>
                        <option value="cash" selected>Cash</option>
                        <option value="mobile_money">Mobile Money</option>
                        <option value="card">Card Payment</option>
                        <option value="bank_transfer">Bank Transfer</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Payment Date <span style="color: red;">*</span></label>
                    <input type="date" name="payment_date" required class="form-control" value="<?php echo date('Y-m-d'); ?>">
                </div>
                
                <div class="form-group">
                    <label>Notes (Optional)</label>
                    <textarea name="notes" class="form-control" rows="2" placeholder="Additional notes..."></textarea>
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="submit" class="btn btn-success" style="flex: 1;">
                        <i class="fas fa-check"></i> Record Payment
                    </button>
                    <button type="button" onclick="closePaymentModal()" class="btn btn-outline" style="flex: 1;">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    // Search functionality
    document.getElementById('searchStaff').addEventListener('input', function(e) {
        const search = e.target.value.toLowerCase();
        const items = document.querySelectorAll('.staff-item');
        
        items.forEach(item => {
            const searchText = item.getAttribute('data-search');
            if (searchText.includes(search)) {
                item.style.display = 'grid';
            } else {
                item.style.display = 'none';
            }
        });
    });
    
    function setAmount(amount) {
        document.getElementById('amount_input').value = amount;
    }
    
    function openPaymentModal(person, period) {
        document.getElementById('modal_user_id').value = person.user_id;
        document.getElementById('modal_period_type').value = period;
        
        const periodText = period === 'daily' ? 'Daily' : 'Weekly';
        const paidAmount = period === 'daily' ? person.paid_today : person.paid_this_week;
        
        document.getElementById('staffInfo').innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: start;">
                <div>
                    <strong style="font-size: 16px;">${person.first_name} ${person.last_name}</strong><br>
                    <small style="color: var(--text-secondary);">${person.role.charAt(0).toUpperCase() + person.role.slice(1)} - ${person.email}</small>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 12px; color: var(--text-secondary);">${periodText} Paid</div>
                    <strong style="color: var(--success-green); font-size: 16px;"><?php echo CURRENCY_SYMBOL; ?>${parseFloat(paidAmount).toLocaleString()}</strong>
                </div>
            </div>
        `;
        document.getElementById('paymentModal').style.display = 'flex';
    }
    
    function closePaymentModal() {
        document.getElementById('paymentModal').style.display = 'none';
        document.getElementById('paymentForm').reset();
    }
    
    // Close modal on outside click
    document.getElementById('paymentModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closePaymentModal();
        }
    });
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
