<?php
// accountant/revenue-reports.php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/auto-update-session.php';

$page_title = 'Revenue Reports';
check_permission(['accountant', 'admin']);

$db = Database::getInstance()->getConnection();
$school_id = $_SESSION['user']['school_id'] ?? (isset($GLOBALS['current_user']) ? $GLOBALS['current_user']['school_id'] : 0);

// Get date range
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');

// Get monthly revenue with error handling
$monthly_revenue = [];
try {
    $stmt = $db->prepare("
        SELECT 
            DATE_FORMAT(p.created_at, '%Y-%m') as month,
            COUNT(*) as transaction_count,
            SUM(p.amount) as total
        FROM payments p
        WHERE p.school_id = ? 
        AND DATE(p.created_at) BETWEEN ? AND ?
        GROUP BY DATE_FORMAT(p.created_at, '%Y-%m')
        ORDER BY month DESC
    ");
    $stmt->execute([$school_id, $start_date, $end_date]);
    $monthly_revenue = $stmt->fetchAll();
} catch (PDOException $e) {
    $monthly_revenue = [];
}

// Get payment methods breakdown
$stmt = $db->prepare("
    SELECT 
        COALESCE(payment_method, 'Not Specified') as payment_method,
        COUNT(*) as count,
        SUM(amount) as total
    FROM transactions
    WHERE school_id = ? AND status = 'completed'
    AND transaction_type = 'fee_payment'
    AND COALESCE(payment_date, created_at) BETWEEN ? AND ?
    GROUP BY payment_method
");
$stmt->execute([$school_id, $start_date, $end_date]);
$payment_methods = $stmt->fetchAll();

// Get total statistics
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_transactions,
        SUM(amount) as total_revenue,
        AVG(amount) as average_payment
    FROM transactions
    WHERE school_id = ? AND status = 'completed'
    AND transaction_type = 'fee_payment'
    AND COALESCE(payment_date, created_at) BETWEEN ? AND ?
");
$stmt->execute([$school_id, $start_date, $end_date]);
$stats = $stmt->fetch();

// Get top students by payment
$stmt = $db->prepare("
    SELECT 
        u.first_name,
        u.last_name,
        COUNT(t.transaction_id) as payment_count,
        SUM(t.amount) as total_paid
    FROM transactions t
    INNER JOIN students s ON t.student_id = s.student_id
    LEFT JOIN users u ON s.user_id = u.user_id
    WHERE t.school_id = ? AND t.status = 'completed'
    AND t.transaction_type = 'fee_payment'
    AND COALESCE(t.payment_date, t.created_at) BETWEEN ? AND ?
    GROUP BY t.student_id
    ORDER BY total_paid DESC
    LIMIT 10
");
$stmt->execute([$school_id, $start_date, $end_date]);
$top_payers = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Auto-refresh Indicator -->
    <div id="refreshIndicator" style="position: fixed; top: 70px; right: 20px; background: var(--primary-blue); color: white; padding: 10px 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); display: none; z-index: 1000; animation: slideInRight 0.3s ease;">
        <i class="fas fa-sync-alt fa-spin"></i> Updating...
    </div>
    
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
        <div>
            <h3 style="margin: 0 0 5px 0;"><i class="fas fa-chart-line"></i> Revenue Reports</h3>
            <p style="margin: 0; opacity: 0.9; font-size: 14px;">Real-time revenue monitoring - Auto-refreshes every 30 seconds</p>
        </div>
        <div style="text-align: right;">
            <div style="font-size: 12px; opacity: 0.8;">Last updated</div>
            <div id="lastUpdated" style="font-size: 14px; font-weight: 600;">Just now</div>
        </div>
    </div>
    
    <!-- Statistics Cards -->
    <div class="stats-grid" id="statsCards">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="stat-details">
                <h3 id="totalRevenue"><?php echo format_currency($stats['total_revenue'] ?? 0); ?></h3>
                <p>Total Revenue</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-exchange-alt"></i>
            </div>
            <div class="stat-details">
                <h3 id="totalTransactions"><?php echo $stats['total_transactions'] ?? 0; ?></h3>
                <p>Transactions</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="stat-details">
                <h3 id="averagePayment"><?php echo format_currency($stats['average_payment'] ?? 0); ?></h3>
                <p>Average Payment</p>
            </div>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-filter"></i> Filter Report</h3>
        </div>
        <form method="GET" style="display: grid; grid-template-columns: 1fr 1fr auto; gap: 15px; padding: 20px;">
            <div class="form-group">
                <label>Start Date</label>
                <input type="date" name="start_date" value="<?php echo $start_date; ?>" class="form-control">
            </div>
            <div class="form-group">
                <label>End Date</label>
                <input type="date" name="end_date" value="<?php echo $end_date; ?>" class="form-control">
            </div>
            <div style="display: flex; align-items: flex-end; gap: 10px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Filter
                </button>
                <a href="?start_date=<?php echo date('Y-m-01'); ?>&end_date=<?php echo date('Y-m-t'); ?>" class="btn btn-secondary">
                    <i class="fas fa-redo"></i> Reset
                </a>
            </div>
        </form>
    </div>
    
    <!-- Monthly Revenue Chart -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-chart-bar"></i> Monthly Revenue Trend</h3>
        </div>
        <div style="padding: 20px; text-align: center; color: var(--text-secondary);">
            <p>Chart data loading...</p>
        </div>
    </div>
    
    <!-- Two Column Layout -->
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">
        <!-- Payment Methods Breakdown -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-credit-card"></i> Payment Methods</h3>
            </div>
            <div id="paymentMethodsList" style="padding: 20px;">
                <?php if (count($payment_methods) > 0): ?>
                    <?php foreach ($payment_methods as $method): ?>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; padding-bottom: 10px; border-bottom: 1px solid var(--border-color);">
                            <span><?php echo ucfirst($method['payment_method']); ?></span>
                            <strong><?php echo $method['count']; ?> - <?php echo format_currency($method['total']); ?></strong>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="color: var(--text-secondary); text-align: center;">No payment method data</p>
                <?php endif; ?>
            </div>
        </div>
    
        <!-- Top Payers -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-user-tie"></i> Top Payers</h3>
            </div>
            <div id="topPayersList" style="padding: 20px;">
                <?php if (count($top_payers) > 0): ?>
                    <table style="width: 100%;">
                        <thead>
                            <tr>
                                <th style="text-align: left;">Student</th>
                                <th style="text-align: right;">Paid</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_payers as $index => $payer): ?>
                                <tr style="border-bottom: 1px solid var(--border-color);">
                                    <td style="padding: 10px 0;">
                                        <span style="background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); color: white; padding: 2px 8px; border-radius: 50%; font-weight: 600; font-size: 12px; margin-right: 10px;">
                                            <?php echo $index + 1; ?>
                                        </span>
                                        <?php echo $payer['first_name'] . ' ' . $payer['last_name']; ?>
                                    </td>
                                    <td style="text-align: right; padding: 10px 0;">
                                        <strong><?php echo format_currency($payer['total_paid']); ?></strong>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p style="color: var(--text-secondary); text-align: center;">No payment data available</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Monthly Revenue Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-table"></i> Monthly Breakdown</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Month</th>
                        <th>Transactions</th>
                        <th>Total Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($monthly_revenue) > 0): ?>
                        <?php foreach ($monthly_revenue as $month): ?>
                            <tr>
                                <td><?php echo date('F Y', strtotime($month['month'] . '-01')); ?></td>
                                <td><?php echo $month['transaction_count']; ?></td>
                                <td><strong><?php echo format_currency($month['total']); ?></strong></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" style="text-align: center; padding: 40px;">
                                <p style="color: var(--text-secondary);">No revenue data for the selected period</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
