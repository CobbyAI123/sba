<?php
// accountant/dashboard.php - Accountant Dashboard with Income Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Accountant Dashboard';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get school info
$stmt = $db->prepare("SELECT school_name FROM schools WHERE school_id = ?");
$stmt->execute([$school_id]);
$school_info = $stmt->fetch();

// Get current month boundaries
$month_start = date('Y-m-01 00:00:00');
$month_end = date('Y-m-t 23:59:59');

// Get total revenue (all time)
$total_revenue = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE school_id = ? AND status IN ('paid', 'completed')
    ");
    $stmt->execute([$school_id]);
    $total_revenue = $stmt->fetch()['total'] ?? 0;
    
    // Add teacher collections (canteen, bus)
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM teacher_collections 
        WHERE school_id = ?
    ");
    $stmt->execute([$school_id]);
    $total_revenue += $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    $total_revenue = 0;
}

// Get pending revenue
$pending_revenue = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total
        FROM payments
        WHERE school_id = ? AND status = 'pending'
    ");
    $stmt->execute([$school_id]);
    $pending_revenue = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    $pending_revenue = 0;
}

// Get this month's income
$this_month_income = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE school_id = ? AND status IN ('paid', 'completed') 
        AND created_at BETWEEN ? AND ?
    ");
    $stmt->execute([$school_id, $month_start, $month_end]);
    $this_month_income = $stmt->fetch()['total'] ?? 0;
    
    // Add teacher collections for this month
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM teacher_collections 
        WHERE school_id = ?
        AND collection_date BETWEEN ? AND ?
    ");
    $stmt->execute([$school_id, $month_start, $month_end]);
    $this_month_income += $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    $this_month_income = 0;
}

// Get this month's expenditure
$this_month_expenditure = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM expenses 
        WHERE school_id = ? AND status = 'approved'
        AND expense_date BETWEEN ? AND ?
    ");
    $stmt->execute([$school_id, date('Y-m-01'), date('Y-m-t')]);
    $this_month_expenditure = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    $this_month_expenditure = 0;
}

// Get total expenses (all time)
$total_expenses = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM expenses 
        WHERE school_id = ? AND status = 'approved'
    ");
    $stmt->execute([$school_id]);
    $total_expenses = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    $total_expenses = 0;
}

// Calculate net profit
$net_profit = $total_revenue - $total_expenses;
$monthly_net_profit = $this_month_income - $this_month_expenditure;

// Get overdue amount
$overdue = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total
        FROM payments
        WHERE school_id = ? AND status = 'overdue'
    ");
    $stmt->execute([$school_id]);
    $overdue = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    $overdue = 0;
}

// Calculate collection rate
$total_expected = $total_revenue + $pending_revenue + $overdue;
$collection_rate = $total_expected > 0 ? ($total_revenue / $total_expected) * 100 : 0;

// Get teacher collections (canteen)
$canteen_collections = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM teacher_collections 
        WHERE school_id = ? AND collection_type = 'canteen'
    ");
    $stmt->execute([$school_id]);
    $canteen_collections = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    $canteen_collections = 0;
}

// Get teacher collections (bus)
$bus_collections = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM teacher_collections 
        WHERE school_id = ? AND collection_type = 'bus'
    ");
    $stmt->execute([$school_id]);
    $bus_collections = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    $bus_collections = 0;
}

// Total teacher collections
$teacher_collections_total = $canteen_collections + $bus_collections;

// ==============================================
// ONLINE TRANSACTION STATISTICS
// ==============================================

// Get online transactions (MTN, Tigo, PayStack)
$online_transactions_total = 0;
$online_transactions_count = 0;
try {
    $stmt = $db->prepare("
        SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as total
        FROM transactions
        WHERE school_id = ? AND status = 'completed'
        AND gateway_name IN ('mtn_momo', 'tigo_cash', 'paystack')
    ");
    $stmt->execute([$school_id]);
    $result = $stmt->fetch();
    $online_transactions_count = $result['count'] ?? 0;
    $online_transactions_total = $result['total'] ?? 0;
} catch (PDOException $e) {
    $online_transactions_total = 0;
    $online_transactions_count = 0;
}

// Get pending online transactions
$pending_online_transactions = 0;
try {
    $stmt = $db->prepare("
        SELECT COUNT(*) as count
        FROM transactions
        WHERE school_id = ? AND status = 'pending'
    ");
    $stmt->execute([$school_id]);
    $pending_online_transactions = $stmt->fetch()['count'] ?? 0;
} catch (PDOException $e) {
    $pending_online_transactions = 0;
}

// Get failed online transactions
$failed_online_transactions = 0;
try {
    $stmt = $db->prepare("
        SELECT COUNT(*) as count
        FROM transactions
        WHERE school_id = ? AND status = 'failed'
    ");
    $stmt->execute([$school_id]);
    $failed_online_transactions = $stmt->fetch()['count'] ?? 0;
} catch (PDOException $e) {
    $failed_online_transactions = 0;
}

// Get today's transactions
$today_transactions = 0;
$today_transactions_amount = 0;
try {
    $stmt = $db->prepare("
        SELECT COUNT(*) as count, COALESCE(SUM(amount), 0) as total
        FROM transactions
        WHERE school_id = ? AND DATE(created_at) = CURDATE() AND status = 'completed'
    ");
    $stmt->execute([$school_id]);
    $result = $stmt->fetch();
    $today_transactions = $result['count'] ?? 0;
    $today_transactions_amount = $result['total'] ?? 0;
} catch (PDOException $e) {
    $today_transactions = 0;
    $today_transactions_amount = 0;
}

// Get payment gateway breakdown
$gateway_stats = [];
try {
    $stmt = $db->prepare("
        SELECT 
            gateway_name,
            COUNT(*) as transaction_count,
            COALESCE(SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END), 0) as total_amount
        FROM transactions
        WHERE school_id = ?
        AND gateway_name IN ('mtn_momo', 'tigo_cash', 'paystack')
        GROUP BY gateway_name
    ");
    $stmt->execute([$school_id]);
    $gateway_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $gateway_stats = [];
}

// Get recent transactions (last 10)
$recent_transactions = [];
try {
    $stmt = $db->prepare("
        SELECT 
            t.*,
            s.admission_number,
            CONCAT(u.first_name, ' ', u.last_name) as student_name
        FROM transactions t
        LEFT JOIN students s ON t.student_id = s.student_id
        LEFT JOIN users u ON s.user_id = u.user_id
        WHERE t.school_id = ?
        ORDER BY t.created_at DESC
        LIMIT 10
    ");
    $stmt->execute([$school_id]);
    $recent_transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    $recent_transactions = [];
}

// Get all student payments (all payment types)
$student_payments_total = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM payments 
        WHERE school_id = ? AND status IN ('paid', 'completed')
    ");
    $stmt->execute([$school_id]);
    $student_payments_total = $stmt->fetch()['total'] ?? 0;
    
    // Add online transactions
    $student_payments_total += $online_transactions_total;
} catch (PDOException $e) {
    $student_payments_total = 0;
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
        /* Welcome Banner */
        .welcome-banner {
            background: linear-gradient(135deg, #66BB6A 0%, #43A047 100%);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            color: white;
            box-shadow: 0 8px 20px rgba(67, 160, 71, 0.3);
        }
    
        .welcome-banner h2 {
            margin: 0 0 5px 0;
            font-size: 28px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
    
        .welcome-banner p {
            margin: 0;
            font-size: 16px;
            opacity: 0.95;
        }
    
        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
    
        .stat-card {
            background: linear-gradient(135deg, #1e2f4d 0%, #2a3f5f 100%);
            border-radius: 12px;
            padding: 25px;
            border-left: 4px solid;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
    
        .stat-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 50%;
        }
    
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
    
        .stat-card.revenue {
            border-left-color: #4CAF50;
        }
    
        .stat-card.pending {
            border-left-color: #FFA726;
        }
    
        .stat-card.income {
            border-left-color: #42A5F5;
        }
    
        .stat-card.expenditure {
            border-left-color: #EF5350;
        }
    
        .stat-card.overdue {
            border-left-color: #FF5252;
        }
    
        .stat-card.collection {
            border-left-color: #AB47BC;
        }
    
        .stat-card.canteen {
            border-left-color: #FFA726;
        }
    
        .stat-card.transport {
            border-left-color: #26A69A;
        }
    
        .stat-icon {
            font-size: 32px;
            margin-bottom: 15px;
            opacity: 0.9;
        }
    
        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: white;
            margin-bottom: 5px;
        }
    
        .stat-label {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.8);
            font-weight: 500;
        }
    
        /* Revenue Management Section */
        .section-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 25px;
            color: var(--text-primary);
        }
    
        .revenue-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }
    
        .revenue-card {
            border-radius: 15px;
            padding: 35px;
            color: white;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            cursor: pointer;
        }
    
        .revenue-card::before {
            content: '';
            position: absolute;
            top: -100px;
            right: -100px;
            width: 300px;
            height: 300px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
    
        .revenue-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
        }
    
        .revenue-card.school-fees {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
    
        .revenue-card.canteen {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
    
        .revenue-card.transport {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
    
        .revenue-icon {
            font-size: 48px;
            margin-bottom: 20px;
            opacity: 0.95;
        }
    
        .revenue-title {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 15px;
        }
    
        .revenue-amount {
            font-size: 36px;
            font-weight: 800;
            margin-bottom: 20px;
        }
    
        .revenue-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
    
        .revenue-btn {
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.3);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
    
        .revenue-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
            color: white;
        }
    </style>
    
    <!-- Welcome Banner -->
    <div class="welcome-banner">
        <h2>
            <i class="fas fa-hand-sparkles"></i>
            Welcome, <?php echo htmlspecialchars(strtoupper($current_user['first_name'])); ?>!
        </h2>
        <p>Financial Overview - <?php echo date('l, F d, Y'); ?></p>
    </div>
    
    <!-- Financial Statistics Grid -->
    <div class="stats-grid">
        <!-- Total Revenue -->
        <div class="stat-card revenue">
            <div class="stat-icon">
                <i class="fas fa-money-bill-wave" style="color: #4CAF50;"></i>
            </div>
            <div class="stat-value"><?php echo format_currency($total_revenue); ?></div>
            <div class="stat-label">Total Revenue</div>
        </div>
    
        <!-- Pending Revenue -->
        <div class="stat-card pending">
            <div class="stat-icon">
                <i class="fas fa-clock" style="color: #FFA726;"></i>
            </div>
            <div class="stat-value"><?php echo format_currency($pending_revenue); ?></div>
            <div class="stat-label">Pending Revenue</div>
        </div>
    
        <!-- This Month Income -->
        <div class="stat-card income">
            <div class="stat-icon">
                <i class="fas fa-arrow-up" style="color: #42A5F5;"></i>
            </div>
            <div class="stat-value"><?php echo format_currency($this_month_income); ?></div>
            <div class="stat-label">This Month Income</div>
        </div>
    
        <!-- This Month Expenditure -->
        <div class="stat-card expenditure">
            <div class="stat-icon">
                <i class="fas fa-shopping-cart" style="color: #EF5350;"></i>
            </div>
            <div class="stat-value"><?php echo format_currency($this_month_expenditure); ?></div>
            <div class="stat-label">This Month Expenditure</div>
        </div>
    
        <!-- Overdue -->
        <div class="stat-card overdue">
            <div class="stat-icon">
                <i class="fas fa-exclamation-triangle" style="color: #FF5252;"></i>
            </div>
            <div class="stat-value"><?php echo format_currency($overdue); ?></div>
            <div class="stat-label">Overdue</div>
        </div>
    
        <!-- Collection Rate -->
        <div class="stat-card collection">
            <div class="stat-icon">
                <i class="fas fa-percentage" style="color: #AB47BC;"></i>
            </div>
            <div class="stat-value"><?php echo number_format($collection_rate, 0); ?>%</div>
            <div class="stat-label">Collection Rate</div>
        </div>
    
        <!-- Teacher Collections -->
        <div class="stat-card teacher-collections">
            <div class="stat-icon">
                <i class="fas fa-hand-holding-usd" style="color: #9C27B0;"></i>
            </div>
            <div class="stat-value"><?php echo format_currency($teacher_collections_total); ?></div>
            <div class="stat-label">Teacher Collections</div>
        </div>
    
        <!-- Total Expenses -->
        <div class="stat-card expenditure">
            <div class="stat-icon">
                <i class="fas fa-receipt" style="color: #FF5252;"></i>
            </div>
            <div class="stat-value"><?php echo format_currency($total_expenses); ?></div>
            <div class="stat-label">Total Expenses</div>
        </div>
    
        <!-- Net Profit -->
        <div class="stat-card <?php echo $net_profit >= 0 ? 'income' : 'expenditure'; ?>">
            <div class="stat-icon">
                <i class="fas fa-<?php echo $net_profit >= 0 ? 'arrow-up' : 'arrow-down'; ?>" style="color: <?php echo $net_profit >= 0 ? '#4CAF50' : '#EF5350'; ?>;"></i>
            </div>
            <div class="stat-value"><?php echo format_currency($net_profit); ?></div>
            <div class="stat-label">Net Profit (All Time)</div>
        </div>
    
        <!-- Monthly Net Profit -->
        <div class="stat-card <?php echo $monthly_net_profit >= 0 ? 'income' : 'expenditure'; ?>">
            <div class="stat-icon">
                <i class="fas fa-calendar-alt" style="color: <?php echo $monthly_net_profit >= 0 ? '#42A5F5' : '#FF5252'; ?>;"></i>
            </div>
            <div class="stat-value"><?php echo format_currency($monthly_net_profit); ?></div>
            <div class="stat-label">Monthly Net Profit</div>
        </div>
    </div>
    
    <!-- Quick Actions Widget -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border: none;">
        <div class="card-header" style="border-bottom: 1px solid rgba(255,255,255,0.2); background: transparent;">
            <h3 style="color: white; margin: 0; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-bolt"></i> Quick Actions
            </h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9; font-size: 13px; color: white;">One-click access to common tasks</p>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; padding: 20px;">
            
            <!-- Record Payment -->
            <a href="<?php echo APP_URL; ?>/accountant/payments.php" class="quick-action-btn" style="text-decoration: none;">
                <i class="fas fa-money-bill-wave"></i>
                <span>Record Payment</span>
                <small>Fast entry</small>
            </a>
            
            <!-- Record Expense -->
            <a href="<?php echo APP_URL; ?>/accountant/expenses.php" class="quick-action-btn" style="text-decoration: none;">
                <i class="fas fa-receipt"></i>
                <span>Record Expense</span>
                <small>Track costs</small>
            </a>
            
            <!-- Print Receipt -->
            <a href="<?php echo APP_URL; ?>/accountant/receipts.php" class="quick-action-btn" style="text-decoration: none;">
                <i class="fas fa-print"></i>
                <span>Print Receipt</span>
                <small>Student receipts</small>
            </a>
            
            <!-- Today's Report -->
            <a href="<?php echo APP_URL; ?>/accountant/revenue-reports.php?start_date=<?php echo date('Y-m-d'); ?>&end_date=<?php echo date('Y-m-d'); ?>" class="quick-action-btn" style="text-decoration: none;">
                <i class="fas fa-chart-line"></i>
                <span>Today's Report</span>
                <small>Collection summary</small>
            </a>
            
            <!-- Outstanding Fees -->
            <a href="<?php echo APP_URL; ?>/accountant/outstanding-fees.php" class="quick-action-btn" style="text-decoration: none;">
                <i class="fas fa-exclamation-circle"></i>
                <span>Outstanding Fees</span>
                <small>Unpaid fees</small>
            </a>
            
            <!-- Revenue Reports -->
            <a href="<?php echo APP_URL; ?>/accountant/revenue-reports.php" class="quick-action-btn" style="text-decoration: none;">
                <i class="fas fa-file-alt"></i>
                <span>Revenue Reports</span>
                <small>Financial analysis</small>
            </a>
        </div>
    </div>
    
    <style>
    .quick-action-btn {
        background: rgba(255, 255, 255, 0.15);
        border: 1px solid rgba(255, 255, 255, 0.3);
        border-radius: 12px;
        padding: 20px 15px;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 8px;
        text-align: center;
        color: white;
        backdrop-filter: blur(10px);
    }
    
    .quick-action-btn:hover {
        background: rgba(255, 255, 255, 0.25);
        border-color: rgba(255, 255, 255, 0.5);
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
        text-decoration: none;
        color: white;
    }
    
    .quick-action-btn:active {
        transform: translateY(-1px);
    }
    
    .quick-action-btn i {
        font-size: 32px;
        opacity: 0.9;
    }
    
    .quick-action-btn span {
        font-size: 15px;
        font-weight: 600;
    }
    
    .quick-action-btn small {
        font-size: 12px;
        opacity: 0.8;
    }
    </style>
    
    <!-- Revenue Management Section -->
    <h3 class="section-title">
        <i class="fas fa-chart-line"></i>
        Revenue Management
    </h3>
    
    <div class="revenue-cards">
        <!-- Student Payments Card -->
        <div class="revenue-card school-fees" onclick="window.location.href='<?php echo APP_URL; ?>/accountant/student-payments.php'">
            <div class="revenue-icon">
                <i class="fas fa-users"></i>
            </div>
            <div class="revenue-title">Student Payments</div>
            <div class="revenue-amount"><?php echo format_currency($student_payments_total); ?></div>
            <div class="revenue-subtitle" style="font-size: 14px; opacity: 0.9; margin: -10px 0 15px 0;">
                All payment types (Tuition, Canteen, Bus, etc.)
            </div>
            <div class="revenue-actions">
                <a href="<?php echo APP_URL; ?>/accountant/student-payments.php" class="revenue-btn">
                    <i class="fas fa-users"></i> View Students
                </a>
                <a href="<?php echo APP_URL; ?>/accountant/payments.php" class="revenue-btn">
                    <i class="fas fa-money-check-alt"></i> Manage Payments
                </a>
            </div>
        </div>
    
        <!-- Teacher Collections Card -->
        <div class="revenue-card teacher-collections" onclick="window.location.href='<?php echo APP_URL; ?>/accountant/teacher-collections.php'" style="background: linear-gradient(135deg, #9C27B0 0%, #673AB7 100%);">
            <div class="revenue-icon">
                <i class="fas fa-hand-holding-usd"></i>
            </div>
            <div class="revenue-title">Teacher Collections</div>
            <div class="revenue-amount"><?php echo format_currency($teacher_collections_total); ?></div>
            <div class="revenue-subtitle" style="font-size: 14px; opacity: 0.9; margin: -10px 0 15px 0;">
                Canteen: <?php echo format_currency($canteen_collections); ?> • Bus: <?php echo format_currency($bus_collections); ?>
            </div>
            <div class="revenue-actions">
                <a href="<?php echo APP_URL; ?>/accountant/teacher-collections.php" class="revenue-btn">
                    <i class="fas fa-hand-holding-usd"></i> Collect
                </a>
                <a href="<?php echo APP_URL; ?>/accountant/teacher-collections.php#recent" class="revenue-btn">
                    <i class="fas fa-list"></i> View Records
                </a>
            </div>
        </div>
    </div>
    
    <!-- ONLINE PAYMENT TRANSACTIONS SECTION -->
    <div style="margin: 40px 0 20px 0; padding: 25px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; color: white;">
        <h3 style="margin: 0 0 10px 0; font-size: 24px; font-weight: 700;">
            <i class="fas fa-credit-card"></i> Online Payment Transactions
        </h3>
        <p style="margin: 0; opacity: 0.9; font-size: 14px;">Real-time online payment monitoring (MTN MoMo, Tigo Cash, PayStack)</p>
    </div>
    
    <!-- Online Transaction Stats Grid -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <!-- Online Transactions -->
        <div class="stat-card" style="border-left-color: #667eea; background: linear-gradient(135deg, #1e2f4d 0%, #2a3f5f 100%);">
            <div class="stat-icon">
                <i class="fas fa-mobile-alt" style="color: #667eea;"></i>
            </div>
            <div class="stat-value"><?php echo number_format($online_transactions_count); ?></div>
            <div class="stat-label">Online Transactions</div>
            <div style="margin-top: 10px; font-size: 12px; opacity: 0.8; color: white;">
                Total: <?php echo format_currency($online_transactions_total); ?>
            </div>
        </div>
    
        <!-- Pending Online -->
        <div class="stat-card" style="border-left-color: #f093fb; background: linear-gradient(135deg, #1e2f4d 0%, #2a3f5f 100%);">
            <div class="stat-icon">
                <i class="fas fa-clock" style="color: #f093fb;"></i>
            </div>
            <div class="stat-value"><?php echo number_format($pending_online_transactions); ?></div>
            <div class="stat-label">Pending Transactions</div>
        </div>
    
        <!-- Failed Online -->
        <div class="stat-card" style="border-left-color: #fa709a; background: linear-gradient(135deg, #1e2f4d 0%, #2a3f5f 100%);">
            <div class="stat-icon">
                <i class="fas fa-exclamation-triangle" style="color: #fa709a;"></i>
            </div>
            <div class="stat-value"><?php echo number_format($failed_online_transactions); ?></div>
            <div class="stat-label">Failed Transactions</div>
        </div>
    
        <!-- Today's Transactions -->
        <div class="stat-card" style="border-left-color: #4facfe; background: linear-gradient(135deg, #1e2f4d 0%, #2a3f5f 100%);">
            <div class="stat-icon">
                <i class="fas fa-chart-line" style="color: #4facfe;"></i>
            </div>
            <div class="stat-value"><?php echo number_format($today_transactions); ?></div>
            <div class="stat-label">Today's Transactions</div>
            <div style="margin-top: 10px; font-size: 12px; opacity: 0.8; color: white;">
                Amount: <?php echo format_currency($today_transactions_amount); ?>
            </div>
        </div>
    </div>
    
    <!-- Payment Gateway Performance -->
    <?php if (!empty($gateway_stats)): ?>
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-chart-pie"></i> Payment Gateway Performance</h3>
            <a href="<?php echo APP_URL; ?>/admin/payment-gateway-settings.php" class="btn btn-sm btn-primary">
                <i class="fas fa-cog"></i> Settings
            </a>
        </div>
        <div style="padding: 25px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
                <?php foreach ($gateway_stats as $gateway): ?>
                    <?php
                    $gateway_info = [
                        'mtn_momo' => ['icon' => 'fa-mobile-alt', 'color' => '#FFCC00', 'name' => 'MTN Mobile Money'],
                        'tigo_cash' => ['icon' => 'fa-money-bill-wave', 'color' => '#0066CC', 'name' => 'Tigo Cash'],
                        'paystack' => ['icon' => 'fa-credit-card', 'color' => '#00C3F7', 'name' => 'PayStack']
                    ];
                    $info = $gateway_info[$gateway['gateway_name']] ?? ['icon' => 'fa-wallet', 'color' => '#666', 'name' => ucfirst($gateway['gateway_name'])];
                    ?>
                    <div style="background: var(--bg-secondary); border-radius: 12px; padding: 20px; border-left: 4px solid <?php echo $info['color']; ?>;">
                        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 15px;">
                            <div style="width: 50px; height: 50px; border-radius: 10px; background: <?php echo $info['color']; ?>; color: white; display: flex; align-items: center; justify-content: center; font-size: 24px;">
                                <i class="fas <?php echo $info['icon']; ?>"></i>
                            </div>
                            <div>
                                <h4 style="margin: 0; font-size: 16px;"><?php echo $info['name']; ?></h4>
                                <p style="margin: 0; font-size: 12px; color: var(--text-secondary);"><?php echo $gateway['transaction_count']; ?> transactions</p>
                            </div>
                        </div>
                        
                        <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border-color);">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <span style="font-size: 12px; color: var(--text-secondary);">Total Revenue</span>
                                <strong style="font-size: 18px; color: var(--primary-blue);"><?php echo format_currency($gateway['total_amount']); ?></strong>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Recent Transactions -->
    <?php if (!empty($recent_transactions)): ?>
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-receipt"></i> Recent Online Transactions</h3>
            <a href="<?php echo APP_URL; ?>/accountant/all-transactions.php" class="btn btn-sm btn-primary">
                <i class="fas fa-eye"></i> View All
            </a>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Reference</th>
                        <th>Student</th>
                        <th>Amount</th>
                        <th>Gateway</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_transactions as $txn): ?>
                        <?php
                        $status_colors = [
                            'completed' => 'success',
                            'pending' => 'warning',
                            'failed' => 'danger'
                        ];
                        $status_color = $status_colors[$txn['status']] ?? 'secondary';
                        
                        $gateway_names = [
                            'mtn_momo' => 'MTN MoMo',
                            'tigo_cash' => 'Tigo Cash',
                            'paystack' => 'PayStack'
                        ];
                        $gateway_display = $gateway_names[$txn['gateway_name']] ?? ucfirst($txn['payment_method'] ?? 'N/A');
                        ?>
                        <tr>
                            <td><?php echo date('M d, Y H:i', strtotime($txn['created_at'])); ?></td>
                            <td>
                                <small style="font-family: monospace; font-size: 11px;"><?php echo htmlspecialchars($txn['reference']); ?></small>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($txn['student_name'] ?? 'N/A'); ?>
                                <?php if ($txn['admission_number']): ?>
                                    <br><small style="color: var(--text-secondary);"><?php echo htmlspecialchars($txn['admission_number']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><strong><?php echo format_currency($txn['amount']); ?></strong></td>
                            <td>
                                <?php if ($txn['gateway_name']): ?>
                                    <span style="padding: 4px 8px; background: var(--bg-secondary); border-radius: 4px; font-size: 11px;">
                                        <?php echo htmlspecialchars($gateway_display); ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color: var(--text-secondary);">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo $status_color; ?>">
                                    <?php echo ucfirst($txn['status']); ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

<?php include BASE_PATH . '/includes/footer.php'; ?>
