<?php
// accountant/messages.php - Accountant Messaging System
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Messages';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$user_id = $current_user['user_id'];

// Helper function to display time elapsed
if (!function_exists('time_elapsed_string')) {
    function time_elapsed_string($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        // Calculate weeks from days
        $weeks = floor($diff->d / 7);
        $days = $diff->d - ($weeks * 7);

        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        
        $values = array(
            'y' => $diff->y,
            'm' => $diff->m,
            'w' => $weeks,
            'd' => $days,
            'h' => $diff->h,
            'i' => $diff->i,
            's' => $diff->s,
        );
        
        foreach ($string as $k => &$v) {
            if ($values[$k]) {
                $v = $values[$k] . ' ' . $v . ($values[$k] > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }
}

// Handle message actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
            set_message('error', 'Invalid request. Please try again.');
            redirect(APP_URL . '/accountant/messages.php');
            exit;
        }
        
        if ($_POST['action'] == 'send_message') {
            $recipient_id = (int)$_POST['recipient_id'];
            $subject = sanitize_input($_POST['subject']);
            $message = sanitize_input($_POST['message']);
            $priority = sanitize_input($_POST['priority'] ?? 'normal');
            
            try {
                $stmt = $db->prepare("
                    INSERT INTO messages (school_id, sender_id, recipient_id, subject, message, message_type, priority, read_status)
                    VALUES (?, ?, ?, ?, ?, 'personal', ?, 'unread')
                ");
                $stmt->execute([$school_id, $user_id, $recipient_id, $subject, $message, $priority]);
                
                set_message('success', 'Message sent successfully!');
                log_activity($user_id, "Sent message: $subject", 'messages', $db->lastInsertId());
                redirect(APP_URL . '/accountant/messages.php?tab=sent');
            } catch (PDOException $e) {
                set_message('error', 'Error sending message: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'mark_read') {
            $message_id = (int)$_POST['message_id'];
            
            try {
                $stmt = $db->prepare("UPDATE messages SET read_status = 'read', read_at = NOW() WHERE message_id = ? AND recipient_id = ?");
                $stmt->execute([$message_id, $user_id]);
                
                echo json_encode(['success' => true]);
                exit;
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
                exit;
            }
        } elseif ($_POST['action'] == 'delete_message') {
            $message_id = (int)$_POST['message_id'];
            
            try {
                $stmt = $db->prepare("UPDATE messages SET deleted_by_recipient = 1 WHERE message_id = ? AND recipient_id = ?");
                $stmt->execute([$message_id, $user_id]);
                
                set_message('success', 'Message deleted successfully!');
                redirect(APP_URL . '/accountant/messages.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting message: ' . $e->getMessage());
            }
        }
    }
}

// Get current tab
$tab = isset($_GET['tab']) ? sanitize_input($_GET['tab']) : 'inbox';

// Get messages based on tab
if ($tab == 'inbox') {
    $stmt = $db->prepare("
        SELECT m.*, 
               u.first_name as sender_first_name,
               u.last_name as sender_last_name,
               u.role as sender_role
        FROM messages m
        INNER JOIN users u ON m.sender_id = u.user_id
        WHERE m.recipient_id = ? AND m.deleted_by_recipient = 0
        ORDER BY m.created_at DESC
    ");
    $stmt->execute([$user_id]);
} elseif ($tab == 'sent') {
    $stmt = $db->prepare("
        SELECT m.*, 
               u.first_name as recipient_first_name,
               u.last_name as recipient_last_name,
               u.role as recipient_role
        FROM messages m
        LEFT JOIN users u ON m.recipient_id = u.user_id
        WHERE m.sender_id = ? AND m.deleted_by_sender = 0
        ORDER BY m.created_at DESC
    ");
    $stmt->execute([$user_id]);
}

$messages = $stmt->fetchAll();

// Get unread count
$stmt = $db->prepare("SELECT COUNT(*) as unread_count FROM messages WHERE recipient_id = ? AND read_status = 'unread' AND deleted_by_recipient = 0");
$stmt->execute([$user_id]);
$unread_count = $stmt->fetch()['unread_count'];

// Get parents and staff for messaging
$stmt = $db->prepare("
    SELECT user_id, first_name, last_name, role 
    FROM users 
    WHERE school_id = ? AND user_id != ? AND role IN ('admin', 'teacher', 'parent') AND status = 'active'
    ORDER BY role, first_name
");
$stmt->execute([$school_id, $user_id]);
$users = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .message-tabs {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
        border-bottom: 2px solid var(--border-color);
    }
    
    .message-tab {
        padding: 12px 24px;
        background: none;
        border: none;
        cursor: pointer;
        color: var(--text-secondary);
        font-weight: 500;
        border-bottom: 3px solid transparent;
        transition: all 0.3s ease;
    }
    
    .message-tab.active {
        color: var(--primary-blue);
        border-bottom-color: var(--primary-blue);
    }
    
    .message-tab:hover {
        color: var(--primary-blue);
        background: rgba(45, 91, 255, 0.05);
    }
    
    .message-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 15px;
        transition: all 0.3s ease;
        cursor: pointer;
    }
    
    .message-card:hover {
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        border-color: var(--primary-blue);
        transform: translateY(-2px);
    }
    
    .message-card.unread {
        background: rgba(45, 91, 255, 0.05);
        border-left: 4px solid var(--primary-blue);
    }
    
    .message-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 10px;
    }
    
    .message-sender {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .sender-avatar {
        width: 45px;
        height: 45px;
        border-radius: 10px;
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 700;
        font-size: 16px;
    }
    
    .sender-info h4 {
        margin: 0;
        font-size: 15px;
        color: var(--text-primary);
    }
    
    .sender-info p {
        margin: 0;
        font-size: 12px;
        color: var(--text-secondary);
    }
    
    .message-meta {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .priority-badge {
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .priority-urgent {
        background: rgba(255, 59, 48, 0.1);
        color: #FF3B30;
    }
    
    .priority-high {
        background: rgba(255, 149, 0, 0.1);
        color: #FF9500;
    }
    
    .priority-normal {
        background: rgba(0, 122, 255, 0.1);
        color: #007AFF;
    }
    
    .message-time {
        font-size: 12px;
        color: var(--text-secondary);
    }
    
    .message-subject {
        font-weight: 600;
        font-size: 16px;
        margin-bottom: 8px;
        color: var(--text-primary);
    }
    
    .message-preview {
        color: var(--text-secondary);
        font-size: 14px;
        line-height: 1.5;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }
    
    .compose-form {
        background: var(--bg-card);
        border-radius: 15px;
        padding: 30px;
        border: 1px solid var(--border-color);
    }
    
    .info-box {
        background: rgba(45, 91, 255, 0.1);
        border-left: 4px solid var(--primary-blue);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }
    
    .info-box i {
        color: var(--primary-blue);
        margin-right: 8px;
    }
    </style>
    
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2><i class="fas fa-envelope"></i> Messages</h2>
        <button class="btn btn-primary" onclick="showComposeModal()">
            <i class="fas fa-paper-plane"></i> Compose Message
        </button>
    </div>
    
    <div class="info-box">
        <i class="fas fa-info-circle"></i>
        <strong>Accountant Messaging:</strong> Send messages to parents, teachers, and admin regarding fees and payments.
    </div>
    
    <!-- Message Tabs -->
    <div class="message-tabs">
        <a href="?tab=inbox" class="message-tab <?php echo $tab == 'inbox' ? 'active' : ''; ?>">
            <i class="fas fa-inbox"></i> Inbox 
            <?php if ($unread_count > 0): ?>
                <span class="badge badge-primary" style="margin-left: 5px;"><?php echo $unread_count; ?></span>
            <?php endif; ?>
        </a>
        <a href="?tab=sent" class="message-tab <?php echo $tab == 'sent' ? 'active' : ''; ?>">
            <i class="fas fa-paper-plane"></i> Sent
        </a>
    </div>
    
    <!-- Messages List -->
    <div class="card">
        <div class="card-header">
            <h3>
                <?php if ($tab == 'inbox'): ?>
                    <i class="fas fa-inbox"></i> Inbox (<?php echo count($messages); ?>)
                <?php else: ?>
                    <i class="fas fa-paper-plane"></i> Sent Messages (<?php echo count($messages); ?>)
                <?php endif; ?>
            </h3>
        </div>
        <div style="padding: 20px;">
            <?php if (count($messages) > 0): ?>
                <?php foreach ($messages as $msg): ?>
                    <?php 
                    $is_inbox = $tab == 'inbox';
                    $sender_name = $is_inbox ? $msg['sender_first_name'] . ' ' . $msg['sender_last_name'] : ($msg['recipient_first_name'] . ' ' . $msg['recipient_last_name']);
                    $initials = $is_inbox ? strtoupper(substr($msg['sender_first_name'], 0, 1) . substr($msg['sender_last_name'], 0, 1)) : strtoupper(substr($sender_name, 0, 2));
                    $role = $is_inbox ? ucfirst(str_replace('_', ' ', $msg['sender_role'])) : ucfirst($msg['recipient_role']);
                    ?>
                    <div class="message-card <?php echo $msg['read_status'] == 'unread' && $is_inbox ? 'unread' : ''; ?>" 
                         onclick="viewMessage(<?php echo $msg['message_id']; ?>)">
                        <div class="message-header">
                            <div class="message-sender">
                                <div class="sender-avatar"><?php echo $initials; ?></div>
                                <div class="sender-info">
                                    <h4><?php echo $sender_name; ?></h4>
                                    <p><?php echo $role; ?></p>
                                </div>
                            </div>
                            <div class="message-meta">
                                <?php if ($msg['priority'] != 'normal'): ?>
                                    <span class="priority-badge priority-<?php echo $msg['priority']; ?>">
                                        <?php echo ucfirst($msg['priority']); ?>
                                    </span>
                                <?php endif; ?>
                                <span class="message-time">
                                    <i class="fas fa-clock"></i>
                                    <?php echo time_elapsed_string($msg['created_at']); ?>
                                </span>
                            </div>
                        </div>
                        <div class="message-subject"><?php echo htmlspecialchars($msg['subject']); ?></div>
                        <div class="message-preview"><?php echo htmlspecialchars($msg['message']); ?></div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 60px;">
                    <i class="fas fa-inbox" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
                    <h3 style="color: var(--text-secondary);">
                        <?php echo $tab == 'inbox' ? 'No messages in your inbox' : 'No sent messages'; ?>
                    </h3>
                    <p style="color: var(--text-secondary);">
                        <?php echo $tab == 'inbox' ? 'You haven\'t received any messages yet' : 'You haven\'t sent any messages yet'; ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Compose Message Modal -->
    <div id="composeModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 700px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                <h2 style="margin: 0;"><i class="fas fa-paper-plane"></i> Compose Message</h2>
                <button onclick="closeComposeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" class="compose-form" style="padding: 0;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="send_message">
                
                <div class="form-group">
                    <label for="recipient_id">To: (Select Recipient)</label>
                    <select name="recipient_id" id="recipient_id" required>
                        <option value="">-- Select Recipient --</option>
                        <?php
                        $current_role = '';
                        foreach ($users as $user):
                            if ($current_role != $user['role']):
                                if ($current_role != '') echo '</optgroup>';
                                $current_role = $user['role'];
                                echo '<optgroup label="' . ucfirst(str_replace('_', ' ', $user['role'])) . '">';
                            endif;
                        ?>
                            <option value="<?php echo $user['user_id']; ?>">
                                <?php echo $user['first_name'] . ' ' . $user['last_name']; ?>
                            </option>
                        <?php endforeach; ?>
                        <?php if ($current_role != '') echo '</optgroup>'; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" name="subject" id="subject" required placeholder="Enter message subject">
                </div>
                
                <div class="form-group">
                    <label for="priority">Priority</label>
                    <select name="priority" id="priority">
                        <option value="normal">Normal</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea name="message" id="message" rows="8" required placeholder="Type your message here..."></textarea>
                </div>
                
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeComposeModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> Send Message
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showComposeModal() {
        document.getElementById('composeModal').style.display = 'block';
    }
    
    function closeComposeModal() {
        document.getElementById('composeModal').style.display = 'none';
    }
    
    function viewMessage(messageId) {
        // Mark as read via AJAX
        fetch(window.location.href, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=mark_read&message_id=' + messageId + '&csrf_token=<?php echo generate_csrf_token(); ?>'
        });
        
        location.reload();
    }
    
    // Close modal when clicking outside
    window.onclick = function(event) {
        const composeModal = document.getElementById('composeModal');
        if (event.target == composeModal) {
            closeComposeModal();
        }
    }
    </script>
    
    </div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
