<?php
// accountant/all-transactions.php - View All Transactions (Accountant)
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'School Transactions';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$user_id = $current_user['user_id'];
$accountant_school_id = $current_user['school_id'];

// Filter parameters
$date_from = isset($_GET['date_from']) ? sanitize_input($_GET['date_from']) : date('Y-m-01'); // First day of month
$date_to = isset($_GET['date_to']) ? sanitize_input($_GET['date_to']) : date('Y-m-d'); // Today
$payment_method = isset($_GET['payment_method']) ? sanitize_input($_GET['payment_method']) : '';

// Build query - always filter by accountant's school
$where_conditions = ["p.status IN ('paid', 'completed')", "s.school_id = ?"];
$params = [$accountant_school_id];

if ($date_from) {
    $where_conditions[] = "p.payment_date >= ?";
    $params[] = $date_from;
}

if ($date_to) {
    $where_conditions[] = "p.payment_date <= ?";
    $params[] = $date_to;
}

if ($payment_method) {
    $where_conditions[] = "p.payment_method = ?";
    $params[] = $payment_method;
}

$where_sql = implode(' AND ', $where_conditions);

// Get transactions
$stmt = $db->prepare("
    SELECT 
        p.*,
        s.admission_number,
        CONCAT(u.first_name, ' ', u.last_name) as student_name,
        c.class_name,
        sch.school_name
    FROM payments p
    INNER JOIN students s ON p.student_id = s.student_id
    INNER JOIN users u ON s.user_id = u.user_id
    LEFT JOIN classes c ON s.class_id = c.class_id
    INNER JOIN schools sch ON s.school_id = sch.school_id
    WHERE $where_sql
    ORDER BY p.payment_date DESC, p.created_at DESC
    LIMIT 500
");
$stmt->execute($params);
$transactions = $stmt->fetchAll();

// Calculate summary
$total_amount = array_sum(array_column($transactions, 'amount'));
$total_transactions = count($transactions);
$cash_total = array_sum(array_map(fn($t) => $t['payment_method'] == 'cash' ? $t['amount'] : 0, $transactions));
$online_total = array_sum(array_map(fn($t) => in_array($t['payment_method'], ['card', 'online', 'upi']) ? $t['amount'] : 0, $transactions));

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .transaction-row {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        padding: 15px;
        margin-bottom: 10px;
        border-radius: 8px;
        transition: all 0.2s;
    }
    
    .transaction-row:hover {
        box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    }
    
    .filter-box {
        background: var(--bg-card);
        padding: 20px;
        border-radius: 12px;
        margin-bottom: 25px;
    }
    
    .payment-method-badge {
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .method-cash { background: rgba(52, 199, 89, 0.1); color: #34C759; }
    .method-card { background: rgba(0, 122, 255, 0.1); color: #007AFF; }
    .method-online { background: rgba(88, 86, 214, 0.1); color: #5856D6; }
    .method-upi { background: rgba(255, 149, 0, 0.1); color: #FF9500; }
    .method-bank { background: rgba(52, 199, 89, 0.1); color: #34C759; }
    .method-cheque { background: rgba(255, 59, 48, 0.1); color: #FF3B30; }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-exchange-alt"></i> School Transactions</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> View all payment transactions for your school
        </p>
    </div>
    
    <!-- Summary Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 25px;">
        <div style="background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo number_format($total_transactions); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Transactions</p>
        </div>
        <div style="background: linear-gradient(135deg, #34C759, #30D158); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 28px;">GHS <?php echo number_format($total_amount, 2); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Amount</p>
        </div>
        <div style="background: linear-gradient(135deg, #5856D6, #5E5CE6); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 28px;">GHS <?php echo number_format($cash_total, 2); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Cash Payments</p>
        </div>
        <div style="background: linear-gradient(135deg, #007AFF, #0A84FF); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 28px;">GHS <?php echo number_format($online_total, 2); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Online Payments</p>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="filter-box">
        <form method="GET" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end;">
            <div class="form-group" style="margin: 0;">
                <label>From Date</label>
                <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>">
            </div>
            
            <div class="form-group" style="margin: 0;">
                <label>To Date</label>
                <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>">
            </div>
            
            <div class="form-group" style="margin: 0;">
                <label>Payment Method</label>
                <select name="payment_method">
                    <option value="">All Methods</option>
                    <option value="cash" <?php echo $payment_method == 'cash' ? 'selected' : ''; ?>>Cash</option>
                    <option value="card" <?php echo $payment_method == 'card' ? 'selected' : ''; ?>>Card</option>
                    <option value="online" <?php echo $payment_method == 'online' ? 'selected' : ''; ?>>Online</option>
                    <option value="upi" <?php echo $payment_method == 'upi' ? 'selected' : ''; ?>>UPI</option>
                    <option value="bank_transfer" <?php echo $payment_method == 'bank_transfer' ? 'selected' : ''; ?>>Bank Transfer</option>
                    <option value="cheque" <?php echo $payment_method == 'cheque' ? 'selected' : ''; ?>>Cheque</option>
                </select>
            </div>
            
            <div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-filter"></i> Filter
                </button>
                <a href="all-transactions.php" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Clear
                </a>
            </div>
        </form>
    </div>
    
    <!-- Transactions List -->
    <?php if (count($transactions) > 0): ?>
        <?php foreach ($transactions as $transaction): ?>
            <div class="transaction-row">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="flex: 1;">
                        <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 8px;">
                            <h4 style="margin: 0;">
                                <?php echo htmlspecialchars($transaction['student_name']); ?>
                            </h4>
                            <span class="payment-method-badge method-<?php echo $transaction['payment_method']; ?>">
                                <?php echo strtoupper(str_replace('_', ' ', $transaction['payment_method'])); ?>
                            </span>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; font-size: 13px; color: var(--text-secondary);">
                            <?php if (!empty($transaction['payment_reference'])): ?>
                            <div>
                                <i class="fas fa-receipt"></i> <strong>Reference:</strong> <?php echo htmlspecialchars($transaction['payment_reference']); ?>
                            </div>
                            <?php endif; ?>
                            <div>
                                <i class="fas fa-school"></i> <?php echo htmlspecialchars($transaction['school_name']); ?>
                            </div>
                            <div>
                                <i class="fas fa-graduation-cap"></i> <?php echo htmlspecialchars($transaction['class_name'] ?: 'N/A'); ?>
                            </div>
                            <div>
                                <i class="fas fa-calendar"></i> <?php echo date('M d, Y', strtotime($transaction['payment_date'])); ?>
                            </div>
                            <div>
                                <i class="fas fa-money-bill"></i> <?php echo ucfirst(str_replace('_', ' ', $transaction['payment_method'])); ?>
                            </div>
                            <div>
                                <i class="fas fa-hashtag"></i> ID: <?php echo $transaction['payment_id']; ?>
                            </div>
                        </div>
                        
                        <?php if ($transaction['remarks']): ?>
                            <div style="margin-top: 8px; padding: 8px; background: rgba(0,0,0,0.02); border-radius: 5px; font-size: 13px;">
                                <strong>Remarks:</strong> <?php echo htmlspecialchars($transaction['remarks']); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div style="text-align: right; margin-left: 20px;">
                        <div style="font-size: 24px; font-weight: 700; color: #34C759;">
                            GHS <?php echo number_format($transaction['amount'], 2); ?>
                        </div>
                        <div style="font-size: 11px; color: var(--text-secondary); margin-top: 5px;">
                            <?php echo date('h:i A', strtotime($transaction['created_at'])); ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        
        <div style="text-align: center; margin-top: 20px; color: var(--text-secondary);">
            Showing <?php echo count($transactions); ?> transactions
            <?php if (count($transactions) >= 500): ?>
                (Limited to 500 most recent)
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 60px; background: var(--bg-card); border-radius: 15px;">
            <i class="fas fa-exchange-alt" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
            <h3 style="color: var(--text-secondary);">No Transactions Found</h3>
            <p style="color: var(--text-secondary);">Try adjusting your filters</p>
        </div>
    <?php endif; ?>
    
    <!-- Export Options -->
    <div style="margin-top: 30px; text-align: center;">
        <button onclick="window.print()" class="btn btn-secondary">
            <i class="fas fa-print"></i> Print Report
        </button>
        <button onclick="exportToCSV()" class="btn btn-success">
            <i class="fas fa-file-csv"></i> Export to CSV
        </button>
    </div>
    
    <script>
    function exportToCSV() {
        // Simple CSV export
        alert('CSV export functionality - to be implemented with full transaction data');
    }
    </script>
    
    </div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
