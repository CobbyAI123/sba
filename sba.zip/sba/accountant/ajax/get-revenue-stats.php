<?php
// accountant/ajax/get-revenue-stats.php - Get Revenue Statistics via AJAX
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/config.php';

header('Content-Type: application/json');

// Check authentication
$current_user = check_permission(['accountant', 'admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get date filters from request
$start_date = sanitize_input($_GET['start_date'] ?? date('Y-m-01'));
$end_date = sanitize_input($_GET['end_date'] ?? date('Y-m-t'));

$response = [
    'success' => false,
    'data' => []
];

try {
    // Get total statistics
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total_transactions,
            COALESCE(SUM(amount), 0) as total_revenue,
            COALESCE(AVG(amount), 0) as average_payment
        FROM transactions
        WHERE school_id = ? AND status = 'completed'
        AND transaction_type = 'fee_payment'
        AND payment_date BETWEEN ? AND ?
    ");
    $stmt->execute([$school_id, $start_date, $end_date]);
    $stats = $stmt->fetch();

    // Get monthly revenue
    $stmt = $db->prepare("
        SELECT 
            DATE_FORMAT(payment_date, '%Y-%m') as month,
            DATE_FORMAT(payment_date, '%M %Y') as month_label,
            COUNT(*) as transaction_count,
            SUM(amount) as total_amount
        FROM transactions
        WHERE school_id = ? AND status = 'completed' 
        AND transaction_type = 'fee_payment'
        AND payment_date BETWEEN ? AND ?
        GROUP BY DATE_FORMAT(payment_date, '%Y-%m')
        ORDER BY payment_date DESC
    ");
    $stmt->execute([$school_id, $start_date, $end_date]);
    $monthly_revenue = $stmt->fetchAll();

    // Get payment methods breakdown
    $stmt = $db->prepare("
        SELECT 
            payment_method,
            COUNT(*) as count,
            SUM(amount) as total
        FROM transactions
        WHERE school_id = ? AND status = 'completed'
        AND transaction_type = 'fee_payment'
        AND payment_date BETWEEN ? AND ?
        GROUP BY payment_method
    ");
    $stmt->execute([$school_id, $start_date, $end_date]);
    $payment_methods = $stmt->fetchAll();

    // Get top payers
    $stmt = $db->prepare("
        SELECT 
            u.first_name,
            u.last_name,
            COUNT(t.transaction_id) as payment_count,
            SUM(t.amount) as total_paid
        FROM transactions t
        INNER JOIN students s ON t.student_id = s.student_id
        LEFT JOIN users u ON s.user_id = u.user_id
        WHERE t.school_id = ? AND t.status = 'completed'
        AND t.transaction_type = 'fee_payment'
        AND t.payment_date BETWEEN ? AND ?
        GROUP BY t.student_id
        ORDER BY total_paid DESC
        LIMIT 10
    ");
    $stmt->execute([$school_id, $start_date, $end_date]);
    $top_payers = $stmt->fetchAll();

    $response['success'] = true;
    $response['data'] = [
        'stats' => $stats,
        'monthly_revenue' => $monthly_revenue,
        'payment_methods' => $payment_methods,
        'top_payers' => $top_payers,
        'timestamp' => date('Y-m-d H:i:s')
    ];

} catch (PDOException $e) {
    $response['error'] = 'Database error occurred';
    error_log("Revenue Stats AJAX Error: " . $e->getMessage());
}

echo json_encode($response);
