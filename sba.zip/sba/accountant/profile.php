<?php
// accountant/profile.php - Accountant Profile
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'My Profile';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'update_profile') {
            $phone = sanitize_input($_POST['phone']);
            // Note: address field removed - users table doesn't have address column
            
            try {
                $stmt = $db->prepare("
                    UPDATE users 
                    SET phone = ?
                    WHERE user_id = ?
                ");
                $stmt->execute([$phone, $current_user['user_id']]);
                
                log_activity($current_user['user_id'], "Updated profile information", 'users', $current_user['user_id']);
                
                set_message('success', 'Profile updated successfully!');
                redirect(APP_URL . '/accountant/profile.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating profile: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'change_password') {
            $current_password = $_POST['current_password'];
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            if (!password_verify($current_password, $current_user['password_hash'])) {
                set_message('error', 'Current password is incorrect!');
            } elseif ($new_password !== $confirm_password) {
                set_message('error', 'New passwords do not match!');
            } elseif (strlen($new_password) < 6) {
                set_message('error', 'Password must be at least 6 characters!');
            } else {
                try {
                    $password_hash = password_hash($new_password, PASSWORD_BCRYPT);
                    $stmt = $db->prepare("UPDATE users SET password_hash = ? WHERE user_id = ?");
                    $stmt->execute([$password_hash, $current_user['user_id']]);
                    
                    log_activity($current_user['user_id'], "Changed password", 'users', $current_user['user_id']);
                    
                    set_message('success', 'Password changed successfully!');
                    redirect(APP_URL . '/accountant/profile.php');
                } catch (PDOException $e) {
                    set_message('error', 'Error changing password: ' . $e->getMessage());
                }
            }
        } elseif ($_POST['action'] == 'upload_avatar') {
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
                $allowed = ['jpg', 'jpeg', 'png', 'gif'];
                $filename = $_FILES['avatar']['name'];
                $filetype = pathinfo($filename, PATHINFO_EXTENSION);
                
                if (in_array(strtolower($filetype), $allowed)) {
                    $new_filename = 'avatar_' . $current_user['user_id'] . '_' . time() . '.' . $filetype;
                    $upload_path = AVATAR_PATH . $new_filename;
                    
                    if (!file_exists(AVATAR_PATH)) {
                        mkdir(AVATAR_PATH, 0777, true);
                    }
                    
                    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $upload_path)) {
                        if ($current_user['avatar'] && file_exists(AVATAR_PATH . $current_user['avatar'])) {
                            unlink(AVATAR_PATH . $current_user['avatar']);
                        }
                        
                        $stmt = $db->prepare("UPDATE users SET avatar = ? WHERE user_id = ?");
                        $stmt->execute([$new_filename, $current_user['user_id']]);
                        
                        log_activity($current_user['user_id'], "Updated profile picture", 'users', $current_user['user_id']);
                        
                        set_message('success', 'Profile picture updated successfully!');
                        redirect(APP_URL . '/accountant/profile.php');
                    } else {
                        set_message('error', 'Failed to upload file!');
                    }
                } else {
                    set_message('error', 'Invalid file type! Only JPG, JPEG, PNG, and GIF are allowed.');
                }
            } else {
                set_message('error', 'Please select a file to upload!');
            }
        }
    }
}

// Get fresh user data
$stmt = $db->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$current_user['user_id']]);
$user = $stmt->fetch();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .profile-container {
        display: grid;
        grid-template-columns: 300px 1fr;
        gap: 30px;
    }
    
    .profile-sidebar {
        background: var(--card-bg);
        border-radius: 15px;
        padding: 30px;
        text-align: center;
        height: fit-content;
    }
    
    .profile-avatar {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        background: linear-gradient(135deg, #2196F3, #9C27B0);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 48px;
        font-weight: 700;
        margin: 0 auto 20px;
    }
    
    .profile-name {
        font-size: 22px;
        font-weight: 600;
        margin-bottom: 5px;
    }
    
    .profile-role {
        color: var(--text-secondary);
        margin-bottom: 20px;
    }
    
    .profile-main {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }
    
    @media (max-width: 768px) {
        .profile-container {
            grid-template-columns: 1fr;
        }
    }
    </style>
    
    <!-- Page Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #9C27B0); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-user"></i> My Profile
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Manage your account information
            </p>
        </div>
    </div>
    
    <div class="profile-container">
        <!-- Sidebar -->
        <div class="profile-sidebar">
            <div class="profile-avatar" style="<?php if ($user['avatar']): ?>background: none; padding: 0;<?php endif; ?>">
                <?php if ($user['avatar']): ?>
                    <img src="<?php echo APP_URL . '/uploads/avatars/' . $user['avatar']; ?>" 
                         alt="Profile Picture" 
                         style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">
                <?php else: ?>
                    <?php echo strtoupper(substr($user['first_name'], 0, 1) . substr($user['last_name'], 0, 1)); ?>
                <?php endif; ?>
            </div>
            <form method="POST" enctype="multipart/form-data" id="avatarForm" style="margin-bottom: 15px;">
                <input type="hidden" name="action" value="upload_avatar">
                <input type="file" name="avatar" id="avatar" accept="image/*" style="display: none;" onchange="document.getElementById('avatarForm').submit()">
                <button type="button" onclick="document.getElementById('avatar').click()" class="btn btn-primary btn-sm">
                    <i class="fas fa-camera"></i> Change Photo
                </button>
            </form>
            <div class="profile-name"><?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?></div>
            <div class="profile-role"><?php echo ucfirst($user['role']); ?></div>
            <div style="padding-top: 20px; border-top: 1px solid var(--border-color); text-align: left;">
                <div style="margin-bottom: 15px;">
                    <i class="fas fa-envelope" style="color: var(--primary-blue); margin-right: 10px;"></i>
                    <span style="font-size: 14px;"><?php echo htmlspecialchars($user['email']); ?></span>
                </div>
                <div style="margin-bottom: 15px;">
                    <i class="fas fa-phone" style="color: var(--primary-blue); margin-right: 10px;"></i>
                    <span style="font-size: 14px;"><?php echo htmlspecialchars($user['phone'] ?? 'Not set'); ?></span>
                </div>
                <div>
                    <i class="fas fa-calendar" style="color: var(--primary-blue); margin-right: 10px;"></i>
                    <span style="font-size: 14px;">Joined <?php echo date('M Y', strtotime($user['created_at'])); ?></span>
                </div>
            </div>
        </div>
    
        <!-- Main Content -->
        <div class="profile-main">
            <!-- Update Profile -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-user-edit"></i> Update Profile</h3>
                </div>
                <form method="POST" style="padding: 20px;">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" value="<?php echo htmlspecialchars($user['first_name']); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" value="<?php echo htmlspecialchars($user['last_name']); ?>" disabled>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                    </div>
                    
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" placeholder="Enter phone number">
                    </div>
                    
                    <div class="form-group">
                        <label>Address</label>
                        <textarea name="address" rows="3" placeholder="Enter address"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Profile
                    </button>
                </form>
            </div>
    
            <!-- Change Password -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-lock"></i> Change Password</h3>
                </div>
                <form method="POST" style="padding: 20px;">
                    <input type="hidden" name="action" value="change_password">
                    
                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" name="current_password" required>
                    </div>
                    
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" required minlength="6">
                    </div>
                    
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" required minlength="6">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    </div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
