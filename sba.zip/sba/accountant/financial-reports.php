<?php
// accountant/financial-reports.php - Financial Reports
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Financial Reports';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get date range
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');

// Get summary data
$stmt = $db->prepare("
    SELECT 
        COUNT(DISTINCT p.payment_id) as total_transactions,
        COALESCE(SUM(p.amount), 0) as total_collected,
        COUNT(DISTINCT p.student_id) as students_paid,
        (SELECT COUNT(DISTINCT s.student_id) FROM students s WHERE s.school_id = ? AND s.status = 'active') as students_pending
    FROM payments p
    WHERE p.school_id = ?
");
$stmt->execute([$school_id, $school_id]);
$summary = $stmt->fetch();

// Get financial data with error handling
$financial_records = [];
try {
    $stmt = $db->prepare("
        SELECT 
            p.payment_id,
            p.created_at as transaction_date,
            CONCAT('Payment from ', u.first_name, ' ', u.last_name) as description,
            p.payment_type as category,
            p.amount,
            'credit' as type,
            p.payment_reference as reference_number,
            CONCAT(u.first_name, ' ', u.last_name) as recorded_by
        FROM payments p
        LEFT JOIN users u ON p.collected_by = u.user_id
        WHERE p.school_id = ?
        ORDER BY p.created_at DESC
        LIMIT 100
    ");
    $stmt->execute([$school_id]);
    $financial_records = $stmt->fetchAll();
} catch (PDOException $e) {
    // student_fees or other tables may not exist
    $financial_records = [];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-chart-line"></i> Financial Reports</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Comprehensive financial analysis and reports
        </p>
    </div>
    
    <!-- Summary Cards -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-bottom: 30px;">
        <div style="background: linear-gradient(135deg, #34C759, #30D158); color: white; padding: 25px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;">₹<?php echo number_format($summary['total_collected'], 2); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Collected</p>
        </div>
        <div style="background: linear-gradient(135deg, #007AFF, #0A84FF); color: white; padding: 25px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo number_format($summary['total_transactions']); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Transactions</p>
        </div>
        <div style="background: linear-gradient(135deg, #5856D6, #5E5CE6); color: white; padding: 25px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo number_format($summary['students_paid']); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Students Paid</p>
        </div>
        <div style="background: linear-gradient(135deg, #FF9500, #FF9F0A); color: white; padding: 25px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo number_format($summary['students_pending']); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Students Pending</p>
        </div>
    </div>
    
    <!-- Report Options -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
        <div style="background: var(--bg-card); padding: 25px; border-radius: 12px; border: 1px solid var(--border-color);">
            <i class="fas fa-calendar-day" style="font-size: 32px; color: var(--primary-blue); margin-bottom: 15px;"></i>
            <h3 style="margin: 0 0 10px 0;">Daily Collection</h3>
            <p style="color: var(--text-secondary); margin: 0 0 15px 0;">View day-wise collection reports</p>
            <a href="daily-collection.php" class="btn btn-primary">View Report</a>
        </div>
        
        <div style="background: var(--bg-card); padding: 25px; border-radius: 12px; border: 1px solid var(--border-color);">
            <i class="fas fa-calendar-week" style="font-size: 32px; color: var(--secondary-purple); margin-bottom: 15px;"></i>
            <h3 style="margin: 0 0 10px 0;">Monthly Report</h3>
            <p style="color: var(--text-secondary); margin: 0 0 15px 0;">Month-wise collection analysis</p>
            <a href="all-transactions.php" class="btn btn-primary">View Report</a>
        </div>
        
        <div style="background: var(--bg-card); padding: 25px; border-radius: 12px; border: 1px solid var(--border-color);">
            <i class="fas fa-users" style="font-size: 32px; color: #34C759; margin-bottom: 15px;"></i>
            <h3 style="margin: 0 0 10px 0;">Student-wise Report</h3>
            <p style="color: var(--text-secondary); margin: 0 0 15px 0;">Individual student fee status</p>
            <a href="student-fees.php" class="btn btn-primary">View Report</a>
        </div>
        
        <div style="background: var(--bg-card); padding: 25px; border-radius: 12px; border: 1px solid var(--border-color);">
            <i class="fas fa-graduation-cap" style="font-size: 32px; color: #FF9500; margin-bottom: 15px;"></i>
            <h3 style="margin: 0 0 10px 0;">Class-wise Report</h3>
            <p style="color: var(--text-secondary); margin: 0 0 15px 0;">Fee collection by class</p>
            <a href="class-receipts.php" class="btn btn-primary">View Report</a>
        </div>
        
        <div style="background: var(--bg-card); padding: 25px; border-radius: 12px; border: 1px solid var(--border-color);">
            <i class="fas fa-exclamation-triangle" style="font-size: 32px; color: #FF3B30; margin-bottom: 15px;"></i>
            <h3 style="margin: 0 0 10px 0;">Outstanding Fees</h3>
            <p style="color: var(--text-secondary); margin: 0 0 15px 0;">Pending fee payments</p>
            <a href="outstanding-fees.php" class="btn btn-primary">View Report</a>
        </div>
        
        <div style="background: var(--bg-card); padding: 25px; border-radius: 12px; border: 1px solid var(--border-color);">
            <i class="fas fa-receipt" style="font-size: 32px; color: #007AFF; margin-bottom: 15px;"></i>
            <h3 style="margin: 0 0 10px 0;">Receipt Register</h3>
            <p style="color: var(--text-secondary); margin: 0 0 15px 0;">All payment receipts</p>
            <a href="receipts.php" class="btn btn-primary">View Report</a>
        </div>
    </div>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
