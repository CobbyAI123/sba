<?php
// accountant/manage-staff.php - Manage Canteen and Bus Teachers/Staff
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/default-passwords.php';

$page_title = 'Manage Canteen & Bus Staff';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        // Verify CSRF token
        if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
            set_message('error', 'Invalid request. Please try again.');
            redirect(APP_URL . '/accountant/manage-staff.php');
            exit;
        }
        
        if ($_POST['action'] == 'add') {
            $username = sanitize_input($_POST['username']);
            $email = sanitize_input($_POST['email']);
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $phone = sanitize_input($_POST['phone']);
            $staff_type = sanitize_input($_POST['staff_type']); // canteen or bus
            
            // Use default password: teacher123
            $default_credentials = generate_default_credentials('teacher');
            $random_password = $default_credentials['password'];
            $password = $default_credentials['hash'];
            
            try {
                // Ensure unique username
                $original_username = $username;
                $counter = 1;
                while (true) {
                    $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE username = ? AND school_id = ?");
                    $check_stmt->execute([$username, $school_id]);
                    if ($check_stmt->fetch()['count'] == 0) {
                        break;
                    }
                    $username = $original_username . '_' . $counter;
                    $counter++;
                }
                
                // Ensure unique email
                $original_email = $email;
                $counter = 1;
                while (true) {
                    $check_stmt = $db->prepare("SELECT COUNT(*) as count FROM users WHERE email = ? AND school_id = ?");
                    $check_stmt->execute([$email, $school_id]);
                    if ($check_stmt->fetch()['count'] == 0) {
                        break;
                    }
                    $email_parts = explode('@', $original_email);
                    $email = $email_parts[0] . '_' . $counter . '@' . $email_parts[1];
                    $counter++;
                }
                
                $stmt = $db->prepare("
                    INSERT INTO users (school_id, username, email, password_hash, role, 
                                     first_name, last_name, phone, status)
                    VALUES (?, ?, ?, ?, 'teacher', ?, ?, ?, 'active')
                ");
                $stmt->execute([$school_id, $username, $email, $password, $first_name, $last_name, $phone]);
                
                $user_id = $db->lastInsertId();
                
                // Add staff type to a metadata table or use notes
                // For now, we'll track this through teacher_collections when they collect money
                
                log_activity($current_user['user_id'], "Added new $staff_type staff: $first_name $last_name", 'users', $user_id);
                
                set_message('success', "Staff member added successfully! Login - Username: $username, Password: $random_password (Please save this password)");
                redirect(APP_URL . '/accountant/manage-staff.php');
            } catch (PDOException $e) {
                set_message('error', 'Error adding staff: ' . $e->getMessage());
            }
            
        } elseif ($_POST['action'] == 'edit') {
            $user_id = sanitize_input($_POST['user_id']);
            $email = sanitize_input($_POST['email']);
            $first_name = sanitize_input($_POST['first_name']);
            $last_name = sanitize_input($_POST['last_name']);
            $phone = sanitize_input($_POST['phone']);
            $status = sanitize_input($_POST['status']);
            
            try {
                $stmt = $db->prepare("
                    UPDATE users 
                    SET email = ?, first_name = ?, last_name = ?, phone = ?, status = ?
                    WHERE user_id = ? AND school_id = ?
                ");
                $stmt->execute([$email, $first_name, $last_name, $phone, $status, $user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Updated staff: $first_name $last_name", 'users', $user_id);
                
                set_message('success', 'Staff member updated successfully!');
                redirect(APP_URL . '/accountant/manage-staff.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating staff: ' . $e->getMessage());
            }
            
        } elseif ($_POST['action'] == 'delete') {
            $user_id = sanitize_input($_POST['user_id']);
            
            try {
                $stmt = $db->prepare("DELETE FROM users WHERE user_id = ? AND school_id = ?");
                $stmt->execute([$user_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted staff ID: $user_id", 'users', $user_id);
                
                set_message('success', 'Staff member deleted successfully!');
                redirect(APP_URL . '/accountant/manage-staff.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting staff: ' . $e->getMessage());
            }
        }
    }
}

// Get all staff (teachers who handle canteen or bus)
// We'll show all teachers and staff, accountant can manage them
$staff = [];
try {
    $stmt = $db->prepare("
        SELECT u.*,
               GROUP_CONCAT(DISTINCT tc.collection_type) as staff_types,
               COALESCE(SUM(tc.amount), 0) as total_collected
        FROM users u
        LEFT JOIN teacher_collections tc ON u.user_id = tc.teacher_id
        WHERE u.school_id = ? 
        AND u.role IN ('teacher', 'accountant', 'librarian')
        GROUP BY u.user_id
        ORDER BY u.created_at DESC
    ");
    $stmt->execute([$school_id]);
    $staff = $stmt->fetchAll();
} catch (PDOException $e) {
    // teacher_collections table may not exist
    $stmt = $db->prepare("
        SELECT u.*
        FROM users u
        WHERE u.school_id = ? 
        AND u.role IN ('teacher', 'accountant', 'librarian')
        ORDER BY u.created_at DESC
    ");
    $stmt->execute([$school_id]);
    $staff = $stmt->fetchAll();
    foreach ($staff as &$member) {
        $member['staff_types'] = null;
        $member['total_collected'] = 0;
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Action Bar -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
            <button class="btn btn-primary" onclick="showAddModal()">
                <i class="fas fa-plus"></i> Add Staff Member
            </button>
        </div>
        <div>
            <a href="<?php echo APP_URL; ?>/accountant/collect-canteen-fees-teachers.php" class="btn btn-info">
                <i class="fas fa-utensils"></i> Collect Canteen Fees
            </a>
            <a href="<?php echo APP_URL; ?>/accountant/collect-transport-fees-teachers.php" class="btn btn-info">
                <i class="fas fa-bus"></i> Collect Bus Fees
            </a>
        </div>
    </div>
    
    <!-- Info Alert -->
    <div class="alert alert-info" style="margin-bottom: 20px;">
        <i class="fas fa-info-circle"></i>
        <strong>Manage Canteen & Bus Staff:</strong> Add, edit, or remove staff members who handle canteen and bus/transport services. These staff members can collect fees from students and teachers.
    </div>
    
    <!-- Staff Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-users"></i> Canteen & Bus Staff (<?php echo count($staff); ?>)</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Staff Name</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Role</th>
                        <th>Assigned To</th>
                        <th>Total Collected</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($staff) > 0): ?>
                        <?php foreach ($staff as $member): ?>
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 35px; height: 35px; border-radius: 8px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600;">
                                            <?php echo strtoupper(substr($member['first_name'], 0, 1) . substr($member['last_name'], 0, 1)); ?>
                                        </div>
                                        <span><?php echo $member['first_name'] . ' ' . $member['last_name']; ?></span>
                                    </div>
                                </td>
                                <td><strong><?php echo $member['username']; ?></strong></td>
                                <td><?php echo $member['email']; ?></td>
                                <td><?php echo $member['phone'] ?: 'N/A'; ?></td>
                                <td>
                                    <span class="badge badge-secondary">
                                        <?php echo ucfirst($member['role']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php 
                                    $types = $member['staff_types'] ? explode(',', $member['staff_types']) : [];
                                    if (empty($types) || !$member['staff_types']): ?>
                                        <span class="badge badge-secondary">Not assigned</span>
                                    <?php else: 
                                        foreach ($types as $type): 
                                            $badge_class = $type == 'canteen' ? 'success' : 'info';
                                            $icon = $type == 'canteen' ? 'utensils' : 'bus';
                                    ?>
                                        <span class="badge badge-<?php echo $badge_class; ?>" style="margin-right: 5px;">
                                            <i class="fas fa-<?php echo $icon; ?>"></i> <?php echo ucfirst($type); ?>
                                        </span>
                                    <?php 
                                        endforeach;
                                    endif; 
                                    ?>
                                </td>
                                <td>
                                    <strong style="color: var(--success-green);">
                                        ₦<?php echo number_format($member['total_collected'], 2); ?>
                                    </strong>
                                </td>
                                <td>
                                    <span class="badge badge-<?php 
                                        echo $member['status'] == 'active' ? 'success' : 
                                            ($member['status'] == 'suspended' ? 'warning' : 'danger'); 
                                    ?>">
                                        <?php echo ucfirst($member['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-info" onclick='editStaff(<?php echo json_encode($member); ?>)'>
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="deleteStaff(<?php echo $member['user_id']; ?>, '<?php echo addslashes($member['first_name'] . ' ' . $member['last_name']); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" style="text-align: center; padding: 60px;">
                                <i class="fas fa-users" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                                <h3 style="margin-bottom: 10px;">No Staff Members Yet</h3>
                                <p style="color: var(--text-secondary); margin-bottom: 20px;">Add staff members who will handle canteen and bus services</p>
                                <button class="btn btn-primary" onclick="showAddModal()">
                                    <i class="fas fa-plus"></i> Add Your First Staff Member
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Add/Edit Staff Modal -->
    <div id="staffModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Add Staff Member</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="staffForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="user_id" id="userId">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label for="first_name">First Name *</label>
                        <input type="text" name="first_name" id="first_name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="last_name">Last Name *</label>
                        <input type="text" name="last_name" id="last_name" required>
                    </div>
                </div>
                
                <div class="form-group" id="usernameGroup">
                    <label for="username">Username *</label>
                    <input type="text" name="username" id="username" required>
                    <small style="color: var(--text-secondary);">Will be used for login</small>
                </div>
                
                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" name="email" id="email" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="text" name="phone" id="phone">
                </div>
                
                <div class="form-group" id="staffTypeGroup">
                    <label for="staff_type">Assigned To *</label>
                    <select name="staff_type" id="staff_type" required>
                        <option value="">Select assignment...</option>
                        <option value="canteen">Canteen Services</option>
                        <option value="bus">Bus/Transport Services</option>
                    </select>
                    <small style="color: var(--text-secondary);">What service will this staff member handle?</small>
                </div>
                
                <div class="form-group" id="statusGroup" style="display: none;">
                    <label for="status">Status</label>
                    <select name="status" id="status">
                        <option value="active">Active</option>
                        <option value="suspended">Suspended</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </div>
                
                <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Staff Member
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
        <div style="max-width: 400px; margin: 100px auto; background: var(--bg-card); border-radius: 15px; padding: 30px; text-align: center;">
            <i class="fas fa-exclamation-triangle" style="font-size: 48px; color: var(--warning-orange); margin-bottom: 20px;"></i>
            <h3 style="margin-bottom: 10px;">Confirm Deletion</h3>
            <p id="deleteMessage" style="margin-bottom: 20px; color: var(--text-secondary);"></p>
            
            <form method="POST" id="deleteForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="user_id" id="deleteUserId">
                
                <div style="display: flex; gap: 10px; justify-content: center;">
                    <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showAddModal() {
        document.getElementById('modalTitle').textContent = 'Add Staff Member';
        document.getElementById('formAction').value = 'add';
        document.getElementById('staffForm').reset();
        document.getElementById('userId').value = '';
        document.getElementById('usernameGroup').style.display = 'block';
        document.getElementById('staffTypeGroup').style.display = 'block';
        document.getElementById('statusGroup').style.display = 'none';
        document.getElementById('staffModal').style.display = 'block';
    }
    
    function editStaff(staff) {
        document.getElementById('modalTitle').textContent = 'Edit Staff Member';
        document.getElementById('formAction').value = 'edit';
        document.getElementById('userId').value = staff.user_id;
        document.getElementById('first_name').value = staff.first_name;
        document.getElementById('last_name').value = staff.last_name;
        document.getElementById('email').value = staff.email;
        document.getElementById('phone').value = staff.phone || '';
        document.getElementById('status').value = staff.status;
        document.getElementById('usernameGroup').style.display = 'none';
        document.getElementById('staffTypeGroup').style.display = 'none';
        document.getElementById('statusGroup').style.display = 'block';
        document.getElementById('staffModal').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('staffModal').style.display = 'none';
    }
    
    function deleteStaff(userId, name) {
        document.getElementById('deleteMessage').textContent = 'Are you sure you want to delete ' + name + '? This action cannot be undone.';
        document.getElementById('deleteUserId').value = userId;
        document.getElementById('deleteModal').style.display = 'block';
    }
    
    function closeDeleteModal() {
        document.getElementById('deleteModal').style.display = 'none';
    }
    
    // Close modals when clicking outside
    window.onclick = function(event) {
        const staffModal = document.getElementById('staffModal');
        const deleteModal = document.getElementById('deleteModal');
        
        if (event.target == staffModal) {
            closeModal();
        }
        if (event.target == deleteModal) {
            closeDeleteModal();
        }
    }
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
