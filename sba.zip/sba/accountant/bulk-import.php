<?php
// accountant/bulk-import.php - Bulk Payment Import System
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Bulk Payment Import';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

$import_result = null;
$errors = [];

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['import_file'])) {
    $file = $_FILES['import_file'];
    
    // Validate file
    if ($file['error'] === UPLOAD_ERR_OK) {
        $filename = $file['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        // Check file type
        if (!in_array($ext, ['csv', 'xlsx', 'xls'])) {
            $errors[] = 'Invalid file type. Please upload CSV or Excel file.';
        } else {
            // Process file
            $result = processPaymentImport($file['tmp_name'], $ext, $school_id, $db);
            $import_result = $result;
        }
    } else {
        $errors[] = 'Error uploading file. Please try again.';
    }
}

/**
 * Process payment import file
 */
function processPaymentImport($file_path, $ext, $school_id, $db) {
    $payments = [];
    $import_errors = [];
    $row_num = 0;
    
    if ($ext === 'csv') {
        // Parse CSV
        if (($handle = fopen($file_path, 'r')) !== false) {
            // Skip header
            fgetcsv($handle);
            $row_num = 1;
            
            while (($data = fgetcsv($handle)) !== false) {
                $row_num++;
                
                if (count($data) < 2) {
                    continue;
                }
                
                $admission_number = trim($data[0]);
                $amount = (float)$data[1];
                $payment_date = isset($data[2]) ? trim($data[2]) : date('Y-m-d');
                $payment_method = isset($data[3]) ? trim($data[3]) : 'cash';
                $notes = isset($data[4]) ? trim($data[4]) : '';
                
                // Validate data
                if (empty($admission_number) || $amount <= 0) {
                    $import_errors[] = "Row $row_num: Invalid admission number or amount";
                    continue;
                }
                
                // Find student
                try {
                    $stmt = $db->prepare("
                        SELECT s.student_id, CONCAT(u.first_name, ' ', u.last_name) as student_name
                        FROM students s
                        INNER JOIN users u ON s.user_id = u.user_id
                        WHERE s.school_id = ? AND s.admission_number = ?
                    ");
                    $stmt->execute([$school_id, $admission_number]);
                    $student = $stmt->fetch();
                    
                    if (!$student) {
                        $import_errors[] = "Row $row_num: Student with admission number '$admission_number' not found";
                        continue;
                    }
                    
                    $payments[] = [
                        'student_id' => $student['student_id'],
                        'student_name' => $student['student_name'],
                        'admission_number' => $admission_number,
                        'amount' => $amount,
                        'payment_date' => $payment_date,
                        'payment_method' => $payment_method,
                        'notes' => $notes,
                        'row_num' => $row_num
                    ];
                } catch (PDOException $e) {
                    $import_errors[] = "Row $row_num: Database error - " . $e->getMessage();
                }
            }
            fclose($handle);
        }
    } else {
        // Handle Excel files - use simple CSV parsing for now
        $import_errors[] = "Excel support coming soon. Please use CSV format.";
    }
    
    // Process validated payments
    $successful = 0;
    $failed = 0;
    $failed_details = [];
    
    foreach ($payments as $payment) {
        try {
            $stmt = $db->prepare("
                INSERT INTO payments 
                (student_id, amount, payment_date, reference, notes, status, created_by, school_id)
                VALUES (?, ?, ?, ?, ?, 'paid', ?, ?)
            ");
            
            $stmt->execute([
                $payment['student_id'],
                $payment['amount'],
                $payment['payment_date'],
                $payment['payment_method'],
                $payment['notes'],
                $current_user['user_id'],
                $school_id
            ]);
            
            $successful++;
            
            // Send notification
            try {
                require_once BASE_PATH . '/includes/NotificationManager.php';
                $notifier = new NotificationManager($school_id);
                $notifier->notifyPaymentReceived(
                    $db->lastInsertId(),
                    $payment['amount'],
                    $payment['student_name'],
                    $payment['admission_number']
                );
            } catch (Exception $e) {
                // Notification failed, but payment was recorded
            }
        } catch (PDOException $e) {
            $failed++;
            $failed_details[] = "Row {$payment['row_num']}: {$payment['student_name']} - " . $e->getMessage();
        }
    }
    
    return [
        'success' => $successful > 0,
        'successful' => $successful,
        'failed' => $failed,
        'total_validated' => count($payments),
        'import_errors' => $import_errors,
        'processing_errors' => $failed_details,
        'total_amount' => array_sum(array_column($payments, 'amount'))
    ];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
        .import-container {
            max-width: 900px;
            margin: 0 auto;
        }
        
        .upload-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 15px;
            padding: 40px;
            color: white;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .upload-section h2 {
            margin: 0 0 10px 0;
            font-size: 24px;
        }
        
        .upload-section p {
            margin: 0 0 20px 0;
            opacity: 0.9;
        }
        
        .drop-zone {
            border: 2px dashed rgba(255, 255, 255, 0.5);
            border-radius: 10px;
            padding: 40px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.1);
        }
        
        .drop-zone:hover {
            border-color: white;
            background: rgba(255, 255, 255, 0.15);
        }
        
        .drop-zone.dragover {
            border-color: white;
            background: rgba(255, 255, 255, 0.2);
            transform: scale(1.02);
        }
        
        .drop-zone i {
            font-size: 48px;
            margin-bottom: 15px;
            display: block;
            opacity: 0.9;
        }
        
        #file-input {
            display: none;
        }
        
        .file-info {
            margin-top: 20px;
            padding: 15px;
            background: rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            display: none;
        }
        
        .file-info.active {
            display: block;
        }
        
        .file-name {
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .preview-section {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            display: none;
        }
        
        .preview-section.active {
            display: block;
        }
        
        .preview-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }
        
        .preview-table th {
            background: #f5f5f5;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #e0e0e0;
        }
        
        .preview-table td {
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .preview-table tbody tr:hover {
            background: #f9f9f9;
        }
        
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .badge-success {
            background: #D1FAE5;
            color: #10B981;
        }
        
        .badge-error {
            background: #FEE2E2;
            color: #EF4444;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }
        
        .btn-import {
            flex: 1;
            padding: 12px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 15px;
            transition: all 0.3s ease;
        }
        
        .btn-import:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }
        
        .btn-import:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none;
        }
        
        .btn-reset {
            padding: 12px 20px;
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 15px;
            transition: all 0.3s ease;
        }
        
        .btn-reset:hover {
            background: #f5f5f5;
        }
        
        .template-section {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
        }
        
        .template-section h3 {
            margin: 0 0 15px 0;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .template-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            background: #f9f9f9;
            margin-bottom: 15px;
        }
        
        .template-table th,
        .template-table td {
            padding: 10px 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .template-table th {
            background: #667eea;
            color: white;
            font-weight: 600;
        }
        
        .template-table tbody tr:nth-child(odd) {
            background: white;
        }
        
        .result-section {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-top: 25px;
            display: none;
        }
        
        .result-section.active {
            display: block;
        }
        
        .result-header {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        
        .result-stat {
            padding: 15px;
            border-radius: 10px;
            text-align: center;
        }
        
        .result-stat.success {
            background: #D1FAE5;
            border: 2px solid #10B981;
        }
        
        .result-stat.error {
            background: #FEE2E2;
            border: 2px solid #EF4444;
        }
        
        .result-stat.info {
            background: #DBEAFE;
            border: 2px solid #3B82F6;
        }
        
        .result-stat h4 {
            margin: 0 0 5px 0;
            font-size: 28px;
            font-weight: 700;
        }
        
        .result-stat p {
            margin: 0;
            font-size: 13px;
            font-weight: 600;
            opacity: 0.8;
        }
        
        .error-list {
            background: #FFEBEE;
            border: 1px solid #EF5350;
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
        }
        
        .error-list h4 {
            margin: 0 0 10px 0;
            color: #EF4444;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .error-item {
            padding: 8px 0;
            color: #C62828;
            font-size: 13px;
            border-bottom: 1px solid rgba(239, 67, 67, 0.2);
        }
        
        .error-item:last-child {
            border-bottom: none;
        }
        
        .features-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .feature-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            border-left: 4px solid #667eea;
        }
        
        .feature-card h4 {
            margin: 0 0 8px 0;
            color: #333;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .feature-card p {
            margin: 0;
            font-size: 13px;
            color: #666;
            line-height: 1.5;
        }
    </style>
    
    <!-- Main Content -->
    <div class="import-container">
        
        <!-- Upload Section -->
        <div class="upload-section">
            <h2><i class="fas fa-cloud-upload-alt"></i> Bulk Payment Import</h2>
            <p>Upload CSV or Excel file to import multiple payments at once</p>
            
            <form id="importForm" enctype="multipart/form-data" method="POST">
                <div class="drop-zone" id="dropZone" onclick="document.getElementById('file-input').click()">
                    <i class="fas fa-file-excel"></i>
                    <div><strong>Drag & drop file here</strong></div>
                    <div style="opacity: 0.8; margin-top: 5px;">or click to select</div>
                </div>
                
                <input type="file" id="file-input" name="import_file" accept=".csv,.xlsx,.xls">
                
                <div class="file-info" id="fileInfo">
                    <div class="file-name">📄 <span id="fileName"></span></div>
                    <div style="font-size: 13px; opacity: 0.9;">Ready to preview</div>
                </div>
            </form>
        </div>
        
        <!-- Template Section -->
        <div class="template-section">
            <h3>
                <i class="fas fa-book"></i> CSV Template Format
            </h3>
            <p style="margin: 0 0 15px 0; color: #666; font-size: 13px;">
                Use this format for your CSV file. Column A and B are required, others are optional.
            </p>
            
            <table class="template-table">
                <thead>
                    <tr>
                        <th>Admission Number *</th>
                        <th>Amount *</th>
                        <th>Payment Date</th>
                        <th>Payment Method</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>AD001</td>
                        <td>500.00</td>
                        <td>2025-11-28</td>
                        <td>cash</td>
                        <td>Tuition fee November</td>
                    </tr>
                    <tr>
                        <td>AD002</td>
                        <td>300.00</td>
                        <td>2025-11-28</td>
                        <td>bank_transfer</td>
                        <td>Bus fare</td>
                    </tr>
                    <tr>
                        <td>AD003</td>
                        <td>1000.00</td>
                        <td>2025-11-28</td>
                        <td>cheque</td>
                        <td>Full term fee</td>
                    </tr>
                </tbody>
            </table>
            
            <a href="<?php echo APP_URL; ?>/includes/templates/payment-import-template.csv" download class="btn btn-sm" style="background: #667eea; color: white; text-decoration: none; padding: 10px 20px; border-radius: 6px; display: inline-flex; align-items: center; gap: 8px; font-weight: 600;">
                <i class="fas fa-download"></i> Download CSV Template
            </a>
        </div>
        
        <!-- Features Section -->
        <div class="features-section">
            <div class="feature-card">
                <h4><i class="fas fa-check-circle" style="color: #10B981;"></i> Bulk Processing</h4>
                <p>Import 100+ payments in seconds instead of entering them one by one</p>
            </div>
            <div class="feature-card">
                <h4><i class="fas fa-eye" style="color: #3B82F6;"></i> Preview First</h4>
                <p>See all data before importing. Verify amounts and student names</p>
            </div>
            <div class="feature-card">
                <h4><i class="fas fa-bell" style="color: #F59E0B;"></i> Auto Notifications</h4>
                <p>Automatic payment received notifications for each import</p>
            </div>
            <div class="feature-card">
                <h4><i class="fas fa-times-circle" style="color: #EF4444;"></i> Error Handling</h4>
                <p>Invalid rows are skipped with detailed error messages</p>
            </div>
        </div>
        
        <!-- Preview Section -->
        <div class="preview-section" id="previewSection">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h3 style="margin: 0; font-size: 18px;">Import Preview</h3>
                <span id="previewCount" style="background: #667eea; color: white; padding: 5px 15px; border-radius: 20px; font-size: 12px; font-weight: 600;"></span>
            </div>
            
            <table class="preview-table">
                <thead>
                    <tr>
                        <th>Status</th>
                        <th>Admission #</th>
                        <th>Student Name</th>
                        <th>Amount</th>
                        <th>Payment Date</th>
                        <th>Method</th>
                    </tr>
                </thead>
                <tbody id="previewTableBody">
                </tbody>
            </table>
            
            <div class="action-buttons">
                <button type="button" class="btn-import" onclick="confirmImport()">
                    <i class="fas fa-check"></i> Confirm Import
                </button>
                <button type="button" class="btn-reset" onclick="resetImport()">
                    <i class="fas fa-redo"></i> Choose Another File
                </button>
            </div>
        </div>
        
        <!-- Results Section -->
        <?php if ($import_result): ?>
        <div class="result-section active">
            <h3 style="margin: 0 0 20px 0; font-size: 18px; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-<?php echo $import_result['success'] ? 'check-circle' : 'exclamation-circle'; ?>" style="color: <?php echo $import_result['success'] ? '#10B981' : '#EF4444'; ?>;"></i>
                Import Result
            </h3>
            
            <div class="result-header">
                <div class="result-stat success">
                    <h4><?php echo $import_result['successful']; ?></h4>
                    <p>Successful</p>
                </div>
                <div class="result-stat error">
                    <h4><?php echo $import_result['failed']; ?></h4>
                    <p>Failed</p>
                </div>
                <div class="result-stat info">
                    <h4><?php echo format_currency($import_result['total_amount']); ?></h4>
                    <p>Total Amount</p>
                </div>
            </div>
            
            <?php if (!empty($import_result['import_errors'])): ?>
            <div class="error-list">
                <h4><i class="fas fa-exclamation-circle"></i> Validation Errors</h4>
                <?php foreach ($import_result['import_errors'] as $error): ?>
                    <div class="error-item"><?php echo htmlspecialchars($error); ?></div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($import_result['processing_errors'])): ?>
            <div class="error-list" style="margin-top: 15px;">
                <h4><i class="fas fa-database"></i> Processing Errors</h4>
                <?php foreach ($import_result['processing_errors'] as $error): ?>
                    <div class="error-item"><?php echo htmlspecialchars($error); ?></div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            
            <div style="margin-top: 25px; padding: 15px; background: #D1FAE5; border-radius: 8px; border-left: 4px solid #10B981;">
                <p style="margin: 0; color: #10B981; font-weight: 600;">
                    <i class="fas fa-check-circle"></i> <?php echo $import_result['successful']; ?> payments successfully imported!
                </p>
                <p style="margin: 10px 0 0 0; font-size: 13px; color: #047857;">
                    All imported payments are now in the system and students have been notified.
                </p>
            </div>
            
            <div style="margin-top: 20px; display: flex; gap: 10px;">
                <a href="<?php echo APP_URL; ?>/accountant/payments.php" class="btn btn-sm" style="background: #667eea; color: white; text-decoration: none; padding: 10px 20px; border-radius: 6px; font-weight: 600;">
                    <i class="fas fa-list"></i> View All Payments
                </a>
                <button onclick="location.reload()" class="btn btn-sm" style="background: white; color: #667eea; border: 2px solid #667eea; text-decoration: none; padding: 10px 20px; border-radius: 6px; font-weight: 600; cursor: pointer;">
                    <i class="fas fa-plus"></i> Import More
                </button>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Display any errors -->
        <?php if (!empty($errors)): ?>
        <div style="background: #FFEBEE; border: 1px solid #EF5350; border-radius: 8px; padding: 15px; margin-top: 20px;">
            <h4 style="margin: 0 0 10px 0; color: #EF4444; display: flex; align-items: center; gap: 8px;">
                <i class="fas fa-exclamation-circle"></i> Import Error
            </h4>
            <?php foreach ($errors as $error): ?>
                <div style="padding: 5px 0; color: #C62828; font-size: 13px;"><?php echo htmlspecialchars($error); ?></div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        
    </div>
    
    <script>
    // File handling
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('file-input');
    const fileInfo = document.getElementById('fileInfo');
    const previewSection = document.getElementById('previewSection');
    
    // Drag and drop
    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });
    
    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });
    
    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            fileInput.files = files;
            handleFileSelect();
        }
    });
    
    fileInput.addEventListener('change', handleFileSelect);
    
    function handleFileSelect() {
        const file = fileInput.files[0];
        if (!file) return;
        
        const filename = file.name;
        const ext = filename.split('.').pop().toLowerCase();
        
        if (!['csv', 'xlsx', 'xls'].includes(ext)) {
            alert('Please select a CSV or Excel file');
            fileInput.value = '';
            return;
        }
        
        document.getElementById('fileName').textContent = filename;
        fileInfo.classList.add('active');
        
        // Read and preview CSV
        if (ext === 'csv') {
            const reader = new FileReader();
            reader.onload = (e) => {
                previewCSV(e.target.result);
            };
            reader.readAsText(file);
        } else {
            alert('Excel support coming soon. Please use CSV format.');
            fileInput.value = '';
            fileInfo.classList.remove('active');
        }
    }
    
    function previewCSV(content) {
        const lines = content.split('\n').filter(line => line.trim());
        const headers = lines[0].split(',');
        
        let validCount = 0;
        let html = '';
        
        for (let i = 1; i < lines.length; i++) {
            const values = lines[i].split(',').map(v => v.trim());
            
            if (values.length < 2 || !values[0] || !values[1]) continue;
            
            const admission = values[0];
            const amount = parseFloat(values[1]);
            const date = values[2] || new Date().toISOString().split('T')[0];
            const method = values[3] || 'cash';
            
            if (isNaN(amount) || amount <= 0) {
                html += `
                    <tr>
                        <td><span class="status-badge badge-error">Error</span></td>
                        <td>${escapeHtml(admission)}</td>
                        <td colspan="4" style="color: #EF4444; font-size: 12px;">Invalid amount</td>
                    </tr>
                `;
            } else {
                validCount++;
                html += `
                    <tr>
                        <td><span class="status-badge badge-success">Valid</span></td>
                        <td>${escapeHtml(admission)}</td>
                        <td><em>Loading...</em></td>
                        <td>₵${amount.toFixed(2)}</td>
                        <td>${escapeHtml(date)}</td>
                        <td>${escapeHtml(method)}</td>
                    </tr>
                `;
            }
        }
        
        document.getElementById('previewTableBody').innerHTML = html;
        document.getElementById('previewCount').textContent = validCount + ' records';
        previewSection.classList.add('active');
    }
    
    function confirmImport() {
        if (confirm('Are you sure? This will import all valid payments.')) {
            document.getElementById('importForm').submit();
        }
    }
    
    function resetImport() {
        fileInput.value = '';
        fileInfo.classList.remove('active');
        previewSection.classList.remove('active');
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    </script>
    
    </div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
