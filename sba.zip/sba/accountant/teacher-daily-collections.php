<?php
// accountant/teacher-daily-collections.php - Verify Teacher Daily Collections
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Teacher Daily Collections';
$current_user = check_permission(['accountant', 'admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get selected date (default: today)
$selected_date = isset($_GET['date']) ? sanitize_input($_GET['date']) : date('Y-m-d');
$selected_teacher = isset($_GET['teacher_id']) ? intval($_GET['teacher_id']) : 'all';

// Handle payment verification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'verify_payment') {
    $teacher_id = intval($_POST['teacher_id']);
    $collection_date = sanitize_input($_POST['collection_date']);
    $amount_paid = floatval($_POST['amount_paid']);
    $payment_method = sanitize_input($_POST['payment_method']);
    $notes = sanitize_input($_POST['notes'] ?? '');
    
    try {
        $stmt = $db->prepare("
            INSERT INTO teacher_collection_payments 
            (school_id, teacher_id, collection_date, amount_paid, payment_method, 
             notes, verified_by, verified_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $school_id, $teacher_id, $collection_date, $amount_paid, 
            $payment_method, $notes, $current_user['user_id']
        ]);
        
        set_message('success', 'Payment verified and recorded successfully!');
        redirect(APP_URL . "/accountant/teacher-daily-collections.php?date=$collection_date");
    } catch (PDOException $e) {
        set_message('error', 'Error recording payment: ' . $e->getMessage());
    }
}

// Get all teachers who made collections on selected date
$stmt = $db->prepare("
    SELECT DISTINCT
        u.user_id as teacher_id,
        u.first_name,
        u.last_name,
        c.class_name
    FROM daily_collections dc
    INNER JOIN users u ON dc.marked_by = u.user_id
    LEFT JOIN class_teachers ct ON u.user_id = ct.teacher_id AND ct.is_primary = 1
    LEFT JOIN classes c ON ct.class_id = c.class_id
    WHERE dc.school_id = ?
    AND dc.collection_date = ?
    ORDER BY u.first_name, u.last_name
");
$stmt->execute([$school_id, $selected_date]);
$teachers_with_collections = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get detailed collection data for each teacher
$collection_data = [];

foreach ($teachers_with_collections as $teacher) {
    $teacher_id = $teacher['teacher_id'];
    
    // Get the class(es) this teacher collected from
    $stmt = $db->prepare("
        SELECT DISTINCT c.class_id, c.class_name
        FROM daily_collections dc
        INNER JOIN classes c ON dc.class_id = c.class_id
        WHERE dc.marked_by = ?
        AND dc.collection_date = ?
        AND dc.school_id = ?
    ");
    $stmt->execute([$teacher_id, $selected_date, $school_id]);
    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($classes as $class) {
        $class_id = $class['class_id'];
        
        // Get attendance summary for this class on this date
        $stmt = $db->prepare("
            SELECT 
                COUNT(CASE WHEN a.status = 'present' THEN 1 END) as total_present,
                COUNT(CASE WHEN a.status = 'absent' THEN 1 END) as total_absent,
                COUNT(CASE WHEN a.status = 'late' THEN 1 END) as total_late
            FROM attendance a
            WHERE a.class_id = ?
            AND a.date = ?
            AND a.school_id = ?
        ");
        $stmt->execute([$class_id, $selected_date, $school_id]);
        $attendance = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get students on weekly/monthly plans (excluded from daily collection)
        $stmt = $db->prepare("
            SELECT 
                COUNT(CASE WHEN s.canteen_fee_type IN ('weekly', 'monthly') THEN 1 END) as canteen_prepaid,
                COUNT(CASE WHEN s.bus_fee_type IN ('weekly', 'monthly') THEN 1 END) as bus_prepaid
            FROM students s
            INNER JOIN attendance a ON s.student_id = a.student_id
            WHERE s.class_id = ?
            AND a.date = ?
            AND a.status = 'present'
            AND s.school_id = ?
        ");
        $stmt->execute([$class_id, $selected_date, $school_id]);
        $prepaid = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get actual collections made by this teacher
        $stmt = $db->prepare("
            SELECT 
                COUNT(CASE WHEN dc.canteen_paid = 1 THEN 1 END) as canteen_count,
                SUM(CASE WHEN dc.canteen_paid = 1 THEN dc.canteen_amount ELSE 0 END) as canteen_total,
                COUNT(CASE WHEN dc.bus_paid = 1 THEN 1 END) as bus_count,
                SUM(CASE WHEN dc.bus_paid = 1 THEN dc.bus_amount ELSE 0 END) as bus_total
            FROM daily_collections dc
            WHERE dc.marked_by = ?
            AND dc.class_id = ?
            AND dc.collection_date = ?
            AND dc.school_id = ?
        ");
        $stmt->execute([$teacher_id, $class_id, $selected_date, $school_id]);
        $collections = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Check if payment has been verified
        $stmt = $db->prepare("
            SELECT * FROM teacher_collection_payments
            WHERE teacher_id = ?
            AND collection_date = ?
            AND school_id = ?
        ");
        $stmt->execute([$teacher_id, $selected_date, $school_id]);
        $payment_verified = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $grand_total = ($collections['canteen_total'] ?? 0) + ($collections['bus_total'] ?? 0);
        
        $collection_data[] = [
            'teacher_id' => $teacher_id,
            'teacher_name' => $teacher['first_name'] . ' ' . $teacher['last_name'],
            'class_id' => $class_id,
            'class_name' => $class['class_name'],
            'attendance' => $attendance,
            'prepaid' => $prepaid,
            'collections' => $collections,
            'grand_total' => $grand_total,
            'payment_verified' => $payment_verified
        ];
    }
}

require_once BASE_PATH . '/includes/header.php';
?>

<style>
.summary-card {
    background: var(--bg-card);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: var(--shadow-md);
}
.summary-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin-top: 15px;
}
.stat-box {
    text-align: center;
    padding: 15px;
    border-radius: 8px;
    background: var(--bg-secondary);
}
.stat-box.present { border-left: 4px solid #10B981; }
.stat-box.absent { border-left: 4px solid #EF4444; }
.stat-box.prepaid { border-left: 4px solid #2196F3; }
.stat-box.collected { border-left: 4px solid #F59E0B; }
.stat-number {
    font-size: 28px;
    font-weight: bold;
    color: var(--text-primary);
    margin: 5px 0;
}
.stat-label {
    font-size: 12px;
    color: var(--text-secondary);
    text-transform: uppercase;
}
.collection-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
.collection-table th {
    background: var(--primary-blue);
    color: white;
    padding: 12px;
    text-align: left;
    font-weight: 600;
}
.collection-table td {
    padding: 12px;
    border-bottom: 1px solid var(--border-color);
}
.collection-table tr:hover {
    background: var(--bg-hover);
}
.amount-display {
    font-size: 20px;
    font-weight: bold;
    color: #10B981;
}
.verified-badge {
    background: #10B981;
    color: white;
    padding: 5px 15px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}
.pending-badge {
    background: #F59E0B;
    color: white;
    padding: 5px 15px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
}
.modal-content {
    background: var(--bg-card);
    margin: 5% auto;
    padding: 30px;
    border-radius: 15px;
    width: 90%;
    max-width: 600px;
    box-shadow: var(--shadow-lg);
}
</style>

<!-- Page Header -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <div>
        <h2><i class="fas fa-hand-holding-usd"></i> Teacher Daily Collections Verification</h2>
        <p style="color: var(--text-secondary); margin: 5px 0 0 0;">
            Verify and record teacher payments for daily collections
        </p>
    </div>
</div>

<!-- Date Filter -->
<div class="card" style="margin-bottom: 20px;">
    <div class="card-header">
        <h3><i class="fas fa-calendar-alt"></i> Select Date</h3>
    </div>
    <div style="padding: 20px;">
        <form method="GET" style="display: flex; gap: 15px; align-items: end;">
            <div class="form-group" style="margin: 0; flex: 1;">
                <label>Collection Date</label>
                <input type="date" name="date" value="<?php echo $selected_date; ?>" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-search"></i> Load Collections
            </button>
            <a href="?date=<?php echo date('Y-m-d'); ?>" class="btn btn-secondary">
                <i class="fas fa-calendar-day"></i> Today
            </a>
        </form>
    </div>
</div>

<?php if (empty($collection_data)): ?>
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i>
        <strong>No Collections Found</strong> - No teachers made collections on <?php echo date('F d, Y', strtotime($selected_date)); ?>.
    </div>
<?php else: ?>

    <!-- Summary Statistics -->
    <div class="summary-card">
        <h3><i class="fas fa-chart-bar"></i> Daily Summary - <?php echo date('F d, Y', strtotime($selected_date)); ?></h3>
        
        <?php
        $total_canteen = 0;
        $total_bus = 0;
        $total_grand = 0;
        $total_verified = 0;
        $total_pending = 0;
        
        foreach ($collection_data as $data) {
            $total_canteen += $data['collections']['canteen_total'] ?? 0;
            $total_bus += $data['collections']['bus_total'] ?? 0;
            $total_grand += $data['grand_total'];
            
            if ($data['payment_verified']) {
                $total_verified++;
            } else {
                $total_pending++;
            }
        }
        ?>
        
        <div class="summary-grid">
            <div class="stat-box collected">
                <div class="stat-label">Total Canteen</div>
                <div class="stat-number"><?php echo format_currency($total_canteen); ?></div>
            </div>
            <div class="stat-box collected">
                <div class="stat-label">Total Bus</div>
                <div class="stat-number"><?php echo format_currency($total_bus); ?></div>
            </div>
            <div class="stat-box">
                <div class="stat-label">Grand Total</div>
                <div class="stat-number" style="color: #10B981;"><?php echo format_currency($total_grand); ?></div>
            </div>
            <div class="stat-box present">
                <div class="stat-label">Verified</div>
                <div class="stat-number"><?php echo $total_verified; ?> / <?php echo count($collection_data); ?></div>
            </div>
        </div>
    </div>

    <!-- Teacher Collections Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-users"></i> Teacher Collection Details</h3>
        </div>
        <div class="table-responsive">
            <table class="collection-table">
                <thead>
                    <tr>
                        <th>Teacher</th>
                        <th>Class</th>
                        <th>Present</th>
                        <th>Absent</th>
                        <th>Prepaid (Excluded)</th>
                        <th>Canteen Collected</th>
                        <th>Bus Collected</th>
                        <th>Total Amount</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($collection_data as $data): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($data['teacher_name']); ?></strong>
                            </td>
                            <td><?php echo htmlspecialchars($data['class_name']); ?></td>
                            <td>
                                <span class="stat-box present" style="display: inline-block; padding: 5px 10px;">
                                    <strong><?php echo $data['attendance']['total_present'] ?? 0; ?></strong>
                                </span>
                            </td>
                            <td>
                                <span class="stat-box absent" style="display: inline-block; padding: 5px 10px;">
                                    <strong><?php echo $data['attendance']['total_absent'] ?? 0; ?></strong>
                                </span>
                            </td>
                            <td>
                                <span class="stat-box prepaid" style="display: inline-block; padding: 5px 10px;">
                                    C: <?php echo $data['prepaid']['canteen_prepaid'] ?? 0; ?> |
                                    B: <?php echo $data['prepaid']['bus_prepaid'] ?? 0; ?>
                                </span>
                            </td>
                            <td>
                                <strong><?php echo $data['collections']['canteen_count'] ?? 0; ?></strong> students<br>
                                <span style="color: #10B981;"><?php echo format_currency($data['collections']['canteen_total'] ?? 0); ?></span>
                            </td>
                            <td>
                                <strong><?php echo $data['collections']['bus_count'] ?? 0; ?></strong> students<br>
                                <span style="color: #10B981;"><?php echo format_currency($data['collections']['bus_total'] ?? 0); ?></span>
                            </td>
                            <td>
                                <div class="amount-display"><?php echo format_currency($data['grand_total']); ?></div>
                            </td>
                            <td>
                                <?php if ($data['payment_verified']): ?>
                                    <span class="verified-badge">
                                        <i class="fas fa-check-circle"></i> VERIFIED
                                    </span>
                                    <div style="font-size: 11px; color: var(--text-secondary); margin-top: 5px;">
                                        <?php echo date('M d, h:i A', strtotime($data['payment_verified']['verified_at'])); ?>
                                    </div>
                                <?php else: ?>
                                    <span class="pending-badge">
                                        <i class="fas fa-clock"></i> PENDING
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!$data['payment_verified']): ?>
                                    <button onclick="openVerifyModal(<?php echo $data['teacher_id']; ?>, '<?php echo htmlspecialchars($data['teacher_name']); ?>', <?php echo $data['grand_total']; ?>, '<?php echo $selected_date; ?>', <?php echo $data['class_id']; ?>)" 
                                            class="btn btn-sm btn-success">
                                        <i class="fas fa-check"></i> Verify Payment
                                    </button>
                                    <button onclick="viewStudentList(<?php echo $data['teacher_id']; ?>, '<?php echo htmlspecialchars($data['teacher_name']); ?>', <?php echo $data['class_id']; ?>, '<?php echo $selected_date; ?>')" 
                                            class="btn btn-sm btn-info">
                                        <i class="fas fa-users"></i> View Students
                                    </button>
                                <?php else: ?>
                                    <button onclick="viewPaymentDetails(<?php echo $data['payment_verified']['payment_id']; ?>)" 
                                            class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i> View Details
                                    </button>
                                    <button onclick="viewStudentList(<?php echo $data['teacher_id']; ?>, '<?php echo htmlspecialchars($data['teacher_name']); ?>', <?php echo $data['class_id']; ?>, '<?php echo $selected_date; ?>')" 
                                            class="btn btn-sm btn-secondary">
                                        <i class="fas fa-users"></i> View Students
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<!-- Verify Payment Modal -->
<div id="verifyModal" class="modal">
    <div class="modal-content">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3><i class="fas fa-check-circle"></i> Verify Teacher Payment</h3>
            <span onclick="closeModal()" style="font-size: 28px; cursor: pointer; color: var(--text-secondary);">&times;</span>
        </div>
        
        <form method="POST" action="" id="verifyForm" onsubmit="return validateAmount(event);">
            <input type="hidden" name="action" value="verify_payment">
            <input type="hidden" name="teacher_id" id="modal_teacher_id">
            <input type="hidden" name="collection_date" id="modal_collection_date">
            
            <div class="form-group">
                <label><strong>Teacher:</strong></label>
                <div id="modal_teacher_name" style="font-size: 18px; color: var(--primary-blue); margin-bottom: 15px;"></div>
            </div>
            
            <div class="form-group">
                <label><strong>Expected Amount (From Collections):</strong></label>
                <div id="modal_expected_amount" style="font-size: 32px; font-weight: bold; color: #10B981; margin-bottom: 15px;"></div>
                <input type="hidden" id="modal_expected_value" value="">
            </div>
            
            <div style="background: #FFF3E0; border-left: 4px solid #FF9800; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <strong style="color: #E65100;"><i class="fas fa-exclamation-triangle"></i> IMPORTANT:</strong>
                <p style="margin: 8px 0 0 0; color: #5D4037; font-size: 14px;">
                    The amount you enter MUST EXACTLY match the expected amount. Any mismatch will be rejected.
                </p>
            </div>
            
            <div class="form-group">
                <label>Amount Paid <span style="color: red;">*</span></label>
                <input type="number" name="amount_paid" id="modal_amount_paid" class="form-control" 
                       step="0.01" min="0" required
                       style="font-size: 20px; font-weight: bold; padding: 12px;">
                <div id="amount_error" style="display: none; color: #EF4444; font-weight: bold; margin-top: 8px; padding: 10px; background: #FEE2E2; border-radius: 5px;">
                    <i class="fas fa-times-circle"></i> <span id="amount_error_message"></span>
                </div>
                <div id="amount_success" style="display: none; color: #10B981; font-weight: bold; margin-top: 8px; padding: 10px; background: #D1FAE5; border-radius: 5px;">
                    <i class="fas fa-check-circle"></i> Amount matches! Ready to verify.
                </div>
            </div>
            
            <div class="form-group">
                <label>Payment Method <span style="color: red;">*</span></label>
                <select name="payment_method" class="form-control" required>
                    <option value="cash">Cash</option>
                    <option value="mobile_money">Mobile Money</option>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="cheque">Cheque</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Notes (Optional)</label>
                <textarea name="notes" class="form-control" rows="3" 
                          placeholder="Add any notes or comments..."></textarea>
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button type="submit" class="btn btn-success" style="flex: 1;" id="submitBtn" disabled>
                    <i class="fas fa-check"></i> Verify & Record Payment
                </button>
                <button type="button" onclick="closeModal()" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Student List Modal (Read-Only for Accountant) -->
<div id="studentListModal" class="modal">
    <div class="modal-content" style="max-width: 900px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3><i class="fas fa-users"></i> Student Collection Details (View Only)</h3>
            <span onclick="closeStudentModal()" style="font-size: 28px; cursor: pointer; color: var(--text-secondary);">&times;</span>
        </div>
        
        <div id="studentListContent">
            <div style="text-align: center; padding: 40px; color: var(--text-secondary);">
                <i class="fas fa-spinner fa-spin" style="font-size: 48px;"></i>
                <p style="margin-top: 15px;">Loading student data...</p>
            </div>
        </div>
        
        <div style="margin-top: 20px; text-align: right;">
            <button onclick="closeStudentModal()" class="btn btn-secondary">
                <i class="fas fa-times"></i> Close
            </button>
        </div>
    </div>
</div>

<script>
let expectedAmount = 0;

function openVerifyModal(teacherId, teacherName, amount, date, classId) {
    expectedAmount = parseFloat(amount);
    
    document.getElementById('modal_teacher_id').value = teacherId;
    document.getElementById('modal_teacher_name').textContent = teacherName;
    document.getElementById('modal_expected_amount').textContent = '₵' + expectedAmount.toFixed(2);
    document.getElementById('modal_expected_value').value = expectedAmount.toFixed(2);
    document.getElementById('modal_collection_date').value = date;
    document.getElementById('modal_amount_paid').value = ''; // Clear previous value
    
    // Reset validation states
    document.getElementById('amount_error').style.display = 'none';
    document.getElementById('amount_success').style.display = 'none';
    document.getElementById('submitBtn').disabled = true;
    
    document.getElementById('verifyModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('verifyModal').style.display = 'none';
}

function closeStudentModal() {
    document.getElementById('studentListModal').style.display = 'none';
}

// Strict amount validation - MUST match exactly
document.getElementById('modal_amount_paid').addEventListener('input', function() {
    const amountPaid = parseFloat(this.value) || 0;
    const errorElement = document.getElementById('amount_error');
    const successElement = document.getElementById('amount_success');
    const submitBtn = document.getElementById('submitBtn');
    const errorMessage = document.getElementById('amount_error_message');
    
    // Check if amounts match (within 0.01 tolerance for floating point)
    const difference = Math.abs(amountPaid - expectedAmount);
    
    if (this.value === '' || amountPaid === 0) {
        // Empty field
        errorElement.style.display = 'none';
        successElement.style.display = 'none';
        submitBtn.disabled = true;
    }
    else if (difference < 0.01) {
        // EXACT MATCH - Allow submission
        errorElement.style.display = 'none';
        successElement.style.display = 'block';
        submitBtn.disabled = false;
    }
    else {
        // MISMATCH - Block submission
        const shortfall = expectedAmount - amountPaid;
        
        if (shortfall > 0) {
            errorMessage.textContent = `REJECTED: Amount is ₵${shortfall.toFixed(2)} SHORT. Must be exactly ₵${expectedAmount.toFixed(2)}`;
        } else {
            errorMessage.textContent = `REJECTED: Amount is ₵${Math.abs(shortfall).toFixed(2)} OVER. Must be exactly ₵${expectedAmount.toFixed(2)}`;
        }
        
        errorElement.style.display = 'block';
        successElement.style.display = 'none';
        submitBtn.disabled = true;
    }
});

// Validate before form submission
function validateAmount(event) {
    const amountPaid = parseFloat(document.getElementById('modal_amount_paid').value) || 0;
    const difference = Math.abs(amountPaid - expectedAmount);
    
    if (difference >= 0.01) {
        event.preventDefault();
        
        alert(
            '❌ PAYMENT REJECTED!\n\n' +
            'Expected: ₵' + expectedAmount.toFixed(2) + '\n' +
            'You entered: ₵' + amountPaid.toFixed(2) + '\n\n' +
            'The amounts DO NOT MATCH.\n' +
            'Please enter the EXACT amount shown.'
        );
        
        // Highlight the input field
        document.getElementById('modal_amount_paid').style.borderColor = '#EF4444';
        document.getElementById('modal_amount_paid').focus();
        
        return false;
    }
    
    // Final confirmation
    return confirm(
        '✅ Confirm Payment Verification\n\n' +
        'Amount: ₵' + expectedAmount.toFixed(2) + '\n' +
        'This matches the expected amount.\n\n' +
        'Proceed with verification?'
    );
}

// View student list (Read-only for accountant)
function viewStudentList(teacherId, teacherName, classId, date) {
    document.getElementById('studentListModal').style.display = 'block';
    
    // Load student data via AJAX
    fetch(`get-collection-students.php?teacher_id=${teacherId}&class_id=${classId}&date=${date}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayStudentList(data.students, teacherName, data.class_name, date);
            } else {
                document.getElementById('studentListContent').innerHTML = `
                    <div style="text-align: center; padding: 40px; color: #EF4444;">
                        <i class="fas fa-exclamation-triangle" style="font-size: 48px;"></i>
                        <p style="margin-top: 15px;"><strong>Error loading students</strong></p>
                        <p>${data.message || 'Unknown error'}</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            document.getElementById('studentListContent').innerHTML = `
                <div style="text-align: center; padding: 40px; color: #EF4444;">
                    <i class="fas fa-exclamation-triangle" style="font-size: 48px;"></i>
                    <p style="margin-top: 15px;"><strong>Error loading students</strong></p>
                    <p>${error.message}</p>
                </div>
            `;
        });
}

function displayStudentList(students, teacherName, className, date) {
    let html = `
        <div style="background: var(--bg-secondary); padding: 15px; border-radius: 8px; margin-bottom: 20px;">
            <h4 style="margin: 0 0 10px 0; color: var(--primary-blue);">
                <i class="fas fa-info-circle"></i> Collection Details
            </h4>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
                <div><strong>Teacher:</strong> ${teacherName}</div>
                <div><strong>Class:</strong> ${className}</div>
                <div><strong>Date:</strong> ${new Date(date).toLocaleDateString()}</div>
            </div>
        </div>
        
        <div style="background: #FFF3E0; border-left: 4px solid #FF9800; padding: 12px; border-radius: 5px; margin-bottom: 20px;">
            <strong><i class="fas fa-lock"></i> READ-ONLY VIEW</strong>
            <p style="margin: 5px 0 0 0; font-size: 14px;">You are viewing collection data only. You cannot make or modify payments from this page.</p>
        </div>
        
        <div style="max-height: 500px; overflow-y: auto;">
            <table class="collection-table">
                <thead>
                    <tr>
                        <th style="position: sticky; top: 0; background: var(--primary-blue); z-index: 10;">#</th>
                        <th style="position: sticky; top: 0; background: var(--primary-blue); z-index: 10;">Student Name</th>
                        <th style="position: sticky; top: 0; background: var(--primary-blue); z-index: 10;">Attendance</th>
                        <th style="position: sticky; top: 0; background: var(--primary-blue); z-index: 10;">Canteen</th>
                        <th style="position: sticky; top: 0; background: var(--primary-blue); z-index: 10;">Bus</th>
                        <th style="position: sticky; top: 0; background: var(--primary-blue); z-index: 10;">Total</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    let totalCanteen = 0;
    let totalBus = 0;
    
    students.forEach((student, index) => {
        const canteenAmount = parseFloat(student.canteen_amount) || 0;
        const busAmount = parseFloat(student.bus_amount) || 0;
        const total = canteenAmount + busAmount;
        
        if (student.canteen_paid) totalCanteen += canteenAmount;
        if (student.bus_paid) totalBus += busAmount;
        
        html += `
            <tr>
                <td>${index + 1}</td>
                <td><strong>${student.student_name}</strong></td>
                <td>
                    ${student.attendance_status === 'present' 
                        ? '<span style="background: #10B981; color: white; padding: 3px 10px; border-radius: 3px;">PRESENT</span>'
                        : student.attendance_status === 'absent'
                        ? '<span style="background: #EF4444; color: white; padding: 3px 10px; border-radius: 3px;">ABSENT</span>'
                        : '<span style="background: #9E9E9E; color: white; padding: 3px 10px; border-radius: 3px;">UNMARKED</span>'
                    }
                </td>
                <td>
                    ${student.canteen_exempt 
                        ? '<span class="exempt-badge">EXEMPT</span>'
                        : student.canteen_fee_type && student.canteen_fee_type !== 'daily'
                        ? `<span class="exempt-badge" style="background: #2196F3;"><i class="fas fa-lock"></i> ${student.canteen_fee_type.toUpperCase()}</span>`
                        : student.canteen_paid
                        ? `<span style="color: #10B981; font-weight: bold;">✓ ₵${canteenAmount.toFixed(2)}</span>`
                        : '<span style="color: #9E9E9E;">—</span>'
                    }
                </td>
                <td>
                    ${student.bus_exempt
                        ? '<span class="exempt-badge">EXEMPT</span>'
                        : !student.hometown_name
                        ? '<span class="exempt-badge" style="background: #FF9800;">NO ROUTE</span>'
                        : student.bus_fee_type && student.bus_fee_type !== 'daily'
                        ? `<span class="exempt-badge" style="background: #2196F3;"><i class="fas fa-lock"></i> ${student.bus_fee_type.toUpperCase()}</span>`
                        : student.bus_paid
                        ? `<span style="color: #10B981; font-weight: bold;">✓ ₵${busAmount.toFixed(2)}</span>`
                        : '<span style="color: #9E9E9E;">—</span>'
                    }
                </td>
                <td><strong style="color: ${total > 0 ? '#10B981' : '#9E9E9E'};">₵${total.toFixed(2)}</strong></td>
            </tr>
        `;
    });
    
    html += `
                </tbody>
                <tfoot style="background: var(--bg-secondary); font-weight: bold;">
                    <tr>
                        <td colspan="3" style="text-align: right; padding: 12px;">TOTAL COLLECTED:</td>
                        <td style="color: #10B981; font-size: 16px;">₵${totalCanteen.toFixed(2)}</td>
                        <td style="color: #10B981; font-size: 16px;">₵${totalBus.toFixed(2)}</td>
                        <td style="color: #10B981; font-size: 18px;">₵${(totalCanteen + totalBus).toFixed(2)}</td>
                    </tr>
                </tfoot>
            </table>
        </div>
    `;
    
    document.getElementById('studentListContent').innerHTML = html;
}

// Close modal when clicking outside
window.onclick = function(event) {
    const verifyModal = document.getElementById('verifyModal');
    const studentModal = document.getElementById('studentListModal');
    
    if (event.target == verifyModal) {
        closeModal();
    }
    if (event.target == studentModal) {
        closeStudentModal();
    }
}
</script>

<?php require_once BASE_PATH . '/includes/footer.php'; ?>
