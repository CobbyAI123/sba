<?php
// accountant/print-receipt.php - Print Professional Payment Receipt
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['accountant', 'admin']);
$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get payment ID
$payment_id = isset($_GET['payment_id']) ? (int)$_GET['payment_id'] : 0;

if (!$payment_id) {
    die('Invalid payment ID');
}

// Get payment details
$stmt = $db->prepare("
    SELECT 
        p.*,
        s.first_name,
        s.last_name,
        s.admission_number,
        s.phone,
        c.class_name,
        t.term_name
    FROM payments p
    LEFT JOIN students s ON p.student_id = s.student_id
    LEFT JOIN classes c ON s.class_id = c.class_id
    LEFT JOIN terms t ON p.term_id = t.term_id
    WHERE p.payment_id = ? AND p.school_id = ?
");
$stmt->execute([$payment_id, $school_id]);
$payment = $stmt->fetch();

if (!$payment) {
    die('Payment not found');
}

// Get school details
$stmt = $db->prepare("SELECT * FROM schools WHERE school_id = ?");
$stmt->execute([$school_id]);
$school = $stmt->fetch();

// Generate receipt number: First 2 letters of student name + MMDDSS
$first_two = strtoupper(substr($payment['first_name'], 0, 2));
$date_part = date('mdHis'); // Month, Day, Hour, Minute, Second
$receipt_number = $first_two . '-' . $date_part;

// Get paid by name (check if it was stored, otherwise use student name)
$paid_by = !empty($payment['paid_by']) ? $payment['paid_by'] : $payment['first_name'] . ' ' . $payment['last_name'];
$paid_by_phone = !empty($payment['paid_by_phone']) ? $payment['paid_by_phone'] : $payment['phone'];

// Get accountant name
$accountant_name = $current_user['first_name'] . ' ' . $current_user['last_name'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment Receipt - <?php echo $receipt_number; ?></title>
    <style>
        @page {
            size: 2480px 1301px;
            margin: 0;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            width: 2480px;
            height: 1301px;
            margin: 0;
            padding: 80px;
            background: white;
            position: relative;
        }
        
        @media print {
            body {
                margin: 0 !important;
                padding: 80px !important;
            }
        }
        
        .receipt-container {
            width: 100%;
            height: 100%;
            border: 8px solid #2563eb;
            padding: 60px;
            position: relative;
        }
        
        /* Header Section */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 50px;
            padding-bottom: 40px;
            border-bottom: 4px solid #e5e7eb;
        }
        
        .school-info {
            flex: 1;
        }
        
        .school-name {
            font-size: 56px;
            font-weight: 900;
            color: #1e293b;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        
        .school-address {
            font-size: 32px;
            color: #64748b;
            line-height: 1.6;
        }
        
        .school-logo {
            width: 280px;
            height: 280px;
            border: 4px solid #e5e7eb;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f8fafc;
        }
        
        .school-logo img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        
        .logo-placeholder {
            font-size: 120px;
            color: #cbd5e1;
        }
        
        /* Title */
        .receipt-title {
            text-align: center;
            font-size: 72px;
            font-weight: 900;
            color: #2563eb;
            margin: 50px 0;
            text-transform: uppercase;
            letter-spacing: 4px;
        }
        
        /* Receipt Info */
        .receipt-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 50px;
            font-size: 32px;
        }
        
        .receipt-info div {
            display: flex;
            gap: 20px;
        }
        
        .receipt-info strong {
            color: #1e293b;
            font-weight: 700;
        }
        
        .receipt-info span {
            color: #2563eb;
            font-weight: 600;
        }
        
        /* Paid By Section */
        .paid-by-section {
            margin-bottom: 50px;
            font-size: 32px;
        }
        
        .paid-by-section div {
            margin-bottom: 15px;
        }
        
        .paid-by-section strong {
            color: #1e293b;
            font-weight: 700;
            display: inline-block;
            width: 250px;
        }
        
        .paid-by-section span {
            color: #475569;
        }
        
        /* Payment Details Table */
        .payment-details-title {
            font-size: 42px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 30px;
            text-transform: uppercase;
        }
        
        .payment-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 50px;
        }
        
        .payment-table thead {
            background: #2563eb;
            color: white;
        }
        
        .payment-table th {
            padding: 30px 25px;
            text-align: left;
            font-size: 36px;
            font-weight: 700;
            border: 3px solid #1e40af;
        }
        
        .payment-table td {
            padding: 35px 25px;
            font-size: 34px;
            border: 3px solid #e5e7eb;
            color: #1e293b;
        }
        
        .payment-table tbody tr:nth-child(even) {
            background: #f8fafc;
        }
        
        /* Total Section */
        .total-section {
            background: #f1f5f9;
            padding: 40px;
            margin-bottom: 60px;
            border-radius: 15px;
            border: 4px solid #2563eb;
        }
        
        .total-amount {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .total-amount .label {
            font-size: 48px;
            font-weight: 700;
            color: #1e293b;
        }
        
        .total-amount .amount {
            font-size: 64px;
            font-weight: 900;
            color: #2563eb;
        }
        
        /* Signature Section */
        .signature-section {
            margin-top: 80px;
            margin-bottom: 50px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 100px;
        }
        
        .signature-box {
            text-align: center;
        }
        
        .signature-image {
            width: 300px;
            height: 150px;
            border-bottom: 4px solid #1e293b;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
        }
        
        .signature-image img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        
        .accountant-name {
            font-size: 32px;
            color: #1e293b;
            margin-top: 20px;
            font-weight: 700;
        }
        
        .signature-line {
            width: 300px;
            border-bottom: 4px solid #1e293b;
            margin: 30px auto 0;
        }
        
        .signature-title {
            font-size: 28px;
            color: #1e293b;
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        /* Thank You Message */
        .thank-you {
            text-align: center;
            font-size: 42px;
            font-weight: 700;
            color: #2563eb;
            margin-top: 60px;
            text-transform: uppercase;
            letter-spacing: 3px;
        }
        
        /* Print Styles */
        @media print {
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .no-print {
                display: none !important;
            }
        }
        
        .print-button {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 20px 40px;
            background: #2563eb;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 24px;
            cursor: pointer;
            z-index: 1000;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .print-button:hover {
            background: #1e40af;
        }
    </style>
</head>
<body>
    <button onclick="window.print()" class="print-button no-print">
        <i class="fas fa-print"></i> Print Receipt
    </button>
    
    <div class="receipt-container">
        <!-- Header -->
        <div class="header">
            <div class="school-info">
                <div class="school-name"><?php echo htmlspecialchars($school['school_name']); ?></div>
                <div class="school-address">
                    <?php echo htmlspecialchars($school['address'] ?? 'School Address'); ?><br>
                    <?php if (!empty($school['phone'])): ?>
                        Tel: <?php echo htmlspecialchars($school['phone']); ?><br>
                    <?php endif; ?>
                    <?php if (!empty($school['email'])): ?>
                        Email: <?php echo htmlspecialchars($school['email']); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="school-logo">
                <?php if (!empty($school['logo'])): ?>
                    <img src="<?php echo APP_URL . '/' . $school['logo']; ?>" alt="School Logo">
                <?php else: ?>
                    <div class="logo-placeholder">
                        <i class="fas fa-school"></i>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Title -->
        <div class="receipt-title">SCHOOL PAYMENT RECEIPT</div>
        
        <!-- Receipt Info -->
        <div class="receipt-info">
            <div>
                <strong>RECEIPT NO:</strong>
                <span><?php echo $receipt_number; ?></span>
            </div>
            <div>
                <strong>DATE:</strong>
                <span><?php echo date('F d, Y'); ?></span>
            </div>
        </div>
        
        <!-- Paid By Section -->
        <div class="paid-by-section">
            <div>
                <strong>PAID BY:</strong>
                <span><?php echo htmlspecialchars($paid_by); ?></span>
            </div>
            <?php if ($paid_by_phone): ?>
            <div>
                <strong>PHONE:</strong>
                <span><?php echo htmlspecialchars($paid_by_phone); ?></span>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Payment Details -->
        <div class="payment-details-title">PAYMENT DETAILS</div>
        
        <table class="payment-table">
            <thead>
                <tr>
                    <th>DESCRIPTION</th>
                    <th>AMOUNT</th>
                    <th>DATE PAID</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <strong>School Fees Payment</strong><br>
                        <span style="font-size: 28px; color: #64748b;">
                            Student: <?php echo htmlspecialchars($payment['first_name'] . ' ' . $payment['last_name']); ?><br>
                            Admission No: <?php echo htmlspecialchars($payment['admission_number']); ?><br>
                            Class: <?php echo htmlspecialchars($payment['class_name'] ?? 'N/A'); ?><br>
                            <?php if ($payment['term_name']): ?>
                                Term: <?php echo htmlspecialchars($payment['term_name']); ?><br>
                            <?php endif; ?>
                            Payment Method: <?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?>
                            <?php if ($payment['payment_reference']): ?>
                                <br>Reference: <?php echo htmlspecialchars($payment['payment_reference']); ?>
                            <?php endif; ?>
                        </span>
                    </td>
                    <td><strong><?php echo format_currency($payment['amount']); ?></strong></td>
                    <td><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></td>
                </tr>
            </tbody>
        </table>
        
        <!-- Total Payment -->
        <div class="total-section">
            <div class="total-amount">
                <div class="label">TOTAL PAYMENT:</div>
                <div class="amount"><?php echo format_currency($payment['amount']); ?></div>
            </div>
        </div>
        
        <!-- Signature -->
        <div class="signature-section">
            <div class="signature-box">
                <div class="signature-title">ACCOUNTANT SIGNATURE</div>
                <div class="signature-image">
                    <?php if (!empty($current_user['signature'])): ?>
                        <img src="<?php echo APP_URL . '/' . $current_user['signature']; ?>" alt="Accountant Signature">
                    <?php else: ?>
                        <div style="color: #cbd5e1; font-size: 36px;">_____________________</div>
                    <?php endif; ?>
                </div>
                <div class="accountant-name"><?php echo htmlspecialchars($accountant_name); ?></div>
            </div>
            <div class="signature-box">
                <div class="signature-title">AUTHORIZED BY</div>
                <div class="signature-image">
                    <div style="color: #cbd5e1; font-size: 36px;">_____________________</div>
                </div>
                <div class="accountant-name">School Principal</div>
            </div>
        </div>
        
        <!-- Thank You -->
        <div class="thank-you">
            THANK YOU FOR YOUR TIMELY PAYMENT!
        </div>
    </div>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</body>
</html>
