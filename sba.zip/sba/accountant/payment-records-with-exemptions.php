<?php
// accountant/payment-records-with-exemptions.php - Payment Records with Exemption Display
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Payment Records';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get filters
$class_filter = $_GET['class'] ?? '';
$search = $_GET['search'] ?? '';
$fee_type = $_GET['fee_type'] ?? '';

// Get current term
$stmt = $db->prepare("SELECT term_id FROM terms WHERE school_id = ? AND is_current = 1 LIMIT 1");
$stmt->execute([$school_id]);
$current_term = $stmt->fetch();
$term_id = $current_term['term_id'] ?? null;

// Build query
$query = "
    SELECT 
        s.student_id,
        s.admission_number,
        CONCAT(u.first_name, ' ', u.last_name) as student_name,
        c.class_name,
        s.fee_exemption,
        s.exemption_reason,
        s.exemption_date,
        CONCAT(approver.first_name, ' ', approver.last_name) as exemption_approved_by_name,
        
        -- School Fees
        COALESCE(SUM(CASE WHEN p.payment_type = 'Tuition Fee' THEN p.amount ELSE 0 END), 0) as school_fees_paid,
        1200.00 as school_fees_total,
        
        -- Canteen Fees
        COALESCE(SUM(CASE WHEN p.payment_type = 'Canteen Fee' THEN p.amount ELSE 0 END), 0) as canteen_fees_paid,
        s.canteen_fee as canteen_fees_total,
        
        -- Transport Fees
        COALESCE(SUM(CASE WHEN p.payment_type = 'Transport Fee' THEN p.amount ELSE 0 END), 0) as transport_fees_paid,
        s.transport_fee as transport_fees_total
        
    FROM students s
    LEFT JOIN users u ON s.user_id = u.user_id
    LEFT JOIN classes c ON s.class_id = c.class_id
    LEFT JOIN users approver ON s.exemption_approved_by = approver.user_id
    LEFT JOIN payments p ON s.student_id = p.student_id AND p.status = 'completed'
    WHERE s.school_id = ? AND s.status = 'active'
";

$params = [$school_id];

if ($class_filter) {
    $query .= " AND s.class_id = ?";
    $params[] = $class_filter;
}

if ($search) {
    $query .= " AND (u.first_name LIKE ? OR u.last_name LIKE ? OR s.admission_number LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

$query .= " GROUP BY s.student_id ORDER BY c.class_name, student_name";

$stmt = $db->prepare($query);
$stmt->execute($params);
$students = $stmt->fetchAll();

// Get classes
$stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .exemption-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        background: rgba(255, 193, 7, 0.2);
        color: #ffc107;
        border: 2px solid rgba(255, 193, 7, 0.4);
    }
    
    .exemption-row {
        background: rgba(255, 193, 7, 0.05) !important;
    }
    
    .fee-status {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .fee-progress {
        flex: 1;
        height: 8px;
        background: var(--secondary-bg);
        border-radius: 4px;
        overflow: hidden;
    }
    
    .fee-progress-bar {
        height: 100%;
        background: linear-gradient(90deg, #00d68f 0%, #00b974 100%);
        transition: width 0.3s ease;
    }
    
    .exemption-tooltip {
        position: relative;
        cursor: help;
    }
    
    .exemption-tooltip:hover::after {
        content: attr(data-reason);
        position: absolute;
        bottom: 100%;
        left: 50%;
        transform: translateX(-50%);
        padding: 8px 12px;
        background: var(--card-bg);
        border: 2px solid var(--active-pink);
        border-radius: 8px;
        font-size: 12px;
        white-space: nowrap;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
    </style>
    
    <h2><i class="fas fa-file-invoice-dollar"></i> Payment Records with Exemptions</h2>
    
    <!-- Filters -->
    <div class="card" style="margin-bottom: 25px;">
        <div style="padding: 20px;">
            <form method="GET" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: flex-end;">
                <div class="form-group" style="margin: 0;">
                    <label><i class="fas fa-search"></i> Search Student</label>
                    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
                           placeholder="Name or Admission No." class="form-control">
                </div>
                <div class="form-group" style="margin: 0;">
                    <label><i class="fas fa-chalkboard"></i> Class</label>
                    <select name="class" class="form-control">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>" <?php echo $class_filter == $class['class_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                    <a href="?" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Reset
                    </a>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Payment Records -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-table"></i> Payment Records (<?php echo count($students); ?> students)</h3>
        </div>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Admission No.</th>
                        <th>Student Name</th>
                        <th>Class</th>
                        <th>School Fees</th>
                        <th>Canteen Fees</th>
                        <th>Transport Fees</th>
                        <th>Total Paid</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($students) > 0): ?>
                        <?php foreach ($students as $student): 
                            $exemptions = json_decode($student['fee_exemption'] ?? '[]', true) ?: [];
                            $school_exempted = in_array('school', $exemptions);
                            $canteen_exempted = in_array('canteen', $exemptions);
                            $transport_exempted = in_array('transport', $exemptions);
                            
                            $has_exemption = !empty($exemptions);
                            
                            $total_paid = $student['school_fees_paid'] + $student['canteen_fees_paid'] + $student['transport_fees_paid'];
                        ?>
                            <tr class="<?php echo $has_exemption ? 'exemption-row' : ''; ?>">
                                <td><strong><?php echo htmlspecialchars($student['admission_number']); ?></strong></td>
                                <td>
                                    <div style="font-weight: 600;"><?php echo htmlspecialchars($student['student_name']); ?></div>
                                    <?php if ($has_exemption): ?>
                                        <div class="exemption-badge exemption-tooltip" 
                                             data-reason="<?php echo htmlspecialchars($student['exemption_reason'] ?? 'No reason provided'); ?>">
                                            <i class="fas fa-ban"></i>
                                            Fee Exemptions
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($student['class_name'] ?? 'N/A'); ?></td>
                                
                                <!-- School Fees -->
                                <td>
                                    <?php if ($school_exempted): ?>
                                        <div style="text-align: center; padding: 12px; background: rgba(255, 193, 7, 0.1); border-radius: 8px; border: 2px dashed rgba(255, 193, 7, 0.4);">
                                            <div style="font-size: 20px; margin-bottom: 5px;">
                                                <i class="fas fa-ban" style="color: #ffc107;"></i>
                                            </div>
                                            <strong style="color: #ffc107; display: block;">EXEMPTED</strong>
                                            <small style="color: var(--text-secondary); font-size: 11px; display: block; margin-top: 3px;">
                                                <?php echo htmlspecialchars($student['exemption_reason']); ?>
                                            </small>
                                        </div>
                                    <?php else: ?>
                                        <div class="fee-status">
                                            <div style="min-width: 100px;">
                                                <div style="font-weight: 700; color: #00d68f;">GH₵ <?php echo number_format($student['school_fees_paid'], 2); ?></div>
                                                <div style="font-size: 11px; color: var(--text-secondary);">of GH₵ <?php echo number_format($student['school_fees_total'], 2); ?></div>
                                            </div>
                                            <div class="fee-progress">
                                                <?php 
                                                $school_percent = $student['school_fees_total'] > 0 
                                                    ? ($student['school_fees_paid'] / $student['school_fees_total']) * 100 
                                                    : 0;
                                                ?>
                                                <div class="fee-progress-bar" style="width: <?php echo min($school_percent, 100); ?>%;"></div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                
                                <!-- Canteen Fees -->
                                <td>
                                    <?php if ($canteen_exempted): ?>
                                        <div style="text-align: center; padding: 12px; background: rgba(255, 193, 7, 0.1); border-radius: 8px; border: 2px dashed rgba(255, 193, 7, 0.4);">
                                            <div style="font-size: 20px; margin-bottom: 5px;">
                                                <i class="fas fa-ban" style="color: #ffc107;"></i>
                                            </div>
                                            <strong style="color: #ffc107; display: block;">EXEMPTED</strong>
                                            <small style="color: var(--text-secondary); font-size: 11px; display: block; margin-top: 3px;">
                                                <?php echo htmlspecialchars($student['exemption_reason']); ?>
                                            </small>
                                        </div>
                                    <?php elseif ($student['canteen_fees_total'] > 0): ?>
                                        <div class="fee-status">
                                            <div style="min-width: 100px;">
                                                <div style="font-weight: 700; color: #ffa726;">GH₵ <?php echo number_format($student['canteen_fees_paid'], 2); ?></div>
                                                <div style="font-size: 11px; color: var(--text-secondary);">of GH₵ <?php echo number_format($student['canteen_fees_total'], 2); ?></div>
                                            </div>
                                            <div class="fee-progress">
                                                <?php 
                                                $canteen_percent = ($student['canteen_fees_paid'] / $student['canteen_fees_total']) * 100;
                                                ?>
                                                <div class="fee-progress-bar" style="width: <?php echo min($canteen_percent, 100); ?>%; background: linear-gradient(90deg, #ffa726 0%, #ff9800 100%);"></div>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <span style="color: var(--text-secondary);">N/A</span>
                                    <?php endif; ?>
                                </td>
                                
                                <!-- Transport Fees -->
                                <td>
                                    <?php if ($transport_exempted): ?>
                                        <div style="text-align: center; padding: 12px; background: rgba(255, 193, 7, 0.1); border-radius: 8px; border: 2px dashed rgba(255, 193, 7, 0.4);">
                                            <div style="font-size: 20px; margin-bottom: 5px;">
                                                <i class="fas fa-ban" style="color: #ffc107;"></i>
                                            </div>
                                            <strong style="color: #ffc107; display: block;">EXEMPTED</strong>
                                            <small style="color: var(--text-secondary); font-size: 11px; display: block; margin-top: 3px;">
                                                <?php echo htmlspecialchars($student['exemption_reason']); ?>
                                            </small>
                                        </div>
                                    <?php elseif ($student['transport_fees_total'] > 0): ?>
                                        <div class="fee-status">
                                            <div style="min-width: 100px;">
                                                <div style="font-weight: 700; color: #2d5bff;">GH₵ <?php echo number_format($student['transport_fees_paid'], 2); ?></div>
                                                <div style="font-size: 11px; color: var(--text-secondary);">of GH₵ <?php echo number_format($student['transport_fees_total'], 2); ?></div>
                                            </div>
                                            <div class="fee-progress">
                                                <?php 
                                                $transport_percent = ($student['transport_fees_paid'] / $student['transport_fees_total']) * 100;
                                                ?>
                                                <div class="fee-progress-bar" style="width: <?php echo min($transport_percent, 100); ?>%; background: linear-gradient(90deg, #2d5bff 0%, #1e3fbf 100%);"></div>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <span style="color: var(--text-secondary);">N/A</span>
                                    <?php endif; ?>
                                </td>
                                
                                <!-- Total Paid -->
                                <td>
                                    <div style="font-weight: 700; font-size: 18px; color: #00d68f;">
                                        GH₵ <?php echo number_format($total_paid, 2); ?>
                                    </div>
                                    <?php if ($has_exemption): ?>
                                        <div style="font-size: 11px; color: #ffc107; margin-top: 3px;">
                                            <i class="fas fa-info-circle"></i> Some fees exempted
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 60px;">
                                <i class="fas fa-inbox" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 15px; display: block;"></i>
                                <h3>No Students Found</h3>
                                <p style="color: var(--text-secondary);">No payment records match your search criteria.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Legend -->
    <div class="card" style="margin-top: 25px;">
        <div style="padding: 20px;">
            <h4 style="margin-bottom: 15px;"><i class="fas fa-info-circle"></i> Legend</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div class="exemption-badge">
                        <i class="fas fa-ban"></i> Fee Exemptions
                    </div>
                    <span style="color: var(--text-secondary); font-size: 13px;">Student has fee exemptions</span>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div style="padding: 8px 12px; background: rgba(255, 193, 7, 0.1); border-radius: 8px; border: 2px dashed rgba(255, 193, 7, 0.4);">
                        <i class="fas fa-ban" style="color: #ffc107;"></i> EXEMPTED
                    </div>
                    <span style="color: var(--text-secondary); font-size: 13px;">Specific fee is exempted</span>
                </div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div class="fee-progress" style="width: 100px;">
                        <div class="fee-progress-bar" style="width: 75%;"></div>
                    </div>
                    <span style="color: var(--text-secondary); font-size: 13px;">Payment progress</span>
                </div>
            </div>
            <div style="margin-top: 15px; padding: 12px; background: rgba(255, 193, 7, 0.05); border-left: 4px solid #ffc107; border-radius: 4px;">
                <i class="fas fa-lightbulb" style="color: #ffc107;"></i>
                <strong>Tip:</strong> Hover over the "Fee Exemptions" badge to see the exemption reason.
            </div>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
