<?php
// accountant/weekly-fee-students.php - Students Paying Weekly Fees
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Weekly Fee Students';
$current_user = check_permission(['accountant', 'admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get filter parameters
$selected_class = isset($_GET['class_id']) ? sanitize_input($_GET['class_id']) : 'all';
$fee_type_filter = isset($_GET['fee_type']) ? sanitize_input($_GET['fee_type']) : 'all'; // canteen, bus, all

// Get all classes for filter
$classes = [];
$stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get students paying weekly fees
$query = "
    SELECT 
        s.student_id,
        s.admission_number,
        s.first_name,
        s.last_name,
        s.canteen_fee_type,
        s.bus_fee_type,
        s.exempt_canteen,
        s.exempt_bus,
        s.photo,
        c.class_name,
        h.hometown_name,
        h.bus_fee
    FROM students s
    LEFT JOIN classes c ON s.class_id = c.class_id
    LEFT JOIN hometowns h ON s.hometown_id = h.hometown_id
    WHERE s.school_id = ? AND s.status = 'active'
    AND (s.canteen_fee_type = 'weekly' OR s.bus_fee_type = 'weekly')
";

$params = [$school_id];

if ($selected_class != 'all') {
    $query .= " AND s.class_id = ?";
    $params[] = $selected_class;
}

if ($fee_type_filter == 'canteen') {
    $query .= " AND s.canteen_fee_type = 'weekly'";
} elseif ($fee_type_filter == 'bus') {
    $query .= " AND s.bus_fee_type = 'weekly'";
}

$query .= " ORDER BY c.class_name, s.first_name, s.last_name";

$stmt = $db->prepare($query);
$stmt->execute($params);
$students = $stmt->fetchAll();

// Calculate statistics
$stats = [
    'total' => count($students),
    'canteen_only' => 0,
    'bus_only' => 0,
    'both' => 0
];

foreach ($students as $student) {
    $has_canteen = $student['canteen_fee_type'] == 'weekly';
    $has_bus = $student['bus_fee_type'] == 'weekly';
    
    if ($has_canteen && $has_bus) {
        $stats['both']++;
    } elseif ($has_canteen) {
        $stats['canteen_only']++;
    } elseif ($has_bus) {
        $stats['bus_only']++;
    }
}

// Get default canteen fee
$stmt = $db->prepare("
    SELECT daily_fee FROM canteen_fee_structure 
    WHERE school_id = ? 
    ORDER BY created_at DESC 
    LIMIT 1
");
$stmt->execute([$school_id]);
$canteen_fee_row = $stmt->fetch();
$daily_canteen_fee = $canteen_fee_row['daily_fee'] ?? 0;
$weekly_canteen_fee = $daily_canteen_fee * 5; // 5 days per week

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: var(--bg-card);
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            border: 2px solid var(--border-color);
        }
        
        .stat-card.weekly { border-color: #FF9800; }
        .stat-card.canteen { border-color: #4CAF50; }
        .stat-card.bus { border-color: #2196F3; }
        .stat-card.both { border-color: #9C27B0; }
        
        .stat-number {
            font-size: 36px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .stat-card.weekly .stat-number { color: #FF9800; }
        .stat-card.canteen .stat-number { color: #4CAF50; }
        .stat-card.bus .stat-number { color: #2196F3; }
        .stat-card.both .stat-number { color: #9C27B0; }
        
        .filter-bar {
            display: flex;
            gap: 15px;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            background: var(--bg-card);
            padding: 20px;
            border-radius: 12px;
        }
        
        .filter-bar select {
            padding: 10px 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            background: var(--bg-secondary);
            color: var(--text-primary);
            font-size: 14px;
        }
        
        .students-table {
            width: 100%;
            border-collapse: collapse;
            background: var(--bg-card);
            border-radius: 12px;
            overflow: hidden;
        }
        
        .students-table th,
        .students-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        .students-table th {
            background: var(--bg-secondary);
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .student-photo {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .student-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #FF9800;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
        }
        
        .fee-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-right: 5px;
        }
        
        .fee-badge.weekly {
            background: #FFF3E0;
            color: #F57C00;
        }
        
        .fee-badge.canteen {
            background: #E8F5E9;
            color: #388E3C;
        }
        
        .fee-badge.bus {
            background: #E3F2FD;
            color: #1976D2;
        }
    </style>
    
    <!-- Page Header -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <div>
            <h2><i class="fas fa-calendar-week"></i> Weekly Fee Students</h2>
            <p style="color: var(--text-secondary); margin: 5px 0 0 0;">
                Students who pay canteen and/or bus fees on a weekly basis
            </p>
        </div>
        <div>
            <button class="btn btn-success" onclick="exportToExcel()">
                <i class="fas fa-file-excel"></i> Export to Excel
            </button>
            <button class="btn btn-primary" onclick="window.print()">
                <i class="fas fa-print"></i> Print
            </button>
        </div>
    </div>
    
    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card weekly">
            <div class="stat-number"><?php echo $stats['total']; ?></div>
            <div class="stat-label">Total Weekly Payers</div>
            <small>All students paying weekly</small>
        </div>
        
        <div class="stat-card canteen">
            <div class="stat-number"><?php echo $stats['canteen_only']; ?></div>
            <div class="stat-label">Canteen Only</div>
            <small>Weekly canteen fees</small>
        </div>
        
        <div class="stat-card bus">
            <div class="stat-number"><?php echo $stats['bus_only']; ?></div>
            <div class="stat-label">Bus Only</div>
            <small>Weekly bus fees</small>
        </div>
        
        <div class="stat-card both">
            <div class="stat-number"><?php echo $stats['both']; ?></div>
            <div class="stat-label">Both Fees</div>
            <small>Canteen + Bus weekly</small>
        </div>
    </div>
    
    <!-- Filter Bar -->
    <div class="filter-bar">
        <label style="font-weight: 600; color: var(--text-secondary);">
            <i class="fas fa-filter"></i> Filters:
        </label>
        
        <select id="classFilter" onchange="applyFilters()">
            <option value="all" <?php echo $selected_class == 'all' ? 'selected' : ''; ?>>All Classes</option>
            <?php foreach ($classes as $class): ?>
                <option value="<?php echo $class['class_id']; ?>" <?php echo $selected_class == $class['class_id'] ? 'selected' : ''; ?>>
                    <?php echo $class['class_name']; ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <select id="feeTypeFilter" onchange="applyFilters()">
            <option value="all" <?php echo $fee_type_filter == 'all' ? 'selected' : ''; ?>>All Fee Types</option>
            <option value="canteen" <?php echo $fee_type_filter == 'canteen' ? 'selected' : ''; ?>>Canteen Only</option>
            <option value="bus" <?php echo $fee_type_filter == 'bus' ? 'selected' : ''; ?>>Bus Only</option>
        </select>
    </div>
    
    <!-- Students Table -->
    <div class="card" style="margin-top: 20px;">
        <table class="students-table" id="studentsTable">
            <thead>
                <tr>
                    <th>Photo</th>
                    <th>Student Name</th>
                    <th>Admission No.</th>
                    <th>Class</th>
                    <th>Weekly Fees</th>
                    <th>Hometown/Route</th>
                    <th>Estimated Weekly Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($students) > 0): ?>
                    <?php foreach ($students as $student): ?>
                        <?php
                        $estimated_amount = 0;
                        if ($student['canteen_fee_type'] == 'weekly') {
                            $estimated_amount += $weekly_canteen_fee;
                        }
                        if ($student['bus_fee_type'] == 'weekly' && $student['bus_fee']) {
                            $estimated_amount += ($student['bus_fee'] * 5); // 5 days
                        }
                        ?>
                        <tr>
                            <td>
                                <?php if (!empty($student['photo'])): ?>
                                    <img src="<?php echo APP_URL . '/uploads/avatars/' . $student['photo']; ?>" 
                                         alt="<?php echo $student['first_name']; ?>" 
                                         class="student-photo">
                                <?php else: ?>
                                    <div class="student-avatar">
                                        <?php echo strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)); ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></strong>
                            </td>
                            <td><?php echo $student['admission_number']; ?></td>
                            <td><?php echo $student['class_name'] ?? 'N/A'; ?></td>
                            <td>
                                <?php if ($student['canteen_fee_type'] == 'weekly'): ?>
                                    <span class="fee-badge canteen">
                                        <i class="fas fa-utensils"></i> Canteen
                                    </span>
                                <?php endif; ?>
                                <?php if ($student['bus_fee_type'] == 'weekly'): ?>
                                    <span class="fee-badge bus">
                                        <i class="fas fa-bus"></i> Bus
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($student['hometown_name']): ?>
                                    <?php echo $student['hometown_name']; ?>
                                    <small style="color: var(--text-secondary);">
                                        (<?php echo format_currency($student['bus_fee']); ?>/day)
                                    </small>
                                <?php else: ?>
                                    <span style="color: var(--text-secondary);">Not Set</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong style="color: #FF9800;">
                                    <?php echo format_currency($estimated_amount); ?>
                                </strong>
                                <small style="color: var(--text-secondary); display: block;">
                                    per week
                                </small>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 60px;">
                            <i class="fas fa-user-graduate" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 20px; display: block;"></i>
                            <h3 style="margin-bottom: 10px;">No Weekly Fee Students Found</h3>
                            <p style="color: var(--text-secondary);">No students are currently paying fees on a weekly basis.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <script>
    function applyFilters() {
        const classId = document.getElementById('classFilter').value;
        const feeType = document.getElementById('feeTypeFilter').value;
        window.location.href = `?class_id=${classId}&fee_type=${feeType}`;
    }
    
    function exportToExcel() {
        // Simple CSV export
        let csv = 'Student Name,Admission Number,Class,Canteen Fee,Bus Fee,Hometown,Estimated Weekly Amount\n';
        
        const table = document.getElementById('studentsTable');
        const rows = table.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            if (cells.length > 1) {
                const data = [
                    cells[1].textContent.trim(),
                    cells[2].textContent.trim(),
                    cells[3].textContent.trim(),
                    cells[4].textContent.includes('Canteen') ? 'Yes' : 'No',
                    cells[4].textContent.includes('Bus') ? 'Yes' : 'No',
                    cells[5].textContent.trim(),
                    cells[6].textContent.trim()
                ];
                csv += data.join(',') + '\n';
            }
        });
        
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'weekly_fee_students_' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
    }
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
