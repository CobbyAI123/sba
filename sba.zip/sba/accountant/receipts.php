<?php
// accountant/receipts.php - Print Student Payment Receipts
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Receipts';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get school information
$school_info = null;
try {
    $stmt = $db->prepare("SELECT * FROM schools WHERE school_id = ?");
    $stmt->execute([$school_id]);
    $school_info = $stmt->fetch();
} catch (PDOException $e) {
    $school_info = null;
}

// Get all classes for filter
$classes = [];
try {
    $stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
    $stmt->execute([$school_id]);
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $classes = [];
}

// Get search and filter parameters
$search_query = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';
$filter_class = isset($_GET['class_id']) ? sanitize_input($_GET['class_id']) : '';
$filter_amount = isset($_GET['amount']) && !empty($_GET['amount']) ? (float)$_GET['amount'] : null;

// Get all students with filters
$students = [];
try {
    $query = "
        SELECT DISTINCT s.student_id, s.admission_number, u.first_name, u.last_name, c.class_name, s.class_id
        FROM students s
        INNER JOIN users u ON s.user_id = u.user_id
        LEFT JOIN classes c ON s.class_id = c.class_id";
    
    // Join payments if filtering by amount
    if ($filter_amount) {
        $query .= " INNER JOIN payments p ON s.student_id = p.student_id AND p.amount = ?";
    }
    
    $query .= " WHERE s.school_id = ?";
    $params = [];
    
    if ($filter_amount) {
        $params[] = $filter_amount;
    }
    $params[] = $school_id;
    
    // Apply search filter
    if ($search_query) {
        $query .= " AND (u.first_name LIKE ? OR u.last_name LIKE ? OR s.admission_number LIKE ? OR CONCAT(u.first_name, ' ', u.last_name) LIKE ?)";
        $search_param = '%' . $search_query . '%';
        $params[] = $search_param;
        $params[] = $search_param;
        $params[] = $search_param;
        $params[] = $search_param;
    }
    
    // Apply class filter
    if ($filter_class) {
        $query .= " AND s.class_id = ?";
        $params[] = $filter_class;
    }
    
    $query .= " ORDER BY u.first_name, u.last_name";
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $students = $stmt->fetchAll();
} catch (PDOException $e) {
    $students = [];
}

// Get payment records for selected student
$payments = [];
$selected_student = null;
$student_id = isset($_GET['student_id']) ? sanitize_input($_GET['student_id']) : '';

if ($student_id) {
    try {
        // Get student info
        $stmt = $db->prepare("
            SELECT s.*, c.class_name, u.first_name, u.last_name, u.email
            FROM students s
            LEFT JOIN classes c ON s.class_id = c.class_id
            INNER JOIN users u ON s.user_id = u.user_id
            WHERE s.student_id = ? AND s.school_id = ?
        ");
        $stmt->execute([$student_id, $school_id]);
        $selected_student = $stmt->fetch();
        
        // Get payment records
        $date_from = isset($_GET['date_from']) ? sanitize_input($_GET['date_from']) : '';
        $date_to = isset($_GET['date_to']) ? sanitize_input($_GET['date_to']) : '';
        
        $query = "
            SELECT p.*
            FROM payments p
            WHERE p.student_id = ? AND p.school_id = ?
        ";
        $params = [$student_id, $school_id];
        
        if ($date_from) {
            $query .= " AND p.payment_date >= ?";
            $params[] = $date_from;
        }
        
        if ($date_to) {
            $query .= " AND p.payment_date <= ?";
            $params[] = $date_to;
        }
        
        $query .= " ORDER BY p.payment_date DESC";
        
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $payments = $stmt->fetchAll();
    } catch (PDOException $e) {
        $payments = [];
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
        @page {
            size: A4;
            margin: 0;
        }
        
        body {
            margin: 0;
            padding: 0;
        }
        
        .receipt-container {
            background: white;
            color: black;
            padding: 1px;
            margin: 0;
            box-sizing: border-box;
            width: 210mm;  /* A4 width */
            min-height: 297mm; /* A4 height */
            page-break-after: always;
            page-break-inside: avoid;
            font-size: 11px;
        }
        
        .receipt-wrapper {
            padding: 15px;
            height: 100%;
        }
    
        .school-header {
            text-align: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #2196F3;
        }
        
        .school-logo {
            max-width: 60px;
            max-height: 60px;
            margin-bottom: 8px;
        }
        
        .school-name {
            font-size: 18px;
            font-weight: 700;
            margin: 5px 0;
            color: #1976D2;
        }
        
        .school-details {
            font-size: 10px;
            color: #666;
            line-height: 1.4;
        }
    
        .receipt-header {
            text-align: center;
            margin-bottom: 15px;
            padding: 8px;
            background: #f5f5f5;
            border-radius: 5px;
        }
    
        .receipt-title {
            font-size: 16px;
            font-weight: 700;
            margin: 5px 0;
            color: #1976D2;
        }
    
        .receipt-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 15px;
        }
    
        .receipt-section {
            border: 1px solid #ddd;
            padding: 8px;
            border-radius: 5px;
            font-size: 10px;
        }
    
        .receipt-section-title {
            font-weight: 600;
            margin-bottom: 6px;
            border-bottom: 1px solid #2196F3;
            padding-bottom: 3px;
            font-size: 11px;
        }
    
        .receipt-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 4px;
            font-size: 10px;
        }
    
        .receipt-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            font-size: 10px;
        }
    
        .receipt-table th {
            background: #f5f5f5;
            padding: 6px 8px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #2196F3;
            font-size: 10px;
        }
    
        .receipt-table td {
            padding: 5px 8px;
            border-bottom: 1px solid #ddd;
        }
    
        .receipt-table tr:last-child td {
            border-bottom: 2px solid #2196F3;
        }
    
        .receipt-total {
            display: flex;
            justify-content: flex-end;
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 15px;
            padding: 8px;
            background: #f9f9f9;
            border-radius: 5px;
        }
        
        .receipt-footer {
            text-align: center;
            font-size: 9px;
            color: #666;
            border-top: 1px solid #ddd;
            padding-top: 10px;
            margin-top: 15px;
        }
    
        @media print {
            .no-print {
                display: none !important;
            }
            
            body {
                margin: 0;
                padding: 0;
            }
    
            .receipt-container {
                box-shadow: none;
                margin: 0;
                padding: 0;
                width: 100%;
                min-height: auto;
            }
            
            @page {
                margin: 0;
                padding: 1px;
            }
        }
        
        /* Letter size alternative (8.5 x 11 inches) */
        @media print and (max-width: 8.5in) {
            .receipt-container {
                width: 8.5in;
                min-height: 11in;
            }
        }
    </style>
    
    <!-- Page Header -->
    <div class="card no-print" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #1976D2); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-receipt"></i> Print Receipts
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Generate and print payment receipts for students
            </p>
        </div>
    </div>
    
    <!-- Search Form -->
    <div class="card no-print" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-search"></i> Search & Filter</h3>
        </div>
        <div style="padding: 20px;">
            <!-- Search and Class Filter Row -->
            <div style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 15px; align-items: end; margin-bottom: 20px;">
                <div class="form-group">
                    <label for="search_input"><i class="fas fa-search"></i> Search by Student Name or ID</label>
                    <input type="text" id="search_input" placeholder="Enter student name or admission number..." value="<?php echo htmlspecialchars($search_query); ?>" style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 5px;">
                </div>
                
                <div class="form-group">
                    <label for="class_filter"><i class="fas fa-users"></i> Filter by Class</label>
                    <select id="class_filter" style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 5px;">
                        <option value="">-- All Classes --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>" <?php echo $filter_class == $class['class_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="amount_filter"><i class="fas fa-money-bill"></i> Amount Paid</label>
                    <input type="number" id="amount_filter" placeholder="e.g. 500" step="0.01" min="0" value="<?php echo $filter_amount ? htmlspecialchars($filter_amount) : ''; ?>" style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 5px;">
                </div>
                
                <button onclick="applySearchFilter()" class="btn btn-primary" style="height: 45px; padding: 0 25px;">
                    <i class="fas fa-search"></i> Search
                </button>
            </div>
            
            <?php if ($search_query || $filter_class || $filter_amount): ?>
                <div style="margin-bottom: 15px; padding: 10px; background: #e3f2fd; border-left: 4px solid #2196F3; border-radius: 4px;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <strong><i class="fas fa-filter"></i> Active Filters:</strong>
                            <?php if ($search_query): ?>
                                <span class="badge badge-info" style="margin-left: 10px;">Search: "<?php echo htmlspecialchars($search_query); ?>"</span>
                            <?php endif; ?>
                            <?php if ($filter_class): ?>
                                <?php 
                                $selected_class = array_filter($classes, fn($c) => $c['class_id'] == $filter_class);
                                $selected_class = reset($selected_class);
                                ?>
                                <span class="badge badge-info" style="margin-left: 10px;">Class: <?php echo htmlspecialchars($selected_class['class_name'] ?? 'Unknown'); ?></span>
                            <?php endif; ?>
                            <?php if ($filter_amount): ?>
                                <span class="badge badge-info" style="margin-left: 10px;">Amount: ₵<?php echo number_format($filter_amount, 2); ?></span>
                            <?php endif; ?>
                            <span style="margin-left: 10px; color: #666;">(<?php echo count($students); ?> student<?php echo count($students) != 1 ? 's' : ''; ?> found)</span>
                        </div>
                        <a href="<?php echo APP_URL; ?>/accountant/receipts.php" class="btn btn-sm btn-secondary">
                            <i class="fas fa-times"></i> Clear Filters
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Student and Date Filter Row -->
            <div style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 15px; align-items: end;">
                <div class="form-group">
                    <label for="student_select">Select Student *</label>
                    <select id="student_select" onchange="filterReceipts()" style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 5px;">
                        <option value="">-- Select Student --</option>
                        <?php foreach ($students as $student): ?>
                            <option value="<?php echo $student['student_id']; ?>" <?php echo $student_id == $student['student_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name'] . ' (' . $student['admission_number'] . ')'); ?>
                                <?php if ($student['class_name']): ?> - <?php echo htmlspecialchars($student['class_name']); ?><?php endif; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="date_from">From Date</label>
                    <input type="date" id="date_from" value="<?php echo isset($_GET['date_from']) ? $_GET['date_from'] : ''; ?>" style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 5px;">
                </div>
                
                <div class="form-group">
                    <label for="date_to">To Date</label>
                    <input type="date" id="date_to" value="<?php echo isset($_GET['date_to']) ? $_GET['date_to'] : ''; ?>" style="width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 5px;">
                </div>
                
                <button onclick="applyFilter()" class="btn btn-primary" style="height: 45px; padding: 0 25px;">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </div>
        </div>
    </div>
    
    <?php if ($selected_student && count($payments) > 0): ?>
        <!-- Receipts Display -->
        <?php foreach ($payments as $payment): ?>
            <div class="receipt-container">
                <div class="receipt-wrapper">
                    <!-- School Header -->
                    <div class="school-header">
                        <?php if ($school_info && !empty($school_info['logo'])): ?>
                            <img src="<?php echo APP_URL . '/uploads/logos/' . $school_info['logo']; ?>" alt="School Logo" class="school-logo">
                        <?php endif; ?>
                        <div class="school-name"><?php echo strtoupper($school_info['school_name'] ?? 'SCHOOL NAME'); ?></div>
                        <div class="school-details">
                            <?php if ($school_info): ?>
                                <?php if (!empty($school_info['address'])): ?>
                                    <?php echo htmlspecialchars($school_info['address']); ?><br>
                                <?php endif; ?>
                                <?php if (!empty($school_info['phone'])): ?>
                                    Tel: <?php echo htmlspecialchars($school_info['phone']); ?>
                                <?php endif; ?>
                                <?php if (!empty($school_info['email'])): ?>
                                    | Email: <?php echo htmlspecialchars($school_info['email']); ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Receipt Header -->
                    <div class="receipt-header">
                        <div class="receipt-title">PAYMENT RECEIPT</div>
                        <div style="font-size: 10px; color: #666;">School Fees Payment Receipt</div>
                    </div>
                    
                    <!-- Receipt Info -->
                    <div class="receipt-info">
                        <div class="receipt-section">
                            <div class="receipt-section-title">Student Information</div>
                            <div class="receipt-item">
                                <span>Name:</span>
                                <strong><?php echo $selected_student['first_name'] . ' ' . $selected_student['last_name']; ?></strong>
                            </div>
                            <div class="receipt-item">
                                <span>Admission No:</span>
                                <strong><?php echo $selected_student['admission_number']; ?></strong>
                            </div>
                            <div class="receipt-item">
                                <span>Class:</span>
                                <strong><?php echo $selected_student['class_name'] ?? 'N/A'; ?></strong>
                            </div>
                        </div>
                        
                        <div class="receipt-section">
                            <div class="receipt-section-title">Payment Details</div>
                            <div class="receipt-item">
                                <span>Date:</span>
                                <strong><?php echo date('d M, Y', strtotime($payment['payment_date'])); ?></strong>
                            </div>
                            <div class="receipt-item">
                                <span>Receipt No:</span>
                                <strong><?php echo str_pad($payment['payment_id'], 6, '0', STR_PAD_LEFT); ?></strong>
                            </div>
                            <div class="receipt-item">
                                <span>Status:</span>
                                <strong style="color: <?php echo $payment['status'] == 'paid' ? '#4CAF50' : '#FF9800'; ?>;">
                                    <?php echo strtoupper($payment['status']); ?>
                                </strong>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Payment Table -->
                    <table class="receipt-table">
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th>Payment Type</th>
                                <th style="text-align: right;">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>School Fees Payment</td>
                                <td><?php echo ucfirst($payment['payment_type'] ?? 'Tuition'); ?></td>
                                <td style="text-align: right; font-weight: 600;"><?php echo format_currency($payment['amount']); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    
                    <!-- Total -->
                    <div class="receipt-total">
                        <span>Total Amount Paid: <?php echo format_currency($payment['amount']); ?></span>
                    </div>
                    
                    <!-- Footer -->
                    <div class="receipt-footer">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin: 20px 0;">
                            <div style="text-align: center; border-top: 1px solid #333; padding-top: 10px;">
                                <p style="margin: 5px 0; font-weight: 600; font-size: 10px;">ACCOUNTANT SIGNATURE</p>
                                <p style="margin: 5px 0; font-size: 9px;">Finance Officer</p>
                            </div>
                            <div style="text-align: center; border-top: 1px solid #333; padding-top: 10px;">
                                <p style="margin: 5px 0; font-weight: 600; font-size: 10px;">AUTHORIZED BY</p>
                                <p style="margin: 5px 0; font-size: 9px;">School Principal</p>
                            </div>
                        </div>
                        <p style="margin: 5px 0; font-size: 9px;">Generated on <?php echo date('d M, Y H:i A'); ?></p>
                        <p style="margin: 5px 0; font-style: italic; font-size: 9px;">This is an official payment receipt. Please keep for your records.</p>
                        <p style="margin: 5px 0; font-weight: 600; font-size: 10px;">Thank you for your payment!</p>
                        <?php if ($school_info && !empty($school_info['website'])): ?>
                            <p style="margin: 3px 0; font-size: 9px;"><?php echo htmlspecialchars($school_info['website']); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        
        <!-- Print Button -->
        <div class="no-print" style="margin-top: 30px; display: flex; gap: 10px; justify-content: center;">
            <button onclick="window.print()" class="btn btn-primary" style="padding: 12px 30px;">
                <i class="fas fa-print"></i> Print Receipts
            </button>
            <a href="<?php echo APP_URL; ?>/accountant/receipts.php" class="btn btn-secondary" style="padding: 12px 30px; text-decoration: none;">
                <i class="fas fa-redo"></i> Search Again
            </a>
        </div>
    <?php elseif ($selected_student): ?>
        <div class="card no-print">
            <div style="padding: 40px; text-align: center; color: var(--text-secondary);">
                <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 15px; display: block; opacity: 0.5;"></i>
                <h3>No Payments Found</h3>
                <p>No payment records found for the selected filters.</p>
            </div>
        </div>
    <?php elseif (!$student_id): ?>
        <div class="card no-print">
            <div style="padding: 60px; text-align: center; color: var(--text-secondary);">
                <i class="fas fa-search" style="font-size: 48px; margin-bottom: 15px; display: block; opacity: 0.5;"></i>
                <h3>Select a Student</h3>
                <p>Choose a student and date range to view and print their payment receipts.</p>
            </div>
        </div>
    <?php endif; ?>
    
    <script>
    function applySearchFilter() {
        const searchQuery = document.getElementById('search_input').value;
        const classId = document.getElementById('class_filter').value;
        const amount = document.getElementById('amount_filter').value;
        
        let url = '<?php echo APP_URL; ?>/accountant/receipts.php';
        let params = [];
        
        if (searchQuery) params.push('search=' + encodeURIComponent(searchQuery));
        if (classId) params.push('class_id=' + encodeURIComponent(classId));
        if (amount) params.push('amount=' + encodeURIComponent(amount));
        
        if (params.length > 0) {
            url += '?' + params.join('&');
        }
        
        window.location.href = url;
    }
    
    function applyFilter() {
        const studentId = document.getElementById('student_select').value;
        const dateFrom = document.getElementById('date_from').value;
        const dateTo = document.getElementById('date_to').value;
        const searchQuery = document.getElementById('search_input').value;
        const classId = document.getElementById('class_filter').value;
        const amount = document.getElementById('amount_filter').value;
        
        if (!studentId) {
            alert('Please select a student');
            return;
        }
        
        let url = '?student_id=' + studentId;
        if (dateFrom) url += '&date_from=' + dateFrom;
        if (dateTo) url += '&date_to=' + dateTo;
        if (searchQuery) url += '&search=' + encodeURIComponent(searchQuery);
        if (classId) url += '&class_id=' + encodeURIComponent(classId);
        if (amount) url += '&amount=' + encodeURIComponent(amount);
        
        window.location.href = url;
    }
    
    function filterReceipts() {
        const studentId = document.getElementById('student_select').value;
        const searchQuery = document.getElementById('search_input').value;
        const classId = document.getElementById('class_filter').value;
        const amount = document.getElementById('amount_filter').value;
        
        if (studentId) {
            let url = '?student_id=' + studentId;
            if (searchQuery) url += '&search=' + encodeURIComponent(searchQuery);
            if (classId) url += '&class_id=' + encodeURIComponent(classId);
            if (amount) url += '&amount=' + encodeURIComponent(amount);
            window.location.href = url;
        }
    }
    
    // Enable Enter key to trigger search
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('search_input');
        if (searchInput) {
            searchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    applySearchFilter();
                }
            });
        }
    });
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
