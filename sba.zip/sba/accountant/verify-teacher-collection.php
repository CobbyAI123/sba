<?php
// accountant/verify-teacher-collection.php - Verify Teacher's Daily Collection Details
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Verify Teacher Collection';
$current_user = check_permission(['accountant', 'admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get parameters
$teacher_id = isset($_GET['teacher_id']) ? intval($_GET['teacher_id']) : 0;
$collection_type = isset($_GET['type']) ? sanitize_input($_GET['type']) : '';
$date = isset($_GET['date']) ? sanitize_input($_GET['date']) : date('Y-m-d');

if (!$teacher_id || !$collection_type) {
    set_message('error', 'Missing required parameters');
    redirect(APP_URL . '/accountant/teacher-collections.php');
    exit;
}

// Get teacher info
$stmt = $db->prepare("SELECT first_name, last_name FROM users WHERE user_id = ? AND school_id = ?");
$stmt->execute([$teacher_id, $school_id]);
$teacher = $stmt->fetch();

if (!$teacher) {
    set_message('error', 'Teacher not found');
    redirect(APP_URL . '/accountant/teacher-collections.php');
    exit;
}

// Get detailed collection breakdown
if ($collection_type === 'canteen') {
    $stmt = $db->prepare("
        SELECT 
            dc.*,
            s.student_id,
            CONCAT(u.first_name, ' ', u.last_name) as student_name,
            c.class_name,
            dc.canteen_amount,
            dc.canteen_paid
        FROM daily_collections dc
        INNER JOIN students s ON dc.student_id = s.student_id
        INNER JOIN users u ON s.user_id = u.user_id
        INNER JOIN classes c ON dc.class_id = c.class_id
        WHERE dc.marked_by = ?
        AND dc.school_id = ?
        AND dc.collection_date = ?
        AND dc.canteen_paid = 1
        ORDER BY c.class_name, u.first_name, u.last_name
    ");
} else { // bus
    $stmt = $db->prepare("
        SELECT 
            dc.*,
            s.student_id,
            CONCAT(u.first_name, ' ', u.last_name) as student_name,
            c.class_name,
            dc.bus_amount,
            dc.bus_paid
        FROM daily_collections dc
        INNER JOIN students s ON dc.student_id = s.student_id
        INNER JOIN users u ON s.user_id = u.user_id
        INNER JOIN classes c ON dc.class_id = c.class_id
        WHERE dc.marked_by = ?
        AND dc.school_id = ?
        AND dc.collection_date = ?
        AND dc.bus_paid = 1
        ORDER BY c.class_name, u.first_name, u.last_name
    ");
}

$stmt->execute([$teacher_id, $school_id, $date]);
$collections = $stmt->fetchAll();

// Calculate totals
$total_amount = 0;
$student_count = 0;

foreach ($collections as $collection) {
    if ($collection_type === 'canteen') {
        $total_amount += floatval($collection['canteen_amount']);
    } else {
        $total_amount += floatval($collection['bus_amount']);
    }
    $student_count++;
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .verify-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 30px;
        border-radius: 15px;
        margin-bottom: 30px;
    }
    .stat-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin: 20px 0;
    }
    .stat-card {
        background: var(--bg-card);
        padding: 20px;
        border-radius: 10px;
        border-left: 4px solid var(--primary-blue);
        box-shadow: var(--shadow-sm);
    }
    .stat-value {
        font-size: 32px;
        font-weight: bold;
        color: var(--primary-blue);
        margin: 10px 0;
    }
    .stat-label {
        font-size: 14px;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .collection-list {
        background: var(--bg-card);
        border-radius: 10px;
        overflow: hidden;
    }
    </style>
    
    <div class="verify-header">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h1 style="margin: 0 0 10px 0;">
                    <i class="fas fa-search-dollar"></i> Collection Verification
                </h1>
                <p style="margin: 0; opacity: 0.9; font-size: 18px;">
                    Detailed breakdown of teacher's daily collections
                </p>
            </div>
            <a href="teacher-collections.php" class="btn btn-light">
                <i class="fas fa-arrow-left"></i> Back to Collections
            </a>
        </div>
    </div>
    
    <!-- Summary Cards -->
    <div class="stat-grid">
        <div class="stat-card">
            <div class="stat-label">Teacher</div>
            <div class="stat-value" style="font-size: 22px;">
                <?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']); ?>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-label">Collection Type</div>
            <div class="stat-value" style="font-size: 22px; color: #10B981;">
                <?php echo ucfirst($collection_type); ?>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-label">Date</div>
            <div class="stat-value" style="font-size: 22px; color: #F59E0B;">
                <?php echo date('M d, Y', strtotime($date)); ?>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-label">Students Collected</div>
            <div class="stat-value"><?php echo $student_count; ?></div>
        </div>
        
        <div class="stat-card" style="border-left-color: #10B981;">
            <div class="stat-label">Total Amount</div>
            <div class="stat-value" style="color: #10B981;">
                <?php echo format_currency($total_amount); ?>
            </div>
        </div>
    </div>
    
    <?php if (empty($collections)): ?>
        <div class="alert alert-warning" style="text-align: center; padding: 40px;">
            <i class="fas fa-inbox" style="font-size: 64px; color: #F59E0B; display: block; margin-bottom: 20px;"></i>
            <h2>No Collections Found</h2>
            <p style="font-size: 16px; color: var(--text-secondary);">
                This teacher did not collect any <?php echo $collection_type; ?> fees on <?php echo date('M d, Y', strtotime($date)); ?>.
            </p>
            <a href="teacher-collections.php" class="btn btn-primary" style="margin-top: 20px;">
                <i class="fas fa-arrow-left"></i> Back to Collections
            </a>
        </div>
    <?php else: ?>
        <!-- Detailed Collection List -->
        <div class="card">
            <div class="card-header">
                <h3>
                    <i class="fas fa-list-alt"></i> 
                    Student-by-Student Collection Breakdown
                </h3>
                <p style="margin: 5px 0 0 0; color: var(--text-secondary);">
                    This is the exact breakdown from the daily collections page
                </p>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th>Student Name</th>
                            <th>Class</th>
                            <th style="text-align: right;">Amount</th>
                            <th style="text-align: center;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $row_num = 1;
                        foreach ($collections as $collection): 
                            $amount = $collection_type === 'canteen' ? 
                                     floatval($collection['canteen_amount']) : 
                                     floatval($collection['bus_amount']);
                        ?>
                            <tr>
                                <td><?php echo $row_num++; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($collection['student_name']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($collection['class_name']); ?></td>
                                <td style="text-align: right;">
                                    <strong style="color: #10B981; font-size: 16px;">
                                        <?php echo format_currency($amount); ?>
                                    </strong>
                                </td>
                                <td style="text-align: center;">
                                    <span style="background: #10B981; color: white; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold;">
                                        <i class="fas fa-check"></i> PAID
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr style="background: var(--bg-secondary); font-weight: bold; font-size: 18px;">
                            <td colspan="3" style="text-align: right; padding: 15px;">
                                <strong>TOTAL COLLECTED:</strong>
                            </td>
                            <td style="text-align: right; padding: 15px;">
                                <strong style="color: #10B981; font-size: 22px;">
                                    <?php echo format_currency($total_amount); ?>
                                </strong>
                            </td>
                            <td style="text-align: center;">
                                <span style="background: #10B981; color: white; padding: 6px 15px; border-radius: 20px; font-size: 13px;">
                                    <?php echo $student_count; ?> Students
                                </span>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    
        <!-- Action Box -->
        <div style="background: #E8F5E9; border-left: 4px solid #10B981; padding: 25px; border-radius: 10px; margin-top: 30px;">
            <div style="display: flex; gap: 20px; align-items: center;">
                <div style="font-size: 48px; color: #10B981;">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div style="flex: 1;">
                    <h3 style="margin: 0 0 10px 0; color: #2E7D32;">
                        This is the Correct Amount to Record
                    </h3>
                    <p style="margin: 0; color: #2E7D32; font-size: 15px; line-height: 1.6;">
                        The teacher should pay <strong style="font-size: 20px;"><?php echo format_currency($total_amount); ?></strong> for 
                        <?php echo $collection_type; ?> collections on <?php echo date('M d, Y', strtotime($date)); ?>.
                        This is the exact total from <?php echo $student_count; ?> students who paid.
                    </p>
                </div>
                <div>
                    <a href="teacher-collections.php" class="btn btn-success" style="padding: 14px 30px; font-size: 16px;">
                        <i class="fas fa-arrow-left"></i> OK, Record This Amount
                    </a>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    </div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
