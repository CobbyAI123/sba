<?php
// accountant/expenses.php - Track School Expenses
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Track Expenses';
$current_user = check_permission(['accountant', 'admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $expense_type = sanitize_input($_POST['expense_type']);
            $description = sanitize_input($_POST['description']);
            $amount = (float)$_POST['amount'];
            $expense_date = sanitize_input($_POST['expense_date']);
            
            // Validation
            if (empty($expense_type)) {
                set_message('error', 'Expense type is required');
            } elseif ($amount <= 0) {
                set_message('error', 'Amount must be greater than 0');
            } elseif (strtotime($expense_date) > strtotime(date('Y-m-d'))) {
                set_message('error', 'Expense date cannot be in the future');
            } else {
                try {
                    $db->beginTransaction();
                    
                    $stmt = $db->prepare("
                        INSERT INTO expenses (school_id, expense_type, description, amount, expense_date, status)
                        VALUES (?, ?, ?, ?, ?, 'pending')
                    ");
                    $stmt->execute([$school_id, $expense_type, $description, $amount, $expense_date]);
                    
                    $db->commit();
                    
                    log_activity($current_user['user_id'], "Added expense: $expense_type", 'expenses', $db->lastInsertId());
                    set_message('success', 'Expense recorded successfully!');
                    redirect(APP_URL . '/accountant/expenses.php');
                } catch (PDOException $e) {
                    $db->rollBack();
                    set_message('error', 'Error recording expense: ' . $e->getMessage());
                }
            }
        } elseif ($_POST['action'] == 'edit') {
            // Only admins/super_admins and accountants can edit
            if (!in_array($current_user['role'], ['accountant', 'admin', 'super_admin'])) {
                set_message('error', 'You do not have permission to edit expenses');
                redirect(APP_URL . '/accountant/expenses.php');
                exit;
            }
            
            $expense_id = (int)$_POST['expense_id'];
            $expense_type = sanitize_input($_POST['expense_type']);
            $description = sanitize_input($_POST['description']);
            $amount = (float)$_POST['amount'];
            $expense_date = sanitize_input($_POST['expense_date']);
            
            // Validation
            if (empty($expense_type)) {
                set_message('error', 'Expense type is required');
            } elseif ($amount <= 0) {
                set_message('error', 'Amount must be greater than 0');
            } else {
                try {
                    $stmt = $db->prepare("
                        UPDATE expenses 
                        SET expense_type = ?, description = ?, amount = ?, expense_date = ?
                        WHERE expense_id = ? AND school_id = ?
                    ");
                    $stmt->execute([$expense_type, $description, $amount, $expense_date, $expense_id, $school_id]);
                    
                    log_activity($current_user['user_id'], "Updated expense: $expense_type", 'expenses', $expense_id);
                    set_message('success', 'Expense updated successfully!');
                    redirect(APP_URL . '/accountant/expenses.php');
                } catch (PDOException $e) {
                    set_message('error', 'Error updating expense: ' . $e->getMessage());
                }
            }
        } elseif ($_POST['action'] == 'approve') {
            $expense_id = (int)$_POST['expense_id'];
            
            try {
                $stmt = $db->prepare("UPDATE expenses SET status = 'approved' WHERE expense_id = ? AND school_id = ?");
                $stmt->execute([$expense_id, $school_id]);
                
                log_activity($current_user['user_id'], "Approved expense", 'expenses', $expense_id);
                set_message('success', 'Expense approved successfully!');
                redirect(APP_URL . '/accountant/expenses.php');
            } catch (PDOException $e) {
                set_message('error', 'Error approving expense: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'reject') {
            $expense_id = (int)$_POST['expense_id'];
            
            try {
                $stmt = $db->prepare("UPDATE expenses SET status = 'rejected' WHERE expense_id = ? AND school_id = ?");
                $stmt->execute([$expense_id, $school_id]);
                
                log_activity($current_user['user_id'], "Rejected expense", 'expenses', $expense_id);
                set_message('success', 'Expense rejected successfully!');
                redirect(APP_URL . '/accountant/expenses.php');
            } catch (PDOException $e) {
                set_message('error', 'Error rejecting expense: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'delete') {
            // Only admins/super_admins and accountants can delete
            if (!in_array($current_user['role'], ['accountant', 'admin', 'super_admin'])) {
                set_message('error', 'You do not have permission to delete expenses');
                redirect(APP_URL . '/accountant/expenses.php');
                exit;
            }
            
            $expense_id = (int)$_POST['expense_id'];
            
            try {
                $stmt = $db->prepare("DELETE FROM expenses WHERE expense_id = ? AND school_id = ?");
                $stmt->execute([$expense_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted expense", 'expenses', $expense_id);
                set_message('success', 'Expense deleted successfully!');
                redirect(APP_URL . '/accountant/expenses.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting expense: ' . $e->getMessage());
            }
        }
    }
}

// Get expense types from settings or use defaults
try {
    $stmt = $db->prepare("SELECT setting_value FROM settings WHERE school_id = ? AND setting_key = 'expense_types'");
    $stmt->execute([$school_id]);
    $expense_types_setting = $stmt->fetch();
    $expense_types = $expense_types_setting && !empty($expense_types_setting['setting_value']) 
        ? explode(',', $expense_types_setting['setting_value'])
        : ['Staff Salary', 'Utilities', 'Maintenance', 'Supplies', 'Transport', 'Other'];
} catch (Exception $e) {
    $expense_types = ['Staff Salary', 'Utilities', 'Maintenance', 'Supplies', 'Transport', 'Other'];
}

// Get statistics
$stmt = $db->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE school_id = ? AND status = 'approved'");
$stmt->execute([$school_id]);
$total_approved = $stmt->fetch()['total'] ?? 0;

$stmt = $db->prepare("SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE school_id = ? AND status = 'pending'");
$stmt->execute([$school_id]);
$total_pending = $stmt->fetch()['total'] ?? 0;

// Get all expenses
$stmt = $db->prepare("
    SELECT * FROM expenses 
    WHERE school_id = ?
    ORDER BY expense_date DESC
");
$stmt->execute([$school_id]);
$expenses = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Statistics -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo format_currency($total_approved); ?></h3>
                <p>Approved Expenses</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon orange">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo format_currency($total_pending); ?></h3>
                <p>Pending Approval</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-list"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo count($expenses); ?></h3>
                <p>Total Expenses</p>
            </div>
        </div>
    </div>
    
    <!-- Action Bar -->
    <div style="margin-bottom: 30px;">
        <button type="button" onclick="openAddModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Record Expense
        </button>
    </div>
    
    <!-- Expenses Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-receipt"></i> Expenses</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Description</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($expenses) > 0): ?>
                        <?php foreach ($expenses as $expense): ?>
                            <tr>
                                <td><?php echo date('M d, Y', strtotime($expense['expense_date'])); ?></td>
                                <td><strong><?php echo $expense['expense_type']; ?></strong></td>
                                <td><?php echo substr($expense['description'] ?? '', 0, 40) . (strlen($expense['description'] ?? '') > 40 ? '...' : ''); ?></td>
                                <td><?php echo format_currency($expense['amount']); ?></td>
                                <td>
                                    <?php 
                                    $status_class = $expense['status'] == 'approved' ? 'success' : ($expense['status'] == 'pending' ? 'warning' : 'danger');
                                    ?>
                                    <span class="badge badge-<?php echo $status_class; ?>"><?php echo ucfirst($expense['status']); ?></span>
                                </td>
                                <td>
                                    <?php if ($current_user['role'] == 'admin' || $current_user['role'] == 'super_admin'): ?>
                                        <!-- Admin Actions -->
                                        <?php if ($expense['status'] == 'pending'): ?>
                                            <button onclick="confirmApprove(<?php echo $expense['expense_id']; ?>)" class="btn btn-sm btn-success" title="Approve">
                                                <i class="fas fa-check"></i> Approve
                                            </button>
                                            <button onclick="confirmReject(<?php echo $expense['expense_id']; ?>)" class="btn btn-sm btn-warning" title="Reject">
                                                <i class="fas fa-ban"></i> Reject
                                            </button>
                                        <?php else: ?>
                                            <button onclick="openEditModal(<?php echo htmlspecialchars(json_encode($expense)); ?>)" class="btn btn-sm btn-info" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                        <?php endif; ?>
                                        <button onclick="confirmDelete(<?php echo $expense['expense_id']; ?>)" class="btn btn-sm btn-danger" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    <?php else: ?>
                                        <!-- Accountant Actions -->
                                        <button onclick="openEditModal(<?php echo htmlspecialchars(json_encode($expense)); ?>)" class="btn btn-sm btn-info" title="Edit">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <button onclick="confirmDelete(<?php echo $expense['expense_id']; ?>)" class="btn btn-sm btn-danger" title="Delete">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 40px;">
                                <i class="fas fa-receipt" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 10px; display: block;"></i>
                                <h3>No Expenses</h3>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Add Expense Modal -->
    <div id="expenseModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Record Expense</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Expense Type *</label>
                        <select name="expense_type" required>
                            <option value="">Select Type</option>
                            <?php foreach ($expense_types as $type): ?>
                                <option value="<?php echo htmlspecialchars(trim($type)); ?>"><?php echo htmlspecialchars(trim($type)); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Amount (₵) *</label>
                        <input type="number" name="amount" step="0.01" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Expense Date *</label>
                    <input type="date" name="expense_date" required>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="3"></textarea>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Record Expense</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Expense Modal -->
    <div id="editExpenseModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Edit Expense</h2>
                <button onclick="closeEditModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="editExpenseForm">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="expense_id" id="edit_expense_id">
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Expense Type *</label>
                        <select name="expense_type" id="edit_expense_type" required>
                            <option value="">Select Type</option>
                            <?php foreach ($expense_types as $type): ?>
                                <option value="<?php echo htmlspecialchars(trim($type)); ?>"><?php echo htmlspecialchars(trim($type)); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Amount (₵) *</label>
                        <input type="number" name="amount" id="edit_amount" step="0.01" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Expense Date *</label>
                    <input type="date" name="expense_date" id="edit_expense_date" required>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" id="edit_description" rows="3"></textarea>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Expense</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Approve Confirmation Modal -->
    <div id="approveModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
        <div style="max-width: 400px; margin: 200px auto; background: var(--bg-card); border-radius: 15px; padding: 30px; text-align: center;">
            <i class="fas fa-check-circle" style="font-size: 60px; color: #10B981; margin-bottom: 20px;"></i>
            <h2>Approve Expense?</h2>
            <p style="color: var(--text-secondary); margin: 15px 0;">Are you sure you want to approve this expense?</p>
            
            <form method="POST" id="approveForm">
                <input type="hidden" name="action" value="approve">
                <input type="hidden" name="expense_id" id="approve_expense_id">
                
                <div style="display: flex; gap: 10px; justify-content: center; margin-top: 25px;">
                    <button type="button" class="btn btn-secondary" onclick="closeApproveModal()">Cancel</button>
                    <button type="submit" class="btn btn-success"><i class="fas fa-check"></i> Approve</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Reject Confirmation Modal -->
    <div id="rejectModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
        <div style="max-width: 400px; margin: 200px auto; background: var(--bg-card); border-radius: 15px; padding: 30px; text-align: center;">
            <i class="fas fa-ban" style="font-size: 60px; color: #F59E0B; margin-bottom: 20px;"></i>
            <h2>Reject Expense?</h2>
            <p style="color: var(--text-secondary); margin: 15px 0;">Are you sure you want to reject this expense?</p>
            
            <form method="POST" id="rejectForm">
                <input type="hidden" name="action" value="reject">
                <input type="hidden" name="expense_id" id="reject_expense_id">
                
                <div style="display: flex; gap: 10px; justify-content: center; margin-top: 25px;">
                    <button type="button" class="btn btn-secondary" onclick="closeRejectModal()">Cancel</button>
                    <button type="submit" class="btn btn-warning"><i class="fas fa-ban"></i> Reject</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
        <div style="max-width: 400px; margin: 200px auto; background: var(--bg-card); border-radius: 15px; padding: 30px; text-align: center;">
            <i class="fas fa-exclamation-triangle" style="font-size: 60px; color: #EF4444; margin-bottom: 20px;"></i>
            <h2>Delete Expense?</h2>
            <p style="color: var(--text-secondary); margin: 15px 0;">This action cannot be undone. Are you sure you want to delete this expense?</p>
            
            <form method="POST" id="deleteForm">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="expense_id" id="delete_expense_id">
                
                <div style="display: flex; gap: 10px; justify-content: center; margin-top: 25px;">
                    <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function openAddModal() { 
        document.getElementById('expenseModal').style.display = 'block'; 
    }
    
    function closeModal() { 
        document.getElementById('expenseModal').style.display = 'none'; 
    }
    
    function openEditModal(expense) {
        document.getElementById('edit_expense_id').value = expense.expense_id;
        document.getElementById('edit_expense_type').value = expense.expense_type;
        document.getElementById('edit_amount').value = expense.amount;
        document.getElementById('edit_expense_date').value = expense.expense_date;
        document.getElementById('edit_description').value = expense.description || '';
        document.getElementById('editExpenseModal').style.display = 'block';
    }
    
    function closeEditModal() {
        document.getElementById('editExpenseModal').style.display = 'none';
    }
    
    function confirmApprove(expenseId) {
        document.getElementById('approve_expense_id').value = expenseId;
        document.getElementById('approveModal').style.display = 'block';
    }
    
    function closeApproveModal() {
        document.getElementById('approveModal').style.display = 'none';
    }
    
    function confirmReject(expenseId) {
        document.getElementById('reject_expense_id').value = expenseId;
        document.getElementById('rejectModal').style.display = 'block';
    }
    
    function closeRejectModal() {
        document.getElementById('rejectModal').style.display = 'none';
    }
    
    function confirmDelete(expenseId) {
        document.getElementById('delete_expense_id').value = expenseId;
        document.getElementById('deleteModal').style.display = 'block';
    }
    
    function closeDeleteModal() {
        document.getElementById('deleteModal').style.display = 'none';
    }
    
    window.onclick = function(e) { 
        if (e.target.id === 'expenseModal') e.target.style.display = 'none';
        if (e.target.id === 'editExpenseModal') e.target.style.display = 'none';
        if (e.target.id === 'approveModal') e.target.style.display = 'none';
        if (e.target.id === 'rejectModal') e.target.style.display = 'none';
        if (e.target.id === 'deleteModal') e.target.style.display = 'none';
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
