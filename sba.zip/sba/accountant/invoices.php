<?php
// accountant/invoices.php - Invoice Management
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Invoices';
$current_user = check_permission(['accountant', 'admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle invoice generation
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'generate') {
            $student_id = (int)$_POST['student_id'];
            $description = sanitize_input($_POST['description']);
            $amount = (float)$_POST['amount'];
            
            // Validation
            if (empty($student_id)) {
                set_message('error', 'Please select a student');
            } elseif (empty($description)) {
                set_message('error', 'Description is required');
            } elseif ($amount <= 0) {
                set_message('error', 'Amount must be greater than 0');
            } else {
                try {
                    $db->beginTransaction();
                    
                    $invoice_number = 'INV-' . $school_id . '-' . time();
                    
                    $stmt = $db->prepare("
                        INSERT INTO invoices (school_id, student_id, invoice_number, description, amount, status)
                        VALUES (?, ?, ?, ?, ?, 'pending')
                    ");
                    $stmt->execute([$school_id, $student_id, $invoice_number, $description, $amount]);
                    
                    $db->commit();
                    
                    log_activity($current_user['user_id'], "Generated invoice: $invoice_number", 'invoices', $student_id);
                    set_message('success', 'Invoice generated successfully!');
                    redirect(APP_URL . '/accountant/invoices.php');
                } catch (PDOException $e) {
                    $db->rollBack();
                    set_message('error', 'Error generating invoice: ' . $e->getMessage());
                }
            }
        }
        elseif ($_POST['action'] == 'mark_paid') {
            $invoice_id = (int)$_POST['invoice_id'];
            
            try {
                $stmt = $db->prepare("UPDATE invoices SET status = 'paid' WHERE invoice_id = ? AND school_id = ?");
                $stmt->execute([$invoice_id, $school_id]);
                
                log_activity($current_user['user_id'], "Marked invoice as paid", 'invoices', $invoice_id);
                set_message('success', 'Invoice marked as paid!');
                redirect(APP_URL . '/accountant/invoices.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating invoice: ' . $e->getMessage());
            }
        }
    }
}

// Get invoices with student details
$stmt = $db->prepare("
    SELECT 
        i.*,
        s.first_name,
        s.last_name,
        s.admission_number,
        c.class_name
    FROM invoices i
    LEFT JOIN students s ON i.student_id = s.student_id
    LEFT JOIN classes c ON s.class_id = c.class_id
    WHERE i.school_id = ?
    ORDER BY i.created_at DESC
");
$stmt->execute([$school_id]);
$invoices = $stmt->fetchAll();

// Get students for dropdown
$stmt = $db->prepare("
    SELECT s.student_id, u.first_name, u.last_name, s.admission_number, c.class_name
    FROM students s
    INNER JOIN users u ON s.user_id = u.user_id
    LEFT JOIN classes c ON s.class_id = c.class_id
    WHERE s.school_id = ? AND s.status = 'active'
    ORDER BY u.first_name, u.last_name
");
$stmt->execute([$school_id]);
$students = $stmt->fetchAll();

// Calculate statistics
$total_invoices = count($invoices);
$pending = count(array_filter($invoices, function($i) { return $i['status'] == 'pending'; }));
$paid = count(array_filter($invoices, function($i) { return $i['status'] == 'paid'; }));
$total_amount = array_sum(array_column($invoices, 'amount'));

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Statistics -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-file-invoice"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $total_invoices; ?></h3>
                <p>Total Invoices</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon orange">
                <i class="fas fa-clock"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $pending; ?></h3>
                <p>Pending</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $paid; ?></h3>
                <p>Paid</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo format_currency($total_amount); ?></h3>
                <p>Total Amount</p>
            </div>
        </div>
    </div>
    
    <!-- Action Buttons -->
    <div style="margin-bottom: 30px; display: flex; gap: 10px;">
        <button type="button" onclick="openGenerateModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Generate Invoice
        </button>
        <button type="button" onclick="printInvoices()" class="btn btn-secondary">
            <i class="fas fa-print"></i> Print All
        </button>
    </div>
    
    <!-- Invoices Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-file-invoice"></i> Invoices List</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Invoice #</th>
                        <th>Student</th>
                        <th>Class</th>
                        <th>Description</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($invoices) > 0): ?>
                        <?php foreach ($invoices as $invoice): ?>
                            <tr>
                                <td><strong><?php echo $invoice['invoice_number']; ?></strong></td>
                                <td><?php echo $invoice['first_name'] . ' ' . $invoice['last_name']; ?></td>
                                <td><?php echo $invoice['class_name'] ?: '-'; ?></td>
                                <td><?php echo $invoice['description']; ?></td>
                                <td><?php echo format_currency($invoice['amount']); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $invoice['status'] == 'paid' ? 'success' : 'warning'; ?>">
                                        <?php echo ucfirst($invoice['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($invoice['created_at'])); ?></td>
                                <td>
                                    <button type="button" class="btn btn-primary btn-sm" onclick="printInvoice('<?php echo htmlspecialchars($invoice['invoice_number']); ?>')" title="Print Invoice">
                                        <i class="fas fa-print"></i>
                                    </button>
                                    <?php if ($invoice['status'] !== 'paid'): ?>
                                        <button type="button" class="btn btn-success btn-sm" onclick="markAsPaid(<?php echo $invoice['invoice_id']; ?>, '<?php echo htmlspecialchars($invoice['invoice_number']); ?>')" title="Mark as Paid">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    <?php else: ?>
                                        <span class="badge badge-success" style="padding: 8px 12px;">Paid</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                                <i class="fas fa-file-invoice" style="font-size: 48px; margin-bottom: 10px; display: block;"></i>
                                <h3>No Invoices Yet</h3>
                                <p>Start by generating your first invoice</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Generate Invoice Modal -->
    <div id="generateModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Generate Invoice</h2>
                <button onclick="closeGenerateModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="generate">
                
                <div style="display: grid; gap: 15px;">
                    <div class="form-group">
                        <label for="student_id">Student *</label>
                        <select name="student_id" id="student_id" required>
                            <option value="">Select Student</option>
                            <?php foreach ($students as $student): ?>
                                <option value="<?php echo $student['student_id']; ?>">
                                    <?php echo $student['first_name'] . ' ' . $student['last_name'] . ' (' . $student['admission_number'] . ')'; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description *</label>
                        <textarea name="description" id="description" rows="3" required placeholder="e.g., Tuition Fee - 1st Term"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="amount">Amount (₵) *</label>
                        <input type="number" name="amount" id="amount" step="0.01" required placeholder="0.00">
                    </div>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeGenerateModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Generate Invoice
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function openGenerateModal() {
        document.getElementById('generateModal').style.display = 'block';
    }
    
    function closeGenerateModal() {
        document.getElementById('generateModal').style.display = 'none';
    }
    
    function printInvoice(invoiceNumber) {
        alert('Printing invoice ' + invoiceNumber);
        window.print();
        // In production: window.location = 'print-invoice.php?invoice=' + invoiceNumber;
    }
    
    function printInvoices() {
        window.print();
    }
    
    function markAsPaid(invoiceId, invoiceNumber) {
        document.getElementById('markPaidModal').style.display = 'block';
        document.getElementById('invoiceId').value = invoiceId;
        document.getElementById('invoiceInfo').textContent = 'Are you sure you want to mark invoice ' + invoiceNumber + ' as paid?';
    }
    
    function closePaidModal() {
        document.getElementById('markPaidModal').style.display = 'none';
    }
    
    window.onclick = function(event) {
        if (event.target.id === 'generateModal') {
            event.target.style.display = 'none';
        }
        if (event.target.id === 'markPaidModal') {
            event.target.style.display = 'none';
        }
    }
    </script>
    
    <style media="print">
        @media print {
            .btn, [onclick] { display: none !important; }
            body { background: white; }
            .table-responsive { overflow: visible !important; }
        }
    </style>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
