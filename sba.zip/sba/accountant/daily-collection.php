<?php
// accountant/daily-collection.php - Daily Collection Report
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Daily Collection';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

$selected_date = isset($_GET['date']) ? sanitize_input($_GET['date']) : date('Y-m-d');

// Get today's collections
$stmt = $db->prepare("
    SELECT 
        fp.*,
        CONCAT(s.first_name, ' ', s.last_name) as student_name,
        c.class_name,
        CONCAT(u.first_name, ' ', u.last_name) as collected_by_name
    FROM fee_payments fp
    INNER JOIN students s ON fp.student_id = s.student_id
    INNER JOIN classes c ON s.class_id = c.class_id
    INNER JOIN users u ON fp.collected_by = u.user_id
    WHERE s.school_id = ? AND fp.payment_date = ? AND fp.status = 'verified'
    ORDER BY fp.created_at DESC
");
$stmt->execute([$school_id, $selected_date]);
$payments = $stmt->fetchAll();

$total_amount = array_sum(array_column($payments, 'amount'));
$cash_total = array_sum(array_map(fn($p) => $p['payment_method'] == 'cash' ? $p['amount'] : 0, $payments));
$online_total = $total_amount - $cash_total;

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-money-check-alt"></i> Daily Collection Report</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> Today's fee collection summary
        </p>
    </div>
    
    <!-- Date Selector -->
    <div style="background: var(--bg-card); padding: 15px; border-radius: 12px; margin-bottom: 20px;">
        <form method="GET" style="display: flex; gap: 10px; align-items: end;">
            <div class="form-group" style="margin: 0; flex: 1;">
                <label>Select Date</label>
                <input type="date" name="date" value="<?php echo htmlspecialchars($selected_date); ?>">
            </div>
            <button type="submit" class="btn btn-primary">View</button>
        </form>
    </div>
    
    <!-- Summary -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 25px;">
        <div style="background: linear-gradient(135deg, #34C759, #30D158); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 28px;">₹<?php echo number_format($total_amount, 2); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Collection</p>
        </div>
        <div style="background: linear-gradient(135deg, #5856D6, #5E5CE6); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 28px;"><?php echo count($payments); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Transactions</p>
        </div>
        <div style="background: linear-gradient(135deg, #FF9500, #FF9F0A); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 28px;">₹<?php echo number_format($cash_total, 2); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Cash</p>
        </div>
        <div style="background: linear-gradient(135deg, #007AFF, #0A84FF); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 28px;">₹<?php echo number_format($online_total, 2); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Online/Card</p>
        </div>
    </div>
    
    <!-- Payments List -->
    <h3 style="margin: 0 0 15px 0;">Transactions - <?php echo date('l, F d, Y', strtotime($selected_date)); ?></h3>
    
    <?php if (count($payments) > 0): ?>
        <?php foreach ($payments as $payment): ?>
            <div style="background: var(--bg-card); border: 1px solid var(--border-color); padding: 15px; border-radius: 8px; margin-bottom: 10px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="flex: 1;">
                        <h4 style="margin: 0 0 5px 0;"><?php echo htmlspecialchars($payment['student_name']); ?></h4>
                        <div style="font-size: 13px; color: var(--text-secondary);">
                            <i class="fas fa-receipt"></i> <?php echo htmlspecialchars($payment['receipt_number']); ?> | 
                            <i class="fas fa-credit-card"></i> <?php echo strtoupper($payment['payment_method']); ?> | 
                            <i class="fas fa-clock"></i> <?php echo date('h:i A', strtotime($payment['created_at'])); ?> | 
                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($payment['collected_by_name']); ?>
                        </div>
                    </div>
                    <div style="font-size: 24px; font-weight: 700; color: #34C759; margin-left: 20px;">
                        ₹<?php echo number_format($payment['amount'], 2); ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div style="text-align: center; padding: 60px; background: var(--bg-card); border-radius: 15px;">
            <i class="fas fa-inbox" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
            <h3 style="color: var(--text-secondary);">No Collections on This Date</h3>
        </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
