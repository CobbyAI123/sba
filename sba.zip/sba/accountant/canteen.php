<?php
// accountant/canteen.php - Manage Canteen Income and Assignments
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Canteen Management';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle canteen payment collection
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'collect') {
            $teacher_id = sanitize_input($_POST['teacher_id']);
            $amount = sanitize_input($_POST['amount']);
            $payment_date = sanitize_input($_POST['payment_date']);
            $reference = sanitize_input($_POST['reference'] ?? '');
            
            try {
                $db->beginTransaction();
                
                // Insert canteen payment
                $stmt = $db->prepare("
                    INSERT INTO staff_payments (school_id, user_id, amount, payment_date, payment_type, reference, status, created_by)
                    VALUES (?, ?, ?, ?, 'canteen', ?, 'paid', ?)
                ");
                $stmt->execute([$school_id, $teacher_id, $amount, $payment_date, $reference, $current_user['user_id']]);
                
                $payment_id = $db->lastInsertId();
                
                log_activity($current_user['user_id'], "Collected canteen income - Amount: $amount from staff ID: $teacher_id", 'payments', $payment_id);
                
                $db->commit();
                
                set_message('success', "Canteen income of " . format_currency($amount) . " recorded successfully!");
                redirect(APP_URL . '/accountant/canteen.php');
            } catch (PDOException $e) {
                $db->rollBack();
                set_message('error', 'Error recording canteen income: ' . $e->getMessage());
            }
        } elseif ($_POST['action'] == 'assign_teacher') {
            // Teacher assignment feature temporarily disabled
            set_message('info', 'Teacher assignment feature will be available soon.');
        } elseif ($_POST['action'] == 'remove_teacher') {
            // Teacher removal feature temporarily disabled
            set_message('info', 'Teacher removal feature will be available soon.');
        }
    }
}

// Get all teachers
$teachers = [];
try {
    $stmt = $db->prepare("SELECT user_id, first_name, last_name FROM users WHERE school_id = ? AND role = 'teacher' ORDER BY first_name, last_name");
    $stmt->execute([$school_id]);
    $teachers = $stmt->fetchAll();
} catch (PDOException $e) {
    $teachers = [];
}

// Get assigned canteen teachers
$assigned_teachers = [];
// Note: teacher_assignments table doesn't exist yet
$assigned_teachers = [];

// Get available teachers (not assigned to canteen)
$available_teachers = [];
$assigned_ids = array_map(function($t) { return $t['user_id']; }, $assigned_teachers);
foreach ($teachers as $teacher) {
    if (!in_array($teacher['user_id'], $assigned_ids)) {
        $available_teachers[] = $teacher;
    }
}

// Get total canteen revenue
$total_canteen = 0;
try {
    $stmt = $db->prepare("
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM staff_payments 
        WHERE school_id = ? AND payment_type = 'canteen' AND status = 'paid'
    ");
    $stmt->execute([$school_id]);
    $total_canteen = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    $total_canteen = 0;
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
        .teacher-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            border-left: 4px solid var(--primary-blue);
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.3s ease;
        }
    
        .teacher-card:hover {
            transform: translateX(5px);
            box-shadow: var(--shadow);
        }
    
        .teacher-info {
            flex: 1;
        }
    
        .teacher-name {
            font-weight: 600;
            margin-bottom: 5px;
        }
    
        .teacher-revenue {
            font-size: 18px;
            font-weight: 700;
            color: var(--primary-blue);
        }
    
        .teacher-actions {
            display: flex;
            gap: 10px;
        }
    </style>
    
    <!-- Page Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #FF9800, #F57C00); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-utensils"></i> Canteen Management
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Manage canteen staff assignments and collect canteen income
            </p>
        </div>
    </div>
    
    <!-- Stats -->
    <div style="background: var(--card-bg); padding: 20px; border-radius: 12px; margin-bottom: 30px; border-left: 4px solid #FF9800;">
        <div style="font-size: 14px; color: var(--text-secondary); margin-bottom: 5px;">Total Canteen Revenue</div>
        <div style="font-size: 28px; font-weight: 700; color: #FF9800;"><?php echo format_currency($total_canteen); ?></div>
        <div style="font-size: 12px; color: var(--text-secondary); margin-top: 10px;">
            <i class="fas fa-users"></i> <?php echo count($assigned_teachers); ?> staff assigned
        </div>
    </div>
    
    <!-- Assigned Teachers -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-user-check"></i> Assigned Staff (<?php echo count($assigned_teachers); ?>)</h3>
        </div>
        <div style="padding: 20px;">
            <?php if (count($assigned_teachers) > 0): ?>
                <?php foreach ($assigned_teachers as $teacher): ?>
                    <div class="teacher-card">
                        <div class="teacher-info">
                            <div class="teacher-name"><?php echo $teacher['first_name'] . ' ' . $teacher['last_name']; ?></div>
                            <div style="font-size: 12px; color: var(--text-secondary);">
                                <i class="fas fa-money-bill"></i> Collected: <strong><?php echo format_currency($teacher['total_collected']); ?></strong>
                            </div>
                        </div>
                        <div class="teacher-actions">
                            <button class="btn btn-sm btn-success" onclick="showCollectModal(<?php echo $teacher['user_id']; ?>, '<?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']); ?>')">
                                <i class="fas fa-plus"></i> Collect
                            </button>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="action" value="remove_teacher">
                                <input type="hidden" name="teacher_id" value="<?php echo $teacher['user_id']; ?>">
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Remove this staff from canteen?')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="padding: 40px; text-align: center; color: var(--text-secondary);">
                    <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 15px; display: block; opacity: 0.5;"></i>
                    <p>No staff assigned to canteen yet. Assign a staff member below.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Assign New Teacher -->
    <?php if (count($available_teachers) > 0): ?>
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-user-plus"></i> Assign New Staff to Canteen</h3>
            </div>
            <div style="padding: 20px;">
                <form method="POST" style="display: flex; gap: 10px; align-items: end;">
                    <input type="hidden" name="action" value="assign_teacher">
                    <div class="form-group" style="margin-bottom: 0; flex: 1;">
                        <label for="teacher_id">Select Staff</label>
                        <select name="teacher_id" id="teacher_id" required>
                            <option value="">-- Select a staff member --</option>
                            <?php foreach ($available_teachers as $teacher): ?>
                                <option value="<?php echo $teacher['user_id']; ?>">
                                    <?php echo $teacher['first_name'] . ' ' . $teacher['last_name']; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-plus-circle"></i> Assign
                    </button>
                </form>
            </div>
        </div>
    <?php else: ?>
        <div class="card" style="background: rgba(255, 152, 0, 0.05); border-left: 4px solid #FF9800;">
            <div style="padding: 20px; text-align: center; color: var(--text-secondary);">
                <i class="fas fa-check-circle" style="font-size: 32px; color: #4CAF50; margin-bottom: 10px; display: block;"></i>
                <p>All staff members are already assigned to canteen!</p>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Collect Modal -->
    <div id="collectModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 500px; margin: 100px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Collect Canteen Income</h2>
                <button onclick="closeCollectModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="collect">
                <input type="hidden" name="teacher_id" id="modal_teacher_id">
                
                <div style="background: rgba(255, 152, 0, 0.1); padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                    <strong>Staff:</strong> <span id="modal_teacher_name"></span>
                </div>
                
                <div class="form-group">
                    <label for="amount">Amount *</label>
                    <input type="number" name="amount" id="amount" placeholder="0.00" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label for="payment_date">Payment Date *</label>
                    <input type="date" name="payment_date" id="payment_date" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="reference">Reference (Optional)</label>
                    <input type="text" name="reference" id="reference" placeholder="e.g., Receipt Number">
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end;">
                    <button type="button" class="btn btn-secondary" onclick="closeCollectModal()">Cancel</button>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check"></i> Record Payment
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showCollectModal(teacherId, teacherName) {
        document.getElementById('modal_teacher_id').value = teacherId;
        document.getElementById('modal_teacher_name').textContent = teacherName;
        document.getElementById('collectModal').style.display = 'block';
    }
    
    function closeCollectModal() {
        document.getElementById('collectModal').style.display = 'none';
    }
    
    // Close modal on background click
    document.getElementById('collectModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeCollectModal();
        }
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
