<?php
// accountant/collection-reports.php - Daily Collection Reports
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Collection Reports';
$current_user = check_permission(['accountant', 'admin', 'super_admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get filter parameters
$start_date = isset($_GET['start_date']) ? sanitize_input($_GET['start_date']) : date('Y-m-d');
$end_date = isset($_GET['end_date']) ? sanitize_input($_GET['end_date']) : date('Y-m-d');
$class_filter = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
$type_filter = isset($_GET['type']) ? sanitize_input($_GET['type']) : 'all';

// Get all classes
$stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get daily collections with error handling
$collections = [];
try {
    $query = "
        SELECT 
            dc.collection_id,
            dc.student_id,
            dc.collection_date,
            dc.canteen_paid,
            dc.bus_paid,
            dc.canteen_amount,
            dc.bus_amount,
            dc.marked_by,
            s.admission_number,
            CONCAT(u.first_name, ' ', u.last_name) as student_name,
            c.class_name,
            h.route_name,
            CONCAT(t.first_name, ' ', t.last_name) as marked_by_name
        FROM daily_collections dc
        INNER JOIN students s ON dc.student_id = s.student_id
        INNER JOIN users u ON s.user_id = u.user_id
        INNER JOIN classes c ON dc.class_id = c.class_id
        LEFT JOIN hometowns h ON s.hometown_id = h.hometown_id
        LEFT JOIN users t ON dc.marked_by = t.user_id
        WHERE dc.school_id = ?
        AND dc.collection_date BETWEEN ? AND ?
    ";
    $params = [$school_id, $start_date, $end_date];

    if ($class_filter > 0) {
        $query .= " AND dc.class_id = ?";
        $params[] = $class_filter;
    }

    if ($type_filter != 'all') {
        if ($type_filter == 'canteen') {
            $query .= " AND dc.canteen_paid = 1";
        } elseif ($type_filter == 'bus') {
            $query .= " AND dc.bus_paid = 1";
        }
    }

    $query .= " ORDER BY dc.collection_date DESC, c.class_name, u.first_name";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $collections = $stmt->fetchAll();
} catch (PDOException $e) {
    $collections = [];
}

// Calculate summary statistics
$total_collections = count($collections);
$canteen_total = 0;
$bus_total = 0;
$canteen_count = 0;
$bus_count = 0;

foreach ($collections as $collection) {
    if ($collection['canteen_paid']) {
        $canteen_total += $collection['canteen_amount'];
        $canteen_count++;
    }
    if ($collection['bus_paid']) {
        $bus_total += $collection['bus_amount'];
        $bus_count++;
    }
}

$grand_total = $canteen_total + $bus_total;

// Group by date for daily summary
$daily_summary = [];
foreach ($collections as $collection) {
    $date = $collection['collection_date'];
    if (!isset($daily_summary[$date])) {
        $daily_summary[$date] = [
            'canteen_total' => 0,
            'bus_total' => 0,
            'canteen_count' => 0,
            'bus_count' => 0,
            'total' => 0
        ];
    }
    
    if ($collection['canteen_paid']) {
        $daily_summary[$date]['canteen_total'] += $collection['canteen_amount'];
        $daily_summary[$date]['canteen_count']++;
    }
    if ($collection['bus_paid']) {
        $daily_summary[$date]['bus_total'] += $collection['bus_amount'];
        $daily_summary[$date]['bus_count']++;
    }
    $daily_summary[$date]['total'] = $daily_summary[$date]['canteen_total'] + $daily_summary[$date]['bus_total'];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .summary-cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .summary-card {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        color: white;
        padding: 25px;
        border-radius: 12px;
        text-align: center;
    }
    
    .summary-card.canteen {
        background: linear-gradient(135deg, #4CAF50, #81C784);
    }
    
    .summary-card.bus {
        background: linear-gradient(135deg, #FF9800, #FFB74D);
    }
    
    .summary-card.total {
        background: linear-gradient(135deg, #9C27B0, #BA68C8);
    }
    
    .summary-card h3 {
        margin: 0;
        font-size: 36px;
        font-weight: bold;
    }
    
    .summary-card p {
        margin: 8px 0 0 0;
        font-size: 14px;
        opacity: 0.95;
    }
    
    .summary-card small {
        display: block;
        margin-top: 5px;
        font-size: 12px;
        opacity: 0.85;
    }
    
    .daily-summary-card {
        background: var(--card-bg);
        border: 2px solid var(--border-color);
        border-left: 5px solid var(--primary-blue);
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 15px;
    }
    
    .daily-summary-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
        padding-bottom: 15px;
        border-bottom: 2px solid var(--border-color);
    }
    
    .daily-stats {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 15px;
    }
    
    .daily-stat {
        text-align: center;
        padding: 15px;
        background: var(--bg-secondary);
        border-radius: 8px;
    }
    </style>
    
    <div style="margin-bottom: 20px;">
        <h2><i class="fas fa-chart-bar"></i> Daily Collection Reports</h2>
        <p style="color: var(--text-secondary);">View and analyze canteen and bus fee collections</p>
    </div>
    
    <!-- Filter Form -->
    <div class="card" style="margin-bottom: 25px;">
        <div class="card-header">
            <h3><i class="fas fa-filter"></i> Filters</h3>
        </div>
        <div style="padding: 20px;">
            <form method="GET" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end;">
                <div class="form-group" style="margin: 0;">
                    <label>Start Date</label>
                    <input type="date" name="start_date" value="<?php echo $start_date; ?>" class="form-control" required>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>End Date</label>
                    <input type="date" name="end_date" value="<?php echo $end_date; ?>" class="form-control" required>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>Class</label>
                    <select name="class_id" class="form-control">
                        <option value="0">All Classes</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>" <?php echo $class_filter == $class['class_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>Type</label>
                    <select name="type" class="form-control">
                        <option value="all" <?php echo $type_filter == 'all' ? 'selected' : ''; ?>>All</option>
                        <option value="canteen" <?php echo $type_filter == 'canteen' ? 'selected' : ''; ?>>Canteen Only</option>
                        <option value="bus" <?php echo $type_filter == 'bus' ? 'selected' : ''; ?>>Bus Only</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary" style="margin: 0;">
                    <i class="fas fa-search"></i> Filter
                </button>
                
                <a href="<?php echo APP_URL; ?>/accountant/collection-reports.php" class="btn btn-secondary" style="margin: 0;">
                    <i class="fas fa-redo"></i> Reset
                </a>
            </form>
        </div>
    </div>
    
    <!-- Summary Cards -->
    <div class="summary-cards">
        <div class="summary-card canteen">
            <h3><?php echo format_currency($canteen_total); ?></h3>
            <p>Total Canteen Collections</p>
            <small><?php echo $canteen_count; ?> transactions</small>
        </div>
        
        <div class="summary-card bus">
            <h3><?php echo format_currency($bus_total); ?></h3>
            <p>Total Bus Collections</p>
            <small><?php echo $bus_count; ?> transactions</small>
        </div>
        
        <div class="summary-card total">
            <h3><?php echo format_currency($grand_total); ?></h3>
            <p>Grand Total</p>
            <small><?php echo $total_collections; ?> total records</small>
        </div>
    </div>
    
    <!-- Daily Summary -->
    <?php if (!empty($daily_summary)): ?>
    <div class="card" style="margin-bottom: 25px;">
        <div class="card-header">
            <h3><i class="fas fa-calendar-day"></i> Daily Summary</h3>
        </div>
        <div style="padding: 20px;">
            <?php foreach ($daily_summary as $date => $summary): ?>
                <div class="daily-summary-card">
                    <div class="daily-summary-header">
                        <h4 style="margin: 0;">
                            <i class="fas fa-calendar"></i> <?php echo date('l, F d, Y', strtotime($date)); ?>
                        </h4>
                        <h4 style="margin: 0; color: var(--primary-blue);">
                            <?php echo format_currency($summary['total']); ?>
                        </h4>
                    </div>
                    <div class="daily-stats">
                        <div class="daily-stat">
                            <div style="font-size: 24px; font-weight: bold; color: #4CAF50;">
                                <?php echo format_currency($summary['canteen_total']); ?>
                            </div>
                            <div style="font-size: 12px; color: var(--text-secondary); margin-top: 5px;">
                                Canteen (<?php echo $summary['canteen_count']; ?> students)
                            </div>
                        </div>
                        <div class="daily-stat">
                            <div style="font-size: 24px; font-weight: bold; color: #FF9800;">
                                <?php echo format_currency($summary['bus_total']); ?>
                            </div>
                            <div style="font-size: 12px; color: var(--text-secondary); margin-top: 5px;">
                                Bus (<?php echo $summary['bus_count']; ?> students)
                            </div>
                        </div>
                        <div class="daily-stat">
                            <div style="font-size: 24px; font-weight: bold; color: var(--primary-blue);">
                                <?php echo $summary['canteen_count'] + $summary['bus_count']; ?>
                            </div>
                            <div style="font-size: 12px; color: var(--text-secondary); margin-top: 5px;">
                                Total Transactions
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Detailed Collections Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Detailed Collections (<?php echo count($collections); ?> records)</h3>
            <button onclick="exportToCSV()" class="btn btn-success">
                <i class="fas fa-file-excel"></i> Export CSV
            </button>
        </div>
        
        <div class="table-responsive">
            <table id="collectionsTable">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Student</th>
                        <th>Class</th>
                        <th>Route</th>
                        <th>Canteen</th>
                        <th>Bus</th>
                        <th>Total</th>
                        <th>Marked By</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($collections) > 0): ?>
                        <?php foreach ($collections as $collection): ?>
                            <tr>
                                <td><?php echo date('M d, Y', strtotime($collection['collection_date'])); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($collection['student_name']); ?></strong><br>
                                    <small style="color: var(--text-secondary);"><?php echo htmlspecialchars($collection['admission_number']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($collection['class_name']); ?></td>
                                <td>
                                    <?php if ($collection['hometown_name']): ?>
                                        <?php echo htmlspecialchars($collection['hometown_name']); ?><br>
                                        <small style="color: var(--text-secondary);"><?php echo htmlspecialchars($collection['route_name']); ?></small>
                                    <?php else: ?>
                                        <small style="color: var(--text-secondary);">-</small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($collection['canteen_paid']): ?>
                                        <strong style="color: #4CAF50;"><?php echo format_currency($collection['canteen_amount']); ?></strong>
                                    <?php else: ?>
                                        <span style="color: var(--text-secondary);">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($collection['bus_paid']): ?>
                                        <strong style="color: #FF9800;"><?php echo format_currency($collection['bus_amount']); ?></strong>
                                    <?php else: ?>
                                        <span style="color: var(--text-secondary);">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong style="color: var(--primary-blue);"><?php echo format_currency($collection['total_amount']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($collection['marked_by_name']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px;">
                                <i class="fas fa-inbox" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 10px; display: block;"></i>
                                <h3>No Collections Found</h3>
                                <p style="color: var(--text-secondary);">Try adjusting your filters or date range</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
                <?php if (count($collections) > 0): ?>
                    <tfoot>
                        <tr style="background: var(--bg-secondary); font-weight: bold;">
                            <td colspan="4" style="text-align: right;">TOTALS:</td>
                            <td style="color: #4CAF50;"><?php echo format_currency($canteen_total); ?></td>
                            <td style="color: #FF9800;"><?php echo format_currency($bus_total); ?></td>
                            <td style="color: var(--primary-blue);"><?php echo format_currency($grand_total); ?></td>
                            <td></td>
                        </tr>
                    </tfoot>
                <?php endif; ?>
            </table>
        </div>
    </div>
    
    <script>
    function exportToCSV() {
        const table = document.getElementById('collectionsTable');
        let csv = [];
        
        // Headers
        const headers = [];
        table.querySelectorAll('thead th').forEach(th => {
            headers.push(th.textContent.trim());
        });
        csv.push(headers.join(','));
        
        // Data rows
        table.querySelectorAll('tbody tr').forEach(tr => {
            const row = [];
            tr.querySelectorAll('td').forEach(td => {
                let text = td.textContent.trim().replace(/\n/g, ' ').replace(/\s+/g, ' ');
                row.push('"' + text + '"');
            });
            if (row.length > 0) {
                csv.push(row.join(','));
            }
        });
        
        // Download
        const csvContent = csv.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'collection_report_<?php echo $start_date; ?>_to_<?php echo $end_date; ?>.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }
    </script>
    
    </div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
