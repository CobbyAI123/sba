<?php
// accountant/payments-new.php - Payment Collection Hub
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Payment Collection';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get statistics
$stats = [];

// Total collected today
$stmt = $db->prepare("
    SELECT COALESCE(SUM(amount), 0) as total
    FROM payments
    WHERE DATE(payment_date) = CURDATE()
    AND student_id IN (SELECT student_id FROM students WHERE school_id = ?)
");
$stmt->execute([$school_id]);
$stats['today_collection'] = $stmt->fetch()['total'] ?? 0;

// Pending payments
$stmt = $db->prepare("
    SELECT COALESCE(SUM(amount), 0) as total
    FROM payments
    WHERE status = 'pending'
    AND student_id IN (SELECT student_id FROM students WHERE school_id = ?)
");
$stmt->execute([$school_id]);
$stats['pending'] = $stmt->fetch()['total'] ?? 0;

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .revenue-type-card {
        background: white;
        border-radius: 12px;
        padding: 30px;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s ease;
        border: 2px solid transparent;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    .revenue-type-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }
    
    .revenue-type-card.school-fees {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
    
    .revenue-type-card.canteen {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        color: white;
    }
    
    .revenue-type-card.transport {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        color: white;
    }
    
    .revenue-type-card .icon {
        font-size: 64px;
        margin-bottom: 20px;
        opacity: 0.9;
    }
    
    .revenue-type-card h3 {
        margin: 0 0 10px 0;
        font-size: 24px;
        color: white;
    }
    
    .revenue-type-card p {
        margin: 0;
        opacity: 0.9;
        font-size: 14px;
    }
    
    .stats-banner {
        background: linear-gradient(135deg, #4CAF50, #8BC34A);
        color: white;
        padding: 30px;
        border-radius: 12px;
        margin-bottom: 30px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 30px;
    }
    
    .stat-item {
        text-align: center;
    }
    
    .stat-item h2 {
        margin: 0 0 5px 0;
        font-size: 36px;
        color: white;
    }
    
    .stat-item p {
        margin: 0;
        opacity: 0.9;
        font-size: 16px;
    }
    </style>
    
    <!-- Welcome Section -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-cash-register"></i> Payment Collection Center
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Select payment type to begin collection - <?php echo date('l, F d, Y'); ?>
            </p>
        </div>
    </div>
    
    <!-- Statistics Banner -->
    <div class="stats-banner">
        <div class="stat-item">
            <h2><?php echo format_currency($stats['today_collection']); ?></h2>
            <p><i class="fas fa-calendar-day"></i> Collected Today</p>
        </div>
        <div class="stat-item">
            <h2><?php echo format_currency($stats['pending']); ?></h2>
            <p><i class="fas fa-clock"></i> Total Pending</p>
        </div>
    </div>
    
    <!-- Revenue Type Selection -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-hand-holding-usd"></i> Select Payment Type</h3>
        </div>
        <div style="padding: 30px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px;">
                
                <!-- School Fees -->
                <a href="<?php echo APP_URL; ?>/accountant/collect-school-fees.php" style="text-decoration: none;">
                    <div class="revenue-type-card school-fees">
                        <div class="icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <h3>School Fees</h3>
                        <p>Collect tuition fees by class</p>
                        <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.3);">
                            <p style="font-size: 12px; opacity: 0.8;">
                                <i class="fas fa-users"></i> Class-based collection<br>
                                <i class="fas fa-calendar"></i> Term/Annual fees
                            </p>
                        </div>
                    </div>
                </a>
    
                <!-- Canteen -->
                <a href="<?php echo APP_URL; ?>/accountant/collect-canteen-fees-teachers.php" style="text-decoration: none;">
                    <div class="revenue-type-card canteen">
                        <div class="icon">
                            <i class="fas fa-utensils"></i>
                        </div>
                        <h3>Canteen Fees</h3>
                        <p>Collect from teachers & staff</p>
                        <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.3);">
                            <p style="font-size: 12px; opacity: 0.8;">
                                <i class="fas fa-users"></i> Teachers & Staff<br>
                                <i class="fas fa-calendar-day"></i> Daily/Weekly
                            </p>
                        </div>
                    </div>
                </a>
    
                <!-- Transport/Bus -->
                <a href="<?php echo APP_URL; ?>/accountant/collect-transport-fees-teachers.php" style="text-decoration: none;">
                    <div class="revenue-type-card transport">
                        <div class="icon">
                            <i class="fas fa-bus"></i>
                        </div>
                        <h3>Transport Fees</h3>
                        <p>Collect from teachers & staff</p>
                        <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.3);">
                            <p style="font-size: 12px; opacity: 0.8;">
                                <i class="fas fa-users"></i> Teachers & Staff<br>
                                <i class="fas fa-calendar-day"></i> Daily/Weekly
                            </p>
                        </div>
                    </div>
                </a>
    
            </div>
        </div>
    </div>
    
    <!-- Quick Stats -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-top: 30px;">
        
        <!-- Recent Payments -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-history"></i> Recent Collections</h3>
            </div>
            <div style="max-height: 300px; overflow-y: auto;">
                <?php
                $stmt = $db->prepare("
                    SELECT 
                        p.*,
                        s.first_name,
                        s.last_name,
                        s.admission_number
                    FROM payments p
                    INNER JOIN students s ON p.student_id = s.student_id
                    WHERE s.school_id = ?
                    AND DATE(p.payment_date) = CURDATE()
                    ORDER BY p.payment_date DESC
                    LIMIT 10
                ");
                $stmt->execute([$school_id]);
                $recent = $stmt->fetchAll();
                
                if (count($recent) > 0):
                    foreach ($recent as $payment):
                ?>
                    <div style="padding: 12px; border-bottom: 1px solid var(--border-color);">
                        <div style="display: flex; justify-content: space-between;">
                            <div>
                                <strong><?php echo $payment['first_name'] . ' ' . $payment['last_name']; ?></strong>
                                <br>
                                <small style="color: var(--text-secondary);">
                                    <?php echo $payment['admission_number']; ?> - 
                                    <?php echo date('h:i A', strtotime($payment['payment_date'])); ?>
                                </small>
                            </div>
                            <strong style="color: var(--success-green);">
                                <?php echo format_currency($payment['amount']); ?>
                            </strong>
                        </div>
                    </div>
                <?php 
                    endforeach;
                else:
                ?>
                    <div style="padding: 40px; text-align: center; color: var(--text-secondary);">
                        <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 10px; display: block;"></i>
                        No collections today
                    </div>
                <?php endif; ?>
            </div>
        </div>
    
        <!-- Payment Methods -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-credit-card"></i> Payment Methods</h3>
            </div>
            <div style="padding: 20px;">
                <div style="margin-bottom: 15px; padding: 15px; background: var(--bg-secondary); border-radius: 8px;">
                    <i class="fas fa-money-bill-wave" style="color: var(--success-green); margin-right: 10px;"></i>
                    <strong>Cash</strong>
                    <p style="margin: 5px 0 0 0; font-size: 12px; color: var(--text-secondary);">Direct cash payment</p>
                </div>
                <div style="margin-bottom: 15px; padding: 15px; background: var(--bg-secondary); border-radius: 8px;">
                    <i class="fas fa-university" style="color: var(--primary-blue); margin-right: 10px;"></i>
                    <strong>Bank Transfer</strong>
                    <p style="margin: 5px 0 0 0; font-size: 12px; color: var(--text-secondary);">Electronic transfer</p>
                </div>
                <div style="margin-bottom: 15px; padding: 15px; background: var(--bg-secondary); border-radius: 8px;">
                    <i class="fas fa-mobile-alt" style="color: var(--secondary-purple); margin-right: 10px;"></i>
                    <strong>Mobile Money</strong>
                    <p style="margin: 5px 0 0 0; font-size: 12px; color: var(--text-secondary);">POS/Mobile payment</p>
                </div>
                <div style="padding: 15px; background: var(--bg-secondary); border-radius: 8px;">
                    <i class="fas fa-credit-card" style="color: var(--warning-orange); margin-right: 10px;"></i>
                    <strong>Card Payment</strong>
                    <p style="margin: 5px 0 0 0; font-size: 12px; color: var(--text-secondary);">Debit/Credit card</p>
                </div>
            </div>
        </div>
    
        <!-- Quick Links -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-link"></i> Quick Links</h3>
            </div>
            <div style="padding: 20px;">
                <a href="<?php echo APP_URL; ?>/accountant/outstanding-fees.php" class="btn btn-danger" style="width: 100%; margin-bottom: 10px; text-decoration: none; display: block; text-align: center;">
                    <i class="fas fa-exclamation-circle"></i> View Outstanding Fees
                </a>
                <a href="<?php echo APP_URL; ?>/accountant/revenue-reports.php" class="btn btn-info" style="width: 100%; margin-bottom: 10px; text-decoration: none; display: block; text-align: center;">
                    <i class="fas fa-chart-line"></i> Revenue Reports
                </a>
                <a href="<?php echo APP_URL; ?>/accountant/receipts.php" class="btn btn-secondary" style="width: 100%; margin-bottom: 10px; text-decoration: none; display: block; text-align: center;">
                    <i class="fas fa-receipt"></i> Print Receipts
                </a>
                <a href="<?php echo APP_URL; ?>/accountant/dashboard.php" class="btn btn-outline" style="width: 100%; text-decoration: none; display: block; text-align: center;">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    
    </div>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
