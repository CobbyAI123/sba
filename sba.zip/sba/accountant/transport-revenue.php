<?php
// accountant/transport-revenue.php - Transport Revenue Reports
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Transport Revenue Reports';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get date range from filters
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');

// Get transport revenue statistics
$stmt = $db->prepare("
    SELECT 
        COALESCE(SUM(amount), 0) as total_revenue,
        COUNT(*) as total_transactions,
        COALESCE(AVG(amount), 0) as average_transaction
    FROM payments
    WHERE (payment_type = 'transport' OR payment_reference LIKE '%transport%')
    AND status = 'paid'
    AND payment_date BETWEEN ? AND ?
    AND school_id = ?
");
$stmt->execute([$start_date, $end_date, $school_id]);
$stats = $stmt->fetch();

// Get daily breakdown
$stmt = $db->prepare("
    SELECT 
        DATE(payment_date) as date,
        COUNT(*) as transactions,
        COALESCE(SUM(amount), 0) as total
    FROM payments
    WHERE (payment_type = 'transport' OR payment_reference LIKE '%transport%')
    AND status = 'paid'
    AND payment_date BETWEEN ? AND ?
    AND school_id = ?
    GROUP BY DATE(payment_date)
    ORDER BY date DESC
");
$stmt->execute([$start_date, $end_date, $school_id]);
$daily_breakdown = $stmt->fetchAll();

// Get recent transactions
$stmt = $db->prepare("
    SELECT 
        p.*,
        u.first_name,
        u.last_name,
        u.email
    FROM payments p
    LEFT JOIN users u ON p.user_id = u.user_id
    WHERE (p.payment_type = 'transport' OR p.payment_reference LIKE '%transport%')
    AND p.status = 'paid'
    AND p.payment_date BETWEEN ? AND ?
    AND p.school_id = ?
    ORDER BY p.payment_date DESC, p.created_at DESC
    LIMIT 50
");
$stmt->execute([$start_date, $end_date, $school_id]);
$transactions = $stmt->fetchAll();

// Get payment method breakdown
$stmt = $db->prepare("
    SELECT 
        payment_method,
        COUNT(*) as count,
        COALESCE(SUM(amount), 0) as total
    FROM payments
    WHERE (payment_type = 'transport' OR payment_reference LIKE '%transport%')
    AND status = 'paid'
    AND payment_date BETWEEN ? AND ?
    AND school_id = ?
    GROUP BY payment_method
");
$stmt->execute([$start_date, $end_date, $school_id]);
$payment_methods = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .filter-card {
        background: white;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .stat-box {
        background: linear-gradient(135deg, #4facfe, #00f2fe);
        color: white;
        padding: 25px;
        border-radius: 12px;
        text-align: center;
    }
    
    .stat-box h2 {
        margin: 0 0 5px 0;
        font-size: 36px;
        color: white;
    }
    
    .stat-box p {
        margin: 0;
        opacity: 0.9;
        font-size: 14px;
    }
    </style>
    
    <!-- Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #4facfe, #00f2fe); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-bus"></i> Transport Revenue Reports
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Detailed transport revenue analysis and transaction history
            </p>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="filter-card">
        <form method="GET" style="display: flex; gap: 15px; align-items: end; flex-wrap: wrap;">
            <div style="flex: 1; min-width: 200px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600;">Start Date</label>
                <input type="date" name="start_date" value="<?php echo $start_date; ?>" class="form-control">
            </div>
            <div style="flex: 1; min-width: 200px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 600;">End Date</label>
                <input type="date" name="end_date" value="<?php echo $end_date; ?>" class="form-control">
            </div>
            <div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-filter"></i> Apply Filter
                </button>
                <a href="?" class="btn btn-outline">
                    <i class="fas fa-redo"></i> Reset
                </a>
            </div>
        </form>
    </div>
    
    <!-- Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="stat-box">
            <h2><?php echo format_currency($stats['total_revenue']); ?></h2>
            <p><i class="fas fa-money-bill-wave"></i> Total Revenue</p>
        </div>
        <div class="stat-box">
            <h2><?php echo number_format($stats['total_transactions']); ?></h2>
            <p><i class="fas fa-receipt"></i> Total Transactions</p>
        </div>
        <div class="stat-box">
            <h2><?php echo format_currency($stats['average_transaction']); ?></h2>
            <p><i class="fas fa-chart-line"></i> Average Transaction</p>
        </div>
    </div>
    
    <!-- Payment Methods Breakdown -->
    <?php if (count($payment_methods) > 0): ?>
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-credit-card"></i> Payment Methods</h3>
        </div>
        <div style="padding: 20px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                <?php foreach ($payment_methods as $method): ?>
                    <div style="padding: 15px; background: var(--bg-secondary); border-radius: 8px;">
                        <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 5px;">
                            <?php echo ucfirst(str_replace('_', ' ', $method['payment_method'])); ?>
                        </div>
                        <div style="font-size: 20px; font-weight: 600; color: var(--primary-blue);">
                            <?php echo format_currency($method['total']); ?>
                        </div>
                        <div style="font-size: 12px; color: var(--text-secondary); margin-top: 5px;">
                            <?php echo $method['count']; ?> transactions
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Daily Breakdown -->
    <?php if (count($daily_breakdown) > 0): ?>
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-calendar-alt"></i> Daily Breakdown</h3>
        </div>
        <div style="max-height: 400px; overflow-y: auto;">
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Transactions</th>
                        <th>Total Revenue</th>
                        <th>Average</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($daily_breakdown as $day): ?>
                        <tr>
                            <td><strong><?php echo date('M d, Y', strtotime($day['date'])); ?></strong></td>
                            <td><?php echo $day['transactions']; ?></td>
                            <td><strong style="color: var(--success-green);"><?php echo format_currency($day['total']); ?></strong></td>
                            <td><?php echo format_currency($day['total'] / $day['transactions']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Recent Transactions -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Recent Transactions</h3>
            <span class="badge badge-info"><?php echo count($transactions); ?> records</span>
        </div>
        <?php if (count($transactions) > 0): ?>
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Reference</th>
                            <th>Payer</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transactions as $transaction): ?>
                            <tr>
                                <td><?php echo date('M d, Y', strtotime($transaction['payment_date'])); ?></td>
                                <td><small><?php echo $transaction['payment_reference']; ?></small></td>
                                <td>
                                    <?php if ($transaction['first_name']): ?>
                                        <?php echo $transaction['first_name'] . ' ' . $transaction['last_name']; ?>
                                    <?php else: ?>
                                        <span style="color: var(--text-secondary);">N/A</span>
                                    <?php endif; ?>
                                </td>
                                <td><strong style="color: var(--success-green);"><?php echo format_currency($transaction['amount']); ?></strong></td>
                                <td><?php echo ucfirst(str_replace('_', ' ', $transaction['payment_method'])); ?></td>
                                <td><small><?php echo $transaction['description'] ?? '-'; ?></small></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div style="padding: 60px; text-align: center; color: var(--text-secondary);">
                <i class="fas fa-inbox" style="font-size: 64px; margin-bottom: 20px; display: block;"></i>
                <h3>No Transactions Found</h3>
                <p>No transport transactions in the selected date range</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Export Options -->
    <div style="margin-top: 20px; text-align: right;">
        <button onclick="window.print()" class="btn btn-secondary">
            <i class="fas fa-print"></i> Print Report
        </button>
        <a href="<?php echo APP_URL; ?>/accountant/dashboard.php" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
