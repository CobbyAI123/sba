<?php
// accountant/fee-structure.php - DEPRECATED - Moved to Admin
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Fee Structure';
$current_user = check_permission(['accountant']);

// Redirect to admin section with a message
set_message('info', 'Fee Structure management has been moved to Admin section. Please contact your administrator to set up fee structures.');
redirect(APP_URL . '/accountant/dashboard.php');
exit();
