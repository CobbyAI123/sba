<?php
// accountant/teacher-collections.php - Collect Money from Canteen/Bus Teachers
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Teacher Collections - Canteen & Bus';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'record_collection') {
            $teacher_id = (int)$_POST['teacher_id'];
            $collection_type = sanitize_input($_POST['collection_type']); // 'canteen' or 'bus'
            $amount = (float)$_POST['amount'];
            $collection_date = sanitize_input($_POST['collection_date']);
            $payment_method = sanitize_input($_POST['payment_method']);
            $reference = sanitize_input($_POST['reference'] ?? '');
            $remarks = sanitize_input($_POST['remarks'] ?? '');
            
            // VALIDATION: Check if amount matches teacher's daily collections FOR THE SELECTED DATE
            if ($collection_type === 'canteen') {
                $stmt = $db->prepare("
                    SELECT 
                        SUM(dc.canteen_amount) as total_amount,
                        COUNT(CASE WHEN dc.canteen_paid = 1 THEN 1 END) as count_paid
                    FROM daily_collections dc
                    WHERE dc.marked_by = ?
                    AND dc.school_id = ?
                    AND dc.collection_date = ?
                    AND dc.canteen_paid = 1
                ");
            } else { // bus
                $stmt = $db->prepare("
                    SELECT 
                        SUM(dc.bus_amount) as total_amount,
                        COUNT(CASE WHEN dc.bus_paid = 1 THEN 1 END) as count_paid
                    FROM daily_collections dc
                    WHERE dc.marked_by = ?
                    AND dc.school_id = ?
                    AND dc.collection_date = ?
                    AND dc.bus_paid = 1
                ");
            }
            
            $stmt->execute([$teacher_id, $school_id, $collection_date]);
            $result = $stmt->fetch();
            
            $expected_amount = floatval($result['total_amount'] ?? 0);
            $student_count = intval($result['count_paid'] ?? 0);
            
            // Check if already collected for this date and type
            $stmt = $db->prepare("
                SELECT amount FROM teacher_collections
                WHERE school_id = ? AND teacher_id = ? AND collection_type = ? AND collection_date = ?
            ");
            $stmt->execute([$school_id, $teacher_id, $collection_type, $collection_date]);
            $existing = $stmt->fetch();
            
            if ($existing) {
                set_message('error', "Collection already recorded for this teacher on $collection_date. Amount: " . format_currency($existing['amount']));
                redirect(APP_URL . '/accountant/teacher-collections.php');
                exit;
            }
            
            // Validate amount matches
            if (abs($amount - $expected_amount) > 0.01) { // Allow 1 cent tolerance
                // Store error details in session for popup modal
                $_SESSION['amount_mismatch_error'] = [
                    'teacher_name' => $_POST['teacher_name'] ?? 'Teacher',
                    'collection_type' => ucfirst($collection_type),
                    'collection_date' => date('M d, Y', strtotime($collection_date)),
                    'collection_date_raw' => $collection_date, // For verification link
                    'expected_amount' => $expected_amount,
                    'entered_amount' => $amount,
                    'student_count' => $student_count,
                    'teacher_id' => $teacher_id,
                    'payment_method' => $payment_method,
                    'reference' => $reference,
                    'remarks' => $remarks
                ];
                
                redirect(APP_URL . '/accountant/teacher-collections.php?show_error=1');
                exit;
            }
            
            try {
                $stmt = $db->prepare("
                    INSERT INTO teacher_collections 
                    (school_id, teacher_id, collection_type, amount, collection_date, payment_method, reference, remarks, recorded_by)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $school_id,
                    $teacher_id,
                    $collection_type,
                    $amount,
                    $collection_date,
                    $payment_method,
                    $reference,
                    $remarks,
                    $current_user['user_id']
                ]);
                
                log_activity($current_user['user_id'], "Recorded $collection_type collection from teacher", 'teacher_collections', $db->lastInsertId());
                set_message('success', '✅ Collection recorded successfully! Amount matches daily collection.');
                redirect(APP_URL . '/accountant/teacher-collections.php');
            } catch (PDOException $e) {
                set_message('error', 'Error recording collection: ' . $e->getMessage());
            }
        }
        
        if ($_POST['action'] == 'update_collection') {
            $collection_id = (int)$_POST['collection_id'];
            $amount = (float)$_POST['amount'];
            $collection_date = sanitize_input($_POST['collection_date']);
            $payment_method = sanitize_input($_POST['payment_method']);
            $reference = sanitize_input($_POST['reference'] ?? '');
            $remarks = sanitize_input($_POST['remarks'] ?? '');
            
            try {
                $stmt = $db->prepare("
                    UPDATE teacher_collections 
                    SET amount = ?, collection_date = ?, payment_method = ?, reference = ?, remarks = ?
                    WHERE collection_id = ? AND school_id = ?
                ");
                $stmt->execute([$amount, $collection_date, $payment_method, $reference, $remarks, $collection_id, $school_id]);
                
                log_activity($current_user['user_id'], "Updated teacher collection #$collection_id", 'teacher_collections', $collection_id);
                set_message('success', 'Collection updated successfully!');
                redirect(APP_URL . '/accountant/teacher-collections.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating collection: ' . $e->getMessage());
            }
        }
        
        if ($_POST['action'] == 'delete_collection') {
            $collection_id = (int)$_POST['collection_id'];
            
            try {
                $stmt = $db->prepare("
                    DELETE FROM teacher_collections 
                    WHERE collection_id = ? AND school_id = ?
                ");
                $stmt->execute([$collection_id, $school_id]);
                
                log_activity($current_user['user_id'], "Deleted teacher collection #$collection_id", 'teacher_collections', $collection_id);
                set_message('success', 'Collection deleted successfully!');
                redirect(APP_URL . '/accountant/teacher-collections.php');
            } catch (PDOException $e) {
                set_message('error', 'Error deleting collection: ' . $e->getMessage());
            }
        }
    }
}

// Get canteen teachers with error handling
$canteen_teachers = [];
try {
    $stmt = $db->prepare("
        SELECT u.user_id, u.first_name, u.last_name, u.email,
               COALESCE(SUM(tc.amount), 0) as total_collected,
               COUNT(tc.collection_id) as collection_count,
               MAX(tc.collection_date) as last_collection
        FROM users u
        LEFT JOIN teacher_collections tc ON u.user_id = tc.teacher_id AND tc.collection_type = 'canteen'
        WHERE u.school_id = ? AND u.role = 'teacher' AND u.status = 'active'
        GROUP BY u.user_id, u.first_name, u.last_name, u.email
        ORDER BY u.first_name, u.last_name
    ");
    $stmt->execute([$school_id]);
    $canteen_teachers = $stmt->fetchAll();
} catch (PDOException $e) {
    $canteen_teachers = [];
}

// Get bus teachers with error handling
$bus_teachers = [];
try {
    $stmt = $db->prepare("
        SELECT u.user_id, u.first_name, u.last_name, u.email,
               COALESCE(SUM(tc.amount), 0) as total_collected,
               COUNT(tc.collection_id) as collection_count,
               MAX(tc.collection_date) as last_collection
        FROM users u
        LEFT JOIN teacher_collections tc ON u.user_id = tc.teacher_id AND tc.collection_type = 'bus'
        WHERE u.school_id = ? AND u.role = 'teacher' AND u.status = 'active'
        GROUP BY u.user_id, u.first_name, u.last_name, u.email
        ORDER BY u.first_name, u.last_name
    ");
    $stmt->execute([$school_id]);
    $bus_teachers = $stmt->fetchAll();
} catch (PDOException $e) {
    $bus_teachers = [];
}

// Get all teachers for dropdown with error handling
$all_teachers = [];
try {
    $stmt = $db->prepare("
        SELECT user_id, first_name, last_name 
        FROM users 
        WHERE school_id = ? AND role = 'teacher' AND status = 'active'
        ORDER BY first_name, last_name
    ");
    $stmt->execute([$school_id]);
    $all_teachers = $stmt->fetchAll();
} catch (PDOException $e) {
    $all_teachers = [];
}

// Get recent collections with error handling
$recent_collections = [];
try {
    $stmt = $db->prepare("
        SELECT tc.*, u.first_name, u.last_name,
               ur.first_name as recorded_by_first, ur.last_name as recorded_by_last
        FROM teacher_collections tc
        INNER JOIN users u ON tc.teacher_id = u.user_id
        LEFT JOIN users ur ON tc.submitted_by = ur.user_id
        WHERE tc.school_id = ?
        ORDER BY tc.collection_date DESC, tc.created_at DESC
        LIMIT 50
    ");
    $stmt->execute([$school_id]);
    $recent_collections = $stmt->fetchAll();
} catch (PDOException $e) {
    // teacher_collections table may not exist yet
    $recent_collections = [];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fas fa-hand-holding-usd"></i>  Teacher Collections</h1>
    </div>

    <style>
    .tab-buttons {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
    }
    .tab-button {
        padding: 12px 24px;
        border: none;
        background: var(--bg-secondary);
        color: var(--text-primary);
        cursor: pointer;
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s;
    }
    .tab-button.active {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        color: white;
    }
    .tab-content {
        display: none;
    }
    .tab-content.active {
        display: block;
    }
    </style>
    
    <!-- Page Header -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        
        <button onclick="openRecordModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Record Collection
        </button>
    </div>
    
    <!-- Amount Mismatch Error Modal -->
    <?php if (isset($_GET['show_error']) && isset($_SESSION['amount_mismatch_error'])): ?>
        <?php $error = $_SESSION['amount_mismatch_error']; ?>
        <div id="errorModal" style="display: block; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 10000; overflow-y: auto;">
            <div style="max-width: 550px; margin: 80px auto; background: var(--bg-card); border-radius: 20px; padding: 0; box-shadow: 0 20px 60px rgba(0,0,0,0.5); animation: slideDown 0.3s ease-out;">
                <!-- Header -->
                <div style="background: linear-gradient(135deg, #ef5350 0%, #e53935 100%); padding: 25px 30px; border-radius: 20px 20px 0 0; color: white;">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <div style="width: 60px; height: 60px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 32px;">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div>
                            <h2 style="margin: 0; font-size: 24px; font-weight: 700;">❌ Amount Mismatch!</h2>
                            <p style="margin: 5px 0 0 0; opacity: 0.95; font-size: 14px;">The entered amount does not match</p>
                        </div>
                    </div>
                </div>
                
                <!-- Body -->
                <div style="padding: 30px;">
                    <!-- Teacher Info -->
                    <div style="background: var(--bg-secondary); padding: 20px; border-radius: 12px; margin-bottom: 25px;">
                        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 10px;">
                            <i class="fas fa-user-tie" style="font-size: 24px; color: var(--primary-blue);"></i>
                            <div>
                                <div style="font-size: 12px; color: var(--text-secondary); margin-bottom: 3px;">Teacher</div>
                                <div style="font-size: 18px; font-weight: 700; color: var(--text-primary);"><?php echo htmlspecialchars($error['teacher_name']); ?></div>
                            </div>
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border-color);">
                            <div>
                                <div style="font-size: 11px; color: var(--text-secondary); margin-bottom: 3px;">Collection Type</div>
                                <div style="font-weight: 600; color: var(--text-primary);"><?php echo $error['collection_type']; ?></div>
                            </div>
                            <div>
                                <div style="font-size: 11px; color: var(--text-secondary); margin-bottom: 3px;">Date</div>
                                <div style="font-weight: 600; color: var(--text-primary);"><?php echo $error['collection_date']; ?></div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Amount Comparison -->
                    <div style="margin-bottom: 25px;">
                        <h3 style="margin: 0 0 15px 0; font-size: 16px; color: var(--text-primary); display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-calculator"></i> Amount Comparison
                        </h3>
                        
                        <div style="display: grid; gap: 12px;">
                            <!-- Expected Amount -->
                            <div style="background: linear-gradient(135deg, #4caf50 0%, #43a047 100%); padding: 18px; border-radius: 12px; color: white;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <div style="font-size: 12px; opacity: 0.9; margin-bottom: 3px;">✅ Expected Amount (<?php echo $error['collection_date']; ?>)</div>
                                        <div style="font-size: 28px; font-weight: 800;"><?php echo format_currency($error['expected_amount']); ?></div>
                                        <?php if (isset($error['student_count']) && $error['student_count'] > 0): ?>
                                        <div style="font-size: 11px; opacity: 0.85; margin-top: 5px;">
                                            <i class="fas fa-users"></i> From <?php echo $error['student_count']; ?> student<?php echo $error['student_count'] != 1 ? 's' : ''; ?>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    <div style="font-size: 40px; opacity: 0.3;">
                                        <i class="fas fa-check-circle"></i>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Entered Amount -->
                            <div style="background: linear-gradient(135deg, #ef5350 0%, #e53935 100%); padding: 18px; border-radius: 12px; color: white;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <div style="font-size: 12px; opacity: 0.9; margin-bottom: 3px;">❌ Amount You Entered</div>
                                        <div style="font-size: 28px; font-weight: 800;"><?php echo format_currency($error['entered_amount']); ?></div>
                                    </div>
                                    <div style="font-size: 40px; opacity: 0.3;">
                                        <i class="fas fa-times-circle"></i>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Difference -->
                            <?php $difference = abs($error['entered_amount'] - $error['expected_amount']); ?>
                            <div style="background: var(--bg-secondary); padding: 15px; border-radius: 12px; border: 2px dashed #ff9800;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div style="font-size: 14px; font-weight: 600; color: var(--text-primary);">
                                        <i class="fas fa-exclamation-circle" style="color: #ff9800;"></i> Difference
                                    </div>
                                    <div style="font-size: 20px; font-weight: 700; color: #ff9800;"><?php echo format_currency($difference); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Warning Message -->
                    <div style="background: #fff3cd; border-left: 4px solid #ff9800; padding: 15px; border-radius: 8px; margin-bottom: 25px;">
                        <div style="display: flex; gap: 12px;">
                            <div style="font-size: 24px; color: #ff9800;">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                            <div style="flex: 1;">
                                <strong style="color: #856404; display: block; margin-bottom: 5px;">Please Verify!</strong>
                                <p style="margin: 0; color: #856404; font-size: 14px; line-height: 1.6;">
                                    The amount you entered does NOT match the teacher's daily <?php echo strtolower($error['collection_type']); ?> collection for <?php echo $error['collection_date']; ?>. 
                                    Please verify with the teacher and ensure you have the <strong>exact amount</strong> before recording!
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Action Button -->
                    <div style="text-align: center;">
                        <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
                            <a href="verify-teacher-collection.php?teacher_id=<?php echo $error['teacher_id']; ?>&type=<?php echo strtolower($error['collection_type']); ?>&date=<?php echo isset($error['collection_date_raw']) ? $error['collection_date_raw'] : date('Y-m-d', strtotime($error['collection_date'])); ?>" 
                               class="btn btn-info" 
                               style="padding: 14px 30px; font-size: 16px; font-weight: 600; background: linear-gradient(135deg, #3B82F6, #1D4ED8); border: none; box-shadow: 0 4px 15px rgba(59,130,246,0.4);">
                                <i class="fas fa-search-dollar"></i> View Detailed Breakdown
                            </a>
                            
                            <button onclick="closeErrorModal()" class="btn btn-primary" style="padding: 14px 40px; font-size: 16px; font-weight: 600; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); border: none; box-shadow: 0 4px 15px rgba(102,126,234,0.4);">
                                <i class="fas fa-redo"></i> OK, Let Me Re-enter the Correct Amount
                            </button>
                        </div>
                        <p style="margin-top: 15px; font-size: 13px; color: var(--text-secondary);">
                            <i class="fas fa-lightbulb"></i> Expected amount is from daily collections on <strong><?php echo $error['collection_date']; ?></strong>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        </style>
        
        <script>
        // Close error modal and re-open record modal with pre-filled data
        function closeErrorModal() {
            document.getElementById('errorModal').style.display = 'none';
            
            // Open record modal with pre-filled data
            openRecordModal();
            
            // Pre-fill the form
            document.getElementById('teacherId').value = '<?php echo $error['teacher_id']; ?>';
            document.getElementById('collectionType').value = '<?php echo strtolower($error['collection_type']); ?>';
            document.getElementById('collectionDate').value = '<?php echo date('Y-m-d', strtotime($error['collection_date'])); ?>';
            document.getElementById('amount').value = '<?php echo $error['expected_amount']; ?>'; // Pre-fill with correct amount
            document.getElementById('paymentMethod').value = '<?php echo $error['payment_method']; ?>';
            document.getElementById('reference').value = '<?php echo htmlspecialchars($error['reference'], ENT_QUOTES); ?>';
            document.getElementById('remarks').value = '<?php echo htmlspecialchars($error['remarks'], ENT_QUOTES); ?>';
            document.getElementById('modalTitle').textContent = 'Collect from <?php echo htmlspecialchars($error['teacher_name']); ?>';
            
            // Focus on amount field
            setTimeout(() => {
                document.getElementById('amount').focus();
                document.getElementById('amount').select();
            }, 300);
            
            // Clear error from session
            window.history.replaceState({}, document.title, window.location.pathname);
        }
        </script>
        <?php unset($_SESSION['amount_mismatch_error']); ?>
    <?php endif; ?>
    
    <!-- Info Alert -->
    <div class="alert alert-info" style="margin-bottom: 30px;">
        <i class="fas fa-info-circle"></i>
        <strong>Teacher Collections:</strong> Record money collected from teachers assigned to canteen or bus services. Track all collections and payment history.
    </div>
    
    <!-- Tabs -->
    <div class="tab-buttons">
        <button class="tab-button active" onclick="switchTab('canteen')">
            <i class="fas fa-utensils"></i> Canteen Teachers
        </button>
        <button class="tab-button" onclick="switchTab('bus')">
            <i class="fas fa-bus"></i> Bus Teachers
        </button>
        <button class="tab-button" onclick="switchTab('recent')">
            <i class="fas fa-history"></i> Recent Collections
        </button>
    </div>
    
    <!-- Canteen Teachers Tab -->
    <div id="canteen-tab" class="tab-content active">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-utensils"></i> Canteen Teachers</h3>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Teacher Name</th>
                            <th>Email</th>
                            <th>Total Collected</th>
                            <th>Collections</th>
                            <th>Last Collection</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($canteen_teachers) > 0): ?>
                            <?php foreach ($canteen_teachers as $teacher): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($teacher['email']); ?></td>
                                    <td><strong style="color: var(--success-green);"><?php echo format_currency($teacher['total_collected']); ?></strong></td>
                                    <td><?php echo $teacher['collection_count']; ?></td>
                                    <td><?php echo $teacher['last_collection'] ? date('M d, Y', strtotime($teacher['last_collection'])) : '-'; ?></td>
                                    <td>
                                        <button onclick="collectFromTeacher(<?php echo $teacher['user_id']; ?>, 'canteen', '<?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']); ?>')" 
                                                class="btn btn-sm btn-success">
                                            <i class="fas fa-plus"></i> Collect
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 40px;">
                                    <i class="fas fa-inbox" style="font-size: 48px; color: var(--text-secondary); display: block; margin-bottom: 10px;"></i>
                                    <h3>No Canteen Teachers</h3>
                                    <p style="color: var(--text-secondary);">Assign teachers to canteen in admin panel</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Bus Teachers Tab -->
    <div id="bus-tab" class="tab-content">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-bus"></i> Bus Teachers</h3>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Teacher Name</th>
                            <th>Email</th>
                            <th>Total Collected</th>
                            <th>Collections</th>
                            <th>Last Collection</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($bus_teachers) > 0): ?>
                            <?php foreach ($bus_teachers as $teacher): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($teacher['email']); ?></td>
                                    <td><strong style="color: var(--success-green);"><?php echo format_currency($teacher['total_collected']); ?></strong></td>
                                    <td><?php echo $teacher['collection_count']; ?></td>
                                    <td><?php echo $teacher['last_collection'] ? date('M d, Y', strtotime($teacher['last_collection'])) : '-'; ?></td>
                                    <td>
                                        <button onclick="collectFromTeacher(<?php echo $teacher['user_id']; ?>, 'bus', '<?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']); ?>')" 
                                                class="btn btn-sm btn-success">
                                            <i class="fas fa-plus"></i> Collect
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align: center; padding: 40px;">
                                    <i class="fas fa-inbox" style="font-size: 48px; color: var(--text-secondary); display: block; margin-bottom: 10px;"></i>
                                    <h3>No Bus Teachers</h3>
                                    <p style="color: var(--text-secondary);">Assign teachers to bus services in admin panel</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Recent Collections Tab -->
    <div id="recent-tab" class="tab-content">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-history"></i> Recent Collections</h3>
            </div>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Teacher</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Reference</th>
                            <th>Recorded By</th>
                            <th>Remarks</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($recent_collections) > 0): ?>
                            <?php foreach ($recent_collections as $collection): ?>
                                <tr>
                                    <td><?php echo date('M d, Y', strtotime($collection['collection_date'])); ?></td>
                                    <td><strong><?php echo htmlspecialchars($collection['first_name'] . ' ' . $collection['last_name']); ?></strong></td>
                                    <td>
                                        <span class="badge" style="background: <?php echo $collection['collection_type'] == 'canteen' ? '#FF9800' : '#2196F3'; ?>; color: white;">
                                            <?php echo ucfirst($collection['collection_type']); ?>
                                        </span>
                                    </td>
                                    <td><strong><?php echo format_currency($collection['amount']); ?></strong></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $collection['payment_method'])); ?></td>
                                    <td><?php echo htmlspecialchars($collection['reference'] ?: '-'); ?></td>
                                    <td><?php echo htmlspecialchars(($collection['recorded_by_first'] ?? '') . ' ' . ($collection['recorded_by_last'] ?? '')); ?></td>
                                    <td><?php echo htmlspecialchars($collection['remarks'] ?: '-'); ?></td>
                                    <td>
                                        <button onclick="editCollection(<?php echo htmlspecialchars(json_encode($collection)); ?>)" class="btn btn-sm btn-info" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this collection?');">
                                            <input type="hidden" name="action" value="delete_collection">
                                            <input type="hidden" name="collection_id" value="<?php echo $collection['collection_id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="9" style="text-align: center; padding: 40px;">
                                    <i class="fas fa-inbox" style="font-size: 48px; color: var(--text-secondary); display: block; margin-bottom: 10px;"></i>
                                    <h3>No Collections Yet</h3>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Record Collection Modal -->
    <div id="recordModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Record Collection</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="collectionForm">
                <input type="hidden" name="action" value="record_collection">
                <input type="hidden" name="teacher_name" id="teacherNameHidden">
                
                <div class="form-group">
                    <label>Teacher *</label>
                    <select name="teacher_id" id="teacherId" required onchange="updateTeacherName()">
                        <option value="">Select Teacher</option>
                        <?php foreach ($all_teachers as $t): ?>
                            <option value="<?php echo $t['user_id']; ?>" data-name="<?php echo htmlspecialchars($t['first_name'] . ' ' . $t['last_name']); ?>">
                                <?php echo htmlspecialchars($t['first_name'] . ' ' . $t['last_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Collection Type *</label>
                    <select name="collection_type" id="collectionType" required onchange="fetchExpectedAmount()">
                        <option value="">Select Type</option>
                        <option value="canteen">Canteen</option>
                        <option value="bus">Bus/Transport</option>
                    </select>
                </div>
                
                <!-- Expected Amount Display (Shows after selecting teacher, type, and date) -->
                <div id="expectedAmountDisplay" style="display: none; background: #E8F5E9; border-left: 4px solid #10B981; padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                    <div style="font-size: 13px; color: #2E7D32; font-weight: 600; margin-bottom: 5px;">
                        <i class="fas fa-info-circle"></i> Expected Amount from Daily Collections:
                    </div>
                    <div id="expectedAmountValue" style="font-size: 28px; font-weight: bold; color: #10B981;"></div>
                    <div style="font-size: 12px; color: #2E7D32; margin-top: 5px;">
                        This is the exact amount the teacher collected on the selected date.
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Amount (₵) *</label>
                        <input type="number" name="amount" id="amount" step="0.01" required 
                               oninput="validateAmountMatch()" 
                               style="font-size: 18px; font-weight: bold; padding: 12px;">
                        <input type="hidden" id="expectedAmount" value="0">
                        <div id="amountValidation" style="display: none; margin-top: 8px; padding: 10px; border-radius: 5px; font-weight: bold;"></div>
                    </div>
                    
                    <div class="form-group">
                        <label>Collection Date *</label>
                        <input type="date" name="collection_date" id="collectionDate" value="<?php echo date('Y-m-d'); ?>" required onchange="fetchExpectedAmount()">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Payment Method *</label>
                    <select name="payment_method" id="paymentMethod" required>
                        <option value="">Select Method</option>
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="mobile_money">Mobile Money</option>
                        <option value="cheque">Cheque</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Reference (Receipt/Cheque #)</label>
                    <input type="text" name="reference" id="reference" placeholder="e.g., REC001">
                </div>
                
                <div class="form-group">
                    <label>Remarks/Notes</label>
                    <textarea name="remarks" id="remarks" rows="2" placeholder="Additional notes"></textarea>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Record Collection
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Collection Modal -->
    <div id="editModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Edit Collection</h2>
                <button onclick="closeEditModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="update_collection">
                <input type="hidden" name="collection_id" id="editCollectionId">
                
                <div class="form-group">
                    <label>Teacher</label>
                    <input type="text" id="editTeacherName" readonly style="background: var(--bg-secondary);">
                </div>
                
                <div class="form-group">
                    <label>Collection Type</label>
                    <input type="text" id="editCollectionType" readonly style="background: var(--bg-secondary);">
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Amount (₵) *</label>
                        <input type="number" name="amount" id="editAmount" step="0.01" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Collection Date *</label>
                        <input type="date" name="collection_date" id="editCollectionDate" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Payment Method *</label>
                    <select name="payment_method" id="editPaymentMethod" required>
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="mobile_money">Mobile Money</option>
                        <option value="cheque">Cheque</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Reference</label>
                    <input type="text" name="reference" id="editReference">
                </div>
                
                <div class="form-group">
                    <label>Remarks/Notes</label>
                    <textarea name="remarks" id="editRemarks" rows="2"></textarea>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Collection
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    let expectedAmountGlobal = 0;
    let submitAllowed = false;
    
    function switchTab(tab) {
        // Hide all tabs
        document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
        document.querySelectorAll('.tab-button').forEach(el => el.classList.remove('active'));
        
        // Show selected tab
        document.getElementById(tab + '-tab').classList.add('active');
        event.target.classList.add('active');
    }
    
    function updateTeacherName() {
        const select = document.getElementById('teacherId');
        const selectedOption = select.options[select.selectedIndex];
        const teacherName = selectedOption.getAttribute('data-name') || '';
        document.getElementById('teacherNameHidden').value = teacherName;
        
        // Reset expected amount when teacher changes
        document.getElementById('expectedAmountDisplay').style.display = 'none';
        document.getElementById('expectedAmount').value = '0';
        expectedAmountGlobal = 0;
        submitAllowed = false;
    }
    
    function openRecordModal() {
        document.getElementById('recordModal').style.display = 'block';
        document.getElementById('collectionForm').reset();
        document.getElementById('collectionDate').value = '<?php echo date('Y-m-d'); ?>';
        document.getElementById('expectedAmountDisplay').style.display = 'none';
        document.getElementById('amountValidation').style.display = 'none';
        expectedAmountGlobal = 0;
        submitAllowed = false;
    }
    
    function collectFromTeacher(teacherId, type, name) {
        openRecordModal();
        document.getElementById('teacherId').value = teacherId;
        document.getElementById('collectionType').value = type;
        document.getElementById('modalTitle').textContent = 'Collect from ' + name;
        document.getElementById('teacherNameHidden').value = name;
        
        // Auto-fetch expected amount
        setTimeout(() => {
            fetchExpectedAmount();
        }, 100);
    }
    
    function closeModal() {
        document.getElementById('recordModal').style.display = 'none';
    }
    
    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
    }
    
    // Fetch expected amount from daily collections
    function fetchExpectedAmount() {
        const teacherId = document.getElementById('teacherId').value;
        const collectionType = document.getElementById('collectionType').value;
        const collectionDate = document.getElementById('collectionDate').value;
        
        if (!teacherId || !collectionType || !collectionDate) {
            document.getElementById('expectedAmountDisplay').style.display = 'none';
            return;
        }
        
        // Fetch via AJAX
        fetch(`get-teacher-daily-amount.php?teacher_id=${teacherId}&type=${collectionType}&date=${collectionDate}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    expectedAmountGlobal = parseFloat(data.amount);
                    document.getElementById('expectedAmount').value = expectedAmountGlobal;
                    document.getElementById('expectedAmountValue').textContent = '₵' + expectedAmountGlobal.toFixed(2);
                    document.getElementById('expectedAmountDisplay').style.display = 'block';
                    
                    // Auto-fill amount field with expected amount
                    document.getElementById('amount').value = expectedAmountGlobal.toFixed(2);
                    
                    // Validate immediately
                    validateAmountMatch();
                } else {
                    // No collections found
                    expectedAmountGlobal = 0;
                    document.getElementById('expectedAmount').value = '0';
                    document.getElementById('expectedAmountValue').textContent = '₵0.00';
                    document.getElementById('expectedAmountDisplay').style.display = 'block';
                    
                    // Show warning
                    const validation = document.getElementById('amountValidation');
                    validation.style.display = 'block';
                    validation.style.background = '#FFF3E0';
                    validation.style.color = '#E65100';
                    validation.style.border = '1px solid #FF9800';
                    validation.innerHTML = '<i class="fas fa-exclamation-triangle"></i> No daily collections found for this teacher on this date.';
                }
            }
        });
    }
    
    function validateAmountMatch() {
        const enteredAmount = parseFloat(document.getElementById('amount').value) || 0;
        const expectedAmount = expectedAmountGlobal;
        const validation = document.getElementById('amountValidation');
        const tolerance = 0.01;
        
        if (Math.abs(enteredAmount - expectedAmount) <= tolerance) {
            validation.style.display = 'none';
            document.querySelector('button[type="submit"]').disabled = false;
        } else {
            validation.style.display = 'block';
            validation.style.background = '#FFEBEE';
            validation.style.color = '#C62828';
            validation.style.border = '1px solid #EF5350';
            validation.innerHTML = '<i class="fas fa-times-circle"></i> Amount mismatch! Expected: ₵' + expectedAmount.toFixed(2) + ', but got: ₵' + enteredAmount.toFixed(2);
            document.querySelector('button[type="submit"]').disabled = true;
        }
    }
</script>

<?php include BASE_PATH . '/includes/footer.php'; ?>
```

```
