<?php
// accountant/collect-school-fees.php - Collect School Fees by Class
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Collect School Fees';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle payment submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'record_payment') {
    $student_id = (int)$_POST['student_id'];
    $amount = (float)$_POST['amount'];
    $payment_method = sanitize_input($_POST['payment_method']);
    $payment_reference = sanitize_input($_POST['payment_reference'] ?? '');
    $payment_date = sanitize_input($_POST['payment_date']);
    $term_id = !empty($_POST['term_id']) ? (int)$_POST['term_id'] : NULL;
    $paid_by = sanitize_input($_POST['paid_by'] ?? '');
    $paid_by_phone = sanitize_input($_POST['paid_by_phone'] ?? '');
    $remarks = sanitize_input($_POST['remarks'] ?? '');
    
    try {
        $db->beginTransaction();
        
        // Check if student is exempted from school fees
        $stmt = $db->prepare("
            SELECT fee_exemption, exemption_reason 
            FROM students 
            WHERE student_id = ? AND school_id = ?
        ");
        $stmt->execute([$student_id, $school_id]);
        $student_check = $stmt->fetch();
        
        if ($student_check) {
            $exemptions = json_decode($student_check['fee_exemption'] ?? '[]', true) ?: [];
            
            // Check if student is exempted from school fees
            if (in_array('school', $exemptions)) {
                $db->rollBack();
                $reason = $student_check['exemption_reason'] ?? 'No reason provided';
                set_message('error', "Cannot record payment! This student is EXEMPTED from School fees. Reason: {$reason}");
                redirect(APP_URL . '/accountant/collect-school-fees.php?class_id=' . $_POST['class_id']);
                exit;
            }
        }
        
        // Check if payment_type column exists
        $stmt = $db->query("SHOW COLUMNS FROM payments LIKE 'payment_type'");
        $has_payment_type = $stmt->rowCount() > 0;
        
        // Check if paid_by columns exist
        $stmt = $db->query("SHOW COLUMNS FROM payments LIKE 'paid_by'");
        $has_paid_by = $stmt->rowCount() > 0;
        
        if (!$has_paid_by) {
            // Add paid_by columns if they don't exist
            $db->exec("ALTER TABLE payments ADD COLUMN paid_by VARCHAR(255) DEFAULT NULL AFTER payment_reference");
            $db->exec("ALTER TABLE payments ADD COLUMN paid_by_phone VARCHAR(20) DEFAULT NULL AFTER paid_by");
        }
        
        // Check if remarks column exists
        $stmt = $db->query("SHOW COLUMNS FROM payments LIKE 'remarks'");
        $has_remarks = $stmt->rowCount() > 0;
        
        if (!$has_remarks) {
            $db->exec("ALTER TABLE payments ADD COLUMN remarks TEXT DEFAULT NULL");
        }
        
        // Insert payment with all fields
        if ($has_payment_type && $has_remarks) {
            $stmt = $db->prepare("
                INSERT INTO payments (
                    school_id, student_id, amount, payment_type, payment_method, 
                    payment_reference, paid_by, paid_by_phone, payment_date, 
                    term_id, status, remarks, created_at, updated_at
                )
                VALUES (?, ?, ?, 'tuition', ?, ?, ?, ?, ?, ?, 'paid', ?, NOW(), NOW())
            ");
            $stmt->execute([
                $school_id, $student_id, $amount, $payment_method, 
                $payment_reference, $paid_by, $paid_by_phone, $payment_date, 
                $term_id, $remarks
            ]);
        } elseif ($has_payment_type) {
            $stmt = $db->prepare("
                INSERT INTO payments (
                    school_id, student_id, amount, payment_type, payment_method, 
                    payment_reference, paid_by, paid_by_phone, payment_date, 
                    term_id, status, created_at
                )
                VALUES (?, ?, ?, 'tuition', ?, ?, ?, ?, ?, ?, 'paid', NOW())
            ");
            $stmt->execute([
                $school_id, $student_id, $amount, $payment_method, 
                $payment_reference, $paid_by, $paid_by_phone, $payment_date, $term_id
            ]);
        } else {
            $stmt = $db->prepare("
                INSERT INTO payments (
                    school_id, student_id, amount, payment_method, 
                    payment_reference, paid_by, paid_by_phone, payment_date, 
                    term_id, status, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'paid', NOW())
            ");
            $stmt->execute([
                $school_id, $student_id, $amount, $payment_method, 
                $payment_reference, $paid_by, $paid_by_phone, $payment_date, $term_id
            ]);
        }
        
        $payment_id = $db->lastInsertId();
        
        // Update student fees balance if student_fees table exists
        try {
            $stmt = $db->prepare("
                INSERT INTO student_fees (school_id, student_id, total_paid, last_payment_date, updated_at)
                VALUES (?, ?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE 
                    total_paid = total_paid + ?,
                    last_payment_date = ?,
                    updated_at = NOW()
            ");
            $stmt->execute([$school_id, $student_id, $amount, $payment_date, $amount, $payment_date]);
        } catch (PDOException $e) {
            // student_fees table might not exist, that's okay - payments table is primary
            error_log("Student fees update skipped: " . $e->getMessage());
        }
        
        // Send SMS notification to parent if available
        try {
            if (file_exists(BASE_PATH . '/includes/sms-helper.php')) {
                require_once BASE_PATH . '/includes/sms-helper.php';
                $sms = new SMSHelper($school_id);
                $sms->sendPaymentSMS($student_id, $amount, 'tuition', $payment_reference);
            }
        } catch (Exception $e) {
            error_log("SMS notification failed: " . $e->getMessage());
        }
        
        $db->commit();
        
        log_activity($current_user['user_id'], "Recorded school fee payment of " . format_currency($amount) . " for student ID: $student_id", 'payments', $payment_id);
        set_message('success', 'Payment of ' . format_currency($amount) . ' recorded successfully! Now visible in Student Payments and all reports.');
        redirect(APP_URL . '/accountant/collect-school-fees.php?class_id=' . $_POST['class_id']);
    } catch (PDOException $e) {
        $db->rollBack();
        set_message('error', 'Error recording payment: ' . $e->getMessage());
    }
}

// Get selected class
$selected_class = isset($_GET['class_id']) ? (int)$_GET['class_id'] : null;

// Get all classes
$stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get students if class is selected
$students = [];
if ($selected_class) {
    $stmt = $db->prepare("
        SELECT 
            s.*,
            c.class_name,
            COALESCE(SUM(CASE WHEN p.status = 'paid' THEN p.amount ELSE 0 END), 0) as total_paid,
            COALESCE(SUM(CASE WHEN p.status = 'pending' THEN p.amount ELSE 0 END), 0) as total_pending
        FROM students s
        LEFT JOIN classes c ON s.class_id = c.class_id
        LEFT JOIN payments p ON s.student_id = p.student_id
        WHERE s.class_id = ? AND s.school_id = ? AND s.status = 'active'
        GROUP BY s.student_id
        ORDER BY s.first_name, s.last_name
    ");
    $stmt->execute([$selected_class, $school_id]);
    $students = $stmt->fetchAll();
}

// Get active term
$stmt = $db->prepare("SELECT * FROM terms WHERE status = 'active' LIMIT 1");
$stmt->execute();
$active_term = $stmt->fetch();

// Get all terms
$stmt = $db->prepare("SELECT * FROM terms ORDER BY term_name DESC");
$stmt->execute();
$terms = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .class-selector {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        gap: 15px;
        margin-bottom: 30px;
    }
    
    .class-btn {
        padding: 20px;
        background: white;
        border: 2px solid var(--border-color);
        border-radius: 8px;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s;
        text-decoration: none;
        color: var(--text-primary);
    }
    
    .class-btn:hover {
        border-color: var(--primary-blue);
        background: var(--bg-secondary);
        transform: translateY(-2px);
    }
    
    .class-btn.active {
        background: var(--primary-blue);
        color: white;
        border-color: var(--primary-blue);
    }
    
    .class-btn i {
        font-size: 24px;
        margin-bottom: 10px;
        display: block;
    }
    
    .student-row {
        padding: 15px;
        border-bottom: 1px solid var(--border-color);
        display: grid;
        grid-template-columns: 2fr 1fr 1fr 1fr auto;
        gap: 15px;
        align-items: center;
    }
    
    .student-row:hover {
        background: var(--bg-secondary);
    }
    
    .payment-modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
        align-items: center;
        justify-content: center;
    }
    
    .payment-modal.active {
        display: flex;
    }
    
    .modal-content {
        background: white;
        padding: 30px;
        border-radius: 12px;
        max-width: 500px;
        width: 90%;
        max-height: 90vh;
        overflow-y: auto;
    }
    </style>
    
    <!-- Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #667eea, #764ba2); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-graduation-cap"></i> Collect School Fees
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Select a class to view students and collect fees
            </p>
        </div>
    </div>
    
    <!-- Class Selection -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-users"></i> Select Class</h3>
        </div>
        <div style="padding: 20px;">
            <div class="class-selector">
                <?php foreach ($classes as $class): ?>
                    <a href="?class_id=<?php echo $class['class_id']; ?>" 
                       class="class-btn <?php echo $selected_class == $class['class_id'] ? 'active' : ''; ?>">
                        <i class="fas fa-chalkboard-teacher"></i>
                        <strong><?php echo $class['class_name']; ?></strong>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <?php if ($selected_class && count($students) > 0): ?>
    <!-- Students List -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-user-graduate"></i> Students in <?php 
                $selected_class_name = '';
                foreach ($classes as $c) {
                    if ($c['class_id'] == $selected_class) {
                        $selected_class_name = $c['class_name'];
                        break;
                    }
                }
                echo $selected_class_name;
            ?></h3>
            <div>
                <span class="badge badge-info"><?php echo count($students); ?> Students</span>
            </div>
        </div>
        <div>
            <!-- Header Row -->
            <div class="student-row" style="background: var(--bg-secondary); font-weight: 600;">
                <div>Student Details</div>
                <div>Total Paid</div>
                <div>Outstanding</div>
                <div>Status</div>
                <div>Action</div>
            </div>
            
            <!-- Student Rows -->
            <?php foreach ($students as $student): ?>
                <?php 
                $is_fully_paid = $student['total_pending'] == 0 && $student['total_paid'] > 0;
                $has_outstanding = $student['total_pending'] > 0;
                ?>
                <div class="student-row">
                    <div>
                        <strong><?php echo $student['first_name'] . ' ' . $student['last_name']; ?></strong>
                        <br>
                        <small style="color: var(--text-secondary);">
                            <?php echo $student['admission_number']; ?>
                        </small>
                    </div>
                    <div>
                        <strong style="color: var(--success-green);">
                            <?php echo format_currency($student['total_paid']); ?>
                        </strong>
                    </div>
                    <div>
                        <strong style="color: <?php echo $has_outstanding ? 'var(--danger-red)' : 'var(--text-secondary)'; ?>">
                            <?php echo format_currency($student['total_pending']); ?>
                        </strong>
                    </div>
                    <div>
                        <?php if ($is_fully_paid): ?>
                            <span class="badge badge-success">Fully Paid</span>
                        <?php elseif ($has_outstanding): ?>
                            <span class="badge badge-warning">Outstanding</span>
                        <?php else: ?>
                            <span class="badge badge-secondary">No Payment</span>
                        <?php endif; ?>
                    </div>
                    <div>
                        <button onclick="openPaymentModal(<?php echo htmlspecialchars(json_encode($student)); ?>)" 
                                class="btn btn-primary btn-sm">
                            <i class="fas fa-plus"></i> Add Payment
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <?php elseif ($selected_class): ?>
    <div class="card">
        <div style="padding: 60px; text-align: center; color: var(--text-secondary);">
            <i class="fas fa-user-slash" style="font-size: 64px; margin-bottom: 20px; display: block;"></i>
            <h3>No Students Found</h3>
            <p>There are no active students in this class.</p>
        </div>
    </div>
    
    <?php else: ?>
    <div class="card">
        <div style="padding: 60px; text-align: center; color: var(--text-secondary);">
            <i class="fas fa-hand-pointer" style="font-size: 64px; margin-bottom: 20px; display: block;"></i>
            <h3>Select a Class</h3>
            <p>Please select a class above to view students and collect fees.</p>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Payment Modal -->
    <div id="paymentModal" class="payment-modal">
        <div class="modal-content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h3 style="margin: 0;"><i class="fas fa-money-check-alt"></i> Record Payment</h3>
                <button onclick="closePaymentModal()" class="btn btn-outline" style="padding: 5px 10px;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="paymentForm">
                <input type="hidden" name="action" value="record_payment">
                <input type="hidden" name="student_id" id="modal_student_id">
                <input type="hidden" name="class_id" value="<?php echo $selected_class; ?>">
                
                <div id="studentInfo" style="background: var(--bg-secondary); padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <!-- Student info will be inserted here -->
                </div>
                
                <div class="form-group">
                    <label>Amount <span style="color: red;">*</span></label>
                    <input type="number" name="amount" step="0.01" required class="form-control" placeholder="Enter amount">
                </div>
                
                <div class="form-group">
                    <label>Paid By (Name)</label>
                    <input type="text" name="paid_by" class="form-control" placeholder="Name of person making payment (optional)">
                </div>
                
                <div class="form-group">
                    <label>Phone Number (Optional)</label>
                    <input type="text" name="paid_by_phone" class="form-control" placeholder="Contact phone number">
                </div>
                
                <div class="form-group">
                    <label>Payment Method <span style="color: red;">*</span></label>
                    <select name="payment_method" required class="form-control">
                        <option value="">Select method</option>
                        <option value="cash">Cash</option>
                        <option value="bank_transfer">Bank Transfer</option>
                        <option value="mobile_money">Mobile Money</option>
                        <option value="card">Card Payment</option>
                        <option value="cheque">Cheque</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Payment Reference (Optional)</label>
                    <input type="text" name="payment_reference" class="form-control" placeholder="Transaction ID, Receipt No, etc.">
                </div>
                
                <div class="form-group">
                    <label>Payment Date <span style="color: red;">*</span></label>
                    <input type="date" name="payment_date" required class="form-control" value="<?php echo date('Y-m-d'); ?>">
                </div>
                
                <div class="form-group">
                    <label>Term</label>
                    <select name="term_id" class="form-control">
                        <option value="">Select term (optional)</option>
                        <?php foreach ($terms as $term): ?>
                            <option value="<?php echo $term['term_id']; ?>" 
                                    <?php echo ($active_term && $active_term['term_id'] == $term['term_id']) ? 'selected' : ''; ?>>
                                <?php echo $term['term_name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="submit" class="btn btn-success" style="flex: 1;">
                        <i class="fas fa-check"></i> Record Payment
                    </button>
                    <button type="button" onclick="closePaymentModal()" class="btn btn-outline" style="flex: 1;">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function openPaymentModal(student) {
        document.getElementById('modal_student_id').value = student.student_id;
        document.getElementById('studentInfo').innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: start;">
                <div>
                    <strong style="font-size: 16px;">${student.first_name} ${student.last_name}</strong><br>
                    <small style="color: var(--text-secondary);">${student.admission_number}</small>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 12px; color: var(--text-secondary);">Total Paid</div>
                    <strong style="color: var(--success-green); font-size: 16px;"><?php echo CURRENCY_SYMBOL; ?>${parseFloat(student.total_paid).toLocaleString()}</strong>
                </div>
            </div>
        `;
        document.getElementById('paymentModal').classList.add('active');
    }
    
    function closePaymentModal() {
        document.getElementById('paymentModal').classList.remove('active');
        document.getElementById('paymentForm').reset();
    }
    
    // Close modal on outside click
    document.getElementById('paymentModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closePaymentModal();
        }
    });
    </script>

</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
