<?php
// accountant/student-payments.php - Student Payment Records
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Student Payment Records';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get filter parameters
$filter_class = isset($_GET['class_id']) && !empty($_GET['class_id']) ? (int)$_GET['class_id'] : null;
$search = isset($_GET['search']) ? sanitize_input($_GET['search']) : '';

// Get classes for filtering
$stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Build query to get students with their payment summary
$query = "SELECT 
        s.student_id,
        s.admission_number,
        u.first_name,
        u.last_name,
        c.class_name,
        s.class_id,
        COALESCE(SUM(CASE WHEN p.status IN ('paid', 'completed') THEN p.amount ELSE 0 END), 0) as total_paid,
        COALESCE(SUM(CASE WHEN p.status = 'pending' THEN p.amount ELSE 0 END), 0) as total_pending,
        COUNT(CASE WHEN p.status IN ('paid', 'completed') THEN 1 END) as payment_count,
        MAX(CASE WHEN p.status IN ('paid', 'completed') THEN p.payment_date END) as last_payment_date,
        MAX(CASE WHEN p.status IN ('paid', 'completed') THEN p.created_at END) as last_payment_time
    FROM students s
    INNER JOIN users u ON s.user_id = u.user_id
    LEFT JOIN classes c ON s.class_id = c.class_id
    LEFT JOIN payments p ON s.student_id = p.student_id AND p.school_id = s.school_id
    WHERE s.school_id = ? AND s.status = 'active'";

$params = [$school_id];

if ($filter_class) {
    $query .= " AND s.class_id = ?";
    $params[] = $filter_class;
}

if ($search) {
    $query .= " AND (s.admission_number LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $params[] = $search_term;
}

$query .= " GROUP BY s.student_id, s.admission_number, u.first_name, u.last_name, c.class_name, s.class_id
            ORDER BY c.class_name, u.first_name, u.last_name";

$stmt = $db->prepare($query);
$stmt->execute($params);
$students = $stmt->fetchAll();

// Calculate total fees for each student
foreach ($students as &$student) {
    if ($student['class_id']) {
        $stmt = $db->prepare("
            SELECT COALESCE(SUM(amount), 0) as total
            FROM fee_structure
            WHERE school_id = ? AND class_id = ?
        ");
        $stmt->execute([$school_id, $student['class_id']]);
        $student['total_fees'] = $stmt->fetch()['total'];
        $student['outstanding'] = max(0, $student['total_fees'] - $student['total_paid']);
    } else {
        $student['total_fees'] = 0;
        $student['outstanding'] = 0;
    }
}
unset($student);

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fas fa-users"></i>  Student Payment Records</h1>
    </div>

    <!-- Page Header -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        
        <a href="<?php echo APP_URL; ?>/accountant/payments.php" class="btn btn-primary">
            <i class="fas fa-arrow-left"></i> Back to Payments
        </a>
    </div>
    
    <!-- Filters -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-filter"></i> Filter Students</h3>
        </div>
        <div style="padding: 20px;">
            <form method="GET" action="" style="display: grid; grid-template-columns: 1fr 1fr auto; gap: 15px; align-items: end;">
                <div class="form-group" style="margin: 0;">
                    <label>Class</label>
                    <select name="class_id" onchange="this.form.submit()">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>" <?php echo $filter_class == $class['class_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>Search Student</label>
                    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name or Admission No.">
                </div>
                
                <div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Search
                    </button>
                    <?php if ($filter_class || $search): ?>
                        <a href="<?php echo APP_URL; ?>/accountant/student-payments.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Clear
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Statistics -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo count($students); ?></h3>
                <p>Total Students</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo format_currency(array_sum(array_column($students, 'total_paid'))); ?></h3>
                <p>Total Collected</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon red">
                <i class="fas fa-exclamation-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo format_currency(array_sum(array_column($students, 'outstanding'))); ?></h3>
                <p>Total Outstanding</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-receipt"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo array_sum(array_column($students, 'payment_count')); ?></h3>
                <p>Total Payments</p>
            </div>
        </div>
    </div>
    
    <!-- Students Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-table"></i> Student Payment Records (<?php echo count($students); ?>)</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Admission No.</th>
                        <th>Student Name</th>
                        <th>Class</th>
                        <th>Total Fees</th>
                        <th>Total Paid</th>
                        <th>Outstanding</th>
                        <th>Payments</th>
                        <th>Last Payment</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($students) > 0): ?>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($student['admission_number']); ?></strong></td>
                                <td>
                                    <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?>
                                </td>
                                <td><?php echo htmlspecialchars($student['class_name'] ?: '-'); ?></td>
                                <td><strong><?php echo format_currency($student['total_fees']); ?></strong></td>
                                <td>
                                    <span style="color: var(--success-green); font-weight: bold;">
                                        <?php echo format_currency($student['total_paid']); ?>
                                    </span>
                                </td>
                                <td>
                                    <span style="color: <?php echo $student['outstanding'] > 0 ? 'var(--danger-red)' : 'var(--success-green)'; ?>; font-weight: bold;">
                                        <?php echo format_currency($student['outstanding']); ?>
                                    </span>
                                </td>
                                <td><?php echo $student['payment_count']; ?></td>
                                <td>
                                    <?php echo $student['last_payment_date'] ? date('M d, Y', strtotime($student['last_payment_date'])) : '-'; ?>
                                </td>
                                <td>
                                    <a href="<?php echo APP_URL; ?>/accountant/payments.php?student_id=<?php echo $student['student_id']; ?>" 
                                       class="btn btn-sm btn-info" title="View Payments">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo APP_URL; ?>/accountant/payments.php?add_payment=<?php echo $student['student_id']; ?>" 
                                       class="btn btn-sm btn-success" title="Add Payment">
                                        <i class="fas fa-plus"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="9" style="text-align: center; padding: 40px;">
                                <i class="fas fa-inbox" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 10px; display: block;"></i>
                                <h3>No Students Found</h3>
                                <p style="color: var(--text-secondary);">Try adjusting your filters</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    </div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
