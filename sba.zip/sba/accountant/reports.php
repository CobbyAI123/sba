<?php
// accountant/reports.php - Redirect to Revenue Reports
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$current_user = check_permission(['accountant']);

// Redirect to revenue reports
redirect(APP_URL . '/accountant/revenue-reports.php');
?>
