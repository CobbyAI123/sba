<?php
// accountant/get-teacher-daily-amount.php - Get teacher's exact daily collection amount
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

header('Content-Type: application/json');

$current_user = check_permission(['accountant', 'admin', 'super_admin']);
$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

$teacher_id = isset($_GET['teacher_id']) ? intval($_GET['teacher_id']) : 0;
$collection_type = isset($_GET['type']) ? sanitize_input($_GET['type']) : '';
$date = isset($_GET['date']) ? sanitize_input($_GET['date']) : '';

if (!$teacher_id || !$collection_type || !$date) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

try {
    // Get the exact amount this teacher collected on the specified date
    if ($collection_type === 'canteen') {
        $stmt = $db->prepare("
            SELECT SUM(dc.canteen_amount) as total_amount,
                   COUNT(CASE WHEN dc.canteen_paid = 1 THEN 1 END) as count_paid
            FROM daily_collections dc
            WHERE dc.marked_by = ?
            AND dc.school_id = ?
            AND dc.collection_date = ?
            AND dc.canteen_paid = 1
        ");
    } else { // bus
        $stmt = $db->prepare("
            SELECT SUM(dc.bus_amount) as total_amount,
                   COUNT(CASE WHEN dc.bus_paid = 1 THEN 1 END) as count_paid
            FROM daily_collections dc
            WHERE dc.marked_by = ?
            AND dc.school_id = ?
            AND dc.collection_date = ?
            AND dc.bus_paid = 1
        ");
    }
    
    $stmt->execute([$teacher_id, $school_id, $date]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $amount = floatval($result['total_amount'] ?? 0);
    $count = intval($result['count_paid'] ?? 0);
    
    if ($amount > 0) {
        echo json_encode([
            'success' => true,
            'amount' => $amount,
            'count' => $count,
            'type' => $collection_type,
            'date' => $date
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'amount' => 0,
            'message' => 'No daily collections found for this teacher on this date'
        ]);
    }
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
