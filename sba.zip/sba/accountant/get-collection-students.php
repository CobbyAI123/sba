<?php
// accountant/get-collection-students.php - Get student collection details (Read-only for accountant)
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

header('Content-Type: application/json');

$current_user = check_permission(['accountant', 'admin', 'super_admin']);
$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

$teacher_id = isset($_GET['teacher_id']) ? intval($_GET['teacher_id']) : 0;
$class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
$date = isset($_GET['date']) ? sanitize_input($_GET['date']) : '';

if (!$teacher_id || !$class_id || !$date) {
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit;
}

try {
    // Get class name
    $stmt = $db->prepare("SELECT class_name FROM classes WHERE class_id = ? AND school_id = ?");
    $stmt->execute([$class_id, $school_id]);
    $class_info = $stmt->fetch();
    
    if (!$class_info) {
        echo json_encode(['success' => false, 'message' => 'Class not found']);
        exit;
    }
    
    // Get all students with their collection data
    $stmt = $db->prepare("
        SELECT 
            s.student_id,
            CONCAT(u.first_name, ' ', u.last_name) as student_name,
            s.canteen_fee_type,
            s.bus_fee_type,
            s.exempt_canteen,
            s.exempt_bus,
            h.hometown_name,
            a.status as attendance_status,
            dc.canteen_paid,
            dc.canteen_amount,
            dc.bus_paid,
            dc.bus_amount
        FROM students s
        INNER JOIN users u ON s.user_id = u.user_id
        LEFT JOIN hometowns h ON s.hometown_id = h.hometown_id
        LEFT JOIN attendance a ON s.student_id = a.student_id AND a.date = ? AND a.school_id = ?
        LEFT JOIN daily_collections dc ON s.student_id = dc.student_id 
            AND dc.collection_date = ? 
            AND dc.marked_by = ?
            AND dc.school_id = ?
        WHERE s.class_id = ?
        AND s.school_id = ?
        AND s.status = 'active'
        ORDER BY u.first_name, u.last_name
    ");
    
    $stmt->execute([
        $date, $school_id,  // attendance
        $date, $teacher_id, $school_id,  // daily_collections
        $class_id, $school_id  // students
    ]);
    
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'students' => $students,
        'class_name' => $class_info['class_name']
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
