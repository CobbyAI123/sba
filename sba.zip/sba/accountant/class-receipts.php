<?php
// accountant/class-receipts.php - Print Class-Based Payment Receipts and Arrears
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Class Receipts & Arrears';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get all classes
$classes = [];
try {
    $stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
    $stmt->execute([$school_id]);
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $classes = [];
}

// Get students and their payment records for selected class
$class_data = [];
$selected_class = null;
$class_id = isset($_GET['class_id']) ? sanitize_input($_GET['class_id']) : '';
$report_type = isset($_GET['report_type']) ? sanitize_input($_GET['report_type']) : 'recent'; // recent, arrears, or all
$date_from = isset($_GET['date_from']) ? sanitize_input($_GET['date_from']) : '';
$date_to = isset($_GET['date_to']) ? sanitize_input($_GET['date_to']) : '';

if ($class_id) {
    try {
        // Get class info
        $stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE class_id = ? AND school_id = ?");
        $stmt->execute([$class_id, $school_id]);
        $selected_class = $stmt->fetch();
        
        // Get students in this class
        $stmt = $db->prepare("
            SELECT s.student_id, s.admission_number, u.first_name, u.last_name
            FROM students s
            INNER JOIN users u ON s.user_id = u.user_id
            WHERE s.class_id = ? AND s.school_id = ?
            ORDER BY s.admission_number
        ");
        $stmt->execute([$class_id, $school_id]);
        $students = $stmt->fetchAll();
        
        foreach ($students as $student) {
            $student_id = $student['student_id'];
            
            // Get total fees expected for this student
            $stmt = $db->prepare("
                SELECT COALESCE(SUM(fs.amount), 0) as total_expected
                FROM fee_structure fs
                WHERE fs.school_id = ?
                AND (fs.class_id = ? OR fs.class_id IS NULL)
                AND fs.status = 'active'
            ");
            $stmt->execute([$school_id, $class_id]);
            $fee_result = $stmt->fetch();
            $total_expected = $fee_result['total_expected'];
            
            // Get payments based on report type
            $query = "SELECT p.* FROM payments p WHERE p.student_id = ? AND p.school_id = ?";
            $params = [$student_id, $school_id];
            
            if ($date_from) {
                $query .= " AND p.payment_date >= ?";
                $params[] = $date_from;
            }
            if ($date_to) {
                $query .= " AND p.payment_date <= ?";
                $params[] = $date_to;
            }
            
            $query .= " ORDER BY p.payment_date DESC";
            
            $stmt = $db->prepare($query);
            $stmt->execute($params);
            $payments = $stmt->fetchAll();
            
            $total_paid = array_reduce($payments, function($carry, $item) {
                return $carry + $item['amount'];
            }, 0);
            
            // Calculate arrears
            $arrears = max(0, $total_expected - $total_paid);
            
            $class_data[] = [
                'student' => $student,
                'payments' => $payments,
                'total_paid' => $total_paid,
                'total_expected' => $total_expected,
                'arrears' => $arrears
            ];
        }
    } catch (PDOException $e) {
        $class_data = [];
    }
}

// Filter based on report type
$filtered_data = $class_data;
if ($report_type == 'arrears') {
    $filtered_data = array_filter($class_data, function($item) {
        return $item['arrears'] > 0; // Has arrears
    });
} elseif ($report_type == 'paid') {
    $filtered_data = array_filter($class_data, function($item) {
        return $item['arrears'] == 0 && $item['total_paid'] > 0; // Fully paid
    });
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
        .receipt-container {
            background: white;
            color: black;
            padding: 30px;
            border-radius: 8px;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            page-break-inside: avoid;
        }
    
        .receipt-header {
            text-align: center;
            margin-bottom: 25px;
            border-bottom: 3px solid var(--primary-blue);
            padding-bottom: 15px;
        }
    
        .receipt-title {
            font-size: 20px;
            font-weight: 700;
            margin: 5px 0;
        }
    
        .student-receipt {
            margin-bottom: 30px;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 6px;
            page-break-inside: avoid;
        }
    
        .student-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
    
        .student-name {
            font-weight: 600;
            font-size: 14px;
        }
    
        .student-amount {
            font-weight: 700;
            font-size: 14px;
            color: var(--primary-blue);
        }
    
        .print-btn {
            display: none;
        }
    
        .no-print {
            page-break-inside: avoid;
        }
    
        @media print {
            .no-print {
                display: none !important;
            }
    
            .receipt-container {
                box-shadow: none;
            }
    
            .student-receipt {
                border: 1px solid #ccc;
            }
        }
    
        .filter-form {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
        }
    
        .report-type-selector {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }
    
        .report-type-btn {
            padding: 8px 15px;
            border: 2px solid var(--border-color);
            background: transparent;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.3s ease;
        }
    
        .report-type-btn.active {
            background: var(--primary-blue);
            color: white;
            border-color: var(--primary-blue);
        }
    </style>
    
    <!-- Page Header -->
    <div class="card no-print" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #1976D2); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-file-pdf"></i> Class Receipts & Arrears Report
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Generate and print payment reports for entire classes
            </p>
        </div>
    </div>
    
    <!-- Filter Form -->
    <div class="card no-print">
        <div class="card-header">
            <h3><i class="fas fa-filter"></i> Report Filters</h3>
        </div>
        <div class="filter-form">
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr auto; gap: 15px; align-items: end; margin-bottom: 20px;">
                <div class="form-group">
                    <label for="class_select">Select Class *</label>
                    <select id="class_select" onchange="updateForm()">
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>" <?php echo $class_id == $class['class_id'] ? 'selected' : ''; ?>>
                                <?php echo $class['class_name']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="date_from">From Date</label>
                    <input type="date" id="date_from" value="<?php echo $date_from; ?>">
                </div>
                
                <div class="form-group">
                    <label for="date_to">To Date</label>
                    <input type="date" id="date_to" value="<?php echo $date_to; ?>">
                </div>
                
                <button onclick="applyFilter()" class="btn btn-primary">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </div>
    
            <?php if ($class_id): ?>
                <div style="border-top: 1px solid var(--border-color); padding-top: 15px;">
                    <label style="margin-bottom: 10px; display: block; font-weight: 600;">Report Type</label>
                    <div class="report-type-selector">
                        <button onclick="setReportType('recent')" class="report-type-btn <?php echo $report_type == 'recent' ? 'active' : ''; ?>">
                            <i class="fas fa-clock"></i> Recent Payments
                        </button>
                        <button onclick="setReportType('paid')" class="report-type-btn <?php echo $report_type == 'paid' ? 'active' : ''; ?>">
                            <i class="fas fa-check-circle"></i> Paid Students
                        </button>
                        <button onclick="setReportType('arrears')" class="report-type-btn <?php echo $report_type == 'arrears' ? 'active' : ''; ?>">
                            <i class="fas fa-exclamation-circle"></i> Arrears
                        </button>
                        <button onclick="setReportType('all')" class="report-type-btn <?php echo $report_type == 'all' ? 'active' : ''; ?>">
                            <i class="fas fa-list"></i> All Students
                        </button>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if ($selected_class && count($filtered_data) > 0): ?>
        <!-- Receipt Display -->
        <div class="receipt-container">
            <div class="receipt-header">
                <div class="receipt-title"><?php echo $selected_class['class_name']; ?> - PAYMENT REPORT</div>
                <div style="font-size: 13px; color: #666;">
                    Generated on <?php echo date('d M, Y H:i'); ?>
                </div>
                <?php if ($date_from || $date_to): ?>
                    <div style="font-size: 12px; color: #999; margin-top: 5px;">
                        <?php echo $date_from ? 'From: ' . date('d M, Y', strtotime($date_from)) : ''; ?>
                        <?php echo ($date_from && $date_to) ? ' to ' : ''; ?>
                        <?php echo $date_to ? date('d M, Y', strtotime($date_to)) : ''; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <div style="margin-bottom: 20px;">
                <strong>Total Students in Report:</strong> <?php echo count($filtered_data); ?>
            </div>
            
            <!-- Student Receipts -->
            <?php foreach ($filtered_data as $item): ?>
                <div class="student-receipt">
                    <div class="student-header">
                        <div>
                            <div class="student-name"><?php echo $item['student']['first_name'] . ' ' . $item['student']['last_name']; ?></div>
                            <div style="font-size: 11px; color: #999;">ID: <?php echo $item['student']['admission_number']; ?></div>
                        </div>
                        <div style="text-align: right;">
                            <?php if ($item['arrears'] > 0): ?>
                                <div class="student-amount" style="color: var(--danger-red);">
                                    Arrears: <?php echo format_currency($item['arrears']); ?>
                                </div>
                                <div style="font-size: 11px; color: #666;">
                                    Paid: <?php echo format_currency($item['total_paid']); ?> / <?php echo format_currency($item['total_expected']); ?>
                                </div>
                            <?php elseif ($item['total_paid'] > 0): ?>
                                <div class="student-amount" style="color: var(--success-green);">
                                    Fully Paid: <?php echo format_currency($item['total_paid']); ?>
                                </div>
                                <div style="font-size: 11px; color: #4CAF50;">Paid <?php echo count($item['payments']); ?> time(s)</div>
                            <?php else: ?>
                                <div class="student-amount" style="color: var(--danger-red);">No Payment</div>
                                <div style="font-size: 11px; color: var(--danger-red);">
                                    Expected: <?php echo format_currency($item['total_expected']); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Fee Breakdown -->
                    <div style="background: #f9f9f9; padding: 10px; border-radius: 4px; margin-bottom: 10px; font-size: 11px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                            <span><strong>Total Expected Fees:</strong></span>
                            <span style="font-weight: 600;"><?php echo format_currency($item['total_expected']); ?></span>
                        </div>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 5px; color: var(--success-green);">
                            <span><strong>Total Paid:</strong></span>
                            <span style="font-weight: 600;"><?php echo format_currency($item['total_paid']); ?></span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding-top: 5px; border-top: 1px solid #ddd;">
                            <span><strong>Balance/Arrears:</strong></span>
                            <span style="font-weight: 700; color: <?php echo $item['arrears'] > 0 ? 'var(--danger-red)' : 'var(--success-green)'; ?>">
                                <?php echo format_currency($item['arrears']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <?php if (count($item['payments']) > 0): ?>
                        <div style="font-size: 11px; color: #666;">
                            <strong>Payment History:</strong>
                            <?php foreach ($item['payments'] as $payment): ?>
                                <div style="display: flex; justify-content: space-between; padding: 3px 0; border-bottom: 1px solid #f0f0f0;">
                                    <span><?php echo date('d M, Y', strtotime($payment['payment_date'])); ?></span>
                                    <span><?php echo format_currency($payment['amount']); ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
            
            <div style="margin-top: 30px; padding-top: 20px; border-top: 2px solid var(--primary-blue);">
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; text-align: center;">
                    <div>
                        <div style="font-size: 12px; color: #666; margin-bottom: 5px;">Total Expected</div>
                        <div style="font-size: 18px; font-weight: 700; color: var(--text-primary);">
                            <?php 
                                $total_expected_sum = array_reduce($filtered_data, function($carry, $item) {
                                    return $carry + $item['total_expected'];
                                }, 0);
                                echo format_currency($total_expected_sum);
                            ?>
                        </div>
                    </div>
                    <div>
                        <div style="font-size: 12px; color: #666; margin-bottom: 5px;">Total Collected</div>
                        <div style="font-size: 18px; font-weight: 700; color: var(--success-green);">
                            <?php 
                                $total_collected = array_reduce($filtered_data, function($carry, $item) {
                                    return $carry + $item['total_paid'];
                                }, 0);
                                echo format_currency($total_collected);
                            ?>
                        </div>
                    </div>
                    <div>
                        <div style="font-size: 12px; color: #666; margin-bottom: 5px;">Total Arrears</div>
                        <div style="font-size: 18px; font-weight: 700; color: var(--danger-red);">
                            <?php 
                                $total_arrears = array_reduce($filtered_data, function($carry, $item) {
                                    return $carry + $item['arrears'];
                                }, 0);
                                echo format_currency($total_arrears);
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Print Button -->
        <div class="no-print" style="margin-top: 30px; display: flex; gap: 10px; justify-content: center;">
            <button onclick="window.print()" class="btn btn-primary" style="padding: 12px 30px;">
                <i class="fas fa-print"></i> Print Class Report
            </button>
            <a href="<?php echo APP_URL; ?>/accountant/class-receipts.php" class="btn btn-secondary" style="padding: 12px 30px; text-decoration: none;">
                <i class="fas fa-redo"></i> New Report
            </a>
        </div>
    <?php elseif ($selected_class): ?>
        <div class="card no-print">
            <div style="padding: 40px; text-align: center; color: var(--text-secondary);">
                <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 15px; display: block; opacity: 0.5;"></i>
                <h3>No Records Found</h3>
                <p>No students or payment records found for the selected filters.</p>
            </div>
        </div>
    <?php elseif (!$class_id): ?>
        <div class="card no-print">
            <div style="padding: 60px; text-align: center; color: var(--text-secondary);">
                <i class="fas fa-search" style="font-size: 48px; margin-bottom: 15px; display: block; opacity: 0.5;"></i>
                <h3>Select a Class</h3>
                <p>Choose a class to generate payment reports and arrears summaries.</p>
            </div>
        </div>
    <?php endif; ?>
    
    <script>
    function applyFilter() {
        const classId = document.getElementById('class_select').value;
        const dateFrom = document.getElementById('date_from').value;
        const dateTo = document.getElementById('date_to').value;
        
        if (!classId) {
            alert('Please select a class');
            return;
        }
        
        let url = '?class_id=' + classId + '&report_type=<?php echo $report_type; ?>';
        if (dateFrom) url += '&date_from=' + dateFrom;
        if (dateTo) url += '&date_to=' + dateTo;
        
        window.location.href = url;
    }
    
    function setReportType(type) {
        const classId = document.getElementById('class_select').value;
        const dateFrom = document.getElementById('date_from').value;
        const dateTo = document.getElementById('date_to').value;
        
        let url = '?class_id=' + classId + '&report_type=' + type;
        if (dateFrom) url += '&date_from=' + dateFrom;
        if (dateTo) url += '&date_to=' + dateTo;
        
        window.location.href = url;
    }
    
    function updateForm() {
        const classId = document.getElementById('class_select').value;
        if (classId) {
            applyFilter();
        }
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
