<?php
// accountant/school-fees.php - Collect School Fees by Class and Student
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Collect School Fees';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle fee collection
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'collect') {
    $student_id = (int)sanitize_input($_POST['student_id']);
    $amount = (float)sanitize_input($_POST['amount']);
    $payment_date = sanitize_input($_POST['payment_date']);
    $term_id = (int)sanitize_input($_POST['term_id']);
    $reference = sanitize_input($_POST['reference'] ?? '');
    
    // Auto-generate reference number if empty
    if (empty($reference)) {
        $reference = 'SF' . date('ymd') . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 4));
    }
    
    try {
        $db->beginTransaction();
        
        // Check if student is exempted from school fees
        $stmt = $db->prepare("
            SELECT fee_exemption, exemption_reason 
            FROM students 
            WHERE student_id = ? AND school_id = ?
        ");
        $stmt->execute([$student_id, $school_id]);
        $student_check = $stmt->fetch();
        
        if ($student_check) {
            $exemptions = json_decode($student_check['fee_exemption'] ?? '[]', true) ?: [];
            
            // Check if student is exempted from school fees
            if (in_array('school', $exemptions)) {
                $db->rollBack();
                $reason = $student_check['exemption_reason'] ?? 'No reason provided';
                set_message('error', "Cannot record payment! This student is EXEMPTED from School fees. Reason: {$reason}");
                redirect(APP_URL . '/accountant/school-fees.php?class_id=' . $_POST['class_id']);
                exit;
            }
        }
        
        // Insert into transactions table
        $stmt = $db->prepare("
            INSERT INTO transactions (
                school_id, student_id, term_id, amount, 
                payment_method, reference, transaction_type, 
                status, user_id, payment_date, created_at
            )
            VALUES (?, ?, ?, ?, 'Cash', ?, 'fee_payment', 'completed', ?, ?, NOW())
        ");
        $stmt->execute([
            $school_id, 
            $student_id, 
            $term_id, 
            $amount, 
            $reference, 
            $current_user['user_id'],
            $payment_date
        ]);
        
        $transaction_id = $db->lastInsertId();
        
        // Also insert into payments table for backward compatibility (if table exists)
        try {
            $stmt = $db->prepare("
                INSERT INTO payments (
                    school_id, student_id, amount, payment_date, 
                    payment_type, reference, status, created_by, term_id
                )
                VALUES (?, ?, ?, ?, 'school_fees', ?, 'completed', ?, ?)
            ");
            $stmt->execute([
                $school_id, 
                $student_id, 
                $amount, 
                $payment_date, 
                $reference, 
                $current_user['user_id'], 
                $term_id
            ]);
        } catch (PDOException $e) {
            // Table might not exist, continue anyway
        }
        
        log_activity(
            $current_user['user_id'], 
            "Collected school fees: " . format_currency($amount) . " from student ID: $student_id (Ref: $reference)", 
            'transactions', 
            $transaction_id
        );
        
        $db->commit();
        
        set_message('success', "Fee of " . format_currency($amount) . " collected successfully! Reference: $reference");
        redirect(APP_URL . '/accountant/school-fees.php');
    } catch (PDOException $e) {
        $db->rollBack();
        set_message('error', 'Error collecting fee: ' . $e->getMessage());
    }
}

// Get all terms
$terms = [];
try {
    $stmt = $db->prepare("SELECT term_id, term_name, session_year FROM terms WHERE school_id = ? ORDER BY session_year DESC, term_name DESC");
    $stmt->execute([$school_id]);
    $terms = $stmt->fetchAll();
} catch (PDOException $e) {
    $terms = [];
}

// Get all classes
$classes = [];
try {
    $stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
    $stmt->execute([$school_id]);
    $classes = $stmt->fetchAll();
} catch (PDOException $e) {
    $classes = [];
}

// Get students for selected class
$students = [];
$selected_class = isset($_GET['class_id']) ? sanitize_input($_GET['class_id']) : '';
if ($selected_class) {
    try {
        $stmt = $db->prepare("
            SELECT s.student_id, s.admission_number, CONCAT(COALESCE(u.first_name, 'Unknown'), ' ', COALESCE(u.last_name, '')) as student_name, u.first_name, u.last_name
            FROM students s
            LEFT JOIN users u ON s.user_id = u.user_id
            WHERE s.school_id = ? AND s.class_id = ?
            ORDER BY s.admission_number
        ");
        $stmt->execute([$school_id, $selected_class]);
        $students = $stmt->fetchAll();
    } catch (PDOException $e) {
        $students = [];
    }
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
        .fee-form-section {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
        }
    
        .form-section-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--border-color);
        }
    
        .student-list {
            max-height: 400px;
            overflow-y: auto;
            border: 2px solid var(--border-color);
            border-radius: 10px;
        }
    
        .student-item {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            cursor: pointer;
            transition: all 0.3s ease;
        }
    
        .student-item:hover {
            background: var(--bg-secondary);
        }
    
        .student-item.selected {
            background: rgba(33, 150, 243, 0.1);
            border-left: 4px solid var(--primary-blue);
        }
    
        .student-name {
            font-weight: 600;
            margin-bottom: 3px;
        }
    
        .student-meta {
            font-size: 12px;
            color: var(--text-secondary);
        }
    </style>
    
    <!-- Page Header -->
    <div class="card" style="margin-bottom: 30px; background: linear-gradient(135deg, #2196F3, #1976D2); color: white;">
        <div style="padding: 30px;">
            <h2 style="margin: 0 0 10px 0; color: white;">
                <i class="fas fa-money-bill-wave"></i> Collect School Fees
            </h2>
            <p style="margin: 0; font-size: 16px; opacity: 0.9;">
                Collect fees by selecting a class and student
            </p>
        </div>
    </div>
    
    <!-- Fee Collection Form -->
    <form method="POST" id="feeForm">
        <input type="hidden" name="action" value="collect">
        
        <!-- Step 1: Select Term -->
        <div class="fee-form-section">
            <div class="form-section-title">
                <i class="fas fa-calendar"></i> Step 1: Select Academic Term
            </div>
            <div class="form-group">
                <label for="term_id">Academic Term *</label>
                <select name="term_id" id="term_id" required>
                    <option value="">-- Select Term --</option>
                    <?php foreach ($terms as $term): ?>
                        <option value="<?php echo $term['term_id']; ?>">
                            <?php echo $term['term_name'] . ' - ' . $term['session_year']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <?php if (empty($terms)): ?>
                    <small style="color: var(--danger-red);"><i class="fas fa-exclamation-triangle"></i> No terms found. Create terms first.</small>
                <?php endif; ?>
            </div>
        </div>
    
        <!-- Step 2: Select Class -->
        <div class="fee-form-section">
            <div class="form-section-title">
                <i class="fas fa-book"></i> Step 2: Select Class
            </div>
            <div class="form-group">
                <label for="class_id">Class *</label>
                <select name="class_id" id="class_id" required onchange="loadStudents()">
                    <option value="">-- Select Class --</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['class_id']; ?>" <?php echo $selected_class == $class['class_id'] ? 'selected' : ''; ?>>
                            <?php echo $class['class_name']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    
        <!-- Step 3: Select Student -->
        <div class="fee-form-section">
            <div class="form-section-title">
                <i class="fas fa-user-graduate"></i> Step 3: Select Student
            </div>
            <div id="studentsContainer">
                <?php if (count($students) > 0): ?>
                    <div class="student-list">
                        <?php foreach ($students as $student): ?>
                            <div class="student-item" onclick="selectStudent('<?php echo $student['student_id']; ?>', '<?php echo htmlspecialchars(trim($student['first_name'] . ' ' . $student['last_name'])); ?>')">
                                <div class="student-name"><?php echo htmlspecialchars(trim($student['first_name'] . ' ' . $student['last_name'])); ?></div>
                                <div class="student-meta"><i class="fas fa-id-card"></i> <?php echo $student['admission_number']; ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div style="padding: 20px; text-align: center; color: var(--text-secondary);">
                        <i class="fas fa-inbox" style="font-size: 32px; margin-bottom: 10px; display: block; opacity: 0.5;"></i>
                        <p>Select a class to view students</p>
                    </div>
                <?php endif; ?>
            </div>
            <input type="hidden" name="student_id" id="student_id">
            <div id="selectedStudentDiv" style="margin-top: 15px; padding: 15px; background: rgba(76, 175, 80, 0.1); border-radius: 10px; display: none;">
                <strong>Selected Student:</strong> <span id="selectedStudentName"></span>
            </div>
        </div>
    
        <!-- Step 4: Fee Details -->
        <div class="fee-form-section">
            <div class="form-section-title">
                <i class="fas fa-receipt"></i> Step 4: Fee Details
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label for="amount">Amount *</label>
                    <input type="number" name="amount" id="amount" placeholder="0.00" step="0.01" min="0" required>
                </div>
                <div class="form-group">
                    <label for="payment_date">Payment Date *</label>
                    <input type="date" name="payment_date" id="payment_date" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label for="reference">Reference/Receipt No. (Optional)</label>
                <input type="text" name="reference" id="reference" placeholder="Leave empty to auto-generate (e.g., SF251110A3F2)">
                <small style="color: var(--text-secondary);">
                    <i class="fas fa-info-circle"></i> Reference will be automatically generated if left blank (Format: SF251110A3F2)
                </small>
            </div>
        </div>
    
        <!-- Submit Button -->
        <div style="display: flex; gap: 10px; justify-content: flex-end;">
            <a href="<?php echo APP_URL; ?>/accountant/dashboard.php" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-success" id="submitBtn" disabled style="opacity: 0.5; cursor: not-allowed;">
                <i class="fas fa-check-circle"></i> Confirm Payment
            </button>
        </div>
    </form>
    
    <script>
    function loadStudents() {
        const classId = document.getElementById('class_id').value;
        if (classId) {
            window.location.href = '?class_id=' + classId;
        }
    }
    
    function selectStudent(studentId, studentName) {
        document.getElementById('student_id').value = studentId;
        document.getElementById('selectedStudentName').textContent = studentName;
        document.getElementById('selectedStudentDiv').style.display = 'block';
        
        // Check if form is complete to enable button
        checkFormComplete();
        
        // Highlight selected student
        document.querySelectorAll('.student-item').forEach(item => item.classList.remove('selected'));
        event.currentTarget.classList.add('selected');
        
        // Scroll to form
        document.getElementById('feeForm').scrollIntoView({ behavior: 'smooth' });
    }
    
    // Enable/disable submit button based on form completion
    function checkFormComplete() {
        const termId = document.getElementById('term_id').value;
        const studentId = document.getElementById('student_id').value;
        const amount = document.getElementById('amount').value;
        const submitBtn = document.getElementById('submitBtn');
        
        if (termId && studentId && amount && parseFloat(amount) > 0) {
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.style.cursor = 'pointer';
        } else {
            submitBtn.disabled = true;
            submitBtn.style.opacity = '0.5';
            submitBtn.style.cursor = 'not-allowed';
        }
    }
    
    // Add event listeners to form fields
    document.getElementById('term_id').addEventListener('change', checkFormComplete);
    document.getElementById('amount').addEventListener('input', checkFormComplete);
    
    // Form validation
    document.getElementById('feeForm').addEventListener('submit', function(e) {
        const termId = document.getElementById('term_id').value;
        const studentId = document.getElementById('student_id').value;
        const amount = document.getElementById('amount').value;
        
        if (!termId) {
            e.preventDefault();
            alert('Please select a term');
            document.getElementById('term_id').focus();
            return false;
        }
        if (!studentId) {
            e.preventDefault();
            alert('Please select a student');
            return false;
        }
        if (!amount || parseFloat(amount) <= 0) {
            e.preventDefault();
            alert('Please enter a valid amount');
            document.getElementById('amount').focus();
            return false;
        }
        
        // Show loading state
        const submitBtn = document.getElementById('submitBtn');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
        
        return true;
    });
    
    // Set default payment date to today
    window.addEventListener('load', function() {
        document.getElementById('payment_date').valueAsDate = new Date();
    });
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
