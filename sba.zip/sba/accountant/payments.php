<?php
// accountant/payments.php - Manage Payments
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';
require_once BASE_PATH . '/includes/auto-update-session.php';

$page_title = 'Manage Payments';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'add') {
            $student_id = (int)$_POST['student_id'];
            $amount = (float)$_POST['amount'];
            $payment_method = sanitize_input($_POST['payment_method']);
            $payment_reference = sanitize_input($_POST['payment_reference'] ?? '');
            $payment_type = sanitize_input($_POST['payment_type'] ?? 'tuition');
            $term_id = !empty($_POST['term_id']) ? (int)$_POST['term_id'] : NULL;
            $remarks = sanitize_input($_POST['remarks'] ?? '');
            
            try {
                // Check if student is exempted from this fee type
                $stmt = $db->prepare("
                    SELECT fee_exemption, exemption_reason 
                    FROM students 
                    WHERE student_id = ? AND school_id = ?
                ");
                $stmt->execute([$student_id, $school_id]);
                $student = $stmt->fetch();
                
                if ($student) {
                    $exemptions = json_decode($student['fee_exemption'] ?? '[]', true) ?: [];
                    
                    // Map payment type to exemption type
                    $exemption_type = null;
                    if (stripos($payment_type, 'tuition') !== false || stripos($payment_type, 'school') !== false) {
                        $exemption_type = 'school';
                    } elseif (stripos($payment_type, 'canteen') !== false) {
                        $exemption_type = 'canteen';
                    } elseif (stripos($payment_type, 'transport') !== false || stripos($payment_type, 'bus') !== false) {
                        $exemption_type = 'transport';
                    }
                    
                    // Check if student is exempted from this fee
                    if ($exemption_type && in_array($exemption_type, $exemptions)) {
                        $fee_name = ucfirst($exemption_type);
                        $reason = $student['exemption_reason'] ?? 'No reason provided';
                        set_message('error', "Cannot record payment! This student is EXEMPTED from {$fee_name} fees. Reason: {$reason}");
                        redirect(APP_URL . '/accountant/payments.php');
                        exit;
                    }
                }
                
                $stmt = $db->prepare("
                    INSERT INTO payments (school_id, student_id, amount, payment_date, payment_method, payment_reference, payment_type, term_id, status, remarks)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'completed', ?)
                ");
                $stmt->execute([$school_id, $student_id, $amount, date('Y-m-d'), $payment_method, $payment_reference, $payment_type, $term_id, $remarks]);
                
                // Send SMS notification to parent if enabled
                try {
                    if (file_exists(BASE_PATH . '/includes/sms-helper.php')) {
                        require_once BASE_PATH . '/includes/sms-helper.php';
                        $sms = new SMSHelper($school_id);
                        // Pass payment reference for detailed SMS
                        $sms->sendPaymentSMS($student_id, $amount, $payment_type, $payment_reference);
                    }
                } catch (Exception $e) {
                    error_log("SMS notification failed: " . $e->getMessage());
                }
                
                log_activity($current_user['user_id'], "Recorded $payment_type payment of " . format_currency($amount) . " from student", 'payments', $db->lastInsertId());
                set_message('success', 'Payment of ' . format_currency($amount) . ' recorded successfully! SMS sent to parent.');
                redirect(APP_URL . '/accountant/payments.php');
            } catch (PDOException $e) {
                set_message('error', 'Error recording payment: ' . $e->getMessage());
            }
        }
        elseif ($_POST['action'] == 'update') {
            $payment_id = (int)$_POST['payment_id'];
            $student_id = (int)$_POST['student_id'];
            $amount = (float)$_POST['amount'];
            $payment_method = sanitize_input($_POST['payment_method']);
            $payment_reference = sanitize_input($_POST['payment_reference'] ?? '');
            $payment_type = sanitize_input($_POST['payment_type'] ?? 'tuition');
            $term_id = !empty($_POST['term_id']) ? (int)$_POST['term_id'] : NULL;
            $remarks = sanitize_input($_POST['remarks'] ?? '');
            
            try {
                // Check if student is exempted from this fee type
                $stmt = $db->prepare("
                    SELECT fee_exemption, exemption_reason 
                    FROM students 
                    WHERE student_id = ? AND school_id = ?
                ");
                $stmt->execute([$student_id, $school_id]);
                $student = $stmt->fetch();
                
                if ($student) {
                    $exemptions = json_decode($student['fee_exemption'] ?? '[]', true) ?: [];
                    
                    // Map payment type to exemption type
                    $exemption_type = null;
                    if (stripos($payment_type, 'tuition') !== false || stripos($payment_type, 'school') !== false) {
                        $exemption_type = 'school';
                    } elseif (stripos($payment_type, 'canteen') !== false) {
                        $exemption_type = 'canteen';
                    } elseif (stripos($payment_type, 'transport') !== false || stripos($payment_type, 'bus') !== false) {
                        $exemption_type = 'transport';
                    }
                    
                    // Check if student is exempted from this fee
                    if ($exemption_type && in_array($exemption_type, $exemptions)) {
                        $fee_name = ucfirst($exemption_type);
                        $reason = $student['exemption_reason'] ?? 'No reason provided';
                        set_message('error', "Cannot update payment! This student is EXEMPTED from {$fee_name} fees. Reason: {$reason}");
                        redirect(APP_URL . '/accountant/payments.php');
                        exit;
                    }
                }
                
                $stmt = $db->prepare("
                    UPDATE payments
                    SET student_id = ?, amount = ?, payment_method = ?, payment_reference = ?, payment_type = ?, term_id = ?, remarks = ?
                    WHERE payment_id = ? AND school_id = ?
                ");
                $stmt->execute([$student_id, $amount, $payment_method, $payment_reference, $payment_type, $term_id, $remarks, $payment_id, $school_id]);
                
                log_activity($current_user['user_id'], "Updated payment of " . format_currency($amount), 'payments', $payment_id);
                set_message('success', 'Payment of ' . format_currency($amount) . ' updated successfully! Changes reflected in proprietor reports.');
                redirect(APP_URL . '/accountant/payments.php');
            } catch (PDOException $e) {
                set_message('error', 'Error updating payment: ' . $e->getMessage());
            }
        }
        elseif ($_POST['action'] == 'delete') {
            $payment_id = (int)$_POST['payment_id'];
            
            try {
                $db->beginTransaction();
                
                // Get payment details before deleting
                $stmt = $db->prepare("SELECT * FROM payments WHERE payment_id = ? AND school_id = ?");
                $stmt->execute([$payment_id, $school_id]);
                $payment = $stmt->fetch();
                
                if ($payment) {
                    // Move to recycle bin
                    $stmt = $db->prepare("
                        INSERT INTO deleted_payments 
                        (payment_id, school_id, student_id, amount, payment_date, payment_method, 
                         payment_reference, payment_type, term_id, status, remarks, deleted_by)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $payment['payment_id'],
                        $payment['school_id'],
                        $payment['student_id'],
                        $payment['amount'],
                        $payment['payment_date'],
                        $payment['payment_method'],
                        $payment['payment_reference'] ?? null,
                        $payment['payment_type'] ?? 'tuition',
                        $payment['term_id'] ?? null,
                        $payment['status'],
                        $payment['remarks'] ?? null,
                        $current_user['user_id']
                    ]);
                    
                    // Delete from payments table
                    $stmt = $db->prepare("DELETE FROM payments WHERE payment_id = ? AND school_id = ?");
                    $stmt->execute([$payment_id, $school_id]);
                    
                    // Update student payment records (deduct amount)
                    // This ensures student balance reflects the deletion
                    try {
                        // If there's a student_payments summary table, update it
                        $stmt = $db->prepare("
                            UPDATE student_fees 
                            SET total_paid = total_paid - ?,
                                balance = balance + ?
                            WHERE student_id = ? AND school_id = ?
                        ");
                        $stmt->execute([$payment['amount'], $payment['amount'], $payment['student_id'], $school_id]);
                    } catch (PDOException $e) {
                        // Table might not exist, that's okay - payments are the source of truth
                        error_log("Student fees update skipped: " . $e->getMessage());
                    }
                    
                    $db->commit();
                    
                    log_activity($current_user['user_id'], "Deleted payment of " . format_currency($payment['amount']) . " (moved to recycle bin)", 'payments', $payment_id);
                    set_message('success', 'Payment of ' . format_currency($payment['amount']) . ' deleted! Student balance updated. Check recycle bin to restore.');
                } else {
                    $db->rollBack();
                    set_message('error', 'Payment not found!');
                }
                
                redirect(APP_URL . '/accountant/payments.php');
            } catch (PDOException $e) {
                $db->rollBack();
                set_message('error', 'Error deleting payment: ' . $e->getMessage());
            }
        }
        elseif ($_POST['action'] == 'restore') {
            $deleted_payment_id = (int)$_POST['deleted_payment_id'];
            
            try {
                $db->beginTransaction();
                
                // Get deleted payment details
                $stmt = $db->prepare("SELECT * FROM deleted_payments WHERE deleted_payment_id = ? AND school_id = ?");
                $stmt->execute([$deleted_payment_id, $school_id]);
                $deleted_payment = $stmt->fetch();
                
                if ($deleted_payment) {
                    // Restore to payments table
                    $stmt = $db->prepare("
                        INSERT INTO payments 
                        (school_id, student_id, amount, payment_date, payment_method, 
                         payment_reference, payment_type, term_id, status, remarks)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([
                        $deleted_payment['school_id'],
                        $deleted_payment['student_id'],
                        $deleted_payment['amount'],
                        $deleted_payment['payment_date'],
                        $deleted_payment['payment_method'],
                        $deleted_payment['payment_reference'] ?? null,
                        $deleted_payment['payment_type'] ?? 'tuition',
                        $deleted_payment['term_id'] ?? null,
                        $deleted_payment['status'],
                        $deleted_payment['remarks'] ?? null
                    ]);
                    
                    // Update student payment records (add amount back)
                    try {
                        $stmt = $db->prepare("
                            UPDATE student_fees 
                            SET total_paid = total_paid + ?,
                                balance = balance - ?
                            WHERE student_id = ? AND school_id = ?
                        ");
                        $stmt->execute([
                            $deleted_payment['amount'], 
                            $deleted_payment['amount'], 
                            $deleted_payment['student_id'], 
                            $school_id
                        ]);
                    } catch (PDOException $e) {
                        // Table might not exist, that's okay
                        error_log("Student fees update skipped: " . $e->getMessage());
                    }
                    
                    // Remove from recycle bin
                    $stmt = $db->prepare("DELETE FROM deleted_payments WHERE deleted_payment_id = ?");
                    $stmt->execute([$deleted_payment_id]);
                    
                    $db->commit();
                    
                    log_activity($current_user['user_id'], "Restored payment of " . format_currency($deleted_payment['amount']) . " from recycle bin", 'payments', $db->lastInsertId());
                    set_message('success', 'Payment of ' . format_currency($deleted_payment['amount']) . ' restored successfully! Student balance updated.');
                } else {
                    $db->rollBack();
                    set_message('error', 'Deleted payment not found!');
                }
                
                redirect(APP_URL . '/accountant/payments.php');
            } catch (PDOException $e) {
                $db->rollBack();
                set_message('error', 'Error restoring payment: ' . $e->getMessage());
            }
        }
        elseif ($_POST['action'] == 'permanent_delete') {
            $deleted_payment_id = (int)$_POST['deleted_payment_id'];
            
            try {
                // Get payment details before permanent deletion
                $stmt = $db->prepare("SELECT * FROM deleted_payments WHERE deleted_payment_id = ? AND school_id = ?");
                $stmt->execute([$deleted_payment_id, $school_id]);
                $payment = $stmt->fetch();
                
                if ($payment) {
                    // Permanently delete from recycle bin
                    $stmt = $db->prepare("DELETE FROM deleted_payments WHERE deleted_payment_id = ? AND school_id = ?");
                    $stmt->execute([$deleted_payment_id, $school_id]);
                    
                    log_activity($current_user['user_id'], "Permanently deleted payment ID {$payment['payment_id']} (Amount: " . format_currency($payment['amount']) . ") from recycle bin", 'payments', $deleted_payment_id);
                    set_message('success', 'Payment of ' . format_currency($payment['amount']) . ' permanently deleted!');
                } else {
                    set_message('error', 'Payment not found!');
                }
                
                redirect(APP_URL . '/accountant/payments.php');
            } catch (PDOException $e) {
                set_message('error', 'Error permanently deleting payment: ' . $e->getMessage());
            }
        }
        elseif ($_POST['action'] == 'bulk_permanent_delete') {
            if (isset($_POST['payment_ids']) && is_array($_POST['payment_ids'])) {
                try {
                    $deleted_count = 0;
                    $total_amount = 0;
                    
                    foreach ($_POST['payment_ids'] as $deleted_payment_id) {
                        $deleted_payment_id = (int)$deleted_payment_id;
                        
                        // Get payment details
                        $stmt = $db->prepare("SELECT * FROM deleted_payments WHERE deleted_payment_id = ? AND school_id = ?");
                        $stmt->execute([$deleted_payment_id, $school_id]);
                        $payment = $stmt->fetch();
                        
                        if ($payment) {
                            // Permanently delete
                            $stmt = $db->prepare("DELETE FROM deleted_payments WHERE deleted_payment_id = ? AND school_id = ?");
                            $stmt->execute([$deleted_payment_id, $school_id]);
                            
                            $deleted_count++;
                            $total_amount += $payment['amount'];
                        }
                    }
                    
                    log_activity($current_user['user_id'], "Bulk permanently deleted {$deleted_count} payments (Total: " . format_currency($total_amount) . ") from recycle bin", 'payments', null);
                    set_message('success', "{$deleted_count} payment(s) permanently deleted! Total amount: " . format_currency($total_amount));
                } catch (PDOException $e) {
                    set_message('error', 'Error bulk deleting payments: ' . $e->getMessage());
                }
            } else {
                set_message('error', 'No payments selected!');
            }
            
            redirect(APP_URL . '/accountant/payments.php');
        }
    }
}

// Get terms
$stmt = $db->prepare("SELECT * FROM terms WHERE school_id = ? ORDER BY term_name DESC");
$stmt->execute([$school_id]);
$terms = $stmt->fetchAll();

// Get classes for filtering
$stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get filter parameters
$filter_class = isset($_GET['class_id']) && !empty($_GET['class_id']) ? (int)$_GET['class_id'] : null;
$filter_term = isset($_GET['term_id']) && !empty($_GET['term_id']) ? (int)$_GET['term_id'] : null;
$filter_days = isset($_GET['days']) && !empty($_GET['days']) ? (int)$_GET['days'] : null;
$filter_type = isset($_GET['payment_type']) && !empty($_GET['payment_type']) ? sanitize_input($_GET['payment_type']) : null;
$filter_student = isset($_GET['student_id']) && !empty($_GET['student_id']) ? (int)$_GET['student_id'] : null;
$filter_amount = isset($_GET['amount']) && !empty($_GET['amount']) ? (float)$_GET['amount'] : null;
$add_payment_student = isset($_GET['add_payment']) && !empty($_GET['add_payment']) ? (int)$_GET['add_payment'] : null;

// Build dynamic query with filters
$query = "SELECT 
        p.*,
        u.first_name,
        u.last_name,
        s.admission_number,
        s.class_id,
        c.class_name,
        t.term_name
    FROM payments p
    INNER JOIN students s ON p.student_id = s.student_id
    INNER JOIN users u ON s.user_id = u.user_id
    LEFT JOIN classes c ON s.class_id = c.class_id
    LEFT JOIN terms t ON p.term_id = t.term_id
    WHERE p.school_id = ?";

$params = [$school_id];

if ($filter_class) {
    $query .= " AND s.class_id = ?";
    $params[] = $filter_class;
}

if ($filter_term) {
    $query .= " AND p.term_id = ?";
    $params[] = $filter_term;
}

if ($filter_days) {
    $query .= " AND p.payment_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)";
    $params[] = $filter_days;
}

if ($filter_type) {
    $query .= " AND p.payment_type = ?";
    $params[] = $filter_type;
}

if ($filter_student) {
    $query .= " AND p.student_id = ?";
    $params[] = $filter_student;
}

if ($filter_amount) {
    $query .= " AND p.amount = ?";
    $params[] = $filter_amount;
}

$query .= " ORDER BY p.payment_date DESC";

$stmt = $db->prepare($query);
$stmt->execute($params);
$payments = $stmt->fetchAll();

// Get deleted payments with error handling
$deleted_payments = [];
try {
    $stmt = $db->prepare("
        SELECT 
            dp.deleted_payment_id,
            dp.payment_id,
            dp.student_id,
            dp.amount,
            dp.payment_type,
            dp.payment_date,
            dp.deletion_reason,
            dp.deleted_at,
            s.admission_number,
            c.class_name,
            t.term_name,
            du.first_name as deleted_by_first_name,
            du.last_name as deleted_by_last_name
        FROM deleted_payments dp
        INNER JOIN students s ON dp.student_id = s.student_id
        INNER JOIN users u ON s.user_id = u.user_id
        LEFT JOIN classes c ON s.class_id = c.class_id
        LEFT JOIN terms t ON dp.term_id = t.term_id
        LEFT JOIN users du ON dp.deleted_by = du.user_id
        WHERE dp.school_id = ?
        ORDER BY dp.deleted_at DESC
    ");
    $stmt->execute([$school_id]);
    $deleted_payments = $stmt->fetchAll();
} catch (PDOException $e) {
    // deleted_payments table may not exist yet
    $deleted_payments = [];
}

// Get students for dropdown
$stmt = $db->prepare("SELECT s.*, u.first_name, u.last_name FROM students s INNER JOIN users u ON s.user_id = u.user_id WHERE s.school_id = ? ORDER BY u.first_name");
$stmt->execute([$school_id]);
$students = $stmt->fetchAll();

// Summary
$total_paid = array_sum(array_map(fn($p) => $p['amount'], $payments));
$completed_count = count(array_filter($payments, fn($p) => $p['status'] == 'completed'));

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fa-file"></i> PAYMENT RECEIPT</h1>
    </div>

    <!-- Summary Cards -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo format_currency($total_paid); ?></h3>
                <p>Total Paid</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo $completed_count; ?></h3>
                <p>Completed</p>
            </div>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-filter"></i> Filter Payments</h3>
        </div>
        <div style="padding: 20px;">
            <form method="GET" action="" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end;">
                <div class="form-group" style="margin: 0;">
                    <label>Class</label>
                    <select name="class_id" onchange="this.form.submit()">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>" <?php echo $filter_class == $class['class_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>Term</label>
                    <select name="term_id" onchange="this.form.submit()">
                        <option value="">All Terms</option>
                        <?php foreach ($terms as $term): ?>
                            <option value="<?php echo $term['term_id']; ?>" <?php echo $filter_term == $term['term_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($term['term_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>Payment Type</label>
                    <select name="payment_type" onchange="this.form.submit()">
                        <option value="">All Types</option>
                        <option value="tuition" <?php echo $filter_type == 'tuition' ? 'selected' : ''; ?>>Tuition</option>
                        <option value="canteen" <?php echo $filter_type == 'canteen' ? 'selected' : ''; ?>>Canteen</option>
                        <option value="bus" <?php echo $filter_type == 'bus' ? 'selected' : ''; ?>>Bus</option>
                        <option value="library" <?php echo $filter_type == 'library' ? 'selected' : ''; ?>>Library</option>
                        <option value="sports" <?php echo $filter_type == 'sports' ? 'selected' : ''; ?>>Sports</option>
                        <option value="other" <?php echo $filter_type == 'other' ? 'selected' : ''; ?>>Other</option>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>Days</label>
                    <select name="days" onchange="this.form.submit()">
                        <option value="">All Time</option>
                        <option value="7" <?php echo $filter_days == 7 ? 'selected' : ''; ?>>Last 7 Days</option>
                        <option value="30" <?php echo $filter_days == 30 ? 'selected' : ''; ?>>Last 30 Days</option>
                        <option value="90" <?php echo $filter_days == 90 ? 'selected' : ''; ?>>Last 90 Days</option>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>Amount Paid</label>
                    <input type="number" name="amount" placeholder="e.g. 500" step="0.01" min="0" 
                           value="<?php echo $filter_amount ? htmlspecialchars($filter_amount) : ''; ?>" 
                           style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; width: 100%;">
                </div>
                
                <div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-search"></i> Search
                    </button>
                </div>
                
                <div>
                    <?php if ($filter_class || $filter_term || $filter_days || $filter_type || $filter_amount): ?>
                        <a href="<?php echo APP_URL; ?>/accountant/payments.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Clear Filters
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Action Bar -->
    <div style="margin-bottom: 30px; display: flex; gap: 10px;">
        <button type="button" onclick="openAddModal()" class="btn btn-primary">
            <i class="fas fa-plus"></i> Record Payment
        </button>
        <button type="button" onclick="printPayments()" class="btn btn-secondary">
            <i class="fas fa-print"></i> Print
        </button>
        <button type="button" onclick="toggleRecycleBin()" class="btn btn-warning">
            <i class="fas fa-trash-restore"></i> Recycle Bin (<?php echo count($deleted_payments); ?>)
        </button>
    </div>
    
    <!-- Payments Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-credit-card"></i> Payments (<?php echo count($payments); ?>)</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Student</th>
                        <th>Class</th>
                        <th>Type</th>
                        <th>Term</th>
                        <th>Amount</th>
                        <th>Method</th>
                        <th>Reference</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($payments) > 0): ?>
                        <?php foreach ($payments as $payment): ?>
                            <tr>
                                <td><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></td>
                                <td>
                                    <strong><?php echo $payment['first_name'] . ' ' . $payment['last_name']; ?></strong>
                                    <br><small><?php echo $payment['admission_number']; ?></small>
                                </td>
                                <td><?php echo $payment['class_name'] ?: '-'; ?></td>
                                <td>
                                    <span class="badge" style="background: <?php 
                                        $type = $payment['payment_type'] ?? 'tuition';
                                        echo $type == 'canteen' ? '#FF9800' : ($type == 'bus' ? '#2196F3' : '#4CAF50'); 
                                    ?>; color: white;">
                                        <?php echo ucfirst($type); ?>
                                    </span>
                                </td>
                                <td><?php echo $payment['term_name'] ?: '-'; ?></td>
                                <td><strong><?php echo format_currency($payment['amount']); ?></strong></td>
                                <td><?php echo ucfirst($payment['payment_method']); ?></td>
                                <td><?php echo $payment['payment_reference'] ?: '-'; ?></td>
                                <td><span class="badge badge-success"><?php echo ucfirst($payment['status']); ?></span></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-success" onclick="printReceipt(<?php echo htmlspecialchars(json_encode($payment)); ?>)" title="Print Receipt">
                                        <i class="fas fa-print"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-info" onclick="editPayment(<?php echo htmlspecialchars(json_encode($payment)); ?>)" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-danger" onclick="deletePayment(<?php echo $payment['payment_id']; ?>)" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" style="text-align: center; padding: 40px;">
                                <i class="fas fa-credit-card" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 10px; display: block;"></i>
                                <h3>No Payments</h3>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Add/Edit Payment Modal -->
    <div id="paymentModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 600px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 id="modalTitle">Record Payment</h2>
                <button onclick="closeModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="paymentForm">
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="payment_id" id="paymentId">
                
                <div class="form-group">
                    <label>Student *</label>
                    <select name="student_id" id="studentId" required>
                        <option value="">Select Student</option>
                        <?php foreach ($students as $s): ?>
                            <option value="<?php echo $s['student_id']; ?>">
                                <?php echo $s['first_name'] . ' ' . $s['last_name'] . ' (' . $s['admission_number'] . ')'; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Payment Type *</label>
                        <select name="payment_type" id="paymentType" required>
                            <option value="">Select Type</option>
                            <option value="tuition">Tuition Fee</option>
                            <option value="canteen">Canteen Fee</option>
                            <option value="bus">Bus/Transport Fee</option>
                            <option value="library">Library Fee</option>
                            <option value="sports">Sports Fee</option>
                            <option value="exam">Exam Fee</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>Term</label>
                        <select name="term_id" id="termId">
                            <option value="">-- Select Term (Optional) --</option>
                            <?php foreach ($terms as $t): ?>
                                <option value="<?php echo $t['term_id']; ?>"><?php echo $t['term_name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Amount (₵) *</label>
                        <input type="number" name="amount" id="amount" step="0.01" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Payment Method *</label>
                        <select name="payment_method" id="paymentMethod" required>
                            <option value="">Select Method</option>
                            <option value="cash">Cash</option>
                            <option value="bank_transfer">Bank Transfer</option>
                            <option value="paystack">Paystack</option>
                            <option value="card">Card</option>
                            <option value="mobile_money">Mobile Money</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Reference (Receipt/Cheque #)</label>
                    <input type="text" name="payment_reference" id="paymentReference" placeholder="e.g., CHK001">
                </div>
                
                <div class="form-group">
                    <label>Remarks/Notes</label>
                    <textarea name="remarks" id="remarks" rows="2" placeholder="Additional notes about this payment"></textarea>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="submitBtn"><i class="fas fa-save"></i> Record Payment</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
        <div style="max-width: 400px; margin: 150px auto; background: var(--bg-card); border-radius: 15px; padding: 30px; text-align: center;">
            <i class="fas fa-exclamation-triangle" style="font-size: 48px; color: var(--warning-orange); margin-bottom: 15px; display: block;"></i>
            <h2>Delete Payment?</h2>
            <p style="color: var(--text-secondary); margin: 15px 0;">This payment will be moved to the recycle bin. You can restore it later if needed.</p>
            <form method="POST" style="display: inline;">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="payment_id" id="deleteId">
                <div style="display: flex; gap: 10px; justify-content: center; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeDeleteModal()">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Move to Recycle Bin</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Recycle Bin Modal -->
    <div id="recycleBinModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; overflow-y: auto;">
        <div style="max-width: 1200px; margin: 50px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2><i class="fas fa-trash-restore"></i> Recycle Bin - Deleted Payments</h2>
                <button onclick="closeRecycleBin()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <?php if (count($deleted_payments) > 0): ?>
                <div style="margin-bottom: 20px; display: flex; gap: 10px; align-items: center;">
                    <button type="button" onclick="selectAllDeleted()" class="btn btn-secondary btn-sm">
                        <i class="fas fa-check-square"></i> Select All
                    </button>
                    <button type="button" onclick="bulkPermanentDelete()" class="btn btn-danger btn-sm">
                        <i class="fas fa-trash-alt"></i> Permanently Delete Selected
                    </button>
                    <span id="selectedCount" style="color: var(--text-secondary); font-size: 14px;"></span>
                </div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th width="40"><input type="checkbox" id="selectAllCheckbox" onchange="toggleAllDeleted(this)"></th>
                                <th>Date</th>
                                <th>Student</th>
                                <th>Class</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Deleted By</th>
                                <th>Deleted At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($deleted_payments as $dp): ?>
                                <tr style="background: rgba(255, 152, 0, 0.05);">
                                    <td><input type="checkbox" class="deleted-payment-checkbox" value="<?php echo $dp['deleted_payment_id']; ?>" onchange="updateSelectedCount()"></td>
                                    <td><?php echo date('M d, Y', strtotime($dp['payment_date'])); ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($dp['first_name'] . ' ' . $dp['last_name']); ?></strong>
                                        <br><small><?php echo htmlspecialchars($dp['admission_number'] ?? ''); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($dp['class_name'] ?? '-'); ?></td>
                                    <td>
                                        <span class="badge" style="background: #FF9800; color: white;">
                                            <?php echo ucfirst($dp['payment_type'] ?? 'tuition'); ?>
                                        </span>
                                    </td>
                                    <td><strong><?php echo format_currency($dp['amount']); ?></strong></td>
                                    <td><?php echo htmlspecialchars(($dp['deleted_by_first_name'] ?? '') . ' ' . ($dp['deleted_by_last_name'] ?? '')); ?></td>
                                    <td><?php echo date('M d, Y H:i', strtotime($dp['deleted_at'])); ?></td>
                                    <td>
                                        <div style="display: flex; gap: 5px;">
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="action" value="restore">
                                                <input type="hidden" name="deleted_payment_id" value="<?php echo $dp['deleted_payment_id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-success" title="Restore">
                                                    <i class="fas fa-undo"></i> Restore
                                                </button>
                                            </form>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Permanently delete this payment? This action CANNOT be undone!');">
                                                <input type="hidden" name="action" value="permanent_delete">
                                                <input type="hidden" name="deleted_payment_id" value="<?php echo $dp['deleted_payment_id']; ?>">
                                                <button type="submit" class="btn btn-sm btn-danger" title="Permanently Delete">
                                                    <i class="fas fa-trash-alt"></i> Delete Forever
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 60px;">
                    <i class="fas fa-trash" style="font-size: 64px; color: var(--text-secondary); opacity: 0.3; margin-bottom: 20px;"></i>
                    <h3 style="color: var(--text-secondary);">Recycle Bin is Empty</h3>
                    <p style="color: var(--text-secondary);">Deleted payments will appear here</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    function openAddModal() {
        document.getElementById('paymentModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Record Payment';
        document.getElementById('formAction').value = 'add';
        document.getElementById('submitBtn').innerHTML = '<i class="fas fa-save"></i> Record Payment';
        document.getElementById('paymentForm').reset();
        document.getElementById('paymentId').value = '';
    }
    
    function editPayment(payment) {
        document.getElementById('paymentModal').style.display = 'block';
        document.getElementById('modalTitle').textContent = 'Edit Payment';
        document.getElementById('formAction').value = 'update';
        document.getElementById('submitBtn').innerHTML = '<i class="fas fa-save"></i> Update Payment';
        
        document.getElementById('paymentId').value = payment.payment_id;
        document.getElementById('studentId').value = payment.student_id;
        document.getElementById('paymentType').value = payment.payment_type || 'tuition';
        document.getElementById('termId').value = payment.term_id || '';
        document.getElementById('amount').value = payment.amount;
        document.getElementById('paymentMethod').value = payment.payment_method;
        document.getElementById('paymentReference').value = payment.payment_reference || '';
        document.getElementById('remarks').value = payment.remarks || '';
    }
    
    function deletePayment(paymentId) {
        document.getElementById('deleteModal').style.display = 'block';
        document.getElementById('deleteId').value = paymentId;
    }
    
    function closeModal() {
        document.getElementById('paymentModal').style.display = 'none';
    }
    
    function closeDeleteModal() {
        document.getElementById('deleteModal').style.display = 'none';
    }
    
    function toggleRecycleBin() {
        const modal = document.getElementById('recycleBinModal');
        modal.style.display = modal.style.display === 'none' ? 'block' : 'none';
    }
    
    function closeRecycleBin() {
        document.getElementById('recycleBinModal').style.display = 'none';
    }
    
    function toggleAllDeleted(checkbox) {
        const checkboxes = document.querySelectorAll('.deleted-payment-checkbox');
        checkboxes.forEach(cb => cb.checked = checkbox.checked);
        updateSelectedCount();
    }
    
    function selectAllDeleted() {
        const selectAllCheckbox = document.getElementById('selectAllCheckbox');
        selectAllCheckbox.checked = true;
        toggleAllDeleted(selectAllCheckbox);
    }
    
    function updateSelectedCount() {
        const checked = document.querySelectorAll('.deleted-payment-checkbox:checked').length;
        const countSpan = document.getElementById('selectedCount');
        if (checked > 0) {
            countSpan.textContent = `${checked} payment(s) selected`;
        } else {
            countSpan.textContent = '';
        }
    }
    
    function bulkPermanentDelete() {
        const checkboxes = document.querySelectorAll('.deleted-payment-checkbox:checked');
        if (checkboxes.length === 0) {
            alert('Please select at least one payment to delete');
            return;
        }
        
        if (!confirm(`Permanently delete ${checkboxes.length} payment(s)? This action CANNOT be undone!`)) {
            return;
        }
        
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '';
        
        const actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        actionInput.value = 'bulk_permanent_delete';
        form.appendChild(actionInput);
        
        checkboxes.forEach(checkbox => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'payment_ids[]';
            input.value = checkbox.value;
            form.appendChild(input);
        });
        
        document.body.appendChild(form);
        form.submit();
    }
    
    function printPayments() {
        window.print();
    }
    
    function printReceipt(payment) {
        // Open print window
        const printWindow = window.open('', '_blank', 'width=800,height=600');
        
        printWindow.document.write('<!DOCTYPE html>');
        printWindow.document.write('<html>');
        printWindow.document.write('<head>');
        printWindow.document.write('<title>Payment Receipt - ' + payment.first_name + ' ' + payment.last_name + '</title>');
        printWindow.document.write('<style>');
        printWindow.document.write('body { margin: 0; padding: 20px; font-family: Arial, sans-serif; }');
        printWindow.document.write('@media print { body { margin: 0; padding: 20px; } }');
        printWindow.document.write('</style>');
        printWindow.document.write('</head>');
        printWindow.document.write('<body>');
        
        // Receipt content
        printWindow.document.write('<div style="max-width: 800px; margin: 0 auto; padding: 40px;">');
        
        // Header
        printWindow.document.write('<div style="text-align: center; border-bottom: 3px solid #2196F3; padding-bottom: 20px; margin-bottom: 30px;">');
        printWindow.document.write('');
        printWindow.document.write('<p style="margin: 5px 0; color: #666; font-size: 14px;">Official Payment Confirmation</p>');
        printWindow.document.write('</div>');
        
        // Details
        printWindow.document.write('<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 30px;">');
        
        // Left column
        printWindow.document.write('<div>');
        printWindow.document.write('<div style="margin-bottom: 15px;">');
        printWindow.document.write('<div style="font-size: 12px; color: #666;">RECEIPT NO.</div>');
        printWindow.document.write('<div style="font-size: 16px; font-weight: 700; color: #333;">' + (payment.payment_reference || 'PAY-' + payment.payment_id) + '</div>');
        printWindow.document.write('</div>');
        printWindow.document.write('<div style="margin-bottom: 15px;">');
        printWindow.document.write('<div style="font-size: 12px; color: #666;">PAYMENT DATE</div>');
        printWindow.document.write('<div style="font-size: 16px; font-weight: 600; color: #333;">' + new Date(payment.payment_date).toLocaleDateString('en-GB', {day: '2-digit', month: 'short', year: 'numeric'}) + '</div>');
        printWindow.document.write('</div>');
        printWindow.document.write('<div>');
        printWindow.document.write('<div style="font-size: 12px; color: #666;">PAYMENT METHOD</div>');
        printWindow.document.write('<div style="font-size: 16px; font-weight: 600; color: #333; text-transform: capitalize;">' + payment.payment_method.replace('_', ' ') + '</div>');
        printWindow.document.write('</div>');
        printWindow.document.write('</div>');
        
        // Right column
        printWindow.document.write('<div style="text-align: right;">');
        printWindow.document.write('<div style="margin-bottom: 15px;">');
        printWindow.document.write('<div style="font-size: 12px; color: #666;">STUDENT NAME</div>');
        printWindow.document.write('<div style="font-size: 16px; font-weight: 700; color: #333;">' + payment.first_name + ' ' + payment.last_name + '</div>');
        printWindow.document.write('</div>');
        printWindow.document.write('<div style="margin-bottom: 15px;">');
        printWindow.document.write('<div style="font-size: 12px; color: #666;">ADMISSION NO.</div>');
        printWindow.document.write('<div style="font-size: 16px; font-weight: 600; color: #333;">' + payment.admission_number + '</div>');
        printWindow.document.write('</div>');
        printWindow.document.write('<div>');
        printWindow.document.write('<div style="font-size: 12px; color: #666;">CLASS</div>');
        printWindow.document.write('<div style="font-size: 16px; font-weight: 600; color: #333;">' + (payment.class_name || 'N/A') + '</div>');
        printWindow.document.write('</div>');
        printWindow.document.write('</div>');
        
        printWindow.document.write('</div>');
        
        // Payment details table
        printWindow.document.write('<div style="border: 2px solid #e0e0e0; border-radius: 8px; overflow: hidden; margin-bottom: 30px;">');
        printWindow.document.write('<div style="background: #f5f5f5; padding: 15px; border-bottom: 2px solid #e0e0e0;">');
        printWindow.document.write('<h3 style="margin: 0; font-size: 18px; color: #333;">Payment Details</h3>');
        printWindow.document.write('</div>');
        printWindow.document.write('<div style="padding: 20px;">');
        
        printWindow.document.write('<div style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f0f0f0;">');
        printWindow.document.write('<span style="font-size: 14px; color: #666;">Payment Type:</span>');
        printWindow.document.write('<span style="font-size: 14px; font-weight: 600; text-transform: capitalize;">' + (payment.payment_type || 'School Fees') + '</span>');
        printWindow.document.write('</div>');
        
        printWindow.document.write('<div style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f0f0f0;">');
        printWindow.document.write('<span style="font-size: 14px; color: #666;">Term:</span>');
        printWindow.document.write('<span style="font-size: 14px; font-weight: 600;">' + (payment.term_name || 'N/A') + '</span>');
        printWindow.document.write('</div>');
        
        printWindow.document.write('<div style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f0f0f0;">');
        printWindow.document.write('<span style="font-size: 14px; color: #666;">Transaction ID:</span>');
        printWindow.document.write('<span style="font-size: 14px; font-weight: 600;">' + (payment.transaction_id || '-') + '</span>');
        printWindow.document.write('</div>');
        
        printWindow.document.write('<div style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 2px solid #2196F3;">');
        printWindow.document.write('<span style="font-size: 14px; color: #666;">Remarks:</span>');
        printWindow.document.write('<span style="font-size: 14px; font-weight: 600;">' + (payment.remarks || 'N/A') + '</span>');
        printWindow.document.write('</div>');
        
        printWindow.document.write('<div style="display: flex; justify-content: space-between; padding: 20px 0; background: #f9f9f9; margin: 20px -20px -20px -20px; padding-left: 20px; padding-right: 20px;">');
        printWindow.document.write('<span style="font-size: 18px; font-weight: 700; color: #333;">AMOUNT PAID:</span>');
        printWindow.document.write('<span style="font-size: 24px; font-weight: 700; color: #2196F3;">₵' + parseFloat(payment.amount).toFixed(2) + '</span>');
        printWindow.document.write('</div>');
        
        printWindow.document.write('</div>');
        printWindow.document.write('</div>');
        
        // Footer
        printWindow.document.write('<div style="text-align: center; padding-top: 30px; border-top: 2px solid #e0e0e0;">');
        printWindow.document.write('<div style="margin-bottom: 15px;">');
        printWindow.document.write('<p style="margin: 5px 0; font-size: 12px; color: #666;">This is an official payment receipt generated on ' + new Date().toLocaleDateString('en-GB', {day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'}) + '</p>');
        printWindow.document.write('</div>');
        printWindow.document.write('<div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e0e0e0;">');
        printWindow.document.write('<p style="margin: 0; font-size: 11px; color: #999;">For any queries, please contact the accounts office</p>');
        printWindow.document.write('</div>');
        printWindow.document.write('</div>');
        
        printWindow.document.write('</div>');
        printWindow.document.write('<scr' + 'ipt>');
        printWindow.document.write('window.onload = function() { window.print(); };');
        printWindow.document.write('</scr' + 'ipt>');
        printWindow.document.write('</body>');
        printWindow.document.write('</html>');
        printWindow.document.close();
    }
    
    window.onclick = function(e) {
        if (e.target.id === 'paymentModal') e.target.style.display = 'none';
        if (e.target.id === 'deleteModal') e.target.style.display = 'none';
        if (e.target.id === 'recycleBinModal') e.target.style.display = 'none';
    }
    
    // Auto-open modal if add_payment parameter is set
    <?php if ($add_payment_student): ?>
    window.addEventListener('DOMContentLoaded', function() {
        openAddModal();
        document.getElementById('studentId').value = <?php echo $add_payment_student; ?>;
    });
    <?php endif; ?>
    </script>
    
    <style media="print">
        @media print {
            .btn, [onclick] { display: none !important; }
            body { background: white; }
            .table-responsive { overflow: visible !important; }
        }
    </style>
    
    </div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
