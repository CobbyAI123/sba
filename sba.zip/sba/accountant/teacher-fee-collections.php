<?php
// accountant/teacher-fee-collections.php - Verify Teacher Collections
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Teacher Fee Collections';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];
$accountant_id = $current_user['user_id'];

// Handle verification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_collection'])) {
    $payment_id = (int)$_POST['payment_id'];
    $action = $_POST['action']; // 'approve' or 'reject'
    $notes = sanitize_input($_POST['notes'] ?? '');
    
    try {
        $db->beginTransaction();
        
        if ($action === 'approve') {
            $stmt = $db->prepare("
                UPDATE payments 
                SET status = 'completed', 
                    verified_by = ?,
                    verified_at = NOW(),
                    verification_notes = ?
                WHERE payment_id = ? AND school_id = ?
            ");
            $stmt->execute([$accountant_id, $notes, $payment_id, $school_id]);
            set_message('success', 'Collection verified and approved successfully!');
        } else {
            $stmt = $db->prepare("
                UPDATE payments 
                SET status = 'rejected', 
                    verified_by = ?,
                    verified_at = NOW(),
                    verification_notes = ?
                WHERE payment_id = ? AND school_id = ?
            ");
            $stmt->execute([$accountant_id, $notes, $payment_id, $school_id]);
            set_message('warning', 'Collection rejected.');
        }
        
        $db->commit();
    } catch (Exception $e) {
        $db->rollBack();
        set_message('error', 'Error processing verification: ' . $e->getMessage());
    }
    
    redirect($_SERVER['PHP_SELF']);
}

// Get submitted collections
$stmt = $db->prepare("
    SELECT 
        p.*,
        s.admission_number,
        CONCAT(su.first_name, ' ', su.last_name) as student_name,
        CONCAT(tu.first_name, ' ', tu.last_name) as teacher_name,
        c.class_name
    FROM payments p
    JOIN students s ON p.student_id = s.student_id
    LEFT JOIN users su ON s.user_id = su.user_id
    LEFT JOIN users tu ON p.collected_by = tu.user_id
    LEFT JOIN classes c ON s.class_id = c.class_id
    WHERE p.school_id = ? 
        AND p.status IN ('submitted_to_accountant', 'pending_verification')
        AND (p.submitted_to = ? OR p.submitted_to IS NULL)
    ORDER BY p.submitted_at DESC, p.created_at DESC
");
$stmt->execute([$school_id, $accountant_id]);
$pending_collections = $stmt->fetchAll();

// Get verification statistics
$stmt = $db->prepare("
    SELECT 
        COUNT(*) as total_pending,
        SUM(amount) as total_amount
    FROM payments
    WHERE school_id = ? AND status IN ('submitted_to_accountant', 'pending_verification')
");
$stmt->execute([$school_id]);
$stats = $stmt->fetch();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <h2><i class="fas fa-clipboard-check"></i> Teacher Fee Collections</h2>
    
    <!-- Statistics -->
    <div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="stat-card" style="border-left: 4px solid #ffa726;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                    <h4 style="color: var(--text-secondary); font-size: 14px; margin-bottom: 8px;">
                        <i class="fas fa-clock"></i> Pending Verification
                    </h4>
                    <h2 style="font-size: 28px; font-weight: 700; margin: 0; color: #ffa726;">
                        <?php echo $stats['total_pending'] ?? 0; ?>
                    </h2>
                    <p style="font-size: 12px; color: var(--text-secondary); margin-top: 5px;">
                        Collections to verify
                    </p>
                </div>
                <div style="background: rgba(255, 167, 38, 0.1); padding: 12px; border-radius: 10px;">
                    <i class="fas fa-hourglass-half" style="font-size: 24px; color: #ffa726;"></i>
                </div>
            </div>
        </div>
        
        <div class="stat-card" style="border-left: 4px solid #00d68f;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                    <h4 style="color: var(--text-secondary); font-size: 14px; margin-bottom: 8px;">
                        <i class="fas fa-money-bill-wave"></i> Total Amount
                    </h4>
                    <h2 style="font-size: 28px; font-weight: 700; margin: 0; color: #00d68f;">
                        GH₵ <?php echo number_format($stats['total_amount'] ?? 0, 2); ?>
                    </h2>
                    <p style="font-size: 12px; color: var(--text-secondary); margin-top: 5px;">
                        Pending verification
                    </p>
                </div>
                <div style="background: rgba(0, 214, 143, 0.1); padding: 12px; border-radius: 10px;">
                    <i class="fas fa-dollar-sign" style="font-size: 24px; color: #00d68f;"></i>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Collections Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Submitted Collections</h3>
        </div>
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Date Collected</th>
                        <th>Student</th>
                        <th>Fee Type</th>
                        <th>Period</th>
                        <th>Amount</th>
                        <th>Collected By</th>
                        <th>Payment Method</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($pending_collections) > 0): ?>
                        <?php foreach ($pending_collections as $payment): ?>
                            <tr>
                                <td>
                                    <div style="font-weight: 600;"><?php echo date('M d, Y', strtotime($payment['payment_date'])); ?></div>
                                    <div style="font-size: 11px; color: var(--text-secondary);">
                                        Submitted: <?php echo $payment['submitted_at'] ? date('M d, h:i A', strtotime($payment['submitted_at'])) : 'N/A'; ?>
                                    </div>
                                </td>
                                <td>
                                    <div style="font-weight: 600;"><?php echo htmlspecialchars($payment['student_name']); ?></div>
                                    <div style="font-size: 11px; color: var(--text-secondary);">
                                        <?php echo htmlspecialchars($payment['admission_number']); ?> | <?php echo htmlspecialchars($payment['class_name'] ?? 'N/A'); ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge" style="background: rgba(45, 91, 255, 0.15); color: #2d5bff;">
                                        <i class="fas <?php echo $payment['payment_type'] === 'Canteen Fee' ? 'fa-utensils' : 'fa-bus'; ?>"></i>
                                        <?php echo $payment['payment_type']; ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge" style="background: rgba(156, 39, 176, 0.15); color: #9c27b0;">
                                        <?php echo ucfirst($payment['collection_period'] ?? 'N/A'); ?>
                                    </span>
                                </td>
                                <td>
                                    <strong style="font-size: 16px; color: #00d68f;">GH₵ <?php echo number_format($payment['amount'], 2); ?></strong>
                                </td>
                                <td>
                                    <div style="font-weight: 600;"><?php echo htmlspecialchars($payment['teacher_name']); ?></div>
                                </td>
                                <td>
                                    <i class="fas <?php echo $payment['payment_method'] === 'Cash' ? 'fa-money-bill' : 'fa-credit-card'; ?>"></i>
                                    <?php echo htmlspecialchars($payment['payment_method']); ?>
                                </td>
                                <td>
                                    <div style="display: flex; gap: 5px;">
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="verify_collection" value="1">
                                            <input type="hidden" name="payment_id" value="<?php echo $payment['payment_id']; ?>">
                                            <input type="hidden" name="action" value="approve">
                                            <input type="hidden" name="notes" value="Verified by accountant">
                                            <button type="submit" class="btn btn-success" style="padding: 6px 12px; font-size: 12px;" 
                                                    onclick="return confirm('Approve this collection?')">
                                                <i class="fas fa-check"></i> Approve
                                            </button>
                                        </form>
                                        <button onclick="openRejectModal(<?php echo $payment['payment_id']; ?>)" 
                                                class="btn btn-danger" style="padding: 6px 12px; font-size: 12px;">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 60px;">
                                <i class="fas fa-check-circle" style="font-size: 64px; color: #00d68f; margin-bottom: 15px; display: block;"></i>
                                <h3>No Pending Collections</h3>
                                <p style="color: var(--text-secondary);">All teacher collections have been verified.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Reject Modal -->
    <div id="rejectModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 10000; align-items: center; justify-content: center;">
        <div style="background: var(--card-bg); border-radius: 16px; max-width: 500px; width: 90%; padding: 30px;">
            <h2 style="margin-bottom: 20px;"><i class="fas fa-exclamation-triangle"></i> Reject Collection</h2>
            <form method="POST" id="rejectForm">
                <input type="hidden" name="verify_collection" value="1">
                <input type="hidden" name="payment_id" id="reject_payment_id">
                <input type="hidden" name="action" value="reject">
                
                <div class="form-group">
                    <label>Reason for Rejection</label>
                    <textarea name="notes" class="form-control" rows="4" required 
                              placeholder="Enter reason why this collection is being rejected..."></textarea>
                </div>
                
                <div style="display: flex; gap: 10px; margin-top: 20px;">
                    <button type="submit" class="btn btn-danger" style="flex: 1;">
                        <i class="fas fa-times"></i> Reject Collection
                    </button>
                    <button type="button" onclick="closeRejectModal()" class="btn btn-secondary">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function openRejectModal(paymentId) {
        document.getElementById('reject_payment_id').value = paymentId;
        document.getElementById('rejectModal').style.display = 'flex';
    }
    
    function closeRejectModal() {
        document.getElementById('rejectModal').style.display = 'none';
    }
    
    // Close on outside click
    document.getElementById('rejectModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeRejectModal();
        }
    });
    </script>
    
    </div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
