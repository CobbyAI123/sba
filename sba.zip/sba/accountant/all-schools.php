<?php
// accountant/all-schools.php - View All Schools (Accountant)
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'School Overview';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$user_id = $current_user['user_id'];

// Get accountant's school with financial summary (only their school)
$accountant_school_id = $current_user['school_id'];

$stmt = $db->prepare("
    SELECT 
        s.*,
        COUNT(DISTINCT st.student_id) as total_students,
        COUNT(DISTINCT u.user_id) as total_staff,
        COALESCE(SUM(sf.total_amount), 0) as total_fees,
        COALESCE(SUM(sf.paid_amount), 0) as total_collected,
        COALESCE(SUM(sf.balance_amount), 0) as total_pending
    FROM schools s
    LEFT JOIN students st ON s.school_id = st.school_id AND st.status = 'active'
    LEFT JOIN users u ON s.school_id = u.school_id AND u.status = 'active'
    LEFT JOIN student_fees sf ON s.school_id = (SELECT school_id FROM students WHERE student_id = sf.student_id)
    WHERE s.school_id = ?
    GROUP BY s.school_id
");
$stmt->execute([$accountant_school_id]);
$schools = $stmt->fetchAll();

// Overall statistics
$total_schools = count($schools);
$total_students = array_sum(array_column($schools, 'total_students'));
$total_fees = array_sum(array_column($schools, 'total_fees'));
$total_collected = array_sum(array_column($schools, 'total_collected'));
$total_pending = array_sum(array_column($schools, 'total_pending'));

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    /* Schools Grid Container - Responsive Grid Layout */
    .schools-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(500px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
        max-width: 100%;
    }
    
    /* Limit single card width to prevent stretching */
    .schools-grid > .school-card:only-child {
        max-width: 700px;
    }
    
    /* Responsive adjustments */
    @media (max-width: 1400px) {
        .schools-grid {
            grid-template-columns: repeat(auto-fill, minmax(450px, 1fr));
        }
    }
    
    @media (max-width: 1024px) {
        .schools-grid {
            grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
        }
        .schools-grid > .school-card:only-child {
            max-width: 100%;
        }
    }
    
    @media (max-width: 768px) {
        .schools-grid {
            grid-template-columns: 1fr;
        }
    }
    
    .school-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        transition: all 0.3s ease;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    
    .school-card:hover {
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        border-color: var(--primary-blue);
        transform: translateY(-2px);
    }
    
    .stat-box {
        background: rgba(0,0,0,0.02);
        padding: 15px;
        border-radius: 8px;
        text-align: center;
    }
    </style>
    
    <div style="margin-bottom: 25px;">
        <h2><i class="fas fa-school"></i> School Overview</h2>
        <p style="color: var(--text-secondary); margin-top: 8px;">
            <i class="fas fa-info-circle"></i> View your school's financial summary and statistics
        </p>
    </div>
    
    <!-- Overall Statistics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 30px;">
        <div style="background: linear-gradient(135deg, #5856D6, #5E5CE6); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 32px;"><?php echo number_format($total_students); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Students</p>
        </div>
        <div style="background: linear-gradient(135deg, #FF9500, #FF9F0A); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 28px;">₹<?php echo number_format($total_fees, 2); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Total Fees</p>
        </div>
        <div style="background: linear-gradient(135deg, #34C759, #30D158); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 28px;">₹<?php echo number_format($total_collected, 2); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Collected</p>
        </div>
        <div style="background: linear-gradient(135deg, #FF3B30, #FF453A); color: white; padding: 20px; border-radius: 12px;">
            <h3 style="margin: 0; font-size: 28px;">₹<?php echo number_format($total_pending, 2); ?></h3>
            <p style="margin: 5px 0 0 0; opacity: 0.9;">Pending</p>
        </div>
    </div>
    
    <!-- Schools List -->
    <div class="schools-grid">
    <?php foreach ($schools as $school): ?>
        <div class="school-card">
            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 15px;">
                <div>
                    <h3 style="margin: 0 0 5px 0;">
                        <i class="fas fa-school"></i> <?php echo htmlspecialchars($school['school_name']); ?>
                    </h3>
                    <?php if ($school['address']): ?>
                        <p style="margin: 0; color: var(--text-secondary); font-size: 13px;">
                            <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($school['address']); ?>
                        </p>
                    <?php endif; ?>
                </div>
                <div style="text-align: right;">
                    <span class="status-badge" style="background: rgba(52, 199, 89, 0.1); color: #34C759;">
                        Active
                    </span>
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin: 15px 0;">
                <div class="stat-box">
                    <div style="font-size: 24px; font-weight: 700; color: var(--primary-blue);">
                        <?php echo number_format($school['total_students']); ?>
                    </div>
                    <div style="font-size: 12px; color: var(--text-secondary); margin-top: 5px;">Students</div>
                </div>
                <div class="stat-box">
                    <div style="font-size: 24px; font-weight: 700; color: var(--secondary-purple);">
                        <?php echo number_format($school['total_staff']); ?>
                    </div>
                    <div style="font-size: 12px; color: var(--text-secondary); margin-top: 5px;">Staff</div>
                </div>
                <div class="stat-box">
                    <div style="font-size: 20px; font-weight: 700; color: #34C759;">
                        ₹<?php echo number_format($school['total_collected'], 2); ?>
                    </div>
                    <div style="font-size: 12px; color: var(--text-secondary); margin-top: 5px;">Collected</div>
                </div>
                <div class="stat-box">
                    <div style="font-size: 20px; font-weight: 700; color: #FF9500;">
                        ₹<?php echo number_format($school['total_pending'], 2); ?>
                    </div>
                    <div style="font-size: 12px; color: var(--text-secondary); margin-top: 5px;">Pending</div>
                </div>
            </div>
            
            <div style="display: flex; gap: 10px; margin-top: 15px; padding-top: 15px; border-top: 1px solid var(--border-color);">
                <a href="school-transactions.php?school_id=<?php echo $school['school_id']; ?>" class="btn btn-sm btn-primary">
                    <i class="fas fa-exchange-alt"></i> View Transactions
                </a>
                <a href="school-reports.php?school_id=<?php echo $school['school_id']; ?>" class="btn btn-sm btn-secondary">
                    <i class="fas fa-chart-bar"></i> Reports
                </a>
                <?php if ($school['phone']): ?>
                    <a href="tel:<?php echo htmlspecialchars($school['phone']); ?>" class="btn btn-sm btn-info">
                        <i class="fas fa-phone"></i> <?php echo htmlspecialchars($school['phone']); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
    
    <?php if (count($schools) == 0): ?>
        <div style="text-align: center; padding: 60px; background: var(--bg-card); border-radius: 15px;">
            <i class="fas fa-school" style="font-size: 64px; color: var(--text-secondary); margin-bottom: 20px;"></i>
            <h3 style="color: var(--text-secondary);">No Schools Found</h3>
        </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
