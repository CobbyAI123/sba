<?php
// accountant/outstanding-fees.php - Outstanding Fees Tracker
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Outstanding Fees';
$current_user = check_permission(['accountant', 'admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get filter parameters
$class_id = sanitize_input($_GET['class_id'] ?? '');
$status_filter = sanitize_input($_GET['status'] ?? 'outstanding');

// Handle notification sending
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'send_notifications') {
    $notify_students = isset($_POST['notify_students']) ? true : false;
    $notify_parents = isset($_POST['notify_parents']) ? true : false;
    $selected_students = isset($_POST['selected_students']) ? (array)$_POST['selected_students'] : [];
    
    if (count($selected_students) > 0 && ($notify_students || $notify_parents)) {
        try {
            // Log the notification sending activity
            log_activity($current_user['user_id'], "Sent payment reminder notifications to " . count($selected_students) . " students", 'outstanding_fees');
            set_message('success', 'Notifications sent to ' . count($selected_students) . ' students successfully!');
            redirect(APP_URL . '/accountant/outstanding-fees.php?class_id=' . $class_id . '&status=' . $status_filter);
        } catch (PDOException $e) {
            set_message('error', 'Error sending notifications: ' . $e->getMessage());
        }
    } else {
        set_message('error', 'Please select at least one student and specify notification type');
    }
}

// Get classes for dropdown
$stmt = $db->prepare("SELECT * FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Build query for outstanding fees - combining payments from both tables
$query = "
    SELECT 
        s.student_id,
        s.admission_number,
        u.first_name,
        u.last_name,
        c.class_name,
        fs.amount as fee_amount,
        (
            COALESCE((SELECT SUM(amount) FROM payments WHERE student_id = s.student_id AND status = 'completed'), 0) +
            COALESCE((SELECT SUM(amount) FROM transactions WHERE student_id = s.student_id AND transaction_type = 'fee_payment' AND status = 'completed'), 0)
        ) as paid_amount,
        (
            COALESCE(fs.amount, 0) -
            (
                COALESCE((SELECT SUM(amount) FROM payments WHERE student_id = s.student_id AND status = 'completed'), 0) +
                COALESCE((SELECT SUM(amount) FROM transactions WHERE student_id = s.student_id AND transaction_type = 'fee_payment' AND status = 'completed'), 0)
            )
        ) as outstanding_amount
    FROM students s
    INNER JOIN users u ON s.user_id = u.user_id
    LEFT JOIN classes c ON s.class_id = c.class_id
    LEFT JOIN fee_structure fs ON s.class_id = fs.class_id AND fs.school_id = s.school_id
    WHERE s.school_id = ? AND s.status = 'active'
";

$params = [$school_id];

if ($class_id) {
    $query .= " AND s.class_id = ?";
    $params[] = $class_id;
}

$query .= " GROUP BY s.student_id";

if ($status_filter === 'outstanding') {
    $query .= " HAVING outstanding_amount > 0";
} elseif ($status_filter === 'paid') {
    $query .= " HAVING outstanding_amount = 0";
}

$query .= " ORDER BY outstanding_amount DESC";

$students = [];
try {
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $students = $stmt->fetchAll();
} catch (PDOException $e) {
    $students = [];
}

// Calculate totals
$total_outstanding = 0;
$total_expected = 0;
$total_paid = 0;

foreach ($students as $student) {
    $total_outstanding += $student['outstanding_amount'];
    $total_expected += $student['fee_amount'] ?? 0;
    $total_paid += $student['paid_amount'];
}

$paid_percentage = ($total_expected > 0) ? ($total_paid / $total_expected) * 100 : 0;

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <!-- Statistics Cards -->
    <div class="stats-grid" style="margin-bottom: 30px;">
        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-money-bill-wave"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo format_currency($total_outstanding); ?></h3>
                <p>Outstanding Balance</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo round($paid_percentage); ?>%</h3>
                <p>Collection Rate</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon orange">
                <i class="fas fa-exclamation-circle"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo count(array_filter($students, function($s) { return $s['outstanding_amount'] > 0; })); ?></h3>
                <p>Students with Dues</p>
            </div>
        </div>
    
        <div class="stat-card">
            <div class="stat-icon purple">
                <i class="fas fa-money-bill-alt"></i>
            </div>
            <div class="stat-details">
                <h3><?php echo format_currency($total_paid); ?></h3>
                <p>Total Collected</p>
            </div>
        </div>
    </div>
    
    <!-- Filters and Action Buttons -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-filter"></i> Filter & Actions</h3>
        </div>
        <form method="GET" style="display: grid; grid-template-columns: 1fr 1fr auto auto auto; gap: 15px; padding: 20px;">
            <div class="form-group">
                <label>Class</label>
                <select name="class_id">
                    <option value="">All Classes</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?php echo $class['class_id']; ?>" <?php echo $class_id == $class['class_id'] ? 'selected' : ''; ?>>
                            <?php echo $class['class_name']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="outstanding" <?php echo $status_filter === 'outstanding' ? 'selected' : ''; ?>>Outstanding Only</option>
                    <option value="paid" <?php echo $status_filter === 'paid' ? 'selected' : ''; ?>>Fully Paid</option>
                    <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Students</option>
                </select>
            </div>
            <div style="display: flex; align-items: flex-end; gap: 10px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Filter
                </button>
                <a href="?" class="btn btn-secondary">
                    <i class="fas fa-redo"></i> Reset
                </a>
                <button type="button" onclick="printArrearsReport()" class="btn btn-info">
                    <i class="fas fa-print"></i> Print Arrears
                </button>
                <button type="button" onclick="openNotificationModal()" class="btn btn-success">
                    <i class="fas fa-bell"></i> Send Reminder
                </button>
            </div>
        </form>
    </div>
    
    <!-- Outstanding Fees Table -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-file-invoice-dollar"></i> Outstanding Fees Details</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Admission No.</th>
                        <th>Student Name</th>
                        <th>Class</th>
                        <th>Fee Amount</th>
                        <th>Paid</th>
                        <th>Outstanding</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($students) > 0): ?>
                        <?php foreach ($students as $student): ?>
                            <?php 
                                $outstanding = $student['outstanding_amount'];
                                $percentage_paid = ($student['fee_amount'] > 0) ? ($student['paid_amount'] / $student['fee_amount']) * 100 : 0;
                            ?>
                            <tr>
                                <td><?php echo $student['admission_number']; ?></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 35px; height: 35px; border-radius: 50%; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; font-size: 12px;">
                                            <?php echo strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)); ?>
                                        </div>
                                        <?php echo $student['first_name'] . ' ' . $student['last_name']; ?>
                                    </div>
                                </td>
                                <td><?php echo $student['class_name'] ?: 'Not Assigned'; ?></td>
                                <td><?php echo format_currency($student['fee_amount'] ?? 0); ?></td>
                                <td><?php echo format_currency($student['paid_amount']); ?></td>
                                <td>
                                    <strong class="<?php echo $outstanding > 0 ? 'style="color: var(--danger-red);"' : 'style="color: var(--success-green);"'; ?>>
                                        <?php echo format_currency($outstanding); ?>
                                    </strong>
                                </td>
                                <td>
                                    <div style="background: linear-gradient(90deg, var(--primary-blue), var(--secondary-purple)); width: 100%; height: 6px; border-radius: 3px; overflow: hidden; margin-bottom: 5px;">
                                        <div style="height: 100%; width: <?php echo $percentage_paid; ?>%; background: var(--success-green);"></div>
                                    </div>
                                    <small><?php echo round($percentage_paid); ?>% paid</small>
                                </td>
                                <td>
                                    <button type="button" onclick="sendReminder(<?php echo $student['student_id']; ?>, '<?php echo addslashes($student['first_name'] . ' ' . $student['last_name']); ?>')" 
                                            class="btn btn-warning btn-sm" title="Send Reminder">
                                        <i class="fas fa-bell"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                                <i class="fas fa-check-circle" style="font-size: 48px; margin-bottom: 10px; display: block;"></i>
                                <h3>All Fees Collected!</h3>
                                <p>Great! There are no outstanding fees at the moment.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Summary Card -->
    <div class="card" style="margin-top: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-chart-pie"></i> Summary</h3>
        </div>
        <div style="padding: 20px;">
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px;">
                <div style="text-align: center; padding: 15px; background: var(--bg-secondary); border-radius: 10px;">
                    <div style="font-size: 24px; color: var(--primary-blue); font-weight: 600; margin-bottom: 5px;">
                        <?php echo count($students); ?>
                    </div>
                    <div style="color: var(--text-secondary);">Total Students</div>
                </div>
                <div style="text-align: center; padding: 15px; background: var(--bg-secondary); border-radius: 10px;">
                    <div style="font-size: 24px; color: var(--success-green); font-weight: 600; margin-bottom: 5px;">
                        <?php echo count(array_filter($students, function($s) { return $s['outstanding_amount'] == 0; })); ?>
                    </div>
                    <div style="color: var(--text-secondary);">Fully Paid</div>
                </div>
                <div style="text-align: center; padding: 15px; background: var(--bg-secondary); border-radius: 10px;">
                    <div style="font-size: 24px; color: var(--danger-red); font-weight: 600; margin-bottom: 5px;">
                        <?php echo count(array_filter($students, function($s) { return $s['outstanding_amount'] > 0; })); ?>
                    </div>
                    <div style="color: var(--text-secondary);">Outstanding</div>
                </div>
                <div style="text-align: center; padding: 15px; background: var(--bg-secondary); border-radius: 10px;">
                    <div style="font-size: 24px; color: var(--secondary-purple); font-weight: 600; margin-bottom: 5px;">
                        <?php echo round($paid_percentage); ?>%
                    </div>
                    <div style="color: var(--text-secondary);">Collection %</div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function sendReminder(studentId, studentName) {
        if (confirm('Send payment reminder to ' + studentName + '?')) {
            // Create a simple notification
            alert('Reminder sent to ' + studentName);
            // In production, this would send an email or notification
        }
    }
    </script>
    
    <!-- Notification Modal -->
    <div id="notificationModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
        <div style="max-width: 500px; margin: 100px auto; background: var(--bg-card); border-radius: 15px; padding: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2>Send Payment Reminders</h2>
                <button onclick="closeNotificationModal()" style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form method="POST" id="notificationForm">
                <input type="hidden" name="action" value="send_notifications">
                <input type="hidden" name="selected_students" id="selectedStudents" value="">
                <input type="hidden" name="class_id" value="<?php echo htmlspecialchars($class_id); ?>">
                <input type="hidden" name="status" value="<?php echo htmlspecialchars($status_filter); ?>">
                
                <div style="background: var(--bg-secondary); padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <p id="selectedCount" style="margin: 0; color: var(--text-secondary);">0 students selected</p>
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="notify_students" checked>
                        <span>Send SMS to Students</span>
                    </label>
                    <small style="color: var(--text-secondary);">Students will receive payment reminder via SMS</small>
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="notify_parents" checked>
                        <span>Send SMS to Parents</span>
                    </label>
                    <small style="color: var(--text-secondary);">Parents will receive payment reminder via SMS</small>
                </div>
                
                <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                    <button type="button" class="btn btn-secondary" onclick="closeNotificationModal()">Cancel</button>
                    <button type="submit" class="btn btn-success" id="sendBtn"><i class="fas fa-paper-plane"></i> Send Reminders</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    let selectedStudentsArray = [];
    
    function selectStudent(studentId, button) {
        const index = selectedStudentsArray.indexOf(studentId);
        if (index > -1) {
            selectedStudentsArray.splice(index, 1);
            button.classList.remove('btn-success');
            button.classList.add('btn-info');
        } else {
            selectedStudentsArray.push(studentId);
            button.classList.remove('btn-info');
            button.classList.add('btn-success');
        }
    }
    
    function openNotificationModal() {
        if (selectedStudentsArray.length === 0) {
            alert('Please select at least one student');
            return;
        }
        document.getElementById('selectedStudents').value = selectedStudentsArray.join(',');
        document.getElementById('selectedCount').textContent = selectedStudentsArray.length + ' student(s) selected';
        document.getElementById('notificationModal').style.display = 'block';
    }
    
    function closeNotificationModal() {
        document.getElementById('notificationModal').style.display = 'none';
    }
    
    function printArrearsReport() {
        window.print();
    }
    
    window.onclick = function(event) {
        if (event.target.id === 'notificationModal') {
            event.target.style.display = 'none';
        }
    }
    </script>
    
    <style media="print">
        @media print {
            .btn, [onclick], .card-header, form { display: none !important; }
            body { background: white; }
            .table-responsive { overflow: visible !important; }
        }
    </style>
</div>


<?php include BASE_PATH . '/includes/footer.php'; ?>