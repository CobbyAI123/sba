<?php
define('BASE_PATH', dirname(dirname(__FILE__)));
require_once BASE_PATH . '/config.php';

$current_user = check_permission('accountant');
$page_title = 'Settings';
include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fa-cog"></i> Settings</h1>
        <p class="text-muted">Manage your account settings</p>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>Account Settings</h3>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-group">
                            <label>Email Notifications</label>
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="email_reports" checked>
                                <label class="custom-control-label" for="email_reports">
                                    Receive daily financial reports and notifications
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Notification Email</label>
                            <input type="email" class="form-control" value="<?php echo htmlspecialchars($current_user['email'] ?? ''); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label>Report Format</label>
                            <select class="form-control">
                                <option>PDF</option>
                                <option>Excel</option>
                                <option>Email</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                    </form>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-header">
                    <h3>Security</h3>
                </div>
                <div class="card-body">
                    <p><strong>Change Password</strong></p>
                    <div class="form-group">
                        <input type="password" class="form-control" placeholder="Current password">
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" placeholder="New password">
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" placeholder="Confirm new password">
                    </div>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h3>Quick Links</h3>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled">
                        <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                        <li><a href="messages.php"><i class="fas fa-envelope"></i> Messages</a></li>
                        <li><a href="payments.php"><i class="fas fa-wallet"></i> Payments</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
