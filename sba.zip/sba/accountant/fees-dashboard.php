<?php
// accountant/fees-dashboard.php - Accountant Fee Collection and Payment Tracking
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Fee Management & Payment Tracking';
$current_user = check_permission(['accountant', 'admin']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// ============================================================================
// PAYMENT STATISTICS
// ============================================================================

// Payments Today
$payments_today = [];
try {
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total
        FROM fee_payments fp
        INNER JOIN students s ON fp.student_id = s.student_id
        WHERE s.school_id = ? AND fp.status = 'paid' AND DATE(fp.paid_date) = CURDATE()
    ");
    $stmt->execute([$school_id]);
    $result = $stmt->fetch();
    $payments_today['count'] = $result['count'];
    $payments_today['total'] = $result['total'];
} catch (PDOException $e) {
    $payments_today = ['count' => 0, 'total' => 0];
}

// Payments This Month
$payments_month = [];
try {
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as count,
            COALESCE(SUM(amount), 0) as total
        FROM fee_payments fp
        INNER JOIN students s ON fp.student_id = s.student_id
        WHERE s.school_id = ? AND fp.status = 'paid' 
        AND MONTH(fp.paid_date) = MONTH(CURDATE()) 
        AND YEAR(fp.paid_date) = YEAR(CURDATE())
    ");
    $stmt->execute([$school_id]);
    $result = $stmt->fetch();
    $payments_month['count'] = $result['count'];
    $payments_month['total'] = $result['total'];
} catch (PDOException $e) {
    $payments_month = ['count' => 0, 'total' => 0];
}

// Payment Methods Distribution
$payment_methods = [];
try {
    $stmt = $db->prepare("
        SELECT 
            COALESCE(fp.payment_method, 'Not specified') as method,
            COUNT(*) as count,
            COALESCE(SUM(fp.amount), 0) as total
        FROM fee_payments fp
        INNER JOIN students s ON fp.student_id = s.student_id
        WHERE s.school_id = ? AND fp.status = 'paid'
        GROUP BY fp.payment_method
        ORDER BY total DESC
    ");
    $stmt->execute([$school_id]);
    $payment_methods = $stmt->fetchAll();
} catch (PDOException $e) {
    $payment_methods = [];
}

// Daily Payments This Week
$daily_payments = [];
try {
    $stmt = $db->prepare("
        SELECT 
            DATE(fp.paid_date) as date,
            COUNT(*) as count,
            COALESCE(SUM(fp.amount), 0) as total
        FROM fee_payments fp
        INNER JOIN students s ON fp.student_id = s.student_id
        WHERE s.school_id = ? AND fp.status = 'paid'
        AND fp.paid_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(fp.paid_date)
        ORDER BY date DESC
    ");
    $stmt->execute([$school_id]);
    $daily_payments = $stmt->fetchAll();
} catch (PDOException $e) {
    $daily_payments = [];
}

// Recent Payments (Last 20)
$recent_payments = [];
try {
    $stmt = $db->prepare("
        SELECT 
            fp.fee_payment_id,
            CONCAT(u.first_name, ' ', u.last_name) as student_name,
            s.admission_number,
            c.class_name,
            fp.fee_type,
            fp.amount,
            fp.payment_method,
            fp.payment_reference,
            fp.paid_date,
            fp.status
        FROM fee_payments fp
        INNER JOIN students s ON fp.student_id = s.student_id
        INNER JOIN users u ON s.user_id = u.user_id
        LEFT JOIN classes c ON s.class_id = c.class_id
        WHERE s.school_id = ? AND fp.status = 'paid'
        ORDER BY fp.paid_date DESC
        LIMIT 20
    ");
    $stmt->execute([$school_id]);
    $recent_payments = $stmt->fetchAll();
} catch (PDOException $e) {
    $recent_payments = [];
}

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .metric-card {
        background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple));
        color: white;
        padding: 25px;
        border-radius: 15px;
        text-align: center;
        margin-bottom: 20px;
    }
    
    .metric-card.success {
        background: linear-gradient(135deg, #34C759, #30D158);
    }
    
    .metric-card h3 {
        margin: 0;
        font-size: 32px;
        font-weight: 700;
    }
    
    .metric-card p {
        margin: 10px 0 0 0;
        font-size: 14px;
        opacity: 0.9;
    }
    
    .chart-container {
        background: var(--bg-card);
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 30px;
        border: 1px solid var(--border-color);
    }
    </style>
    
    <div style="margin-bottom: 30px;">
        <h2><i class="fas fa-credit-card"></i> Payment Tracking & Fee Management</h2>
        <p style="color: var(--text-secondary); margin: 0;">
            Monitor student payments and track fee collection in real-time
        </p>
    </div>
    
    <!-- Quick Metrics -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px;">
        <div class="metric-card success">
            <h3><?php echo $payments_today['count']; ?></h3>
            <p>✓ Payments Today</p>
            <p style="font-size: 16px; margin-top: 5px;"><?php echo format_currency($payments_today['total']); ?></p>
        </div>
        
        <div class="metric-card">
            <h3><?php echo $payments_month['count']; ?></h3>
            <p>Payments This Month</p>
            <p style="font-size: 16px; margin-top: 5px;"><?php echo format_currency($payments_month['total']); ?></p>
        </div>
        
        <div class="metric-card success">
            <h3>₦<?php echo number_format($payments_month['total'], 2); ?></h3>
            <p>Monthly Revenue</p>
            <p style="font-size: 12px; margin-top: 5px;">Fee collections</p>
        </div>
    </div>
    
    <!-- Daily Payments Chart -->
    <div class="chart-container">
        <h3><i class="fas fa-chart-bar"></i> Daily Payments (Last 7 Days)</h3>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(100px, 1fr)); gap: 15px; margin-top: 20px;">
            <?php if (count($daily_payments) > 0): ?>
                <?php foreach (array_reverse($daily_payments) as $day): ?>
                    <div style="text-align: center;">
                        <div style="background: linear-gradient(135deg, #34C759, #30D158); color: white; padding: 15px; border-radius: 10px; margin-bottom: 10px;">
                            <div style="font-size: 20px; font-weight: 700;">₦<?php echo number_format($day['total'], 0); ?></div>
                            <div style="font-size: 12px; opacity: 0.9;">x<?php echo $day['count']; ?> payments</div>
                        </div>
                        <small><?php echo date('M d', strtotime($day['date'])); ?></small>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="grid-column: 1/-1; text-align: center; color: var(--text-secondary);">No payments recorded</p>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Payment Methods -->
    <div class="card" style="margin-bottom: 30px;">
        <div class="card-header">
            <h3><i class="fas fa-money-bill-wave"></i> Payment Methods Distribution</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Payment Method</th>
                        <th>Count</th>
                        <th>Total Amount</th>
                        <th>% of Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($payment_methods) > 0): ?>
                        <?php 
                        $total_all_methods = array_sum(array_column($payment_methods, 'total'));
                        foreach ($payment_methods as $method):
                            $percentage = $total_all_methods > 0 ? ($method['total'] / $total_all_methods) * 100 : 0;
                        ?>
                            <tr>
                                <td><strong><?php echo ucfirst(str_replace('_', ' ', htmlspecialchars($method['method']))); ?></strong></td>
                                <td><?php echo $method['count']; ?> payments</td>
                                <td><span style="color: #34C759; font-weight: 600;"><?php echo format_currency($method['total']); ?></span></td>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 60px; height: 6px; background: #eee; border-radius: 3px; overflow: hidden;">
                                            <div style="width: <?php echo $percentage; ?>%; height: 100%; background: #34C759;"></div>
                                        </div>
                                        <strong><?php echo round($percentage, 1); ?>%</strong>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 40px;">No payment method data available</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <!-- Recent Payments -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-receipt"></i> Recent Payments (Last 20)</h3>
        </div>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Student</th>
                        <th>Admission No.</th>
                        <th>Class</th>
                        <th>Fee Type</th>
                        <th>Amount</th>
                        <th>Method</th>
                        <th>Reference</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($recent_payments) > 0): ?>
                        <?php foreach ($recent_payments as $payment): ?>
                            <tr>
                                <td><?php echo date('M d, Y H:i', strtotime($payment['paid_date'])); ?></td>
                                <td><strong><?php echo htmlspecialchars($payment['student_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($payment['admission_number']); ?></td>
                                <td><?php echo htmlspecialchars($payment['class_name'] ?? 'N/A'); ?></td>
                                <td>
                                    <span style="text-transform: capitalize;">
                                        <?php echo str_replace('_', ' ', htmlspecialchars($payment['fee_type'])); ?>
                                    </span>
                                </td>
                                <td><span style="color: #34C759; font-weight: 600;"><?php echo format_currency($payment['amount']); ?></span></td>
                                <td>
                                    <span class="badge badge-info">
                                        <?php echo ucfirst(str_replace('_', ' ', htmlspecialchars($payment['payment_method'] ?? 'N/A'))); ?>
                                    </span>
                                </td>
                                <td>
                                    <code style="font-size: 11px; background: var(--bg-secondary); padding: 4px 8px; border-radius: 4px;">
                                        <?php echo htmlspecialchars($payment['payment_reference'] ?? 'N/A'); ?>
                                    </code>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align: center; padding: 40px;">No payment records found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
