<?php
// accountant/canteen-bus-payments.php - Track Canteen & Bus Payments
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/config.php';

$page_title = 'Canteen & Bus Payments';
$current_user = check_permission(['accountant']);

$db = Database::getInstance()->getConnection();
$school_id = $current_user['school_id'];

// Get filter parameters
$class_filter = isset($_GET['class_id']) ? (int)$_GET['class_id'] : null;
$payment_type = isset($_GET['payment_type']) ? sanitize_input($_GET['payment_type']) : 'all';
$payment_status = isset($_GET['status']) ? sanitize_input($_GET['status']) : 'all';
$term_filter = isset($_GET['term_id']) ? (int)$_GET['term_id'] : null;

// Get current term
$stmt = $db->prepare("SELECT term_id FROM terms WHERE school_id = ? AND is_current = 1 LIMIT 1");
$stmt->execute([$school_id]);
$current_term = $stmt->fetch();
if (!$term_filter && $current_term) {
    $term_filter = $current_term['term_id'];
}

// Get all classes
$stmt = $db->prepare("SELECT class_id, class_name FROM classes WHERE school_id = ? ORDER BY class_name");
$stmt->execute([$school_id]);
$classes = $stmt->fetchAll();

// Get all terms
$stmt = $db->prepare("SELECT term_id, term_name, session_year FROM terms WHERE school_id = ? ORDER BY session_year DESC, term_name");
$stmt->execute([$school_id]);
$terms = $stmt->fetchAll();

// Build query for student payment status
$query = "
    SELECT 
        s.student_id,
        s.admission_number,
        CONCAT(COALESCE(u.first_name, 'Unknown'), ' ', COALESCE(u.last_name, '')) as student_name,
        c.class_name,
        s.canteen_fee,
        s.transport_fee,
        COALESCE(SUM(CASE WHEN p.payment_type = 'Canteen Fee' THEN p.amount ELSE 0 END), 0) as canteen_paid,
        COALESCE(SUM(CASE WHEN p.payment_type = 'Transport Fee' THEN p.amount ELSE 0 END), 0) as transport_paid,
        (s.canteen_fee - COALESCE(SUM(CASE WHEN p.payment_type = 'Canteen Fee' THEN p.amount ELSE 0 END), 0)) as canteen_balance,
        (s.transport_fee - COALESCE(SUM(CASE WHEN p.payment_type = 'Transport Fee' THEN p.amount ELSE 0 END), 0)) as transport_balance,
        MAX(CASE WHEN p.payment_type = 'Canteen Fee' THEN p.payment_date END) as last_canteen_payment,
        MAX(CASE WHEN p.payment_type = 'Transport Fee' THEN p.payment_date END) as last_transport_payment,
        COUNT(DISTINCT CASE WHEN p.payment_type = 'Canteen Fee' AND p.collected_by IS NOT NULL THEN p.collected_by END) as canteen_collectors,
        COUNT(DISTINCT CASE WHEN p.payment_type = 'Transport Fee' AND p.collected_by IS NOT NULL THEN p.collected_by END) as transport_collectors
    FROM students s
    LEFT JOIN users u ON s.user_id = u.user_id
    LEFT JOIN classes c ON s.class_id = c.class_id
    LEFT JOIN payments p ON s.student_id = p.student_id 
        AND (p.payment_type IN ('Canteen Fee', 'Transport Fee'))
        " . ($term_filter ? "AND p.term_id = ?" : "") . "
    WHERE s.school_id = ? AND s.status = 'active'
";

$params = [];
if ($term_filter) {
    $params[] = $term_filter;
}
$params[] = $school_id;

if ($class_filter) {
    $query .= " AND s.class_id = ?";
    $params[] = $class_filter;
}

$query .= " GROUP BY s.student_id, s.admission_number, u.first_name, u.last_name, c.class_name, s.canteen_fee, s.transport_fee";

$stmt = $db->prepare($query);
$stmt->execute($params);
$students = $stmt->fetchAll();

// Filter by payment type and status
$filtered_students = [];
foreach ($students as $student) {
    $include = true;
    
    // Payment type filter
    if ($payment_type === 'canteen') {
        if ($student['canteen_fee'] == 0) $include = false;
    } elseif ($payment_type === 'transport') {
        if ($student['transport_fee'] == 0) $include = false;
    }
    
    // Payment status filter
    if ($payment_status !== 'all' && $include) {
        $canteen_status = $student['canteen_paid'] >= $student['canteen_fee'] ? 'paid' : 
                         ($student['canteen_paid'] > 0 ? 'partial' : 'unpaid');
        $transport_status = $student['transport_paid'] >= $student['transport_fee'] ? 'paid' : 
                           ($student['transport_paid'] > 0 ? 'partial' : 'unpaid');
        
        if ($payment_type === 'canteen') {
            if ($canteen_status !== $payment_status) $include = false;
        } elseif ($payment_type === 'transport') {
            if ($transport_status !== $payment_status) $include = false;
        } else {
            if ($canteen_status !== $payment_status && $transport_status !== $payment_status) $include = false;
        }
    }
    
    if ($include) {
        $filtered_students[] = $student;
    }
}

$students = $filtered_students;

// Calculate statistics
$total_students = count($students);
$canteen_expected = 0;
$canteen_collected = 0;
$transport_expected = 0;
$transport_collected = 0;
$canteen_paid = 0;
$canteen_unpaid = 0;
$transport_paid = 0;
$transport_unpaid = 0;

foreach ($students as $student) {
    $canteen_expected += $student['canteen_fee'];
    $canteen_collected += $student['canteen_paid'];
    $transport_expected += $student['transport_fee'];
    $transport_collected += $student['transport_paid'];
    
    if ($student['canteen_paid'] >= $student['canteen_fee'] && $student['canteen_fee'] > 0) $canteen_paid++;
    if ($student['canteen_paid'] < $student['canteen_fee'] && $student['canteen_fee'] > 0) $canteen_unpaid++;
    if ($student['transport_paid'] >= $student['transport_fee'] && $student['transport_fee'] > 0) $transport_paid++;
    if ($student['transport_paid'] < $student['transport_fee'] && $student['transport_fee'] > 0) $transport_unpaid++;
}

// Get teacher collections summary
$stmt = $db->prepare("
    SELECT 
        CONCAT(u.first_name, ' ', u.last_name) as teacher_name,
        p.payment_type,
        COUNT(*) as collection_count,
        SUM(p.amount) as total_collected
    FROM payments p
    JOIN users u ON p.collected_by = u.user_id
    JOIN students s ON p.student_id = s.student_id
    WHERE p.payment_type IN ('Canteen Fee', 'Transport Fee')
        AND s.school_id = ?
        " . ($term_filter ? "AND p.term_id = ?" : "") . "
    GROUP BY p.collected_by, u.first_name, u.last_name, p.payment_type
    ORDER BY total_collected DESC
");
$params = [$school_id];
if ($term_filter) {
    $params[] = $term_filter;
}
$stmt->execute($params);
$teacher_collections = $stmt->fetchAll();

include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <style>
    .filter-card {
        background: var(--card-bg);
        padding: 25px;
        border-radius: 12px;
        margin-bottom: 25px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    .filter-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        align-items: end;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: var(--card-bg);
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    .stat-card h4 {
        margin: 0 0 10px 0;
        font-size: 14px;
        color: var(--text-secondary);
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .stat-card .amount {
        font-size: 32px;
        font-weight: 700;
        margin: 10px 0;
    }
    
    .stat-card .sub-info {
        display: flex;
        justify-content: space-between;
        margin-top: 15px;
        padding-top: 15px;
        border-top: 1px solid var(--border-color);
    }
    
    .status-badge {
        display: inline-block;
        padding: 6px 14px;
        border-radius: 6px;
        font-weight: 600;
        font-size: 13px;
    }
    
    .status-badge.paid { background: #00d68f; color: white; }
    .status-badge.unpaid { background: #ff3d71; color: white; }
    .status-badge.partial { background: #ffa726; color: white; }
    .status-badge.na { background: #ccc; color: #666; }
    
    .tab-buttons {
        display: flex;
        gap: 10px;
        margin-bottom: 25px;
    }
    
    .tab-button {
        padding: 12px 24px;
        border: 2px solid var(--primary-color);
        background: white;
        color: var(--primary-color);
        border-radius: 8px;
        cursor: pointer;
        font-weight: 600;
        transition: all 0.3s;
    }
    
    .tab-button.active {
        background: var(--primary-color);
        color: white;
    }
    
    .tab-button:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    </style>
    
    <!-- Page Header -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
        <h2><i class="fas fa-money-check-alt"></i> Canteen & Bus Payment Tracking</h2>
        <div style="display: flex; gap: 10px;">
            <button onclick="window.print()" class="btn btn-secondary">
                <i class="fas fa-print"></i> Print
            </button>
            <button onclick="exportToCSV()" class="btn btn-primary">
                <i class="fas fa-download"></i> Export CSV
            </button>
        </div>
    </div>
    
    <!-- Tab Buttons -->
    <div class="tab-buttons">
        <button class="tab-button active" onclick="showTab('students')">
            <i class="fas fa-users"></i> Student Payments
        </button>
        <button class="tab-button" onclick="showTab('teachers')">
            <i class="fas fa-chalkboard-teacher"></i> Teacher Collections
        </button>
    </div>
    
    <div id="students-tab">
        <!-- Filters -->
        <div class="filter-card">
            <h3 style="margin-bottom: 20px;"><i class="fas fa-filter"></i> Filter Payments</h3>
            <form method="GET" class="filter-grid">
                <div class="form-group" style="margin: 0;">
                    <label>Payment Type</label>
                    <select name="payment_type" class="form-control">
                        <option value="all" <?php echo $payment_type === 'all' ? 'selected' : ''; ?>>All Types</option>
                        <option value="canteen" <?php echo $payment_type === 'canteen' ? 'selected' : ''; ?>>Canteen Only</option>
                        <option value="transport" <?php echo $payment_type === 'transport' ? 'selected' : ''; ?>>Bus/Transport Only</option>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>Class</label>
                    <select name="class_id" class="form-control">
                        <option value="">All Classes</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?php echo $class['class_id']; ?>" <?php echo $class_filter == $class['class_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>Term</label>
                    <select name="term_id" class="form-control">
                        <?php foreach ($terms as $term): ?>
                            <option value="<?php echo $term['term_id']; ?>" <?php echo $term_filter == $term['term_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($term['term_name'] . ' - ' . $term['session_year']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin: 0;">
                    <label>Payment Status</label>
                    <select name="status" class="form-control">
                        <option value="all" <?php echo $payment_status === 'all' ? 'selected' : ''; ?>>All Status</option>
                        <option value="paid" <?php echo $payment_status === 'paid' ? 'selected' : ''; ?>>Paid</option>
                        <option value="unpaid" <?php echo $payment_status === 'unpaid' ? 'selected' : ''; ?>>Unpaid</option>
                        <option value="partial" <?php echo $payment_status === 'partial' ? 'selected' : ''; ?>>Partial</option>
                    </select>
                </div>
                
                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Filter
                    </button>
                    <a href="<?php echo APP_URL; ?>/accountant/canteen-bus-payments.php" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> Reset
                    </a>
                </div>
            </form>
        </div>
    
        <!-- Statistics -->
        <div class="stats-grid">
            <!-- Canteen Stats -->
            <div class="stat-card" style="border-left: 4px solid #ffa726;">
                <h4><i class="fas fa-utensils"></i> Canteen Fees</h4>
                <div class="amount" style="color: #ffa726;">GH₵ <?php echo number_format($canteen_collected, 2); ?></div>
                <div class="sub-info">
                    <div>
                        <small style="color: var(--text-secondary);">Expected</small>
                        <div style="font-weight: 600;">GH₵ <?php echo number_format($canteen_expected, 2); ?></div>
                    </div>
                    <div style="text-align: right;">
                        <small style="color: var(--text-secondary);">Outstanding</small>
                        <div style="font-weight: 600; color: #ff3d71;">GH₵ <?php echo number_format($canteen_expected - $canteen_collected, 2); ?></div>
                    </div>
                </div>
                <div style="margin-top: 10px;">
                    <small style="color: var(--text-secondary);">Paid: <?php echo $canteen_paid; ?> | Unpaid: <?php echo $canteen_unpaid; ?></small>
                </div>
            </div>
    
            <!-- Transport Stats -->
            <div class="stat-card" style="border-left: 4px solid #2d5bff;">
                <h4><i class="fas fa-bus"></i> Transport Fees</h4>
                <div class="amount" style="color: #2d5bff;">GH₵ <?php echo number_format($transport_collected, 2); ?></div>
                <div class="sub-info">
                    <div>
                        <small style="color: var(--text-secondary);">Expected</small>
                        <div style="font-weight: 600;">GH₵ <?php echo number_format($transport_expected, 2); ?></div>
                    </div>
                    <div style="text-align: right;">
                        <small style="color: var(--text-secondary);">Outstanding</small>
                        <div style="font-weight: 600; color: #ff3d71;">GH₵ <?php echo number_format($transport_expected - $transport_collected, 2); ?></div>
                    </div>
                </div>
                <div style="margin-top: 10px;">
                    <small style="color: var(--text-secondary);">Paid: <?php echo $transport_paid; ?> | Unpaid: <?php echo $transport_unpaid; ?></small>
                </div>
            </div>
    
            <!-- Total Stats -->
            <div class="stat-card" style="border-left: 4px solid #00d68f;">
                <h4><i class="fas fa-chart-line"></i> Total Collection</h4>
                <div class="amount" style="color: #00d68f;">GH₵ <?php echo number_format($canteen_collected + $transport_collected, 2); ?></div>
                <div class="sub-info">
                    <div>
                        <small style="color: var(--text-secondary);">Expected</small>
                        <div style="font-weight: 600;">GH₵ <?php echo number_format($canteen_expected + $transport_expected, 2); ?></div>
                    </div>
                    <div style="text-align: right;">
                        <small style="color: var(--text-secondary);">Rate</small>
                        <div style="font-weight: 600;">
                            <?php 
                            $total_expected = $canteen_expected + $transport_expected;
                            $collection_rate = $total_expected > 0 ? (($canteen_collected + $transport_collected) / $total_expected * 100) : 0;
                            echo number_format($collection_rate, 1); 
                            ?>%
                        </div>
                    </div>
                </div>
                <div style="margin-top: 10px;">
                    <small style="color: var(--text-secondary);">Students: <?php echo $total_students; ?></small>
                </div>
            </div>
        </div>
    
        <!-- Students Table -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-table"></i> Student Payment Details</h3>
            </div>
            <div style="padding: 20px; overflow-x: auto;">
                <table class="data-table" id="studentsTable">
                    <thead>
                        <tr>
                            <th>Admission No.</th>
                            <th>Student Name</th>
                            <th>Class</th>
                            <th colspan="3" style="background: #ffa726; color: white;">Canteen Fee</th>
                            <th colspan="3" style="background: #2d5bff; color: white;">Transport Fee</th>
                            <th>Action</th>
                        </tr>
                        <tr>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th style="background: #ffd699;">Fee</th>
                            <th style="background: #ffd699;">Paid</th>
                            <th style="background: #ffd699;">Status</th>
                            <th style="background: #a8bdff;">Fee</th>
                            <th style="background: #a8bdff;">Paid</th>
                            <th style="background: #a8bdff;">Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($students) > 0): ?>
                            <?php foreach ($students as $student): 
                                $canteen_status = $student['canteen_fee'] == 0 ? 'na' : 
                                                ($student['canteen_paid'] >= $student['canteen_fee'] ? 'paid' : 
                                                ($student['canteen_paid'] > 0 ? 'partial' : 'unpaid'));
                                $transport_status = $student['transport_fee'] == 0 ? 'na' : 
                                                  ($student['transport_paid'] >= $student['transport_fee'] ? 'paid' : 
                                                  ($student['transport_paid'] > 0 ? 'partial' : 'unpaid'));
                            ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($student['admission_number']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($student['student_name']); ?></td>
                                    <td><?php echo htmlspecialchars($student['class_name']); ?></td>
                                    <td>GH₵ <?php echo number_format($student['canteen_fee'], 2); ?></td>
                                    <td style="color: #00d68f; font-weight: 600;">GH₵ <?php echo number_format($student['canteen_paid'], 2); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $canteen_status; ?>">
                                            <?php echo $canteen_status === 'na' ? 'N/A' : ucfirst($canteen_status); ?>
                                        </span>
                                    </td>
                                    <td>GH₵ <?php echo number_format($student['transport_fee'], 2); ?></td>
                                    <td style="color: #00d68f; font-weight: 600;">GH₵ <?php echo number_format($student['transport_paid'], 2); ?></td>
                                    <td>
                                        <span class="status-badge <?php echo $transport_status; ?>">
                                            <?php echo $transport_status === 'na' ? 'N/A' : ucfirst($transport_status); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="student-payments.php?student_id=<?php echo $student['student_id']; ?>" 
                                           class="btn btn-sm btn-primary" title="View Payments">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="10" style="text-align: center; padding: 40px;">
                                    <i class="fas fa-inbox" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 10px; display: block;"></i>
                                    <h3>No Records Found</h3>
                                    <p style="color: var(--text-secondary);">Try adjusting your filters.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Teacher Collections Tab -->
    <div id="teachers-tab" style="display: none;">
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-chalkboard-teacher"></i> Teacher Collection Summary</h3>
            </div>
            <div style="padding: 20px; overflow-x: auto;">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Teacher Name</th>
                            <th>Payment Type</th>
                            <th>Collections Count</th>
                            <th>Total Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($teacher_collections) > 0): ?>
                            <?php foreach ($teacher_collections as $collection): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($collection['teacher_name']); ?></strong></td>
                                    <td>
                                        <span style="color: <?php echo $collection['payment_type'] === 'Canteen Fee' ? '#ffa726' : '#2d5bff'; ?>; font-weight: 600;">
                                            <i class="fas fa-<?php echo $collection['payment_type'] === 'Canteen Fee' ? 'utensils' : 'bus'; ?>"></i>
                                            <?php echo $collection['payment_type']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo number_format($collection['collection_count']); ?> payments</td>
                                    <td style="font-weight: 700; color: #00d68f; font-size: 16px;">
                                        GH₵ <?php echo number_format($collection['total_collected'], 2); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" style="text-align: center; padding: 40px;">
                                    <i class="fas fa-user-slash" style="font-size: 48px; color: var(--text-secondary); margin-bottom: 10px; display: block;"></i>
                                    <h3>No Teacher Collections</h3>
                                    <p style="color: var(--text-secondary);">No payments have been collected by teachers yet.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
    function showTab(tab) {
        // Hide all tabs
        document.getElementById('students-tab').style.display = 'none';
        document.getElementById('teachers-tab').style.display = 'none';
        
        // Remove active class from all buttons
        document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
        
        // Show selected tab
        document.getElementById(tab + '-tab').style.display = 'block';
        
        // Add active class to clicked button
        event.target.closest('.tab-button').classList.add('active');
    }
    
    function exportToCSV() {
        const table = document.getElementById('studentsTable');
        let csv = [];
        
        csv.push(['Canteen & Bus Payment Report']);
        csv.push(['Generated on: ' + new Date().toLocaleDateString()]);
        csv.push([]);
        
        // Add statistics
        csv.push(['Financial Summary']);
        csv.push(['Canteen Expected', 'GH₵ <?php echo number_format($canteen_expected, 2); ?>']);
        csv.push(['Canteen Collected', 'GH₵ <?php echo number_format($canteen_collected, 2); ?>']);
        csv.push(['Transport Expected', 'GH₵ <?php echo number_format($transport_expected, 2); ?>']);
        csv.push(['Transport Collected', 'GH₵ <?php echo number_format($transport_collected, 2); ?>']);
        csv.push(['Total Expected', 'GH₵ <?php echo number_format($canteen_expected + $transport_expected, 2); ?>']);
        csv.push(['Total Collected', 'GH₵ <?php echo number_format($canteen_collected + $transport_collected, 2); ?>']);
        csv.push([]);
        
        // Add table
        const rows = table.querySelectorAll('tr');
        rows.forEach(row => {
            const cols = row.querySelectorAll('td, th');
            const rowData = [];
            cols.forEach((col, index) => {
                if (index < 9) { // Exclude action column
                    rowData.push('"' + col.textContent.trim() + '"');
                }
            });
            if (rowData.length > 0) {
                csv.push(rowData);
            }
        });
        
        const csvContent = csv.map(row => Array.isArray(row) ? row.join(',') : row).join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'canteen-bus-payments-' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
    }
    </script>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
