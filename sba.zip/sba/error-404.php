<?php
// error-404.php - Custom 404 Error Page
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .error-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #2D5BFF, #6C5CE7);
            padding: 20px;
        }
        .error-container {
            text-align: center;
            color: white;
            max-width: 600px;
        }
        .error-code {
            font-size: 120px;
            font-weight: bold;
            margin: 0;
            text-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .error-title {
            font-size: 32px;
            margin: 20px 0;
        }
        .error-message {
            font-size: 18px;
            margin: 20px 0;
            opacity: 0.9;
        }
        .error-icon {
            font-size: 80px;
            margin-bottom: 20px;
            opacity: 0.8;
        }
        .btn-home {
            display: inline-block;
            padding: 15px 40px;
            background: white;
            color: #2D5BFF;
            text-decoration: none;
            border-radius: 50px;
            font-weight: bold;
            margin-top: 30px;
            transition: all 0.3s ease;
        }
        .btn-home:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>
    <div class="error-page">
        <div class="error-container">
            <div class="error-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h1 class="error-code">404</h1>
            <h2 class="error-title">Page Not Found</h2>
            <p class="error-message">
                The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
            </p>
            <a href="/msms" class="btn-home">
                <i class="fas fa-home"></i> Go to Homepage
            </a>
        </div>
    </div>
</body>
</html>
