<?php
// Comprehensive audit of all user portals
define('BASE_PATH', dirname(__FILE__));

$essential_pages = [
    'profile.php' => 'User profile management',
    'settings.php' => 'Account settings',
    'messages.php' => 'Messaging system',
    'dashboard.php' => 'Main dashboard'
];

$portals = [
    'accountant' => 'Accountant',
    'admin' => 'Admin',
    'bookstore' => 'Bookstore',
    'librarian' => 'Librarian',
    'parent' => 'Parent',
    'proprietor' => 'Proprietor',
    'student' => 'Student',
    'super-admin' => 'Super Admin',
    'teacher' => 'Teacher'
];

echo "=" . str_repeat("=", 120) . "\n";
echo "COMPREHENSIVE PORTAL AUDIT\n";
echo "=" . str_repeat("=", 120) . "\n\n";

$issues = [];

foreach ($portals as $portal_dir => $portal_name) {
    $base_path = BASE_PATH . '/' . $portal_dir;
    
    if (!is_dir($base_path)) {
        echo "❌ $portal_name: Directory not found\n";
        $issues[$portal_name] = ['Directory not found'];
        continue;
    }
    
    echo "\n📁 $portal_name Portal:\n";
    echo str_repeat("-", 50) . "\n";
    
    $portal_issues = [];
    
    foreach ($essential_pages as $page => $description) {
        $file_path = $base_path . '/' . $page;
        
        if (!file_exists($file_path)) {
            echo "  ❌ $page - MISSING ($description)\n";
            $portal_issues[] = "Missing: $page";
        } else {
            $size = filesize($file_path);
            
            // Check if it's a stub (less than 500 bytes) or redirect
            if ($size < 500) {
                $content = file_get_contents($file_path);
                if (strpos($content, 'redirect') !== false) {
                    echo "  ⚠️  $page - REDIRECT (size: {$size}B)\n";
                    $portal_issues[] = "Stub/Redirect: $page";
                } else {
                    echo "  ⚠️  $page - STUB (size: {$size}B)\n";
                    $portal_issues[] = "Stub: $page";
                }
            } else {
                echo "  ✅ $page - EXISTS (size: {$size}B)\n";
            }
        }
    }
    
    if (!empty($portal_issues)) {
        $issues[$portal_name] = $portal_issues;
    }
}

echo "\n\n" . "=" . str_repeat("=", 120) . "\n";
echo "SUMMARY OF ISSUES\n";
echo "=" . str_repeat("=", 120) . "\n\n";

if (empty($issues)) {
    echo "✅ All portals are complete!\n";
} else {
    foreach ($issues as $portal => $portal_issues) {
        echo "\n$portal:\n";
        foreach ($portal_issues as $issue) {
            echo "  • $issue\n";
        }
    }
}

echo "\n";
?>
