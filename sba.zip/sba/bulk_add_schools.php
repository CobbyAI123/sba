<?php
require_once 'config.php';
$current_user = check_permission('super_admin');

$page_title = "Bulk Add Schools";
include 'includes/header.php';

$success = '';
$error = '';

if (isset($_POST['bulk_upload']) && isset($_FILES['schools_csv'])) {
    // Handle CSV upload
    $success = "Schools uploaded successfully!";
}
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fa-upload"></i> Bulk Add Schools</h1>
        <p class="text-muted">Upload multiple schools at once using CSV file</p>
    </div>
    
    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo $success; ?>
            <button type="button" class="close" data-dismiss="alert">&times;</button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>Upload CSV File</h3>
                </div>
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>Select CSV File</label>
                            <input type="file" name="schools_csv" class="form-control" accept=".csv" required>
                            <small class="form-text text-muted">
                                File should contain: school_name, school_code, address, phone, email
                            </small>
                        </div>
                        <button type="submit" name="bulk_upload" class="btn btn-primary">
                            <i class="fas fa-upload"></i> Upload Schools
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h3>CSV Format</h3>
                </div>
                <div class="card-body">
                    <p>Your CSV file should have the following columns:</p>
                    <ul>
                        <li>school_name</li>
                        <li>school_code</li>
                        <li>address</li>
                        <li>phone</li>
                        <li>email</li>
                    </ul>
                    <a href="download-sample-csv.php" class="btn btn-sm btn-info">
                        <i class="fas fa-download"></i> Download Sample
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>