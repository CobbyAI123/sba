<?php
// ============================================================================
// CREATE OR FIX SUPERADMIN USER
// ============================================================================
// Run this to create/fix the superadmin account
// DELETE THIS FILE AFTER USE
// ============================================================================

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html>
<html>
<head>
    <title>Create Superadmin</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f5f5f5; }
        .box { background: white; padding: 20px; margin: 10px 0; border-radius: 5px; }
        .success { color: green; font-weight: bold; }
        .error { color: red; font-weight: bold; }
        .info { color: blue; }
        button { padding: 10px 20px; background: #2D5BFF; color: white; border: none; cursor: pointer; border-radius: 5px; }
    </style>
</head>
<body>";

echo "<h1>🔧 Create/Fix Superadmin User</h1>";

// Load config
try {
    require_once __DIR__ . '/config.php';
    echo "<div class='box'><p class='success'>✓ Config loaded</p></div>";
} catch (Exception $e) {
    die("<div class='box'><p class='error'>✗ Cannot load config: " . $e->getMessage() . "</p></div>");
}

// Get database connection
try {
    $db = Database::getInstance()->getConnection();
    echo "<div class='box'><p class='success'>✓ Database connected</p></div>";
} catch (Exception $e) {
    die("<div class='box'><p class='error'>✗ Cannot connect to database: " . $e->getMessage() . "</p></div>");
}

// Check if users table exists
echo "<div class='box'><h2>Step 1: Check Users Table</h2>";
try {
    $stmt = $db->query("SHOW TABLES LIKE 'users'");
    $tableExists = $stmt->rowCount() > 0;
    
    if ($tableExists) {
        echo "<p class='success'>✓ Users table exists</p>";
        
        // Count users
        $stmt = $db->query("SELECT COUNT(*) as count FROM users");
        $result = $stmt->fetch();
        echo "<p class='info'>Total users in database: " . $result['count'] . "</p>";
        
    } else {
        echo "<p class='error'>✗ Users table does NOT exist!</p>";
        echo "<p>You need to import the database schema first.</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>✗ Error: " . $e->getMessage() . "</p>";
}
echo "</div>";

// Check for existing superadmin
echo "<div class='box'><h2>Step 2: Check Superadmin User</h2>";
try {
    $stmt = $db->prepare("SELECT * FROM users WHERE username = 'superadmin'");
    $stmt->execute();
    $existingUser = $stmt->fetch();
    
    if ($existingUser) {
        echo "<p class='info'>Superadmin user found:</p>";
        echo "<ul>";
        echo "<li>User ID: " . $existingUser['user_id'] . "</li>";
        echo "<li>Username: " . $existingUser['username'] . "</li>";
        echo "<li>Email: " . ($existingUser['email'] ?? 'Not set') . "</li>";
        echo "<li>Status: " . $existingUser['status'] . "</li>";
        echo "<li>Role: " . $existingUser['role'] . "</li>";
        echo "<li>School ID: " . ($existingUser['school_id'] ?? 'Not set') . "</li>";
        echo "</ul>";
        
        if ($existingUser['status'] !== 'active') {
            echo "<p class='error'>⚠ User is NOT active!</p>";
        }
    } else {
        echo "<p class='error'>✗ Superadmin user NOT found in database</p>";
    }
} catch (Exception $e) {
    echo "<p class='error'>✗ Error: " . $e->getMessage() . "</p>";
}
echo "</div>";

// Create/Update form
echo "<div class='box'><h2>Step 3: Create/Update Superadmin</h2>";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_superadmin'])) {
    echo "<h3>Creating/Updating Superadmin...</h3>";
    
    try {
        // Password hash for "password"
        $passwordHash = password_hash('password', PASSWORD_DEFAULT);
        
        // Check if user exists
        $stmt = $db->prepare("SELECT user_id FROM users WHERE username = 'superadmin'");
        $stmt->execute();
        $exists = $stmt->fetch();
        
        if ($exists) {
            // Update existing user
            $stmt = $db->prepare("
                UPDATE users 
                SET password_hash = ?,
                    status = 'active',
                    role = 'super_admin',
                    email = 'superadmin@schoolsystem.com',
                    first_name = 'Super',
                    last_name = 'Admin'
                WHERE username = 'superadmin'
            ");
            $stmt->execute([$passwordHash]);
            
            echo "<p class='success'>✓ Superadmin user UPDATED successfully!</p>";
            
        } else {
            // Check if we need school_id
            $schoolIdRequired = false;
            try {
                $stmt = $db->query("SHOW COLUMNS FROM users LIKE 'school_id'");
                $schoolIdRequired = $stmt->rowCount() > 0;
            } catch (Exception $e) {
                // Column check failed, assume not required
            }
            
            // Insert new user
            if ($schoolIdRequired) {
                // First create a default school if none exists
                $stmt = $db->query("SELECT school_id FROM schools LIMIT 1");
                $school = $stmt->fetch();
                
                if (!$school) {
                    // Create default school
                    $stmt = $db->prepare("
                        INSERT INTO schools (school_name, school_code, email, phone, address, status, created_at)
                        VALUES ('Main School', 'MAIN001', 'info@school.com', '0000000000', 'School Address', 'active', NOW())
                    ");
                    $stmt->execute();
                    $schoolId = $db->lastInsertId();
                    echo "<p class='info'>→ Created default school (ID: $schoolId)</p>";
                } else {
                    $schoolId = $school['school_id'];
                    echo "<p class='info'>→ Using existing school (ID: $schoolId)</p>";
                }
                
                $stmt = $db->prepare("
                    INSERT INTO users (username, password_hash, email, first_name, last_name, role, school_id, status, created_at)
                    VALUES ('superadmin', ?, 'superadmin@schoolsystem.com', 'Super', 'Admin', 'super_admin', ?, 'active', NOW())
                ");
                $stmt->execute([$passwordHash, $schoolId]);
                
            } else {
                // No school_id required
                $stmt = $db->prepare("
                    INSERT INTO users (username, password_hash, email, first_name, last_name, role, status, created_at)
                    VALUES ('superadmin', ?, 'superadmin@schoolsystem.com', 'Super', 'Admin', 'super_admin', 'active', NOW())
                ");
                $stmt->execute([$passwordHash]);
            }
            
            echo "<p class='success'>✓ Superadmin user CREATED successfully!</p>";
        }
        
        echo "<div style='background: #e7f3ff; padding: 15px; border-left: 4px solid #2D5BFF; margin-top: 20px;'>";
        echo "<h3>✅ Login Credentials:</h3>";
        echo "<p><strong>Username:</strong> superadmin</p>";
        echo "<p><strong>Password:</strong> password</p>";
        echo "<p><a href='login.php' style='background: #2D5BFF; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 10px;'>Go to Login Page</a></p>";
        echo "</div>";
        
        echo "<p style='margin-top: 20px;'><a href='test-login-no-htaccess.php'>Test Login Again</a></p>";
        
    } catch (Exception $e) {
        echo "<p class='error'>✗ Error: " . $e->getMessage() . "</p>";
        echo "<pre>" . $e->getTraceAsString() . "</pre>";
    }
    
} else {
    // Show form
    echo "<p>Click the button below to create or fix the superadmin account:</p>";
    echo "<form method='POST'>";
    echo "<button type='submit' name='create_superadmin'>Create/Fix Superadmin User</button>";
    echo "</form>";
    
    echo "<div style='background: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; margin-top: 20px;'>";
    echo "<h4>This will:</h4>";
    echo "<ul>";
    echo "<li>Create superadmin user if it doesn't exist</li>";
    echo "<li>Update password to 'password' if user exists</li>";
    echo "<li>Set status to 'active'</li>";
    echo "<li>Set role to 'super_admin'</li>";
    echo "</ul>";
    echo "</div>";
}

echo "</div>";

// Additional checks
echo "<div class='box'><h2>Additional Checks</h2>";

// Check table structure
try {
    echo "<h3>Users Table Structure:</h3>";
    $stmt = $db->query("DESCRIBE users");
    $columns = $stmt->fetchAll();
    
    echo "<table border='1' cellpadding='5' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    foreach ($columns as $col) {
        echo "<tr>";
        echo "<td>" . $col['Field'] . "</td>";
        echo "<td>" . $col['Type'] . "</td>";
        echo "<td>" . $col['Null'] . "</td>";
        echo "<td>" . $col['Key'] . "</td>";
        echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} catch (Exception $e) {
    echo "<p class='error'>Cannot get table structure: " . $e->getMessage() . "</p>";
}

echo "</div>";

// Warning
echo "<div class='box' style='background: #fee; border-left: 4px solid #f00;'>";
echo "<h2>⚠️ SECURITY WARNING</h2>";
echo "<p><strong>DELETE THIS FILE after creating the superadmin!</strong></p>";
echo "<p>File: create-superadmin.php</p>";
echo "<p>This file is a security risk if left on the server.</p>";
echo "</div>";

echo "</body></html>";
?>
