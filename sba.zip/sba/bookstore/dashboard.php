<?php
require_once '../config.php';
requireLogin('bookstore');

$page_title = "Bookstore Dashboard";
include '../includes/header.php';
include '../includes/sidebar.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fa-store"></i> Bookstore Dashboard</h1>
        <p class="text-muted">Manage your bookstore operations</p>
    </div>
    
    <div class="row">
        <div class="col-md-3">
            <div class="card stats-card bg-primary text-white">
                <div class="card-body">
                    <h3>0</h3>
                    <p><i class="fas fa-boxes"></i> Total Items</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stats-card bg-success text-white">
                <div class="card-body">
                    <h3>0</h3>
                    <p><i class="fas fa-shopping-cart"></i> Today's Sales</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stats-card bg-info text-white">
                <div class="card-body">
                    <h3>GHS 0.00</h3>
                    <p><i class="fas fa-money-bill-wave"></i> Revenue</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card stats-card bg-warning text-white">
                <div class="card-body">
                    <h3>0</h3>
                    <p><i class="fas fa-exclamation-triangle"></i> Low Stock</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3>Quick Actions</h3>
                </div>
                <div class="card-body">
                    <a href="items.php" class="btn btn-primary mr-2">
                        <i class="fas fa-plus"></i> Add Item
                    </a>
                    <a href="sales.php" class="btn btn-success mr-2">
                        <i class="fas fa-cash-register"></i> Record Sale
                    </a>
                    <a href="reports.php" class="btn btn-info">
                        <i class="fas fa-chart-bar"></i> View Reports
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>