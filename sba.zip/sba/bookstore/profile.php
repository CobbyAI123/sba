<?php
define('BASE_PATH', dirname(dirname(__FILE__)));
require_once BASE_PATH . '/config.php';

$current_user = check_permission('bookstore_manager');
$page_title = 'My Profile';
include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fa-user-circle"></i> My Profile</h1>
        <p class="text-muted">Manage your profile information</p>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <div style="width: 100px; height: 100px; background: linear-gradient(135deg, var(--primary-blue), var(--secondary-purple)); border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; color: white; font-size: 40px;">
                        <?php echo strtoupper(substr($current_user['first_name'], 0, 1) . substr($current_user['last_name'], 0, 1)); ?>
                    </div>
                    <h3><?php echo htmlspecialchars($current_user['first_name'] . ' ' . $current_user['last_name']); ?></h3>
                    <p class="text-muted"><?php echo ucfirst(str_replace('_', ' ', $current_user['role'])); ?></p>
                    <hr>
                    <p><strong>Username:</strong> <?php echo htmlspecialchars($current_user['username']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($current_user['email'] ?? 'Not set'); ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>Edit Profile</h3>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($current_user['first_name']); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($current_user['last_name']); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" value="<?php echo htmlspecialchars($current_user['email'] ?? ''); ?>" disabled>
                        </div>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i> Contact your administrator to update your profile information.
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
