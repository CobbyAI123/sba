<?php
define('BASE_PATH', dirname(dirname(__FILE__)));
require_once BASE_PATH . '/config.php';

$current_user = check_permission('bookstore_manager');
$page_title = 'Reports';
include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fa-chart-bar"></i> Reports</h1>
        <p class="text-muted">View bookstore reports and analytics</p>
    </div>

    <div class="row">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body text-center">
                    <h3 style="margin: 0;">0</h3>
                    <p style="margin: 5px 0 0 0;">Total Items</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body text-center">
                    <h3 style="margin: 0;">0</h3>
                    <p style="margin: 5px 0 0 0;">Total Sales</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body text-center">
                    <h3 style="margin: 0;">0</h3>
                    <p style="margin: 5px 0 0 0;">Low Stock Items</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body text-center">
                    <h3 style="margin: 0;">GHS 0.00</h3>
                    <p style="margin: 5px 0 0 0;">Total Revenue</p>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <h3>Generate Report</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
                    <label>Report Type</label>
                    <select class="form-control">
                        <option>Sales Report</option>
                        <option>Inventory Report</option>
                        <option>Revenue Report</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label>Start Date</label>
                    <input type="date" class="form-control">
                </div>
                <div class="col-md-3">
                    <label>End Date</label>
                    <input type="date" class="form-control">
                </div>
                <div class="col-md-3" style="padding-top: 32px;">
                    <button class="btn btn-primary btn-block">Generate</button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
