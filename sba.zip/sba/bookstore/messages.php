<?php
define('BASE_PATH', dirname(dirname(__FILE__)));
require_once BASE_PATH . '/config.php';

$current_user = check_permission('bookstore_manager');
$page_title = 'Messages';
include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fa-envelope"></i> Messages</h1>
        <p class="text-muted">View and manage your messages</p>
    </div>

    <div class="row">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 style="margin: 0; color: var(--primary-blue);">0</h3>
                    <p style="margin: 8px 0 0 0;">Total Messages</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 style="margin: 0; color: #34C759;">0</h3>
                    <p style="margin: 8px 0 0 0;">Unread</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 style="margin: 0; color: #FF9500;">0</h3>
                    <p style="margin: 8px 0 0 0;">From Admin</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 style="margin: 0; color: #5856D6;">0</h3>
                    <p style="margin: 8px 0 0 0;">Archived</p>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h3 style="margin: 0;">Inbox</h3>
                <button class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> New Message
                </button>
            </div>
        </div>
        <div class="card-body">
            <div style="text-align: center; padding: 40px; color: var(--text-secondary);">
                <i class="fas fa-inbox" style="font-size: 48px; opacity: 0.3; margin-bottom: 20px;"></i>
                <p>No messages yet</p>
            </div>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
