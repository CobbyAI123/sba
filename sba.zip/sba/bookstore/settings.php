<?php
define('BASE_PATH', dirname(dirname(__FILE__)));
require_once BASE_PATH . '/config.php';

$current_user = check_permission('bookstore_manager');
$page_title = 'Settings';
include BASE_PATH . '/includes/header.php';
?>

<div class="content-wrapper">
    <div class="content-header">
        <h1><i class="fas fa-cog"></i> Settings</h1>
        <p class="text-muted">Manage your bookstore settings</p>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>General Settings</h3>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-group">
                            <label>Stock Low Threshold</label>
                            <input type="number" class="form-control" placeholder="Default: 10" value="10">
                            <small class="text-muted">Alert when stock falls below this number</small>
                        </div>
                        <div class="form-group">
                            <label>Notifications Email</label>
                            <input type="email" class="form-control" placeholder="Enter email" value="<?php echo htmlspecialchars($current_user['email'] ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" checked> Receive low stock notifications
                            </label>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" checked> Receive daily sales report
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h3>Quick Links</h3>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled">
                        <li><a href="dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                        <li><a href="items.php"><i class="fas fa-box"></i> Manage Items</a></li>
                        <li><a href="sales.php"><i class="fas fa-shopping-cart"></i> Sales</a></li>
                        <li><a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
