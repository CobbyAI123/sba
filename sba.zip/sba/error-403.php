<?php
// error-403.php - Custom 403 Forbidden Page
http_response_code(403);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 - Access Forbidden</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .error-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #6C5CE7, #FFA726);
            padding: 20px;
        }
        .error-container {
            text-align: center;
            color: white;
            max-width: 600px;
        }
        .error-code {
            font-size: 120px;
            font-weight: bold;
            margin: 0;
            text-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .error-title {
            font-size: 32px;
            margin: 20px 0;
        }
        .error-message {
            font-size: 18px;
            margin: 20px 0;
            opacity: 0.9;
        }
        .error-icon {
            font-size: 80px;
            margin-bottom: 20px;
            opacity: 0.8;
        }
        .btn-home {
            display: inline-block;
            padding: 15px 40px;
            background: white;
            color: #6C5CE7;
            text-decoration: none;
            border-radius: 50px;
            font-weight: bold;
            margin-top: 30px;
            transition: all 0.3s ease;
        }
        .btn-home:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>
    <div class="error-page">
        <div class="error-container">
            <div class="error-icon">
                <i class="fas fa-lock"></i>
            </div>
            <h1 class="error-code">403</h1>
            <h2 class="error-title">Access Forbidden</h2>
            <p class="error-message">
                You don't have permission to access this resource. Please contact your administrator if you believe this is an error.
            </p>
            <a href="/msms" class="btn-home">
                <i class="fas fa-home"></i> Go to Homepage
            </a>
        </div>
    </div>
</body>
</html>
