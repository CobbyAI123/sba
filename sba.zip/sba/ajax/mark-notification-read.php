<?php
// ajax/mark-notification-read.php
require_once dirname(__DIR__) . '/config.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user = get_logged_in_user();
$db = Database::getInstance()->getConnection();

$data = json_decode(file_get_contents('php://input'), true);
$notification_id = $data['notification_id'] ?? null;

if (!$notification_id) {
    echo json_encode(['success' => false, 'message' => 'Invalid notification ID']);
    exit;
}

$stmt = $db->prepare("
    UPDATE notifications 
    SET is_read = 1 
    WHERE notification_id = ? AND user_id = ?
");
$stmt->execute([$notification_id, $user['user_id']]);

echo json_encode(['success' => true]);
