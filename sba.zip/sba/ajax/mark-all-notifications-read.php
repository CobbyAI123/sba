<?php
// ajax/mark-all-notifications-read.php
require_once dirname(__DIR__) . '/config.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user = get_logged_in_user();
$db = Database::getInstance()->getConnection();

$stmt = $db->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
$stmt->execute([$user['user_id']]);

echo json_encode(['success' => true]);
