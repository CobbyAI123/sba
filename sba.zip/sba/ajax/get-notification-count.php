<?php
// ajax/get-notification-count.php
require_once dirname(__DIR__) . '/config.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user = get_logged_in_user();
$db = Database::getInstance()->getConnection();

$stmt = $db->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->execute([$user['user_id']]);
$result = $stmt->fetch();

echo json_encode([
    'success' => true,
    'count' => $result['count']
]);
