<?php
// ajax/get-notifications.php
require_once dirname(__DIR__) . '/config.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user = get_logged_in_user();
$db = Database::getInstance()->getConnection();

$stmt = $db->prepare("
    SELECT * FROM notifications 
    WHERE user_id = ? 
    ORDER BY created_at DESC 
    LIMIT 20
");
$stmt->execute([$user['user_id']]);
$notifications = $stmt->fetchAll();

echo json_encode([
    'success' => true,
    'notifications' => $notifications
]);
