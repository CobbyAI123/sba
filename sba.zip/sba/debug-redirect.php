<?php
// Debug redirect issue
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';

echo "<!DOCTYPE html><html><head><title>Debug Redirect</title>";
echo "<style>body{font-family:Arial;padding:20px;background:#f5f5f5;} .box{background:white;padding:20px;margin:10px 0;border-radius:8px;border-left:4px solid #2196F3;} pre{background:#f8f9fa;padding:10px;border-radius:4px;overflow-x:auto;}</style>";
echo "</head><body>";

echo "<h1>🔍 Debug Information</h1>";

// 1. Check APP_ENV
echo "<div class='box'>";
echo "<h2>1. Environment</h2>";
echo "<pre>APP_ENV: " . APP_ENV . "</pre>";
echo "<pre>APP_URL: " . APP_URL . "</pre>";
echo "<pre>HTTP_HOST: " . ($_SERVER['HTTP_HOST'] ?? 'not set') . "</pre>";
echo "</div>";

// 2. Check if logged in
echo "<div class='box'>";
echo "<h2>2. Session Status</h2>";
if (isset($_SESSION['user_id'])) {
    echo "<pre style='color:green'>✅ Logged in as User ID: " . $_SESSION['user_id'] . "</pre>";
    echo "<pre>Role: " . ($_SESSION['role'] ?? 'not set') . "</pre>";
    echo "<pre>Username: " . ($_SESSION['username'] ?? 'not set') . "</pre>";
    echo "<pre>Full Name: " . ($_SESSION['full_name'] ?? 'not set') . "</pre>";
} else {
    echo "<pre style='color:red'>❌ NOT logged in</pre>";
}
echo "</div>";

// 3. Check database connection
echo "<div class='box'>";
echo "<h2>3. Database Connection</h2>";
try {
    $db = Database::getInstance()->getConnection();
    echo "<pre style='color:green'>✅ Database connected</pre>";
    
    // Get user count
    $stmt = $db->query("SELECT COUNT(*) as count FROM users");
    $result = $stmt->fetch();
    echo "<pre>Total users: " . $result['count'] . "</pre>";
} catch (Exception $e) {
    echo "<pre style='color:red'>❌ Database error: " . $e->getMessage() . "</pre>";
}
echo "</div>";

// 4. Test dashboard URLs
echo "<div class='box'>";
echo "<h2>4. Dashboard URLs</h2>";
$roles = ['super_admin', 'admin', 'teacher', 'student'];
foreach ($roles as $role) {
    $url = get_dashboard_url($role);
    echo "<pre>$role: $url</pre>";
}
echo "</div>";

// 5. Check if dashboard files exist
echo "<div class='box'>";
echo "<h2>5. Dashboard Files Check</h2>";
$files_to_check = [
    'super-admin/dashboard.php',
    'admin/dashboard.php',
    'teacher/dashboard.php',
    'accountant/dashboard.php',
];

foreach ($files_to_check as $file) {
    $fullpath = BASE_PATH . '/' . $file;
    if (file_exists($fullpath)) {
        echo "<pre style='color:green'>✅ $file EXISTS</pre>";
    } else {
        echo "<pre style='color:red'>❌ $file MISSING</pre>";
    }
}
echo "</div>";

// 6. Test redirect function
echo "<div class='box'>";
echo "<h2>6. Redirect Test</h2>";
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    $dashboard_url = get_dashboard_url($_SESSION['role']);
    echo "<pre>Your dashboard URL: <a href='$dashboard_url'>$dashboard_url</a></pre>";
    echo "<p><a href='$dashboard_url' style='background:#2196F3;color:white;padding:10px 20px;text-decoration:none;border-radius:5px;'>Click to go to dashboard</a></p>";
} else {
    echo "<pre>Not logged in - <a href='login.php'>Go to login</a></pre>";
}
echo "</div>";

// 7. PHP Info
echo "<div class='box'>";
echo "<h2>7. Server Info</h2>";
echo "<pre>PHP Version: " . phpversion() . "</pre>";
echo "<pre>Server Software: " . ($_SERVER['SERVER_SOFTWARE'] ?? 'Unknown') . "</pre>";
echo "<pre>Document Root: " . ($_SERVER['DOCUMENT_ROOT'] ?? 'Unknown') . "</pre>";
echo "</div>";

echo "<div class='box' style='background:#fff3cd;border-left-color:#ffc107;'>";
echo "<p><strong>⚠️ DELETE THIS FILE after debugging!</strong></p>";
echo "</div>";

echo "</body></html>";
?>
